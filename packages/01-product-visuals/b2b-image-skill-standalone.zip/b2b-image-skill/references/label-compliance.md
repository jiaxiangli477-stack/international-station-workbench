# 包装标签合规资料库（产品实物标签 · 美国市场 · FDA）

> ## 🔴🔴 先分清两个面，别搞混（最重要）
>
> 这份管的是**产品实物标签（罐身/袋身/盒面上印的字）** —— 卖到美国的成品必须守的 **FDA 标签法**。
> **它不是阿里出图的文案规则。**
>
> | | 阿里 listing 图（本 skill 的产出） | 产品实物标签（这份管的） |
> |---|---|---|
> | 权威源 | `copy-compliance.md`（§2.1 **禁任何 FDA 内容**） | **本文件**（FDA 标签法） |
> | FDA 字样 | ⛔ **一律不出现**（含免责段、`FDA Registered`） | ✅ 按 FDA 法**该印的要印**（S/F 宣称要带免责） |
> | 功能宣称 | ⛔ 改零宣称/纯规格 | ✅ 结构/功能宣称合法（带免责 + 通报），疾病宣称禁 |
>
> 🔴 **红线：本文件里任何 FDA 免责/宣称文字，绝不能因为"这里说该印"就搬进阿里主图/详情页。**
> 阿里图那边 §2.1 说了算 —— 免责段本身也禁。两个面各守各的源，冲突时看你在做哪个面。

## 什么时候用这份

1. **审/清理产品实物照里的标签**：真实产品照上印的字要不要合规（配合 `verify_label.py` 查 AI 有没有改字、`packaging-cleanup.md` 擦假认证标）。
2. **新品模式设计一张新包装的标签**（`new-product.md`）：要让标签在美国买家眼里**法规上站得住**——该有的元素别缺、宣称别越界。买家是要拿去美国卖的品牌方，标签不合规等于给客户埋雷。
3. **回答买家/客户"美国标签要印什么"**：给出依据，别凭印象答。

> ⚪ **范围**：本期只铺**美国 FDA**（美国优先）。欧/英/澳的标签制度另有格式（EU FIC、UK、AU/NZ），**第二阶段再补**，别拿美国这套硬套别国。

---

## 1. 膳食补充剂标签的 5 个强制元素（缺一即不合规）

FDA 要求膳食补充剂标签必须有这 5 项，且**分панель摆放有规定**：

| # | 元素 | 摆哪个面 | 要点 |
|---|---|---|---|
| 1 | **Statement of Identity**（品名） | **主展示面 PDP** | 必须含 `dietary supplement` 字样；`dietary` 可换成成分类型（`herbal supplement`）或成分名（`bee pollen supplement`）|
| 2 | **Net Quantity of Contents**（净含量） | **主展示面 PDP** | 数量/净重（如 `60 capsules` / `Net Wt. 120 g`）|
| 3 | **Supplement Facts panel**（营养成分表） | 信息面 | 见 §2 |
| 4 | **Ingredient list**（配料表） | 信息面 | 若成分未全部在 Supplement Facts 里列出，须另附配料表 |
| 5 | **Name & Place of Business**（厂商/包装商/经销商名址） | 信息面 | 制造/包装/经销方名称与地址 |

- **PDP = Principal Display Panel**：货架上正对买家那一面。品名 + 净含量必须在这。
- **信息面 = Information Panel**：通常在 PDP 右侧那一面。③④⑤ 若不在 PDP 上，就必须齐聚在信息面。
- 🔴 **新品标签设计自检**：这 5 项一项都不能少。AI 生图的包装最爱只画个漂亮品名、把营养表/配料表/厂商名址全漏掉 → 法规上是废标。

> 📌 CFR 查证号（下结论回 FDA 官方指南核，别只认这几个号）：品名 21 CFR 101.3 · 净含量 101.105 · Supplement Facts 101.36 · 配料表 101.4。

## 2. Supplement Facts panel（营养成分表）

- 做**营养素含量宣称**（nutrient content claim）时**必须**有 Supplement Facts panel。
- 格式受 **21 CFR 101.36** 管：每份用量（serving size）、每份含量、每日摄入量百分比（%DV）等。
- 🔴 **这张表是"事实陈述"** —— 数字必须真实。跟 `compliance.md §3.5`「没配方别编」一条线：没有本款真实配方时，走**样例配方话术**（`Sample formula shown…`），别编一张假的 Supplement Facts。
- ⚠️ **AI 改字高危区**：`verify_label.py` 重点盯的就是成分名/含量数字被 AI 悄悄改掉（实测被改过注册类目、成分名）。经 gpt-image-2 生成/去遮挡的标签，必跑 `verify_label.py` + 人工放大。

## 3. 宣称：结构/功能宣称 vs 疾病宣称（红线在这）

FDA 把补充剂能说的话分两类：

### ✅ 结构/功能宣称（Structure/Function Claim）—— 合法，但有三件套
描述成分对**身体正常结构或功能**的作用（如 `supports immune health`、`helps maintain healthy energy levels`）。合法，但**产品实物标签上**必须同时满足（依 FD&C Act 403(r)(6) + **21 CFR 101.93**）：
1. **有实证支撑**（truthful and not misleading，厂方留证）；
2. **紧挨宣称印上免责声明**（原文，一字不改）：
   > **This statement has not been evaluated by the Food and Drug Administration. This product is not intended to diagnose, treat, cure, or prevent any disease.**
   —— 免责须**紧贴宣称**、中间不插别的内容；或印在同一面/同一页上带该宣称处。
   - **一条宣称用单数 `This statement`；同一处有两条及以上宣称时用复数形式**：
     > **These statements have not been evaluated by the Food and Drug Administration. This product is not intended to diagnose, treat, cure, or prevent any disease.**
   - 业内常见的简写变体 `*These statements have not been evaluated by the FDA.`（把机构名缩写成 FDA、前置星号）**在美国实物标签上属于非标准写法** —— 标签上按 21 CFR 101.93 印**全称** `Food and Drug Administration`。
     （📌 该简写变体原先存放在 `compliance.md §3`，现已按「阿里图禁任何 FDA 内容」从那边删除、原文归档到此处，避免信息丢失。⛔ 它同样**不得**出现在阿里 listing 图上。）
3. **上市后 30 天内向 FDA 通报**该宣称文本（厂方义务，不是我们出图的事，但设计标签时要知道这条存在）。

> 🔴🔴 **但这三件套只属于【产品实物标签 / 美国市场】。阿里 listing 图 → §0 表已说：免责段禁出现，功能宣称改零宣称。别把这段免责搬进阿里图。**

### ⛔ 疾病宣称（Disease Claim）—— 禁，没有"加免责就能说"这回事
明示或暗示能**诊断/治疗/治愈/缓解/预防疾病**的话（`cures cancer`、`treats diabetes`、`lowers blood pressure`、`anti-inflammatory` 当疗效用……）**一律禁**，加免责也不行——补充剂不是药。
- 禁词表与 `copy-compliance.md §1.1`（疾病/治疗）完全对齐，那份是词表权威源。
- 暗示也算：把产品和某个病名/药物形象并置、放病理图、`FDA approved to treat…` 等。

## 4. ⛔ `FDA approved` / `FDA certified` —— 补充剂不存在这回事

- **FDA 不审批、不认证膳食补充剂**（上市前不需要 FDA 批准）。任何 `FDA approved`、`FDA certified`、`approved by FDA` = **虚假宣称**，实物标签和阿里图**两边都禁**。
- 设施层面 FDA 只做**注册（registration）**。在**美国市场语境**可写 `FDA-registered facility`（主语是工厂不是产品，同 `compliance.md §2` NSF 那条逻辑）。
- 🔴 **阿里图更严**：连 `Registered` / 任何 `FDA` 字样都不出现（`copy-compliance.md §2.1`）。**这份的"美国标签可写 registered"不适用于阿里图。**
- 平台侧印证：阿里国际站《保健食品(膳食补充剂)资质准入、管控规则》明令禁止宣称"膳食补充剂已获美国 FDA 批准"（见 `copy-compliance.md` 附录·官方规则出处）。

## 5. 过敏原标注（FALCPA + FASTER Act）

FALCPA 适用于**包括膳食补充剂在内**的预包装食品：**主要食物过敏原**必须在标签上明确标出。

- **9 大过敏原**（2004 FALCPA 8 种 + FASTER Act 新增芝麻，**自 2023-01-01 起芝麻为第 9 种**）：
  牛奶 milk · 蛋 eggs · 鱼 fish · 甲壳类 crustacean shellfish · 坚果 tree nuts · 小麦 wheat · 花生 peanuts · 大豆 soybeans · **芝麻 sesame**。
- **`Contains` 声明的位置**：有配料表时，`Contains …` 紧跟/紧邻配料表之后；标签没有配料表时，`Contains` 印在 Supplement Facts 外侧、紧跟/紧邻其后。
- 🔴 新品标签设计：产品若含上述过敏原（很多补剂含大豆卵磷脂、乳清=牛奶、坚果），标签**必须**有对应过敏原声明——漏了是实打实的召回级风险。

## 6. 和现有工具/红线怎么接

| 关注点 | 去哪 |
|---|---|
| AI 有没有改标签上的字（成分名/含量/类目） | `scripts/verify_label.py`（筛子，须人工放大确认） |
| 标签上 AI 自画的假 NSF/GMP 标、假专利标、乱码 | `references/packaging-cleanup.md`（⛔ 别用 edits 重画） |
| 标签上的**文字**禁用词（疾病/治疗/专利成分®/organic/绝对化） | `copy-compliance.md §1`（词表权威源 + `verify_copy.py`）|
| 工厂级认证 ≠ 产品级认证（NSF 印在产品上 = 宣称产品级） | `compliance.md §2` + `copy-compliance.md §4` |
| 没有本款真实配方 → 别编 Supplement Facts | `compliance.md §3.5` 样例配方话术 |
| 商标（品名/logo 别撞他人注册商标） | `copy-compliance.md §7` |

---

## 来源（本轮已核，2026-07-30）

- **FDA Dietary Supplement Labeling Guide**（膳食补充剂标签总纲）：
  https://www.fda.gov/food/dietary-supplements-guidance-documents-regulatory-information/dietary-supplement-labeling-guide
  - Chapter I 一般标签（5 元素 / PDP vs 信息面）· Chapter II 品名 · Chapter III 净含量 · Chapter IV 营养标注 · **Chapter VI 宣称**。
- **DSHEA 免责声明 / 结构功能宣称**（21 CFR 101.93）：
  https://www.fda.gov/food/information-industry-dietary-supplements/notifications-structurefunction-and-related-claims-dietary-supplement-labeling
  免责原文见 §3；FDA 致行业信：https://www.fda.gov/food/information-industry-dietary-supplements/letter-dietary-supplement-industry-dshea-disclaimer
- **FALCPA 过敏原**：https://www.fda.gov/food/food-allergensgluten-free-guidance-documents-regulatory-information/food-allergen-labeling-and-consumer-protection-act-2004-falcpa
  （芝麻为第 9 大过敏原 = FASTER Act，2023-01-01 起生效。）
- FDA 食品总入口（法规导航）：https://www.fda.gov/food
- 🔴 **CFR 号仅供查证**（21 CFR 101.3/101.4/101.36/101.93/101.105/101.36）；**下结论回 FDA 官方指南原文核**，第三方转载有延迟。
- ⚪ **第二阶段待补**：欧盟 FIC / 英国 / 澳新标签格式；各原料专利品牌完整清单；各国目的地资质制度（部分见阿里跨境资质规则）。
