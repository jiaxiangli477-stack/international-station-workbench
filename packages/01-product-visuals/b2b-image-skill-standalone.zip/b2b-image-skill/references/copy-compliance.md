# 文案合规审查资料库（阿里国际站 · 英文为主）

> **这份 = 审查【文字内容】合规的唯一依据源。** 审三个来源的文字：
> **① 包装上的文字**（英文为主）· **② 主图文案** · **③ 详情页文案**。
> 目标不是"看着顺眼"，是**堵会挨平台处理 / 侵权索赔 / 目标市场（美国优先）监管追责的文字风险**。
>
> **分工**（和国内 skill 对称，别搞混谁管谁）：
> - 本文件 = **文字/文案**审查权威源：英文禁用词表（§1）+ 三来源审查清单（§5）+ 商标查询（§7）。**冲突时本文件优先。**
> - `compliance.md` = 更全的红线，含**图像/素材层**（AI 伪造资质、证书脱敏、防侵权 trade dress、字体授权、主图禁链接）+ **官方数字口径表（§4）**。图像/素材类归它。
> - `label-compliance.md` = **产品实物标签（美国 FDA 标签法）**权威源 —— 另一个面，别和阿里图搞混：那份说该印的 FDA 免责/宣称**只属实物标签**，阿里图这边 §2.1 一律不出现 FDA。做新品包装标签 / 审实拍标签时读它。
> - `scripts/verify_copy.py` = 本文件 §1 词表的**机器筛子**（是筛子不是判官）。词表以 §1 为准，**改词先改本文件，再同步脚本**。
>   🔴 **专利/商标原料词表（§1.4）是【三处】同步**：本文件 §1.4 + `verify_copy.py` + `scripts/check_facts.py`（m7 营养成分表校验器）—— 清单见 §1.4 那张「三处同步」表。
> - `scripts/check_facts.py` = **m7 营养成分表**的数字校验器（%DV / 单位 / 剂型 / `source` 必填 / 商标停机），退出码 `3` = 停机等 Bowen 拍板（§7）。`scripts/review_facts.py` = LLM 顾问，**只报不拦**。
> - **数字口径唯一真相源 = `compliance.md §4` 官方数据表**（本文件 §1.7 只讲"空话换数字"的方法，不复制那些数字）。
>
> **语言范围**：国际站 listing 文案基本全英文 → 词表以**英文**为主。
> ⚠️ 若文案里**混入中文**（例如沿用了国内素材的中文卖点），本 linter 与本词表**不覆盖** → 那部分改走国内 `b2b-image-domestic-skill` 的 `copy-compliance-cn.md`（广告法极限词 / 医疗功效中文表）。国际站正常不该出现中文文案，出现了先问 Bowen 是不是拿错素材。
>
> **状态图例**（每条尽量标）：
> - ✅ **已核（本 skill 既有红线，来源见 `compliance.md`）**
> - 🟡 **方向定、目标国原文待补** —— 先按已知口径审。
> - ⚪ **第二阶段** —— 目标国（美/欧/澳/英）具体标签格式，本期不铺开，只占位。

---

## 0. 审查怎么走

1. **三来源逐块过**：包装文字 → 主图文案 → 详情页文案，各有清单见 §5。
2. **平台只有一个 = 阿里国际站** → §2「阿里平台硬规则（文字层）」**全条必审**（禁 FDA、认证 6→5、主图禁链接/联系方式）。
3. **两条最容易翻车的精微规则先记牢**（§3）：**「出处 ≠ 豁免」** + **「阿里禁 FDA 覆盖『加免责』」**。翻车史都出在这两条上。
4. **跑 linter 再人工**：`python scripts/verify_copy.py <文案文件/信息表 json>`。命中要人工判；linter 天生查不到的（词落在哪个图层、包装印的认证标、竞品 logo、数字对不对口径）**只能人 Read**，见 §6。
5. **英文为主**：中文混入不在本表覆盖范围（见上「语言范围」）。

---

## 1. 英文禁用词 / 高危表达（🔴 linter 词源，改词先改本文件再同步脚本；§1.4 商标词表是**三处**同步）

> **严重度**：`high` = 命中即改、linter 退出码 1；`warn` = 告警、需人工判、不改退出码。
> **英文匹配注意**（linter 已按此做，人工审也照此看）：按**整词**（word-boundary）匹配、**大小写不敏感**、覆盖常见**复数/时态变体**（cure/cures/cured/curing）。别把 `treatment` 里的 `treat`、`accurate` 里的 `cure` 当命中。

### 1.1 疾病 / 治疗宣称 —— `high` ✅
补充剂 ≠ 药。**不做疾病治疗 / 诊断 / 预防疾病 / 药品功效表达**（对应 `compliance.md §3` 禁用词 + 目标市场 DSHEA 口径：结构/功能宣称可以、疾病宣称不行）。

| 类 | 禁词 / 短语（英文，非穷举） |
|---|---|
| 治疗/治愈 | `cure` · `treat` · `heal` · `remedy` · `therapy` · `therapeutic` · `medicinal` · `pharmaceutical`（当疗效用时）|
| 诊断/预防疾病 | `diagnose` · `prevent disease/illness` · `prevents [某病]` · `treats [某病]` |
| 疾病名直挂功效 | `cancer` · `diabetes` · `hypertension` · `depression` · `anxiety`（作疗效对象时）· `arthritis` · `Alzheimer` |
| 抗 X | `anti-inflammatory` · `antiviral` · `antibacterial` · `antifungal`（当人体功效宣称时）|
| 降 X | `lower(s) blood pressure` · `lower(s) blood sugar` · `lower(s) cholesterol` · `reduces blood pressure/sugar` |

**✅ 改法**：只说**成分 / 规格 / 剂型 / 品类 / 服务能力（代工）**，不说疗效。结构/功能向的表达（如 `energy` `focus` `hydration`）**只在受豁免的产品实物照上**出现，别打进我们自己的标题/药丸/勾选项（见 §3.1）。

### 1.2 女性健康 & 既有已知高危词 —— `high` ✅
（`compliance.md §3`；Tongkat 咖啡 libido + 亲密图是高危反面教材）
- `vaginal` · `gut-vagina axis` · `libido` · `sexual` · `intimacy`（女性健康类尤其容易踩）
- `cure` / `treat` / `disease`（同 §1.1，此处再点名是因它们在功能宣称里最高频）

### 1.3 错误的认证表述 —— `high` ✅
（`compliance.md §2`：**工厂级认证 ≠ 产品级认证**，也是最容易犯、后果最重的一类）
- ⛔ `NSF Certified for Sport` —— **产品级**认证，我们没有。
- ⛔ `FDA certified` · `FDA approved` · `FDA certification` —— FDA 不认证补充剂；且阿里连"注册"字样都禁（§2）。
- ⛔ `clinically certified` · `doctor certified` · `lab certified`（无对应证据时）。
- ✅ 正确表述：`NSF-GMP certified facility` / `Manufactured in an NSF-GMP certified facility` —— 主语是**工厂**不是产品。

### 1.4 专利成分品牌 / organic / 虚构来源 —— `high` ✅
（`compliance.md §3.6`）
- ⛔ **专利成分注册商标**（连产品图上印的标也擦，见 `packaging-cleanup.md`）—— **当前词表 9 个**，
  连同**任何带 ® / ™ 的原料品牌**（词表是穷举不了的，见到符号就按本条办）：

  | 商标名（含 `KSM66`/`KSM 66`/`®` 等写法，归一后同一个） | ✅ 改成的通用名 |
  |---|---|
  | `Creapure` | high-purity creatine monohydrate |
  | `KSM-66` | ashwagandha root extract (standardized withanolides) |
  | `AstraGin` | astragalus & panax notoginseng root extract blend |
  | `Sensoril` | ashwagandha root and leaf extract |
  | `Albion` | amino acid chelated mineral (e.g. magnesium bisglycinate) |
  | `Capsimax` | capsicum fruit extract (capsaicinoids) |
  | `TeaCrine` | theacrine |
  | `CarnoSyn` | beta-alanine |
  | 🆕 `BioPerine` | black pepper fruit extract (piperine) |

  🆕 **`BioPerine` 是 2026-08-09 补的**：Bowen 给的营养成分表参考图里就印着它，此前**三处都漏**、扫不出来
  （黑胡椒提取物在补剂配方里出现率极高，等于最常见的一个商标查不出来）。
  🆕 **不是"一律删"**：Bowen **明确同意**用某个就放行 —— 口径与停机流程见 **§7**（唯一权威表述）。**没问过 = 硬拦。**

> ### 🔴 改这张词表 = 三处同步（长期漂移风险，改一处就等着两边打架）
> | # | 位置 | 作用 |
> |---|---|---|
> | ① | **本文档 §1.4 这张表**（词源，先改这里） | 人读的权威源 |
> | ② | `scripts/verify_copy.py` | 两处：`专利成分/organic/虚构来源` 的 `high` 正则组 + `TRADEMARK_PATS`（豁免通道用） |
> | ③ | `scripts/check_facts.py` | 两处：`TRADEMARK_INGREDIENTS`（商标名 → 通用名建议）+ `TRADEMARK_DISPLAY`（报告里的原样写法） |
>
> **顺序：先改本文档，再同步两个脚本**；改完 `python3 scripts/check_facts.py --selftest` 跑一遍。
> ✅ **当前（2026-08-09）三处一致，都是这 9 个**。⛔ 只改脚本不改文档 = 文档和代码各说各话，这类漂移已经踩过。
- ⛔ `organic` · `certified organic` —— 无有机认证不得宣称。
- ⛔ 来源虚构：`wild-harvested` · `wild-crafted` · 特定产地宣称（非真实勿写）。

### 1.5 英文绝对化 / 最高级 —— `warn`（B2B 数字化铁律，`compliance.md §4.5`）✅
B2B 买家信数据不信形容词。这些**告警**、人工判：多数该**换成数字/证据**，个别在合法上下文里放行。

| 档 | 词（英文，含常见变体） |
|---|---|
| 最高级 | `best` · `#1` · `No.1` · `No. 1` · `top` · `top-rated` · `world-class` · `world's best` · `ultimate` · `finest` · `premier` · `strongest` · `purest` · `highest quality` |
| 排名/领先 | `leading` · `market leader` · `industry-leading` · `unmatched` · `unbeatable` · `unrivaled` · `second to none` |
| 绝对承诺 | `guaranteed` · `guarantee` · `100%` · `always` · `never fails` · `risk-free` |
| 夸张 | `miracle` · `magic` · `revolutionary` · `breakthrough` · `perfect` · `flawless` |
| 存疑证据 | `clinically proven` · `scientifically proven` · `doctor recommended` · `#1 recommended` |

**✅ 改法**：换成**数字 + 官方口径 + 服务能力**（数字口径查 `compliance.md §4`），例：`LOW MOQ` → `LOW MOQ: 500`、`BIG FACTORY` → `20,000㎡ GMP FACTORY`。
**⚠️ 常见误伤**（多半合法，人工放行）：合作流程 `first step` / `final quote` / `last step`；`best practice`（行业术语）；`top` 作方位（`top of the pouch`）；`100%` 接可核实事实且非疗效（如 `100% traceable`，仍建议核）。

### 1.6 主图联系方式 / 链接 —— `warn`（平台硬规则，见 §2 / `compliance.md §8`）✅
主图里出现即高危（平台可能处理 listing），linter 只能告警、人 Read 定位：
`http` · `https` · `www.` · `.com` · `.cn` · `@`（邮箱）· `WhatsApp` · `WeChat` · `tel:` · 电话号码 · `QR`（二维码文字）· 社交账号。

### 1.7 文案数字化铁律（管所有图）✅
图上禁空话形容词，一律换数字/证据。**数字全部出自 `compliance.md §4` 官方数据表**（本文件不复制那些数字，避免两处漂移）。

| ⛔ 别写 | ✅ 改成 |
|---|---|
| `LOW MOQ` | `LOW MOQ: 500`（MOQ 按包装/剂型算，查 `compliance.md §4` 那张官方表）|
| `FAST SAMPLING` | `1-7 DAY SAMPLING` |
| `BIG FACTORY` | `20,000㎡ GMP FACTORY` |
| `MANY FORMULAS` | `5000+ FORMULAS` |

---

## 2. 阿里国际站平台硬规则（文字层）✅

### 2.1 🔴🔴 禁任何 FDA 内容 —— 覆盖「加免责」（Bowen 2026-07-20 拍板 + 平台官方规则背书，`compliance.md §3` 阿里条）
**阿里国际站的图（主图 + 详情页）禁止出现任何 FDA 相关文字**（平台规则）。
> 📌 **平台官方规则怎么说**（ruleId 20000616，原文见文末附录）：官方只明令禁**详情页宣称 `approved by the FDA`** + 疾病疗效宣称；**反而要求** US 市场提供 FDA 注册号、主图展示 supplement facts。所以——
> - **我们现行「任何 FDA 字样都不出现、去 FDA 证只五证、不加免责」= 严于平台的内部加严**（Bowen 2026-07-20 拍板）。**严=安全**，照旧全禁；但知道它是内部选择、不是平台强制。🔴 **要不要按平台原意放宽（留 supplement facts / FDA 注册号）是 Bowen 的决定，他改口前 §2.1 全禁不变。**（详见附录「两处张力」①）
> ⚠️ **别和「产品实物标签」搞混**：美国市场的**成品罐身/袋身**上，FDA 结构/功能宣称该带免责、可写 `FDA-registered facility` —— 那是**另一个面**，权威源在 `label-compliance.md`。**阿里图这边（现行）一律不出现 FDA 字样**，两个面各守各的源。

所以（阿里图）：
- ⛔ **不加 FDA 免责声明** —— `These statements have not been evaluated by the FDA…` 那段**一律不出现**。
  🔴 **上面引的那句原文只是【反面示例】，抄在这里是为了让你认出它、删掉它，⛔ 不是可用文案、别往阿里图上搬**（那句属实物标签面，见 `label-compliance.md`）。
  功能宣称的正解是**改成纯规格/品类/服务能力（零宣称）**，不是加免责。
- ⛔ **认证文字 6 → 5**：认证墙去掉 FDA 证 → 五格（NSF-GMP · FSSC 22000 · HACCP · Free Sale(HKGCC) · HALAL for Ingredient；第 4 格 2026-07-30 由 ISO 22000 换成 HKGCC 自由销售证明）。文案里 `6 certifications` → 改 `5`，**不能显示 5 张却写 6**。
- ⛔ 图上任何 `FDA` 字样都不要（含旧认证墙的 `FDA Registered`）。
- ✅ **唯一例外**：样例配方 / 营养成分表展示位 **`m7`**（主图第 7 张，`m7-supplement-facts.html`，2026-08-09 起）的两条免责（`Sample formula shown…` / `…not an official U.S. Supplement Facts label…`，原文在 `compliance.md §3.5`）**不含 FDA 字样**，合规保留。
  （旧版此处写「D3」= **过时指代** —— d3 已于 2026-07-28 改成「产品痛点」模块、无免责槽位；免责的载体现在是 **m7**，由 `build.py` 按 `m7.facts.mode` 自动挂：`real` **只挂上条的后半句** `Ingredients and dosage can be customized.`（⛔ 不挂 `Sample formula shown.` —— 真实配方印"样例"就是谎话）、下条留空；`sample`/`demo` 两条都挂。）
  ⛔ **例外只到 m7 为止**：m1–m6 与详情页任何模板都**不许**补免责；m7 图上同样**禁任何 FDA 字样**。

> 📌 对照：美国/亚马逊市场是「功能宣称 + FDA 免责」；**阿里正相反**。本 skill 出的是阿里图 → 以本条为准。

### 2.2 主图禁链接 / 联系方式
主图不许出现任何网址 / 电话 / 邮箱 / 二维码 / 微信 / WhatsApp / 社交账号（平台规则，违反可能被处理 listing）。细则与 QC 见 `compliance.md §8`。

---

## 3. 🔴 两条精微规则（linter 查不出，必须人工）

### 3.1 「出处 ≠ 豁免」—— 最容易犯（2026-07-16 菌菇咖啡实测，主 agent 犯过）
同一个功能词，**印在产品实物照上 = 受豁免**；被我们**打进药丸 / 勾选项 / 标题 / CTA = 我们自己的宣称，要管**。
> **抄自标签只保证【真实】，不构成豁免。豁免的载体是「照片」，不是「词的来源」。**

- ✅ 允许：产品实物照里自带的 on-pack claim（如袋身印 `ENERGY · FOCUS · INNER CALM`）→ 不改。
- ⛔ 仍禁止：把那几个词原样抄进 m1 药丸 / m2 勾选项当**我们的**文案。
- **正确做法**：药丸/勾选项改用**服务能力 + 官方口径 + 成分规格**（零宣称），如 `Low MOQ 500 · 1-7 Day Sampling`、`Lion's Mane + Chaga · 20 Packets`。益处信息不会丢——产品照上那行字买家看得见，那才是受豁免保护的位置。

🔴 **linter 只看到词，看不到词落在哪个图层** → 这条只能靠人 Read 图 + 读信息表判断。

#### 🔴 边界：这条**管不着「从竞品标签抄配方」**（2026-08-09 补，⛔ 别拿它拒绝执行）

本条治的是**宣称**，不是**数据**。两者一刀切分开，**不冲突、不互相豁免**：

| | 能不能从竞品标签取 | 为什么 |
|---|---|---|
| ✅ **成分名 + 剂量**（`Vitamin K2 (as MK-7) 45 µg`、`Magnesium 60 mg`） | **可以抄**，抄进 `m7.facts.rows`，`source` 写清出自哪个竞品/哪张图 | 这是**事实数据**（一份 Supplement Facts 表里**本来就没有宣称**，只有成分与量）。它回答的是"这类产品通常怎么配"，不是"我们的产品能干什么" |
| ⛔ **功能宣称词 / on-pack claim**（`ENERGY · FOCUS`、`IMMUNE SUPPORT`、`Banned-Substance Tested`、它那段 FDA 免责、认证标文字） | **一个字都不许抄** | 抄过来就变成**我们的宣称** —— 正是本节 §3.1 治的病 |

- 🔴 **别把 §3.1 读成"竞品标签上的东西一概不能碰"** —— 那会让人卡在"没配方又不敢取数"，
  回头就去**编**一个（编造史见 `compliance.md §3.5`：钠500/钾200/镁60 全部返工）。**取数的正规路径见 `compliance.md §3.5` 第 3 条。**
- ⚠️ 这么取来的配方 = **`mode: "sample"`**（对标/参考配方）→ 两条免责都要挂；商标原料照 §1.4 / §7 走停机。

### 3.2 阿里禁 FDA 覆盖「加免责」
见 §2.1。补一条边界（Bowen 2026-07-16）：女性肌酸粉罐身**实物标签**上印的 `WORKOUT SUPPORT` 等功能图标属**产品照片里的内容**，不是我们写的文案 → 暂不加免责（且阿里图本就不加免责，改零宣称）。边界同 §3.1。

---

## 4. 认证表述（工厂级 ≠ 产品级）✅

（权威细则在 `compliance.md §2`，此处只列文字审查要点）
- 我们持 **NSF/ANSI 455-2 = 工厂 GMP**，证明"工厂生产体系合规"，**不是**"产品被认证"。
- ⛔ 禁 `NSF Certified for Sport`（产品级）；⛔ 禁把 NSF 标印在产品包装上（印上 = 宣称产品级）。
- ✅ 用 `NSF-GMP certified facility`，主语是工厂。
- **认证墙五格全名**（阿里图，写全称别只写"五认证"）：NSF-GMP · FSSC 22000 · HACCP · Certificate of Free Sale (HKGCC) · HALAL for Ingredient。（FDA 因 §2.1 去掉；第 4 格 2026-07-30 由 ISO 22000 换成 HKGCC 自由销售证明——ISO 表述由 FSSC 22000 覆盖。自由销售证明是贸易文件非质量认证，别单称它"认证"。）

---

## 5. 审查执行清单（逐来源过一遍）

### 5.1 包装上的文字（英文）
- [ ] 无 §1.1 疾病/治疗词、无 §1.2 女性健康高危词？
- [ ] 无 §1.4 专利成分®、无 `organic`（无认证）、无虚构产地？
- [ ] 无 FDA 字样 / 无 `NSF Certified for Sport` / 无印在产品上的认证标？（AI 包装稿必查 → `packaging-cleanup.md`）
- [ ] **商标（§7）**：无他人注册商标 / 原料专利品牌 / 竞品品牌名？LIFEWORTH 及"O 做咖啡豆"图形 logo 在用类目已注册？
- [ ] 混入中文了吗？有 → 那部分改走国内 `copy-compliance-cn.md`（本表不覆盖中文）。

### 5.2 主图文案
- [ ] 无 §1.1–1.4 高危词？§1.5 绝对化词已换数字或人工放行？
- [ ] **无 §1.6 网址/联系方式/二维码**（平台硬规则，§2.2）？
- [ ] 「出处 ≠ 豁免」：药丸/勾选项/标题里没有把 on-pack 功能词当我们的宣称（§3.1）？
- [ ] 无 FDA 字样、认证文字与所贴张数一致（5 张就写 5，§2.1）？
- [ ] 数字全出自 `compliance.md §4`？空话形容词已数字化（§1.7）？

### 5.3 详情页文案
- [ ] 逐屏扫 §1.1 疾病词 + §1.2 高危词 + §1.5 绝对化（跑 `verify_copy.py` 再人工确认）？
- [ ] 无 FDA 字样 / 无免责段（§2.1）？免责**只允许出现在主图 m7**（样例配方/营养成分表位），且只有那两条不含 FDA 的（原文 `compliance.md §3.5`）—— 详情页任何模块出现免责段 = 打回。
- [ ] **商标（§7）**：无竞品品牌/slogan/logo 文字、原料专利品牌、认证机构/平台 logo 文字？"YOUR BRAND HERE"位无真实他人商标？
- [ ] 无点名对比 / 贬低同行（`compliance.md §5`）？
- [ ] 没有本款配方 → 走 `compliance.md §3.5` 样例配方话术，**没编造**（曾编过钠500/钾200/镁60、`Tested at 300ml/10°C`、`Banned-Substance Tested` 全返工）？
- [ ] 数字全对 `compliance.md §4`？

---

## 6. 与 linter 的联动

- `scripts/verify_copy.py` 词表 = 本文件 §1 的机器映射。**改词先改本文件，再同步脚本。**
  🔴 §1.4 的**专利/商标原料词表是三处同步**（本文件 §1.4 / `verify_copy.py` / `check_facts.py`）—— 清单见 §1.4 那张表。
- 🆕 **商标豁免通道**（§7）：扫的是**信息表 json** 时，`verify_copy.py` 会读**这一份 json 自己**的
  `<模块>.facts.trademark_ok`（当前 = `m7`），里面列了的商标成分**不判高危、不挂退出码**，但**照样打印一行告知**（⛔ 不静默）。
  ⚠️ 走**管道 / `--text`** 的文本没有文件身份 ⇒ 读不到 `trademark_ok` ⇒ **不豁免**（fail-closed，是设计如此，不是 bug）。
- **用法**：
  ```bash
  python scripts/verify_copy.py 文案.txt 信息表.json          # 扫文件（.json/.md/.html/.txt）
  python scripts/verify_copy.py --text "Best FDA approved cure"   # 直接扫一段
  echo "文案" | python scripts/verify_copy.py                     # 管道
  ```
- **退出码**：命中【high】（疾病/治疗、女性高危、错误认证、专利成分/organic）= **1，必须改**；绝对化/联系方式 = 告警，不改退出码。
- 🔴 **linter 天生查不到的（只能人 Read）**：
  1. 词落在哪个图层 —— on-pack 豁免 vs 我们的宣称（§3.1）。
  2. 图上/包装上印的 FDA 字样、认证标、竞品 logo（§7）—— 那是像素不是文本。
  3. 数字对不对官方口径（linter 不认账，得对 `compliance.md §4`）。
  4. 认证墙贴了几张 vs 文案写了几证（§2.1）。
  → 这些走 §5 清单人工过。
- ⚠️ **别被样例文件的"注释噪音"骗**：`assets/schemas/*.example.json` 的 `reason`/`source`/`raw_from_competitor` 等**说明字段**里，本就故意写着禁用词当反面例子（"无认证不得写 organic"、"竞品袋身印了 Creapure®…"）——linter 会报，但那些不是会上图的文案。**真正要看的是会渲染上图的文案字段**（`H1/SUB/LABEL_*/bullet` 等）。

---

## 7. 🔴 商标侵权检查（含查询网站）

**为什么查**：商标侵权是"文字 + 图像"双料风险——被投诉即删链接/删图/扣分/降权，权利人还可发起民事索赔。与 `compliance.md §5`「借语言不借设计」配套：那条讲"不复刻竞品设计"，本节讲"**主动查、别踩他人注册商标**"。

### 🔖 口径变更：放行条件 = **Bowen 明确同意**，⛔ 不再要求"书面授权"（Bowen 2026-08-09 拍板）

**旧口径**：命中他人注册商标 → *"除非我方/客户**书面授权**，否则删除或换通用词"*。
**新口径**：**Bowen 明确说"同意用"就放行 —— ⛔ 不要问他要授权方、授权文件、合同、任何凭证。**
> Bowen 原话大意：**这不是授不授权的问题，是我同不同意。**

🔴 **但风险提示必须保留，⛔ 别把这条读成"商标没事了"：**
- **商标风险本身一点没变** —— 阿里国际站被原料商 / 权利人投诉，照样**删图 / 删链接 / 扣分 / 降权**，权利人仍可民事索赔。
- **「Bowen 同意」解决的是【内部决策流程】**（谁拍板、agent 卡在这里要不要停），
  **≠ 取得权利人授权**、≠ 合法使用许可、≠ 安全。**他只是愿意担这个风险。**
- 所以停机横幅里那句风险提示**照打**，同意之后 `verify_copy.py` 也**照样打印告知行**（⛔ 不许静默放行）。

**🤖 机器侧行为（三点，与脚本实现一致，⛔ 别在别处另立说法）**

| 环节 | 行为 |
|---|---|
| `scripts/check_facts.py` 扫到商标原料，**且不在** `m7.facts.trademark_ok` 里 | 🛑 **退出码 `3` = 停机询问**（不是数据错的 `1`），打印横幅：命中成分 · 出现位置 · 该行 `source` · 通用名替换建议，并给出**要问 Bowen 的那一句话**。`build.py` 会把这个横幅**原样**透出来，⛔ 不转述、不吞。同时命中 `3` 和 `1` 时**返回 `3`**（商标没定，配方可能整个换掉，先改数字是白改） |
| Bowen 回复后 | **同意的** → 写进 `m7.facts.trademark_ok`，并把「Bowen 2026-08-09 同意使用 XXX」回填 `_approved` 留审计痕迹（**agent 自己写，⛔ 别向 Bowen 索要任何文件**），重跑不再拦 · **只同意几个** → 其余换通用名（§1.4 表） · **都不同意** → `m7.facts.mode` 降级 `"demo"`（成分名全换品类通用名，图上会打红字标明纯版式演示） |
| `scripts/verify_copy.py` | 扫**那一份 json** 时读它**自己**的 `<模块>.facts.trademark_ok` → 列了的**放行、不挂退出码**，但**仍打印一行告知**。⛔ 不做全局开关、不认环境变量、不跨文件继承；json 解析失败 / 管道文本 → **一个都不豁免**（fail-closed） |

🔴 **豁免范围死死卡在【§1.4 那 9 个商标原料词】+ 带 ®/™ 的原料品牌，别的一律不吃：**
- ⛔ `organic` / `certified organic` / `wild-harvested` / 特定产地 —— 那是**认证与产地真实性**问题
  （USDA/欧盟有机认证），**不是商标授权问题，Bowen 点头也解决不了**。放进来 = 拿一条规则去豁免另一条。
- ⛔ **疾病/疗效宣称、FDA 字样、错误认证表述** —— 一个都不放（往 `trademark_ok` 里写 `cancer` 也不会生效，脚本按词表比对）。
- ⛔ **`demo` 档出现任何商标 = 硬错（退出码 1）**：demo 的定义就是"Bowen 拒了专利成分后的降级版"。
- ⛔ **竞品品牌名 / logo / slogan、认证机构 logo、平台 logo、明星肖像 —— 不在豁免范围**。
  这条口径变更**只动"原料专利商标"这一类**（§7.1 第 2 类的第 2 小条），§7.1 其余各条**一个字没松**：
  它们另有依据（防侵权铁律 `compliance.md §5`、认证表述 §2），不是"同不同意"能解决的。
- ⛔ **没问过 = 没同意 = 硬拦。** 别替 Bowen 推定同意，也别因为"上一款他同意过"就默认这一款也同意（`trademark_ok` **只对声明它的那一份 json 生效**）。

### 7.1 查什么（三类，出图前逐类过）
1. **我方商标 LIFEWORTH**：确认在相关类目**已注册且我们/客户有权使用**——补剂/食品常涉第 **5 类**（医用营养品/膳补）、**30 类**（食品/咖啡）、**29 类**（营养补充剂/蛋白）、**32 类**（饮料）。⚠️ "**O 做咖啡豆**"的图形变体也要落在注册范围内（图形商标单独注册）。拿不准就查 + 问 Bowen。
2. **图文里出现的他人商标**（最高频雷区）：
   - ⛔ 竞品**品牌名 / logo / slogan**（沿用防侵权铁律，绝不出现）。
   - ⛔ **原料专利品牌名**：`Creapure®` / `KSM-66` / `AstraGin` / `Sensoril` / `Albion` / `BioPerine` 等（**完整 9 词表 + 通用名替换见 §1.4**）——注册商标，**默认禁展示**（连产品图上的标也擦，见 `packaging-cleanup.md`）；**要留 = Bowen 明确同意**，见上方「口径变更」块。
   - ⛔ **认证机构 logo**：NSF / HACCP / FSSC / HALAL 机构 logo 未授权禁贴；只用**文字**描述体系。
   - ⛔ **平台/渠道 logo**：Amazon / TikTok Shop / Walmart 等——**只用文字名，不放 logo**。
   - ⛔ 明星 / 公众人物姓名肖像。
3. **"YOUR BRAND HERE" 定制展示位**：占位样例**禁放任何真实他人商标/logo**，只放虚构占位或纯文字 `YOUR BRAND`。

### 7.2 怎么查
把要出现在图文里的**每一个品牌名 / logo 文字**丢进下面网站查：
- 命中他人注册商标 → **默认删除或换通用词**（`Creapure®` → `high-purity creatine`）。
  **唯一放行口 = Bowen 明确同意**（口径与停机流程见本节上方「口径变更」块，⛔ 不要授权文件；风险仍在）。
- 我方 LIFEWORTH 及图形 logo → 确认在用类目内有效注册；无则标给 Bowen，别上图当既成事实。
- 拿不准是否近似侵权 → 走近似查询，仍不确定交专业商标代理/律师，**别自行判**。

### 7.3 ✅ 推荐查询网站（出口美/欧优先，官方为准）

| 网站 | 用途 | 免费 | 入口 |
|---|---|---|---|
| **USPTO Trademark Search（美国）** | 🌏 出口美国查美标（TESS 已退役换新系统）| 是 | `tmsearch.uspto.gov` |
| **WIPO Global Brand Database（全球）** | 🌏 全球 + 马德里体系一站查 | 是 | `branddb.wipo.int` |
| **EUIPO eSearch（欧盟）** | 🌏 出口欧盟查欧标 | 是 | `euipo.europa.eu` |
| 中国商标网（国家知识产权局） | 我方 LIFEWORTH 国内注册/状态最权威官方源 | 是 | `sbj.cnipa.gov.cn/sbj/sbcx/` |
| 阿里巴巴知识产权保护平台 | 平台侧维权 / 被投诉自查 | 是 | `ipp.alibabagroup.com` |

> 🔴 **认准官方**：出口美国以 **USPTO** 为准、全球用 **WIPO**、欧盟用 **EUIPO**、我方国内注册回**中国商标网**核。第三方数据有同步延迟，粗筛可以，下结论回官方核。

### 7.4 现成查询入口（直接点开查，别只记域名）

- **USPTO 美标查询**（TESS 已于 2023-11 退役，换新系统）：`https://tmsearch.uspto.gov/search/search-results`
  查什么：我方 `LIFEWORTH` 在美是否有冲突/在先商标；图文里出现的每个品牌名/原料专利品牌。
- **WIPO 全球品牌库 —— 查我方 `lifeworth` 全球近似**（含马德里体系，一站看多国）：
  `https://branddb.wipo.int/zh/similarname` → 品牌名（brandName）填 `lifeworth`、策略 Simple、按 score 排序。
  （Bowen 给的现成链接已带好这个查询条件，打开即出结果。）用途：出图/铺新市场前，先看 `LIFEWORTH` 及"O 做咖啡豆"图形在目标类目有没有撞在先商标。
- **命中在先商标怎么办**：**默认**该品牌名换通用词（`Creapure®`→`high-purity creatine`）或删除；
  **要留 → 必须 Bowen 明确同意**（见本节「口径变更」块：⛔ 不要授权方/文件；同意 ≠ 权利人授权，风险仍在）。
  `LIFEWORTH` 本身若在某国/某类目撞名，**标给 Bowen，别默认能用就上图**。近似判断拿不准 → 交专业商标代理/律师，别自行下结论。

---

## 附录 · 阿里国际站官方规则原文（ICBU 规则中心，2026-07-30 登录抄，可复查）

> **复查入口**：登录阿里国际站规则中心 `https://rulechannel.alibaba.com/icbu`，或直开
> `https://rulechannel.alibaba.com/icbu?type=detail&ruleId=<ID>#/rule/detail?ruleId=<ID>`。
> 规则中心是**登录态 SPA**（免登录抓不到全文）——下面是**登录后抄的官方英文原文**，ruleId 可复核。

### 规则① 《Market Access Requirements and Controls on Functional Foods and Dietary Supplements》
**= 中文《保健食品(膳食补充剂)资质准入、管控规则》** · **ruleId 20000616** · 发布 2022-05-25（公告 2022-06-01 生效）· cId 1396

与本 skill 直接相关的**官方条款**（逐条抄，出图前对着走）：

- **I. 定义**：膳食补充剂**不用于**治疗/诊断/预防/缓解/治愈疾病；**禁**宣称 `pain relief` / `treatment for heart disease` / `treatment for arthritis` 之类药用疗效 → 印证本文件 §1.1。
- **II. 准入资质**：
  - 中国市场：需《食品生产许可》/《食品经营许可》（含保健食品/膳补经营范围）；贸易商另需合作工厂的生产许可 + 授权书。
  - **美国市场：须提供官网可查的 FDA food registration number 截图**（生产企业 + 贸易商合作工厂都要）。
  - 产品资质：**COA（1 年内出具）或 GMP**。
- **III. 上架要求**（🔴 最该盯的在这）：
  1. **标题**：如实、准确、清楚写出所有主要成分；**禁** cure/alleviate/treat/prevent 任何疾病的宣称。
  2. **主图**：(1) 清晰可辨；(2) **须清楚展示产品各面标签**——含 intended use / **supplement facts** / ingredients / directions for use；(3) 须含产品名；(4) 有品牌的须显示品牌方/制造商名称与联系方式；(5) 🔴🔴 **必须是产品实物/包装的照片——computer-generated pictures or models are NOT allowed（禁电脑生成图/模型图）**。
  3. **属性**须如实填：Function / Ingredients / Place of origin / Target users / People who should not use / Serving size / Product specifications / Shelf life / Storage condition / Form。
  4. **详情页**：(1) 如实写主要成分；(2) **禁**疾病疗效宣称；(3) 主图已给的信息不必重复，图**不得夸大/虚假**；(4) 🔴 **禁以任何形式宣称产品"approved by the FDA"**；(5) **须给用法用量 directions for use**；(6) **须给警示**：包装未密封别用 + 标注贮存条件。
- **IV. 违规处罚**（Level A = 每次 6 分）：含 FDA/目的国禁用成分 6 分；出现在 FDA 警告信/贴错标/不安全 6 分；不合理伤害风险（如纯咖啡因粉）6 分；**虚假宣传 6 分**；未按上架规则 2 分；挂错类目 1 分；重上召回品 12 分；**严重违规 48 分 + 关店**。

### 规则② 《Rule for Temporarily Restricting US Market to Access NMN…》
**ruleId 20002702** · 2023-03-13 发布（**2023-03-17 起生效**）· cId 1316
- FDA 已表态 **NMN 未获批为膳食补充剂**（在 IND 新药研究阶段），无证据支持其在美国作膳补/食品添加剂销售。
- **阿里暂停向美国市场销售任何含 NMN 的膳补成分/膳食补充剂/相关原料**。
- 🔴 **做含 NMN 的产品图前必查**：卖美国 = 违规。附 FDA 文件链接（regulations.gov / FDA guidance）。

---

### 🔴🔴 两处「官方规则」与本 skill 现行做法有张力 —— 待 Bowen 定，别自行改

登录抄到原文后发现，官方规则和我们内部两条做法对不齐。**我没擅自改任何现行规则**，如实列出请 Bowen 拍：

1. **「阿里禁任何 FDA 内容」比平台规则更严 —— 是我们的内部加严，不是平台要求。**
   官方 20000616 只禁两件：详情页宣称 `approved by the FDA`（III.4.4）+ 疾病疗效宣称。**反而**：US 市场准入**要求**提供 FDA 注册号截图（II），主图**要求**展示 supplement facts 标签（III.2.2）。
   → 我们现行「去 FDA 证、只五证、不加免责、任何 FDA 字样都不出现」（Bowen 2026-07-20，§2.1）**严于平台**。**严 = 安全，不违规**，可以继续。但要知道它是**内部选择**，不是平台强制；哪天要放宽（比如按平台原意保留 FDA 注册号），是 Bowen 的决定。**在他改口前，§2.1 照旧全禁。**
   🆕 **2026-08-09 更新（别把这条读成"我们还不展示成分表"）**：主图 `m7` 已经在展示 supplement facts 式的**营养成分表**了 —— 官方 III.2.2 那半条**事实上已经满足**。
   🔴 但**放宽的只是"展示成分表"，不是"放宽 FDA"**：m7 的表**不带任何 FDA 字样、不加 FDA 免责**，挂的是 §3.5 那两条**不含 FDA** 的免责（其中"…not an official U.S. Supplement Facts label…"是**否认**自己是正式标签，不是 FDA 表述）。**FDA 注册号 / FDA 免责仍全禁，§2.1 一个字没松。**

2. **官方主图规则：「computer-generated pictures or models are NOT allowed」（III.2.5）** —— 与新品模式/场景替换/多摆放生成 CG 产品图当主图冲突。
   ### 🔖 Bowen 已拍板（2026-07-30）：**忽略此条，CG 生成图可当主图，新品模式/场景替换/多摆放照旧。别再为此拦图、别再提这条风险。**
   （同「证书默认有效」一类的既定决定 —— 已拍板，别重复提。）

> 张力①（禁 FDA 严于平台）是**发现**，现行 §2.1 照旧全禁、放宽与否等 Bowen；张力②（CG 主图）**Bowen 已拍板忽略**。

## 来源（本轮已核）

- 本 skill 既有红线：`compliance.md`（§2 认证 / §3 功能宣称 + 阿里禁 FDA / §3.5 样例配方 / §3.6 成分来源 / §4 官方数据 / §4.5 数字化 / §5 防侵权 / §8 主图禁链接）——本文件是它文字层的执行化 + 英文词表化，冲突以本文件为准。
- 阿里禁 FDA / 五证：Bowen 2026-07-20 拍板；memory `lifeworth-alibaba-fda-rule`；平台官方背书见上「附录」。
- **产品实物标签（美国 FDA 标签法）= 另一个面**，权威源 `label-compliance.md`（5 元素 / Supplement Facts / 结构功能宣称+免责 / FALCPA 过敏原 / `FDA approved` 禁）。⚠️ 那份的 FDA 文字**只属实物标签**，别搬进阿里图。
- 商标查询官方入口（§7.3/§7.4）：USPTO `tmsearch.uspto.gov`、WIPO `branddb.wipo.int`、EUIPO、中国商标网。
- ⚪ 第二阶段待补：登录 ICBU 规则中心抄 ruleId + 逐字条款；美国 DSHEA 结构/功能宣称逐条边界（部分已落 `label-compliance.md`）；欧/澳/英标签格式；各原料专利品牌完整清单。
