# 新品模式 —— 参考竞品 → 造一款 LIFEWORTH 新品 → 出整套 listing

> 🔴🔴 **只在这两种情况才走本文档（= 生成新包装图）**（Bowen 2026-07-31）：
> ① **新品/竞品模式**：我们店铺**还没有**这个产品，只有别家竞品参考；或 ② 用户**明确要求**「走设计稿生成新的产品包装图」。
> ⛔ **品牌模式（用户给的是我们自己店铺已上线的产品链接）一律不走这里** —— 那种用**真实产品图**改主图/详情页，**禁重新生成包装**。判定见 `SKILL.md`「第 0 决策」。

**什么时候用**：手里没有本款产品，只有**一个别家品牌的参考**（阿里/亚马逊链接，或一张下载好的竞品主图），
想让 LIFEWORTH 做一款**类似的新品**。

**跟"品牌模式"的区别**：品牌模式是拿**我们已上线的真实产品**（真实产品图）去套主图/详情页模板、只改视觉；
新品模式是**先无中生有造出这款产品的包装白底图**，再当真产品图喂进 V2 出 listing。

> 🔴 **新流程（Bowen 2026-07-31 定，接进 V2）**，四段：
> ① **分析竞品**包装特色/卖点/人群（= 老的 Step 1-2，只落文字，绝不喂 img2img）→
> ② 写**包装设计稿**签字（= Step 3，包装本身长什么样、每条文案来源）→
> ③ **`gen_image.py --raw` 生成产品包装白底图**（= Step 4，文字/logo 烘进生图；**这张就是干净白底真产品图**）→
> ④ **接着走 V2**：把这张白底图当 `swap.product` 填进 `product.json`，`render_v2.py` 出整套 6 主图 + 12 详情块
>   （`scene-swap.md`【生产工作流 v2】）。此时产品背景才回到宝蓝 VI。
>
> ⚠️ 白底图出来后**不再抠透明**（V2 的 `--scene` 直接吃白底图）；⛔ 不因"小字要分毫不差"自动切抠图——只有用户明确要求"走抠图"才走。

**这个模式坐在两条已有铁律的交叉点上，先把它们记牢：**
- `compliance.md §5 防侵权`：竞品图**只做风格/构图参考，绝不喂高保真 img2img 复刻**。
- `packaging-cleanup.md`：AI 自画包装**最爱伪造 NSF/GMP 标 + 专利标 + 拼写乱码**。
- 全程还要过一遍 `compliance.md` 的功能宣称 / 成分来源 / 认证表述红线。

---

## 🔴 首次实跑经验（2026-07-20，ETHLETE 电解质+肌酸 → Peach Mango 新品；这些是踩出来的）

1. **Bowen 要文字/logo 在生图时就烘进去，不后期合成**（此决定已转正为 Step 4 标准路线；
   2026-07-27 Bowen 进一步把**工具也锁死**成中转生图通道，见 Step 4；当时那条通道是 TokenStation，
   2026-08-06 起换成 deepkey —— 锁的是"只准走 `gen_image.py`"，不是某一家中转）。
   → `gen_image.py --raw` 把**全部文字逐条锁进 prompt**。gpt-image-2 系列实测英文文字很稳、没乱码；出图后仍必 QC。
2. 🔴 **`--raw` 会绕掉脚本默认的"悬空无阴影"块** → AI 加烘焙阴影 → 抠图留白晕 + 撞模板 CSS 阴影 = 双重阴影。
   **用 `--raw` 必须手写 `floating in mid-air, no shadow, no reflection, nothing beneath` 进 prompt。**
3. ⚙️ **（仅走抠图法时）抠完必带 `--defringe 2` 去白边**（flood 二值边留白圈；见 `cutout.md`）。红底放大验彩色边。
   🔴 **默认 V2 不抠**：白底图直接喂 `--scene`（Bowen 2026-07-31，见下方 Step 4/6）。
4. **出图前先出老板格式设计稿**（痛点 / 产品色 / **每条文案来源**，格式见 `references/detail-page.md` §Step 1「设计稿签字，再跑代码」）。
   直接生图 → 中间太空、版式撞竞品，都是跳过设计稿的后果。
5. **"中间太空" 是图形处理问题，不是文字量问题** —— 参考靠**多层暖色波浪带**填充下半身，别靠加大水果/重排版式。
6. **新品模式只用参考本身取数**，别去引用户没提到的自有产品（一度误用"女性肌酸粉"配方被 Bowen 纠正）。
   🔴 **配方/营养表取数默认走 B（Bowen 2026-07-20 定）**：① 先读**参考产品自己的 Supplement Facts**
   （常印在袋背/主图，实测 ETHLETE 袋背就有完整 SF）；② 参考没有 → **用关键词去亚马逊搜一款规格/主成分相似的对标品，参考其配方含量**。
   都当"样例配方"出（挂 §3.5 两条免责，不含 FDA），⛔ 别编。⛔ 参考袋背印的 `FDA-registered facility`/FDA 免责**只取剂量数字、绝不抄**。

   > 🆕 **2026-08-09 起，这段取数有了落地载体和硬闸门 —— 三条差异补齐：**
   > 1. **取来的配方填进主图 `m7`**（营养成分表 / 参考配方展示位）的 `m7.facts`：`mode` = **`"sample"`**
   >    （对标/参考配方 → **两条免责都挂**，由 `build.py` 自动挂、⛔ 别手写）；每行 `name` / `amount` / `unit` / **`source` 必填**
   >    （`source` 写清出自哪个竞品、哪张图 —— **空串硬失败**）。**从竞品标签取【成分名 + 剂量】是允许的**（事实数据），
   >    ⛔ 但功能宣称 / on-pack claim / 认证标 / 它那段 FDA 免责**一个字都不许抄** —— 边界见 `copy-compliance.md §3.1`「边界」小节。
   > 2. **必过 `check_facts.py`**（`build.py` 构建 m7 前自动跑的硬闸门）：%DV 会按 `assets/schemas/dv_table.json`
   >    **重算并比对**、单位/剂型可行性/`source` 都查。🔴 **竞品标签上的数照抄也可能错**（实测参考图两处：K2 按**旧版 DV** 算的 `56%`、
   >    2 mL 滴剂塞 2,005 mg 固形物做不出来）→ 报错就回去核，⛔ 别硬改数字凑过闸门。配方逻辑另可跑 `review_facts.py`（LLM 顾问，**只报不拦**）。
   > 3. 🛑 **商标停机协议**：竞品配方里几乎必带专利原料商标（`KSM-66` / `BioPerine` …，9 词表见 `copy-compliance.md §1.4`）
   >    → `check_facts.py` **退出码 3 停机**，横幅原样透出，**去问 Bowen 一句"用还是不用"**。
   >    ⛔ **别向他要授权方/授权文件**（Bowen 2026-08-09：同意即可）；同意的写进 `m7.facts.trademark_ok` + `_approved` 留痕，
   >    都不同意就把 `mode` 降级 `"demo"`。⚠️ 同意 ≠ 取得授权，商标风险仍在（阿里被投诉即删图/扣分）。完整口径 = `copy-compliance.md §7`。
7. **阿里出图走五证、禁 FDA**（`compliance.md` §3 的阿里条 + memory `lifeworth-alibaba-fda-rule`）。
8. 接老模式出整套 listing 时：认证墙 `m4-cert-wall.html` 已是**五证**（3+2）；产品图当 product-asset 填进 `product.json`。

---

## 🔴 第一原则：借语言，不借设计（这条决定这个模式合不合法）

参考竞品时，**能借什么、碰不得什么，一刀切分清**（同 `compliance.md §5`）：

| ✅ 能借（品类通用视觉语言，不受保护） | ⛔ 绝不能碰（trade dress / 商标） |
|---|---|
| 品类、剂型 / 包装形态（罐 / 袋 / 条包 / 软糖 / 盒 / 滴管瓶） | 竞品品牌名 / logo / slogan |
| **色彩情绪与设计风格大类**（如"暖橙+奶白、圆润无衬线、运动感"） | 它那套**独特配色组合 + 版式的精确复刻** |
| 卖点方向、目标人群 | 专有插画 / 图案 / 独特字体处理 |
| 构图角度、光位、场景类型、留白比例 | 代言人长相、认证机构 logo |

> 📌 用户已定：**新品的包装跟着参考的色彩 / 设计风格走，不锁宝蓝 VI**（Bowen 2026-07-20）。
> 这跟"背景永远宝蓝一像素不许改"**不冲突**——那条管的是 **listing 主图的背景**，
> 这里说的是**产品包装本身**。产品包装用什么色，跟着参考的风格来。
> **唯一硬锁的是 logo：必须是 LIFEWORTH 的，不许是竞品的、也不许 AI 乱造。**

🔴 **"跟风格"和"抄设计"只隔一层纸**。安全线：借的是**风格大类**（"这类产品常用暖色调圆润包装"），
不是**这一个包装的具体长相**。拿不准就退回更抽象一层，或换参考。

---

## 流程（Step 1-2 分析竞品 → Step 3 包装设计稿签字闸门 → Step 4 `gen_image.py` 生成白底 → Step 5 QC → Step 6 接 V2）

### Step 1 · 读参考，抽成结构化 brief

两种输入都支持：

- **给链接**：用浏览器打开 → **重点看主图**（Supplement Facts 常印在主图里，见 `compliance.md §3.5`）
  → 逐项记下：包装形态、色彩/设计风格（**用文字描述**）、卖点原文、目标人群、on-pack 有没有认证标 / 专利成分 / 疗效词。
- **给图片文件**：`Read` 那张图，同样逐项提取。

🔴 **只把参考落成【文字描述】。** 竞品的像素**绝不**喂进 `gen_image.py`（那就是 img2img 复刻，踩红线）。
你要的是"暖橙渐变、哑光袋、顶部开窗露产品"这种**语言**，不是那张图本身。

### Step 2 · 合规过滤 —— 把竞品卖点翻译成 LIFEWORTH 合规版

竞品怎么写不代表我们能照抄。逐条对照 `compliance.md` 过滤：

| 竞品上常见的 | 我们怎么处理 | 依据 |
|---|---|---|
| 专利成分（`Creapure®` / 带 ® 的原料商标） | 去 ®，改通用名（`creatine monohydrate`） | §3.6 禁专利成分 |
| `organic` / `100% natural` | 删（无认证不得宣称） | §3.6 |
| 疗效 / 禁用词（`cure` `treat` `disease` `libido` `vaginal`…） | 改说品类 / 成分 / 规格 | §3 功能宣称 |
| 竞品包装上的认证标（NSF Certified for Sport 等） | **不照搬**。我们只用自己的真实脱敏件（阿里认证墙**五证、去 FDA**），且 NSF 只写**工厂级** | §2 / `copy-compliance.md §2.1` |
| 虚构产地 / `wild-harvested` | 删 | §3.6 |
| 竞品的功能宣称，我们想写进**自己的文案** | **改成服务能力 / 规格（零宣称）**；⛔ 阿里禁 FDA，**不加免责** | `copy-compliance.md §3.1`「出处 ≠ 豁免」 |

📌 **益处信息不会丢**：功能宣称若印在**产品实物照**上是受豁免的；打进我们自己写的标题/药丸/勾选项就得**改成零宣称**（阿里图不加 FDA 免责，见 `copy-compliance.md §2.1 / §3.1`）。

### Step 3 · 🔴 包装设计稿签字（签字闸门，跳过必翻车）

照 `assets/schemas/new-product.example.json` 填一份**包装设计稿**（这款新品的**包装本身**长什么样 + 每条文案来源），交 Bowen 签字。至少包含：

- 品类 / 剂型 / **包装形态**
- **色彩 + 设计风格方向**（文字描述，注明"参考自 XX 链接的风格大类，非复刻"）
- **卖点**：每条都写【原始出处】+【合规改写后】两列
- **目标人群**（对应 `main-images.md §0` 五类品牌方买家画像里的哪一类）
- **on-pack 文案**（logo=LIFEWORTH；正文全数字化、零宣称，见 `compliance.md §4.5`）
- 配方/成分：有没有本款配方？没有就走 `compliance.md §3.5` 的样例配方合规话术，**别编**。
  🆕 顺手把 **m7 营养成分表**的 `facts` 一起签掉（`mode` / 每行成分名+剂量+`source`）——
  新品模式基本都是 `"sample"`；商标原料要不要用，**这一步就问 Bowen**，别等 `check_facts.py` 停机才问。

⛔ 没签字别开跑 `gen_image.py`。编卖点、假认证、抄 trade dress 的翻车史全发生在没这道闸的时候。

### Step 4 · 出白底图 —— 🔴 工具锁死 `scripts/gen_image.py`（Bowen 2026-07-27 拍板）

**包装白底图一律用 `scripts/gen_image.py` 生成，新品模式也不例外。**
（2026-08-06 起默认走 **deepkey** 通道、型号 `gpt-image-2-1k` = 1024²；没配 deepkey 的机器
自动落回老通道 TokenStation 的 `gpt-image-2`。⛔ 别自己换 `-2k`/`-4k`：Bowen 2026-08-06「默认 1k 即可，
不要 2k，2k 成本较高」。**锁的是"只准走 `gen_image.py`"，不是某一家中转。**）
⛔ 不许用 HTML 模板 / Pillow 把 logo、文字贴到空白包装上交差；⛔ 不许换别的生图服务。
（v1.4 原推荐的「AI 出空白包装形体 + 后期合成 logo/文字」路线**作废**——首次实跑时 Bowen 已定
文字/logo 生图时烘进去，这次连工具一起锁死。）

1. **`gen_image.py --raw`，把 Step 3 签字稿里的全部 on-pack 文案逐条锁进 prompt**，
   同时用文字描述参考的色彩 + 材质 + 形态（gpt-image-2 实测英文文字很稳、没乱码）：
   ```bash
   python scripts/gen_image.py --raw "matte stand-up pouch, warm coral-to-cream gradient, rounded modern label, wordmark text 'LIFEWORTH', ..., floating in mid-air, no shadow, no reflection, nothing beneath, centered on pure white background, square 1:1" -o build/new-pouch.png
   ```
   🔴 `--raw` 会绕掉脚本默认的「悬空无阴影」块 → **必须手写 `floating in mid-air, no shadow,
   no reflection, nothing beneath` 进 prompt**，否则烘焙阴影 + 模板 CSS 阴影 = 双重阴影。
2. **logo**：文字 wordmark `LIFEWORTH` 直接烘进 prompt；要用带"O 做咖啡豆"字形的**真 logo 图**
   → 走 `--anchor` 喂真图（见 memory `lifeworth-render-logo-rules` + `anchor-placement.md`），
   ⛔ 不许让 AI 凭空画那个字形，⛔ 认证标一个都不许画。
3. **出图后必查（换了工具这条不松）**：
   - `packaging-cleanup.md` 全查：假认证标 / 专利标 / 拼写乱码，一个都不能留；
   - `verify_label.py` 核对文字（仅 macOS，是筛子不是判官，🔴 须人工放大逐字确认）；
   - 中文包装 ⛔ 禁 AI 重绘。
4. 🆕 **这张就是干净白底真产品图，直接进 V2**（Bowen 2026-07-31）：**不再抠透明**——V2 的 `--scene` 直接吃白底图。
   把它填进 `product.json` 顶层 `product.swap_image`（见 Step 6）。⚙️ 抠图法只由**用户明确要求**触发，⛔ 不因"小字须分毫不差"自动切。

### Step 5 · 🔴 QC（新品模式专属，压过一切内部偏好）

- [ ] **防侵权并排**：产出物 vs 竞品原图**并排**看，一眼能看出同源 → **重做或换参考**。（`compliance.md §5`）
- [ ] logo 是 **LIFEWORTH**，不是竞品的、不是 AI 乱造的。
- [ ] 包装上**没有**假认证标 / 专利标 / 拼写乱码。（`packaging-cleanup.md`）
- [ ] 文案无专利成分 / `organic` / 疗效词；功能宣称有免责或已改成规格。
- [ ] 数字全是官方口径（`compliance.md §4`）。
- [ ] 白底干净、产品**悬空无烘焙阴影**（`--raw` prompt 带了 floating/no shadow；目视 + `verify_label.py`）。
- [ ] 每条卖点都能追到 Step 3 签字稿里的来源，没有临场新编的。

### Step 6 · 🆕 接 V2 出整套 listing（Bowen 2026-07-31）

白底包装图签字过关后，它就是这款的**真产品图**。接着走 V2（`scene-swap.md`【生产工作流 v2】）：
1. 填 `product.json`：顶层 `product.swap_image` = 这张白底图；每个有产品的模块 `images` 槽放**占位件**
   （库存抠好的透明件，只为定位/量 check_layout）+ `swap.subject` 点名要替换的物体。文案照 Step 2/3 的合规版。
2. 出图：
   ```bash
   python scripts/build.py product.json -o build/ --only m1 m2 m3 m4 m5 m6 m7   # 详情页用 --detail-all
   python scripts/render_v2.py product.json build/ -o out/ --modules m1 m2 m3 m4 m5 m6 m7
   ```
   🆕 **`m7` = 营养成分表**（上面第 6 条那份参考配方的落地位）：`build.py` 构建它之前会**自动跑 `check_facts.py` 硬闸门**，
   商标命中会**退出码 3 停机**。⛔ **不出 m7 就从 `--only` 里去掉它**，别把闸门注释掉。
   🔴 **m7 在 `product.json` 里⛔ 不许写 `swap` 段** —— 它没有产品要换，走 render 直出；
   把数字表交给 `--scene` 重绘 = **必出假数据**（实测史：`20g Sachet`→`Saciet`、钾 `22`→`23`）。
   V2 自动把白底真产品换进各图占位处、锁我方文案、查压字。**此时产品背景才回到宝蓝 VI**。
   **别把"包装跟参考走"套到 listing 背景上，那是两回事。**

> ⚠️ 提醒：Step 4 的白底图是 AI 生成/重绘的包装 → Step 5 已逐字核过；V2 的 `--scene` 会**再重绘一次**产品
> → 出图后**再放大核一遍**产品文字没被改乱，漂了就重跑 `--scene`；⛔ 不因此自动切抠图——用户明确要求"走抠图"时才走（用 Step 4 的白底图抠透明 → 合成）。
