# LIFEWORTH 锚点图产品摆放与 Photo Skill 提示词

> 🆕 2026-07-24：`scripts/gen_image.py` 已内建 `--anchor` 锚点图生图模式（走生图通道的 `/v1/images/edits`
> —— 2026-08-06 起默认通道是 **deepkey**、型号 `gpt-image-2-1k`；没配 deepkey 的机器落回老通道 TokenStation 的 `gpt-image-2`）。
> 通用锚点锁定提示词 + 反向约束【已封装进脚本】，你只需传一段「表现形式提示词」。
>
> 🔴 **这套的真正用途（Bowen 2026-07-24 校准）= 拿一张已批准产品图，出【白底产品图的多种表现形式】**
> （平铺 flat-lay / 悬浮 hero / 干净角度图，参考三张 Glutathione 白底图），供详情页+主图复用、减少视觉疲劳。
> **不是**套蓝底加标题的成品主图。下方"方式一/二/三"的构图思路可借，但**底色一律纯白**。
> 实测 VOLT 袋出 平铺/悬浮/角度 三种：LIFEWORTH/口味/规格/卖点/图标全零漂移。
>
> ## ✅ 三种验证过的表现形式（Bowen 2026-07-24 沉淀，实测 VOLT 袋零漂移）
> 示例图见 `assets/library/anchor-examples/`（V1 平铺 / V2 悬浮 / V3 角度）。`<口味>` 换成本款口味水果。
> ```bash
> # V1 平铺 flat-lay（俯拍 + 口味水果 + 调好的饮品杯）—— 适合详情页场景/生活化
> python scripts/gen_image.py "Composition mode: top-down flat-lay product presentation. Lay the approved \
>   product pouch flat and angled naturally on a pure white seamless surface, with fresh <口味> pieces and a \
>   glass of prepared drink beside it, plus a few water droplets. Bright even studio lighting, soft realistic \
>   shadows, pure white seamless background, square 1:1 canvas, equal width and height. Clean commercial \
>   e-commerce product photography." --anchor <A0.png> -o out/V1_平铺.png
>
> # V2 悬浮 hero（直立 + 水果悬浮环绕）—— 适合主图 hero / 有冲击力
> python scripts/gen_image.py "Composition mode: floating hero product presentation. Show the approved product \
>   pouch upright and floating slightly, with fresh <口味> cubes and a green leaf arranged around it. Pure white \
>   seamless background, soft realistic drop shadow beneath, bright studio lighting, crisp focus, square 1:1 \
>   canvas, equal width and height. Clean commercial e-commerce product photography." --anchor <A0.png> -o out/V2_悬浮.png
>
> # V3 干净角度图（正面微角度 + 少量水果点缀）—— 适合规整产品证件照
> python scripts/gen_image.py "Composition mode: clean three-quarter angled product presentation. Show the \
>   approved product pouch standing at a slight three-quarter angle, minimal styling, one small <口味> accent at \
>   the base. Pure white seamless background, soft shadow, bright even studio lighting, square 1:1 canvas, equal \
>   width and height. Clean commercial e-commerce product photography." --anchor <A0.png> -o out/V3_角度.png
> ```
> - 🔴 **提示词必带 `square 1:1 canvas, equal width and height`** —— 实测 edits 端点【不认 `--size`】，靠这句才逼出方形（不写会随机 3:2/2:3）。
> - 🔴 **底色必写 `pure white seamless background`**（白底产品图，不是蓝底成品）。
> - `--anchor <A0>` 每次都用【原始 A0】，⛔ 别拿上一张生成图当锚点。
> - 🔴 出图后**必做**：`verify_label.py` + 人工放大核对。⚠️ 喂的是我们自己已批准的产品图，与"竞品像素禁 img2img"红线不冲突。
>
> ## 🔴 工作标准：做主图/详情页【前】先规划表现形式（Bowen 2026-07-24 定）
> 出主图 7 图（m1–m7）/ 详情页之前，**先看参考图（竞品/老板样图），按参考规划这一款要出哪几种表现形式的白底产品图**
> （平铺/悬浮/角度…），再把不同表现形式分配到不同主图位和详情页模块，**丰富整套的排版和视觉、减少视觉疲劳**
> ——别 10 张主图都用同一张产品证件照。产品图是"内容层"的最大变量之一（背景 VI 锁死，产品表现形式可变）。
>
> 🔴 **`m7`（营养成分表，2026-08-09 新增的第 7 张）不在这套规划里**：它是**纯数字表格**（深蓝底 + 反白表），
> **没有产品图槽**，也**不需要**任何表现形式 —— 所以 `--anchor` 的产出**用不到 m7**，
> ⛔ 更别拿 AI 去生成/重绘那张表（数字表交给 AI = 必出假数据，见 `scene-swap.md` 里的 m7 禁区红块）。
> 出图命令按 7 张走：`build.py … --only m1 m2 m3 m4 m5 m6 m7` / `render_v2.py … --modules m1 m2 m3 m4 m5 m6 m7`
> （m7 的数据闸门是 `check_facts.py`，见 `compliance.md §3.5`）。
>
> ## ⛔ 已验证的能力边界：别再试这几类（2026-07-24 踩过 V4–V7）
> 在**一张正面闭口平袋**锚点上，用纯 AI edit **做不出**"开口 + 倒条包 + 极端角度"的图：
> - 要开口在物理正确的顶端 → 标签必须狠透视后退 → **小字必漂**（V5b：30→3C、AQUA FRESH→AQUA FRESB）；
> - 要标签正立文字不漂 → 开口就被挤到袋底（物理错，V6）或版式被对调（V7）；
> - 袋内/散落的**条包是 AI 凭空造的**，小字必乱（没有条包真实素材）。
> 👉 这三者（开口物理对 + 版式保真 + 文字不漂）在闭口平袋锚点上**凑不齐**。真要这类图：给一张**真实的"开口袋+散条包"照片**当锚点，或交实拍/手动合成。⛔ 别再花回合纯 AI 硬试。

---

> ⚠️ **以下为老板侧原始作业记录（历史存档，仅供借构图思路）。执行一律以顶部 🆕/🔴 块为准：**
> 工具已锁死 `gen_image.py --anchor`（⛔ 不许再用 Photo Skill 等别的生图服务——
> 见 `CHANGELOG.md` v1.11「包装白底图工具锁死中转生图通道」，当时的通道是 TokenStation，
> 2026-08-06 起换成 deepkey；**锁的是"只准走 `gen_image.py`"，不是某一家中转**）；
> 产出是**纯白底表现形式图**，不是蓝底成品主图。
> ⛔ 下文的蓝底 prompt、`lifeworth.en.alibaba.com` 网址文案（主图禁网址）都别照抄。

## 适用场景

用于基于同一张产品锚点图，生成三种不同构图方式的 LIFEWORTH Alibaba International 主图，同时尽量保持产品包装身份一致。

当前产品示例：

- 产品：Women's Balance Gummies
- 口味：Pineapple Flavor
- 包装：蓝白 LIFEWORTH / ODM 立式袋
- 规格：60 Gummies / 30 Servings
- 卖点：Sugar Free / Vegan Pectin
- 锚点图：A0-B 原始锚点图

## 核心原则

1. 每次都使用原始 A0 锚点图，不要把上一张生成图作为下一张锚点。
2. 走 edits 类端点（现行 = `gen_image.py --anchor`，默认 deepkey 通道；旧 `photo-skill edit` 已作废），不要使用纯文字 `generate` 重新设计包装。
3. 产品包装是不可变化项，场景和摆放方式是可变化项。
4. 每次只改变背景、光线、比例、裁切和位置。
5. 禁止模型重新设计包装、重画标签、改变产品名、口味、规格或卖点。
6. 三种摆放方式分别调用三次，每次输入都必须是同一张 A0 锚点图。

## 通用锚点锁定提示词

将下面这段放在每个 Photo Skill Prompt 的前面：

```text
Use the attached anchor image as the sole source of truth for product identity.

The product package must remain visually unchanged:
same pouch shape, same front-facing orientation, same blue and white color blocking, same label layout, same typography hierarchy, same LIFEWORTH / ODM mark, same WOMEN'S BALANCE GUMMIES wording, same pineapple flavor graphics, same SUGAR FREE badge, same VEGAN PECTIN badge, same 60 GUMMIES and 30 SERVINGS specifications.

Do not redesign, redraw, simplify, replace, rotate, open, reshape, recolor, or relabel the pouch.
Do not invent a new package, alternate flavor, alternate claims, alternate logo, or different product format.
Do not use the previous generated image as the product reference.
Only change the scene, background, lighting, scale, crop, and placement of the approved anchor product.
Keep one approved product pouch only.
```

## 方式一：中央偏右主视觉

适合 B1 品牌主图。产品最大、最突出。

```text
Create one complete finished Alibaba International main image.

Composition mode: centered-right hero placement.
Place the approved product pouch large in the center-right area, occupying approximately 55-65% of the canvas height.
Keep the pouch front-facing and vertically stable.
Leave clean negative space on the left for a headline and short supporting copy.
Use a royal blue and white LIFEWORTH brand background.
Add fresh pineapple pieces and orange gummies near the bottom as flavor cues.
Use premium commercial e-commerce product photography, clean studio lighting, crisp focus, soft natural shadow.

Visible copy:
LIFEWORTH / ODM
WOMEN'S BALANCE GUMMIES
Private Label / OEM/ODM
Pineapple Flavor | Sugar Free | Vegan Pectin
lifeworth.en.alibaba.com

The final image must be a complete ready-to-upload image, not a draft or later compositing asset.
```

## 方式二：右侧锚定摆放

适合 B2 痛点钩子、标题型主图。

```text
Create one complete finished Alibaba International main image.

Composition mode: right-anchored product placement.
Place the approved product pouch in the right third of the canvas, occupying approximately 40-48% of the canvas height.
Keep the pouch front-facing, unchanged, and clearly readable.
Reserve the entire left half for a large buyer-facing headline and three small support cards.
Use a strong LIFEWORTH royal blue title area with a clean white lower content area.
Add pineapple and orange gummies around the product base without covering the package.

Visible copy:
LIFEWORTH / ODM
Launch a Best-Selling Women's Gummy
Compliant | On-Trend | Ready to Scale
Private Label Ready
Pineapple Gummy Appeal
Daily Wellness Positioning
lifeworth.en.alibaba.com

Do not change the pouch, label, product name, flavor, claims, or specifications.
```

## 方式三：左下角产品摆放

适合 B3 定制能力或 B6 流程 CTA 主图。

```text
Create one complete finished Alibaba International main image.

Composition mode: lower-left product placement.
Place the approved product pouch in the lower-left area, occupying approximately 38-45% of the canvas height.
Keep the pouch front-facing, unchanged, and visually dominant enough to remain recognizable.
Reserve the upper-right and right side for customization options or a four-step service process.
Use a clean blue and light-blue LIFEWORTH brand layout.
Keep the product pouch separate from the information cards.
Add small pineapple pieces and orange gummies only near the product base.

Visible copy:
LIFEWORTH / ODM
Customize Your Women's Gummy Line
Formula
Flavor
Count
Package
Label
Bulk
YOUR BRAND HERE
lifeworth.en.alibaba.com

The additional package mockups must be neutral placeholders only.
Do not create alternate finished product packages or different pineapple labels.
```

## 统一反向约束

将下面这段追加在每个 Prompt 末尾：

```text
Negative constraints:
no redesigned packaging,
no altered label,
no rewritten product name,
no changed flavor,
no changed count,
no changed claims,
no second finished package,
no duplicate product,
no floating distorted pouch,
no warped typography,
no fake certification,
no FDA Approved,
no cure,
no treat,
no disease claims,
no watermark,
no gibberish text,
no collage,
no unfinished template,
no placeholder box.
```

## 推荐执行顺序

1. 准备原始 A0 锚点图。
2. 选择一种摆放方式。
3. 使用 `photo-skill edit`，输入原始 A0 锚点图。
4. 粘贴“通用锚点锁定提示词”。
5. 粘贴对应的三种摆放方式之一。
6. 追加“统一反向约束”。
7. 生成一张成品图。
8. 检查包装是否仍然包含：
   - `LIFEWORTH / ODM`
   - `WOMEN'S BALANCE GUMMIES`
   - `Pineapple Flavor`
   - `Sugar Free`
   - `Vegan Pectin`
   - `60 Gummies`
   - `30 Servings`
9. 如果包装文字、颜色、图案或规格变化，直接废弃并重新调用，不要把错误图作为下一次锚点。

## 重要限制

Photo Skill 可以通过锚点锁定和反向约束显著降低包装漂移，但不能保证每个小字号文字像素级不变。对于 Alibaba 主图，建议优先检查产品名、口味、规格、核心卖点和包装结构；任何关键事实变化都应重新生成。
