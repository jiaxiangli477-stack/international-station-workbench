#!/usr/bin/env python3
"""三组凭据自检：一条命令告诉你【生图 / 云 OCR / 老通道】各自通不通。

为什么要它（Bowen 2026-08-06，换 deepkey 时定）：
  凭据分成三组之后，配错一组的后果**不是报错，是静默**——最典型的：
  没配 `DEEPKEY_TEXT_*` 的机器跑 `verify_label.py`，云 OCR 拿不到凭据 → 抛 CloudOCRUnavailable
  → 打一句"退回人工核对" → **退出码 0**。标签检查根本没跑，而退出码是绿的。
  以前只能等整套图（主图 7 + 详情页 12 = 19 张）出完、事后才发现那一层一直没跑。
  **装环境时跑一次本脚本就该知道。**
  ⚠️ 这里原本写的是「21 张图」= **国内 1688 站口径**（主图 8 + t 系列 13），属反向污染（I-48）。

🔴 本脚本【不生图、不花钱】：只打 `GET /v1/models`（免费，实测 ~1 秒），看两件事——
  ① 这组凭据能不能通（401/超时/连不上都在这一步暴露）；
  ② 这组里**有没有我们真正要用的那个型号**。
  ⛔ 别改成"真出一张图/真调一次视觉模型"来探活：那是花钱的，而且探活失败时你分不清
  是凭据坏了还是模型不在组里 —— 模型清单能直接告诉你后者。

实测（2026-08-06，本机三组）：
    deepkey 生图组   5 个模型，有 gpt-image-2-1k / gpt-image-2，**没有任何 gpt-5.x**
    deepkey 文本组   8 个模型，有 gpt-5.5 / gpt-5.4-mini，**没有任何 gpt-image**
    TokenStation     **只有 gpt-image-2 一个模型** —— 所以它调 gpt-5.x 必回 503，
                     那不是临时故障、是模型不在组里（云 OCR 的兜底档因此已被摘掉）。

用法:
    python check_env.py            # 三组全查
    python check_env.py --quiet    # 只在有问题时输出（给脚本/CI 用）

退出码:
    0 = 该有的都有（macOS 上云 OCR 缺失只告警不算失败——本机走系统 Vision，不依赖它）
    1 = 有【会影响出图或验收】的缺失（非 macOS 缺云 OCR 也算，那边没有 Vision 兜底）
"""
import argparse
import json
import platform
import ssl
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （必须 import：修 Windows 管道输出下 emoji 崩溃）
from _compat import get_secret                                  # noqa: E402
from gen_image import PROVIDERS, OCR_PROVIDERS, DEFAULT_MODEL, USER_AGENT, _ssl_context  # noqa: E402

IS_MAC = platform.system() == "Darwin"


def _list_models(base: str, key: str) -> tuple:
    """返回 (模型 id 列表, 错误说明)。任一为 None 表示另一个有效。"""
    req = urllib.request.Request(
        f"{base.rstrip('/')}/v1/models",
        headers={"Authorization": f"Bearer {key}", "User-Agent": USER_AGENT},
    )
    try:
        with urllib.request.urlopen(req, timeout=60, context=_ssl_context()) as r:
            data = json.loads(r.read())
        return [m.get("id", "") for m in data.get("data", [])], None
    except urllib.error.HTTPError as e:
        why = {401: "key 无效或已过期", 403: "余额耗尽 / 这把 key 没权限"}.get(e.code, f"HTTP {e.code}")
        return None, why
    except Exception as e:                                       # noqa: BLE001
        return None, f"{type(e).__name__}: {e}"


def _resolve(providers: list) -> tuple:
    """按【组】配对取凭据（与 gen_image._pick 同一套规则）。返回 (provider, base, key) 或 (None, None, None)。
    ⛔ 别在这里自己写一套"key 和 base 各自找最先有值的"——那正是会拼出跨组组合的老写法。"""
    got = get_secret(*[n for _p, ks, bs in providers for n in ks + bs])
    for prov, ks, bs in providers:
        key = next((got[n] for n in ks if got.get(n)), None)
        base = next((got[n] for n in bs if got.get(n)), None)
        if key and base:
            return prov, base.rstrip("/"), key
    return None, None, None


def check(title: str, providers: list, need: str, how_to_fix: str, out: list) -> str:
    """查一组。返回 "ok" / "missing"（没配） / "bad"（配了但不通或没有那个型号）。"""
    prov, base, key = _resolve(providers)
    if not prov:
        out.append(f"❌ {title}：**没配**")
        out.append(f"   👉 {how_to_fix}")
        return "missing"
    t = time.time()
    ids, err = _list_models(base, key)
    dt = time.time() - t
    if ids is None:
        out.append(f"❌ {title}：凭据配了（通道 {prov}），但**连不通** —— {err}（{dt:.1f}s）")
        out.append(f"   👉 {how_to_fix}")
        return "bad"
    if need not in ids:
        out.append(f"❌ {title}：通道 {prov} 能连上（{len(ids)} 个模型，{dt:.1f}s），"
                   f"但这组里**没有 `{need}`**")
        out.append(f"   组里有：{', '.join(sorted(ids)[:8]) or '（空）'}"
                   + ("…" if len(ids) > 8 else ""))
        out.append(f"   🔴 多半是**两组 key 拿反了**（deepkey 两把都是 51 位、肉眼分不出）。{how_to_fix}")
        return "bad"
    out.append(f"✅ {title}：通道 {prov}，`{need}` 在（{len(ids)} 个模型，{dt:.1f}s）")
    return "ok"


def main() -> None:
    ap = argparse.ArgumentParser(description="三组凭据自检（不生图、不花钱）")
    ap.add_argument("--quiet", action="store_true", help="只在有问题时输出")
    a = ap.parse_args()

    out = ["—— 凭据自检（只查模型清单，不生图、不花钱）——"]

    # ① 生图：deepkey 生图组，缺了会自动落回老通道（能用，但慢且不遵守 size）
    img_prov, _b, _k = _resolve(PROVIDERS)
    img_need = DEFAULT_MODEL.get(img_prov or "deepkey", "gpt-image-2-1k")
    img = check("① 生图 gen_image.py", PROVIDERS, img_need,
                "配 DEEPKEY_IMAGE_BASE_URL / DEEPKEY_IMAGE_API_KEY（见 .env.example）", out)
    if img == "ok" and img_prov == "tokenstation":
        out.append("   ⚠️ 走的是**老通道**：能出图，但不遵守 size（实测请求 1024² 实回 1122×1402 之类，"
                   "随后会被居中裁掉边缘），且比 deepkey 慢约 1.8 倍。配上 DEEPKEY_IMAGE_* 更好。")

    # ② 云 OCR：deepkey 文本组。⛔ 没有兜底档——TokenStation 那把 key 组里根本没有 gpt-5.x。
    try:
        from verify_label import CLOUD_OCR_MODEL                 # noqa: E402
    except Exception:                                            # noqa: BLE001
        CLOUD_OCR_MODEL = "gpt-5.5"
    ocr = check(f"② 云 OCR verify_label.py（{CLOUD_OCR_MODEL}）", OCR_PROVIDERS, CLOUD_OCR_MODEL,
                "配 DEEPKEY_TEXT_BASE_URL / DEEPKEY_TEXT_API_KEY（⛔ 别拿生图组那把顶，它没有文本模型）", out)
    if ocr != "ok":
        if IS_MAC:
            out.append("   ℹ️ 本机是 macOS，验标签走**系统 Vision OCR**，不依赖这组 —— 所以这条不算失败。")
            out.append("   ⚠️ 但**同事的 Windows 没有 Vision**：这组缺了，他那边 `verify_label.py` 会"
                       "打一句'退回人工核对'然后**退出码 0** —— 检查没跑，退出码却是绿的。")
        else:
            out.append("   🔴 本机不是 macOS，**没有系统 OCR 兜底** ⇒ 这组缺了 = 标签检查等于没跑"
                       "（`verify_label.py` 仍退出码 0，别把它当通过）。")

    ok = (img == "ok") and (ocr == "ok" or IS_MAC)
    if not a.quiet or not ok:
        print("\n".join(out))
    if not ok:
        print("\n🔴 上面有 ❌ —— 按各自的 👉 修完再出图。改完重跑本脚本确认。")
        sys.exit(1)
    if not a.quiet:
        # 🔴 ⛔ 别无条件打 ✅：macOS 豁免的那种情况下②确实是 ❌，抬头再打绿的就是"抬头绿、下面红"
        #   的混合信号 —— 人眼扫日志只会记住那行 ✅。这个 skill 已经因为同一类混合信号翻过车。
        if ocr != "ok":
            print("\n⚠️ 生图这组齐了，出图不受影响；但**云 OCR 那组是缺的**，"
                  "本机靠 macOS 系统 Vision 顶着才没判失败。")
            print("   👉 要发给同事/在 Windows 上跑之前，把 DEEPKEY_TEXT_* 补上，否则那边标签检查等于没跑。")
        else:
            print("\n✅ 该有的都有。（本脚本只验「能连上 + 型号在组里」；"
                  "真出图/真读图还会不会出别的问题，出图后照常按 QC 清单验收。）")


if __name__ == "__main__":
    main()
