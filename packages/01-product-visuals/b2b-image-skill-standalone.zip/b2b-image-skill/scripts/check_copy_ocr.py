#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""③ 文案审核官（国际站版）：读 `--scene` 出来的图，核对【我方文案】AI 有没有画错。

移植自国内 skill 的 `check_copy_ocr.py`（整改 I-23 的第一半，为 I-72 铺路）。
🔴 **本轮只搬了判据① 和 判据③，判据②（禁词）没搬** —— 理由见下面「为什么没有判据②」。

为什么有这一步（国内 Bowen 2026-08-12 定，取代"一律 overlay"）：
  `--scene` 是重绘整张图，我方文案也过一遍 AI。过去的做法是**无条件**把 HTML 文案层叠回去
  （overlay_copy），保证文案像素级精确 —— 但 overlay 是【盖】不是【擦】，盖不掉 AI 在旁边多画的
  那一份 ⇒ 双影。
  ⇒ 新路径：**内容对就直接用**（不 overlay ⇒ 结构上不可能双影），内容错则**先改提示词再重掷**
     （把要保真的字样写进 `swap.keep_text`）—— 🔴 **那是国内那套的阶梯**；国际站的
     `gen_image.py` 还没有 `--keep-text`（方案 I-73），所以本站现在只能原路重掷，见退出码 1 那条。
  🔴 代价要认：走这条路 = **放弃版式与字体的像素级一致**（AI 的字是模仿的、位置会漂几到二十几 px）。

🔴 **本闸门的口径（⛔ 别扩大解释）**：它**只保证【文字内容】对得上**（该有的字都在），
   ⛔ **不保证【版式边界】** —— 字全对但整块被画布切掉一截，判据① 照样全绿。
   国内实测（乳清蛋白粉 t02）：H1 顶部被削掉 1/4 字高，两跑都是 21/21 绿灯。
   ⇒ 所以补了**判据③：贴边告警**（只提示、⛔ 不改退出码），版式仍须放大目检。

判据（🔴 **只有 ① 决定退出码**；③ 只打印）：
  ① 必含 —— 模板里我方的每一条文案，都要在 OCR 结果里原样出现（归一化后比对）。
     少一条 = AI 把它改了 / 糊了 / 漏画了 ⇒ 不通过。
  ③ 贴边告警（⚠️ 不改退出码）—— 画布四边最外一圈里有没有笔画/硬边贴着边缘。
     🔴 这条**不读 OCR**：云 OCR 只回文字行、**不回坐标**（`verify_label._ocr_cloud` 返回的是
     `[(文字, 置信度)]`，Vision 那条虽有 boundingBox 但 `ocr()` 也没往外传），拿不到文字块
     外接框 ⇒ 改成直接量**像素**。判据与阈值见 `_edge_ink_hits`。
     ⛔ **别为这条去改 `verify_label.ocr()` 的返回结构** —— 那个函数在国内侧有多个调用方，
        国内把它改三元组时当场把另一道闸门打崩过（`ValueError: too many values to unpack`）。

🔴 **为什么没有判据②（禁词），以及它什么时候才补**（2026-08-17，⛔ 别自作主张先接上）：
   国内那条判据② 是把 OCR 读到的全部文字过一遍 `verify_copy_cn` 的**中文广告法极限词表** ——
   那套词表（"最"字诀、疗效词、保健功能宣称）对**阿里国际站完全不适用**，一个词都搬不过来。
   国际站对应的表是 `verify_copy.py` 的 `RULES`。但**国际站还没做 I-06「分面」**：
   现行 `RULES` 把「阿里出图禁 FDA」和「产品实物标签法定必须印 FDA 免责」两个**面**混在一张表里 ⇒
   拿它去扫 OCR 结果，**DSHEA 法定免责原文会被判成 4 条高危**（那句话印在真产品罐子上，
   AI 忠实重绘就命中；而它恰恰是法规要求印的）。
   国内早就吃过同一个亏的变体：肌酸粉罐身原厂印着 `100% CREATINE`，每轮命中「100%」⇒
   文案明明 9/9 全对却判不过 ⇒ 白掷几轮（**重掷根本改不掉产品实物上印的字**）⇒ 退回 overlay ⇒ 必然双影。
   🔴 **把一个已知会假报的判据接进出图主路，正是这一轮整改在治的病。**
   ⇒ 判据② 留给 I-23 的后半，**跟 I-06 分面一起做**：先让 `verify_copy.py` 能区分
     「阿里出图面」/「产品实物标签面」，判据② 才有一张能用的表。
   ⇒ 退出码语义相应收窄：**现在只有判据① 决定退出码**，本脚本对"AI 自己编出来的违规词"
     **一点保护都没有** —— ⛔ 别把本脚本绿灯当成"这张图合规了"，合规仍走 `verify_copy.py`
     （查我方文案）+ `references/label-compliance.md`（查产品实物上的字）人工那一路。

退出码（⛔ 别合并，三种情形的处置完全不同）：
  0 = 通过（我方文案逐条对得上）→ 调用方跳过 overlay，直接尺寸归一出成品
  1 = **没通过**（漏字/改字）→ 处置见脚本末尾打印的清单（目检放行 / 退回 overlay / 改 composite）。
      🔴 ⛔ **别按"写 `swap.keep_text` 再重掷"办** —— 本站 `gen_image.py` **没有 `--keep-text`**
      （argparse 里 0 命中），写了不透传，重掷 = 原路重掷（同位同错法）。接通 = 方案 I-73。
  2 = **没跑成**（OCR 挂了 / 缺凭据 / 提不出期望文案）→ 🔴 绝不等于通过，也别拿它去重掷，
      先修工具。撞码是这套脚本的老病：`check_scene_text` 曾因"崩了也退 1"害人对着没查过的图改版式。

用法:
    python check_copy_ocr.py <build_dir> <module_key> --after out/m1.png
    python check_copy_ocr.py --selftest        # 判据① 的正反例自检，不联网、不出图
"""
import argparse
import difflib
import html as _html
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （必须 import：修 Windows 管道输出下 emoji 崩溃）

SCRIPTS = Path(__file__).resolve().parent


# ── 期望文案：从 build 出来的 HTML 里取 ─────────────────────────────────────────
# 🔴 为什么读 HTML 而不是读 product.json：模板里还有一批**固定文案**（logo、顶栏 tag、CTA、
#    表头…）不在 json 里，只在模板里。漏掉它们 = AI 把「GET A FREE QUOTE」画成别的字也判通过。
#    实测 m1 提出来的 9 条里，有 2 条（`LIFEWORTH`、`OEM / ODM SUPPLEMENT MANUFACTURER`）
#    在 product.example.json 里根本查不到。
_TAG_TEXT = re.compile(r">([^<>]+)<")
_DROP_BLOCKS = re.compile(r"<(script|style)[^>]*>.*?</\1>", re.S | re.I)
# 🆕 国际站模板里的注释是**大段中文版式说明**（m1/m2 里就有整段"⛔ 原为 lifeworth.en.alibaba.com
#    角标，已删…"）。国内那版没显式剥注释，靠"注释里恰好没有 >…< 配对"侥幸躲过。⛔ 别赌这个。
_DROP_COMMENT = re.compile(r"<!--.*?-->", re.S)


def expected_copy(html_path: Path) -> list:
    """从模块 HTML 里提出所有可见文案（一条一行，去重保序）。

    🔴 `<br>` 必须**拆成独立条目**，⛔ 别拼成一条（国内 2026-08-12 三款试跑逮到的判据 bug）：
      模板里双列/多行卡片长这样 `<div class="h1">{{H1_A}}<br>{{H1_B}}<br>…</div>`。
      拼成一条当期望，就要求这几截在 OCR 结果里**相邻**；但 OCR 是按**视觉行序**读的
      （左上→右上→左下→右下），双列卡片读出来是「左列第1行」→「右列第1行」→「左列第2行」…
      两截中间永远隔着右列的字 ⇒ 跨行拼接匹配不上 ⇒ **判据必然失败**。
      国内实测：t01 从 14/17 → **20/20**、t02 19/21 → 21/21；而没有双列的主图本来就 9/9 一次过 ——
      这个差异正是 bug 的指纹。
      🔴 国际站同样有这个结构：`m1/m2` 的 `.h1` 是三段 `<br>`、`m5` 的数字块是「数字<br>说明」、
        `m7` 是整张成分**表格**（每格独立）。⛔ 别改回拼接。

    🆕 国际站独有的两处调整（国内那版没有，⛔ 别当成多余）：
      · **HTML 实体要还原**：英文模板里 `&` 是写成 `&amp;` 的（实测 m2 有 2 处、m3 有 2 处）。
        不 unescape 就等于拿字面量「&amp;」去要求 OCR 读出来 ⇒ 必然报缺。
      · **残留占位符 `{{X}}` 不作判据**：它是 build 没填上（本该 build.py 自己拦），
        当期望只会让门禁替 build 的漏洞背锅、还报一条谁也看不懂的"缺字"。这里改成**显式告警**。
    """
    raw = _DROP_COMMENT.sub(" ", html_path.read_text(encoding="utf-8"))
    raw = _DROP_BLOCKS.sub(" ", raw)
    raw = re.sub(r"<br\s*/?>", "\x00", raw, flags=re.I)   # \x00 = 条目分隔符
    out, seen, holes = [], set(), []
    for m in _TAG_TEXT.finditer(raw):
        for piece in m.group(1).split("\x00"):
            t = " ".join(_html.unescape(piece).split())
            if "{{" in t or "}}" in t:
                holes.append(t)
                continue
            # ⛔ 一两个字符的碎片（®、·、→、单个数字）不作必含判据：OCR 对它们本来就时读时不读，
            #    当判据只会把好图判成坏图。真正要守的是成句的文案。
            #    判长度用【去标点后】的字符数：`®`、`· ·`、`→` 这类整条都是标点的碎片一并滤掉。
            if len(t) < 3 or len(_alnum(t)) < 3 or t in seen:
                continue
            seen.add(t)
            out.append(t)
    if holes:
        print(f"⚠️ {html_path.name} 里还有 {len(holes)} 处没填上的占位符（本该 build.py 拦住）："
              f"{holes[:5]}{' …' if len(holes) > 5 else ''}")
        print("   ⛔ 它们不作必含判据（否则是门禁替 build 背锅），但**这个构建目录本身就不该拿去出图**。")
    return out


def norm(s: str) -> str:
    """比对前归一化（松档）。⛔ 只抹平【表现差异】，不抹平字义 —— 别顺手把数字、单位也归一掉。"""
    s = s.replace("®", "").replace("™", "").replace(" ", " ")
    s = re.sub(r"[–—−‑-]", "-", s)                          # 各种横线
    s = re.sub(r"[·•・‧∙⋅]", "·", s)                         # 各种间隔号
    s = re.sub(r"[“”„‟]", '"', s)
    s = re.sub(r"[‘’‚‛]", "'", s)
    s = re.sub(r"[（）]", lambda m: "(" if m.group() == "（" else ")", s)
    s = s.replace("：", ":").replace("，", ",")
    # 🆕 国际站的单位记号：`㎡`(U+33A1 合字) OCR 一定读成 m² 或 m2；`µ`(U+00B5) 与 `μ`(U+03BC)
    #    是两个不同码位、肉眼一模一样。实测 m5 有「20,000㎡」、m7 有「2.4 µg」——
    #    不归一这两处，两张主图开箱就各挂一条。
    s = s.replace("㎡", "m2").replace("²", "2").replace("³", "3").replace("µ", "μ")
    # 英文里空格是有意义的分词，但 OCR 的空格宽度判断本来就不稳（"5 g"/"5g" 随机切换），
    # 而两边都抹掉空格是**对称**操作，不会放过改词。
    return re.sub(r"\s+", "", s).strip().lower()


def _alnum(s: str) -> str:
    """严档归一：只留字母/数字/汉字，标点空格全丢。

    🔴 为什么需要第二档（国际站新增，国内那版只有松档）：国际站文案里**装饰性标点密度高得多** ——
       `CUSTOMIZE YOURS →`、`Sugar-Free · 30 Sticks`、`% DV`、`† Daily Value not established`、
       `20,000㎡`。箭头/间隔号/剑标 OCR **时读时不读**，千位逗号还常被读成句点。
       只有松档一档的话，这些全部误判成"AI 改了我们的字" ⇒ 白烧两轮重掷（每轮一次生图 + 一次 OCR）。
       ⇒ 松档命中 = 干净通过；只有严档命中 = **通过但打印⚠️**（点明"只差标点"，人自己看一眼）；
         两档都不中 = 真的缺字，退 1。
       ⛔ 严档不能拿来当唯一档：它把标点全丢了，`5g`/`5 g` 之外连 `99.9%`/`999%` 都不分了。
    """
    return re.sub(r"[^0-9a-z一-鿿]", "", s.lower())


def judge_copy(want: list, lines: list):
    """判据①（纯函数，可自检、不碰 IO）。返回 (missing, soft)。

    · missing = 两档都不中 → 决定退出码
    · soft    = 松档不中但严档中 → 只差标点/间隔号，**不进退出码**，只打印
    命中条件：某一行与它相等 / 包含它；或**跨行拼接后**包含它（OCR 常把一句拆成两行）。
    """
    got = [norm(x) for x in lines]
    got_blob = "".join(got)
    got_a = [_alnum(x) for x in lines]
    got_a_blob = "".join(got_a)
    missing, soft = [], []
    for w in want:
        nw = norm(w)
        if not nw:
            continue
        if any(nw == g or nw in g for g in got) or nw in got_blob:
            continue
        aw = _alnum(w)
        if aw and (any(aw in g for g in got_a) or aw in got_a_blob):
            soft.append(w)
            continue
        missing.append(w)
    return missing, soft


# ── 判据③：贴边检测 ────────────────────────────────────────────────────────────
# 🔴 为什么要它：判据① 比的是**文字内容**，「字对但被裁掉」它一点感觉都没有 ——
#    国内 2026-08-14 t02 两跑 21/21 绿灯，成品标题顶部却被削掉 1/4 字高。
# 判据：沿画布最外一圈逐行/逐列扫，看有多少像素是【局部异常点】（笔画、硬边），
#      而不是背景（纯色或渐变）。异常判据 = 与同一条线上相距 EDGE_NEIGHBOR 的两个邻居的**均值**
#      偏离超过 EDGE_INK_TOL。⛔ 别改回"与整条线的众数色比"：宝蓝渐变底会一口气假报 13.9%。
EDGE_BAND_RATIO = 0.006   # 检测带 = 短边的 0.6%（1000² 主图 = 6px；750 宽详情 = 4→兜底 3px；@2x 加倍）
                          # 依据：模板内边距都在几十 px 量级，正常版式绝不会有字落进这几 px。
EDGE_NEIGHBOR = 6         # 邻居距离（px）：比笔画粗、比色块窄 —— 让笔画边缘凸出来、渐变底压平
EDGE_INK_TOL = 60         # 单通道偏离阈值：照片纹理压不到 60，字与底的对比一般 > 150
EDGE_INK_RATIO = 0.03     # 该行超过 3% 是异常点才算"贴边"
# 阈值的实测依据（国内 2026-08-15，四套成品图 **84 张**）：
#   · 干净图的噪声上限 = **1.13%**（满幅底图的边缘）· 真事故 = 削标题顶边 **15.0%** / 末行贴底 **14.2%**
#   ⇒ 3% 取在中间：比噪声高 2.6 倍、比真事故低 5 倍。⛔ 别降到 1% —— 满幅 AI 照片会假报。
#   ⚠️ 这组阈值是在**国内 1920 宽详情图**上标定的，国际站是 1000² 主图 / 750 宽详情，
#      口径没在国际站的图上重标过 —— 所以它只告警、不进退出码（本来也只该告警）。
_SIDES = ("顶", "底", "左", "右")


def _edge_line(im, side, i) -> bytes:
    """取距某条边第 i 圈的那一行/列像素，返回 RGB 三字节一组的裸 bytes。

    ⛔ 别改回 `list(im.crop(box).getdata())`：Pillow 12 起 `getdata()` 已弃用（本机就是 12.3），
       每跑一次就往门禁日志里刷一行 DeprecationWarning（而新的 `get_flattened_data()`
       老 Pillow 又没有）。`tobytes()` 两边都有、还更快。
    """
    W, H = im.size
    if side == "顶":
        box = (0, i, W, i + 1)
    elif side == "底":
        box = (0, H - 1 - i, W, H - i)
    elif side == "左":
        box = (i, 0, i + 1, H)
    else:
        box = (W - 1 - i, 0, W - i, H)
    return im.crop(box).tobytes()


def _ink_ratio(buf: bytes) -> float:
    """一条边线上"局部异常点"的占比。渐变底≈0，文字笔画/硬边会顶上去。"""
    k, n = EDGE_NEIGHBOR, len(buf) // 3
    if n <= 2 * k:
        return 0.0
    step = k * 3
    ink = 0
    for o in range(k * 3, (n - k) * 3, 3):
        if max(abs(buf[o] - (buf[o - step] + buf[o + step]) / 2.0),
               abs(buf[o + 1] - (buf[o + 1 - step] + buf[o + 1 + step]) / 2.0),
               abs(buf[o + 2] - (buf[o + 2 - step] + buf[o + 2 + step]) / 2.0)) > EDGE_INK_TOL:
            ink += 1
    return ink / (n - 2 * k)


def _edge_ink_hits(path: Path):
    """返回 [(边, 距边第几圈, 异常点占比)]；PIL 缺席时返回 None（=没查成，⛔ 不等于干净）。"""
    try:
        from PIL import Image
    except ImportError:
        return None
    with Image.open(path) as raw:
        im = raw.convert("RGB")
        W, H = im.size
        band = max(3, int(round(EDGE_BAND_RATIO * min(W, H))))
        out = []
        for side in _SIDES:
            for i in range(band):
                r = _ink_ratio(_edge_line(im, side, i))
                if r >= EDGE_INK_RATIO:
                    out.append((side, i, r))
                    break            # 只报最靠外的那一圈，够定位了
    return out


def _print_edge_report(path: Path) -> None:
    """判据③ 的输出。🔴 只打印，⛔ 绝不参与退出码（Bowen 的口径：这条是提示不是门禁）。"""
    hits = _edge_ink_hits(path)
    if hits is None:
        print("   ⏭️ 版式贴边检查跳过（没装 Pillow）—— ⛔ 不等于没问题，四边放大看一眼。")
        return
    if not hits:
        print("   ✅ 版式贴边检查：四边最外一圈都是干净背景（没有被画布切掉的迹象）。")
        return
    print("   ⚠️ 版式贴边（只告警，不影响退出码）—— 内容压在画布边上，**可能是被切掉了**：")
    for side, i, r in hits:
        print(f"      · {side}边 第 {i}px 圈就有笔画/硬边（该行 {r*100:.1f}% 是异常点）")
    print("      🔴 判据①只比【文字内容】，「字对但被削掉一截」它必然绿灯 ⇒ 这里报了就**放大那条边核一眼**。")
    print("      ℹ️ 通栏色块 / 满幅照片本来就贴边（m1 的斜切蓝底就是）—— 那是设计如此，"
          "看一眼确认不是字被切即可。")


# ── OCR 通道 ──────────────────────────────────────────────────────────────────
def _ocr_lines(path: Path) -> list:
    """读图取文字行。抛 `CloudOCRUnavailable` / `RuntimeError` 交给 main 转退出码 2。

    🔴 用 `verify_label.ocr()`，⛔ 不是国内那版写死的 `_ocr_cloud`：
      国内的 `verify_label` 只有云通道，macOS 上也照样花钱调云；**国际站的 `verify_label` 两条都有**
      （`_ocr_vision` = macOS 系统 Vision，离线免费；`_ocr_cloud` = 非 macOS 的 deepkey 文本组），
      `ocr()` 就是那个按平台分发的门面。判据① **只要文字内容、不要坐标**，Vision 完全够用
      ⇒ 走 `ocr()` 能在 macOS 上把每张图的云调用费省掉，同事的 Windows 自动落到云那条，行为不变。
    🔴 **按【下标】取，⛔ 别写成 `for t, _conf in ocr(path)`** —— OCR 的返回形状是**跨文件契约**
      （现行 `ocr()` 返回 `[(文字, 置信度)]` 二元组，且**没有** `ocr_lines()` 这种只回文字的变体）。
      按元组长度解包的话，`ocr()` 一旦多回一位（国内就发生过：有人给它加了第三位）就当场
      `ValueError: too many values to unpack` ⇒ 本脚本崩在这行 ⇒ **退出码 1**（Python 未捕获异常）。
      而 1 在调用方 `render_v2` 那里的语义是「门禁没通过」⇒ 它会去**烧两轮重掷**，
      而真相是「这道闸门根本没跑成」，本该退 2、停下来修工具。
    ⚠️ **不按置信度过滤**（`verify_label.check_expect_forbid` 那边有 `--min-conf`，这里故意不要）：
      滤掉低分行只会让 `got` 变少 ⇒ 制造假的"缺字" ⇒ 白烧重掷。多留几行噪声最多让判据①
      稍微宽松一点，方向上是安全的那一边。
    """
    try:
        from verify_label import ocr  # noqa: PLC0415
    except ImportError as e:
        raise RuntimeError(f"导不进 verify_label（{e}）—— skill 没同步全？")
    rows = ocr(path)
    return [row[0] for row in rows]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="① 我方文案必含（决定退出码） + ③ 贴边告警（只打印）。⛔ 不含禁词判据，见文件头。")
    ap.add_argument("build_dir", nargs="?", help="build.py 的输出目录（里面有 <module_key>.html）")
    ap.add_argument("module_key", nargs="?", help="模块名，如 m1 / d2")
    ap.add_argument("--after", help="--scene 出来的图（overlay 之前那张）")
    ap.add_argument("--selftest", action="store_true",
                    help="判据① 的正反例自检（不联网、不出图、不读构建目录）")
    a = ap.parse_args(argv)

    if a.selftest:
        return _selftest()
    if not (a.build_dir and a.module_key and a.after):
        ap.error("要么给 <build_dir> <module_key> --after <图>，要么只给 --selftest")

    build = Path(a.build_dir)
    html = build / f"{a.module_key}.html"
    after = Path(a.after)
    if not html.exists():
        print(f"❌ 没跑成：{html} 不在（build 目录/模块名给错了？）")
        return 2
    if not after.exists():
        print(f"❌ 没跑成：{after} 不在")
        return 2

    want = expected_copy(html)
    if not want:
        print(f"❌ 没跑成：从 {html.name} 里一条文案都没提出来 —— 模板结构变了，判据失效。\n"
              f"   ⛔ 别当通过：这张图有没有被改字**根本没查过**。")
        return 2

    try:
        lines = _ocr_lines(after)
    except Exception as e:                                    # noqa: BLE001
        name = type(e).__name__
        print(f"❌ 没跑成：OCR 不可用（{name} {e}）")
        if name == "CloudOCRUnavailable":
            print(f"   👉 先跑 python {SCRIPTS.name}/check_env.py 看 ② 那一行（云 OCR 走 deepkey"
                  f"【文本组】，⛔ 不是生图组）。")
        elif name in ("ImportError", "ModuleNotFoundError"):
            print("   👉 macOS 走系统 Vision，缺的多半是 pyobjc（Quartz / Vision）。")
        print("   ⛔ 这不是「文案没问题」，别放它过去。")
        # 判据③ 不依赖 OCR、也不联网 —— OCR 挂了它仍能给出唯一的自动信号，照打。
        # ⛔ 但它顶不了判据①：退出码仍是 2（没跑成），别拿"贴边没报"当通过。
        _print_edge_report(after)
        return 2

    missing, soft = judge_copy(want, lines)

    print(f"🔎 {a.module_key}：OCR 读到 {len(lines)} 行；期望文案 {len(want)} 条 —— "
          f"命中 {len(want) - len(missing)}/{len(want)}")
    if soft:
        print("   ⚠️ 这几条**字都对、只差标点/间隔号**（OCR 对 → · † , 本来就时读时不读）⇒ 判通过，"
              "但值得扫一眼：")
        for s in soft:
            print(f"      · 「{s}」")
    if missing:
        got_n = [norm(x) for x in lines]
        print("   ❌ 这几条我方文案在图上【对不上】（AI 改了 / 糊了 / 被产品压住了）：")
        for m in missing:
            # 「图上最接近的是」是给人看的定位线索 —— 报错时人要靠它判断是"被改写"还是"整条没画"。
            # ⛔ 别改回国内那版的 `len(set(g) & set(norm(m)))`（**按字符集合**取交集）：
            #    那个打分只数"有多少种字符重合"、不看顺序也不看长度，**中文能凑合、英文会指错人** ——
            #    实测本机反例（把 `NSF GMP Certified Facility` 改成 `NSF Certified Plant`），
            #    它指到了完全无关的 `oem/odmsupplementmanufacturer`（那行长、字母种类多），
            #    真正的改写行反而没被指出来。difflib 看顺序，同一例直接指对。
            near = max(got_n, key=lambda g: difflib.SequenceMatcher(None, g, norm(m)).ratio(),
                       default="")
            print(f"      · 期望「{m}」  图上最接近的是「{near[:44]}」")

    # 判据③：🔴 放在退出之前打，通过/不通过两条路都要看得见
    _print_edge_report(after)

    if missing:
        # 🔴 处置顺序 = 【当下真能做的排前面】。
        #    旧版把「写 swap.keep_text → gen_image.py --keep-text」当第一处置，但**本站
        #    gen_image.py 根本没有 `--keep-text`**（argparse 里 0 命中），而同一次运行里
        #    render_v2 收尾自己还会打一句"本站还没有 --keep-text" ⇒ 脚本自相矛盾、照做无效。
        #    ⇒ 接通前把它降级成【暂不可用】。接通 = 方案 I-73（给 gen_image.py 补参数），
        #    ⛔ 别在本文件里"顺手"造透传。
        print("   👉 处置（🔴 按【当下真能做的】排序，脚本不替你选，判定权在用户）：")
        print("      ① 放大目检后觉得能用 ⇒ 直接用（③⁰ 是筛子不是判官，云 OCR 自己也会读错）。")
        print("      ② 退回 overlay（`RENDER_V2_COPY_OCR=0` 重跑这几个模块）⇒ 文案像素级精确，"
              "**但有双影风险**（overlay 是「盖」不是「擦」，由 ③½ check_scene_text 去查）。")
        print("      ③ 改 `mode: composite` ⇒ 全分辨率精确、不调 AI，**但要先有干净透明抠图件**"
              "（cutout.py 在同事机器上不稳，是兜底不是常规解）。")
        print("      ⛔ 暂不可用（方案 I-73 未做）：把点出来的字样写进 product.json 该模块的")
        print("         `swap.keep_text`、指望 `gen_image.py --keep-text` 逐字保真 —— "
              "**本站 gen_image.py 没有这个参数**，")
        print("         写了也不会透传，掷出去的提示词与上一轮**逐字相同**。")
        print("      ⛔ 所以别原路重掷：国内三掷实测，第 2 掷（一字未改）同位同错法；"
              "点名字样后一掷就对")
        print("         ⇒ **「改了提示词的重掷」和「原路重掷」是两回事**，本站现在只有后者。")
        return 1

    print("   ✅ 通过：我方文案逐条对得上 ⇒ 可以【不 overlay】直接出图（结构上不会有双影）。")
    print("   ⚠️ 本判据只保证【文字内容】对。字体是 AI 模仿的、整块位置可能漂几到二十几 px。")
    print("   🔴 ⛔ 它**不保证版式边界**：字全对但整块被画布切掉一截，这里照样是绿灯"
          "（国内 t02 两跑 21/21，实际标题被削 1/4 字高）。上面的贴边告警只是筛子 ——"
          "**成品仍要逐张 Read 放大核四边**。")
    print("   🔴 ⛔ 它也**不查违规词**（本版没有判据②，理由见文件头）—— 合规照旧走 verify_copy.py"
          " + references/label-compliance.md 人工那一路。")
    return 0


# ── 自检：造正反例，证明判据① 既能报、也不会乱报 ──────────────────────────────────
_SELFTEST_HTML = """<!doctype html><html><head><style>.h1{font-size:54px;}</style></head><body>
<!-- ⛔ 这段注释里带 <b>标签</b> 和 > 号，是用来证明注释被剥干净的 -->
<div class="bar"><div class="logo">LIFEWORTH<sup>&reg;</sup></div>
<div class="tag">OEM / ODM SUPPLEMENT MANUFACTURER</div></div>
<div class="h1">LAUNCH A<br>HOT-SELLING<br><span class="lime">CREATINE HYDRATION</span></div>
<div class="cols">
  <div class="col">Flexible MOQ<br>Low-volume trial runs</div>
  <div class="col">Fast Sampling<br>Test the market first</div>
</div>
<div class="cta">GET A FREE QUOTE &rarr;</div>
<div class="hole">{{NOT_FILLED}}</div>
</body></html>"""

# OCR 的**视觉行序**：双列卡片是「左列第1行 → 右列第1行 → 左列第2行 → 右列第2行」。
# 🔴 这个顺序就是 `<br>` 必须拆条的全部理由 —— 拼成一条的话，"Flexible MOQ Low-volume trial runs"
#    中间永远隔着 "Fast Sampling"，跨行拼接匹配不上。
_OCR_GOOD = [
    "LIFEWORTH", "OEM / ODM SUPPLEMENT MANUFACTURER",
    "LAUNCH A", "HOT-SELLING", "CREATINE HYDRATION",
    "Flexible MOQ", "Fast Sampling",
    "Low-volume trial runs", "Test the market first",
    "GET A FREE QUOTE",          # 箭头没读出来 → 只该落进 soft，⛔ 不该判失败
]


def _selftest() -> int:
    import tempfile
    fails = []

    def ck(name, cond, detail=""):
        print(("  ✅ " if cond else "  ❌ ") + name + (f"  {detail}" if detail and not cond else ""))
        if not cond:
            fails.append(name)

    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "t.html"
        p.write_text(_SELFTEST_HTML, encoding="utf-8")
        print("【A】expected_copy 提取")
        want = expected_copy(p)
        for t in want:
            print(f"     |{t}|")
        ck("A1 <br> 拆成独立条目（不是拼一条）",
           "Flexible MOQ" in want and "Low-volume trial runs" in want
           and not any("Flexible MOQ Low" in w for w in want), want)
        ck("A2 注释整段剥掉（含注释里的标签）", not any("标签" in w or "注释" in w for w in want), want)
        ck("A3 <style> 块不进期望", not any("font-size" in w for w in want), want)
        ck("A4 HTML 实体还原（&rarr; → →）", "GET A FREE QUOTE →" in want, want)
        ck("A5 一两字符碎片不作判据（®）", not any(_alnum(w) == "" for w in want) and "®" not in want, want)
        ck("A6 没填上的占位符不作判据", not any("{{" in w for w in want), want)

    print("【B】判据①：不该报的没报")
    miss, soft = judge_copy(want, _OCR_GOOD)
    ck("B1 OCR 按视觉行序读双列卡片 → 零缺字", miss == [], f"missing={miss}")
    ck("B2 只差箭头的那条落进 soft（通过但提示）", soft == ["GET A FREE QUOTE →"], f"soft={soft}")
    wrapped = ["LIFEWORTH", "OEM / ODM SUPPLEMENT", "MANUFACTURER"] + _OCR_GOOD[2:]
    miss_w, _ = judge_copy(want, wrapped)
    ck("B3 OCR 把一句折成两行（跨行拼接）也算命中", miss_w == [], f"missing={miss_w}")
    upper = [x.upper() for x in _OCR_GOOD]
    miss_u, _ = judge_copy(want, upper)
    ck("B4 CSS text-transform 造成的大小写差异不算缺字", miss_u == [], f"missing={miss_u}")

    print("【C】判据①：该报的报了")
    drop = [x for x in _OCR_GOOD if x != "Fast Sampling"]
    miss_d, _ = judge_copy(want, drop)
    ck("C1 漏画一条 → 精确报出那一条", miss_d == ["Fast Sampling"], f"missing={miss_d}")
    reword = ["Quick Sampling" if x == "Fast Sampling" else x for x in _OCR_GOOD]
    miss_r, _ = judge_copy(want, reword)
    ck("C2 AI 改写一条（Fast→Quick）→ 报出来", miss_r == ["Fast Sampling"], f"missing={miss_r}")
    typo = ["CREATINE HYDRATON" if x == "CREATINE HYDRATION" else x for x in _OCR_GOOD]
    miss_t, _ = judge_copy(want, typo)
    ck("C3 掉一个字母的错字 → 报出来（⛔ 不做模糊匹配）", miss_t == ["CREATINE HYDRATION"], f"missing={miss_t}")
    miss_e, _ = judge_copy(want, [])
    ck("C4 OCR 一行都没读到 → 全报（⛔ 不静默放行）", len(miss_e) == len(want), f"missing={len(miss_e)}")

    print("【D】判据③：贴边检测（合成图，不出真图）")
    try:
        from PIL import Image, ImageDraw
        with tempfile.TemporaryDirectory() as d:
            clean = Path(d) / "clean.png"
            im = Image.new("RGB", (400, 400))
            px = im.load()
            for y in range(400):                     # 竖直渐变底：模拟宝蓝渐变，应当零命中
                for x in range(400):
                    px[x, y] = (10 + y // 8, 40 + y // 6, 120 + y // 4)
            im.save(clean)
            ck("D1 渐变底 → 不报贴边", _edge_ink_hits(clean) == [], str(_edge_ink_hits(clean)))
            cut = Path(d) / "cut.png"
            im2 = im.copy()
            dr = ImageDraw.Draw(im2)
            for x in range(0, 400, 7):               # 顶边压上一排"笔画"：模拟标题被削
                dr.rectangle([x, 0, x + 2, 3], fill=(255, 255, 255))
            im2.save(cut)
            hits = _edge_ink_hits(cut)
            ck("D2 顶边有笔画 → 报出「顶」边", any(h[0] == "顶" for h in hits or []), str(hits))
    except ImportError:
        print("  ⏭️ 跳过（没装 Pillow）")

    print()
    if fails:
        print(f"❌ 自检不通过：{len(fails)} 项 —— {fails}")
        return 1
    print("✅ 自检通过：判据① 正反例都对，判据③ 正反例都对。")
    print("   ⚠️ 自检只证明【判据逻辑】对，⛔ 不证明真 OCR 读得准 —— 那要跑真图。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
