#!/usr/bin/env python3
"""阿里国际站英文文案合规筛子 —— 扫疾病/治疗宣称、FDA、错误认证、专利成分、绝对化词、联系方式。

用法：
    python scripts/verify_copy.py 文案.txt 信息表.json ...    # 扫文件（含 .json/.md/.html/.txt）
    python scripts/verify_copy.py --text "Best FDA approved cure"   # 直接扫一段文字
    echo "copy text" | python scripts/verify_copy.py               # 管道

退出码：命中【高危】(疾病/治疗·FDA·错误认证·专利成分/organic) = 1，否则 0。
        绝对化/联系方式只告警，不改退出码。

🆕 2026-08-09 商标豁免通道：扫的是信息表 json 时，若 `<模块>.facts.trademark_ok`（当前 = m7）
   列了某个**商标原料名**，该词降为 🟢 告知、不判高危、不挂退出码 1
   —— Bowen 定：**他同意就行，⛔ 不需要他提供授权方/授权文件**。
   ⛔ 只对【被扫的那份 json 自己】生效，⛔ 没有全局开关/环境变量，⛔ organic 与疾病宣称等一律不吃这条。
   细节与三条护栏见下面 TRADEMARK_PATS 那段注释。

🔴 这是**筛子不是判官**：命中要人工判。词表与口径以 references/copy-compliance.md §1 为准
   （改词先改那份文档，再同步本脚本）。英文按【整词 + 大小写不敏感 + 常见变体】匹配，
   已尽量避开子串误伤（treatment 里的 treat、accurate 里的 cure），拿不准的一律报出来让人看。

⚠️ 别拿本脚本扫 references/*.md 合规文档本身——那些文档就是词表，会整片飘红。
   要扫的是【会上图的文案】：信息表 json、渲染出的 html、或单独的文案 txt。
"""
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _compat  # noqa: F401  跨平台 UTF-8 兜底（Windows 管道下不修会崩）

# (类别, 严重度 high/warn, [正则...])。high 影响退出码。
# 正则一律 re.IGNORECASE 编译；\b 保证整词，避免子串误伤。
RULES = [
    ("疾病/治疗宣称", "high", [
        r"\bcure(s|d)?\b", r"\bcuring\b",
        r"\btreat(s|ing|ed)?\b", r"\bheal(s|ed|ing)?\b",
        r"\bremed(y|ies)\b", r"\btherap(y|ies|eutic)\b", r"\bmedicinal\b",
        r"\bdiagnos(e|es|ed|is|tic)\b",
        r"\bprevent(s|ing)?\s+(disease|diseases|illness|infection|cancer|flu|cold)\b",
        r"\banti-?inflammatory\b", r"\bantiviral\b", r"\bantibacterial\b", r"\bantifungal\b",
        r"\b(lower|lowers|reduce|reduces)\s+(blood\s+)?(pressure|sugar|cholesterol)\b",
    ]),
    ("疾病名(作疗效对象)", "high", [
        r"\bcancer\b", r"\bdiabetes\b", r"\bhypertension\b",
        r"\bdepression\b", r"\banxiety\b", r"\barthritis\b", r"\bAlzheimer('?s)?\b",
    ]),
    ("女性健康/既有高危词", "high", [
        r"\bvaginal\b", r"\bgut[- ]vagina\s+axis\b", r"\blibido\b",
        r"\bsexual\b", r"\bintimacy\b", r"\bdisease\b",
    ]),
    ("FDA(阿里国际站全禁)", "high", [
        r"\bFDA\b", r"美国食品药品监督管理局",
    ]),
    ("错误认证表述", "high", [
        r"\bNSF\s+Certified\s+for\s+Sport\b",
        r"\bFDA[- ]?(certified|approved|certification|cleared)\b",
        r"\b(clinically|doctor|lab)\s+certified\b",
    ]),
    ("专利成分/organic/虚构来源", "high", [
        r"\bCreapure\b", r"\bKSM-?66\b", r"\bAstraGin\b", r"\bSensoril\b",
        r"\bAlbion\b", r"\bCapsimax\b", r"\bTeaCrine\b", r"\bCarnoSyn\b",
        r"\bBio-?Perine\b",   # 2026-08-09 补：Bowen 给的营养成分表参考图里就印着它，此前扫不出来
        r"\bcertified\s+organic\b", r"\borganic\b",
        r"\bwild-?harvested\b", r"\bwild-?crafted\b",
    ]),
    ("绝对化/最高级(数字化铁律)", "warn", [
        r"#\s*1\b", r"\bno\.?\s*1\b",
        r"\bbest\b", r"\btop-?rated\b", r"\bworld-?class\b", r"\bultimate\b",
        r"\bfinest\b", r"\bpremier\b", r"\bstrongest\b", r"\bpurest\b",
        r"\bleading\b", r"\bindustry-?leading\b", r"\bmarket\s+leader\b",
        r"\bunmatched\b", r"\bunbeatable\b", r"\bunrival{1,2}ed\b",
        r"\bguarantee(s|d)?\b", r"\b100\s*%", r"\bperfect\b", r"\bflawless\b",
        r"\bmiracle\b", r"\brevolutionary\b", r"\bbreakthrough\b",
        r"\b(clinically|scientifically)\s+proven\b", r"\bdoctor\s+recommended\b",
    ]),
    ("联系方式/链接(主图硬禁)", "warn", [
        r"https?://", r"\bwww\.", r"\.com\b", r"\.cn\b",
        r"\bWhatsApp\b", r"\bWeChat\b", r"\btel:", r"[\w.\-]+@[\w.\-]+\.\w+", r"\bQR\b",
    ]),
]

# 命中后看紧随其后的文字，落在这些合法上下文里就放行（只对 warn 用，减少误伤）。
# key = 正则原文；value = 命中点之后 24 字符内若匹配任一，则跳过。
EXCLUDE_AFTER = {
    r"\bbest\b": [r"^\s*[- ]?practices?\b"],          # best practice(s) 行业术语
    r"\b100\s*%": [r"\s*(traceable|natural\s+source|recyclable)\b"],  # 可核实事实，非疗效
    r"\bleading\b": [r"\s*edge\b"],                    # leading edge
}

# 命中点所在【整行】落进这些上下文就放行 —— 比 EXCLUDE_AFTER 多看一层：
# 有些误伤只能靠命中点【之前】的字判断，而 EXCLUDE_AFTER 只看后面 24 字符。
# 🆕 2026-08-09（m7 营养成分表带来的）：`"dv": "100%"` 是**法定 %DV 数据**，不是"100% 最强"式宣称。
#   不排掉的话，每张含维生素的成分表都会稳定打一条 ⚠️（维生素按 100% DV 投料是常规做法）——
#   那正是 qc.py 里写明的那条原则：**假警会训练人忽略告警，比不报更糟**。
# ⛔ 加条目前先确认它只能靠"前文"判断；能靠后文判断的一律进 EXCLUDE_AFTER（那个更窄、更难误放）。
EXCLUDE_LINE = {
    r"\b100\s*%": [r'"dv"\s*:\s*"?\s*\d+\s*%'],
}

COMPILED = [
    (cat, sev, [(p, re.compile(p, re.IGNORECASE)) for p in pats])
    for cat, sev, pats in RULES
]
EXCLUDE_C = {k: [re.compile(x, re.IGNORECASE) for x in v] for k, v in EXCLUDE_AFTER.items()}
EXCLUDE_LINE_C = {k: [re.compile(x, re.IGNORECASE) for x in v] for k, v in EXCLUDE_LINE.items()}

# ══════════════════════════════════════════════════════════════════════════════
# 🆕 商标成分豁免通道（Bowen 2026-08-09 定，m7 营养成分表带来的）
#
# 规矩：`check_facts.py` 扫到商标原料 → 退出码 3 停机问 Bowen → **他说同意就算数**，
#   ⛔ 不要求他提供授权方/授权文件（口径变更：copy-compliance.md §7 原写"除非书面授权"，
#   由 B3 组同步改成"Bowen 明确同意 = 放行；未询问/未同意 = 硬拦"）。
#   同意的成分名写进信息表 `m7.facts.trademark_ok` → 本脚本重跑时不再判高危、不挂退出码。
#   （否则每改一版配方就被同一个词卡一次，闸门会被人整个绕过去 —— 那才是真危险。）
#
# 🔴 三条护栏，动这段之前先读完：
#   ① **只认【被扫的那份 json 自己】声明的 trademark_ok** —— ⛔ 不做全局开关、⛔ 不认环境变量、
#      ⛔ 不跨文件继承。做成开关 = 一个 `SKIP_TM=1` 就能绕过整道合规闸门，等于没有闸门。
#   ② **只有商标原料词可豁免**（下表）。⛔ organic / wild-harvested / certified organic 不在内：
#      那是**认证与产地宣称**（USDA/欧盟有机认证、来源真实性），不是商标授权问题，
#      Bowen 点头也解决不了 —— 把它们放进来就是拿一条规则去豁免另一条。
#      疾病宣称 / FDA / 错误认证更是一个都不放（trademark_ok 里写 "cancer" 也不会生效）。
#   ③ 豁免 ≠ 没风险：商标风险本身还在（阿里被投诉即删图/扣分），所以豁免要**打印出来**让人看见，
#      ⛔ 不许静默跳过。静默正是本 skill 反复在治的病。
# ══════════════════════════════════════════════════════════════════════════════
TRADEMARK_PATS = {
    r"\bCreapure\b", r"\bKSM-?66\b", r"\bAstraGin\b", r"\bSensoril\b",
    r"\bAlbion\b", r"\bCapsimax\b", r"\bTeaCrine\b", r"\bCarnoSyn\b", r"\bBio-?Perine\b",
}


# 🔴 商标名归一 = **直接用 `check_facts.norm_tm`**（I-77，2026-08-17），⛔ 别在这里再写一份。
#    它比本文件的旧实现多做一步：**先摘掉 ® ™ (R) （R）再比**。少这一步，Bowen 在 `trademark_ok`
#    里写 "KSM-66 (R)" 会归成 "ksm66r"、跟命中词 "ksm66" 对不上 ⇒ **同意了照样被拦**，
#    而人只会以为闸门坏了。
#    旧账：`check_facts` 2026-08-09 就修好了，本文件一直没跟上；`build.py` 当时的应对是加了个
#    「优先 import check_facts 那份」的适配层绕过去 —— 于是 build 那条路是对的，
#    **单独跑 `verify_copy.py` 的人照旧踩坑**（文档里教了 20+ 处单跑）。
#    ⛔ 改回本地实现 = 那个坑原样复活。`check_facts.selftest()` 有一条断言专门钉住这件事。
from check_facts import norm_tm as _norm_tm   # noqa: E402


def approved_trademarks(path: Path) -> tuple:
    """从**这一份**信息表 json 里读已获同意的商标成分。返回 (归一名集合, 回填说明)。

    取数位置 = 契约定死的 `<模块>.facts.trademark_ok`（当前只有 m7 有 facts 段；
    按"任一顶层模块的 facts"读，是为了以后再加成分表模块时不用改这里，⛔ 不是放宽范围）。
    json 解析不了（不是 json / 语法错）→ **返回空集 = 一个都不豁免**（fail-closed，
    ⛔ 别改成"解析失败就全放行"）。"""
    if path.suffix.lower() != ".json":
        return frozenset(), ""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return frozenset(), ""
    if not isinstance(data, dict):
        return frozenset(), ""
    ok, notes = set(), []
    for mod, spec in data.items():
        if mod.startswith("_") or not isinstance(spec, dict):
            continue
        facts = spec.get("facts")
        if not isinstance(facts, dict):
            continue
        for name in facts.get("trademark_ok") or []:
            if isinstance(name, str) and _norm_tm(name):
                ok.add(_norm_tm(name))
        note = facts.get("_approved")
        if isinstance(note, str) and note.strip():
            notes.append(f"{mod}: {note.strip()}")
    return frozenset(ok), " · ".join(notes)


def _load_text(path: Path) -> str:
    """读文件文本。.json 也按纯文本读（顺便扫到键名/注释），足够当筛子用。"""
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError as e:
        print(f"⚠️  读不了 {path}: {e}")
        return ""


def scan(text: str, approved=frozenset()):
    """返回命中列表 [(严重度, 类别, 命中词, 行号, 行内容)]。

    approved = **本文件自己**声明的已获同意商标（归一名集合，见 approved_trademarks）。
    命中它 → 严重度降为 "ok"（照常打印告知，但不算高危、不挂退出码 1）。
    ⛔ 只有 TRADEMARK_PATS 里的商标原料词吃这条豁免，其余规则一律照旧（护栏②）。"""
    hits = []
    lines = text.splitlines() or [text]
    for lineno, line in enumerate(lines, 1):
        # 跳过信息表里 "_" 开头的注释/取数依据键——那些不会上图（build.py 也跳过它们）
        if line.lstrip().startswith('"_'):
            continue
        for category, severity, pats in COMPILED:
            for raw, rx in pats:
                for m in rx.finditer(line):
                    tail = line[m.end(): m.end() + 24]
                    excls = EXCLUDE_C.get(raw)
                    if excls and any(e.match(tail) for e in excls):
                        continue
                    lex = EXCLUDE_LINE_C.get(raw)
                    if lex and any(e.search(line) for e in lex):
                        continue
                    term = m.group(0).strip()
                    sev = severity
                    if raw in TRADEMARK_PATS and _norm_tm(term) in approved:
                        sev = "ok"
                    hits.append((sev, category, term, lineno, line.strip()))
    return hits


def main(argv):
    args = argv[1:]
    sources = []  # (来源名, 文本)

    # 每个来源自带一份【它自己的】商标豁免集（护栏①：⛔ 不跨来源共享、⛔ 不做全局开关）。
    if "--text" in args:
        i = args.index("--text")
        txt = args[i + 1] if i + 1 < len(args) else ""
        sources.append(("<--text>", txt, frozenset(), ""))
        args = args[:i] + args[i + 2:]

    files = [a for a in args if not a.startswith("-")]
    for f in files:
        p = Path(f)
        if p.is_file():
            ok_tm, note = approved_trademarks(p)
            sources.append((str(p), _load_text(p), ok_tm, note))
        else:
            print(f"⚠️  跳过（不是文件）：{f}")

    if not sources and not sys.stdin.isatty():
        # 管道进来的文本没有文件身份 ⇒ 拿不到 trademark_ok ⇒ 不豁免（fail-closed）。
        sources.append(("<stdin>", sys.stdin.read(), frozenset(), ""))

    if not sources:
        print(__doc__)
        return 2

    total_high = 0
    total_warn = 0
    total_ok = 0
    for source, text, approved, note in sources:
        hits = scan(text, approved)
        if not hits:
            print(f"✅ {source}：未命中")
            continue
        print(f"\n──  {source}  ──")
        seen = set()  # 去重同 (类别,词,行)
        said_ok = False   # 豁免的说明每份文件只讲一遍（每条都讲会把真正的高危行淹掉）
        for severity, category, term, lineno, line in hits:
            key = (category, term.lower(), lineno)
            if key in seen:
                continue
            seen.add(key)
            mark = {"high": "🔴高危", "warn": "⚠️告警"}.get(severity, "🟢已同意")
            print(f"  {mark} [{category}] 「{term}」  L{lineno}: {line[:80]}")
            if severity == "high":
                total_high += 1
            elif severity == "warn":
                total_warn += 1
            else:
                # 🔴 豁免要**说出来**，⛔ 不许静默跳过（护栏③：豁免的是拦截，不是风险）。
                #    但整段说明每份文件只讲一次 —— 每条都讲会把真正的高危行淹在里面。
                total_ok += 1
                print("       └ 已获 Bowen 同意（本文件 facts.trademark_ok 里列了它），不判高危、不挂退出码。")
                if not said_ok:
                    said_ok = True
                    if note:
                        print(f"         回填记录：{note}")
                    print("         ⚠️ 但商标风险本身仍在：阿里被投诉即删图/扣分，"
                          "上图前确认这几个词确实是 Bowen 本人点过头的。")

    print(f"\n合计：🔴高危 {total_high} · ⚠️告警 {total_warn}"
          + (f" · 🟢商标已同意放行 {total_ok}" if total_ok else ""))
    if total_high:
        print("→ 高危项必须改（阿里平台硬规则 / 目标市场监管）。改法见 references/copy-compliance.md。")
    print("⚠️ 这是筛子不是判官，逐条人工确认。linter 查不到的（词在哪个图层/包装印的标/竞品 logo/数字口径）走 §5 清单人工过。")
    return 1 if total_high else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
