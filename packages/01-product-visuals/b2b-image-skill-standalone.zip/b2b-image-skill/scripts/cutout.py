#!/usr/bin/env python3
"""产品图抠透明背景。本地确定性算法，不用 AI 重画产品。

⛔ 绝不要拿产品图去喂 gpt-image-2 的 edits 做"去背景"：
   edits = 重新生成，不是修图。实测它把肌酸桶整个标签重画了——
   丢了"肌肉图标 + MUSCLE SUPPORT & RECOVERY"、排版也变。那是篡改真实产品。

选型口诀（走错就毁素材，别凭感觉）:
   ★ 白底/浅底的产品图（罐/袋/瓶/杯）  → --mode flood  （默认，最常见的情况）
   主体 + 水花/冰块/烟雾的复合场景素材  → --mode flood
   有真实场景背景（桌面/环境/非纯色底） → --mode rembg
   两者都对一半（水果+水花，底部有水洼）→ --mode hybrid

为什么这么分:
   Flood Fill 靠"边缘连通"判背景：颜色像背景还不够，必须能从四边走进来才算外部。
   这条连通性约束让它对白底产品极准——产品轮廓内的白色（标签/高光/袋子侧面）走不进去，保得住。
   rembg 做语义分割，适合"从真实场景里抠出主体"；但它只保主体，水花冰块会被判成背景删光。

🔴 rembg 会啃浅色边缘 —— 别信"语义分割所以白产品没问题"（2026-07-16 VOLT 白袋实证，Bowen 肉眼抓出）
   这份文件曾断言"rembg 认这是个罐子而不是比亮度，所以白产品贴白底完全不是问题"，**该断言是错的，已删**。
   实测 VOLT 白袋：右侧【立体侧面是浅灰 RGB 240-250】，背景 255，只差 5-15 色阶 →
   u2net 判成背景吃掉，袋子边缘一圈丢 3.5%(24660px)，右缘被削成一条笔直竖线（真袋子是圆润的）。
       y=800 那行的证据：x878 RGB(248,248,248) α106 → x890 RGB(245,245,246) α7
       源图明明有产品(245≠255)，rembg 给了近乎全透明。
   同图四法实测【袋子右缘累计丢失】：flood(thresh6)=4px · flood(thresh10)=5px · rembg=179px
   → 4px ≈ 抗锯齿边，属正常；179px = 肉眼可见的缺角。**白底产品一律 flood。**

⚠️ 别试图用"亮度键反解半透明"那类方法（2026-07-16 试过，被 Bowen 打回）:
   思路是 a = 1 - min(RGB)/BG 反解出半透明度，让水花贴蓝底透蓝。水花确实变好看了，
   但它的隐含假设是【越亮 = 越透明】—— **冰块不符合**：冰是散射光的白色固体，亮但不透明。
   实测冰块 alpha 中位数被判成 0，贴蓝底整块透蓝。Bowen 原话：「冰块本应该是白色的，
   放在蓝色背景里变成蓝色就显得不真实」。泡沫/奶/粉末/高光同理。
   **水花+冰块就用 hybrid，二值硬 alpha 让冰块保持白色才是对的。**

本版默认就出【干净边】（针对同事反馈的"毛边/没抠干净/抠多了"三连）：
  · 边缘收尾：flood/hybrid 默认 `--defringe 1`（去白边）+ `--feather 0.8`（抗锯齿），
    产品与深色底之间不再有白圈、边不再锯齿。要绝对硬边用 `--hard-edge`。
  · 背景容差：不传 `--thresh` 时【自动探测】——纯白底=6，均匀近白灰底（如 245 studio 背景）
    自动抬高到刚好覆盖（封顶 18），解决"灰底没抠干净"。三道闸很保守，喷溅/实景图会回落到 6 不冒进。
    冰块/玻璃等浅色高光仍要【手动调低】 `--thresh 2`（见下）。

用法:
    python cutout.py in.png out.png                      # flood（默认，白底产品，自动收边+抗锯齿）
    python cutout.py in.png out.png --mode rembg         # 有真实场景背景时才用
    python cutout.py in.png out.png --mode hybrid --seam 700 790   # ★ 水花+冰块
    python cutout.py in.png out.png --split 518          # 主次包装：只留主包装
    python cutout.py in.png --scan                       # 找主次包装的切点
    python cutout.py out.png --verify in.png             # 单独补一张红底验收图

验收：出图后【自动】生成 `*_验收_红底.png` 并要求你 Read 它，不用记得跑第二条命令。
     ⛔ 别用蓝底自检：品牌蓝会跟产品和谐融合，正好盖住浅色边缘缺失。
        VOLT 那次我合成到蓝底看了、没看出来；换红底立刻露馅。红底是硬要求。
"""
import argparse, sys

from collections import deque
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （必须 import：修 Windows 管道输出下 emoji 崩溃）

try:
    from PIL import Image, ImageFilter
except ImportError:
    sys.exit("需要 Pillow：pip install pillow")


def _edge_finish(alpha: Image.Image, defringe: int = 1, feather: float = 0.8) -> Image.Image:
    """把 flood 的二值 alpha 修成干净的抗锯齿边 —— 一步解决"白边"和"锯齿毛边"两件事。
    （这是 flood/hybrid 的【默认】收尾；旧版 defringe 默认关、且只收边不抗锯齿，同事那边全是毛边。）

    两步，顺序不能反：
      ① 去白边：MinFilter(3) 把不透明区向内收 defringe 像素，削掉产品与白底之间那圈
         235-248 的抗锯齿过渡像素 —— 它们"不够白"→ 被 flood 判成产品留下 → 贴深色底就是一圈白边
         （Bowen 2026-07-20 肉眼抓出，实测边界 63% min(RGB)≥235）。
      ② 抗锯齿：GaussianBlur(feather) 只把最外圈那道硬阶梯柔成 1px 软坡 —— 内部仍 255
         （冰块/白标/袋面不透明，绝不透出底色）、外部仍 0，只有边界变斜坡 → 锯齿毛边消失。
    先收后柔的意义：先把发白的脏边收掉，软坡才是从"干净产品色"渐变到透明，不带白圈。
    纯 PIL，不引额外依赖。⚠️ defringe 别设太大（1-2 足够），大了会啃真产品。"""
    for _ in range(max(0, defringe)):
        alpha = alpha.filter(ImageFilter.MinFilter(3))
    if feather and feather > 0:
        alpha = alpha.filter(ImageFilter.GaussianBlur(feather))
    return alpha


def _auto_thresh(im: Image.Image, user) -> int:
    """自动判背景容差，只解决一件事：【背景是均匀的近白灰（245 灰底/淡阴影），默认 min≥249 抠不干净】。
    ⚠️ 必须保守 —— 抬太高会啃白产品（实测 VOLT 喷溅图边框全是浅蓝水花，抬到 30 直接吃穿白袋）。
    三道闸把它锁在"真·干净白底"上，任何一道不过就回默认 6，宁可漏调也不啃产品：
      ① 扫 1px 边框，只取近中性灰像素（max-min≤6）——彩色产品/水花的边被排除；
      ② 近灰像素要占边框绝大多数（≥85%）——否则边框有内容（喷溅/实景），不是干净背景；
      ③ 这些背景像素必须【又白又均匀】：最暗 ≥236 且明暗跨度 ≤12——渐变太大说明是场景不是backdrop。
    过三关才把 thresh 设到刚好覆盖最暗背景（+2 余量、封顶 18）。连通性约束仍在，只影响外部背景。
    用户显式传 --thresh 就完全听用户的。"""
    if user is not None:
        return user
    rgb = im.convert("RGB"); w, h = rgb.size; px = rgb.load()
    total = 2 * w + 2 * h - 4
    grays = []
    def look(x, y):
        r, g, b = px[x, y]
        if max(r, g, b) - min(r, g, b) <= 6:      # 近中性灰 = 候选背景（排除彩色产品/水花边）
            grays.append(min(r, g, b))
    for x in range(w):
        look(x, 0); look(x, h - 1)
    for y in range(h):
        look(0, y); look(w - 1, y)
    if len(grays) < 0.85 * total:                 # ② 边框不是绝大多数近灰 → 有内容，别调
        return 6
    darkest, brightest = min(grays), max(grays)
    if darkest < 236 or brightest - darkest > 12:  # ③ 不够白 / 不够均匀（渐变/场景）→ 别调
        return 6
    t = min(18, max(6, 255 - darkest + 2))
    if t > 6:
        print(f"   ⚙️ 自动容差 thresh={t}（背景均匀近白、最暗 RGB {darkest}）——偏了就显式传 --thresh 覆盖。")
    return t


def _rembg_alpha(im: Image.Image) -> Image.Image:
    try:
        from rembg import remove, new_session
    except ImportError:
        sys.exit("需要 rembg：pip install rembg\n"
                 "（模型 u2net 首次运行会自动下到 ~/.u2net/，本地跑，不上传图）")
    # 模型固定 u2net。isnet-general-use 实测在白罐上几乎全判半透明，不可用。
    # 也别开 alpha_matting：参数极难调，实测直接毁掉输出。
    return remove(im, session=new_session("u2net")).convert("RGBA").split()[3]


def _flood_alpha(im: Image.Image, thresh: int = 6) -> Image.Image:
    """边缘连通 Flood Fill：颜色像背景还不够，必须能从四边走进来才算外部背景。
    这条"连通性"约束是关键——被产品轮廓包住的白色孤岛（标签、高光）会被保住。"""
    rgb = im.convert("RGB"); w, h = rgb.size; px = rgb.load()

    def is_bg(x, y):
        r, g, b = px[x, y]
        return min(r, g, b) >= 255 - thresh and max(r, g, b) - min(r, g, b) <= 5

    seen = bytearray(w * h); bg = bytearray(w * h); q = deque()
    for x in range(w):
        for y in (0, h - 1):
            if is_bg(x, y) and not seen[y * w + x]:
                seen[y * w + x] = 1; q.append((x, y))
    for y in range(h):
        for x in (0, w - 1):
            if is_bg(x, y) and not seen[y * w + x]:
                seen[y * w + x] = 1; q.append((x, y))
    while q:
        x, y = q.popleft(); bg[y * w + x] = 1
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < w and 0 <= ny < h and not seen[ny * w + nx] and is_bg(nx, ny):
                seen[ny * w + nx] = 1; q.append((nx, ny))
    a = Image.new("L", (w, h)); ap = a.load()
    for y in range(h):
        for x in range(w):
            ap[x, y] = 0 if bg[y * w + x] else 255
    return a



def edge_loss_report(src_im: Image.Image, _unused, alpha: Image.Image) -> None:
    """量 rembg 啃掉了多少浅色边缘 —— 让工具自己发现问题，别等人肉眼看。

    原理：源图里【非纯白】的像素就是产品实体（含浅灰侧面/阴影边）。
         如果某处源图有产品、alpha 却近乎 0，那就是被啃了。
    为什么需要它：VOLT 白袋被啃 3.5%，我看蓝底没看出来、看百分比也没看出来
                （半透明比例、bbox 宽度这些指标全是正常的），是红底图才现形。
    """
    rgb = src_im.convert("RGB")
    w, h = rgb.size
    sp, apx = rgb.load(), alpha.load()
    prod = lost = 0
    for y in range(0, h, 3):
        for x in range(0, w, 3):
            r, g, b = sp[x, y]
            if (255 - r) + (255 - g) + (255 - b) > 8:      # 非纯白 = 产品实体
                prod += 1
                if apx[x, y] < 128:
                    lost += 1
    if not prod:
        return
    pct = lost / prod * 100
    print(f"   浅色边缘啃食自检：源图产品像素中有 {pct:.1f}% 被判成了背景")
    if pct > 1.5:
        print(f"   🔴 {pct:.1f}% > 1.5% —— rembg 很可能啃掉了产品的浅色边缘（白袋侧面/浅灰高光）。")
        print( "      实测 VOLT 白袋 rembg 啃 3.5%(右缘丢 11-40px/行)，换 --mode flood 后只丢 4px。")
        print( "      👉 改用 --mode flood 重跑，然后对比两张红底验收图。")


def scan(path: Path) -> None:
    """列扫描找主次包装之间的缝隙。主图3 需要只留主包装时用。"""
    im = Image.open(path).convert("RGB"); w, h = im.size; px = im.load()
    print(f"{path.name}  {w}×{h}   列扫描（每列的非白像素数）")
    cols = []
    for x in range(w):
        n = sum(1 for y in range(0, h, 3) if min(px[x, y]) < 240)
        cols.append(n)
    peak = max(cols) or 1
    for x in range(0, w, max(1, w // 60)):
        print(f"  x={x:4d} {cols[x]:4d} {'#' * int(cols[x] / peak * 46)}")
    gaps, run = [], None
    for x, n in enumerate(cols):
        if n == 0 and run is None: run = x
        if n > 0 and run is not None:
            if x - run > 4: gaps.append((run, x))
            run = None
    # 🔴 必须排除画布左右边缘的空白带：图若带白边，最左/最右那条"缝隙"会被当成候选，
    #    切出 2px 宽的废件。实测踩过。只认落在画面中段的缝。
    gaps = [(s, e) for s, e in gaps if s > w * 0.15 and e < w * 0.9]

    if gaps:
        print("\n候选切点（纯白缝隙中点）：", [f"{(s+e)//2}" for s, e in gaps])
        print("   （已排除画布左右边缘的空白带；实测切点：VOLT 袋+条 x≈949，电解质盒+条 x≈518–525）")
    else:
        print("\n⚠️ 没有纯白缝隙 —— 主次包装是挨着的（rembg 软边会把它们桥接成一块）。"
              "\n   两条出路："
              "\n   ① 找列向【脖子】：不透明高度骤降处即为分界（实测 x=401 处高度 546→107）。"
              "\n      🔴 必须排除锥形尾巴 —— 要求切开后两侧面积均 ≥8% 总面积，"
              "\n         否则程序会把条包尖尾（h=19）当最小值，切在 x=540 等于没切。"
              "\n   ② 脖子也找不到 → 目视定位后按 x 硬切。实测电解质盒+条就是这样定的。")


def verify(cut_path: Path, src_path: Path) -> Path:
    """红底验收图。这是唯一可信的验收方法。

    为什么用红底不用蓝底：品牌蓝会跟产品自身的蓝混在一起看不出破洞，红色跟任何产品色都不撞。
    为什么必须做：全尺寸缩略图一律不作数——肌酸罐白身被啃出洞，全尺寸看"完好"，放大才现形。
    """
    cut = Image.open(cut_path).convert("RGBA")
    src = Image.open(src_path).convert("RGB")
    bg = Image.new("RGBA", cut.size, (255, 0, 0, 255)); bg.alpha_composite(cut)
    out = Image.new("RGB", (cut.width * 2 + 24, cut.height), (240, 240, 240))
    if src.size == cut.size:
        out.paste(src, (0, 0))                      # 未裁剪 → 可同坐标对比
    else:
        out.paste(src.resize(cut.size), (0, 0))
        print("⚠️ 抠图已被裁剪，与源图坐标对不上；对比是缩放后的，只能粗看。"
              "\n   要精确验收请用未裁剪的输出。")
    out.paste(bg.convert("RGB"), (cut.width + 24, 0))
    p = cut_path.with_name(cut_path.stem + "_验收_红底.png")
    out.save(p)
    a = cut.split()[3]; hist = a.histogram(); tot = sum(hist)
    semi = (tot - hist[0] - hist[255]) / tot * 100
    print(f"✅ {p.name}   左=源图  右=抠图贴红底（红色透出来的地方 = 被删掉了）")
    print(f"   半透明像素 {semi:.1f}%")
    if semi < 0.05:
        # 半透明≈0 = 完全硬边、没有抗锯齿。新版 flood 默认带 --feather 会在轮廓留一薄圈半透明，
        # 所以这里≈0 往往意味着 --hard-edge 或 --feather 0；不是错，但边会有锯齿。
        print("   ℹ️ 半透明≈0% = 完全硬边、无抗锯齿（用了 --hard-edge 或 --feather 0）。"
              "\n      · 正常 flood/hybrid 默认会有一薄圈（轮廓抗锯齿），这个 0 说明柔化被关了 → 边可能有锯齿。"
              "\n      · rembg 模式：不正常，rembg 本该产出抗锯齿软边 —— 去查是不是模型没跑对。"
              "\n      另：底部若有不透明白板，正是 hybrid 模式要解决的问题。")
    print("   👉 现在 Read 这张图，放大看：①顶封边有没有被钻洞 ②底部反射/水洼残留 "
          "③边缘白边锯齿 ④产品是否完整。别只看百分比。")
    return p


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("out", nargs="?")
    # 默认 flood：白底产品是最常见的情况，且 rembg 会啃浅色边缘（见文件头实证）。
    # ⛔ 改默认值前先看文件头的四法对比数据：rembg 在 VOLT 白袋上丢 179px，flood 只丢 4px。
    ap.add_argument("--mode", choices=["rembg", "flood", "hybrid"], default="flood")
    ap.add_argument("--seam", nargs=2, type=int, metavar=("Y0", "Y1"), default=[700, 790],
                    help="hybrid 的过渡带：y<Y0 用 Flood Fill(保水花)，y>Y1 用 rembg(杀水洼)")
    ap.add_argument("--thresh", type=int, default=None,
                    help="flood/hybrid 容差。⚠️ 不传则【自动探测背景】（见 _auto_thresh）：纯白底=6，"
                         "灰/渐变底自动抬高到刚好覆盖。⚠️ 冰块/玻璃/浅色高光要【手动调低】：实测冰块棱面"
                         "灰阶 249-252、背景 253-255 只差 1-6 级，自动值可能把冰块一起吞 → 显式传 --thresh 2。")
    ap.add_argument("--defringe", type=int, default=1, metavar="PX",
                    help="去白边：mask 向内收 PX 像素，削掉 flood 二值边那圈抗锯齿白边。"
                         "⚠️ 默认已改为 1（旧版是 0=关，同事那边普遍白边）。1-2 足够，别太大会啃产品。")
    ap.add_argument("--feather", type=float, default=0.8, metavar="R",
                    help="抗锯齿：对边界做 R 像素高斯柔化，消除二值边的锯齿毛边（默认 0.8）。"
                         "内部仍不透明。设 0 = 不柔化（要绝对硬边时用 --hard-edge）。")
    ap.add_argument("--hard-edge", action="store_true",
                    help="保留二值硬边：不去白边、不抗锯齿。仅在确需像素级硬 alpha 的特殊场景用。")
    ap.add_argument("--split", type=int, metavar="X", help="按 x 硬切，只保留左侧主包装（主图3 专用）")
    ap.add_argument("--scan", action="store_true", help="只做列扫描找切点")
    ap.add_argument("--verify", metavar="SRC", help="给已抠好的图生成红底验收图")
    ap.add_argument("--no-trim", action="store_true", help="不裁到 bbox（验收要用未裁剪的）")
    ap.add_argument("--skip-verify", action="store_true",
                    help="跳过自动红底验收。⛔ 除非你在批处理里稍后统一验收，否则别用——"
                         "验收靠人记得跑第二条命令是不可靠的，实测会被跳过。")
    a = ap.parse_args()

    if a.verify:
        verify(Path(a.src), Path(a.verify)); return
    if a.scan:
        scan(Path(a.src)); return
    if not a.out:
        sys.exit("要指定输出路径（或用 --scan / --verify）")

    src = Path(a.src); im = Image.open(src)
    rgba = im.convert("RGBA")

    thresh = _auto_thresh(im, a.thresh)     # 未显式传 --thresh 时自动探测背景容差（灰底/渐变底不再漏）
    if a.mode == "rembg":
        alpha = _rembg_alpha(im)
    elif a.mode == "flood":
        alpha = _flood_alpha(im, thresh)
    else:
        # 缝合前提：两套 alpha 必须同尺寸对齐 —— 所以两边都在整幅上算，都别裁。
        af, ar = _flood_alpha(im, thresh), _rembg_alpha(im)
        y0, y1 = a.seam
        alpha = Image.new("L", rgba.size); ap_ = alpha.load()
        fp, rp = af.load(), ar.load()
        for y in range(rgba.height):
            w_ = 0.0 if y <= y0 else 1.0 if y >= y1 else (y - y0) / (y1 - y0)
            for x in range(rgba.width):
                ap_[x, y] = int(fp[x, y] * (1 - w_) + rp[x, y] * w_)

    # 边缘收尾（去白边 + 抗锯齿）——同事"毛边"投诉的正解。分模式给默认，避免误伤：
    #   · flood：白底产品，默认 去白边 + 抗锯齿（最常见，收益最大）。
    #   · hybrid：水花喷溅，只抗锯齿【不收边】—— 收边会啃掉脆弱的水珠尖端/水花皇冠。
    #   · rembg：本就是软边，只在用户显式传 --defringe 时收边（不叠柔化，免得糊掉它自己的软边）。
    if a.hard_edge:
        pass
    elif a.mode == "flood":
        alpha = _edge_finish(alpha, a.defringe, a.feather)
    elif a.mode == "hybrid":
        alpha = _edge_finish(alpha, 0, a.feather)
    elif a.defringe:
        alpha = _edge_finish(alpha, a.defringe, 0.0)
    rgba.putalpha(alpha)
    if a.split:
        # 主次包装：只留主包装。⛔ 这条规则只用于主图3；主图1/2 产品是主角，次包装能体现剂型。
        rgba = rgba.crop((0, 0, a.split, rgba.height))
    if not a.no_trim:
        bb = rgba.split()[3].getbbox()
        if bb: rgba = rgba.crop(bb)

    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    rgba.save(out)
    hist = rgba.split()[3].histogram(); tot = sum(hist)
    print(f"✅ {out.name}  {rgba.size}  半透明 {(tot-hist[0]-hist[255])/tot*100:.1f}%")

    # rembg 模式下量一次浅色边缘啃食 —— 这正是 VOLT 白袋翻车的病灶，让它自己报出来
    if a.mode == "rembg":
        edge_loss_report(im, rgba if a.no_trim else None, alpha)

    # 红底验收【自动】跑：靠人记得跑第二条命令是不可靠的（实测会被跳过，我自己就跳过了）
    if not a.skip_verify:
        verify(out, src)
    else:
        print(f"   ⚠️ 已跳过自动验收。补跑：python cutout.py {out} --verify {src}")


if __name__ == "__main__":
    main()
