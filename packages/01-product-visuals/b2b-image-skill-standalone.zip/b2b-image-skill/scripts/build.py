#!/usr/bin/env python3
"""把「产品信息表 product.json」+ 模板 → 自包含构建目录，交给出图脚本渲染。

🔴 构建完谁来出图（口径与本文件结尾那段告警一致，别再各说各话）：
  · **带 swap 段（要把真产品换进图）的模块 → 一律 `render_v2.py`**，它渲底图 → 换真产品 →
    锁文案 → 查双影 → 查压字，每一环都挂在退出码上。
  · `render.py` 只出【本来就没有产品要换】的通用件/证书件/工厂件（⚙️备选纯渲染）。
    ⛔ 别拿它出带产品的模块 —— 那只渲底图，产品还是占位件，双影/压字一个都不查。

为什么要构建目录而不是直接改模板：
  · 模板里的路径若指向项目各处（../fonts、../real-factory），换台机器就全断。
    构建目录把用到的字体和图片都拷进来，内部全是相对路径，从任意根目录起服务都能跑。
  · 10 款产品共用同一批模板，直接改模板 = 改一款毁一款。

产出:
    <out>/
      m1.html … m7.html     已填好文案与布局
      _brand.css _font.css
      fonts/poppins/*.ttf
      img/*                 product.json 里引用到的图片

用法:
    python build.py product.json -o build/
    python build.py product.json -o build/ --only m1
"""
import argparse, html as _htmllib, json, os, re, shutil, subprocess, sys, zlib

from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （必须 import：修 Windows 管道输出下 emoji 崩溃）
try:
    from check_white_bg import scan as _wb_scan   # 白底检查：元素件/产品图该透明却白底 → 返工
except Exception:
    _wb_scan = None

# 🔴 白底守卫（2026-07-31 新增）：这些槽是【产品/场景元素抠图件】，落在彩色模块底上必须透明，
# 否则会贴出白方块（胶原果冻条 m1 石榴翻车）。只查这些槽，避开证书/徽章/整幅照片槽（那些白底正常）。
CUTOUT_SLOT_RE = re.compile(r"(^|_)(main|second|scene|product|anchor)$")
WHITE_BG_OK_MODULES: set = set()   # 国际站无【白底主图】模块；国内 skill 这里含 s5（白底实拍）。

SKILL = Path(__file__).resolve().parent.parent
TPL = SKILL / "assets" / "templates"
FONTS = SKILL / "assets" / "fonts" / "poppins"
LIB = SKILL / "assets" / "library"

TEMPLATE_FILES = {
    # 主图 7 图（1000×1000）
    "m1": "m1-brand-hero.html", "m2": "m2-pain-hook.html", "m3": "m3-your-brand.html",
    "m4": "m4-cert-wall.html", "m5": "m5-factory.html", "m6": "m6-process.html",
    # m7 = 营养成分表 / 参考配方展示位（Bowen 2026-08-09 定，主图 6→7）。
    # 卖的是【代工厂的配方能力】，不是"这瓶货"，所以表格上下要按 mode 挂 compliance.md §3.5 的免责。
    # 纯 HTML 矢量件：product.json 里⛔不写 swap 段。🔴🔴 绝不许让 gen_image --scene 碰它 ——
    # 一张全是数字的表交给 AI 重绘 = 必然出假数据（实测史：20g Sachet→Saciet、钾 22→23）。
    # 数据由 facts_html() 从 m7.facts 段渲染，构建前先过 check_facts.py 硬闸门（见 run_check_facts）。
    "m7": "m7-supplement-facts.html",
    # 详情页 12 块（核心 8 + 4 附加件，宽 750，高度锁死在各模板里，见 references/detail-page.md）
    # 🔴 完整出图一律 `--detail-all`；别只出 d1..d9（那会漏掉 df/dfac/dc/drev = "只出 9 图"的根因）。
    "d1": "d1-hero.html", "d2": "d2-benefits.html", "d3": "d3-formula.html",
    # d4 = Customized Packaging 网格（复刻老板线上图 素材/详情页04.jpg，品牌化 VI）。
    # 旧的 d4-custom.html（ONE-STOP CUSTOMIZATION 三品版）保留在 templates/ 里未删，如需回退改回即可。
    "d4": "d4-packaging.html", "d5": "d5-certs.html", "d6": "d6-factory.html",
    "d7": "d7-service.html", "d8": "d8-record.html", "d9": "d9-cta.html",
    # 第 10 件【附加通用展示件】：Multi-Format Project Support（8 格剂型网格）。
    # key 用 "df" 不用 "d5"（d5 已是认证）也不用 "mf"（会被 startswith("m") 误判成主图）。
    # 已进完整 12 块序列（--detail-all 会出）；只是不进【裸默认】，补渲单张时用 `--only df`。
    "df": "d5-multiformat.html",
    # 详情页07【附加通用件】：工厂车间实拍拼图（20 格），品牌蓝底+圆角白卡，无文案。
    # key 用 "dfac"（不与 d7=八步 撞号），不进默认序列，用 `--only dfac` 单独出。
    "dfac": "d-factory-gallery.html",
    # 【附加通用件】：Genuine Smiles 客户合影墙（去背照片叠蓝底 + HTML 品牌标题）。
    # key "dc"（customers，不占 d8=证言数据）。排版建议插在 d8 上方。
    "dc": "dc-customers.html",
    # 【附加通用件】：真实买家评价（照国内 t13；数据源《评论.xls》）。key "drev"（reviews）。
    # 6 条逐字英文评价 + 首字母圆头像 + 真实后台截图。排版建议插在 d8/d9 附近。
    "drev": "d-reviews.html",
}

# 【附加通用展示件】—— 不计入核心 8 块（d1-d7,d9）合计，但属于完整 12 块交付；写死内容+库素材。
EXTRA_DETAIL = {"df", "dfac", "dc", "drev"}

# 🔴 详情页【完整交付序列】= 核心 8 块 + 4 附加件，共 12 块，按内容叙事排序
# （出处 detail-page.md 开头的「完整交付 = 12 块，不是 9 块」和「完整推荐序（12 件）」，
#   Bowen 2026-07-28 定）。d8 已并入 drev，不在序列里。
# 附加件（df/dfac/dc/drev）不点名就静默不出——同事漏板块的根因就是这个，
# 所以给一条唯一正确的命令 `--detail-all`，一次把 12 块全构建，别再手抄 12 个 key。
DETAIL_FULL = ["d1", "d2", "d3", "d4", "df", "d5", "d6", "dfac", "d7", "dc", "drev", "d9"]

# 带【逐产品替换的产品图】的详情页模块 —— 出图后要自动跑 check_layout.py 查产品没压到文字。
# 判据（改这个集合前先按这两条逐个核一遍，⛔ 别凭印象加减）：
#   ① 模板里有产品图槽（{{IMG_*_MAIN}} 这类占位，不是写死的库素材路径）；且
#   ② product/detail json 里有对应 images 项 + swap 段（说明这张图是逐产品换的）。
# 逐条核过（2026-08-18）：
#   d1 Hero 右侧产品 ✅（IMG_D1_MAIN + swap.subject）
#   d2 Key Ingredients 左侧浅蓝卡里的产品 ✅（IMG_D2_MAIN + swap.subject/hide）
#      —— 🔴 旧版这里漏了 d2，注释还断言"其余模块没有逐产品的产品图"，对 d2 是错的。
#   d3 痛点右栏悬浮产品 ✅（IMG_D3_MAIN + swap.subject）
# 不在集合里的：d2_ing1~3 是成分徽章、d6_line/equip/building 是工厂实拍（都无 swap，
# 且不是产品本体）；d4/d5/df/dfac/dc/drev 走 GENERIC_ASSETS 写死的库素材；d7/d8/d9 无图。
PRODUCT_DETAIL = {"d1", "d2", "d3"}

# 公司通用展示件的图片是【写死进模板、全店复用】的库素材（不走 product.json 的 images 段）。
# key → (assets/library 下的子目录, 构建目录里的目标目录名/也是模板里 img src 的前缀)。
# build 时按需把整目录 png 拷进构建目录，模板才能独立渲染（否则 icons/ photos/ 会 404）。
GENERIC_ASSETS = {
    "m5": ("factory-main", "fac4"),        # 主图05 工厂实力：2×2 真实车间拼图（研发/质检/生产/包装，全店复用）
    "d4": ("packaging-types", "icons"),    # Customized Packaging 的 9 张包材图
    "d5": ("cert-wall", "certs"),          # 真实脱敏证书墙 5 张（2026-07-27 从图标版改真证书）
    "df": ("dosage-formats", "photos"),    # Multi-Format 的 8 张剂型照片
    "dfac": ("factory-gallery", "gallery"),  # 详情页07 工厂拼图（1 张，模板写死引用 gallery/）
    "dc": ("customer-wall", "cwall"),        # 客户合影墙（1 张去背照片层 overlay.png，模板引用 cwall/）
    "drev": ("review-shots", "shots"),       # 真实买家评价的 3 张后台截图（模板引用 shots/）
}

# 详情页各模块的画布高度 —— 【实测老板模板样图 image30-32 得来，锁死】。
# render.py 出图时要传 --size 750x<H>；高度不对会把内容裁掉或留死白。
# ⛔ 别改这些数：它们是逐段量老板模板 + 逐张贴合内容收出来的，改一个就跟模板对不上。
DETAIL_HEIGHTS = {
    "d1": 432, "d2": 470, "d3": 476, "d4": 624, "d5": 486,   # 2026-07-23/27 Bowen 改版：d1 询盘CTA+产品放大；d2 Key Ingredients；d3 产品痛点介绍；d4 副标题+国内包装素材；d5 350→486 图标版→真实脱敏证书墙(5证+底部4保障)
    "d6": 420, "d7": 310, "d8": 300, "d9": 420,   # d6 452→420：原底部 60px 死白，见模板注释
    "df": 620,   # 附加件 Multi-Format（白底版，+底部亮绿CTA胶囊），不计入核心 3638 合计
    "dfac": 523, # 附加件 详情页07 工厂拼图（750×510 源图 + 一圈12px蓝边+8px卡内边），不计入核心 3638
    "dc": 647,   # 附加件 客户合影墙（原图 1254×1081 → 750 宽等比），不计入核心 3638
    "drev": 876, # 附加件 真实买家评价（顶部店铺数据条[合并自d8] + 6 卡 + 后台截图块）。2026-07-28 并入 d8 后 792→876
}   # 核心 d1-d7,d9 合计 3638（d8=300 已废并入 drev，不计入）。改版实值：d1 432 · d2 470 KeyIngredients · d3 476 痛点介绍 · d4 624 · d5 486 真证书墙


def layout_css(layout: dict) -> str:
    """把 product.json 的 layout 段翻译成 CSS。

    为什么布局要逐产品填而不是写死在模板里：每款产品的抠图长宽比都不同，
    同一组 height/left/bottom 换个产品就会溢出画布或压住产品自己的角标。
    数值该由做这张图的 subagent 按实际素材算出来，规则见 references/main-images.md。
    """
    out = []
    for sel, props in layout.items():
        if sel.startswith("_") or not isinstance(props, dict):
            continue                                   # 以 _ 开头的是注释/验算，不是选择器
        body = ";".join(f"{k}:{v}" for k, v in props.items() if not k.startswith("_"))
        if body:
            out.append(f".{sel}{{{body}}}")
    return "\n".join(out)


# ── m7 营养成分表 ────────────────────────────────────────────────────────────
# 🔴 两条免责【逐字】来自 references/compliance.md §3.5（站上既有写法）。
#    ⛔ 别改一个字、别翻译、别自创第三条：它们是「阿里国际站图禁一切 FDA 内容」的**唯一例外**
#    （copy-compliance.md §2.1），一改就不再是那条被认可的例外文本。
#    ⛔ 也别把它当"阿里图可以加免责"的通行证 —— FDA 免责在阿里图一律不出现。
_DISC_TOP = "Sample formula shown. Ingredients and dosage can be customized."
# 🔴 real 档（本款【真实】配方）**不许**印 "Sample formula shown." —— 那是句谎话，
#    而这张表的全部价值就在"数字是真的"。§3.5 那两条是为【样例配方】写的，real 档不适用。
#    但"可定制"是事实、也是我们要说的卖点，所以 real 档只留后半句。
#    ⛔ 别为了"统一"把 real 也挂上整条 —— 真实配方标成样例 = 对买家撒谎，比不挂更糟。
_DISC_TOP_REAL = "Ingredients and dosage can be customized."
_DISC_BOTTOM = (
    'Note: This formula image is a "sample formula presentation," not an official U.S. '
    "Supplement Facts label. An official label must be recalculated based on the final formula, "
    "target market regulations, actual ingredient specifications, and nutrition databases."
)
# json 里统一写 ug（好敲、不怕编码），渲染成 µg。⛔ 别在信息表里直接写 µg/mcg。
_FACTS_UNITS = {"mg": "mg", "g": "g", "ug": "µg", "IU": "IU"}
_FACTS_MODES = ("real", "sample", "demo")
_DV_FOOTNOTE = "† Daily Value not established"

CHECK_FACTS = SKILL / "scripts" / "check_facts.py"


def _num(v) -> str:
    """数字转字符串：把 5000.0 印成 5000，别在成分表上印出多余的 .0。"""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def facts_html(facts: dict) -> dict:
    """把 product.json 的 m7.facts 段翻译成 m7 模板要的几个字符串。

    为什么不写死在模板里（同 layout_css 的理由）：
      · **行数可变** —— 一款 8 行、一款 14 行。build.py 只做 `{{K}}` 字符串替换、不支持循环，
        所以整段 `<tr>` 只能在这里拼好，再塞进 `{{FACTS_TABLE}}`。
      · **免责按 mode 挂** —— 写死进模板就等于"每张都印"，`real` 档不该印下条；
        而这两条又必须逐字等于 compliance.md §3.5，放在这一处才改不散。
      · 10 款产品共用同一个 m7 模板，任何逐产品差异写进模板 = 改一款毁一款。

    🔴 **%DV 不在这里算** —— 由 check_facts.py 按 assets/schemas/dv_table.json 算完、回填 row["dv"]。
       本函数只负责渲染：`dv` 有值 → `xx%`，没值 → `†`（并让脚注出现）。
       ⛔ 别在这里补一套 DV 计算：两处算法必然漂移，而图上印的是哪一套没人分得清。

    ⚠️ 不做 HTML 转义 —— 与本 skill 既有约定一致：信息表里的 & 由填表人直接写成 `&amp;`
       （见 product.example.json 的 m2/m3 文案）。这里再转义一次会在图上印出 `&amp;amp;`。

    返回的 key 就是模板占位符名：FACTS_TABLE / SERVING_SIZE / SERVINGS /
    OTHER_INGREDIENTS / DISCLAIMER_TOP / DISCLAIMER_BOTTOM。
    """
    if not isinstance(facts, dict) or not facts:
        sys.exit("m7 缺 facts 段：m7 是营养成分表，没有 facts 就没有可印的数据。\n"
                 "  照 assets/schemas/product.example.json 的 m7.facts 填（mode/serving_size/"
                 "servings_per_container/rows/other_ingredients）。")

    mode = str(facts.get("mode", "")).strip()
    if mode not in _FACTS_MODES:
        sys.exit(f"m7.facts.mode 必须是 {' / '.join(_FACTS_MODES)} 之一，当前 = {facts.get('mode')!r}\n"
                 "  real  = 品牌模式 + 本款真实配方可核实\n"
                 "          图上只挂 'Ingredients and dosage can be customized.'；\n"
                 "          ⛔ 不挂 'Sample formula shown.' —— 真实配方印「样例」就是谎话\n"
                 "  sample= 对标/参考配方（含从竞品标签取的成分名+剂量）→ 必挂两条免责\n"
                 "  demo  = 商标成分被 Bowen 拒绝后的降级（成分名换品类通用名，纯版式演示）")

    # rows 里以 _ 开头的键是注释；整条全是注释键的行直接跳过（与 layout_css 的口径一致）
    rows = [r for r in facts.get("rows", []) or []
            if isinstance(r, dict) and any(not str(k).startswith("_") for k in r)]
    if not rows:
        sys.exit("m7.facts.rows 是空的：不出空表。取数顺序见 references/compliance.md §3.5，"
                 "四条路都走不通就问 Bowen，⛔ 不许填空、更不许编。")

    trs, need_footnote = [], False
    for i, row in enumerate(rows, 1):
        name = str(row.get("name", "")).strip()
        unit = str(row.get("unit", "")).strip()
        source = str(row.get("source", "")).strip()
        amount = row.get("amount", None)
        if not name:
            sys.exit(f"m7.facts.rows[{i}] 缺 name（成分名）。")
        if amount is None or str(amount).strip() == "":
            sys.exit(f"m7.facts.rows[{i}]（{name}）缺 amount（剂量）。")
        if unit not in _FACTS_UNITS:
            sys.exit(f"m7.facts.rows[{i}]（{name}）unit = {unit!r} 非法，只能是 "
                     f"{' / '.join(_FACTS_UNITS)}（µg/mcg 在 json 里统一写 ug）。")
        if not source:
            # 「无源就问 Bowen，不许填空」是 skill 铁律；营养成分表是最不能没出处的地方。
            sys.exit(f"m7.facts.rows[{i}]（{name}）缺 source（出处）。\n"
                     "  每行必须写清这个数从哪来（产品链接主图的 SF / 站上同类主图 / 亚马逊对标品 / Bowen 提供）。\n"
                     "  ⛔ 空串 = 硬失败，别为了让脚本跑通去删这个字段。见 references/compliance.md §3.5。")

        # dv 由 check_facts.py 回填：有值渲染成 xx%，没值渲染 †（并让脚注出现）。
        # ⛔ 脚注别无条件印死 —— 一行都不缺 DV 时印出来就是句没来由的话。
        # check_facts.py 回填的格式是 "11%"（算得出）或 "†"（无 DV，如植物提取物/氨基酸）。
        # 🔴 三种「没有 DV」的写法都要接住：缺字段 / 空串 / 已经是 †。
        #    ⛔ 别无脑给非空值补 "%" —— 回填成 "†" 时会印出 `†%`，且脚注不出现（实测踩过）。
        dv_raw = row.get("dv", None)
        dv_txt = "" if dv_raw is None else str(dv_raw).strip()
        if dv_txt in ("", "†", "*", "-", "—"):
            dv_txt, need_footnote = "†", True
        elif not dv_txt.endswith("%"):
            dv_txt = _num(dv_raw) + "%"

        note = str(row.get("note", "")).strip()          # note 可空（_allow_empty 白名单口径）
        note_html = f'<span class="note">{note}</span>' if note else ""
        trs.append(f'<tr><th class="ing">{name}{note_html}</th>'
                   f'<td class="amt">{_num(amount)} {_FACTS_UNITS[unit]}</td>'
                   f'<td class="dv">{dv_txt}</td></tr>')

    if need_footnote:
        trs.append(f'<tr class="fnote"><td colspan="3">{_DV_FOOTNOTE}</td></tr>')

    _check_row_count(len(trs), len(rows), need_footnote)

    serving = str(facts.get("serving_size", "")).strip()
    servings = facts.get("servings_per_container", None)
    if not serving or servings is None or str(servings).strip() == "":
        sys.exit("m7.facts 缺 serving_size / servings_per_container："
                 "少了这两行，表格就不是一张 Supplement Facts。")

    return {
        "FACTS_TABLE": "\n        ".join(trs),
        "SERVING_SIZE": serving,
        "SERVINGS": _num(servings),
        # other_ingredients 允许为空（有些剂型确实没有）；模板用 :empty 把整行藏掉，不会露出光秃秃的标签。
        "OTHER_INGREDIENTS": str(facts.get("other_ingredients", "") or "").strip(),
        # real = 只挂后半句（⛔ 不含 Sample formula shown.，见 _DISC_TOP_REAL）；sample / demo = 两条都挂
        # real = 本款真实配方 → 只说"可定制"，⛔ 不印 "Sample formula shown."（见 _DISC_TOP_REAL 注释）
        "DISCLAIMER_TOP": _DISC_TOP_REAL if mode == "real" else _DISC_TOP,
        "DISCLAIMER_BOTTOM": "" if mode == "real" else _DISC_BOTTOM,
    }


# ── m7 行数守卫（P1-6，2026-08-09 实测定档）─────────────────────────────────────
# 🔴 为什么必须有这一关：模板注释一直写着"上限 14 行"，但**没有任何代码守着**，
#    超了不报错、不裁剪，只是**安静地毁图**——build / render / qc 三关全 exit 0。
#
# 度量口径 = **tbody 实际渲染行数**（数据行 + † 脚注行），⛔ 不是 rows 长度：
#    脚注行是 facts_html 按"有没有行算不出 DV"动态加的，它一样占一行高度。
#    实测证明这个口径是对的：17 条数据行【带】脚注 = 18 行 → 坏；同样 17 条数据行
#    【去掉】脚注 = 17 行 → 完好。所以撑破画布的是渲染行数，不是数据条数。
#
# 2026-08-09 逐档实测（1000×1000，example 的 12g 条包表，note 全部单行）：
#    17 行（16 数据 + 脚注）→ 完好，但脚注行已经贴死 Other Ingredients，肉眼看不出余量
#    18 行（17 数据 + 脚注）→ 🔴 `† Daily Value not established` 与 `Other Ingredients:` **相撞**
#    19 行（18 数据 + 脚注）→ 🔴 整条成分行被 Other Ingredients 盖住
#    23 行（22 数据 + 脚注）→ 🔴 溢出面板、压掉底部 §3.5 免责、最后几行直接裁出画布
#
# 阈值：>14 告警（模板注释里那条"上限 14 行"的出处，14 行时还很舒展）；
#      >16 硬失败 —— 17 行虽然实测还完好，但**零余量**：任何一个成分名折行、
#      other_ingredients 长一点，就会掉进 18 行那档。留一行缓冲是这里唯一负担得起的做法。
# ⛔ 别加 `_allow_rows` 之类的放行开关：这一关拦下的后果是"图看着正常其实毁了"，
#    有开关就一定会被人顺手打开（本 skill 反复在治的正是这个）。要出 20 行就拆两张。
_ROW_WARN = 14
_ROW_FAIL = 16


def _check_row_count(n_tr: int, n_rows: int, has_footnote: bool) -> None:
    detail = f"{n_rows} 条成分行" + ("（+1 行 † 脚注）" if has_footnote else "（无 † 脚注）")
    if n_tr > _ROW_FAIL:
        sys.exit(
            f"❌ m7 行数超限：表格要渲 {n_tr} 行（{detail}），上限 {_ROW_FAIL} 行。\n"
            f"  🔴 这一关拦的是【静默毁图】：超过上限不会报错也不会裁剪，只会把 "
            f"「† Daily Value not established」/「Other Ingredients:」/ 底部那条 §3.5 免责\n"
            f"     一层层压在一起，最后整行溢出画布 —— build / render / qc 三关全都 exit 0，人看图才发现。\n"
            f"     （2026-08-09 实测：18 行脚注与 Other Ingredients 相撞；19 行盖住成分行；23 行压掉免责并裁出画布。）\n"
            f"  改法（按推荐顺序，⛔ 别改模板字号硬塞）：\n"
            f"    ① 合并次要成分：把几味小剂量植提合成一行 blend（正是标签的常规写法，也更好看）；\n"
            f"    ② 砍掉与卖点无关的行 —— m7 卖的是【配方能力】，不是把料表抄全；\n"
            f"    ③ 真要全列 → 拆成两张（如 m7 主表 + 一张附加表），每张各自 ≤{_ROW_FAIL} 行；\n"
            f"    ④ 实在要缩字号：改 assets/templates/m7-supplement-facts.html 的 "
            f".ing/.amt/.dv（18px）与 .note（14px），\n"
            f"       ⛔ 改完必须把 14/16/17/18 四档重渲一遍看图确认，别只看脚本 exit 0。"
        )
    if n_tr > _ROW_WARN:
        print(f"   ⚠️ m7 行数偏多：{n_tr} 行（{detail}），舒展上限 {_ROW_WARN} 行、硬上限 {_ROW_FAIL} 行。")
        print(f"      仍会出图，但余量很小：成分名一旦折行就可能撞上 Other Ingredients。"
              f"出图后**逐行看图**确认脚注和 Other Ingredients 没叠在一起。")


# ── m7 上图文案的 FDA / 高危词闸门（P0-2，2026-08-09 新增）────────────────────
# 🔴 为什么非要接这根线：「阿里国际站图禁一切 FDA 内容」是硬红线，但在 m7 上此前**零闸门** ——
#    check_facts.py 只管数字与成分，verify_copy.py 全流水线**没有任何一处调用**（纯靠人记得跑）。
#    偏偏 m7 的取数决策树第③级明写"从竞品标签取数"，而竞品标签上就印着 FDA 字样和那段 FDA 免责：
#    这是最容易把 FDA 带上图的一张，却唯独它没接线。
#
# ⛔ 词表【不在这里复制一份】—— 直接 import verify_copy 用它的 RULES/scan()。
#    词表已经在 copy-compliance.md / verify_copy.py / check_facts.py 三处同步，再抄一份必漂。
#
# 🔴 扫什么 = **会上图的东西**，两路都扫：
#    ① product.json 的 m7.text.*（H1/SUB）、facts 的 serving_size / rows[].name / rows[].note /
#       other_ingredients；⛔ 不扫 rows[].source（出处是给人看的审计信息，不上图，
#       里面本来就会有竞品链接和 "FDA label database" 这类词，扫它 = 制造稳定假警）。
#    ② 渲出来的 m7.html —— 只有它能逮住**模板自己**被人加了字（json 扫不到模板）。
#
# 🔴 假警治理（假警会训练人划过 FDA 告警，而这正是最不能划过的一条）：
#    扫 html 前先抽【可见文本】：剥掉 HTML 注释、<style>/<script>、所有标签。理由 ——
#      · 注释里的 "⛔ 图上禁 FDA 字样" 那句规则本身会稳定命中（选它而不是改注释措辞：
#        注释【永远不会上图】，扫它在原理上就是错的；改措辞只能治这一句，下一个人写注释还会中，
#        而且把规则写成 "F.D.A." 这种躲词的写法反而会让规则变模糊）；
#      · CSS 里三处 `height:100%` 会命中 ⚠️`100%` 规则（同理：CSS 不上图）。
#    再丢掉**纯 %DV 值行**（`100%` / `<1%` / `†`）：那是 check_facts.py 按法规算出来的数据，
#    不是文案，而且一个纯数字行里藏不下任何词。不丢的话每张含维生素的表都稳定打一条 ⚠️。
#
# 判罚：🔴高危 = 硬失败（并把已写出的 m7.html 隔离掉，⛔ 不许留着让 render_v2 捡去出图）；
#      ⚠️告警 / 🟢已同意商标 = 照打不误但不挂退出码（与 verify_copy.py 的严重度口径一致）。
_HTML_COMMENT_RX = re.compile(r"<!--.*?-->", re.S)
_HTML_DROP_RX = re.compile(r"<(script|style)\b[^>]*>.*?</\1\s*>", re.S | re.I)
_HTML_BREAK_RX = re.compile(r"</(td|th|tr|div|p|li|h[1-6])\s*>|<br\s*/?>", re.I)
_HTML_TAG_RX = re.compile(r"<[^>]+>")
# 纯 %DV 值行：`100%` / `<1%` / `†` / `*` —— 数据不是文案
_PURE_DV_RX = re.compile(r"^(?:†|\*+|<\s*1\s*%|\d+(?:\.\d+)?\s*%)$")


def _visible_text(html: str) -> list:
    """把 HTML 抽成【会印在图上的可见文本】行列表（剥注释 / CSS / JS / 标签）。"""
    t = _HTML_COMMENT_RX.sub(" ", html)
    t = _HTML_DROP_RX.sub(" ", t)
    t = _HTML_BREAK_RX.sub("\n", t)
    t = _HTML_TAG_RX.sub(" ", t)
    t = _htmllib.unescape(t)
    out = []
    for line in t.splitlines():
        line = re.sub(r"\s+", " ", line).strip()
        if not line or _PURE_DV_RX.match(line):
            continue
        out.append(line)
    return out


def _m7_copy_gate(spec_m7: dict, html_path: Path) -> None:
    """m7 上图文案闸门：命中高危词（FDA / 疾病宣称 / 错误认证 / 专利成分 / organic）→ 硬失败。"""
    try:
        import verify_copy as _vc          # ⛔ 别复制词表，就用它的
    except Exception as e:
        _m7_quarantine(html_path.parent, "文案闸门跑不成")
        sys.exit(f"❌ m7 文案闸门跑不起来：import verify_copy 失败（{type(e).__name__}: {e}）\n"
                 "  🔴 跑不成【绝不当通过】—— m7 是最容易把 FDA 字样从竞品标签带上图的一张。\n"
                 "  修：确认 scripts/verify_copy.py 在（它和 build.py 同目录）。")

    # 🔴 归一化直接用 `_vc._norm_tm` —— 它自 I-77（2026-08-17）起**就是** `check_facts.norm_tm`
    #    本尊（权威版：先摘 ® ™ (R) （R) 再比）⇒ 与比对另一侧（命中词，来自 TRADEMARK_PATS
    #    的正则、本就不含符号）两边都落在 "ksm66" 上，对得齐。
    #    ⛔ 别再在这里 import check_facts 兜一手：那个 try/except 是**分叉年代的补丁**，
    #    源头修好之后它只会掩盖下一次分叉（真分叉了这里静默走旧版，谁都看不见）。
    _norm_tm = _vc._norm_tm
    facts = spec_m7.get("facts") or {}
    approved = {_norm_tm(x) for x in (facts.get("trademark_ok") or [])
                if isinstance(x, str) and _norm_tm(x)}

    entries = []   # (来源标签, 单行文本)
    for k, v in (spec_m7.get("text") or {}).items():
        if not str(k).startswith("_") and isinstance(v, str):
            entries.append((f"m7.text.{k}", v))
    if isinstance(facts.get("serving_size"), str):
        entries.append(("m7.facts.serving_size", facts["serving_size"]))
    for i, row in enumerate(facts.get("rows") or []):
        if not isinstance(row, dict):
            continue
        for f in ("name", "note"):
            if isinstance(row.get(f), str) and row[f].strip():
                entries.append((f"m7.facts.rows[{i}].{f}", row[f]))
    if isinstance(facts.get("other_ingredients"), str):
        entries.append(("m7.facts.other_ingredients", facts["other_ingredients"]))
    for line in _visible_text(html_path.read_text(encoding="utf-8")):
        entries.append((f"{html_path.name}（渲出的可见文本）", line))

    text = "\n".join(t.replace("\n", " ") for _, t in entries)
    hits = _vc.scan(text, frozenset(approved))

    highs, warns, oks, seen = [], [], [], set()
    for sev, cat, term, lineno, _line in hits:
        where = entries[lineno - 1][0] if 0 < lineno <= len(entries) else "?"
        key = (sev, cat, term.lower(), where)
        if key in seen:
            continue
        seen.add(key)
        (highs if sev == "high" else oks if sev == "ok" else warns).append((cat, term, where, entries[lineno - 1][1]))

    for cat, term, where, line in oks:
        print(f"   🟢 [{cat}]「{term}」{where} —— 已在 m7.facts.trademark_ok 里（Bowen 同意），不判高危。")
    for cat, term, where, line in warns:
        print(f"   ⚠️ [{cat}]「{term}」{where}：{line[:70]}")
    if not highs:
        print(f"   ✅ m7 上图文案扫描通过（{len(entries)} 处文案，词表来自 verify_copy.py）"
              + (f"，⚠️ 告警 {len(warns)} 条（不挂退出码，人工看一眼）" if warns else ""))
        return

    _m7_quarantine(html_path.parent, "上图文案命中高危词")
    print("\n❌ m7 上图文案命中【高危】词 —— 这些字会原样印在主图上：")
    for cat, term, where, line in highs:
        print(f"   🔴 [{cat}]「{term}」 出现在 {where}")
        print(f"       {line[:100]}")
    sys.exit(
        "\n  🔴 阿里国际站出图【禁任何 FDA 内容】（copy-compliance.md §2.1）："
        "不写 FDA 免责、不写 FDA registered / approved、认证墙也要去掉 FDA 证。\n"
        "  ⚠️ m7 尤其容易中招：取数决策树第③级是【从竞品标签取数】，"
        "而竞品标签上就印着 FDA 字样和它那段 FDA 免责 ——\n"
        "     从竞品那里【只抄成分名和剂量】，宣称词 / FDA 字样 / 认证标一个不抄"
        "（compliance.md §3.5 + copy-compliance.md §3.1『出处≠豁免』）。\n"
        "  图上唯一允许的免责，是 build.py 按 mode 自动注入的 §3.5 那两条，⛔ 别在 text/facts 里手写第三条。\n"
        "  改完重跑 build。（本次 m7.html 已隔离，⛔ 不会留下上一版残留冒充本次产出。）"
    )


# ── m7 残留件隔离（P0-1，2026-08-09 新增）────────────────────────────────────
# 🔴 增量构建才是常态（契约禁 `rm -rf build/`），所以"闸门停机 = 没有 m7.html"这句话
#    在增量下是**假的**：上一版合格的 m7.html 还躺在构建目录里。实测链路 ——
#      build1/ 已有合格 m7.html → product.json 加了个 KSM-66 → build.py 退出码 3 停机、
#      不重写 m7.html → `render_v2 --modules m7` 拿【旧】m7.html 渲出成品图并报「✅ 出图 1/1」，零提示。
#    更糟的是 render_v2 判"默认要不要带 m7"就是看 `build/m7.html` 在不在 → 残留件会被**默认**带进 7 张。
# 所以：只要这一轮【打算构建 m7】，就先把上一版挪成 m7.html.stale；构建真正成功时才写回 m7.html
#    并把 .stale 删掉。任何一条失败路径（check_facts 1/2/3、行数超限、文案高危、图片缺失…）
#    走完之后，构建目录里都【不会】有 m7.html。
# ⛔ 别改成"失败时才删"：失败路径有十几条（好几条是 sys.exit 直接走人），挨个补必漏；
#    "先挪走、成功再写回"是唯一漏不掉的写法。
_M7_STALE = "m7.html.stale"


def _m7_quarantine(out: Path, why: str) -> None:
    """把构建目录里已有的 m7.html 挪成 m7.html.stale，并说明原因。"""
    cur = out / "m7.html"
    if not cur.exists():
        return
    stale = out / _M7_STALE
    try:
        if stale.exists():
            stale.unlink()
        cur.rename(stale)
    except OSError:
        try:
            cur.unlink()
        except OSError:
            pass
    print(f"   🧹 已把上一版 m7.html 挪走 → {_M7_STALE}（原因：{why}）")
    print(f"      🔴 这样即使本次 m7 没产出，render_v2 也【拿不到旧图】"
          f"—— 残留件冒充本次产出是最难发现的错图。")


def run_check_facts(spec_path: Path) -> None:
    """m7 的**硬闸门**：构建前先跑 check_facts.py（%DV / 单位 / source / 商标成分）。

    为什么走子进程而不是 import：check_facts.py 是独立可跑的校验器，**退出码就是它的对外契约**
    （0 通过 · 1 数据错 · 2 没跑成 · 3 需要 Bowen 答复），import 进来会把这套码吞掉。
    ⛔ 也**不捕获它的输出** —— 商标停机横幅要【原样】流到用户眼前；转述一次就走样。
    """
    if not CHECK_FACTS.exists():
        sys.exit(
            "❌ m7 构建被拦下：找不到校验器\n"
            f"     {CHECK_FACTS}\n"
            "  m7 是【营养成分表】，整张图全是数字（剂量 / %DV）。没过 check_facts.py 就出图 = "
            "把没校验过的法规数字印在主图上。\n"
            "  ⛔ 这里【绝不静默跳过】—— 「校验缺失 → 静默放行 → 图上印错数据」正是本 skill 反复在治的病。\n"
            "  缺的是：scripts/check_facts.py（它还要读 assets/schemas/dv_table.json）。\n"
            "  修：把这两个文件补齐；确实暂时不出 m7，就从 --only 里去掉 m7（别把闸门注释掉）。"
        )

    print(f"🔎 m7 营养成分表校验：{CHECK_FACTS.name} {spec_path.name}")
    # 🔴 必须 flush：管道输出时父进程的 print 是带缓冲的，不 flush 的话子进程的横幅会
    #    抢在这行【前面】打出来 —— 停机横幅看着像凭空冒出来的，人会以为是别的脚本报的。
    sys.stdout.flush()
    try:
        # 不接管 stdout/stderr → 子进程直接往用户终端写，横幅逐字透传
        code = subprocess.run([sys.executable or "python3", str(CHECK_FACTS), str(spec_path)]).returncode
    except OSError as e:
        sys.exit(f"❌ check_facts.py 跑不起来：{e}\n"
                 "  🔴 跑不成【绝不当通过】（这正是退出码 2 存在的意义）。先把它跑通。")

    if code == 0:
        print("   ✅ 营养成分表校验通过")
        return
    if code == 3:
        # 需要人答复。横幅已由子进程原样打出，这里只补"接下来怎么办"，不复述、不改写。
        print("\n⛑️ 上面是 check_facts.py 的【停机横幅】，原样透传、未做任何改写。")
        print("   含义：配方里有 ® / ™ / 专利原料商标 → 必须先问 Bowen：全部同意 / 只同意某几个 / 都不同意。")
        print("   · 同意的 → 写进 m7.facts.trademark_ok，并把「Bowen <日期> 同意使用 X」回填 _approved；重跑不再拦。")
        print("   · 都不同意 → m7.facts.mode 降级为 demo（成分名换品类通用名）。")
        print("   ⛔ 别绕过、别替 Bowen 决定、别偷偷删成分名蒙混过去。"
              "（Bowen 2026-08-09 定：同意即可，⛔ 不要求他提供授权方/文件。）")
        sys.exit(3)
    if code == 2:
        sys.exit("❌ check_facts.py 【没跑成】（退出码 2：依赖缺失 / DV 表读不到 之类）。\n"
                 "  🔴 没跑成绝不当通过。先把它跑通，⛔ 别换一条更糙的路绕过去。")
    sys.exit(f"❌ m7 营养成分表校验未过（check_facts.py 退出码 {code}）。\n"
             "  按上面的报错改 m7.facts（剂量 / 单位 / source / DV）后重跑 build。")


def _demo_mode_banner() -> None:
    """mode = demo 的醒目告知。

    契约 §3：这条必须出现在**三处**（build.py 收尾 · render_v2.py 收尾汇总 · SKILL.md QC 清单）——
    只在一处打印，会被出图刷屏淹没，人就当成正常图发出去了。
    ⚠️ ANSI 红只在真终端上加：管道 / Windows cmd 里 `\\033[31m` 会印成 `←[31m` 乱码，反而更难读。
       真正保证"醒目"的是这个框和 🔴，颜色只是加分项。
    """
    try:
        tty = sys.stdout.isatty()
    except Exception:
        tty = False
    red, off = ("\033[1;31m", "\033[0m") if tty else ("", "")
    line = "━" * 66
    print(f"\n{red}{line}")
    print("🔴 m7 已降级为【纯版式演示】(m7.facts.mode = demo)")
    print("   专利/商标成分未获 Bowen 同意 → 成分名已换成品类通用名，")
    print("   表格保留的只是剂量结构与版式，⛔ 不代表任何真实配方。")
    print("   ⛔ 别把这张当【配方能力展示】发给客户或上架。")
    print("   转正路径：拿到 Bowen 同意 → 写进 m7.facts.trademark_ok → mode 改回 sample/real → 重跑 build。")
    print(f"{line}{off}")


# 🔴 单模块并发跑 render_v2 时 idx 恒 0 → 七方全落 8620/8621/8622 互杀（pitfalls §11）。
#   这张表与 SKILL.md Step 3 跑法 B 的派活表**必须逐字一致**，改一处要改两处。
_V2_PORT_BASE = {"m1": 8620, "m2": 8623, "m3": 8626, "m4": 8629,
                 "m5": 8632, "m6": 8635, "m7": 8638}


def _v2_hint(spec: dict, keys: list, spec_path: Path, out: Path) -> None:
    """V2-35① 运行时提示：本次构建里哪些模块有 swap 段 → 出图必须走 render_v2。

    🔴 为什么要有它：文档改对了不等于人和 agent 走对了 —— 他们跟的是终端里
    能复制粘贴的那一行。这段就是把默认路径塞进那个位置。
    """
    v2 = [k for k in keys if isinstance(spec.get(k), dict) and spec[k].get("swap")]
    rv2 = SKILL / "scripts" / "render_v2.py"

    if not v2:
        # 全是通用件（m3–m7 / 详情页通用块）—— 本来就没有产品要换，纯渲染是对的。
        # ⚠️ 但"没写 swap"也可能是【漏填】，所以点名说清楚，别让人以为脚本认可了。
        prod = [k for k in keys if k in ("m1", "m2", "d1", "d2", "d3")]
        if prod:
            print(f"\n🔴 本次构建的 {' '.join(prod)} 是【带产品】的模块，但信息表里**一个 swap 段都没有**。")
            print(f"   ⛔ 不填 swap = 出图时产品仍是【库存占位件】：尺寸对、QC 全绿、图很好看，"
                  f"产品不是这一款，**没有任何脚本会报错**。")
            print(f"   👉 照 assets/schemas/product.example.json 的 m1.swap / m2.swap 填完再出图。")
        return

    print(f"\n🔴 本次构建含 {len(v2)} 个 V2 模块（有 swap 段）：{' '.join(v2)}")
    print(f"   👉 出图请跑 render_v2.py —— 渲底图 → 换真产品 → 锁文案 → 查双影 → 查压字，"
          f"每一环都挂在退出码上：")
    mods = " ".join(v2)
    base = _V2_PORT_BASE.get(v2[0]) if len(v2) == 1 else None
    prefix = f"RENDER_V2_PORT_BASE={base} " if base else ""
    # 🔴 路径要加引号：skill 目录名里有空格（"claude code"），不加引号复制过去必断成两段
    print(f'      {prefix}python "{rv2}" "{spec_path}" "{out}" -o <成品目录> --modules {mods}')
    if base:
        print(f"      （单模块并发派活时端口基数按 SKILL.md Step 3 那张表填，⛔ 别用别人的）")
    print(f"   ⛔ 别单跑 render.py —— 那只渲底图，产品还是占位件，双影/压字一个都不查。")


def build_one(key: str, spec: dict, out: Path, img_map: dict, globals_: dict) -> Path:
    src = TPL / TEMPLATE_FILES[key]
    if not src.exists():
        sys.exit(f"找不到模板 {src}")
    html = src.read_text(encoding="utf-8")

    # 全局字段先铺底（如 MOQ —— 每款不同、但一款之内 d4/d7/d9 三处要一致，填一次即可）。
    # 模块自己的 text 可覆盖同名键。
    fields = dict(globals_)
    # 以 _ 开头的键是【注释/取数依据】，不是字段。信息表里的注释是有价值的（记着这个数从哪来），
    # 所以别为了让脚本跑通去删注释 —— 让脚本跳过它们。
    fields.update({k: v for k, v in spec.get("text", {}).items() if not k.startswith("_")})
    fields["LAYOUT_CSS"] = layout_css(spec.get("layout", {}))
    if key == "m7":
        # 营养成分表：行数可变 + 免责按 mode 挂 → 只能在 python 侧拼好（见 facts_html 的 docstring）
        fields.update(facts_html(spec.get("facts", {})))
    for slot, path in spec.get("images", {}).items():
        if slot.startswith("_"):
            continue
        fields[f"IMG_{slot.upper()}"] = f"img/{img_map[path]}"

    for k, v in fields.items():
        html = html.replace("{{" + k + "}}", str(v))

    left = re.findall(r"\{\{([A-Z0-9_]+)\}\}", html)
    if left:
        # 没填的占位符会原样印在图上（真的发生过），所以在这里硬失败而不是放行
        hint = ""
        if "MOQ" in left:
            hint = ("\n  🔴 MOQ 每款不同：先从该产品的阿里 listing 页取，再和用户确认，"
                    "\n     填在信息表【顶层 globals.MOQ】（如 \"500 units\"），别写死进模板。")
        sys.exit(f"{key}: 占位符没填 → {sorted(set(left))}\n"
                 f"  普通字段填在 {key}.text；全店通用字段（如 MOQ）填在顶层 globals。{hint}")

    p = out / f"{key}.html"
    p.write_text(html, encoding="utf-8")
    return p


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("product_json")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--only", nargs="*", choices=list(TEMPLATE_FILES), help="只构建指定几张")
    ap.add_argument("--detail-all", action="store_true",
                    help="构建【完整详情页 12 块】= 核心 8 + 4 附加件（df/dfac/dc/drev），"
                         "按叙事顺序。出全套详情页就用这个，别手抄 12 个 key（会漏附加件）。")
    a = ap.parse_args()

    if a.detail_all and a.only:
        sys.exit("--detail-all 和 --only 不能同时用：--detail-all 已经是完整 12 块序列。")

    spec_path = Path(a.product_json).resolve()
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    globals_ = {k: v for k, v in spec.get("globals", {}).items() if not k.startswith("_")}
    out = Path(a.out).resolve()
    (out / "img").mkdir(parents=True, exist_ok=True)
    (out / "fonts").mkdir(parents=True, exist_ok=True)

    shutil.copy(TPL / "_brand.css", out / "_brand.css")
    shutil.copy(TPL / "_font.css", out / "_font.css")
    shutil.copy(TPL / "_detail.css", out / "_detail.css")   # 详情页 d1-d9 用；主图不引用，拷了也无害
    if (out / "fonts" / "poppins").exists():
        shutil.rmtree(out / "fonts" / "poppins")
    shutil.copytree(FONTS, out / "fonts" / "poppins")

    # 收集所有被引用的图片，拷进 build/img/，用扁平文件名避免同名冲突
    img_map, seen = {}, {}
    keys = DETAIL_FULL if a.detail_all else (a.only or list(TEMPLATE_FILES))

    # 🔴 存量护栏（P1-8，2026-08-09）：m7 是后加的一张图，⛔ 不许把没有 m7 段的老 product.json 打死。
    #    裸跑 build.py（不带 --only / --detail-all）时 keys 含全部模板 → 老信息表会在 m7 闸门上
    #    以 exit 1 挂掉、一张图都不产，报错还把人往"补 m7 段"引 —— 那是把"新增一张图"变成"存量全线停摆"。
    #    口径与 render_v2 完全一致（它按 build/m7.html 在不在决定默认带不带 m7）：
    #      · 显式点名（--only … m7）→ 闸门照跑，没有 m7 段就是硬错（人是真要出这张）；
    #      · 裸默认 + 信息表里没有 m7 段 → 跳过 m7，其余照常出。
    #    ⛔ 这不是静默降级：下面这行会点名说明跳了什么、怎么才能出。
    if "m7" in keys and not (a.only and "m7" in a.only) and not isinstance(spec.get("m7"), dict):
        keys = [k for k in keys if k != "m7"]
        print(f"ℹ️ 跳过 m7（营养成分表）：{spec_path.name} 里没有 m7 段。"
              "要出 m7 就先按 assets/schemas/product.example.json 补 m7 段（text + facts），"
              "或显式 `--only … m7` 让闸门点名报错。")

    # 🔴 m7 硬闸门：营养成分表要先过 check_facts.py 才准构建（fail fast，别先拷一堆图再挂）。
    #    ⛔ 别加"文件不在就跳过"的兜底 —— 见 run_check_facts 里那段。
    if "m7" in keys:
        # 🔴 P0-1：先把上一版 m7.html 挪走（见 _m7_quarantine 上面那段）。⛔ 别挪到闸门之后 ——
        #    闸门 1/2/3 三个码都是 sys.exit 直接走人，放后面就等于没放。
        _m7_quarantine(out, "本轮要重建 m7，先隔离上一版，构建成功再写回")
        run_check_facts(spec_path)
        # 🔴 跑完必须【重读一遍 product.json】：check_facts.py 会把算好的 %DV 回填进 rows[*].dv，
        #    而上面那份 spec 是【闸门跑之前】的内存快照 —— 不重读的话每一行都会印成 †，
        #    DV 整列静默丢光（图上看着"正常"，最难抓的那种错）。
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
        globals_ = {k: v for k, v in spec.get("globals", {}).items() if not k.startswith("_")}

    for k in keys:
        for slot, path in spec.get(k, {}).get("images", {}).items():
            if slot.startswith("_") or path in img_map:
                continue                                   # _ 开头 = 注释，不是图片路径
            src = (spec_path.parent / path).resolve()
            if not src.exists():
                sys.exit(f"图片不存在: {path}\n  （相对 {spec_path.parent} 解析为 {src}）")
            name = src.name
            if name in seen and seen[name] != src:
                name = f"{len(img_map)}_{src.name}"
            seen[name] = src
            shutil.copy(src, out / "img" / name)
            img_map[path] = name

    # 🔴 白底守卫：产品/场景元素抠图件（main/second/scene/*_main）落在彩色底上必须透明，
    # 白底会现白方块（qc.py 量不出、人工也漏过）。查出即硬失败，逼返工。
    if _wb_scan:
        offenders = []
        for k in keys:
            if k in WHITE_BG_OK_MODULES:
                continue
            imgs = spec.get(k, {}).get("images", {})
            allow = set(imgs.get("_allow_white_bg", []) or [])
            for slot, path in imgs.items():
                if slot.startswith("_") or slot in allow or not isinstance(path, str):
                    continue
                if not CUTOUT_SLOT_RE.search(slot.lower()):
                    continue
                src = (spec_path.parent / path).resolve()
                try:
                    if _wb_scan(src)["verdict"] == "white_bg":
                        offenders.append((k, slot, path))
                except Exception:
                    pass
        if offenders:
            print("❌ 白底检查未过 —— 元素件/产品图该透明却是【白底】，落在彩色模块底上会现白方块，必须返工：")
            for k, slot, path in offenders:
                print(f"   · [{k}.{slot}] {path}")
            print("   修：python scripts/cutout.py 白底图 透明件.png  （或走 V2 --scene 场景替换）")
            print("   看白框：python scripts/check_white_bg.py <该图> --preview")
            print("   确属该留白底 → 在该模块 images 里加 \"_allow_white_bg\": [\"槽名\"] 放行。")
            sys.exit("白底检查失败（新增守卫）：先修上面的图再重跑 build。")

    # 通用展示件（d4/df）的库素材：整目录拷进构建目录（模板里写死引用 icons/ photos/）。
    for k in keys:
        if k not in GENERIC_ASSETS:
            continue
        libsub, dst = GENERIC_ASSETS[k]
        srcdir = LIB / libsub
        if not srcdir.exists():
            sys.exit(f"{k}: 库素材目录不存在 {srcdir}")
        dstdir = out / dst
        if dstdir.exists():
            shutil.rmtree(dstdir)
        dstdir.mkdir(parents=True, exist_ok=True)
        pngs = sorted(srcdir.glob("*.png"))
        if not pngs:
            sys.exit(f"{k}: 库素材目录里没有 png {srcdir}")
        for png in pngs:
            shutil.copy(png, dstdir / png.name)

    built = [build_one(k, spec.get(k, {}), out, img_map, globals_) for k in keys]

    # 🔴 m7 的第二道闸门（P0-2）：文案词。放在【渲出 m7.html 之后】才跑，因为要连模板里
    #    写死的字一起扫（json 扫不到模板）。命中高危 → 隔离 m7.html 并硬失败，⛔ 不留残留件。
    if "m7" in keys:
        print("🔎 m7 上图文案扫描（FDA / 疾病宣称 / 错误认证 / 专利成分，词表来自 verify_copy.py）")
        _m7_copy_gate(spec.get("m7", {}) or {}, out / "m7.html")
        # 两道闸门都过了、m7.html 是本轮真产出 → 清掉隔离出来的上一版，别留个 .stale 让人犯嘀咕
        try:
            (out / _M7_STALE).unlink()
        except OSError:
            pass

    print(f"✅ 构建目录 {out}")
    for p in built:
        print(f"   {p.name}")
    print(f"   img/ {len(img_map)} 张   fonts/poppins/ {len(list((out/'fonts'/'poppins').glob('*.ttf')))} 个字重")

    # 🔴🔴 V2-35① 默认路径提示 —— 必须打在【出图命令之前】。
    #   病历：SKILL.md 顶部处处写「V2 默认」，而这里打出来的、真的会被复制粘贴执行的命令
    #   却是 render.py 合成法 → 走那批的图 swap 段没人填也不报错，尺寸对、QC 全绿、
    #   产品却是库存占位件。判据：声明写在哪不重要，能被执行的命令写的是什么才算数。
    #   ⛔ 别把这段挪到末尾或删掉 —— 终端输出是人和 agent 一定会看到的地方，文档不是。
    _v2_hint(spec, keys, spec_path, out)

    # 直接把出图命令打出来 —— 详情页每张高度都不同，靠人记那些数必然出错
    rp = SKILL / "scripts" / "render.py"
    mains = [k for k in keys if k.startswith("m")]
    details = [k for k in keys if k.startswith("d")]
    if mains:
        # 🔴 主图这条也要带 --port：不带就落默认 8747，正是 pitfalls §11 端口表里
        #    标红「三方混跑必撞」的那个值（详情页脚本早就分了段，主图漏掉就是个不一致的口子）。
        p_main, _ = _script_ports(out)
        print(f"\n⚙️ 备选·纯渲染（只渲底图，⛔ 不换产品、不查双影 —— 默认路径见上）："
              f"\n   python {rp} {out} {mains[0]}.html <输出.png> --port {p_main}")
    if details:
        # 逐张 render 命令（顺序 = keys 的顺序，--detail-all 时即叙事顺序）
        png_dir = out / "png"

        cp = SKILL / "scripts" / "check_layout.py"

        # 🔴 这次构建专属的端口（见 _script_ports 上面那段验算）：⛔ 别让这些命令落回默认
        # 8747/8748 —— 那会和 render_v2（8620–8679）/ 手工并发（8580–8619）同机互杀。
        p_render, p_check = _script_ports(out)

        def render_cmd(py: str, k: str) -> str:
            return (f'{py} "{rp}" "{out}" {k}.html "{png_dir / (k + ".png")}" '
                    f"--size 750x{DETAIL_HEIGHTS[k]} --scale 2 --port {p_render}")

        def check_cmd(py: str, k: str) -> str:
            return (f'{py} "{cp}" "{out}" {k}.html --size 750x{DETAIL_HEIGHTS[k]} '
                    f"--port {p_check}")

        # 打印用 `python`（好读，与文档一致）；脚本用真实解释器（跨平台稳，别赌 python/python3）。
        print(f"\n⚙️ 备选·纯渲染（@2x 高清，高度已按模板锁死）"
              f"—— ⛔ 只渲底图、不换产品、不查双影，默认路径见上：")
        for k in details:
            tag = "  ← 附加通用件" if k in EXTRA_DETAIL else ""
            print(f"   {render_cmd('python', k)}{tag}")
        checked = [k for k in details if k in PRODUCT_DETAIL]
        if checked:
            print(f"   （{' '.join(checked)} 带产品图 → 脚本会自动跟一步 check_layout.py 查没压文字）")

        # 🔴 生成一次性出图脚本（.sh + .bat）：同事跑【一个脚本】就把这次构建的所有详情页出全，
        # 不再手抄命令 —— 手抄一多就漏板块，这正是"详情页不完整"的另一半根因。
        # 带产品图的模块（d1/d2/d3，见 PRODUCT_DETAIL）render 完自动跟一步位置检查，
        # 产品压到文字会在末尾红字告警。
        py = sys.executable or "python"
        _write_render_scripts(out, png_dir,
                              [render_cmd(py, k) for k in details],
                              [check_cmd(py, k) for k in checked])
        print(f"\n   ✅ 已生成一次性【纯渲染】脚本（⚙️ 备选：把上面 {len(details)} 张底图一次出完 + 自动查产品遮挡；"
              f"⛔ 它不换产品、不查双影）：")
        print(f"      macOS/Linux:  bash \"{out / 'render_detail.sh'}\"")
        print(f"      Windows:      \"{out / 'render_detail.bat'}\"")
        print(f"      （本构建目录专属端口 {p_render}/{p_check}，与 render_v2 8620–8679、"
              f"手工并发 8580–8619 互不干扰，可同时跑）")

        core = [k for k in details if k not in EXTRA_DETAIL]
        print(f"\n   核心 {len(core)} 块合计高度 {sum(DETAIL_HEIGHTS[k] for k in core)}"
              f"（不含附加件；完整详情页 = 核心 + 4 附加件 = 12 块）")

        # 🔴 漏板块守卫：只要构建了详情页却没凑齐 12 块，就明确告知缺哪些，
        # 即使有人还在跑老的 `--only d1..d9`，也会被这行拦一下，不会静默少交。
        missing = [k for k in DETAIL_FULL if k not in details]
        if missing:
            print(f"\n   ⚠️ 本次【未构建】这些详情页板块：{' '.join(missing)}")
            print(f"      完整详情页是 12 块（含附加件 df/dfac/dc/drev）。若不是刻意只出部分，")
            print(f"      改用一条命令出全套：python {Path(__file__).name} {Path(a.product_json).name} -o {a.out} --detail-all")

    # 🔴 V2-35① 的尾巴：上面那堆 ⚙️备选命令刷屏后，最后再把默认路径说一次。
    #   两头都打是故意的 —— 有人从头读，有人只看最后几行。
    if [k for k in keys if isinstance(spec.get(k), dict) and spec[k].get("swap")]:
        print(f"\n🔴 再说一次：上面的 render.py / render_detail 是 ⚙️备选纯渲染。"
              f"**默认出图 = render_v2.py**（命令见本次输出开头）。")

    # 🔴 放在最后一行打：demo 降级的告知要是最后看到的东西，夹在出图命令中间必被淹没。
    if "m7" in keys and str(spec.get("m7", {}).get("facts", {}).get("mode", "")).strip() == "demo":
        _demo_mode_banner()


# 🔴 一次性出图脚本的专属端口段 8500–8559（30 组 × 2 个，见 references/pitfalls.md §11 端口表）。
#   ⛔ 不能沿用默认 8747/8748：那会和 render_v2（8620–8679）/ 手工并发（8580–8619）同机撞车 ——
#   撞上的后果不是报错，是 render.py 的 http.server 被别人 free_port() 换掉 → Chrome 拿到 404
#   或【别人构建目录里的正常图】（后者体积正常、QC 正常，抓不住）。
#   用构建目录绝对路径的 crc32 取模 → 同一个构建目录每次都拿到同一组端口（可复现、便于排查），
#   不同产品的构建目录几乎必然错开。
#   ⛔ 别用 hash()：Python 每进程给 str 的 hash 加盐（PYTHONHASHSEED），同一目录两次跑结果不一样。
#
# 为什么 8500–8559 安全（2026-08-05 逐段验算，改基数前把这段读完）：
#   ① 国际站自己：手工并发 8580–8619 / render_v2 8620–8679 / 子脚本默认 8747·8748·8792 /
#      render_v2 旧基数 8700–8756（同事手上可能还跑着旧版）—— 全都 ≥8580，本段整体在其下。
#   ② 国内 skill：V2 自动区 8747–8942、手工并发 9100–9139 —— 都 ≥8747，且分配式只加不减。
#   ③ CDP 调试端口：国际站 render.py 走 `--headless=new --screenshot`，全库零处
#      `--remote-debugging-port`，本段不派生 CDP 端口；国内那套按 `port + 1000×(1+scale组序号)`
#      派生 → 9747–9942 / 10747–10942 / 10100–10139 / 11100–11139，与 8500–8559 及其
#      假想派生值 9500–9559 / 10500–10559 均不交叠。
#   ⚠️ 30 组是够用的余量，不是并发保证 —— 脚本本身仍是串行，别据此改成并行。
#   ⚠️ 本机若有第三方服务占着这段（Consul 8500-8502 / Streamlit 8501 / geth 8545 都在段内，
#      free_port 会把它们请走），用环境变量 B2B_SCRIPT_PORT_BASE=<偶数> 换段（构建时生效，
#      端口是写死进 .sh/.bat 的）。
_SCRIPT_PORT_BASE = int(os.environ.get("B2B_SCRIPT_PORT_BASE", "8500"))
_SCRIPT_PORT_SLOTS = 30


def _script_ports(out: Path) -> tuple:
    """给某个构建目录算一组确定性端口 → (render 用, check_layout 用)，两者必不相同。"""
    k = zlib.crc32(str(out.resolve()).encode()) % _SCRIPT_PORT_SLOTS
    return _SCRIPT_PORT_BASE + k * 2, _SCRIPT_PORT_BASE + k * 2 + 1


def _write_render_scripts(out: Path, png_dir: Path, cmds: list, checks: list = None) -> None:
    """把逐张 render 命令写成一次性脚本（bash + bat），跨平台。
    输出 PNG 落在 <build>/png/ 下；脚本任意目录起跑都能用（命令里全是绝对路径）。
    checks = 产品图位置检查命令（d1/d3）：render 全出完后统一跑，压到文字只告警不中断
    （让 12 张先全出来，别因一张遮挡就半途卡住），结尾汇总是否有遮挡。"""
    checks = checks or []
    png_dir.mkdir(parents=True, exist_ok=True)
    p_render, p_check = _script_ports(out)
    # 头部把占用端口打出来：撞车时（"体积偏小疑似 404" / 截到别人的图）一眼能对上是谁在抢。
    # ⛔ 段位别写死：`B2B_SCRIPT_PORT_BASE` 换段后，写死的 "8500–8559" 会在排查撞车时误导人。
    _seg = f"{_SCRIPT_PORT_BASE}–{_SCRIPT_PORT_BASE + _SCRIPT_PORT_SLOTS * 2 - 1}"
    banner = f"本脚本占用端口 {p_render}(render) / {p_check}(check_layout)（专属段 {_seg}，见 pitfalls §11）"
    sh = ["#!/usr/bin/env bash", "set -e", f"# {banner}", f'echo "{banner}"',
          'echo "开始出详情页……"', *cmds,
          f'echo "✅ 出图完成，图在 {png_dir}"']
    if checks:
        sh += ['set +e', 'FAIL=0', 'echo "—— 产品图位置检查（d1/d3 不许压文字）——"',
               *[f'{c} || FAIL=1' for c in checks],
               'if [ "$FAIL" = 1 ]; then echo "❌ 有产品图压到文字，见上，需缩小/右移产品后重出该张"; '
               'else echo "✅ 产品图位置检查通过"; fi']
    sh.append("")
    (out / "render_detail.sh").write_text("\n".join(sh), encoding="utf-8")

    bat = ["@echo on", "setlocal", f"rem {banner}", f"echo {banner}",
           *[c + " || exit /b 1" for c in cmds],
           f'echo 出图完成，图在 {png_dir}']
    if checks:
        bat += ["set FAIL=0", "echo ---- 产品图位置检查（d1/d3 不许压文字）----",
                *[f'{c} || set FAIL=1' for c in checks],
                'if "%FAIL%"=="1" (echo ❌ 有产品图压到文字，见上，需缩小/右移产品后重出该张) '
                'else (echo ✅ 产品图位置检查通过)']
    bat.append("")
    (out / "render_detail.bat").write_text("\r\n".join(bat), encoding="utf-8")


if __name__ == "__main__":
    main()
