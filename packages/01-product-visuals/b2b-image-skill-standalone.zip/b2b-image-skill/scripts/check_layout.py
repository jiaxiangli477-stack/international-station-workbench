#!/usr/bin/env python3
"""详情页【产品图位置检查】—— 产品图的可见像素不许压到文字。

为什么需要它：详情页 d1/d3 的产品图是【逐产品替换】的，10 款抠图长宽比各不同。
版式虽然把产品放在右侧独立列（结构上不该重叠），但只要有人把宽度调大、或某张抠图
特别宽，产品就可能探进左侧文字区，把标题/药丸/CTA 压掉一角。这个坑【不报错】——
出图看着"差不多"，得放大才发现字被盖了。qc.py 只量颜色配比，查不出这种几何遮挡。

怎么查（零新依赖，复用 render.py 那套 Chrome + http.server）：
  1. 把模块 HTML 拷一份、注入一段探针 JS，量出每个产品图的 getBoundingClientRect，以及每个文字
     节点的 **Range.getClientRects()（真实墨迹，逐行）** —— 🔴 不是元素盒，见 I-82；
  2. chrome --headless --dump-dom 把结果读回来；
  3. 🔴 关键：产品图是【透明背景抠图】，元素外框重叠 ≠ 真遮挡。所以用 Pillow 读产品 PNG 的
     alpha，把"文字框 ∩ 产品框"这块映射回产品图像素（正确还原 object-fit:contain 的居中缩放），
     只有那块里有【不透明产品像素】才判定遮挡。空白角重叠不误报。

🆕 V2 场景替换法下仍然有效（Bowen 2026-07-31）：V2 里产品【位置】由底图的【占位件】决定
   （占位 = 库存抠好的透明件，有 alpha），换真产品不改位置。所以照常把本脚本跑在【构建目录的
   dN.html】上 = 量占位件的位置 = 等于量最终产品位置。`render_v2.py` 对**所有有产品图槽的模块**已自动跑（P1-11 起判据不再是 d1/d3 白名单，
   主图 m1/m2、d2、以及 mode:composite 的件都会跑），无需手动。
   （不是跑在 --scene 出的成品图上——那张无 alpha；跑底图/构建目录 HTML 才对。）

用法:
    python check_layout.py <build_dir> <html_name> [--size 750x432] [--port 8748] [--chrome PATH]
    # 通常配合 build/ 里已构建好的 dN.html 用；--size 用该模块的锁死高度（build 会打印）。

退出码：0 = 没有遮挡**或没找到产品图**（后者会打 ⚠️ 要求人工补查，⛔ 别当通过）；
        1 = 有产品像素压住文字（打印是哪几处），**或本脚本自己没跑成**（环境故障也走 sys.exit）。
        🔴 调用方要区分这两种 1，看 stdout 有没有「压到文字」——render_v2._check_layout 已这么做。
        是筛子不是判官，🔴 仍要放大目检。
"""
import argparse, base64, json, re, subprocess, sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （修 Windows 管道输出 emoji 崩溃）
# 复用 render.py 的 Chrome 定位 / 端口清理 / 存活探测，避免逻辑分叉
from render import find_chrome, free_port, http_ok  # noqa: E402

# 🔴 产品图选择器清单（2026-08-05 P1-12 补主图）。
#    之前只有前 4 条（全是【详情页】写法）→ 主图 m1/m2 一律落空、打印"没有产品图"，
#    结果 m1 的袋子顶边切过大标题 ASHWAGANDHA（压约 80px）而检查器说"无需检查"，没人去看。
#    ⛔ 加模板/改产品位的 class 时，必须同步加到这里 —— 落空 = 这道闸门等于没跑。
#    每条对应的模板（assets/templates/ 实测确认，不是照抄国内 skill）：
PRODUCT_SELECTORS = [
    ".prod img",              # d1-hero.html 的 .prod 产品位（详情页 D1）
    ".prodwrap img",          # d3-formula.html 的 .prodwrap 产品位（详情页 D3）
    ".pw img",                # 历史写法，留着兼容旧构建目录
    "[data-role=product] img",  # 通用逃生口：模板可给任意产品图打这个属性
    "img.main",               # m1-brand-hero.html / m2-pain-hook.html 的 img.main 主图主包装
    ".main img",              # 同上的 wrapper 写法（国内 skill v2.16 用这种，两边都认）
    "img.second",             # m1-brand-hero.html 的 img.second 次包装（条包），绝对定位、和 .main 同一簇
    "img.scene",              # m1-brand-hero.html 的 img.scene 产品色载体（水果/冲泡杯），也会探进文字区
    ".pcard img",             # d2-benefits.html 的 .pcard 产品位（详情页 D2）
    "img.p",                  # d4-custom.html 的 img.p 三品并排（.p p1/p2/p3）
    # ⛔ 【故意不加】".frame img"（m3-your-brand.html 的 .frame）：独立回检建议补上，实测会
    #    100% 误报 —— m3 的 `.cap{position:absolute;bottom:16px}` 就长在 `.frame` 里、
    #    **设计上就压在照片上**，且那三张是不透明照片（无 alpha ⇒ 整块算压字）。
    #    加了它 = 每张 m3 必判 ❌，而 check_layout 现在是【阻断】的 ⇒ m3 永远出不来。
    #    📌 本闸门管的是「抠图产品探进文字列」，不是「照片上的叠字」，别把两者混为一谈。
]

# 探针：量产品图与文字**墨迹**的屏幕矩形，base64 塞进根节点属性（base64 无引号/空格，dump-dom 不会转义坏）。
#
# 🔴 文字必须用 `Range.getClientRects()` 量【墨迹】，⛔ 不许用 `parentElement.getBoundingClientRect()`
#    量【元素盒】（2026-08-17 / I-82，m1 真图实测逼出来的）：
#      `.h1` / `.sub` 是**块级**元素，盒宽 = 整条左栏宽 ⇒ m1 的盒右缘 **518.1**，
#      而那几行字的真实墨迹最远只到 **437.4**；袋子 left=452 ⇒ 实际净空 ~15px、一个字都没被压，
#      旧写法却报「产品图【压到文字】3 处」判废。而 `references/main-images.md` 的判据原文是
#      「**别压文案**：以最长那行的**实际末端**为准，不是栏宽」—— 旧写法用的根本不是那把尺子。
#    Range 对**每个行盒**各返回一个 rect（多行文本自动逐行量），所以长段落不会被拉成一个大矩形；
#    高度仍是行盒高（含行距），纵向偏保守 = 宁可多判一点，符合本闸门"筛子"的定位。
_PROBE_TPL = r"""
<script>
(function(){
  function leafText(){
    var out=[], w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null,false), n;
    while(n=w.nextNode()){
      var s=n.textContent.replace(/\s+/g,' ').trim();
      if(!s) continue;
      var rg=document.createRange(); rg.selectNodeContents(n);
      var rs=rg.getClientRects();          // 🔴 墨迹（逐行），不是元素盒
      for(var i=0;i<rs.length;i++){
        var r=rs[i];
        if(r.width<1||r.height<1) continue;
        out.push({t:s.slice(0,44),l:r.left,tp:r.top,w:r.width,h:r.height});
      }
    }
    return out;
  }
  function grab(sel){
    if(!sel) return [];
    return [].slice.call(document.querySelectorAll(sel)).map(function(im){
      var r=im.getBoundingClientRect();
      return {src:im.getAttribute('src'),l:r.left,tp:r.top,w:r.width,h:r.height,
              nw:im.naturalWidth,nh:im.naturalHeight};
    });
  }
  var payload=JSON.stringify({prods:grab('__PRODUCT_SELECTORS__'),
                              others:grab('__OTHER_SELECTORS__'),
                              texts:leafText()});
  document.documentElement.setAttribute('data-layoutcheck',
      btoa(unescape(encodeURIComponent(payload))));
})();
</script>
"""

# 🔴 选择器清单是【唯一来源】：模板注入时才拼进探针，⛔ 别在别处再硬编码一份。
#    （2026-08-05 P1-12：上一版把模板重命名成 _PROBE_TPL 却漏了这一行，
#      main() 里的 PROBE 直接 NameError —— 整道闸门崩了，而管道里的 $? 还是 0。）
def build_probe(selectors, others=()):
    """把选择器清单拼进探针模板。回传的 payload：
       `prods` = `selectors` 命中的元素；`others` = `others` 命中的（本文件不用，
       check_product_spec 拿它当「不许长过去的邻居」）；`texts` = 文字**墨迹**逐行。
    🔴 2026-08-17 / I-81：`check_product_spec.py` 要用**另一份更窄**的选择器
       （它要「只圈印着规格数字的主产品」，而本文件要「凡是可能盖住字的都抓」——
       两个用途要的范围**正相反**，共用一份必错）。所以探针模板对外只暴露这个构造函数，
       ⛔ 别再让别的脚本 `import PROBE` 当成"产品区"来用。"""
    return (_PROBE_TPL.replace("__PRODUCT_SELECTORS__", ",".join(selectors))
                      .replace("__OTHER_SELECTORS__", ",".join(others)))


PROBE = build_probe(PRODUCT_SELECTORS)

ALPHA_MIN = 40      # alpha 高于此算"不透明产品像素"
OPAQUE_MIN_PX = 24  # 映射回产品图后，重叠区里不透明像素≥此数才判遮挡（滤掉抗锯齿毛边）


def _contain_rect(box, nw, nh):
    """object-fit:contain 下，图像在元素框 box 内实际渲染出的矩形 (l,t,w,h)。"""
    bl, bt, bw, bh = box
    if nw <= 0 or nh <= 0:
        return (bl, bt, bw, bh)      # 拿不到自然尺寸，退化成整框
    scale = min(bw / nw, bh / nh)
    rw, rh = nw * scale, nh * scale
    return (bl + (bw - rw) / 2, bt + (bh - rh) / 2, rw, rh)


def _overlap(a, b):
    """两矩形 (l,t,w,h) 的交集 (l,t,w,h)，不相交返回 None。"""
    l = max(a[0], b[0]); t = max(a[1], b[1])
    r = min(a[0] + a[2], b[0] + b[2]); btm = min(a[1] + a[3], b[1] + b[3])
    if r <= l or btm <= t:
        return None
    return (l, t, r - l, btm - t)


def _opaque_pixels(img_path: Path, prod, ovl):
    """重叠区 ovl（CSS px）里，产品图有多少不透明像素。无 alpha 通道视作全不透明。"""
    from PIL import Image
    im = Image.open(img_path)
    nw, nh = im.size
    content = _contain_rect((prod["l"], prod["tp"], prod["w"], prod["h"]), nw, nh)
    vis = _overlap(content, ovl)          # 先和"图像真正渲染出的矩形"求交（object-fit 空白带排除）
    if not vis:
        return 0
    sx = nw / content[2]; sy = nh / content[3]
    px0 = int(max(0, (vis[0] - content[0]) * sx))
    py0 = int(max(0, (vis[1] - content[1]) * sy))
    px1 = int(min(nw, (vis[0] + vis[2] - content[0]) * sx))
    py1 = int(min(nh, (vis[1] + vis[3] - content[1]) * sy))
    if px1 <= px0 or py1 <= py0:
        return 0
    crop = im.crop((px0, py0, px1, py1))
    if "A" not in crop.getbands():
        return crop.width * crop.height   # 不透明矩形图：整块都算压字
    hist = crop.getchannel("A").histogram()   # 256 bins；alpha≥ALPHA_MIN 的像素数
    return sum(hist[ALPHA_MIN:])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("build_dir")
    ap.add_argument("html_name")
    ap.add_argument("--size", default="750x432")
    ap.add_argument("--port", type=int, default=8748)
    ap.add_argument("--chrome", default=None)
    a = ap.parse_args()

    build = Path(a.build_dir).resolve()
    src_html = build / a.html_name
    if not src_html.exists():
        sys.exit(f"找不到 {src_html}")
    w, h = (int(x) for x in a.size.lower().split("x"))
    chrome = a.chrome or find_chrome()

    # 注入探针，写一份临时 HTML 到构建目录（同目录相对路径/图片才解析得到）
    html = src_html.read_text(encoding="utf-8")
    inj = html.replace("</body>", PROBE + "</body>") if "</body>" in html else html + PROBE
    probe_html = build / f"__layoutcheck__{a.html_name}"
    probe_html.write_text(inj, encoding="utf-8")

    free_port(a.port)
    srv = subprocess.Popen(
        [sys.executable, "-m", "http.server", str(a.port)],
        cwd=build, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    try:
        base = f"http://127.0.0.1:{a.port}"
        for _ in range(40):
            if http_ok(f"{base}/{probe_html.name}"):
                break
            time.sleep(0.25)
        else:
            sys.exit(f"服务器起不来或 {probe_html.name} 404")
        res = subprocess.run(
            [chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars",
             "--force-device-scale-factor=1", f"--window-size={w},{h}",
             "--virtual-time-budget=3000", "--dump-dom", f"{base}/{probe_html.name}"],
            capture_output=True, timeout=120,
        )
        dom = res.stdout.decode("utf-8", "replace")
    finally:
        srv.terminate()
        srv.wait(timeout=10)
        probe_html.unlink(missing_ok=True)

    m = re.search(r'data-layoutcheck="([A-Za-z0-9+/=]+)"', dom)
    if not m:
        sys.exit("探针没回传数据（dump-dom 里找不到 data-layoutcheck）——"
                 "多半是 JS 没跑起来，换新版 Chrome，或用 --chrome 指定。")
    data = json.loads(base64.b64decode(m.group(1)).decode("utf-8"))
    prods, texts = data["prods"], data["texts"]

    if not prods:
        # 🔴 ⛔ 这里【不许打 ✅】：「没找到产品图」和「检查通过」是两回事。
        #    2026-08-05 就是把它当放行 → m1 的袋子压住大标题 80px 没人去看。
        #    清单动态拼自 PRODUCT_SELECTORS，⛔ 别再写死一份（旧版写死的那份已经和实际对不上）。
        print(f"⚠️ {a.html_name}: 没找到产品图（试过 {' '.join(PRODUCT_SELECTORS)}）。\n"
              f"   若该模块【确实有产品图】= 选择器没覆盖到，请把它的 class 补进 "
              f"check_layout.py 的 PRODUCT_SELECTORS —— 这不是通过，是要你人工补查。")
        return

    hits = []
    for pi, prod in enumerate(prods):
        img_path = (build / prod["src"]).resolve()
        pbox = (prod["l"], prod["tp"], prod["w"], prod["h"])
        for tx in texts:
            ovl = _overlap(pbox, (tx["l"], tx["tp"], tx["w"], tx["h"]))
            if not ovl:
                continue
            if not img_path.exists():
                hits.append((prod["src"], tx["t"], -1))   # 图丢了，按外框重叠先报
                continue
            op = _opaque_pixels(img_path, prod, ovl)
            if op >= OPAQUE_MIN_PX:
                hits.append((prod["src"], tx["t"], op))

    if hits:
        print(f"❌ {a.html_name}: 产品图【压到文字】{len(hits)} 处（放大核对，多半要缩小/右移产品，或改窄产品列）：")
        for src, txt, op in hits:
            tag = "（产品图缺失，按外框判）" if op < 0 else f"（重叠区约 {op} 个不透明像素）"
            print(f"   · 产品 {src} 压住文字「{txt}」{tag}")
        sys.exit(1)
    print(f"✅ {a.html_name}: {len(prods)} 张产品图均未遮挡文字（查了 {len(texts)} 行文字墨迹）。")


if __name__ == "__main__":
    main()
