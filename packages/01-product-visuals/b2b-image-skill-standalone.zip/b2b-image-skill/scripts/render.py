#!/usr/bin/env python3
"""把构建目录里的 HTML 渲染成精确 1000×1000 的 PNG（无头 Chrome）。

为什么不用 AI 出这类图：认证墙/流程/数据卡/主图骨架都是纯设计件，
HTML+Chrome 能保证色号零漂移、文字零乱码。AI 出图在这些位置只会引入错误。

这个脚本存在的理由是三个反复踩到的坑，它们都【不会报错】，只会安静地出一张错图：

  1. 资源 404（端口上残留着上一次的服务器根目录不对 / 并发时几路互相杀服务器 / 构建目录缺件）。
     两种形态：整页 404（PNG 只有 20KB）、以及更阴的「页面渲出来了但里面几张图是破图」——
     后者体积一点不小（实测 181KB 的主图里 5 张证书破了 4 张），光看体积查不出来。
     脚本每次先杀端口，并在【截图前】把 HTML 引用的每个本地资源 GET 一遍，非 200 就硬失败。
  2. 字体 404 → Chrome 静默回退 Helvetica，出图看着"差不多"，肉眼查不出。
     脚本渲染前 curl 字体必须 200。
  3. Chrome 路径逐平台不同，写死 macOS 路径的脚本在 Windows 上直接不能用。

用法:
    python render.py <build_dir> <html_name> <out_png> [--port 8747]
    python render.py build/ m1.html out/主图1.png
"""
import argparse, os, platform, posixpath, re, shutil, signal, socket, subprocess, sys, time, urllib.request

from pathlib import Path
from urllib.parse import quote, unquote

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （必须 import：修 Windows 管道输出下 emoji 崩溃）

# 🔴 被 SIGTERM 终止时也要收摊（僵尸 http.server 的第二道口子）：
#   main() 的 finally 只在正常退出/异常时跑；SIGTERM 的默认动作是【直接终止解释器】，finally 不执行
#   → 我们 Popen 起的 http.server 当场变孤儿（PPID=1），永久 LISTEN 占着端口。
#   把 SIGTERM 翻译成 SystemExit，finally 就能照常 terminate 掉它。
#   （SIGKILL 拦不住 —— 真正的修法是 free_port 别再误杀客户端进程，这里只是兜底。）
#   overlay_copy.py / check_layout.py `from render import ...` 时会一并装上，它们同样起 http.server。
#   非主线程 import 时 signal.signal 会抛 ValueError，包一层保证 import 永不失败。
try:
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(143))   # 143 = 128 + SIGTERM
except (ValueError, AttributeError, OSError):
    pass

CHROME_CANDIDATES = {
    "Darwin": [
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    ],
    "Windows": [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    ],
    "Linux": [
        "/usr/bin/google-chrome", "/usr/bin/google-chrome-stable",
        "/usr/bin/chromium", "/usr/bin/chromium-browser",
    ],
}


def find_chrome() -> str:
    for name in ("google-chrome", "chrome", "chromium", "msedge"):
        p = shutil.which(name)
        if p:
            return p
    for cand in CHROME_CANDIDATES.get(platform.system(), []):
        if cand and Path(cand).exists():
            return cand
    sys.exit(
        "找不到 Chrome/Chromium/Edge。\n"
        "  macOS : 装 Google Chrome 到 /Applications\n"
        "  Windows: 装 Chrome，或用 --chrome 指定 chrome.exe 完整路径\n"
        "  Linux : apt install chromium-browser"
    )


def _listener_pids(port: int) -> list:
    """只返回【监听】该端口的进程 PID（客户端连接一律不算）。

    🔴 这个 "只认 listener" 是整条管线最贵的一条教训（2026-08-05 定位）：
       旧写法 `lsof -ti :PORT` 在 macOS/Linux 上匹配的是【本地或远端】端口等于 PORT 的所有 socket
       —— 客户端连接也会被列进来。而在这套管线里，客户端就是 render.py / overlay_copy.py /
       check_layout.py 父进程【自己】（http_ok 探活、check_assets 逐个 GET 资源，Chrome 也在拉同一端口）。
       于是并发时：A 正在渲图 → B 启动时 free_port(P) 把 listener 和 A 一起捞出来 kill -9 →
         · A 自己被 SIGKILL 打死（"半成品底图"不只是服务器被杀，渲图进程本身也死）；
         · A 是被 SIGKILL 杀的，下面 main() 里的 finally 根本没机会跑 → A 的 http.server 子进程
           失去父进程被 init 收养（PPID=1），永久 LISTEN 在 P 上（机器上那两个僵尸就是这么来的）。
       实测（端口 8611，一个 http.server + 一个客户端连接，客户端 PID 47422 / listener 47423）：
         lsof -ti :8611                        → ['47422', '47423']   ← 客户端被误伤
         lsof -nP -iTCP:8611 -sTCP:LISTEN -t   → ['47423']            ← 只有 listener
       Windows 分支一直带 `and "LISTENING" in line` 过滤，语义本来就是对的；这里是把 lsof 分支补齐到
       同一语义。⛔ 别为了"省事"把 -sTCP:LISTEN 去掉，也别退回 `lsof -ti :port`。
    """
    try:
        if platform.system() == "Windows":
            out = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True, text=True).stdout
            return [line.split()[-1] for line in out.splitlines()
                    if f":{port} " in line and "LISTENING" in line]
        out = subprocess.run(["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-t"],
                             capture_output=True, text=True).stdout
        return out.split()
    except FileNotFoundError:
        return []  # 没有 lsof/netstat 也不致命，下面的端口探测会兜底


def _kill(pids: list, hard: bool) -> None:
    for pid in pids:
        if platform.system() == "Windows":
            subprocess.run(["taskkill"] + (["/F"] if hard else []) + ["/PID", pid], capture_output=True)
        else:
            subprocess.run(["kill", "-9" if hard else "-15", pid], capture_output=True)


def free_port(port: int) -> None:
    """杀掉【监听】端口的进程。残留服务器的根目录往往是错的，会让所有路径 404。

    先 SIGTERM 再 SIGKILL：占着端口的十有八九是我们自己漏收的 python http.server，SIGTERM 能让它
    正常收摊（少一个僵尸源）；万一是别人的服务，也先给一次体面退出的机会。1 秒内不退才 -9。
    """
    pids = _listener_pids(port)
    if pids:
        _kill(pids, hard=False)
        for _ in range(5):          # 最多等 1s
            time.sleep(0.2)
            if not _listener_pids(port):
                break
        else:
            _kill(_listener_pids(port), hard=True)
    for _ in range(20):
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return
        time.sleep(0.2)


def http_ok(url: str) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=5) as r:
            return r.status == 200
    except Exception:
        return False


# ── 资源 200 自检（下面三个零件）────────────────────────────────────────────
# 为什么要有它：2026-08-04 实测过一次【体积启发式抓不到】的坏图——
# render_v2.py 并发时 4 路互相 kill 掉对方的 http.server，Chrome 拿到 404，
# 出来的 m4.png 只有 181KB（正常 463KB），目检发现认证墙 5 张证书里 4 张是破图占位符，
# 但 render.py 照样打 ✅、退出码 0。原因：告警阈值是 size_kb < 40，181KB 远在阈值之上。
# 体积启发式只能抓「整页 404」，抓不到「页面渲出来了、里面几张图 404」——
# 而后者才是并发抢端口 / 构建目录缺件的典型形态，也是最贵的那类"不报错只安静出错图"。
# 所以改成确定性检查：截图前把 HTML 引用到的每个本地资源都 GET 一遍，必须 200。
RE_ATTR = re.compile(r"""(?:src|href)\s*=\s*["']([^"']+)["']""", re.I)
RE_CSS_URL = re.compile(r"""url\(\s*["']?([^"')]+)["']?\s*\)""", re.I)
# 注释里的 src= / url() 浏览器根本不会去取，把它当"缺件"报出来纯属误报，先剥掉。
RE_HTML_COMMENT = re.compile(r"<!--.*?-->", re.S)
RE_CSS_COMMENT = re.compile(r"/\*.*?\*/", re.S)
# 任何 URI scheme（http: data: mailto: javascript: tel: blob: file: about: …）。
# 用通用式而不是白名单：白名单漏一个，那个 ref 就会被当成相对路径去 GET → 硬闸门误报。
# 相对路径不会误命中——scheme 字符集里没有 "/"，"img/a:b.png" 这种冒号在斜杠之后，匹配不上。
RE_SCHEME = re.compile(r"^[a-z][a-z0-9+.\-]*:", re.I)


def _is_external(ref: str) -> bool:
    """外部 URL / data: / 页内锚点 → 不归我们管，跳过（只查相对路径的本地件）。"""
    r = ref.strip()
    return r.startswith(("//", "#")) or bool(RE_SCHEME.match(r))


def _resolve(ref: str, base_dir: str) -> str:
    """把一个相对引用解析成【相对构建根】的 posix 路径。base_dir = 引用它的那个文件所在目录。
    ⚠️ CSS 里的 url() 是相对【该 CSS 文件】的，不是相对 HTML —— 所以 base_dir 必须按来源文件传，
    否则 css 放在子目录时会整片误报。
    ⚠️ 这里【禁止】用 `.lstrip("./")` 收尾：lstrip 的参数是【字符集合】不是前缀，
       "../real-factory/x.png" 会被啃成 "real-factory/x.png" → 去 GET 一个不存在的路径 →
       硬闸门误报，而且错误信息把人往"缺件"上引，其实是解析错了。
       normpath 本来就会把 "./x" 规范成 "x"，根本不需要再 strip。"""
    ref = ref.strip().split("?", 1)[0].split("#", 1)[0]
    if not ref:
        return ""
    if ref.startswith("/"):
        ref, base_dir = re.sub(r"^/+", "", ref), ""   # 绝对路径 = 相对构建根，不再拼来源目录
    rel = posixpath.normpath(posixpath.join(base_dir, ref))
    return "" if rel in (".", "/") else rel


def _escapes_build(rel: str) -> bool:
    """解析结果逃出了构建根（normpath 后仍以 .. 开头）。"""
    return rel == ".." or rel.startswith("../")


def check_assets(build: Path, html_rel: str, base: str) -> list:
    """截图前把 HTML 引用的本地资源逐个 GET，返回取不到的 [(路径, 出处)]。
    覆盖：HTML 的 src=/href=（img、link rel=stylesheet、script）、HTML 内联 style 的 url()、
          以及 HTML 直接引用的那层 CSS 文件内部的 url()（字体/背景图）。
    不覆盖（够用且不易误报，刻意留白）：CSS 的 @import 链、JS 运行时注入的资源、srcset。
    这些漏网的仍有下面的体积告警兜底。
    逃出构建根的引用（../）只提示不报错 —— 见下面 escaped 一段的理由。"""
    html_dir = posixpath.dirname(html_rel.replace("\\", "/"))   # Windows 传 sub\m1.html 也别算错基准目录
    text = RE_HTML_COMMENT.sub("", (build / html_rel).read_text(encoding="utf-8", errors="ignore"))

    refs, css_files, escaped = [], [], []

    def take(raw: str, base_dir: str, src: str) -> None:
        if _is_external(raw):
            return
        rel = _resolve(raw, base_dir)
        if not rel:
            return
        if _escapes_build(rel):     # 逃出构建根：服务器根 = 构建目录，根本 GET 不到，查了必误报
            escaped.append((rel, src))
            return
        refs.append((rel, src))
        if rel.lower().endswith(".css"):
            css_files.append(rel)

    for raw in RE_ATTR.findall(text) + RE_CSS_URL.findall(text):  # 后者 = 内联 <style>/style="" 里的 url()
        take(raw, html_dir, html_rel)

    for css in css_files:
        f = build / unquote(css)    # HTML 里可能写的是 percent-encoded 路径，落到磁盘要还原
        if not f.exists():
            continue  # 这个 css 本身已经在 refs 里，会被下面点名，不用重复报
        cdir = posixpath.dirname(css)   # ← url() 相对 CSS 自己的目录
        ctext = RE_CSS_COMMENT.sub("", f.read_text(encoding="utf-8", errors="ignore"))
        for raw in RE_CSS_URL.findall(ctext):
            take(raw, cdir, css)

    if escaped:
        # 不当错误报：构建目录本该是自包含扁平结构，理论上不该出现 ../；真出现了，
        # 它指向的是服务器根之外，我们【没有办法】验证，硬报出来就是误伤（比如有人拿
        # assets/render/ 这类老模板目录当构建目录渲，里面就有 ../real-factory/x.png）。
        # 但也不能装没看见——换台机器 / 换服务根目录它必 404，所以打一条醒目提示。
        print("⚠️ 下列引用逃出了构建目录（在服务器根之外，无法验证，已跳过检查）：", file=sys.stderr)
        for rel, src in dict.fromkeys(escaped):
            print(f"    · {rel}   （被 {src} 引用）", file=sys.stderr)
        print("  → 构建目录应当是自包含的扁平结构（build.py 会把图片/字体都拷进来）。"
              "若出图有问题（破图 / 字体静默回退成 Helvetica），先查这几条。", file=sys.stderr)

    missing, seen = [], set()
    for rel, src in refs:
        if rel in seen:
            continue
        seen.add(rel)
        # 路径里有中文/空格 → 必须 quote 才 GET 得到；
        # 但 ref 若【本来就是】percent-encoded，quote 会把 % 二次编码成 %25 → 误报。
        # 分不清是哪种就两个都试一次，任一 200 即算在（只在含 % 时才多发一次请求）。
        cands = [quote(rel, safe="/")]
        if "%" in rel:
            cands.append(rel)
        if not any(http_ok(f"{base}/{c}") for c in cands):
            missing.append((rel, src))
    return missing


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("build_dir")
    ap.add_argument("html_name")
    ap.add_argument("out_png")
    ap.add_argument("--port", type=int, default=8747)
    ap.add_argument("--size", default="1000x1000")
    # 详情页出 @2x 高清用：HTML 仍按 @1x 写（宽 750），--scale 2 出 1500 宽的图。
    # 阿里详情图实测就有 750(@1x) 和 1500(@2x) 两种，@2x 在手机上更锐利，HTML 渲染出 2x 零成本。
    ap.add_argument("--scale", type=int, default=1, choices=[1, 2])
    ap.add_argument("--chrome", default=None)
    a = ap.parse_args()

    build = Path(a.build_dir).resolve()
    if not (build / a.html_name).exists():
        sys.exit(f"找不到 {build / a.html_name}")
    w, h = (int(x) for x in a.size.lower().split("x"))
    out = Path(a.out_png).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    chrome = a.chrome or find_chrome()

    free_port(a.port)
    srv = subprocess.Popen(
        [sys.executable, "-m", "http.server", str(a.port)],
        cwd=build, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    try:
        base = f"http://127.0.0.1:{a.port}"
        for _ in range(40):
            if http_ok(f"{base}/{a.html_name}"):
                break
            time.sleep(0.25)
        else:
            sys.exit(f"服务器起不来或 {a.html_name} 404")

        # 字体自检：字体拿不到时 Chrome 会静默回退 Helvetica，出图看着没问题但字体是错的。
        # ⚠️ 两种失效都要抓，缺一不可：
        #   a) 文件根本不在（build.py 没拷进来）—— 最常见
        #   b) 文件在但服务器取不到（根目录不对 / 端口串了）
        # 旧写法 `if (build/font).exists() and not http_ok(...)` 有短路 bug：
        # 文件缺失时 exists() 为假 → 整个检查被跳过 → 一声不吭渲成 Helvetica。
        # 实测：删掉字体目录后旧版照样打印 ✅。
        font = "fonts/poppins/Poppins-Black.ttf"
        if not (build / font).exists():
            sys.exit(
                f"字体文件不存在：{build / font}\n"
                f"→ Chrome 会静默回退 Helvetica，出图字体是错的。\n"
                f"→ 多半是 build.py 没把字体拷进构建目录，重跑 build.py。"
            )
        if not http_ok(f"{base}/{font}"):
            sys.exit(f"字体 {font} 取不到（服务器 404）→ 会静默回退 Helvetica。检查构建目录结构。")

        # 资源 200 自检（主判据）：页面渲得出来 ≠ 里面的图都在。
        # 实测坏图 m4.png 181KB、5 张证书破了 4 张，体积告警（<40KB）完全没触发 → 必须逐个 GET 确认。
        missing = check_assets(build, a.html_name, base)
        if missing:
            lines = "\n".join(f"    · {rel}   （被 {src} 引用）" for rel, src in missing)
            sys.exit(
                f"❌ {a.html_name} 引用的 {len(missing)} 个本地资源取不到（HTTP 非 200）：\n{lines}\n"
                f"→ 图片会渲成破图占位符、字体会静默回退，而【整张图仍然会出来、体积也不小】，"
                f"光看体积查不出来。\n"
                f"→ 排查顺序：① 构建目录 {build} 是不是缺件（重跑 build.py）；"
                f"② 是不是有别的进程抢了 --port {a.port}（并发渲图时几路互相杀服务器，"
                f"给每路分不同端口）。"
            )

        subprocess.run([
            chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars",
            f"--force-device-scale-factor={a.scale}", f"--window-size={w},{h}",
            f"--screenshot={out}", f"{base}/{a.html_name}",
        ], capture_output=True, timeout=120)
    finally:
        srv.terminate()
        srv.wait(timeout=10)

    if not out.exists():
        sys.exit("Chrome 没有产出 PNG")
    size_kb = out.stat().st_size / 1024
    try:
        from PIL import Image
        got = Image.open(out).size
        want = (w * a.scale, h * a.scale)   # @2x 时产出尺寸是 window-size 的两倍
        if got != want:
            sys.exit(f"尺寸不对：得到 {got}，要求 {want}")
    except ImportError:
        pass
    # 【兜底启发式，不是主判据】主判据是上面截图前的「资源 200 自检」。
    # 体积只能抓「整页 404」这种极端情况：实测 181KB 的图里 5 张证书破了 4 张，这条根本不响。
    # 留着是为了兜住自检覆盖不到的部分（CSS @import 链、JS 注入的资源）。
    warn = "  ⚠️ 体积偏小，疑似截到了 404 错误页——检查图片资源是否都在构建目录里" if size_kb < 40 else ""
    print(f"✅ {out.name}  {w}×{h}  {size_kb:.0f}KB{warn}")


if __name__ == "__main__":
    main()
