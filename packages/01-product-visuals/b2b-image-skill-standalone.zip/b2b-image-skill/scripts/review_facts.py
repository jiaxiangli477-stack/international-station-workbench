#!/usr/bin/env python3
"""m7 营养成分表 —— **第二层：LLM 配方顾问**（只报不拦）。

用法：
    python3 scripts/review_facts.py product.json
    python3 scripts/review_facts.py product.json --module m7 --runs 2 --json out.json

═══════════════════════════════════════════════════════════════════════════
🔴 它和 check_facts.py 是【两层】，⛔ 谁都替不了谁
═══════════════════════════════════════════════════════════════════════════

**第一层 = `check_facts.py`（纯代码硬闸门，会拦）**：%DV 计算 · 单位换算 ·
对着 `assets/schemas/dv_table.json` 比对 · ®/™ 商标词表 · `source` 必填。

⛔ **本脚本【不做】上面这五件事，一件都不做。** 理由必须写死在这里，免得以后有人
"顺手让模型也算一下 %DV"：

    大模型算 %DV 有相当概率用它**训练语料里的旧 DV 表**（美国 DV 2016 年改过一轮，
    网上和语料里新旧混杂）。而"配方表用了旧 DV"**正是我们要抓的那个错**。
    让模型来算 = **用会漂的东西去检查会漂的东西** —— 它给的绿灯毫无意义，
    给的红灯你还得再查一遍。这类"可复现、离线、零成本"的事必须留给代码。

**第二层 = 本脚本（LLM 顾问，只提建议、不拦）**，专治代码写不出规则的判断题：

    ① 配方逻辑合理性 —— 例：每份 2 mL 的滴剂里塞 2,005 mg 固形物 = 剂型不匹配
    ② 成分重复 / 冲突 —— 例：`Curcumin (from Turmeric extract)` 与另列的 Turmeric 重复计
    ③ 别名归一 —— 例：Sea Moss = Irish Moss = Chondrus crispus，同物异名让表看着更长其实重复
    ④ 剂量是否触碰安全上限（UL）—— 语境判断，不是硬规则
    ⑤ 成分与产品定位是否匹配 —— 例：助眠配方里塞运动成分

═══════════════════════════════════════════════════════════════════════════
🔴 三条硬约束（都是本 skill 踩过的坑，改代码前先读）
═══════════════════════════════════════════════════════════════════════════

1. **只报不拦** —— 它是顾问不是判官。正常跑完一律 **退出码 0**，输出结构化建议交人判。
   ⛔ 不许因为"模型说有问题"就挂硬失败：模型会误报，卡住出图流程的代价远大于收益。

2. **锁定的 DV 表必须喂进上下文**（`assets/schemas/dv_table.json`）。
   文件不在 → 报告里明写「DV 表缺失，本次不做任何 DV 相关判断」，并在提示词里禁掉该话题。
   ⛔ 绝不许让模型凭记忆算数（理由见上）。

3. **「没跑成 ≠ 通过」** —— 云不可用 / 凭据缺失 / 模型返回解析不了 / 根本没有 m7 数据
   → **退出码 2 + 醒目说明**。
   ⚠️ `verify_label.py` 就栽在"云 OCR 静默不跑还退出码 0"上（那次是标签检查根本没跑、
   退出码却是绿的），我们刚修完。⛔ 别在新脚本上重犯。

═══════════════════════════════════════════════════════════════════════════
🔴 什么时候跑（B 组文档会引用这一段）
═══════════════════════════════════════════════════════════════════════════

放在 **配方定稿 / 设计稿签字阶段跑一次**，⛔ **不进出图循环**。
出图要可复现、要能随时重跑；每次都调 LLM 会让**同一份配方两次跑出不同结论**，
届时没人知道该信哪一版。顺序：

    配方定稿 → check_facts.py（硬闸门，必须过）→ review_facts.py（顾问，人看一眼）
    → 设计稿签字 → build/render 出图循环（这一段里只跑代码闸门，⛔ 不再调 LLM）

═══════════════════════════════════════════════════════════════════════════
技术接法
═══════════════════════════════════════════════════════════════════════════

· 走 **deepkey 文本组**（`DEEPKEY_TEXT_BASE_URL` / `DEEPKEY_TEXT_API_KEY`），
  凭据解析直接复用 `gen_image.creds_ocr()`（它已处理好 env→.env→~/.zshrc 三级兜底、
  整组配对取值、跨平台）。⛔ 别自己另写一套 HTTP 客户端；
  ⛔ 更别复用 `gen_image.creds()` —— 那是**生图组**，那把 key 的分组里没有任何文本模型。
· 模型 `gpt-5.5`，环境变量 `REVIEW_FACTS_MODEL` 可覆盖（照 `VERIFY_LABEL_MODEL` 的惯例）。
· `temperature=0`。
· **双跑交叉验证**（`verify_label.py` 已有这个范式）：跑两遍，
  只有一遍报出来的条目标成「⚠️ 可疑，需人工判」——LLM 接口即使 temperature=0 也不是
  严格确定的（批处理/路由会带来抖动），只在一遍出现的结论稳定性最差，最该人来看。
  `--runs 1` 可省一半钱，但报告里会明说交叉验证没做。
"""

from __future__ import annotations

import argparse
import difflib
import json
import os
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401  （必须 import：修 Windows 管道输出下 emoji 崩溃 + 密钥三级兜底）

# ── 常量 ────────────────────────────────────────────────────────────────
SKILL_ROOT = Path(__file__).resolve().parent.parent
DV_TABLE_DEFAULT = SKILL_ROOT / "assets" / "schemas" / "dv_table.json"

# 顾问用的文本模型。⛔ 归【deepkey 文本组】的 key 管，生图组调不动它。
REVIEW_FACTS_MODEL = os.environ.get("REVIEW_FACTS_MODEL", "gpt-5.5")

# DV 表塞进上下文的长度上限。超了**不截断**（截一半 = 模型看到残表，缺的那截它会拿记忆补，
# 正好违反硬约束 2）→ 直接判定「DV 表不可用」，禁掉 DV 话题，报告里说清楚。
DV_TABLE_MAX_CHARS = 40000

EXIT_OK = 0        # 跑完了（有没有发现问题都是 0 —— 只报不拦）
EXIT_NOT_RUN = 2   # 🔴 没跑成，绝不当通过

# 🆕 I-89⒤ 瞬时错误退避重试。实证：2026-08-17 那批首跑 `HTTP Error 503` 直接退 2，
#   同环境 check_env.py 两次都报 deepkey 文本组 gpt-5.5 在线，重跑即过 ⇒ 上游抖了一下。
#   本脚本一趟要花钱跑 ~55s（默认还是两跑），抖一下整趟重来，代价太大。
#   🔴 只对【瞬时】错误重试（5xx / 429 / 超时 / 连不上）；⛔ 401/403/404 这类**不重试**
#     —— 那是凭据或路径配错了，重试只是把"该立刻去修"的信号拖慢 3 倍。
#   🔴 重试用尽仍失败 ⇒ 照旧 ReviewUnavailable → 退出码 2，⛔ 绝不当通过。
LLM_RETRIES = max(0, int(os.environ.get("REVIEW_FACTS_RETRIES", "2")))   # 额外重试次数（不含首跑）
LLM_RETRY_BACKOFF = (3.0, 9.0)   # 第 1/2 次重试前各睡几秒；超出则沿用最后一个值
# 会重试的 HTTP 状态码：5xx（上游自己抖）+ 429（限流，等一下就好）。
_RETRY_STATUS = {429, 500, 502, 503, 504, 522, 524}

# 合法单位（与契约 §2 一致）。IU 不是质量单位，⛔ 不许折成 mg 参与求和。
MASS_MG = {"mg": 1.0, "g": 1000.0, "ug": 0.001}

CATEGORIES = {
    "formula_feasibility": "① 配方逻辑 / 剂型可行性",
    "duplicate_conflict":  "② 成分重复 / 冲突",
    "alias":               "③ 别名归一（同物异名）",
    "upper_limit":         "④ 剂量触碰安全上限（UL）",
    "positioning_match":   "⑤ 成分与产品定位匹配",
    "other":               "⑥ 其他（模型自己归不进上面五类的）",
}
SEV_ICON = {"high": "🔴", "medium": "⚠️", "low": "ℹ️"}


class ReviewUnavailable(Exception):
    """跑不成（凭据缺失 / 云不可用 / 返回解析不了 / 没有 m7 数据）→ 退出码 2，⛔ 绝不当通过。"""


# ── 读数据 ──────────────────────────────────────────────────────────────
def _strip_comments(obj):
    """去掉 `_` 开头的注释字段（build.py / verify_copy.py 已有同款约定，别改那套机制）。"""
    if isinstance(obj, dict):
        return {k: _strip_comments(v) for k, v in obj.items() if not str(k).startswith("_")}
    if isinstance(obj, list):
        return [_strip_comments(v) for v in obj]
    return obj


def load_facts(path: Path, module: str):
    """从 product.json 取 `<module>.facts`。也接受直接喂一份只含 facts 的 json（顶层带 rows）。

    返回 `(facts, positioning)`。取不到 → ReviewUnavailable（= 没跑成，不是通过）。"""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise ReviewUnavailable(f"找不到配方文件：{path}")
    except json.JSONDecodeError as e:
        raise ReviewUnavailable(f"配方文件不是合法 JSON：{path}（{e}）")

    facts = None
    if isinstance(data, dict):
        if isinstance(data.get(module), dict) and isinstance(data[module].get("facts"), dict):
            facts = data[module]["facts"]
        elif isinstance(data.get("facts"), dict):
            facts = data["facts"]
        elif "rows" in data:                     # 直接喂了一份 facts
            facts = data
    if not isinstance(facts, dict):
        raise ReviewUnavailable(
            f"{path} 里没有 `{module}.facts`（也不是一份独立的 facts json）—— 没有配方可评。")

    rows = facts.get("rows")
    if not isinstance(rows, list) or not rows:
        raise ReviewUnavailable(f"`{module}.facts.rows` 为空 —— 没有成分可评。")

    # 产品定位上下文（判断项⑤要用）：产品块 + m1 文案
    positioning = {}
    if isinstance(data, dict):
        if isinstance(data.get("product"), dict):
            positioning["product"] = _strip_comments(data["product"])
        m1 = data.get("m1")
        if isinstance(m1, dict) and isinstance(m1.get("text"), dict):
            positioning["m1_text"] = _strip_comments(m1["text"])
        mod = data.get(module)
        if isinstance(mod, dict):
            positioning["m7_headline"] = {k: mod[k] for k in ("H1", "SUB") if k in mod}
    return _strip_comments(facts), positioning


def local_solids(rows: list):
    """**本地**把各行剂量折算成 mg 并求和 —— 这是确定性算术，不是让模型算数。

    为什么要本地算：判断项①（剂型可行性）离不开"这份里一共多少固形物"。
    交给模型加 12 个数，它有概率加错，而这一步完全可以确定性完成 →
    本地算好、当**事实**喂给模型，模型只负责"这么多东西装不装得进 2 mL"的判断。
    ⛔ 这不等于替 check_facts.py 做单位换算校验：非法单位该由它硬拦，这里只是求和。
    """
    total, skipped, bad = 0.0, [], []
    for r in rows:
        if not isinstance(r, dict):
            continue
        name = str(r.get("name", "?"))
        unit = str(r.get("unit", "")).strip()
        amt = r.get("amount")
        if unit == "IU":
            skipped.append(f"{name} {amt} IU（IU 不是质量单位，⛔ 不并入总量）")
            continue
        if unit not in MASS_MG or not isinstance(amt, (int, float)):
            bad.append(f"{name}: amount={amt!r} unit={unit!r}")
            continue
        total += float(amt) * MASS_MG[unit]
    return round(total, 4), skipped, bad


def load_dv_table(path: Path):
    """喂给模型的 DV 表原文。返回 `(text_or_None, reason)`；`text is None` 时 DV 话题整体禁掉。"""
    if not path.exists():
        return None, f"DV 表缺失（{path} 不存在，A2 组负责产出）"
    try:
        raw = path.read_text(encoding="utf-8")
        json.loads(raw)                      # 只做合法性校验，喂给模型的是原文
    except json.JSONDecodeError as e:
        return None, f"DV 表不是合法 JSON（{path}：{e}）"
    except OSError as e:
        return None, f"DV 表读不了（{path}：{e}）"
    if len(raw) > DV_TABLE_MAX_CHARS:
        # ⛔ 不截断：残表 = 模型拿记忆补缺，正好违反硬约束 2
        return None, f"DV 表过大（{len(raw)} 字符 > {DV_TABLE_MAX_CHARS}），⛔ 不截断喂入，本次禁 DV 话题"
    return raw, f"已载入 {path}（{len(raw)} 字符）"


# ── 提示词 ──────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """你是保健品（膳食补充剂）配方审查顾问，服务对象是一家中国代工厂（OEM/ODM）。
他们要把一张"参考配方 / 样例配方"做成电商主图上的 Supplement Facts 表格，卖的是**配方能力**，不是某一瓶货。
你的产出只是**建议**，由人来判断是否采纳。

⛔ 以下五件事【不要做】，它们由另一个纯代码脚本负责，你重复做只会制造噪声和错误：
  1. 计算或核对 %DV（每日摄入量百分比）
  2. 单位换算校验（mg / g / ug / IU 之间）
  3. 与官方 DV 表逐条比对
  4. 扫描 ® / ™ / 专利原料商标
  5. 检查每行 source 字段有没有填

✅ 你【只做】这五类判断（代码写不出规则的判断题）：
  ① formula_feasibility 配方逻辑 / 剂型可行性 —— 给定的每份剂型和体积，物理上装得下这些固形物吗？
     提取物比例（如 10:1）与标示量是否自洽？液体/胶囊/软糖各自的容量常识是否被违反？
  ② duplicate_conflict 成分重复 / 冲突 —— 同一活性物被重复计入（如 Curcumin 又单列 Turmeric）、
     成分之间药理冲突、或明显互斥的组合
  ③ alias 别名归一 —— 同物异名让表看起来更长其实是重复（如 Sea Moss / Irish Moss / Chondrus crispus）
  ④ upper_limit 剂量触碰安全上限（UL）—— 结合剂型、每日份数、目标人群做**语境**判断
  ⑤ positioning_match 成分与产品定位是否匹配 —— 例如助眠配方里塞运动成分

规则：
- 🔴 数字不许凭记忆下断言。不确定就在 finding 里明说"不确定，需人工核"，并把 severity 降到 low。
- 🔴 只准使用【下面提供的 DV 表】里的数值。没提供 DV 表时，**完全不要谈 DV**。
- 🔴 总固形物质量已由脚本本地算好并给你了，⛔ 不要自己重算，直接用。
- ⛔ 不要建议添加任何功效/宣称话术（那是合规红线，另有脚本管）。你只谈配方本身。
- 没有问题就返回空的 findings 数组，⛔ 不要为了凑数硬编问题。

只输出一个 JSON 对象，不要 markdown 代码块、不要任何解释文字：
{
  "findings": [
    {
      "category": "formula_feasibility|duplicate_conflict|alias|upper_limit|positioning_match|other",
      "severity": "high|medium|low",
      "targets": ["涉及的成分名，用配方表里的原写法"],
      "finding": "问题是什么（中文，一两句说清）",
      "suggestion": "建议怎么改（中文，可执行）"
    }
  ],
  "overall": "一句话总体印象（中文）"
}"""


def build_user_prompt(facts: dict, positioning: dict, dv_text, dv_reason: str,
                      total_mg: float, skipped: list, bad: list) -> str:
    parts = []
    parts.append("【本次要审的配方（product.json 的 m7.facts 原文）】")
    parts.append(json.dumps(facts, ensure_ascii=False, indent=2))
    parts.append("")
    parts.append("【脚本本地算好的事实 —— 直接用，⛔ 不要自己重算】")
    parts.append(f"· 每份固形物总量 = {total_mg} mg（≈ {round(total_mg / 1000.0, 4)} g）"
                 f"；每份规格 serving_size = {facts.get('serving_size', '(未填)')}"
                 f"；每容器份数 = {facts.get('servings_per_container', '(未填)')}")
    for s in skipped:
        parts.append(f"· 未并入总量：{s}")
    for b in bad:
        parts.append(f"· 无法折算（剂量/单位有问题，已交由代码闸门处理，你不用管）：{b}")
    parts.append("")
    if dv_text:
        parts.append("【锁定的 DV 表（🔴 只准用这里的数值；表里没有的成分就说'本表无 DV'）】")
        parts.append(dv_text)
    else:
        parts.append(f"【DV 表：不可用 —— {dv_reason}】")
        parts.append("🔴 本次**完全不要**谈 %DV、不要提任何每日推荐量数值。")
    parts.append("")
    if positioning:
        parts.append("【产品定位上下文（判断项⑤用）】")
        parts.append(json.dumps(positioning, ensure_ascii=False, indent=2))
    else:
        parts.append("【产品定位上下文：无 —— 判断项⑤请跳过或降到 low】")
    return "\n".join(parts)


def _is_transient(e: BaseException) -> bool:
    """这个异常值不值得重试？🔴 判据只认【上游抖动/网络】，⛔ 认证与请求错一律不重试。

    - HTTPError：只看状态码，命中 `_RETRY_STATUS`（5xx/429）才重试；
      401/403（凭据不对）、404（base_url 写错）、400（请求体不合法）**立刻退**。
    - URLError / TimeoutError / OSError：连不上或超时 —— 重试。
    - 其它（JSON 解析不了等）：不重试（重试也是同样的返回）。
    """
    import urllib.error as _ue
    if isinstance(e, _ue.HTTPError):
        return getattr(e, "code", 0) in _RETRY_STATUS
    return isinstance(e, (_ue.URLError, TimeoutError, ConnectionError, OSError))


# ── 调模型（复用 verify_label 那套通道，⛔ 别另写 HTTP 客户端）─────────────
def call_llm(system: str, user: str, seed: int) -> str:
    import json as _json
    import urllib.request as _u
    try:
        # 🔴 creds_ocr() = deepkey【文本组】。⛔ 不是 creds()（生图组，那组里没有文本模型）。
        from gen_image import creds_ocr, USER_AGENT, _ssl_context
        base, key, _prov = creds_ocr()   # 没配 key/base 时 sys.exit → 下面 SystemExit 接住
    except SystemExit as e:
        raise ReviewUnavailable(f"没配文本模型凭据 DEEPKEY_TEXT_*（{e}）")
    except Exception as e:  # noqa: BLE001
        raise ReviewUnavailable(f"读取凭据失败：{type(e).__name__} {e}")

    body = _json.dumps({
        "model": REVIEW_FACTS_MODEL,
        "temperature": 0,
        "seed": seed,
        "messages": [{"role": "system", "content": system},
                     {"role": "user", "content": user}],
    }).encode()
    req = _u.Request(f"{base}/v1/chat/completions", data=body,
                     headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json",
                              "User-Agent": USER_AGENT})
    # 🆕 I-89⒤：瞬时错误退避重试（判据见 LLM_RETRIES 那段注释）。
    #   ⛔ 别把凭据读取也搬进这个循环 —— 缺凭据要**立刻**退 2 让人去修，重试只会拖慢。
    d = None
    for attempt in range(LLM_RETRIES + 1):
        try:
            with _u.urlopen(req, timeout=180, context=_ssl_context()) as r:
                d = _json.loads(r.read())
            break
        except Exception as e:  # noqa: BLE001  网络/HTTP/超时 —— 🔴 最终一律"没跑成"，⛔ 不当通过
            left = LLM_RETRIES - attempt
            if left <= 0 or not _is_transient(e):
                why = "（已重试到底）" if LLM_RETRIES and _is_transient(e) else ""
                raise ReviewUnavailable(f"调用失败{why}（{type(e).__name__} {e}）")
            wait = LLM_RETRY_BACKOFF[min(attempt, len(LLM_RETRY_BACKOFF) - 1)]
            # 打出来，别让重试变成"卡住不动"的静默等待（人会以为脚本挂了）。
            print(f"   ⚠️ 上游瞬时错误（{type(e).__name__} {e}）⇒ {wait:g}s 后重试，"
                  f"还剩 {left} 次（⛔ 这不是通过）", file=sys.stderr, flush=True)
            time.sleep(wait)
    try:
        return d["choices"][0]["message"]["content"] or ""
    except Exception:  # noqa: BLE001
        raise ReviewUnavailable(f"返回结构异常：{str(d)[:300]}")


def parse_findings(text: str) -> dict:
    """从模型返回里抠出那个 JSON 对象（容忍 ```json 围栏和前后废话）。"""
    s = (text or "").strip()
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.S)
    try:
        obj = json.loads(s)
    except json.JSONDecodeError:
        i, j = s.find("{"), s.rfind("}")
        if i < 0 or j <= i:
            raise ReviewUnavailable(f"模型没返回可解析的 JSON：{s[:300]}")
        try:
            obj = json.loads(s[i:j + 1])
        except json.JSONDecodeError as e:
            raise ReviewUnavailable(f"模型返回的 JSON 解析失败（{e}）：{s[:300]}")
    if not isinstance(obj, dict):
        raise ReviewUnavailable(f"模型返回的不是 JSON 对象：{s[:300]}")
    out = []
    for f in obj.get("findings") or []:
        if not isinstance(f, dict):
            continue
        cat = str(f.get("category", "other")).strip()
        out.append({
            "category": cat if cat in CATEGORIES else "other",
            "severity": str(f.get("severity", "medium")).strip().lower() or "medium",
            "targets": [str(t) for t in (f.get("targets") or []) if str(t).strip()],
            "finding": str(f.get("finding", "")).strip(),
            "suggestion": str(f.get("suggestion", "")).strip(),
        })
    return {"findings": out, "overall": str(obj.get("overall", "")).strip()}


# ── 双跑交叉验证 ────────────────────────────────────────────────────────
def _norm(s: str) -> str:
    return re.sub(r"[^0-9a-z一-鿿]+", "", str(s).lower())


def _key(f: dict) -> tuple:
    return (f["category"], tuple(sorted(_norm(t) for t in f["targets"])))


def _contained(fa: dict, fb: dict) -> bool:
    """同一类下，一条点名的成分是另一条的子集（且都非空）→ 判成同一个问题、只是圈定范围不同。

    🔴 为什么需要这条：实测同一份配方两跑都说"油性成分放在水/甘油体系里会分层"，
      但一跑只点 Black Seed Oil、另一跑点了 Black Seed Oil + Curcumin + D3 + K2 ——
      精确配对配不上；而中文句子做字符级相似度只有 0.35（中文本来就撑不起这个指标），
      文本兜底也够不着 → 同一条被拆成两条"两跑不一致"。假不一致多了，
      「⚠️ 可疑需人工判」这个标记就贬值了，真正该看的那条会被淹掉。"""
    ta = {_norm(t) for t in fa["targets"]}
    tb = {_norm(t) for t in fb["targets"]}
    return bool(ta and tb) and (ta <= tb or tb <= ta)


def cross_check(runs: list) -> list:
    """两跑对齐：两跑都报 = 一致；只有一跑报 = 🔴 可疑，需人工判。

    三级配对（一级比一级松，⛔ 别再往下放宽 —— 放太松会把两个不同问题并成一条，
    那比多报一条"不一致"危险得多）：
      ① (category + 成分名集合) 完全相同
      ② 同 category + finding 文本相似度 ≥ 0.75
      ③ 同 category + 成分名集合互为子集（见 `_contained`），此时标 scope_differs，
         两版描述都打出来给人看
    """
    if len(runs) == 1:
        for f in runs[0]["findings"]:
            f["agreement"] = "single"
        return runs[0]["findings"]

    a, b = runs[0]["findings"], list(runs[1]["findings"])
    merged = []
    for fa in a:
        scope_differs = False
        hit = next((fb for fb in b if _key(fb) == _key(fa)), None)
        if hit is None:                       # ② 精确配不上 → 文本相似度兜底
            hit = next((fb for fb in b
                        if fb["category"] == fa["category"]
                        and difflib.SequenceMatcher(None, _norm(fa["finding"]),
                                                    _norm(fb["finding"])).ratio() >= 0.75), None)
        if hit is None:                       # ③ 再兜一层：成分范围互为子集
            hit = next((fb for fb in b if fb["category"] == fa["category"]
                        and _contained(fa, fb)), None)
            scope_differs = hit is not None
        fa = dict(fa)
        if hit is not None:
            b.remove(hit)
            fa["agreement"] = "both"
            if scope_differs:
                fa["scope_differs"] = True
                fa["targets_run2"] = hit["targets"]
                fa["finding_run2"] = hit["finding"]
            if _norm(fa["suggestion"]) != _norm(hit["suggestion"]) and hit["suggestion"]:
                fa["suggestion_run2"] = hit["suggestion"]
        else:
            fa["agreement"] = "only_run1"
        merged.append(fa)
    for fb in b:                              # 只有第二跑报出来的
        fb = dict(fb)
        fb["agreement"] = "only_run2"
        merged.append(fb)
    return merged


# ── 输出 ────────────────────────────────────────────────────────────────
def _bar(ch="=", n=64):
    print(ch * n)


def report(merged: list, runs: list, ctx: dict) -> None:
    _bar()
    print("m7 配方 LLM 顾问（review_facts.py）—— 🔴 只报不拦，结论交人判")
    _bar()
    print(f"配方文件 : {ctx['path']}  ·  模块 {ctx['module']}  ·  mode={ctx['mode']}")
    print(f"模型     : {REVIEW_FACTS_MODEL}（deepkey 文本组）· temperature=0 · 跑 {ctx['runs']} 遍")
    print(f"本地算的 : 每份固形物 {ctx['total_mg']} mg ≈ {round(ctx['total_mg'] / 1000.0, 4)} g"
          f"  ·  serving_size={ctx['serving_size']}  ·  {len(ctx['rows'])} 行成分")
    print(f"DV 表    : {ctx['dv_reason']}")
    if not ctx["dv_ok"]:
        print("           🔴 DV 表缺失/不可用 → **本次不做任何 DV 相关判断**（⛔ 不许让模型凭记忆算）")
    if ctx["runs"] == 1:
        print("           ⚠️ --runs 1：**没做交叉验证**，所有条目都只有一次结论，可信度更低")
    print()

    if not merged:
        print("✅ 顾问未提出任何配方层面的问题。")
    else:
        order = {"both": 0, "single": 0, "only_run1": 1, "only_run2": 1}
        sev = {"high": 0, "medium": 1, "low": 2}
        merged = sorted(merged, key=lambda f: (order.get(f.get("agreement"), 1),
                                               sev.get(f.get("severity"), 1)))
        for cat, label in CATEGORIES.items():
            items = [f for f in merged if f["category"] == cat]
            if not items:
                continue
            print(f"── {label} ── {len(items)} 条")
            for f in items:
                icon = SEV_ICON.get(f["severity"], "⚠️")
                tgt = " / ".join(f["targets"]) or "(未点名成分)"
                if f.get("agreement") in ("only_run1", "only_run2"):
                    flag = "  🔴【两跑不一致 → 可疑，必须人工判】"
                elif f.get("agreement") == "both":
                    flag = ("  （两跑一致，但点名成分范围不同 ⚠️ 两版都看）"
                            if f.get("scope_differs") else "  （两跑一致）")
                else:
                    flag = "  （单跑，未交叉验证）"
                print(f"  {icon} [{f['severity']}] {tgt}{flag}")
                print(f"       现象：{f['finding']}")
                if f.get("finding_run2"):
                    print(f"       现象(第二跑，成分范围 {' / '.join(f.get('targets_run2') or [])})："
                          f"{f['finding_run2']}")
                if f["suggestion"]:
                    print(f"       建议：{f['suggestion']}")
                if f.get("suggestion_run2"):
                    print(f"       建议(第二跑给的另一版)：{f['suggestion_run2']}")
            print()

    for i, r in enumerate(runs, 1):
        if r.get("overall"):
            print(f"总体印象(第{i}跑)：{r['overall']}")

    print()
    _bar("─")
    print("⛔ 本脚本【没有】做下面这些 —— 它们归 check_facts.py（纯代码硬闸门）：")
    print("   %DV 计算 · 单位换算 · DV 表逐条比对 · ®/™ 商标扫描 · source 必填")
    print("   （原因：模型算 %DV 会用训练语料里的旧 DV 表 = 用会漂的东西检查会漂的东西）")
    print("🔴 本脚本是【顾问不是判官】：以上全是建议，采纳与否由人定。退出码恒为 0。")
    print("🔴 跑的时机：配方定稿 / 设计稿签字阶段跑一次，⛔ 不进出图循环（LLM 不可复现）。")
    _bar("─")


def not_run_banner(reason) -> None:
    """🔴 没跑成 —— 醒目说明 + 退出码 2。⛔ 绝不能安静退 0（verify_label 栽过这个跟头）。"""
    bar = "🔴" * 32
    print("\n" + bar)
    print("🔴  review_facts 【没跑成】—— 这**不是**「配方没问题」，是**根本没查**。")
    print(f"🔴  原因：{reason}")
    print("🔴")
    print("🔴  怎么办（三选一，⛔ 别当没这回事直接出图）：")
    print("🔴   1. 配上 deepkey【文本组】凭据：DEEPKEY_TEXT_BASE_URL / DEEPKEY_TEXT_API_KEY")
    print("🔴      （⛔ 别拿生图组 DEEPKEY_IMAGE_* 顶替，那组里没有文本模型）")
    print("🔴      自查：python3 scripts/check_env.py")
    print("🔴   2. 让 agent（Claude / Codex）直接读 m7.facts，按本脚本 docstring 里那五类逐条过一遍")
    print("🔴   3. 人工过一遍：剂型装不装得下 · 成分有没有重复/别名 · 剂量有没有触 UL · 合不合产品定位")
    print("🔴")
    print("🔴  退出码 2 = 没跑成。⛔ 别把它当 0 处理。")
    print(bar)


# ── main ───────────────────────────────────────────────────────────────
def main() -> None:
    global REVIEW_FACTS_MODEL
    p = argparse.ArgumentParser(
        description="m7 配方 LLM 顾问（第二层，只报不拦）。硬闸门在 check_facts.py，⛔ 两者不可互替。",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="退出码：0=跑完了（有无问题都是 0）  ·  2=🔴 没跑成（云不可用/没凭据/没数据），⛔ 绝不当通过")
    p.add_argument("product", type=Path, help="product.json（或一份只含 facts 的 json）")
    p.add_argument("--module", default="m7", help="模块键名，默认 m7")
    p.add_argument("--dv-table", type=Path, default=DV_TABLE_DEFAULT,
                   help=f"锁定的 DV 表，默认 {DV_TABLE_DEFAULT}；缺失则本次不做任何 DV 判断")
    p.add_argument("--runs", type=int, default=2, choices=(1, 2),
                   help="跑几遍做交叉验证，默认 2（1 = 省一半钱但没有交叉验证）")
    p.add_argument("--model", default=None, help=f"覆盖模型名，默认 {REVIEW_FACTS_MODEL}")
    p.add_argument("--json", type=Path, default=None, help="把结构化结果另存一份 JSON")
    p.add_argument("--print-prompt", action="store_true", help="只打印将要发出的提示词，不调 API（自查用）")
    args = p.parse_args()

    if args.model:
        REVIEW_FACTS_MODEL = args.model

    try:
        facts, positioning = load_facts(args.product, args.module)
        rows = facts.get("rows") or []
        total_mg, skipped, bad = local_solids(rows)
        dv_text, dv_reason = load_dv_table(args.dv_table)
        user = build_user_prompt(facts, positioning, dv_text, dv_reason, total_mg, skipped, bad)

        if args.print_prompt:
            print(SYSTEM_PROMPT)
            print("\n" + "=" * 64 + "\n")
            print(user)
            sys.exit(EXIT_OK)

        runs = []
        for i in range(args.runs):
            # 🔴 两跑用**不同 seed**：同 seed 跑两遍走的是同一条路径，交叉验证就白做了。
            #    temperature=0 下两跑本就高度相似，交叉验证抓的正是那点残余抖动。
            runs.append(parse_findings(call_llm(SYSTEM_PROMPT, user, seed=7 + i)))

        merged = cross_check(runs)
    except ReviewUnavailable as e:
        not_run_banner(e)
        sys.exit(EXIT_NOT_RUN)

    ctx = {"path": str(args.product), "module": args.module, "mode": facts.get("mode", "(未填)"),
           "runs": args.runs, "total_mg": total_mg, "serving_size": facts.get("serving_size", "(未填)"),
           "rows": rows, "dv_reason": dv_reason, "dv_ok": bool(dv_text)}
    report(merged, runs, ctx)

    if args.json:
        args.json.write_text(json.dumps({
            "script": "review_facts.py", "advisory_only": True, "exit_code": EXIT_OK,
            "model": REVIEW_FACTS_MODEL, "runs": args.runs,
            "dv_table_loaded": bool(dv_text), "dv_table_note": dv_reason,
            "local_total_solids_mg": total_mg,
            "not_covered_here": ["%DV", "unit_conversion", "dv_table_diff",
                                 "trademark_scan", "source_required"],
            "not_covered_by": "check_facts.py",
            "findings": merged,
            "overall": [r.get("overall", "") for r in runs],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\n结构化结果已写入：{args.json}")

    sys.exit(EXIT_OK)   # 🔴 只报不拦：跑完了就是 0，⛔ 不许因为"模型说有问题"挂失败


if __name__ == "__main__":
    main()
