#!/usr/bin/env python3
"""V2 场景替换法【一键出图 glue】：渲底图 → 换真产品 → 锁文案 → 位置检查，串成一条命令。

为什么要它（Bowen 2026-07-31 定 V2 = 默认出图路径，抠图降级为"主动提出才走"）：
  V2 出一张有产品的图要顺序跑这几步——
    ① render.py 渲【文案+版式全对、产品是占位件】的底图
    ② gen_image.py --scene 把【真产品】换进占位处（免抠图）
    ③⁰ check_copy_ocr.py **文案审核官**（🆕 I-72，2026-08-17 起 = 默认路径）：读 ② 归一后的 `_fit`，
       核我方每条文案 AI 有没有画错。**通过 ⇒ 这张不 overlay，`_fit` 直接就是成品**
       （不叠 ⇒ 结构上不可能双影）；不过 ⇒ 重掷 ②（COPY_OCR_RETRIES 轮）；掷尽仍不过 ⇒
       照常出图 + 收尾【待用户确认】清单。见下面 COPY_OCR 那段大注释。
    ③ overlay_copy.py 把 HTML 纯文案层叠回去（--scene 重绘会改我方文案 → 叠回锁死）
       🔴 I-72 起它**只在 `RENDER_V2_COPY_OCR=0`（老路）时才跑** —— 无条件叠 = 主动给每张图
          制造双影机会（overlay 是「盖」不是「擦」），还多烧一次 Chrome。
    ③½ check_scene_text.py 查 --scene 有没有把【我方文案】也重绘了 = 双影（P1-9/P1-10）
       🔴 V2-6（2026-08-06）：这一步【没跑成】（检测器缺失/中间件缺失/跑挂）一律按废图、退出码 1。
          它是"双影图被交付"的唯一通道，宁可整批停下，⛔ 不许静默放行。
       🔴 I-72：它查的是【③ overlay 造成的双影】⇒ 与 ③ 同进退，同样只在老路上跑。
          ⛔ 别读成"新路径跳过了检测"：没叠就没有双影源，不是没查。
    ③½R 检出双影就【自动重掷】②→③→③½（V2-7，默认 2 轮，见 SCENE_RETRIES；同样只在老路上）
    ④ check_layout.py 查产品没压到文字（🔴 判据 = 本模块有没有【产品图槽】，见下）
       🔴 I-72：④ **两条路都跑** —— 产品压字与文案审核是**两件事**，⛔ 别跟着 ③ 一起关掉。
    ⑤ check_product_spec.py 查**产品包装上原厂印的规格数字**（净含量/粒数）有没有被 `--scene` 改
       （🆕 I-74，2026-08-17；实证 d1：源图 `NET WT. 360G` → 成品 `300G`，而 `(12.70 OZ)` 没变
        ⇒ 自相矛盾，四道检查当时全绿放行）。只跑【产品由 AI 重绘】的模块，比的是**最终成品**
        ⇒ 默认路径与 `RENDER_V2_COPY_OCR=0` 老路**都盖到**。三态：通过 / 被改判废 /
        「未自动校验」（没跑成、**或跑成了但产品区一个 token 没读到 / 各尺度判定不一致**——
        🆕 I-83；⛔ 既不静默放行也⛔ 不假报）。收尾那句「已机器核过」**只对真核到的模块打**。
        关掉：`RENDER_V2_SPEC_CHECK=0`。
    ⑥ 🆕 I-85 背景连续性兜底检测（**只对补过边的详情页跑**）：G-2「复制边缘」补边会在有斜切的
       背景上造一条假边界，AI 平滑它时向上侵入内容区 ⇒ 裁回后斜切线断掉（d1 实测最后约 50px）。
       比对成品 ⇄ 底图在补边带内的背景分界。🔴 **告警级，⛔ 不判废、⛔ 不挂退出码**。
  手跑漏一步就出错图（尤其同事 Windows/Codex）。本脚本把 5 步串成一条命令，按 product.json
  的每模块 `swap` 段自动带上【真产品图 + 要替换的物体(subject)】，跑完提示放大核产品印刷小字。

  没有 `swap` 段的模块（m3/m4/m5/m6/**m7**、d4-d9 等通用件）= 无产品要换 → 只 render，底图直接就是成品。
  🔴 m7（营养成分表，2026-08-09 新增）**必须**走这条路：`product.json` 里⛔ 不许给它写 `swap` 段。
     一张全是数字的表交给 `--scene` 重绘 = 必然出假数据（实测史：`20g Sachet`→`Saciet`、钾 `22`→`23`）。
     它是纯 HTML 矢量渲染，不调 AI、不花钱。

前置：先 `build.py <product.json> -o <build> [--only …|--detail-all]` 出好构建目录。
  占位产品 = product.json 的 `images` 槽指向的【库存抠好的透明件】（Bowen 定：可复用现成抠图当占位）。
  产品【位置】由占位件 + layout 决定，换产品不改位置 → 所以 check_layout 跑在【底图】上依然有效。

`swap` 段长这样（写在每个有产品的模块里，见 assets/schemas/*.example.json）：
    "swap": {
      "product": "../library/product-assets/mango/mango-tin-white.png",   // 真产品图（白底/实拍都行）
      "subject": "the black round tin in the center",                     // 换掉场景里哪个物体
      "elements": [                                                        // 可选：产品色载体/配件一起换
        {"product": "../library/render/scenes/mango-splash.png", "subject": "the fruit splash on the left"}
      ],
      "mode": "composite",                                                 // 可选：本模块改走【合成法】，见下
      "spec_box": [x, y, w, h],                                            // 可选（I-81⒊）：⑤ 的产品区人工兜底框
      "hide": ".pcard img"                                                 // ⚠️ 只在 RENDER_V2_COPY_OCR=0 老路有效
    }
  🆕 `spec_box`（I-81⒊）= ⑤ check_product_spec 的产品区**人工收窄框**（成品像素坐标，原点左上），
     原样透传成 `--box x,y,w,h`；不写就让脚本自己用 DOM 探针定。产品区定不准（框偏了 / 把左侧
     文案栏吞进来）时用它，⛔ 别再靠改 `mode: composite` 去绕开一个假报。
  ⚠️ `hide`（给 overlay 用的"这些元素别盖"）在**默认路径上是死键**（I-86⒉）：I-72 之后 ③⁰ 通过
     就不 overlay ⇒ 它一行代码都走不到。脚本见到它会打一行 🟠 点名（⛔ 不静默作废用户的意图）；
     真想让徽章/小字像素级清晰，正解是 `mode: composite`。
  真产品图默认从本模块 swap.product 取；没写就回退顶层 product.swap_image（一款一张、全模块共用时省重复）。

🔴 双影（我方英文文案被 `--scene` 重画并位移）与它的**三级处置阶梯**（V2-7，Bowen 2026-08-06 定；
   与国内 skill v2.26 对称，⛔ 两站口径必须一致）：
  病理：`--scene` 会把底图【整张重绘】，连我方英文文案一起重画并位移，③ overlay 再把原文案**盖**回去，
  盖不掉 AI 在旁边多画的那一份 ⇒ 两层文案错位重叠 = 双影。文案密集的模块（m1/m2/d1）易中。
  🔴 但它是**随机走样、不是必然** —— 整改前的旧版一张双影图都没交付过，靠的正是
     references/scene-swap.md「任一条不过 → 废弃重跑，别硬用」那条**人工返工纪律**。所以：
    ① **重掷这一张 `--scene`**（③½R 已自动做 SCENE_RETRIES 轮，默认 2）—— 首选，成本 ≈¥0.12/张。
    ② 重掷用尽还中 ⇒ 结构病（文案压产品区/太密）→ 改版式（先跑 check_layout）后重出。
    ③ **mode:composite 合成法** —— 兜底，⛔ 不是双影的常规解（依赖 cutout.py 抠图，同事机器上不稳；
       Bowen 2026-08-06：「抠图这条路不行，还是走 V2」）。
  🔴 composite 仍然**首选**的两类（与双影无关，直接写、不用先重掷）：
     【**产品自印**小字要分毫不差】（净含量/营养成分表：AI 每次都改，重掷没用）、【详情页要全分辨率清晰】。

🆕 `"mode": "composite"` = 本模块走【合成法】，不走 V2（整改 P1-10，2026-08-05；与国内 skill 对称）：
  合成法 = 把**抠好的透明产品图**直接放进模板的 `{{IMG_MAIN}}`/`{{IMG_D1_MAIN}}` 槽，build→render
  一把渲出来，**全程不调 AI**：没有重绘就没有双影，且全分辨率像素精确。
  · 给了 mode:composite ⇒ 本脚本**跳过 ② --scene 和 ③ overlay_copy**，该模块只走 ① render，底图即成品。
  · **不给 mode = 现有默认行为（V2）**，一个字没变。
  · mode 只认 "composite" 这一个值，写错会**硬失败点名**（⛔ 不静默当默认——静默正是这次要堵的病）。

🔴 ④ check_layout 的判据 = 【本模块有没有产品图槽】，不是「有没有 swap 段」（整改 P1-11）：
  原判据是 `key in PRODUCT_DETAIL`（只有 d1/d3）⇒ 合成法件、无 swap 但有产品图的件、以及主图
  m1/m2 全部【整个跳过压字检查】。而合成法恰恰是**换了真产品几何**的时刻——2026-08-05 那次
  真产品比占位件宽 **1.48 倍**，m1 的袋子直接切过大标题 ASHWAGANDHA 的字底，没有任何闸门拦住。
  现在判据 = 该模块 `images` 里有没有抠图槽（main/second/scene/product/anchor 结尾，
  复用 build.py 的 CUTOUT_SLOT_RE，与白底守卫同一口径）。

用法:
    python render_v2.py <product.json> <build_dir> -o <out_dir> --modules m1 m2 d1 d3
    python render_v2.py product.json build/ -o out/ --modules m1          # 单张
    python render_v2.py product.json build/ -o out/                       # 不带 = 主图 6 张（有 m7.html 则 7 张）
    python render_v2.py product.json build/ -o out/ --detail-all          # 详情页 12 块
    # 想要抠图法：只在用户/同事明确要求像素级精确时走，见 references/cutout.md（默认路径是本脚本的 V2 场景替换）。
"""
import argparse, json, math, os, re, shutil, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from statistics import median   # 🆕 I-85 背景断线检测的 Theil-Sen 稳健拟合（⛔ 不引 numpy）

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （必须 import：修 Windows 管道输出下 emoji 崩溃）
from build import DETAIL_HEIGHTS, DETAIL_FULL, TEMPLATE_FILES, CUTOUT_SLOT_RE

SKILL = Path(__file__).resolve().parent.parent
SCRIPTS = SKILL / "scripts"
PY = sys.executable or "python"

# 🆕 P1-9：双影检测器。🔴 V2-6：**它不在 = 硬失败**（不是告警更不是通过）—— 见 _check_scene_text。
SCENE_TEXT = SCRIPTS / "check_scene_text.py"
# 🔴 V2-6 验收时逮到的真坑：**检测器自己崩了，Python 的退出码也是 1** —— 与"真检出双影"撞码，
#    会让同事对着一张【根本没查过】的图去加 mode:composite、白烧一轮。所以退出码 1 还要认这句
#    检出证据（check_scene_text.py 检出分支的固定措辞，⛔ 改那边的话这里要同步改）。
SCENE_HIT_MARK = "检出【我方文案被 --scene 重画并位移】"

# 🆕 m7（营养成分表，2026-08-09）：**停机询问码**。契约 §7 的退出码约定 ——
#   0=通过 · 1=数据错误(真错误) · 2=没跑成 · **3=需要人答复**（商标成分未获 Bowen 同意）。
# 🔴 为什么非得单开一个码、⛔ 绝不能和 1 合并：`1` 已被"真错误"占死。V2-6 刚踩过一模一样的坑
#   —— check_scene_text.py 自己崩了也退 1，与"真检出双影"撞码，同事对着一张【根本没查过】的图
#   加 mode:composite、白烧一轮。停机询问撞上真错误更糟：人会去"修"一个不存在的 bug，
#   而真正要做的只是**去问 Bowen 一句话**（"KSM-66 能不能用？"）。
# 🔴 处置口径（与 _check_scene_text 的三态同构）：3 = **不是失败、不是通过**，是第三种状态 ——
#   横幅**原样透传**给用户、整脚本以 3 退出，⛔ 不摘要、⛔ 不改写、⛔ 不塞进 fails 里当"某模块挂了"。
FACTS_STOP_CODE = 3


class StopForHuman(RuntimeError):
    """子脚本退出码 3 = 需要人答复（商标成分未获同意）。banner 里装的是它**原样**的输出。

    ⛔ 别在 except 里把它当普通 RuntimeError 吃掉 —— process() 有一条**先于** `except Exception`
       的专门分支接它（顺序写反了就会退回"某模块失败"，正是这个码要避免的混淆）。"""

    def __init__(self, cmd: list, banner: str):
        self.cmd = cmd
        self.banner = banner
        super().__init__(banner)

# 🆕 P1-10：swap.mode 的合法取值。省略 = V2（默认，行为一字未改）；"composite" = 合成法（跳过 ②③）。
COMPOSITE = "composite"

# 🆕 并发出图（Bowen 2026-07-31）：TokenStation 实测支持 4 路真并发（4 张≈1 张的时间）→ 提速约 3-4 倍。
# 每模块内部 render→--scene→overlay→check 仍串行；模块之间并发。RENDER_V2_WORKERS 可覆盖（1=串行）。
WORKERS = max(1, int(os.environ.get("RENDER_V2_WORKERS", "4")))

# 🔴 V2-7（Bowen 2026-08-06，与国内 skill v2.26 对称）：③½ 检出双影后【自动重掷 --scene】的轮数。
#   为什么是"重掷"而不是"改合成法"：双影 = `--scene` 每次重绘我方文案时的**随机走样**，不是必然。
#   🔴🔴 2026-08-17 限定（I-24 G-2 落地后订正，⛔ 别再把上面那句当全称）：
#     「随机走样」只对**没被各向异性拉伸**的模块成立 —— 也就是主图 m1–m7（画布 1000² ↔ 模型 1024²，等比）。
#     **详情页在 G-2 之前的双影里有一份是【几何必然】**：模型按档位比返回、却被硬塞回目标比
#     ⇒ 内容整体被拉走 ⇒ overlay 用模板写死坐标必然盖不住（d1 16.5% … d7/d8 62–68%，按实测比 1.4906 算）。
#     那一份**重掷多少轮都躲不掉**（每一掷都被同一个拉伸再糟蹋一次）—— 这也是同事反馈"双影 100% 出现"的由来。
#     ⇒ G-2 已从源头消掉它。现在还检出双影，才重新是上面说的那种随机走样。
#     ⛔ 别因为"以前重掷没用"就去改 mode:composite —— 那是在为一个已经修掉的病付抠图/毛边的代价。
#   整改前的旧版从没把双影图交付出去过 —— 靠的正是 references/scene-swap.md 那条
#   「任一条不过 → 废弃重跑，别硬用」的人工返工纪律。本常数只是把那条纪律接进脚本。
#   合成法要先有干净透明抠图件，而 cutout.py 在同事机器上不稳（Bowen 2026-08-06：「抠图这条路不行，
#   还是走 V2，抠图在同事电脑上不稳定，但是 V2 基本上是没有问题的」）⇒ ⛔ 它是第 3 级兜底、不是常规解。
#   成本：每重掷一张 = 1 次 gen_image 调用（≈¥0.12）。设 0 = 关掉自动重掷（回到只报不修的旧行为）。
#   ⛔ 封顶 5 轮：这个数直接换算成真金白银（重掷是真调 API），手滑打成 999 不该让脚本照跑。
SCENE_RETRIES = min(5, max(0, int(os.environ.get("RENDER_V2_SCENE_RETRIES", "2"))))

# ══════════════════════════════════════════════════════════════════════════════
# 🆕 ③⁰ 文案审核官（整改 I-72，2026-08-17；取代"一律 overlay"，与国内 skill v2.8+ 对称）
#
# 病灶（Bowen 2026-08-16 原话）：「所有图出来后**无论文案是否漂，都会默认走 overlay**，
#   这样实质上是浪费资源，把没有问题的图进行二次更改。」—— 改之前 process() 里 ③ overlay_copy
#   **没有任何条件判断**，每个走 V2 的模块必跑。
# 🔴 比"浪费"更重一层：**叠了才有双影风险，不叠结构上就没有**。overlay 是【盖】不是【擦】，
#   盖不掉 AI 在旁边多画的那一份 ⇒ 无条件叠 = 主动给每一张图制造双影机会（还多烧一次 Chrome）。
# ⇒ 新的默认路径：**内容对就直接用**（不 overlay ⇒ 结构上不可能双影）；内容错才重掷；
#   掷尽仍错 ⇒ 照常出图 + 收尾【待用户确认】清单（⛔ 不默认退回 overlay、⛔ 不默认切 composite ——
#   两者代价完全不同，判定权在用户）。
#
# 🔴 这条路换来的代价，⛔ 别自作主张改回去：**放弃版式与字体的像素级一致**。
#   AI 的字是模仿的，整块位置会漂几到二十几 px（国内实测 6~24px）。
#
# 🔴 `--after` 传的必须是 **`_fit`**（G-2 归一裁回画布之后那张），⛔ 不是 `_swapped`（模型原始返回）：
#   判据③ 贴边告警按画布边缘量像素，拿比例不对的原始返回图去量，判据会错。
#
# 成本：check_copy_ocr 在 **macOS 走系统 Vision（离线、零费）**，Windows/Linux 才走云 OCR
#   （deepkey **文本组**凭据，⛔ 不是生图组）。相对它省掉的一次 Chrome overlay，基本是净赚。
#
# 关掉它 = **逐像素回到"一律 overlay"的老行为**：RENDER_V2_COPY_OCR=0
COPY_OCR = SCRIPTS / "check_copy_ocr.py"
COPY_OCR_ON = os.environ.get("RENDER_V2_COPY_OCR", "1") != "0"
# 审核不过时重掷几轮。⛔ 封顶 5（与 SCENE_RETRIES 同款钳制）：每轮都是真金白银（1 次 gen_image）。
# 🔴 国际站的现状要认（⛔ 别把国内那句"重掷前先改提示词"照抄成事实）：
#   **本站 gen_image.py 没有 `--keep-text` 参数**（argparse 里根本没有这一项），
#   所以这里的重掷目前**就是原路重掷** —— 国内 2026-08-13 实测原路重掷错得一模一样。
#   ⇒ 重掷分支会**每轮点名警告**这件事。
#   ⛔ 别在本文件里"顺手"把 keep_text 拼进 subject 硬造一个透传：那是给 gen_image.py 的提示词
#     工程，要连同 `swap.keep_text` 的 schema 一起在 gen_image.py 那边做（已列进报告）。
#
# 🔴🔴 **所以默认值是 0，不是国内那个 2**（2026-08-17 定，⛔ 别"为对称"改回 2）：
#   国内默认 2 是**建立在它有 `--keep-text` 的前提上**的 —— 它的阶梯是「先把点名字样写进
#   keep_text、**改了提示词**再掷」。本站没有那个参数 ⇒ 掷出去的提示词与上一轮**逐字相同**。
#   国内 t02 三掷实测：第 2 掷原路重掷**一字未改 → 同一位置同一种错法**；第 3 掷**点名 LIFEWORTH**
#   → 一掷就对。⇒ 原路重掷不是"成功率低"，是**机制上帮不上忙**。
#   默认 2 就等于**按设计每个没过的模块白烧 ≈¥0.24** 去做一件结构上不可能成功的事。
#   ⇒ 默认 0（审核不过就直接进【待用户确认】清单）。等 gen_image.py 补上 `--keep-text`
#     并接通之后，再把这个默认改回 2 —— **那时改才有意义**。
#   想手动试仍可 `RENDER_V2_COPY_OCR_RETRIES=2`。
COPY_OCR_RETRIES = min(5, max(0, int(os.environ.get("RENDER_V2_COPY_OCR_RETRIES", "0"))))

# ══════════════════════════════════════════════════════════════════════════════
# 🆕 ⑤ 产品规格闸门（整改 I-74，2026-08-17；判据在 check_product_spec.py 里，本文件只接线）
#
# 病灶（2026-08-17 真出图当场逮到，⛔ 不是推演）：`--scene` 会改**产品包装上原厂印的规格数字**。
#   实证：d1 源产品图印 `NET WT. 360G` `(12.70 OZ)` → 成品变成 `NET WT. 300G` `(12.70 OZ)`
#   —— 12.70 oz = 360.0 g，两个数字**自相矛盾**；而净含量是买家下单要看的规格。
#   而管线里**没有任何机器闸门守这一层**，四道检查全绿放行：
#     · ③⁰ check_copy_ocr 按设计**只核我方 HTML 文案**，不核产品自印字；
#     · ④ check_layout 只查产品压没压住文字；· qc.py 只量颜色配比；
#     · verify_label.py **根本不在本脚本链路里**（只是 QC 清单上的人工步骤）。
#
# 🔴 只跑【产品由 AI 重绘】的模块 = 有 swap 且 mode != composite（也就是走 V2 的那些）。
#   composite 件的产品像素是**原样贴**进模板槽的、无 swap 的通用件根本没有产品 —— 两者机制上
#   不可能被改数字，跑它们纯烧 OCR。⛔ 别为"覆盖率好看"给它们也接上。
#   （落地形式：这两条路在 process() 更上面就 return 了，所以下面根本走不到，不用额外判断。）
#
# 🔴 必须拿【最终成品图】去比，⛔ 不是 `_fit`、⛔ 不是 `_swapped`：
#   ③⁰ 通过的默认路径成品 == `_fit` 的副本，但 `RENDER_V2_COPY_OCR=0` 的老路成品是 **overlay 的产物**。
#   接在 `final` 上，两条路自动都盖到（落点就在 ④ check_layout 旁边，共用同一份 build/html/size）。
#
# 🔴 三态处置（⛔ 别一刀切，这三条路代价完全不同）：
#   0 = 通过 → 放行。但它 stdout 里的 ⚠️ 告警（判据②「300G 与 12.70OZ 换算差 20%」之类）
#       **原样打给人看**，⛔ 别吞（本文件的 out.append 收的就是它的全文）。
#   1 = 规格被改 → **阻断，与 ④ check_layout 的 FAIL 同级**：判废、进 _bad、退出码非 0。
#   2 = 没跑成 → **不算失败也不算通过**。照常走完、图照出，但收尾**单独记一笔**
#       「本模块规格未自动校验」+ 原样透传它自己打的人工核对清单。
#       🔴 ⛔ 别当 0 静默放行（那是这套 skill 反复在治的病）；⛔ 也别当 1 假报 ——
#         Windows 云 OCR 不可用就落在这里，`verify_label` 旧版正是这么假报的（v1.20 才修好）。
#
# 成本：macOS 走系统 Vision（离线、零费，可随便跑）；Windows/Linux 落 deepkey 文本组云 OCR。
# 关掉：`RENDER_V2_SPEC_CHECK=0`（命名/写法对齐 RENDER_V2_COPY_OCR）—— 关掉时控制流与接线前**逐条相同**。
SPEC_CHECK = SCRIPTS / "check_product_spec.py"
SPEC_CHECK_ON = os.environ.get("RENDER_V2_SPEC_CHECK", "1") != "0"

# 🔴 并发必须按模块分端口（2026-08-04 定位的"半成品底图"根因）：
#   render.py / overlay_copy.py / check_layout.py 各自起 http.server 喂 Chrome，端口是全局写死的默认值
#   （8747 / 8792 / 8748），且启动前都会 free_port() 抢占端口（找占用者 → kill）。
#   4 路并发时线程 B 的 free_port 会杀掉线程 A 正在服务的 server → A 的 Chrome 拿到 404 → 渲出空白/半成品底图
#   （现场警报＝render.py 那句"体积偏小疑似 404"）。所以按【模块序号 idx】给每模块一组互不冲突的端口。
#   按 idx 而非线程号分配 = 重跑时端口稳定，便于排查。TEMPLATE_FILES 共 **20** 个模块
#   （2026-08-09 新增 m7 营养成分表；--modules 可全选，idx 最大 19）
#   → 本脚本占用 **8620–8679** 这 60 个端口（PORT_BASE + idx*3，算法不动，只挪基数）。
#   🔴🔴 **这 60 个口现在正好用满**（2026-08-18 订正，G 组逮到）：60 ÷ 3 = **20 个模块**，
#     而 TEMPLATE_FILES 此刻正是 20 个（m1–m7 + 详情页 13 块），idx 0..19 → 最后一组 8677/8678/8679。
#     ⇒ **再加第 21 个模块就会溢出 8679 这一段**（8680 及以上不在下面那四条验算的覆盖范围里，
#       ⛔ 别默认它是空的：要么先把这一段整体挪到【8747 以下】的别处，要么把 8680+ 按下面
#       ①②③④ 重新逐条验算一遍）。
#       ⛔ 别以为"还有余量"顺手 append 一个模块进 TEMPLATE_FILES。
#   🔴 两条上限**不是同一件事，⛔ 别混**：
#     · 【段内上限】= 20 个模块（8620–8679 这 60 个口，已用满）—— 这才是现在挡路的那条；
#     · 【绝对上限】= 8620 + (模块数-1)*3 + 2 < 8747 ⇒ 模块数 ≤ **42**（不是 43！）。
#       43 个模块 ⇒ idx 最大 42 ⇒ 端口 **8746 / 8747 / 8748** —— 后两个正好骑上 render.py(8747)
#       与 check_layout.py(8748) 的默认口（下面 ① 那条）；42 个 ⇒ idx 最大 41 ⇒ 8743/8744/8745，安全。
#     超了就得整段往【8747 以下】另找位置，⛔ 别往上挪。
#
# 🔴🔴 I-74（2026-08-17）新接的 ⑤ check_product_spec **也要起 Chrome + http.server**（它的 DOM 探针），
#   但它**复用 p_check、⛔ 没有把每模块的端口数从 3 改成 4**。理由是【可证明】的，不是图省事：
#   （a）**时间上不重叠**：同一模块的 ③½ / ⑤ / ④ 都在**同一个线程里 subprocess.run 串行**跑完
#        （run 阻塞到子进程退出，退出即释放端口）⇒ 三者共用一个口不可能互抢。
#        这不是新发明：③½ check_scene_text 从 V2-6 起就一直复用 p_check，同一条理由。
#   （b）**改成 idx*4 会当场废掉派活表**：`SKILL.md §主图 Step 3 跑法 B`、`references/pitfalls.md §11`、
#        `references/main-images.md` 三处白纸黑字写着 **m1 8620 / m2 8623 / m3 8626 / …**（步长 **3**；
#        7 个 subagent 各跑一张时 idx 恒为 0，全靠这张表错开）。每模块改占 4 个口以后，
#        拿 8623 的那位会一路占到 8626 —— 正是拿 8626 那位的 render 口 ⇒ free_port 的 `kill -9` 原样重演，
#        而且**没有任何代码会报错**（那三份文档本轮不许动；改了代码不改文档 = 埋雷）。
#   ⇒ 端口段仍是 **8620–8679**，上界算式**一个字没变**：上界 = 8620 + (模块数-1)*3 + 2 < 8747 ⇒ 最多 **42** 模块
#     （⛔ 不是 43，见上面那段订正；而段内实际卡死在 20 个模块 = 8679）；
#     RENDER_V2_PORT_OFFSET 的「一档 100 个口够用」那条也不受影响（仍是每模块 3 个口）。
#   ⛔ 哪天真要给 ⑤ 单开端口：先把上面三份文档的派活表改成步长 4，再回来改这里 —— 两件事必须同一轮做完。
#
# 🔴 为什么偏偏是 8620（挪基数前把这段读完，别再随手改）——本区间必须与下面【每一项】错开：
#   ① 子脚本的默认端口：render.py 8747 / check_layout.py 8748 / overlay_copy.py 8792。
#      V2 内部全部显式传端口，但同事手工单跑 render.py / check_layout.py（或跑 build.py 生成的
#      render_detail.sh|.bat —— 那些不带 --port）时会撞进本区间，双方互抢 → 又出"半成品底图"。
#   ② 国内 skill（lifeworth-b2b-image/.../b2b-image-domestic-skill）的端口族：它按槽位分配
#      `{render 8747, overlay 8792, check 8748} + slot*10`（CHROME_WORKERS 决定槽数），
#      并且每个 Chrome 会话还要一个 CDP 端口 = 上述端口 + 1000×(1+组序号) ⇒ 9747 起。
#      两套 skill 同机并行出图很常见，撞上就是互杀重演。
#      （曾经把基数挪到 8800 是【错的】：国内 overlay 从 slot 1 起就是 8802/8812/8822…、
#        render 从 slot 6 起是 8807/8817… 全落在 8800–8856 内。）
#   ③ 两套 skill 的 references/pitfalls.md 都教人"手工并发时用 8801/8802/8803"。
#   ④ 本脚本自己的旧基数 8700（8700–8756，同事手上可能还跑着旧版 skill）。
#   8620–8679 一次性满足全部四条，而且理由是【可证明】的而非"看着没撞上"：
#   【国内】skill 所有会被分配到的端口（含 CDP）都 ≥ 8747，且分配式只会往上加，
#   所以任何槽位数/模块数下都不可能落到 8747 以下 —— 8620–8679 整段永远安全。
#   ⛔ 真要挪，只能继续往【8747 以下】挪，别往上；往上就得重新逐条验算上面四项。
PORT_BASE_DEFAULT = 8620

# 🆕 整组端口偏移 `RENDER_V2_PORT_OFFSET`（2026-08-13，移植自国内 skill 同名变量）：
#   病史（国内实测，国际站至今 0 命中 —— 但同源实现、同样会多款并发，属于"没炸只是运气"）：
#   **同时跑多个 render_v2 实例**（三款产品各起一条命令）时，两个进程各自 enumerate 自己的模块列表
#   ⇒ idx 都从 0 数起 ⇒ 算出【同一组端口】⇒ 后启动的那个 free_port() 把前一个【正在服务】的
#   http.server `lsof -ti | kill -9` ⇒ 前一个的 Chrome 取图 404 / 截到**别人构建目录里的正常图**
#   （体积正常、QC 正常、产品是别款的 —— pitfalls §11 那种"抓不住"的翻车）。
#   —— 就是上面那段跨线程互杀的**跨进程版本**；PORT_BASE 按 idx 分端口只在【一个进程内】有效，治不了它。
#
# 🔴 国际站的接法与国内【不一样】，⛔ 别照抄国内那一行（国内是三个基数各自 `+ offset` 直接往上加）：
#   国内的 {8747, 8792, 8748} 一族坐在所有端口的最上面、分配式只加不减，往上平移 100/200 天然安全；
#   国际站的 8620–8679 头顶 **8747 是上面逐条验算过的不可逾越线** —— 往上 +100 就是 8720–8779，
#   直接骑到 8747/8748（render.py / check_layout.py 的默认口）上，等于把互杀换个姿势重演。
#   往下也没地方落：8580–8619 是手工并发段、8500–8559 是 build.py 一次性脚本段，各有其主。
#   ⇒ 国际站的语义是【改锚】而不是【平移】：offset 非 0 时整组挪到低位专用区 `8000 + offset`
#     （100→8100 / 200→8200 / 300→8300）。该区间两套 skill 全库零占用（所有既有段位都 ≥8500），
#     也避开了 8080 这类常见开发端口。offset=0（默认/未设）时端口**逐字节不变**，仍是 8620 那组。
#   🔴 为什么取 **100 的倍数**：一组最多占 `8000+offset` 起的 60 个口（20 个模块 × 3），
#     60 < 100 ⇒ 相邻两个实例永不重叠。⛔ TEMPLATE_FILES 涨过 **33** 个模块后这条就不成立了
#     （`(模块数-1)*3 + 2 ≥ 100`），到时得同步改步长，别只改模块数。
#   ⛔ 封顶 **300**（默认组之外再给 3 个实例，够"三款产品并发"）：400 段里有 8443（HTTPS-alt，
#     本机常被别的服务占）、500 段直接撞 build.py 的 8500–8559。要更多实例请手工给 RENDER_V2_PORT_BASE。
# 🔴 与 RENDER_V2_PORT_BASE 的关系：**显式设了 PORT_BASE 就以它为准，OFFSET 被忽略并打提示** ——
#   PORT_BASE 是「7 个 subagent 各跑一张、idx 恒为 0」那张派活表用的（pitfalls §11：m1 8620 / m2 8623…），
#   两个变量同时生效会把派好的端口整组挪走，等于把那张表作废。两种跑法本来就 ⛔ 不该同机同时跑。
_PORT_OFFSET_STEP, _PORT_OFFSET_MAX, _PORT_OFFSET_ANCHOR = 100, 300, 8000


def _port_offset() -> int:
    """读 `RENDER_V2_PORT_OFFSET`，非法值一律**回落 0 + 打告警**，⛔ 绝不抛异常。

    为什么不学 WORKERS 那行裸 `int(os.environ.get(...))`：那是**模块导入期**求值，
    `RENDER_V2_PORT_OFFSET=abc` 会让整脚本连 `--help` 都 traceback 崩掉，
    而端口偏移恰恰是同事手打命令行时现敲的（打错的概率远高于代码里写死的默认值）。
    回落到 0 = 回到默认端口段：并发隔离没生效，但至少不比【没设这个变量】更糟。"""
    raw = (os.environ.get("RENDER_V2_PORT_OFFSET") or "").strip()
    if not raw:
        return 0
    try:
        n = int(raw)
    except ValueError:
        print(f"⚠️ RENDER_V2_PORT_OFFSET={raw!r} 不是整数 → 按 0 处理，端口回到默认段 "
              f"{PORT_BASE_DEFAULT}–{PORT_BASE_DEFAULT + 59}（多实例并发就没隔离了，注意别同机再起一条）。")
        return 0
    if n <= 0:
        if n < 0:
            print(f"⚠️ RENDER_V2_PORT_OFFSET={n} 是负数 → 按 0 处理（端口回到默认段 {PORT_BASE_DEFAULT}）。")
        return 0
    # ⛔ 先钳上限、再取整到步长（顺序反了的话 99999 会先被打成 99900、再被钳成 300，白打一条告警）。
    if n > _PORT_OFFSET_MAX:
        print(f"⚠️ RENDER_V2_PORT_OFFSET={n} 超过封顶 {_PORT_OFFSET_MAX} → 按 {_PORT_OFFSET_MAX} 处理"
              f"（再往上撞 8443 / build.py 的 8500–8559）。要更多并发实例请改用 RENDER_V2_PORT_BASE。")
        n = _PORT_OFFSET_MAX
    if n % _PORT_OFFSET_STEP:
        n2 = n // _PORT_OFFSET_STEP * _PORT_OFFSET_STEP
        print(f"⚠️ RENDER_V2_PORT_OFFSET={n} 不是 {_PORT_OFFSET_STEP} 的倍数 → 向下取整到 {n2}。"
              f"🔴 别拿 100/150 这种去区分两个实例 —— 它俩会取整到同一段、当场互杀。")
        n = n2
    return n


PORT_OFFSET = _port_offset()
if "RENDER_V2_PORT_BASE" in os.environ:
    # 显式基数优先（派活表场景）；两个都设了要点名说清楚谁生效，⛔ 别静默吃掉一个。
    if PORT_OFFSET:
        print(f"ℹ️ 同时设了 RENDER_V2_PORT_BASE 和 RENDER_V2_PORT_OFFSET={PORT_OFFSET} "
              f"→ **以 PORT_BASE 为准**，本次忽略 OFFSET（派活表按 PORT_BASE 分口，见 pitfalls §11）。")
        PORT_OFFSET = 0   # ⛔ 归零：留着非 0 会让下面那行运行时提示报出一段【根本没在用】的端口区间。
    PORT_BASE = int(os.environ["RENDER_V2_PORT_BASE"])
else:
    PORT_BASE = PORT_BASE_DEFAULT if not PORT_OFFSET else _PORT_OFFSET_ANCHOR + PORT_OFFSET


def _run(cmd: list, out: list) -> None:
    """跑子脚本，输出【收集进 out】（并发时按模块缓冲，避免多路 print 交织）。失败 raise（不 sys.exit，线程安全）。

    🔴 成功时也要收 stderr（2026-08-04）：render.py 的"引用逃出了构建目录"提示走 stderr 且退出码是 0
       （那类引用无法验证、查了必误报 → 策略是跳过检查+打醒目提示，见 render.py check_assets）。
       只收 stdout 的话，这条提示在 V2 这条【默认出图路径】上 100% 丢失，正好掉回"不报错、只安静
       出错图"那一类。非空才 append（正常情况下子脚本不写 stderr，不会刷屏）。
       失败时【不在这里】收：stderr 已由下面的异常带走，再 append 会同一段打两遍。

    🆕 退出码 3 = **停机询问**（不是失败）：原样打包成 StopForHuman 抛出，由 main() 统一透传。
       ⛔ 在这里就 append 会让横幅混在一大堆渲染日志中间被淹没 —— 契约要的是"醒目"。"""
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode == FACTS_STOP_CODE:
        raise StopForHuman(cmd, ((r.stdout or "") + (r.stderr or "")).rstrip())
    if r.stdout.strip():
        out.append(r.stdout.rstrip())
    if r.returncode != 0:
        raise RuntimeError(f"步骤失败（退出码 {r.returncode}）：{' '.join(str(c) for c in cmd)}\n{r.stderr.rstrip()}")
    if r.stderr.strip():
        out.append(r.stderr.rstrip())


def _dims(key: str) -> tuple:
    """每模块的 (宽, 高, scale)。主图 1000×1000 @1x；详情页 750×锁死高 @2x。"""
    if key.startswith("m"):
        return 1000, 1000, 1
    return 750, DETAIL_HEIGHTS[key], 2


def _gen_size(w: int, h: int) -> str:
    """gpt-image 只吃这几个尺寸；挑最贴近【送图】长宽比的那一档。

    🔴 G-2 之后调用方传的是【补边后】尺寸 pw×ph（不是原画布 tw×th）—— 补边正是为了让这一步
       挑出的档位与送图比例真正一致。⛔ 别改回传 w/h：那等于把补边计划和请求尺寸对不上。"""
    if w == h:
        return "1024x1024"
    return "1536x1024" if w > h else "1024x1536"


# ══════════════════════════════════════════════════════════════════════════════
# 🆕 G-2 比例对齐（整改 I-24，2026-08-17；原样移植国内 skill 的同名实现，Bowen 2026-08-13 定）
# ------------------------------------------------------------------------------
# 病灶（**几何必然，不是概率**）：
#   gen_image.py 的 `ALLOWED_SIZES` 只有 1:1 / 3:2 / 2:3 ⇒ 模型只会返回这三种比例的图。
#   而 ② 拿回来的图**原来是无条件** `resize((w*scale, h*scale))` —— 模型按【档位比】返回，
#   却被硬塞回【目标比】= **各向异性拉伸**。逐模块拉伸量（本 skill 2026-08-16 实测算出）：
#     · 主图 m1–m7（画布 1000×1000 ↔ 模型 1024×1024）：**0%**，等比 —— 所以这个病
#       在主图上从来没现过形，一直只在详情页发作。
#     · 详情页**全中**（按**实测比 1.4906** 算，⛔ 不是理论 1.5 —— 早先按 1.5 算的一版偏低）：
#       d5 3.5% · dfac 3.8% · d3 5.7% · d2 7.1% · d1 16.5% · drev 14.4% · dc 15.9% · d6/d9 19.8%
#       · d4 20.2% · df 21.0% · **d7 62.3% · d8 67.7%**
#   后果两条，都不是随机：
#     （a）**产品被拉胖/拉瘦**且脚本一声不吭（国内实测 t01 纸盒宽高比量到 0.482 vs 真值 0.408）；
#     （b）**双影**：内容被拉伸 ⇒ AI 重绘的我方文案与模板【写死的坐标】对不上 ⇒
#          ③ overlay_copy 盖不住那份被拉走的字 ⇒ 两层文案错位重叠。**结构性必然** ——
#          ③½R 重掷 N 轮也躲不掉（每一掷都被同一个拉伸再糟蹋一次）。
#     🔴 所以 SCENE_RETRIES 那段注释里「双影 = 随机走样」的说法，只对**没被拉伸**的模块成立。
#        详情页在 G-2 之前的双影里有一份是这个几何原因，⛔ 别再一律按"重掷就好"处置。
#
# 解法（国内 2026-08-13 手工跑通：band 完整、标题完整、内容零裁切）：
#   ① 送图前把底图**补边**成模型【实际会返回】的比例
#   ② 补边用**复制首末行/列**延展 —— ⛔ 不许纯色填充（会在底图的对角渐变上压出一条硬边，
#      AI 把那条硬边当构图线重绘）；⛔ 不许镜像填充（会把我方文案镜像出来，AI 当成真内容重绘进画面）
#   ③ 送 `--scene`（比例已合法 ⇒ 模型返回图与补边底图同比例）
#   ④ 回来先归一到【补边后尺寸】，再把补的边**原样裁掉** ⇒ 精确逆变换、逐像素回到原画布。
#
# 🔴 国际站与国内的**唯一实现差异**（⛔ 别照抄国内那条，也⛔ 别哪天"顺手补上"）：
#   国内 t 系列走 `--tier 2k` 把补边吃掉的 ~16% 有效分辨率补回来；**国际站的 gen_image.py 是
#   1K-only** —— `DEFAULT_MODEL["deepkey"] = "gpt-image-2-1k"`、`_norm_size` 明写「默认 1K、禁 2K」、
#   argparse 里**根本没有 `--tier` 这个参数**（传了会直接报错）⇒ 本文件 tier **一律 "1k"**，
#   下面 MEASURED_ASPECT 也**只存 1k 那三档**。
#   ⛔ 别为对称而补 2k 那几行：那会是一个国际站永远走不到、却会随模型漂移而**静默腐坏**的常量。
#   代价要说清楚，别当没有：详情页 @2x 画布 1500 宽，模型 1k 返回本来就只有 ~1264 宽
#   （改动前就在上采样 1.19×），补边后内容区占比再降一截。实测：内容区占比 **59.6%(d8) – 96.6%(d5)**；
#   上采样比 **land 族基本不变 1.187**，但 **sq 族 d4/df/dc 由 1.187 升到 1.465 ＝ +23%**、drev 1.711
#   ⇒ 这四张边缘**明显更软**，⛔ 别写成「略软」（首版就是这么低估的，独立回检逮到）。
#   ⚠️ 但这**远好于**上面那 15–66% 的各向异性拉伸：拉伸是形变 + 必然双影，上采样只是软一点。
#   要全分辨率清晰仍然走 `mode: composite`（那条路根本不调 AI）。
ASPECT_TOL = 0.02                                    # 比例容差：≤2% 视为「就是这个比例」，走老路不补边
NOMINAL_ASPECTS = (1.0, 1536 / 1024, 1024 / 1536)    # 1:1 / 3:2 / 2:3 —— 与 gen_image.py 的 ALLOWED_SIZES 一一对应
                                                     # ⚠️ 只用来【选哪一族】，⛔ 不拿它当补边目标（见下）

# 🔴 **模型返回的不是精确 3:2**（2026-08-13 国内实测，deepkey `gpt-image-2-1k`，请求 `--size 1536x1024`）：
#      1k → 1264×848 = **1.4906**
#   补边如果按理论值 1.500 算，回来这 0.6% 残差会被下面的 cover 居中裁掉 ⇒ **上下各再切掉约 10px@2x
#   真内容**，而且是静默发生的 —— 正是这一轮在治的那类细微裁切。所以补边目标一律取**实测值**。
#
# 🔴 为什么按【族, 档】的元组做键、而不是只按族：与国内 skill 逐字对齐，将来两站对比 diff 时
#   能一眼看出"国际站少的就是 2k 那几行"（而不是"结构不一样，得重读一遍"）。
#   ⚠️ **方图 / 竖图两档都没实测过**：方图按 1.0（请求 1024² 返方图，未见反例），竖图按横图取倒数。
#     ⛔ 别把它们当已验证值写进任何文档 —— 真跑到时会被下面 ④ 的 ASPECT_DRIFT_WARN 自校正告警
#     逮出来点名（"实测常量可能过期，改成 X"），那行告警就是这两档的兜底。
#   （现有模块里 `drev` 画布 1500×1752 = 0.856，按对数距离落的是 **sq 族**、不是 port —— port 那档
#     目前**没有任何模块会走到**，留着是为了新模块出现时不至于 KeyError。）
MEASURED_ASPECT = {
    ("land", "1k"): 1264 / 848,    # 1.4906  实测 2026-08-13（deepkey gpt-image-2-1k，请求 1536x1024）
    ("sq", "1k"): 1.0,             # 未实测（假定精确方图）
    ("port", "1k"): 848 / 1264,    # 未实测（按横图取倒数）
    # ⛔ 别加 ("*","2k")：国际站 gen_image.py 是 1K-only，那几行永远走不到、只会腐坏。
}
ASPECT_DRIFT_WARN = 0.005     # 返回比例 vs 补边目标偏差 >0.5% ⇒ 实测常量可能过期，出声（⛔ 别静默吞）
RESIDUAL_STRETCH_MAX = 0.02   # 残差 ≤2% ⇒ 精确归一（形变看不出）；>2% ⇒ 落回 cover+裁切并告警


def _family(a: float) -> str:
    """画布比例落在哪一族（只按名义比例选族；补边目标另取实测值）。"""
    ta = min(NOMINAL_ASPECTS, key=lambda x: abs(math.log(a / x)))   # 对数距离：等价于「补边面积最小」
    return "sq" if ta == 1.0 else ("land" if ta > 1.0 else "port")


def _pad_plan(tw: int, th: int, tier: str = "1k") -> tuple:
    """画布 tw×th → (补边后宽, 补边后高, 左补, 上补, 补边目标比例)。
    比例已经就是模型会返回的那个 ⇒ 原样返回 + 0 补边（老行为一字不变，主图 1000² 走这条）。

    只往**一个方向**补：比例偏扁就补高、偏高就补宽 —— 补的永远是「短的那一边」，
    ⛔ 绝不缩内容。补边量对半分（左右/上下各一半，余数给下/右），逆变换时按同一份计划裁回。
    🔴 目标比例取 MEASURED_ASPECT[族, 档]（**实测值**，不是理论 1.5）—— 见上方注释。"""
    a = tw / th
    fam = _family(a)
    if (fam, tier) not in MEASURED_ASPECT:
        # ⛔ 硬失败点名，别回落到理论值：静默用 1.500 正是上面那段红字要堵的 0.6% 残差裁切。
        raise RuntimeError(
            f"MEASURED_ASPECT 里没有 ('{fam}', '{tier}') 这一档 —— 国际站只支持 tier='1k'"
            f"（gen_image.py 是 1K-only，没有 --tier 参数）。别在这里回落理论比例，先补实测值。")
    ta = MEASURED_ASPECT[(fam, tier)]
    if abs(a - ta) / ta <= ASPECT_TOL:
        return tw, th, 0, 0, ta
    if a > ta:                       # 画布比目标扁 → 补高
        pw, ph = tw, round(tw / ta)
    else:                            # 画布比目标高 → 补宽
        pw, ph = round(th * ta), th
    return pw, ph, (pw - tw) // 2, (ph - th) // 2, ta


def _pad_edge(src: Path, dst: Path, pw: int, ph: int, left: int, top: int) -> tuple:
    """把 src 补边到 pw×ph 存成 dst，补出来的部分 = **复制首末行/列**延展。返回实际 (原宽, 原高)。

    ⛔ 别改成纯色/镜像填充：纯色会在底图对角渐变上压出硬边，AI 当构图线重绘；
    镜像会把我方文案镜像出来、AI 当成真内容重绘进画面。复制边缘 = 把渐变的最外一行拉长，
    视觉上是同一片底，AI 没有可抓的"新构图信息"。
    🔴 **纯 Pillow、零 numpy**（I-76，2026-08-17）：`_pad_plan` 只往【一个方向】补 ⇒ 永远不用填四个角
       ⇒ 把最外一行/列 `crop` 出来用 **NEAREST** 拉伸即可。NEAREST 在 1px 源上是逐像素照抄、
       **不插值** ⇒ 与老 numpy 版**逐像素相同**（3 张真图 × 7 组补边参数实测 md5 全一致，
       见 `CHANGELOG.md` v1.43）。**目的**：把 numpy 移出**默认出图路径** —— 缺 numpy 不再是
       "每张 V2 图都挂"，只剩 cutout.md / packaging-cleanup.md 两处诊断脚本受影响。
       ⛔ 这**不是** SKILL.md「禁止静默降级」说的那种降级：那条堵的是"缺依赖就临时改用糙算法"，
       这里没有回落分支、也没有精度损失，只有一条经实测等价的实现。
       ⛔ 别把 numpy 加回来当"更稳"：它在 scripts/ 里当年就这一个用点。
       ⛔ `NEAREST` 不许省：默认 BICUBIC 目前虽也等价，但那是 Pillow 实现细节，写死才是契约。"""
    from PIL import Image
    im = Image.open(src).convert("RGB")
    w, h = im.size
    bot, right = ph - h - top, pw - w - left
    out = Image.new("RGB", (pw, ph))
    out.paste(im, (left, top))
    N = Image.NEAREST
    if top:
        out.paste(im.crop((0, 0, w, 1)).resize((w, top), N), (left, 0))
    if bot:
        out.paste(im.crop((0, h - 1, w, h)).resize((w, bot), N), (left, top + h))
    if left:
        out.paste(im.crop((0, 0, 1, h)).resize((left, h), N), (0, top))
    if right:
        out.paste(im.crop((w - 1, 0, w, h)).resize((right, h), N), (left + w, top))
    out.save(dst)
    return w, h


# ══════════════════════════════════════════════════════════════════════════════
# 🆕 I-85（2026-08-18）背景连续性兜底检测 —— G-2 补边**自己造出来的**那道断线
#
# 病灶（2026-08-17 Bowen 目检圈出 + 逐行取证）：`_pad_edge` 用【复制边缘】补边，复制出来的边是
#   **平的** ⇒ 在有斜切的背景上等于人为造了一条「斜切突然变垂直」的假边界；AI 去平滑这条假边界，
#   而平滑**向上侵入真实内容区**，裁回后断线留在成品里。
#   d1 实测（底图 ⇄ 成品，斜切分界 x）：y796 412→354 · y808 402→346 · y820 394→346 ·
#   y832 386→346 · y844 378→346 · y856 370→346 —— 底图匀速左移一路到底，成品 y≈812 冻死成
#   垂直线，最后约 50px 斜切线是断的。
#
# 🔴 为什么六道闸门一道都没抓到 —— **没有一道在看背景**：③⁰ 只比文字内容 · ⑤ 只比产品自印数字 ·
#   ④ 只查产品压不压字；唯一沾边的 ③⁰ 判据③【贴边】只扫画布最外 0.6%（d1 约 5px）且只找
#   笔画/硬边这类局部异常点 —— 而断线在离底边 50px 处、方向还相反（斜切**消失**、背景变得更均匀）。
#
# 🔴🔴 **告警级，⛔ 绝对不接退出码**（I-08/I-09 的教训：新闸门第一版假报率高，接了退出码就是把人
#   训练成无视告警）。它也**不进 `_bad`、不改抬头行的 ✅**，只出声。
# 📌 **只在真补过边时才跑**（pad>0）：主图 1000² 目标比 1:1 无需补边 ⇒ m1/m2/m7 结构上不可能有
#   这个瑕疵，一次都不跑 = 假报率天然为 0。⛔ 别为"覆盖率好看"给主图也开。
#
# 判据（纯 Pillow + 标准库，⛔ 不引 numpy —— 理由见 `_pad_edge` 的 I-76 那段）：
#   ① 只看**补边那一侧**从边往内 2×pad 这条带（补边区已经裁掉了，带内是它污染得最狠的地方）。
#   ② 每行用 1D 最优二分（最小化左右两段的平方误差和）定出**背景明暗分界 x** —— 比"取梯度最大点"
#      稳得多：文字/产品的局部硬边不会把整行的最优分割拉走。
#   ③ 底图那条分界必须**本身就是可跟踪的直线**（够对比度、离左右边够远、Theil-Sen 拟合内点 ≥70%）；
#      不成立 = 这条带里根本没有"背景结构"可比 ⇒ **不报警、出一行 ℹ️ 说明本条没覆盖到**
#      （⛔ 不是通过 —— 这套 skill 反复在治的正是"没查当成查过了"）。
#   ④ 成品在同一行、以底图分界为中心的窗口内定分界，得 Δ(y)。整张图被 AI 平移/重绘会让 Δ
#      **整体**偏一个常数（那是已知代价，不报）；这条断线的特征是 Δ 在带内**自己漂**（d1 实测
#      从 +120 漂到 -54）⇒ 判据 = Δ 的 P90−P10 超阈值就报。
BG_SEAM_DELTA_MIN = 10        # Δ 漂移阈值下限（px）
BG_SEAM_DELTA_FRAC = 0.015    # 或画布宽的 1.5%，取大者
BG_SEAM_CONTRAST = 6.0        # 分界两侧灰度均值差下限：低于它 = 这行没有背景分界，不参与


def _seam_split(row: list, lo: int, hi: int) -> tuple:
    """1D 最优二分：返回 (分界 x, 两段均值差)。O(W) 前缀和，⛔ 别改成 O(W²)（每模块要跑几十行）。"""
    n = len(row)
    s = [0.0] * (n + 1)
    q = [0.0] * (n + 1)
    for i, v in enumerate(row):
        s[i + 1] = s[i] + v
        q[i + 1] = q[i] + v * v
    best = bx = None
    for i in range(max(1, lo), min(n - 1, hi) + 1):
        cost = (q[i] - s[i] * s[i] / i) + ((q[n] - q[i]) - (s[n] - s[i]) ** 2 / (n - i))
        if best is None or cost < best:
            best, bx = cost, i
    return bx, abs(s[bx] / bx - (s[n] - s[bx]) / (n - bx))


def _check_bg_seam(key: str, base: Path, final: Path, pad_t: int, pad_b: int, out: list) -> list:
    """I-85 兜底检测：成品 ⇄ 底图 在补边带内的背景结构还对不对。返回报警的边名列表（"上"/"下"）。

    🔴 只出声、⛔ 不判废、⛔ 不挂退出码。调用方只把返回值拿去收尾汇总里再点一次名。
    ⛔ 别把它挪进重掷循环：一轮一次纯属浪费，判据要的是【最终裁回后】那一版。"""
    from PIL import Image
    hits = []
    try:
        b = Image.open(base).convert("L")
        f = Image.open(final).convert("L")
    except Exception as e:  # noqa: BLE001  告警级：自己挂了就说一句，⛔ 别拖累出图
        out.append(f"   ℹ️ {key}: 背景连续性检测没跑成（{e}）—— 告警级检测，不影响本张判定。")
        return hits
    if b.size != f.size:
        out.append(f"   ℹ️ {key}: 背景连续性检测跳过 —— 底图 {b.size} 与成品 {f.size} 尺寸不同。")
        return hits
    W, H = b.size
    k = max(1, round(W / 250))          # 降采样到 ~250 宽：抹掉文字笔画噪声，保住大结构
    bs = b.resize((W // k, H // k), Image.BOX)
    fs = f.resize((W // k, H // k), Image.BOX)
    w2, h2 = bs.size
    margin = max(2, int(w2 * 0.08))     # 分界离左右边太近 = 退化解（贴边），不算背景结构
    win = max(4, int(w2 * 0.08))        # 成品的搜索窗口（以底图分界为中心）
    thresh = max(BG_SEAM_DELTA_MIN, W * BG_SEAM_DELTA_FRAC)
    for lab, pad in (("上", pad_t), ("下", pad_b)):
        if not pad:
            continue
        rows_n = max(1, min(2 * pad, H // 3) // k)
        rows = range(0, rows_n) if lab == "上" else range(max(0, h2 - rows_n), h2)
        pts = []
        for y in rows:
            rb = list(bs.crop((0, y, w2, y + 1)).tobytes())   # mode "L" ⇒ 一行原始灰度字节
            xb, cb = _seam_split(rb, margin, w2 - margin)
            if cb < BG_SEAM_CONTRAST:
                continue                # 这一行没有背景明暗分界（纯色/全是内容）
            rf = list(fs.crop((0, y, w2, y + 1)).tobytes())
            xf, _ = _seam_split(rf, xb - win, xb + win)
            pts.append((y, xb, xf))
        tot = len(list(rows))
        if len(pts) < 8 or len(pts) < tot * 0.5:
            out.append(f"   ℹ️ {key}: 背景连续性检测【{lab}边补边带】没有可跟踪的背景分界"
                       f"（{len(pts)}/{tot} 行）—— 本条**没覆盖到这一带**，⛔ 不等于这一带没问题；"
                       f"交付前那 {2 * pad}px 仍要人眼扫一遍。")
            continue
        sl = median([(x2 - x1) / (y2 - y1) for (y1, x1, _) in pts for (y2, x2, _) in pts if y2 > y1])
        ic = median([x - sl * y for (y, x, _) in pts])
        tol = max(2.0, w2 * 0.01)
        inl = [p for p in pts if abs(p[1] - (sl * p[0] + ic)) <= tol]
        if len(inl) < 8 or len(inl) < len(pts) * 0.7:
            out.append(f"   ℹ️ {key}: 背景连续性检测【{lab}边补边带】底图那条分界不是直线"
                       f"（线性内点 {len(inl)}/{len(pts)}）⇒ 判据不适用，本条**没覆盖到这一带**，"
                       f"⛔ 不等于没问题。")
            continue
        d = sorted((p[2] - p[1]) * k for p in inl)
        lo, hi = d[int(len(d) * 0.1)], d[min(len(d) - 1, int(len(d) * 0.9))]
        if hi - lo > thresh:
            hits.append(lab)
            out.append(
                f"   🟠 {key}: 【{lab}边背景断线】—— 补边带内（离{lab}边 {2 * pad}px）成品的背景分界"
                f"相对底图漂了 {lo:+d}…{hi:+d}px（跨度 {hi - lo}px > 阈值 {thresh:.0f}px；"
                f"底图斜率 {sl / k:+.2f} px/行，{len(inl)} 行内点）。\n"
                f"      病理：G-2【复制边缘】补边在有斜切的背景上造出一条「斜切突然变垂直」的假边界，"
                f"AI 平滑它时**向上侵入真实内容区** ⇒ 裁回后这一带的斜切线是断的。\n"
                f"      👉 ① 先放大成品{lab}边那 {2 * pad}px 目检确认（🔴 **告警级，本条不判废也不挂退出码**"
                f"—— 第一版假报率未知，⛔ 别据此自动废图）。\n"
                f"      👉 ② 真断了：这个模块改 `\"mode\": \"composite\"` —— 背景由 HTML 渲、"
                f"根本不进 AI ⇒ 该失效模式结构上消失（I-86 的主解，详情页本来就该走这条）。\n"
                f"      ⛔ 别去重掷：断线是补边几何**必然**造出来的，不是随机走样。")
        else:
            out.append(f"   ✅ {key}: 背景连续性【{lab}边补边带】—— 分界漂移 {lo:+d}…{hi:+d}px"
                       f"（跨度 {hi - lo}px ≤ {thresh:.0f}px），斜切结构跟底图对得上。")
    return hits


def _clean(v: dict) -> dict:
    return {k: val for k, val in v.items() if not k.startswith("_")}


def _swap_of(key: str, spec_all: dict) -> dict:
    return _clean(spec_all.get(key, {}).get("swap", {}) or {})


def _swap_mode(key: str, spec_all: dict) -> str:
    """返回 "" (无 swap 段) / "v2" (默认路径) / "composite" (合成法)。P1-10。

    ⛔ 不认识的 mode **硬失败点名**：静默当默认正是这次要堵的病（写错一个字母就悄悄退回会双影的 V2）。
    🔴 只在 main() 的护栏区调用（串行、还没渲任何东西）—— sys.exit 在并发线程里会杀主进程。"""
    swap = _swap_of(key, spec_all)
    if not swap:
        return ""
    mode = swap.get("mode")
    if mode is None:
        return "v2"
    if mode == COMPOSITE:
        return COMPOSITE
    sys.exit(f"❌ {key}.swap.mode = {mode!r} —— 不认识这个取值。\n"
             f"   只支持 \"composite\"（合成法：抠图直接进 {{{{IMG_MAIN}}}} 槽，跳过 --scene 和 overlay，不调 AI）；\n"
             f"   要走默认的 V2 场景替换就【整个删掉 mode 这一行】，别写 \"v2\"/\"scene\"/空串。")


def _has_product_slot(key: str, spec_all: dict) -> bool:
    """本模块有没有【产品图槽】= ④ check_layout 的判据（P1-11）。

    🔴 判据不能是"有没有 swap 段"：mode:composite 的件、以及无 swap 但产品图直接进槽的件
       （合成法出的整套详情页就是这样），都会被漏掉 —— 而它们恰恰是**换了真产品几何**的时刻。
    槽名口径复用 build.py 的 CUTOUT_SLOT_RE（main/second/scene/product/anchor 结尾），
    与白底守卫同一套，避免两处各说各话；证书/图标/整幅照片槽（c1/p1/icons）不算产品。"""
    imgs = spec_all.get(key, {}).get("images", {}) or {}
    return any(not s.startswith("_") and CUTOUT_SLOT_RE.search(s.lower()) for s in imgs)


def _check_layout(key: str, build: Path, size: str, port: int, out: list) -> str:
    """④ 产品⇄文字重叠检查。跑在【构建目录 HTML / 占位件】上 —— 换产品不改位置，所以依然有效。

    🔴 stdout / stderr 【两者都收】（各自非空才收，与 _run 同一口径，2026-08-04）：
       原写法 `cl.stdout.rstrip() or cl.stderr.rstrip()` 是 or 短路 —— check_layout.py 只要
       先打过任意一行进度（stdout 非空），它随后抛的 traceback（走 stderr）就被整个吞掉，
       表现成"检查跑过了、没报警"，正是"不报错、只安静出错图"那一类。
    ⛔ 它若打「没找到产品图（试过 …）」——那是**要求你人工补查的信号，不是放行**（P1-12）。

    返回 "" = 通过 / "press" = 真压到文字 / "error" = 检查本身没跑成（重试过）。两种非空都挂退出码，
    但**措辞必须分开**：把"没跑成"说成"压到文字"，会让人对着 layout 改半天找不着北。
    🔴 2026-08-05 P1-15：**压字必须挂退出码**。此前它只打一行 ⚠️ 就放行，同一次跑里照打
       「✅ V2 成品 / ✅ 完成 N/N」+ 退出码 0 —— 独立回检实测复现，判定这与双影是**同一个病**
       （闸门看得见、流程放行、退出码说没事），也正是 08-05 那张 m1 压住大标题 80px 漏网的完整机制。
       ⛔ 别再以"既有行为"为由留着：闸门报了错却不挡交付，等于没有闸门。"""
    cl = subprocess.run([PY, str(SCRIPTS / "check_layout.py"), str(build), f"{key}.html",
                         "--size", size, "--port", str(port)],
                        capture_output=True, text=True)
    if cl.stdout.strip():
        out.append(cl.stdout.rstrip())
    if cl.stderr.strip():
        out.append(cl.stderr.rstrip())
    if cl.returncode == 0:
        return ""
    # 🔴 check_layout 对【环境故障】（探针没回传/服务器起不来/找不到 HTML）也是退出码 1。
    #    不区分就会把"检查没跑成"误诊成"产品压字"，让人对着 layout 改半天找不着北（独立回检提出）。
    #    两者都 fail-closed（都算失败、都挂退出码），但**措辞必须分开**。
    if "压到文字" in cl.stdout:
        out.append(f"   ❌ {key}: 产品压到文字 → 调 layout（缩小/右移产品件）后重跑 build + 本脚本。")
        return "press"
    # 🔴 「没跑成」先重试一次：实测 Chrome 的 --dump-dom 偶发回不来探针数据（"探针没回传数据"），
    #    并发时更容易撞上。⛔ 但重试仍失败就 fail-closed —— 检查没跑成不等于通过。
    cl2 = subprocess.run([PY, str(SCRIPTS / "check_layout.py"), str(build), f"{key}.html",
                          "--size", size, "--port", str(port)], capture_output=True, text=True)
    if cl2.returncode == 0:
        out.append(f"   ⚠️ {key}: 压字检查首次没跑成，重试通过（上面那条报错可忽略）。")
        if cl2.stdout.strip():
            out.append(cl2.stdout.rstrip())
        return ""
    if "压到文字" in cl2.stdout:
        out.append(cl2.stdout.rstrip())
        out.append(f"   ❌ {key}: 产品压到文字 → 调 layout（缩小/右移产品件）后重跑 build + 本脚本。")
        return "press"
    out.append(f"   ❌ {key}: 压字检查【没跑成】（不是压字本身，已重试一次）—— 看上面 check_layout 的报错，"
               f"多半是 Chrome/端口/构建目录的问题。⛔ 别去改 layout。")
    return "error"


def _check_product_spec(key: str, build: Path, src: Path, final: Path, size: str,
                        port: int, out: list, box: list = None) -> str:
    """⑤ 产品规格闸门（I-74 的接线；判据全在 check_product_spec.py 里，本函数只跑它 + 翻译三态）。

    比的是【源产品图 ⇄ 成品的产品区】里的规格数字（净含量/粒数/条数）有没有被 `--scene` 改掉。
    产品区靠 check_product_spec 自己的 DOM 探针定（复用 check_layout 的选择器），所以要给
    --build-dir/--html/--size；端口与 ④ 共用（同模块内串行，见 PORT_BASE 那段的 I-74 小节）。

    🔴 `final` 必须是【最终成品】：③⁰ 通过的默认路径成品 = `_fit` 的副本，
       `RENDER_V2_COPY_OCR=0` 老路的成品 = overlay 的产物 —— 传 final 两条路才都盖到。
    🔴 `src` = 本模块**换进去的那张源产品图**（swap.product，回退顶层 product.swap_image）——
       ⛔ 不是占位件、⛔ 不是竞品参考图。调用方传进来的就是 ② 送给 gen_image 的那个 --product。

    🆕 I-81⒊（2026-08-18）`box` = `swap.spec_box`（[x,y,w,h]）的人工兜底框，原样透传成 `--box`。
       没写就**不传**（脚本侧自己去定产品区），控制流与接线前逐条相同。
       它治的是 I-81 那条根因：⑤ 的产品区原来借用 ④ check_layout 的**宽选择器**（连 `img.scene`
       都收，注释自己写着"也会探进文字区"）—— 宽网当窄框用，m1 把文案栏吞进来判假红、
       d1 框偏 100px 一个 token 没读到却打 PASS。脚本侧改窄之后仍会有定不住的图，`spec_box`
       就是那时候让人**一行 JSON 收窄**的出口，⛔ 不用再退回 `mode: composite` 去绕开假报。

    返回四态（⛔ 别合并，处置完全不同）：
      "ok"        = **真核到了**（脚本侧 0 = 产品区读到了规格 token 且各尺度判定一致）。
                    🔴 I-83：这一态**只有它**能让收尾说"已机器核过"。它自己"只告警"的情况
                    （判据② 的换算矛盾）也在这一类，告警原文已经 append 给人看了，⛔ 别再吞一次。
      ""          = **本函数没跑**（SPEC_CHECK_ON 关掉 / composite / 无 swap）—— 见调用点。
      "bad"       = **规格数字被改** → 与 ④ 的 FAIL 同级：判废、进失败清单、退出码非 0
      "unchecked" = **没跑成 / 没核到**（退出码 2 / 工具缺失 / 成品图不在 / 它自己崩了）
                    🆕 I-83：脚本侧把「源图有规格 token 但产品区一个没读到」「各尺度判定不一致」
                    也一并改判成退出码 2 ⇒ 这两态从此走这条路，⛔ 不再混进 PASS。
                    → 🔴 **不算失败也不算通过**：图照出、流程照走，但收尾必须**单独记一笔**
                      「本模块规格未自动校验」。⛔ 别当通过静默放行（这套 skill 反复在治的病）；
                      ⛔ 也别当 "bad" 假报 —— Windows 云 OCR 不可用就落这里，
                      `verify_label` 旧版正是这么把同事的机器报成一片红的（v1.20 才修好）。
                      它自己会打一份人工核对清单（"并排放大到 300% 逐个核净含量…"），原样透传。"""
    if not SPEC_CHECK.exists():
        out.append(f"   🟠 {key}: 产品规格【未自动校验】—— 闸门缺失（{SPEC_CHECK.name} 不在 scripts/ 里，"
                   f"多半是 skill 没同步全 / 版本旧）。⛔ 这不是通过：这张产品自印的净含量/粒数"
                   f"有没有被 --scene 改过【根本没查过】。\n"
                   f"      👉 修：把 {SPEC_CHECK.name} 补回 scripts/（重新拉一份完整 skill）再重跑；\n"
                   f"      👉 在那之前**人工核**：源产品图与成品并排放大到 300%+，逐个核净含量"
                   f"(NET WT / g / oz)、粒数、条数 —— 有一个数字不一样就废掉重跑。")
        return "unchecked"
    if not final.exists():
        out.append(f"   🟠 {key}: 产品规格【未自动校验】—— 成品 {final.name} 不在，没有图可比。"
                   f"⛔ 别当成通过，往上翻这个模块前面几步的报错。")
        return "unchecked"
    if not src.exists():
        # 正常情况下走不到（② 之前已经校验过 product 存在），留着是防它在跑图期间被挪走/删掉。
        out.append(f"   🟠 {key}: 产品规格【未自动校验】—— 源产品图 {src} 取不到，没有"
                   f"「标准答案」可比。⛔ 别当成通过；改人工放大核净含量/粒数。")
        return "unchecked"
    cmd = [PY, str(SPEC_CHECK), str(final), "--src", str(src),
           "--build-dir", str(build), "--html", f"{key}.html",
           "--size", size, "--port", str(port)]
    # 🆕 I-81⒊：`swap.spec_box` 人工兜底框 → `--box x,y,w,h`。⛔ 没写就一个字都不加。
    if box is not None:
        if not (isinstance(box, (list, tuple)) and len(box) == 4
                and all(isinstance(n, (int, float)) and not isinstance(n, bool) for n in box)):
            out.append(f"   🟠 {key}: 产品规格【未自动校验】—— `{key}.swap.spec_box` 写成了 {box!r}，"
                       f"不是 4 个数字 [x, y, w, h]（成品像素坐标，原点左上）。⛔ 没拿它去猜，"
                       f"也⛔ 没退回宽选择器（那正是 I-81 的病灶）。\n"
                       f"      👉 改成 4 个数字再重跑；只想让脚本自己定框就【整行删掉】。")
            return "unchecked"
        cmd += ["--box", ",".join(str(int(round(n))) for n in box)]
        out.append(f"   📦 {key}: ⑤ 用 swap.spec_box 指定的产品区 "
                   f"x={int(box[0])} y={int(box[1])} w={int(box[2])} h={int(box[3])}"
                   f"（人工兜底，⛔ 不走 DOM 探针）。")
    r = subprocess.run(cmd, capture_output=True, text=True)
    # 🔴 stdout / stderr 都收（各自非空才收，与 _run/_check_layout 同一口径）：
    #    判据② 那条「300G 与 12.70OZ 换算差 20%」的 ⚠️ 是**通过时**打的，吞了等于把这道闸门
    #    最有价值的一半信息扔掉（它正是 d1 那张自相矛盾包装的现场证据）。
    if r.stdout.strip():
        out.append(r.stdout.rstrip())
    if r.stderr.strip():
        out.append(r.stderr.rstrip())
    if r.returncode == 0:
        # 🆕 I-83：0 == **真核到了**（脚本侧已把"漏读/多尺度打架"改判成 2）⇒ 这一态才是收尾
        #   那句"已机器核过"的唯一凭据。⛔ 别再返回 ""："" 现在专指【本函数没跑】。
        return "ok"
    if r.returncode == 1:
        out.append(f"   ❌ {key}: 产品包装上原厂印的【规格数字被改了】（净含量/粒数之类）——"
                   f"判为废图。\n"
                   f"      👉 ① 重掷这一张：⚠️ **多半没用** —— 产品自印小字 AI 每次都会改"
                   f"（这正是 references/scene-swap.md 里 composite 首选的两类之一）。\n"
                   f"      👉 ② 正解：给 {key}.swap 加 \"mode\": \"composite\" 走合成法"
                   f"（抠好的透明件直接进模板槽、全程不调 AI ⇒ 产品像素原样，规格不可能被改）。\n"
                   f"      ⛔ 别改我方 HTML 文案去"
                   f"「对齐」成品上的错数字 —— 那是把包装造假抄进 listing。")
        return "bad"
    if r.returncode == 2:
        # 🔴 它自己已经打过人工核对清单（上面原样透传了）。这里只补一句"这笔要记进收尾汇总"。
        out.append(f"   🟠 {key}: 产品规格【未自动校验】（{SPEC_CHECK.name} 退出码 2）——"
                   f"⛔ 不是通过、⛔ 也不是失败。原因看上面它自己的说明：没跑成"
                   f"（产品区定不了 / OCR 跑不了；Windows 云 OCR 不可用最常见），"
                   f"**或跑成了但产品区一个 token 都没读到 / 各尺度判定不一致**（🆕 I-83）。\n"
                   f"      👉 框没套准（--scene 每次都在移动放大产品，见 I-81）就给准框："
                   f"{key}.swap 加 \"spec_box\": [x, y, w, h]（成品像素坐标）再重跑；\n"
                   f"      👉 否则按上面那份人工核对清单核这一张，或修好 OCR 后重跑本脚本。")
        return "unchecked"
    out.append(f"   🟠 {key}: 产品规格【未自动校验】—— {SPEC_CHECK.name} 退出码 {r.returncode}，"
               f"不在契约的 0/1/2 里 ⇒ 多半是它自己崩了（看上面的 Traceback）。"
               f"⛔ 不当通过、⛔ 也别据此判废（这张有没有被改规格是**未知**的）。")
    return "unchecked"


def _check_scene_text(key: str, build: Path, base: Path, final: Path, size: str,
                      scale: int, port: int, out: list) -> str:
    """③½ 双影检查：`--scene` 有没有把【我方文案】一起重绘/位移（P1-9 的检测器，本脚本只负责接线）。

    🔴 必须跑在 ③ overlay 【之后】（⛔ 别挪到 ②③ 之间，国内首版就挪错过、等于空转）：
      判据 = ringExtra（笔画外圈新增墨迹）高 **且** lostInk（原字被改）低，二者是与关系。
      `lostInk ≈ 0` 成立的前提正是 ③ 把正确文案【原样盖】回去、字芯逐字节不动 ——
      双影就是"正确的字 + 旁边多出 AI 那份错位的残影"。拿 ③ 之前的 `_fit` 去比，
      那时图上只有 AI 那份错位文案 ⇒ lostInk 全线超标 ⇒ 一个 hit 都不会有 ⇒ 真双影被静默放行。
      所以 `--base` = v2/<key>_base.png（我方渲的底图，文案是对的），`--after` = 成品 out/<key>.png。
      ⛔ 别把删中间件挪到本步之前，`_base` 那时还要用。

    退出码契约（check_scene_text.py 定死，⛔ 别在这边自行改判）：
      0 = 未检出 · 1 = 检出双影（→ ③½R 自动重掷；掷尽仍在才谈改版式 / composite 兜底）
      · 2 = 没跑成（缺参数/Chrome 起不来）。

    🔴 V2-6（2026-08-06 Bowen 定调）：**三种「没能完成检测」一律 fail-closed（按废图处理）** ——
      ①检测器文件不在 ②中间件缺失没法比对 ③检测器跑挂了（退出码非 0/1）。
      改之前这三处都 `return False`（=通过），而②③的提示语里白纸黑字写着「⛔ 别当成通过」，
      紧接着那一行就把它收回去了 —— 正是本 skill 反复在治的「闸门说了实话、退出码不认」，
      而且是**双影图流到客户手上的唯一通道**（其余路径 composite/无 swap 机制上不可能双影）。
      ⛔ 别为了"别卡住出图"把它们改回 return ""：检查没跑成 ≠ 查过了没问题。
      代价是保守失败——检测器一坏整批停下；自救提示写在各分支的报错里（缺什么、怎么修）。

    端口：复用 ④ 那一个（check_layout 在本步之后才跑，同模块内串行、时间上不重叠），
      ⛔ 别新开硬编码端口 —— 撞上会被 free_port() 的 `lsof -ti | kill -9` 连客户端一起打死。

    返回（与 _check_layout 同构，⛔ 别改回 bool —— 「检出双影」和「没查成」要分开报，
      免得同事对着一张根本不存在的双影去改 layout / 加 mode:composite）：
      ""      = 查过了，未检出
      "bad"   = **检出双影**（→ 调用方 ③½R 自动重掷 SCENE_RETRIES 轮；掷尽仍在才是结构病）
      "error" = **没查成**（检测器缺失/中间件缺失/跑挂）→ 同样让 render_v2 非零退出。
      调用方必须把后两者都挂进退出码：2026-08-05 那次翻车正是"5 张废图 + 退出码 0"。

    🔴 V2-7：**"bad" 分支只报事实、⛔ 不在这里给处置建议** —— 本函数在 ③½R 自动重掷时会被
      **反复调用**，第一轮就喊「改 mode:composite」会让人在脚本还要自己掷两次的时候先动手改 JSON。
      完整的三级处置阶梯**只在重掷用尽后、由 main() 统一打印一次**。⛔ 别把建议搬回来。"""
    if not SCENE_TEXT.exists():
        out.append(f"   ❌ {key}: 双影检测【没跑成】—— 检测器缺失（{SCENE_TEXT.name} 不在 scripts/ 里，"
                   f"多半是 skill 没同步全 / 版本旧）。⛔ 不是通过：这张有没有双影【根本没查过】，"
                   f"按废图处理。修：把 {SCENE_TEXT.name} 补回 scripts/（重新拉一份完整 skill），再重跑本脚本。")
        return "error"
    missing = [p.name for p in (base, final) if not p.exists()]
    if missing:
        out.append(f"   ❌ {key}: 双影检测【没跑成】—— 中间件缺失（{' '.join(missing)}）没法比对，按废图处理。\n"
                   f"      多半是上一轮判废时中间件被删了（默认不 --keep）→ 重跑时加 `--keep` 保留 "
                   f"v2/{key}_base.png 等中间件，再重跑本脚本。⛔ 别当成通过。")
        return "error"
    cmd = [PY, str(SCENE_TEXT), str(build), key, "--base", str(base), "--after", str(final),
           "--size", size, "--port", str(port)]
    if scale != 1:
        cmd += ["--scale", str(scale)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    txt = ((r.stdout or "") + (r.stderr or "")).rstrip()
    if txt.strip():
        out.append(txt)
    if r.returncode == 1 and SCENE_HIT_MARK in txt:
        # 🔴 V2-7：**只报事实**（见 docstring 末段）—— 处置阶梯由 main() 在重掷用尽后统一打印一次。
        out.append(f"   ❌ {key}: 检出 --scene 重画了我方文案（双影）。")
        return "bad"
    if r.returncode == 1:
        # 退出码 1 但没打出检出证据 ⇒ 它是**崩在半路**（未捕获异常也退 1），不是查出了双影。
        out.append(f"   ❌ {key}: 双影检测【没跑成】—— {SCENE_TEXT.name} 退出码 1，"
                   f"但输出里没有检出证据（「{SCENE_HIT_MARK}」）⇒ 它多半是自己崩了（看上面的 Traceback）。\n"
                   f"      ⛔ 这【不是】双影，别去加 mode:composite。修好检测器后重跑。")
        return "error"
    if r.returncode != 0:
        out.append(f"   ❌ {key}: 双影检测【没跑成】（{SCENE_TEXT.name} 退出码 {r.returncode}）—— 按废图处理。\n"
                   f"      ⛔ 这【不是】双影，别去加 mode:composite、别去改 layout；"
                   f"这张有没有双影是**未知**的。\n"
                   f"      看上面检测器自己的报错（多半是 Chrome/端口/参数），修好后重跑；"
                   f"要单独复现：python scripts/{SCENE_TEXT.name} {build} {key} "
                   f"--base {base} --after {final} --size {size}"
                   + (f" --scale {scale}" if scale != 1 else "") + f" --port {port}")
        return "error"
    return ""


# 🆕 I-72：把闸门"具体哪几条没对上"抽出来，喂给收尾的【待用户确认】清单。
#   为什么要抽：清单只列模块名 = 又一份"看了也不知道该干嘛"的告警。用户要在三个选项里选
#   （补 keep_text 再掷 / 退回 overlay / 改 composite），得先看见错的是哪几条文案。
# 🔴 判据依赖 check_copy_ocr.py 的输出措辞，⛔ 改那边这里必须同步改（不同步 = 清单**静默变空**）。
#   锚点：`main()` 的 `if missing:` 分支那行 `      · 期望「…」  图上最接近的是「…」`
#   ⛔ **锚点只引函数名/特征字符串，别写行号**（I-69：行号式引用一律不许写，且实测 29% 已指错）。
# ⚠️ 国际站版 check_copy_ocr **没有判据②（禁词）**（理由见它的文件头：I-06 分面没做完，
#   拿 verify_copy 的表去扫 OCR 会把罐身上法定的 DSHEA 免责判成 4 条高危）⇒ 这里也就只解析"缺字"
#   这一种条目。⛔ 别为对称先把国内那段违禁词解析搬过来 —— 上游根本不会打那两行。
_COPY_MISS = re.compile(r"^\s*·\s*期望「(.+?)」")


def parse_copy_failures(stdout: str) -> list:
    """从 check_copy_ocr 的 stdout 里提「这一轮到底哪几条没对上」（去重保序）。"""
    items, seen = [], set()
    for line in stdout.splitlines():
        m = _COPY_MISS.match(line)
        if not m:
            continue
        it = f"我方文案对不上：「{m.group(1).strip()}」"
        if it not in seen:
            seen.add(it)
            items.append(it)
    return items


def _check_copy_ocr(key: str, build: Path, fit: Path, out: list) -> tuple:
    """③⁰ 文案审核（I-72 的接线；判据在 check_copy_ocr.py 里，本函数只负责跑它 + 翻译三态）。

    返回 (退出码, 没对上的条目 list)。**退出码三态，⛔ 绝不许合并**（调用方按它分三条路）：
      0 = 通过（我方文案逐条对得上）→ 跳过 ③ overlay，`_fit` 直接落盘即成品
      1 = 没通过（漏字/改字）      → 重掷 ②（COPY_OCR_RETRIES 轮）；掷尽仍不过 ⇒ 照常出图 + 待确认清单
      2 = 没跑成（OCR 挂了/缺凭据/提不出期望文案）
          🔴 **绝不等于通过，也 ⛔ 不拿它去重掷** —— 这张有没有被改字是**未知**的，
          重掷只是对着未知问题烧钱。判失败、挂非零退出码，逼人先把审核官修好。
          （撞码是这套脚本的老病：check_scene_text 曾因"崩了也退 1"害人对着没查过的图改版式。）

    ⛔ 前两种"跑不了"的情形也一律归 2，别静默当通过：
      · 审核官文件不在（skill 没同步全 / 版本旧）
      · `_fit` 不在（② 换产品没产出）—— 没有图可审
    退出码不在 {0,1,2} 里也归 2（子脚本崩在半路 / 被信号杀掉都可能）。

    成本：macOS 走系统 Vision，**离线、零费**；Windows/Linux 走云 OCR（deepkey 文本组）。
    ⛔ 不给它分端口：它不起 http.server、不碰 Chrome（纯读图），⛔ 别照着 ③½ 给它塞 --port。"""
    if not COPY_OCR.exists():
        out.append(f"   ❌ {key}: 文案审核【没跑成】—— 审核官缺失（{COPY_OCR.name} 不在 scripts/ 里，"
                   f"多半是 skill 没同步全 / 版本旧）。⛔ 不是通过：这张文案有没有被 AI 改过"
                   f"【根本没查过】。修：把 {COPY_OCR.name} 补回 scripts/ 再重跑；"
                   f"要临时退回「一律 overlay」的老路：RENDER_V2_COPY_OCR=0。")
        return 2, []
    if not fit.exists():
        out.append(f"   ❌ {key}: 文案审核【没跑成】—— 中间件 {fit.name} 不在（② 换产品没产出），"
                   f"没有图可审。⛔ 别当成通过，往上翻 ② 的报错。")
        return 2, []
    # 🔴 --after 传 `_fit`（G-2 归一裁回画布之后那张），⛔ 不是 `_swapped`：
    #    _swapped 是模型原始返回、比例与画布不同 ⇒ 判据③ 的贴边像素量法会错。
    r = subprocess.run([PY, str(COPY_OCR), str(build), key, "--after", str(fit)],
                       capture_output=True, text=True)
    txt = ((r.stdout or "") + (r.stderr or "")).rstrip()
    if txt.strip():
        out.append(txt)
    if r.returncode not in (0, 1, 2):
        out.append(f"   ❌ {key}: 文案审核【没跑成】（{COPY_OCR.name} 退出码 {r.returncode}，"
                   f"不在契约的 0/1/2 里）—— 多半是它自己崩了（看上面的 Traceback）。"
                   f"⛔ 不当通过、⛔ 不重掷。")
        return 2, []
    return r.returncode, (parse_copy_failures(txt) if r.returncode == 1 else [])


def _keep_text_of(key: str, spec_all: dict) -> list:
    """读该模块 `swap.keep_text`（要 AI 逐字保真的字样）。**目前只用来打告警**。

    🔴 国际站**没有 keep_text 透传**：gen_image.py 的 argparse 里根本没有 `--keep-text`
      （国内那边有）。所以这里读出来也送不出去 —— 但**必须读**：配了却被静默忽略，
      正是本 skill 反复在治的那类病（人以为改了提示词，实际是原路重掷）。⇒ 重掷时点名说清楚。
    ⛔ 别在本文件里把它拼进 subject 硬造一个"透传"：那是 gen_image.py 那边的提示词工程
      （要连同 schema 一起做），在 glue 里拼字符串只会做出一个谁都不知道它存在的隐式契约。"""
    v = _swap_of(key, spec_all).get("keep_text") or []
    return [t for t in v if isinstance(t, str) and t.strip()]


def process(key: str, idx: int, spec_all: dict, json_dir: Path, build: Path, out_dir: Path, keep: bool,
            mode: str = "", prod_slot: bool = False):
    """出一个模块。两条路（I-72，2026-08-17）：
      · 默认：render→--scene→G-2 归一→**③⁰ 文案审核**→（不过就重掷 ②）→④压字。**不 overlay**。
      · `RENDER_V2_COPY_OCR=0` 老路：render→--scene→G-2 归一→③overlay→③½双影→③½R 重掷→④压字。
    返回 (key, 日志字符串, 成功bool, scene: ""/"bad"/"error", layout: ""/"press"/"error",
          stop: ""/横幅原文, copy_pend: []/[没对上的条目…], spec: ""/"ok"/"bad"/"unchecked",
          bg_warn: []/["上"/"下"…])
      —— spec（🆕 I-74；🆕 I-83 加了 "ok"）= ⑤ 产品规格闸门的状态：
         "ok" **真核到了**（⑤ 退 0）—— 🔴 收尾那句「已机器核过」只对它成立；
         ""   本函数没跑（闸门关掉 / composite / 无 swap）；
         "bad" 规格被改（判废，与 layout 同级）；
         "unchecked" 没跑成、**或跑成了但产品区一个 token 没读到 / 各尺度判定不一致**
         （🆕 I-83；**既不判废也不算通过**，收尾单独记一笔"规格未自动校验"）。
      —— bg_warn（🆕 I-85）= 背景断线告警命中的边（"上"/"下"）。🔴 **告警级**：
         ⛔ 不进 fails、⛔ 不进 _bad、⛔ 不挂退出码，只在收尾再点一次名。
         ⛔ 别把 "unchecked" 并进 fails 或 _bad —— 那就成了假报（Windows 云 OCR 不可用会落这里）。
      —— scene/layout 都是三态字符串（V2-6）：「检出」与「没查成」必须分开报给用户，⛔ 别退回 bool。
      —— copy_pend（🆕 I-72）非空 = ③⁰ 掷尽仍没过 ⇒ **图照出**（ok 仍是 True），但要进收尾
         【待用户确认】清单 + 挂非零退出码。⛔ 别把它并进 fails：那会说成"这张没出成图"。
         ③⁰ **没跑成**（退出码 2）走的是 raise ⇒ 落到 except，ok=False —— ⛔ 与本字段无关，别混。
      —— stop（🆕 m7）= 子脚本退出码 3「需要人答复」时的**原始横幅**；非空 ⇒ 整脚本以 3 退出。
         它既不是 ok=True 也不该进 fails 的 ❌ 列表 —— 是第三种状态，见 FACTS_STOP_CODE 那段。
    🆕 并发安全：不 print、不 sys.exit（并发线程里 sys.exit 会杀主进程）—— 输出收集进 out、错误 raise 后统一记。
    idx = 模块序号，只用来算本模块专属端口（见上面 PORT_BASE 注释：不分端口会互相 kill -9）。
    🆕 mode = main() 里已校验过的路径（""=无 swap／"v2"=默认场景替换／"composite"=合成法，P1-10）；
       prod_slot = 本模块有没有产品图槽（④ 压字检查的判据，P1-11）。两者都在 main() 串行算好再传进来
       —— ⛔ 别在这个线程里调 _swap_mode（它写错值时 sys.exit，会杀掉整个主进程）。"""
    out = [f"—— {key} ——"]
    # 本模块专属端口三元组（render / overlay / check 各一个，跨模块不重叠）
    p_render, p_overlay, p_check = PORT_BASE + idx * 3, PORT_BASE + idx * 3 + 1, PORT_BASE + idx * 3 + 2
    try:
        w, h, scale = _dims(key)
        size = f"{w}x{h}"
        v2 = build / "v2"
        v2.mkdir(parents=True, exist_ok=True)
        final = out_dir / f"{key}.png"
        base = v2 / f"{key}_base.png"

        # ① 渲底图（文案+版式+占位产品，全对）
        cmd = [PY, str(SCRIPTS / "render.py"), str(build), f"{key}.html", str(base), "--size", size,
               "--port", str(p_render)]
        if scale != 1:
            cmd += ["--scale", str(scale)]
        _run(cmd, out)

        swap = _swap_of(key, spec_all)
        # 【底图即成品】的两条路：无 swap 的通用件 · mode:composite 的合成法件（P1-10）。
        #   合成法的产品是【抠好的透明图直接进模板槽】，① render 出来就已经是全分辨率成品，
        #   没有 AI 重绘 ⇒ 没有双影、没有上采样变糊 ⇒ 跳过 ② --scene 和 ③ overlay。
        if mode == COMPOSITE:
            # 🔴 P1-16（A/B 对照实验 2026-08-05 逮到）：composite 只加一行 mode 是【不够】的 ——
            #    `images` 槽若还指着占位件，脚本会打 🧩 成功、退出码 0、check_layout 全绿，
            #    交出去的是一张【无品牌白袋】（根本不是这个产品）。而闸门与汇总行都只说
            #    「加 mode 然后重跑」，照字面做就中招。
            #    ⛔ 这正是本 skill 反复在治的「不报错、只安静出错图」，别在新分支上重演。
            ph = [f"{s}={v}" for s, v in (spec_all.get(key, {}).get("images", {}) or {}).items()
                  if not s.startswith("_") and isinstance(v, str)
                  and CUTOUT_SLOT_RE.search(s.lower()) and "_placeholder" in Path(v).name]
            if ph:
                raise RuntimeError(
                    f"{key}.swap.mode=composite，但产品槽还指着【占位件】：{' / '.join(ph)}\n"
                    f"   合成法 = 把【本款的真产品透明抠图件】直接放进模板槽 —— 占位件是个无品牌白袋，\n"
                    f"   照这样出图会得到一张不是本产品的图，而且各道闸门都会打绿灯。\n"
                    f"   修：images 该槽改成本款 canonical 透明件（见 references/cutout.md §定稿件清单）；\n"
                    f"       库里没有就先 python scripts/cutout.py <白底图> <透明件.png> 抠一张。")
        if not swap or mode == COMPOSITE:
            shutil.copy(base, final)
            how = ("合成法 mode:composite（跳过 --scene/overlay，未调用 AI）"
                   if mode == COMPOSITE else "无 swap（通用件）→ 底图即成品")
            # 🔴 P1-11：这两条路以前【整个跳过压字检查】—— 而合成法恰恰是换了真产品几何的时刻
            #    （2026-08-05 真产品比占位件宽 1.48 倍，m1 袋子切过大标题字底，没有闸门拦住）。
            layout_bad = _check_layout(key, build, size, p_check, out) if prod_slot else ""
            # 🔴 成品行放在闸门【之后】打，且检出就不打 ✅/🧩 —— 先报喜再报忧同样是混合信号
            #    （V2 路径 P1-15 已这么改，这条分支当时没跟上，独立回检逮到）。
            if layout_bad:
                _w = "产品压到文字" if layout_bad == "press" else "压字检查没跑成"
                out.append(f"❌ {key}: {how} —— 但【{_w}，判为废图·待返工】{final}")
            else:
                out.append(f"{'🧩' if mode == COMPOSITE else '✅'} {key}: {how} {final}")
            # ⛔ 这条分支【不删 _base】= 既有行为，别顺手"补上"：底图就是成品本身的来源，
            #    留着便于对比排查；真要清 build/v2 请单独做，别混在本次改动里。
            # scene 位固定为 ""：这两条路没调 AI，机制上不可能双影 —— ⛔ 不是"跳过检测"，别改成 "error"。
            # copy_pend 固定为 []：这两条路根本没调 AI，没有"AI 改字"可审 ⇒ ③⁰ 无从谈起。
            # 🆕 I-74：spec 位同样固定为 ""，⛔ 不是 "unchecked"：composite 的产品像素是**原样贴**进
            #   模板槽的、无 swap 的通用件压根没有产品 ⇒ 规格机制上不可能被改，不是"没查"。
            #    🆕 I-85 bg_warn 位固定 []：这两条路**没补过边**（composite/无 swap 不调 AI，
            #      根本不走 G-2）⇒ 结构上不可能有那道断线。
            return key, "\n".join(out), True, "", layout_bad, "", [], "", []

        # 真产品图：本模块 swap.product 优先，回退顶层 product.swap_image
        prod_rel = swap.get("product") or _clean(spec_all.get("product", {})).get("swap_image")
        if not prod_rel:
            raise RuntimeError(f"{key}.swap 缺 product（真产品图路径），也没有顶层 product.swap_image 兜底。")
        product = (json_dir / prod_rel).resolve()
        if not product.exists():
            raise RuntimeError(f"{key}: 真产品图不存在 {product}")
        subject = swap.get("subject", "")

        # 🆕 G-2 比例对齐（见 _pad_plan 上方大段注释）：送图前把底图补边成模型【实际会返回】的比例。
        #   pw/ph = 补边后尺寸；pad_l/pad_t = 左/上补了多少 —— 这三个数同时是 ④ 的**逆变换计划**。
        #   比例本来就合法（**主图 1000² 全部走这条**）⇒ pw,ph == tw,th 且 pad 全 0
        #   ⇒ gen_image 命令行与本改动之前**逐字节相同**，④ 也退化回原来那句 resize
        #   ⇒ 主图路径在 **deepkey 通道下逐像素与改动前一致**（请求 1024² 返 1024²，drift=0 ⇒ 走精确归一那一句）。
#   ⚠️ ⛔ 别把这句说成无条件「不变」：下面 `RESIDUAL_STRETCH_MAX` 那条判据**没有**按是否补边分流，
#      所以走**老通道 TokenStation**（它自述不遵守 size，实回 1122×1402 之类）时，主图从
#      「静默各向异性压扁」变成「告警 + 等比缩放居中裁」。那是**改进**，但确实是行为改变。
#      ⛔ 别为"统一"给主图也补边。
        #   🔴 tier 一律 "1k"：国际站 gen_image.py 是 1K-only、没有 --tier 参数（见上方注释）。
        tw, th = w * scale, h * scale
        tier = "1k"
        pw, ph, pad_l, pad_t, pad_aspect = _pad_plan(tw, th, tier)
        scene_in = base
        basepad = v2 / f"{key}_basepad.png"
        if (pw, ph) != (tw, th):
            from PIL import Image as _Im
            bw, bh = _Im.open(base).size
            if (bw, bh) != (tw, th):
                # 底图尺寸和画布对不上 ⇒ 补边计划的逆变换不再成立。⛔ 不许硬补（会裁错位置），
                #   退回老路（等比缩放+居中裁切）并**出声**，⛔ 别静默换算法。
                out.append(f"   ⚠️ {key}: 底图实际 {bw}×{bh} ≠ 画布 {tw}×{th} —— "
                           f"跳过 G-2 比例对齐，退回等比缩放+居中裁切（会裁掉内容，往上查 ① 渲图；"
                           f"render.py 报过「体积偏小疑似 404」就是这种）。")
                pw, ph, pad_l, pad_t = tw, th, 0, 0
            else:
                scene_in = basepad
                _pad_edge(base, scene_in, pw, ph, pad_l, pad_t)
                out.append(f"   🧮 {key}: G-2 比例对齐 —— 画布 {tw}×{th}（目标比 {tw/th:.4f}）→ "
                           f"复制边缘补边到 {pw}×{ph}（补边目标比 {pad_aspect:.4f}，实得 {pw/ph:.4f}；"
                           f"补了 上 {pad_t} / 下 {ph-th-pad_t} / 左 {pad_l} / 右 {pw-tw-pad_l} px）"
                           f"→ 请求 {_gen_size(pw, ph)}，出图后按同一份计划原样裁回，管线零裁切。")

        # ② gen_image --scene：把真产品（+可选元素件）换进底图占位处
        swapped = v2 / f"{key}_swapped.png"
        fit = v2 / f"{key}_fit.png"
        # 🔴 送的是 scene_in（补过边的那版）、尺寸档按 pw×ph 挑 —— ⛔ 别改回 base / _gen_size(w,h)：
        #    那样请求档位与送图比例又对不上，等于把 G-2 关掉、拉伸原样重演。
        gcmd = [PY, str(SCRIPTS / "gen_image.py"), subject, "--scene", str(scene_in),
                "--product", str(product), "--size", _gen_size(pw, ph), "-o", str(swapped)]
        for el in swap.get("elements", []):
            if not isinstance(el, dict) or el.get("_"):
                continue
            ep = (json_dir / el["product"]).resolve()
            if not ep.exists():
                raise RuntimeError(f"{key}: 元素件不存在 {ep}")
            gcmd += ["--element", str(ep)]

        # ══════════════════════════════════════════════════════════════════════
        # ③½R 双影自动重掷（V2-7，Bowen 2026-08-06 定；与国内 skill v2.26 对称）
        #
        # 🔴 国际站的架构与国内**不同**，落点也不同（⛔ 别照抄国内的写法）：
        #   国内 render_v2 是【分阶段流水线】（scene_swap 全批 → run_scene_text_checks 全批 →
        #   main() 里插一段 ③½R 循环），重掷要在 main() 里重建上下文；
        #   本脚本是【一个线程把一个模块跑完全程】（process() 里 ①②③③½④ 串行）⇒ 重掷循环
        #   就写在 process() 内部，把 ②→③→③½ 包成 for attempt。好处：`_base` 天然还在
        #   （删中间件在本函数尾部），不用重建任何上下文，也不用把并发编排改一个字。
        #
        # 🔴 为什么"重掷"是第一处置，而不是 2026-08-05 P1-10 首版写的"改 mode:composite"：
        #   · 双影 = `--scene` 每次重绘我方文案时的**随机走样**，同一张重掷通常就干净了。
        #     整改前的旧版一张双影图都没交付过 —— 靠的正是 references/scene-swap.md
        #     「任一条不过 → 废弃重跑，别硬用」的人工纪律。这一步只是把它接进脚本，不是新发明。
        #   · 合成法要先有干净透明抠图件，而 cutout.py 在同事机器上不稳（Bowen 2026-08-06：
        #     「抠图这条路不行，还是走 V2」）⇒ 拿它当双影的常规解 = 把同事推进一条走不通的路。
        #
        # ⛔ 只重掷 scene_bad == "bad"（真检出双影），**绝不重掷 "error"（没查成）**：
        #   那种情况有没有双影是**未知**的，重掷等于对着一个未知问题烧钱，而且检测器本身还坏着。
        #   V2-6 刚把这两者拆开（三态返回值），⛔ 别在这里又合回去。
        # ⛔ 重掷必须在【删中间件之前】：③½ 要拿 `_base` 与成品比对，删了就没法比。
        #
        # 🔴 缓存：**国际站的 gen_image.py 没有结果缓存**（已核：`grep -ni "cache|缓存|hashlib" ` 零命中）
        #   ⇒ 同样的命令行每次都是**真掷**，不需要国内那个 `--refresh-cache`。
        #   ⛔ 哪天给 gen_image.py 加了结果缓存，**这里必须同步加 refresh 开关**，否则重掷会命中缓存、
        #   拿回逐字节相同的那张图 = 空转，而且脚本还会把「一次都没真掷」报成「掷了 N 轮仍中 ⇒ 结构病」
        #   去指挥人改版式（国内 v2.26 独立回检逮到的 P0，原样重演）。
        # ══════════════════════════════════════════════════════════════════════
        # ══════════════════════════════════════════════════════════════════════
        # 🆕 I-72：轮数按走的是哪条路取 —— ③⁰ 开着（默认）时 ③/③½/③½R **整段不跑**，
        #   循环的意义变成"③⁰ 没过就重掷"，所以用 COPY_OCR_RETRIES。
        #   🔴 `RENDER_V2_COPY_OCR=0` ⇒ retries == SCENE_RETRIES 且下面那个 `if COPY_OCR_ON`
        #     整块被跳过 ⇒ 控制流与本改动之前**逐条相同**（连日志措辞都没变）。
        # ══════════════════════════════════════════════════════════════════════
        retries = COPY_OCR_RETRIES if COPY_OCR_ON else SCENE_RETRIES
        copy_rc = None      # None = ③⁰ 没跑（kill-switch 关掉了）；0/1/2 = 审核官的三态
        copy_items: list = []
        scene_bad = ""
        for attempt in range(retries + 1):
            if attempt and COPY_OCR_ON:
                # 🔴 ⛔ 别把这句写成"随机走样，换一版通常就干净了"（那是 ③½R 双影的说法）：
                #   文案被改字**不是**随机走样 —— 国内 2026-08-13 三掷实测，原路重掷第 2 掷
                #   同一位置同一种错法（`LIFEWGRTH` 稳定复现）。真正管用的是【改了提示词再掷】。
                kt = _keep_text_of(key, spec_all)
                out.append(f"   —— ③⁰R 文案审核未过，重掷 --scene（第 {attempt}/{COPY_OCR_RETRIES} 轮）—— "
                           f"本轮 ≈1 次 gen_image 调用（`RENDER_V2_COPY_OCR_RETRIES=0` 关掉自动重掷）。")
                out.append(f"   ⚠️ 🔴 本站的 `gen_image.py` **没有 `--keep-text` 参数** ⇒ 这一轮是"
                           f"【原路重掷】，多半还是同样的错（国内实测：原路重掷两次错得一模一样，"
                           f"不是随机走样）。要真正修好，得给 gen_image.py 补 `--keep-text` 点名逐字保真。"
                           + (f"\n      ⚠️ {key}.swap.keep_text 配了 "
                              + "、".join(f"「{t}」" for t in kt)
                              + " —— 但**本站送不出去**（没有透传），这几条这一轮不起作用。" if kt else ""))
            elif attempt:
                out.append(f"   —— ③½R 双影自动重掷（第 {attempt}/{SCENE_RETRIES} 轮）—— "
                           f"双影是 --scene 每次重绘文案的随机走样，换一版通常就干净了"
                           f"（本轮 ≈1 次 gen_image 调用；`RENDER_V2_SCENE_RETRIES=0` 关掉自动重掷）。")
            _run(list(gcmd), out)

            # ④ 归一 + 逆变换（G-2，整改 I-24 2026-08-17）
            #
            # 🔴 这里原来是**无条件** `resize((w*scale, h*scale))` —— 不看长宽比，直接拉。
            #   模型按【档位比】返回、硬塞回【目标比】= 各向异性拉伸，详情页 15–66% 全中，
            #   产品被拉胖、我方文案被拉离模板写死的坐标 ⇒ overlay 盖不住 ⇒ **必然双影**。
            #   完整病史与逐模块拉伸量见 _pad_plan 上方那段。
            # 改法：目标从「原画布 tw×th」改成「**补边后** pw×ph」，然后按计划把补的边裁掉。
            #   没补边时 pw,ph == tw,th 且 pad 全 0 ⇒ 与改动前**逐像素等价**（主图走这条）。
            #   补了边时还多两件事：
            #   （a）**按返回图的真实宽高算**，⛔ 绝不假设它等于请求的 `--size`
            #        （实测 deepkey 1k 请求 1536x1024 回 1264×848；老通道 TokenStation 更是
            #          压根不遵守 size，会回 1122×1402 这种 —— 那种情况下走下面的 cover 分支）。
            #   （b）残差 ≤ RESIDUAL_STRETCH_MAX 时走**精确归一**而不是 cover+裁切：
            #        残差是 0.x% 级别、形变肉眼不可见，而 cover 会实打实吃掉几 px 内容
            #        —— 那正是这一轮要根治的「细微裁切」。残差超阈值（模型行为变了 / 走了别的通道）
            #        才 cover，并**告警点名**。⛔ 别退回无条件 resize，那是本条整改的病灶本身。
            from PIL import Image
            src = Image.open(swapped).convert("RGB")
            gw, gh = src.width, src.height        # 模型**真实**返回尺寸（下面 resize 会覆盖 src，先留一份）
            sa, ta = gw / gh, pw / ph
            drift = abs(sa - ta) / ta
            # 运行时自校正：实测常量过期就出声点名，⛔ 别静默吞掉（下次改 MEASURED_ASPECT 靠这行；
            #   sq/port 两档至今未实测，就是靠它兜底）。
            if (pw, ph) != (tw, th) and drift > ASPECT_DRIFT_WARN:
                out.append(f"   ⚠️ {key}: 模型返回比例 {sa:.4f}（{gw}×{gh}）与补边目标 {pad_aspect:.4f} "
                           f"差 {drift*100:.2f}% —— **实测常量可能过期**，"
                           f"把 render_v2.py MEASURED_ASPECT[('{_family(tw/th)}', '{tier}')] 更新成 {sa:.4f}。")
            if drift > RESIDUAL_STRETCH_MAX:
                out.append(f"   ⚠️ {key}: 返回 {gw}×{gh}（比例 {sa:.3f}）与送图画布 {pw}×{ph}（{ta:.3f}）"
                           f"差 {drift*100:.1f}%（>2%）—— 走等比缩放+居中裁切"
                           f"（⛔ 不拉伸，拉伸会把产品拉胖并造成双影）。")
                # cover：按较大的那个缩放比来，保证两边都不小于目标
                k = max(pw / gw, ph / gh)
                rw, rh = max(pw, round(gw * k)), max(ph, round(gh * k))
                src = src.resize((rw, rh), Image.LANCZOS)
                left, top = (rw - pw) // 2, (rh - ph) // 2
                img = src.crop((left, top, left + pw, top + ph))
            else:
                rw, rh, left, top = pw, ph, 0, 0      # 精确归一：一个像素都不裁
                img = src.resize((pw, ph), Image.LANCZOS)
            # ④ 逆变换：把 ① 补的边**原样裁掉** —— 补多少裁多少，回到与原画布逐像素相等。
            if (pw, ph) != (tw, th):
                img = img.crop((pad_l, pad_t, pad_l + tw, pad_t + th))
            if img.size != (tw, th):   # 不变式：成品必须 == 画布，否则 overlay 会整层错位。⛔ 别静默。
                raise RuntimeError(f"{key}: 比例对齐逆变换后 {img.size} ≠ 画布 {(tw, th)} —— 这是脚本 bug，别硬用。")
            img.save(fit)
            # 日志把「归一」和「裁回补边」**分开报**：有没有吃到内容，看数就知道，⛔ 别当黑箱。
            cut_x, cut_y = rw - pw, rh - ph
            if not (cut_x or cut_y):
                # 🔴 措辞必须带限定：这句只说【管线】没多裁一个像素，⛔ 不保证成品四边完整 ——
                #    AI 重绘照样可能把整块版式挪出画布（国内 t02 实测上移 129px@2x，补边跑过了、
                #    日志也打「零裁切」，标题照样被削）。不加限定，读的人会拿它当"四边完整"的凭据。
                how = f"精确归一到 {pw}×{ph}（形变 {drift*100:.2f}%，管线零裁切⚠️ 不等于成品四边完整）"
            elif (pw, ph) != (tw, th) and cut_x // 2 <= pad_l and cut_y // 2 <= pad_t:
                how = f"归一到 {rw}×{rh} 后居中裁掉 {cut_x}×{cut_y}px（全落在补边区里，不碰内容）"
            else:
                how = (f"归一到 {rw}×{rh} 后居中裁掉 {cut_x}×{cut_y}px"
                       f"（⚠️ 裁的是画面内容边缘 —— 比例对齐没生效或模型比例偏得太多）")
            out.append(f"   📐 {key}: 送图 {pw}×{ph} → 模型返回 {gw}×{gh} → {how}"
                       + (f" → 裁回补边（上 {pad_t} 下 {ph-th-pad_t} 左 {pad_l} 右 {pw-tw-pad_l}）"
                          if (pw, ph) != (tw, th) else "")
                       + f" → 成品 {tw}×{th}。")

            # ══════════════════════════════════════════════════════════════════
            # ③⁰ 文案审核官（I-72，2026-08-17 起 = 默认路径）
            #
            #   读 ② 归一后的 `_fit` → 我方每条文案是否原样都在。
            #   通过 ⇒ 这张【不 overlay】，`_fit` 就是成品（**结构上不可能双影**）。
            #   不过 ⇒ 重掷 ②（COPY_OCR_RETRIES 轮）；掷尽仍不过 ⇒ 照常出图 + 收尾【待用户确认】。
            #   没跑成 ⇒ ⛔ 不当通过、⛔ 不重掷：判失败，逼人先修工具。
            #
            # 🔴 落点必须在【② + G-2 归一之后、③ overlay 之前】：
            #   · 早于 ③ —— 整条改动的目的就是"文案没问题的图别再叠一次"（叠了才有双影风险）。
            #   · 晚于 G-2 —— `--after` 要的是裁回画布的 `_fit`，⛔ 不是模型原始返回的 `_swapped`。
            # ⛔ 别在这里加 `mode:composite` / 无 swap 分支的处理：那两条路在本函数**更上面**
            #   就 return 掉了（根本不调 AI，没有可审的"AI 改字"）。
            # ══════════════════════════════════════════════════════════════════
            if COPY_OCR_ON:
                # 🔴 先删旧成品：out_dir 只 mkdir 不清理。上一次整脚本跑剩的 out/<key>.png 会在
                #   本轮判 2（没跑成）时留在原地，看着就像"这次出的图"——存量静默错图的老通道。
                #   通过分支下面的 shutil.copy 会重新写一份，删了不影响。
                final.unlink(missing_ok=True)
                copy_rc, copy_items = _check_copy_ocr(key, build, fit, out)
                if copy_rc != 1:
                    break      # 0 = 通过（下面落盘）· 2 = 没跑成（⛔ 绝不重掷，见 _check_copy_ocr）
                continue       # 1 = 没过 → 还有轮次就重掷 ②，掷尽自然退出循环

            # ══════════════════════════════════════════════════════════════════
            # 以下 ③ / ③½ 是 `RENDER_V2_COPY_OCR=0` 的**老路**（一律 overlay）。
            # 🔴 I-72 之前这里没有任何条件判断，每个走 V2 的模块必跑 —— 而 overlay 是「盖」不是
            #   「擦」，盖不掉 AI 在旁边多画的那一份 ⇒ **无条件叠 = 主动给每张图制造双影机会**。
            # ══════════════════════════════════════════════════════════════════
            # ③ overlay_copy：把 HTML 纯文案层叠回去（--scene 重绘会改我方文案 → 叠回锁死）
            # 🔴 先删旧成品再叠：out_dir 只 mkdir 不清理，上一轮重掷（或上一次整脚本跑）留下的
            #    out/<key>.png 会让 ③½ 在 overlay 万一"退 0 却没写文件"时拿**旧图**去比，
            #    导出一个"重掷没用 ⇒ 结构病"的错误诊断（国内 v2.26 回检 🟡 逮到的原样）。
            final.unlink(missing_ok=True)
            ocmd = [PY, str(SCRIPTS / "overlay_copy.py"), str(build), f"{key}.html",
                    str(fit), str(final), "--size", size, "--hide", swap.get("hide", "img"),
                    "--port", str(p_overlay)]
            if scale != 1:
                ocmd += ["--scale", str(scale)]
            _run(ocmd, out)

            # ③½ 双影检查（P1-9 接线）：--scene 有没有把我方文案也重绘了。
            #    🔴 只对【走 V2 路径】的模块跑（composite / 无 swap 根本没调 AI，无从双影）。
            #    🔴 必须在 ③ 之后、删中间件之前 —— 判据要拿 _base ⇄ 成品比，理由见 _check_scene_text。
            scene_bad = _check_scene_text(key, build, base, final, size, scale, p_check, out)
            if scene_bad != "bad":
                break   # ⛔ "" 通过、"error" 没查成 —— 后者绝不重掷（见上方红字）

        if scene_bad == "bad":
            # 只报**事实**（掷了几轮、还在）；完整三级阶梯由 main() 在汇总里统一打印一次。
            out.append(f"   ❌ {key}: " + (f"重掷 {SCENE_RETRIES} 轮后仍检出双影"
                                          if SCENE_RETRIES else
                                          "检出双影（自动重掷已被 RENDER_V2_SCENE_RETRIES=0 关闭）"))

        # ══════════════════════════════════════════════════════════════════════
        # I-72：③⁰ 的三条出路（⛔ 三态别合并，处置完全不同）
        # ══════════════════════════════════════════════════════════════════════
        copy_pend: list = []      # 非空 ⇒ 掷尽仍没过门禁 → 收尾【待用户确认】清单
        if COPY_OCR_ON:
            if copy_rc == 2:
                # 🔴 没跑成 ≠ 通过。⛔ 也别在这里"退回 overlay 兜一下"——那正是本条整改要去掉的
                #   无条件叠加，而且会把一个**工具坏了**的信号偷偷换成一张看着正常的图。
                raise RuntimeError(
                    f"③⁰ 文案审核【没跑成】（退出码 2）—— 这张我方文案有没有被 AI 改字是**未知**的。\n"
                    f"   ⛔ 不当通过、⛔ 不重掷（对着未知问题烧钱）、⛔ 不自动退回 overlay。\n"
                    f"   👉 按上面 {COPY_OCR.name} 自己打的提示修工具（macOS 缺 pyobjc / 非 macOS 缺"
                    f"云 OCR 凭据都在那几行里），修好重跑；\n"
                    f"   👉 实在要先出图，`RENDER_V2_COPY_OCR=0` 退回「一律 overlay」的老路"
                    f"（代价：每张都叠 ⇒ 有双影风险，由 ③½ 去查）。")
            if not fit.exists():
                # 兜底：`_fit` 不在就没有"最后一版"可出（② 每一轮都失败才会到这）。⛔ 别静默跳过。
                raise RuntimeError(f"③⁰ 通过/未过都要用 {fit.name} 出图，但它不在 —— "
                                   f"② 换产品没产出可用的图，往上翻 ② 的报错。")
            # 通过 与 掷尽仍不过，**出的都是这一版 `_fit`**（区别只在要不要问用户）。
            shutil.copy(fit, final)
            if copy_rc == 1:
                # 🔴 掷尽仍不过 ⇒ **照常出图**，⛔ 不默认退回 overlay（会双影）、⛔ 不默认切 composite
                #   （要干净抠图件、同事机器上不稳）—— 两者代价完全不同，判定权在**用户**。
                #   ⛔ 别为了"让流程绿着走完"把它当通过：收尾清单 + 非零退出码才是这一步的重点。
                copy_pend = copy_items or [
                    "（这一轮没能从审核官输出里解析出具体条目 —— 往上翻 ③⁰ 的原文；"
                    "若是 check_copy_ocr 改了措辞，parse_copy_failures 的锚点要同步改）"]
            # ══════════════════════════════════════════════════════════════════
            # 🆕 I-86⒉（2026-08-18）`swap.hide` 在默认路径上是**死键** —— ⛔ 别静默作废用户的意图。
            #   hide 在本文件里**只有一处引用**：老路 ③ `overlay_copy.py --hide`。I-72 之后
            #   ③⁰ 通过即 break ⇒ 默认路径根本走不到那一行 ⇒ 写了等于没写。
            #   实测后果正是它想防的那件事：detail.example.json 的 d2 写着 `"hide": ".pcard img"`
            #   （本意「成分徽章要像素级清晰，别让 --scene 画糊」），成品里三个徽章明显比底图糊、
            #   还右移约 90px。
            # ⛔ 不在这里"顺手替他 overlay 一下"：无条件叠加正是 I-72 去掉的东西（叠了才有双影源），
            #   而且用户真正要的是【徽章根本别进 AI】—— 那是 composite，不是 overlay。
            # ══════════════════════════════════════════════════════════════════
            if swap.get("hide"):
                out.append(
                    f"   🟠 {key}: `swap.hide` = {swap['hide']!r} **本次没有生效** —— 它只被 ③ "
                    f"`overlay_copy.py --hide` 用到，而 I-72 起【③⁰ 文案审核通过就不 overlay】"
                    f"（本张走的正是这条默认路径）⇒ 这个键一行代码都没走到。\n"
                    f"      ⛔ 别当它防住了：hide 想保护的那些元素（成分徽章之类）这次是"
                    f"**被 --scene 整个重画**的，会糊、会位移。\n"
                    f"      👉 正解 = 给 {key}.swap 加 `\"mode\": \"composite\"`：产品与徽章由 HTML "
                    f"原分辨率渲、全程不进 AI（详情页本来就该走这条，见 I-86）。\n"
                    f"      👉 只想让 hide 重新生效（**不推荐**）：`RENDER_V2_COPY_OCR=0` 退回一律 "
                    f"overlay 的老路 —— 代价是每张都叠 ⇒ 有双影风险。")

        # 🆕 I-85 背景连续性兜底检测（🔴 告警级：只出声，⛔ 不判废、⛔ 不挂退出码）。
        #    落点必须在【成品 final 已经落盘之后】：两条路的成品来源不同（默认路径 = 上面
        #    shutil.copy(fit, final)；老路 = 循环里 overlay 写出的 final），接在这里两条都盖到。
        #    📌 只有真补过边的模块才跑（主图 1000² pad 全 0 ⇒ 一次都不跑）。
        bg_warn = _check_bg_seam(key, base, final, pad_t, ph - th - pad_t, out) \
            if (pw, ph) != (tw, th) else []

        # ⑤ 产品规格闸门（🆕 I-74）：源产品图 ⇄ 成品产品区，包装上原厂印的净含量/粒数有没有被改。
        #    🔴 落点在这里是**故意**的 —— 它比的是【最终成品 final】，而 final 有两个来源：
        #      · 默认路径（③⁰ 通过/掷尽）：上面那句 shutil.copy(fit, final)；
        #      · 老路（RENDER_V2_COPY_OCR=0）：循环里 ③ overlay_copy 直接写出的 final。
        #      接在这一点上，**两条路都盖到**；⛔ 别挪进 for 循环里去比 `fit`（老路的成品不是 fit）。
        #    🔴 只有走 V2 的模块能到这里（composite / 无 swap 在本函数更上面就 return 了）
        #      ⇒ 天然只跑「产品由 AI 重绘」的那些，不用额外判断。
        #    与 ③½/④ 共用 p_check：同模块内串行、时间上不重叠（见 PORT_BASE 那段的 I-74 小节）。
        #    ⛔ 不跟着 scene_bad/copy_rc 提前 return：判废的图也要把"规格还被改了"一次说全，
        #      省得人修完双影重跑一轮才看见第二个病。
        #    🆕 I-81⒊：`swap.spec_box`（[x,y,w,h]，成品像素坐标）原样透传成 `--box` 人工兜底框；
        #      ⛔ 没写就不传（脚本侧自己定框），控制流与接线前逐条相同。
        spec_bad = _check_product_spec(key, build, product, final, size, p_check, out,
                                       box=swap.get("spec_box")) if SPEC_CHECK_ON else ""

        # ④ check_layout：产品位置由占位件决定 → 跑在底图/构建目录 HTML 上依然有效。
        #    🔴 I-72：**③⁰ 通过的那条路照样跑 ④** —— 产品压字与文案审核是两件事
        #    （压字看的是占位件几何，AI 一个字没改错也照样能把产品糊到标题上）。⛔ 别跟着 ③ 一起关。
        #    🔴 P1-11：判据从 `key in PRODUCT_DETAIL`（只有 d1/d3）改成【本模块有没有产品图槽】
        #    —— 主图 m1/m2 以前一次都没查过，2026-08-05 m1 的袋子就是这么切进大标题的。
        #    与 ③½ 共用 p_check：同模块内串行、时间上不重叠，⛔ 别为它新开端口（会撞进别的模块的段）。
        layout_bad = _check_layout(key, build, size, p_check, out) if prod_slot else ""

        # 🔴 检出双影就【不许打 ✅ 成品】—— 2026-08-05 那次翻车的本质就是"报成功、图是废的"，
        #    混合信号（先 ❌ 再 ✅）等于把闸门的话又收回去一半。图仍然留在磁盘上供放大核对，
        #    但措辞必须是"待返工"，⛔ 不是"成品"。
        # 🆕 I-74：`spec_bad == "bad"`（规格数字被改）与 layout FAIL **同级判废**。
        #    ⛔ 但 "unchecked" 绝不进这个条件 —— 那是"没查成"，判废就是假报。
        if scene_bad or layout_bad or spec_bad == "bad":
            _why = []
            if scene_bad:
                _why.append("双影（--scene 重画了我方文案）" if scene_bad == "bad" else "双影检查没跑成")
            if layout_bad:
                _why.append("产品压到文字" if layout_bad == "press" else "压字检查没跑成")
            if spec_bad == "bad":
                _why.append("产品包装上的规格数字被改")
            why = "；".join(_why)
            out.append(f"❌ {key}: 图已落盘但【判为废图·待返工】{final} —— {why}；见上方判据。")
            if copy_pend:
                out.append(f"   🟡 {key}: 另外 ③⁰ 文案审核也没过（重掷 {COPY_OCR_RETRIES} 轮）"
                           f"—— 收尾【待用户确认】清单里逐条列。")
        elif copy_pend:
            # 🟡 而不是 ✅：图出了，但门禁没过 —— ⛔ 别打 ✅（先报喜的混合信号正是 P1-15 治的病）。
            out.append(f"🟡 {key}: ③⁰ 文案审核重掷 {COPY_OCR_RETRIES} 轮仍没过 → **照常出图** {final}"
                       f"（⛔ 未自动 overlay、⛔ 未自动改 composite）—— 收尾列进【待用户确认】清单，"
                       f"交付前请人工定夺。")
        elif copy_rc == 0:
            out.append(f"✅ {key}: V2 成品（③⁰ 文案审核通过 → **未 overlay ⇒ 结构上无双影**）{final}")
            out.append("   👉 放大核：①**版式与字体是 AI 模仿的** —— 整块位置可能漂几到二十几 px，"
                       "这是不 overlay 换来的【已知代价】（Bowen 明确接受，⛔ 别当 bug 报）；"
                       "②产品自印小字/规格有没有被 --scene 改乱；③融合；④四边有没有被切。")
            out.append("   ℹ️ 本张**没跑 ③½ 双影检测** —— 双影的唯一来源是 ③ overlay 叠上去的那一层，"
                       "这张压根没叠 ⇒ **没有双影源**。⛔ 别读成「跳过了检测」（那是 ③ 关了、检测跟着关，"
                       "不是漏检）；③⁰ 只保证【文字内容】对，版式边界仍靠上面那条人工放大核。")
        else:
            out.append(f"✅ {key}: V2 成品 {final}")
            out.append("   👉 放大核：①我方文案已锁精确（overlay）②产品自印小字/规格有没有被 --scene 改乱③融合。")
        # 🆕 I-74：**限定词挂在判定之后**（⛔ 不改上面任何一条判定，"没跑成"既不判废也不算通过）。
        #    不打这一句的话，人看到的就是一条干净的 ✅ / 🟡 —— 而这张的规格其实**一次都没查过**。
        if spec_bad == "unchecked":
            out.append(f"   🟠 {key}: ⚠️ 但【产品规格未自动校验】"
                       f"（⑤ 没跑成／产品区一个规格 token 都没读到／各尺度判定不一致，原因见上方）——"
                       f"这张的净含量/粒数**没有任何机器查过**，收尾汇总里单独列一笔。"
                       f"⛔ 别当它查过了：交付前把源产品图与成品并排放大到 300%+ 逐个核。")
        if not keep:
            # 🆕 G-2：`_basepad`（补边后的送图版）也算中间件 —— ⛔ 别漏，漏了 build/v2 里会攒下
            #    一堆比画布大一圈的图，下次排查时很容易被当成"底图"读错（比例都不一样）。
            for p in (base, basepad, swapped, fit):
                p.unlink(missing_ok=True)
        return key, "\n".join(out), True, scene_bad, layout_bad, "", copy_pend, spec_bad, bg_warn
    except StopForHuman as e:
        # 🆕 退出码 3：**需要人答复**，不是失败。⛔ 这个 except 必须排在 `except Exception` 之前
        #    （Python 按书写顺序匹配；写反了 StopForHuman 会被当普通异常吃成"某模块失败"）。
        #    这里只留一行指路，横幅由 main() 在最末尾原样打一次 —— ⛔ 别在这里 append 横幅正文：
        #    并发日志有几百行，夹在中间等于没打；契约 §6 要的是"醒目横幅 + 停机"。
        out.append(f"🛑 {key}: 停机等人答复（退出码 {FACTS_STOP_CODE}）—— 横幅在本次输出的最末尾，"
                   f"⛔ 不是脚本出错、⛔ 不是没通过检查。")
        return key, "\n".join(out), False, "", "", (e.banner or f"（{key}: 子脚本退出码 "
                                                    f"{FACTS_STOP_CODE} 但没打任何横幅）"), [], "", []
    except Exception as e:  # noqa: BLE001  并发线程里任何失败都收进 log，不杀进程
        out.append(f"❌ {key} 失败：{e}")
        # 🆕 I-74 spec 位给 ""：这两条路**根本没出成图**（ok=False，已经算失败了），
        #   再报一句"规格未自动校验"只会让收尾清单里多一条噪声，指向一件不用做的事。
        return key, "\n".join(out), False, "", "", "", [], "", []


def main() -> None:
    ap = argparse.ArgumentParser(description="V2 场景替换法一键出图（render→scene-swap→overlay→check）")
    ap.add_argument("product_json")
    ap.add_argument("build_dir")
    ap.add_argument("-o", "--out", required=True, help="成品 PNG 输出目录")
    ap.add_argument("--modules", nargs="*", choices=list(TEMPLATE_FILES),
                    help="要出的模块；不给默认主图 m1-m6（构建目录里有 m7.html 时自动带上 m7）")
    ap.add_argument("--detail-all", action="store_true", help="出完整详情页 12 块（等价 --modules 全序列）")
    ap.add_argument("--keep", action="store_true", help="保留中间件（底图/换产品图/缩放图），默认删")
    a = ap.parse_args()

    json_path = Path(a.product_json).resolve()
    spec_all = json.loads(json_path.read_text(encoding="utf-8"))
    build = Path(a.build_dir).resolve()
    out_dir = Path(a.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    if a.detail_all:
        modules = list(DETAIL_FULL)
    elif a.modules:
        modules = a.modules
    else:
        # 🆕 2026-08-09 主图 6 图 → 7 图（新增 m7 营养成分表）。
        # 🔴 但 m7 **只在构建目录里真有 m7.html 时**才自动带上：存量 product.json 没有 m7 段
        #   ⇒ build.py 不产出 m7.html ⇒ 无条件默认 7 张会让所有老产品在下面的护栏区直接 sys.exit，
        #   把"新增一张图"变成"存量全线停摆"。
        # ⛔ 这不是静默降级：下面那行抬头会**逐个列出**本次实际要出的模块，缺 m7 时也点名说明。
        modules = ["m1", "m2", "m3", "m4", "m5", "m6"]
        if (build / "m7.html").exists():
            modules.append("m7")
        else:
            print("ℹ️ 默认只出主图 6 张：构建目录里没有 m7.html（营养成分表）。"
                  "要出 m7 就先在 product.json 里补 m7 段并 `build.py --only … m7`。")
    # 去重保序：下面 futs 用模块名做 key，重复传同一模块（--modules m1 m1）只会提交一次，
    # 却会被 .result() 读两次 → 完成计数虚高。这里先去重，计数与实际提交一致。
    modules = list(dict.fromkeys(modules))

    for key in modules:
        if not (build / f"{key}.html").exists():
            # 🆕 m7 少一句话人就会白排查半天：build.py 的 m7 硬闸门（check_facts.py）**退出码 3 时
            #   根本不产出 m7.html** —— 现场表现就是这里的"没有 m7.html"，而真正的原因是
            #   【有商标成分在等 Bowen 答复】，横幅早在 build.py 那一轮就打过了、往上翻就能找到。
            #   ⛔ 不在这里替它重跑 check_facts：闸门该在构建期 fail fast，重跑还会改写 product.json 的 dv。
            hint = ("\n   🛑 如果 build.py 那一轮是以【退出码 3】结束的，那不是构建失败 —— 是 m7 里有\n"
                    "      商标/专利成分在等 Bowen 答复（往上翻 build.py 打的停机横幅）。\n"
                    "      答复后：同意的写进 m7.facts.trademark_ok，或把 m7.facts.mode 改 \"demo\"，再重跑 build.py。"
                    if key == "m7" else "")
            sys.exit(f"❌ 构建目录里没有 {key}.html —— 先跑 build.py 构建（--only/--detail-all 要含 {key}）。{hint}")

    # 🆕 P1-10：每模块的路径三选一 —— ""=无 swap（通用件） / "v2"=默认场景替换 / "composite"=合成法。
    #   ⛔ mode 写错在这里就 sys.exit 点名（护栏区、串行、还没渲任何东西），不拖到渲完才发现，
    #      更不静默当默认（静默退回会双影的 V2 正是这次要堵的病）。
    mode_of = {k: _swap_mode(k, spec_all) for k in modules}
    # 🆕 P1-11：④ 压字检查的判据 = 有没有产品图槽（不是"有没有 swap"），composite/无 swap 的也查。
    slot_of = {k: _has_product_slot(k, spec_all) for k in modules}

    # 🆕 并发出图（≤WORKERS 路）：每模块 render→--scene→overlay→check 内部串行，模块之间并发。
    #    输出按提交顺序缓冲后统一打印（不交织）；某模块失败不影响其他。
    print(f"V2 出图：{len(modules)} 模块（{' '.join(modules)}），≤{WORKERS} 路并发 → {out_dir}")
    # 🆕 只在 OFFSET 真生效时多打这一行（默认路径输出**逐字节不变**）：多实例并发翻车时，
    #    第一件要确认的就是"这两条命令到底用的是不是同一组端口"，让它自己说出来最省事。
    if PORT_OFFSET and PORT_BASE != PORT_BASE_DEFAULT:
        print(f"  🔌 RENDER_V2_PORT_OFFSET={PORT_OFFSET} → 本次端口段 "
              f"{PORT_BASE}–{PORT_BASE + (len(modules) - 1) * 3 + 2}（并发的另一条命令必须给不同的 offset）")
    comp_keys = [k for k in modules if mode_of[k] == COMPOSITE]
    if comp_keys:
        print(f"  🧩 走【合成法】(mode:composite，跳过 --scene 与 overlay、不调 AI)：{' '.join(comp_keys)}")
    # 🆕 I-86⒊（2026-08-18）：详情页升为 composite 默认之后，整批**一个 V2 模块都没有**是常态。
    #   下面 ③⁰/⑤ 两段打的是【接线状态】不是【本批跑过】—— 不先说这一句，人会读成
    #   "文案审核过了、规格核过了"，而这两道闸门在这一批里**一次都没跑到**。
    v2_keys = [k for k in modules if mode_of[k] == "v2"]
    if not v2_keys:
        print("  ℹ️ 本批**没有走 V2 场景替换的模块**（全是 composite / 无 swap）⇒ ③⁰ 文案审核 · "
              "③½ 双影 · ⑤ 产品规格闸门**一个都跑不到**：这几张全程不调 AI，没有"
              "「AI 改字 / AI 改规格」可查。⛔ 下面两行只是接线状态，别读成本批跑过了。")
    # 🆕 I-72：③⁰ 文案审核官的接线状态，**跑之前就说清楚这次走的是哪条路**
    #   （事后说等于没说：日志几百行，人看到成品行时早就滚过去了）。
    if COPY_OCR_ON:
        print(f"  🔎 ③⁰ 文案审核官【开】(默认) —— 我方文案审核通过的模块**不 overlay**"
              f"（不叠 ⇒ 结构上无双影），不过则重掷 ≤{COPY_OCR_RETRIES} 轮。"
              f"代价：版式/字体是 AI 模仿的，整块可能漂几到二十几 px。"
              f"退回「一律 overlay」的老行为：RENDER_V2_COPY_OCR=0")
    else:
        print("  ⚠️ ③⁰ 文案审核官【关】(RENDER_V2_COPY_OCR=0) —— 回到老路：**每张都 overlay**，"
              "由 ③½ 查双影。⛔ 注意 overlay 是「盖」不是「擦」，叠了才有双影风险。")
    # 🆕 I-74：⑤ 产品规格闸门的接线状态，同样**跑之前就说清楚**（事后说等于没说）。
    if SPEC_CHECK_ON:
        print("  🔬 ⑤ 产品规格闸门【开】(默认) —— 走 V2 的模块出图后比对"
              "【源产品图 ⇄ 成品产品区】的净含量/粒数（composite 与无 swap 的件不跑，产品像素没被 AI 碰过）。"
              "规格被改 = 判废；没跑成 = 单独记「未自动校验」，⛔ 不静默放行也⛔ 不假报。关掉：RENDER_V2_SPEC_CHECK=0")
        # 🆕 I-83：「未自动校验」现在有三个来源，⛔ 别只说"没跑成"——另两个才是六图实测里真正发生的。
        print("     └ 🆕 I-83：【产品区一个规格 token 都没读到】与【各尺度判定不一致】也一并归"
              "「未自动校验」（此前前者打 ✅PASS、后者「按设计放过」⇒ 六图实测 ⑤ 一次都没真核到净含量）。"
              "\n        ⇒ 收尾那句「已机器核过」**只对真核到的模块说**，⛔ 不再无条件打印。")
    else:
        print("  ⚠️ ⑤ 产品规格闸门【关】(RENDER_V2_SPEC_CHECK=0) —— 产品包装上原厂印的净含量/粒数"
              "**没有任何机器守着**（--scene 实测会把 360G 改成 300G）。⛔ 交付前必须人工放大核。")
    results, scene_bads, scene_errs, layout_bads, layout_errs = {}, [], [], [], []
    # 🆕 I-74：spec_bads = 规格被改（判废、进退出码）；spec_unchecked = 没跑成（**不进退出码**，
    #   收尾单独列一笔）。⛔ 两者绝不合并 —— 合并成失败就是假报，合并成通过就是静默放行。
    #   🆕 I-83：spec_ok = **真核到了**（⑤ 退 0）。⛔ 必须单独收 —— 收尾那句"已机器核过"从此
    #   只对它成立；此前它是**无条件**打印的，而六图实测 ⑤ 一次都没真正核到净含量。
    spec_bads, spec_unchecked, spec_ok = [], [], []
    # 🆕 I-85：背景断线告警（🔴 **不进 _bad、不进退出码**）—— 只在收尾再点一次名，
    #   否则几百行并发日志里那一行 🟠 等于没打（"打印了 ≠ 被看见"）。
    bg_warns = {}
    stops = {}   # 🆕 key → 停机横幅原文（退出码 3）
    # 🆕 I-72 收尾【待用户确认】清单：{模块: [没对上的条目…]}。
    #   Bowen 口径：门禁掷尽仍不过 ⇒ **照常出图**，⛔ 不自动退 overlay、⛔ 不自动改 composite，
    #   收尾统一问用户（三个选项代价完全不同，脚本不替他决定），并**退出码非 0** 逼人来看。
    pending = {}
    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        # enumerate → 每模块拿到固定 idx，据此分端口（不分端口会互相 kill -9，见 PORT_BASE 注释）
        futs = {k: ex.submit(process, k, i, spec_all, json_path.parent, build, out_dir, a.keep,
                             mode_of[k], slot_of[k])
                for i, k in enumerate(modules)}
        for k in modules:
            key, log, ok, scene_bad, layout_bad, stop, copy_pend, spec_bad, bg_warn = futs[k].result()
            print("\n" + log)
            results[key] = ok
            if stop:
                stops[key] = stop
            if copy_pend:
                pending[key] = copy_pend
            if scene_bad == "bad":
                scene_bads.append(key)
            elif scene_bad == "error":
                scene_errs.append(key)
            if layout_bad == "press":
                layout_bads.append(key)
            elif layout_bad == "error":
                layout_errs.append(key)
            if spec_bad == "bad":
                spec_bads.append(key)
            elif spec_bad == "unchecked":
                spec_unchecked.append(key)
            elif spec_bad == "ok":
                spec_ok.append(key)
            if bg_warn:
                bg_warns[key] = bg_warn

    # 🆕 停机（退出码 3）的模块【不算 fails】：它没出图是因为**在等人回话**，不是脚本挂了。
    #    混进去就会被 "❌ 失败：m7（往上翻各自 log 看原因）" 这句话指到排查方向上去 —— 而正确动作
    #    是去问 Bowen 一句话。⛔ 别为了"少一个分支"合回去。
    fails = [k for k, ok in results.items() if not ok and k not in stops]
    # 🆕 I-74：spec_bads（规格被改）进 _bad = 与压字 FAIL 同级判废；
    #   ⛔ spec_unchecked **不进** —— 它既不是废图也不是通过，只在下面单独列一笔。
    _bad = set(scene_bads) | set(scene_errs) | set(layout_bads) | set(layout_errs) | set(spec_bads)
    # 🔴 `fails` 也要算进来：漏了它，全部模块失败时抬头仍是「✅ 出图 0/2」——退出码虽对，
    #    但人眼扫日志会被这行骗过。与 P1-15 治的是同一个病（独立回检 2026-08-05 逮到）。
    # 🆕 I-72：pending（③⁰ 掷尽仍没过、图照出）同样**不许打 ✅** —— 它的退出码也是非 0。
    _mark = "🛑" if stops else ("⚠️" if (_bad or fails or pending) else "✅")   # 有任何停机/检出/失败/待确认就别用 ✅ 打头
    # 🔴 分子必须是【真出成图的】数量，⛔ 不能写 len(results)-len(fails)：停机的模块被排除在 fails 之外，
    #   那个写法会把"m7 停机、一张没出"报成「出图 1/1」—— 又一次先报喜的混合信号（P1-15 同款病）。
    _done = [k for k, ok in results.items() if ok]
    print(f"\n{_mark} 出图 {len(_done)}/{len(results)} 模块 → {out_dir}"
          + (f"，{len(stops)} 张【停机等答复】" if stops else "")
          + (f"，其中 {len(_bad)} 张【判为废图·待返工】" if _bad else "")
          + (f"，{len(pending)} 张【③⁰ 门禁没过·待用户确认】" if pending else "")
          # 🆕 I-74：这一笔**必须挂在抬头行**上。它不改 _mark（"没跑成"既不是废图也不是失败，
          #   染成 ⚠️ 会和"判为废图"混成一锅），但抬头如果只写「✅ 出图 7/7」，
          #   人就会以为七张的规格都查过了 —— 正是"打印了 ≠ 被看见"那类病。
          + (f"，{len(spec_unchecked)} 张【产品规格未自动校验】" if spec_unchecked else ""))
    # 🔴 汇总要能一眼看出每张走的哪条路 —— 双影的病根就是"以为走的是 A，实际走的是 B"。
    done_v2 = [k for k in modules if results.get(k) and mode_of[k] == "v2"]
    done_comp = [k for k in modules if results.get(k) and mode_of[k] == COMPOSITE]
    done_plain = [k for k in modules if results.get(k) and not mode_of[k]]
    print(f"   路径：V2 场景替换 {len(done_v2)} 张（{' '.join(done_v2) or '—'}） · "
          f"合成法 composite {len(done_comp)} 张（{' '.join(done_comp) or '—'}） · "
          f"通用件无 swap {len(done_plain)} 张（{' '.join(done_plain) or '—'}）")
    # 🆕 I-72：V2 这一列现在有两种成图方式，⛔ 别让人以为还是"都 overlay 过"。
    if COPY_OCR_ON and done_v2:
        _passed = [k for k in done_v2 if k not in pending]
        print(f"     └ 其中 ③⁰ 文案审核通过 · **未 overlay**（无双影源）{len(_passed)} 张"
              f"（{' '.join(_passed) or '—'}）"
              + (f" · 门禁没过仍照常出图 {len(pending)} 张（{' '.join(pending)}）" if pending else ""))
    # 🔴 m7 的 demo 降级告知（契约 §3）：`facts.mode == "demo"` = 专利成分被 Bowen 拒绝后的降级版式，
    #   成分名已换成品类通用名 —— 图能看，但**不是任何真实/参考配方**，⛔ 不能拿去当配方能力的证据。
    #   契约要求这句在【三处】都打（build.py 收尾 · 本脚本收尾汇总 · SKILL.md 的 QC 清单）：
    #   只在一处打必被几百行并发日志淹没，这条正是"打印了 ≠ 被看见"的典型。
    _m7_facts = _clean(spec_all.get("m7", {}) or {}).get("facts", {}) or {}
    if "m7" in modules and _m7_facts.get("mode") == "demo":
        print("\n   🔴🔴 m7 是【demo 降级版式演示】：专利/商标成分未获同意 → 成分名已换成品类通用名。\n"
              "        这张图上的配方**不代表任何真实或参考配方**，只演示版式。\n"
              "        要出真配方：拿到 Bowen 对商标成分的答复后改 m7.facts（同意的写进 trademark_ok，"
              "或整体换 mode: real/sample）再重跑 build + 本脚本。")
    if fails:
        print(f"   ❌ 失败：{' '.join(fails)}（往上翻各自 log 看原因）")
    if scene_bads:
        # 🔴 V2-7（Bowen 2026-08-06）：完整的三级处置阶梯**只在这里打印一次**（重掷已经用尽了）。
        #   ⛔ 别把它搬回 _check_scene_text 的检出分支：那里在自动重掷时会被反复调用，
        #     第一轮就喊「改 composite」会让人在脚本还要自己掷两次的时候先动手改 JSON。
        #   ⛔ 也别把第 ① 级删掉直接跳第 ③ 级 —— composite 是兜底，不是双影的常规解。
        #   口径必须与 references/scene-swap.md §我方文案双影的处置阶梯、check_scene_text.py
        #   检出分支、国内 skill v2.26 完全一致（两站不对称正是上一次翻车的根因）。
        if SCENE_RETRIES:
            print(f"   ❌ 重掷 {SCENE_RETRIES} 轮后仍检出双影：{' '.join(scene_bads)}\n"
                  f"      ⇒ 不是随机走样，是这几张模板的**结构病**：我方文案压在产品区 / 文案太密，AI 绕不开。\n"
                  f"      👉 ② 改版式（文字挪出产品区、缩短文案、让出留白）后重出"
                  f"——先跑 check_layout.py 看重叠。\n"
                  f"      👉 ③ 实在改不动，再考虑给那个模块的 swap 段加 \"mode\": \"composite\" 走合成法；"
                  f"⛔ 它依赖 cutout.py 抠干净透明件、同事机器上不稳，是**兜底不是常规解**。\n"
                  f"      （composite 仍然首选的是另外两类，与双影无关、不用先重掷："
                  f"【产品自印小字要分毫不差】和【详情页要全分辨率清晰】。）")
        else:
            # 自动重掷被关掉：⛔ 别说成"重掷 0 轮后仍检出"（读起来像掷过了）。
            print(f"   ❌ 检出双影：{' '.join(scene_bads)}（自动重掷已关闭 RENDER_V2_SCENE_RETRIES=0）\n"
                  f"      👉 ① 先**重掷**：去掉那个环境变量再跑一遍本脚本"
                  f"——双影是随机走样，换一版通常就干净了。\n"
                  f"      👉 ② 掷不出干净的才是结构病（文案压产品区/太密）→ 改版式（先跑 check_layout.py）；"
                  f"③ 最后才考虑 mode:composite（兜底）。")
    if scene_errs:
        # 🔴 V2-6：与"真检出双影"分开列，⛔ 别合并 —— 合并了同事会对着一张不存在的双影去加
        #    mode:composite / 改 layout，白烧一轮。这里要说的是"没查过"，不是"查出问题"。
        print(f"   ❌ 双影检查【没跑成】（不是双影）：{' '.join(scene_errs)}\n"
              f"      👉 看上面各自的报错——检测器缺失 / 中间件缺失 / 检测器跑挂。"
              f"⛔ 别加 mode:composite、别改 layout：这几张有没有双影是**未知**的。\n"
              f"      修好后重跑（中间件缺失就加 `--keep`）。检查没跑成不算通过，所以照样非零退出。")
    if layout_errs:
        print(f"   ❌ 压字检查【没跑成】（不是压字）：{' '.join(layout_errs)}\n"
              f"      👉 看上面各自的报错——Chrome/端口/构建目录的问题。⛔ 别去改 layout。"
              f"已自动重试过一次；检查没跑成不算通过，所以照样非零退出。")
    if layout_bads:
        print(f"   ❌ 产品压到文字：{' '.join(layout_bads)}\n"
              f"      👉 调这几个模块的 layout（缩小/右移产品件）后重跑 build + 本脚本。"
              f"🔴 几何按【文字可见墨迹】算（I-82 起，Range.getClientRects()）——⛔ 不再是元素盒。")
    # 🆕 I-74 ⑤ 产品规格闸门的两笔，**分开列**（⛔ 合并 = 要么假报要么静默放行）
    if spec_bads:
        print(f"   ❌ 产品包装上的【规格数字被改】：{' '.join(spec_bads)}\n"
              f"      👉 ⚠️ **重掷多半没用** —— 产品自印小字 AI 每次都会改（实测 d1：源图 NET WT. 360G"
              f" → 成品 300G，而 (12.70 OZ) 没变 ⇒ 自相矛盾）。\n"
              f"      👉 正解：给这几个模块的 swap 加 \"mode\": \"composite\" 走合成法"
              f"（抠好的透明件直接进模板槽、不调 AI ⇒ 产品像素原样）。"
              f"这本来就是 composite **首选**的两类之一，与双影无关、不用先重掷。\n"
              f"      ⛔ 别改我方 HTML 文案去「对齐」图上的错数字 —— 那是把包装造假抄进 listing。")
    if spec_unchecked:
        print(f"   🟠 产品规格【未自动校验】（⛔ 不是查出问题，也⛔ 不是查过了）："
              f"{' '.join(spec_unchecked)}\n"
              f"      👉 看上面各自的 ⑤ 报错——闸门缺失 / 产品区定不了 / OCR 跑不了"
              f"（Windows 云 OCR 不可用最常见，macOS 走系统 Vision 一般不会到这）；\n"
              f"        🆕 I-83 起还包括**跑成了但没核到**的两种：【源图有规格 token、产品区一个没读到】"
              f"与【各尺度判定不一致】—— 这两种以前会打 ✅PASS/「按设计放过」，"
              f"⛔ 那是把不确定写成了确定。\n"
              f"        产品区定不准（框偏了/把文案栏吞进来）就在那个模块的 swap 里加 "
              f"\"spec_box\": [x, y, w, h] 人工收窄（成品像素坐标）再重跑。\n"
              f"      👉 在修好之前**这几张必须人工核**：源产品图与成品并排放大到 300%+，逐个核"
              f"净含量(NET WT / g / oz)、粒数、条数 —— 有一个数字不一样就废掉重跑。\n"
              f"      🔴 本项**不挂退出码**（没跑成 ≠ 失败，⛔ 别学 verify_label 旧版把同事的机器报成一片红），"
              f"所以更要人自己盯住这几张。")
    # 🆕 I-85 背景断线告警汇总（🔴 **告警级：不进退出码、不改抬头行的 ✅**）。
    #   ⛔ 别"顺手"把它接进退出码：新闸门第一版假报率未知，接了就是把人训练成无视告警（I-08/I-09）。
    if bg_warns:
        print(f"   🟠 背景断线告警（⛔ 不判废、⛔ 不挂退出码，**要人放大目检确认**）："
              + "、".join(f"{k}（{'/'.join(v)}边）" for k, v in bg_warns.items()) + "\n"
              f"      成因：G-2【复制边缘】补边在有斜切的背景上造出一条「斜切突然变垂直」的假边界，"
              f"AI 平滑它时向上侵入真实内容区 ⇒ 裁回后那一带的斜切线断掉。\n"
              f"      👉 目检确认真断了 ⇒ 那个模块改 \"mode\": \"composite\"（背景由 HTML 渲、"
              f"不进 AI ⇒ 该失效模式结构上消失）。⛔ 别重掷：这是补边几何必然造出来的，不是随机走样。\n"
              f"      📌 只有**补过边**的模块跑得到这一条（主图 1000² 比例 1:1 无需补边 ⇒ 天然不跑）。")

    # 🆕 I-72 收尾【待用户确认】清单 —— ⛔ 别只列模块名（那又是一份"看了也不知道该干嘛"的告警）。
    if pending:
        print(f"\n🟡【待用户确认】{len(pending)} 张图重掷 {COPY_OCR_RETRIES} 轮仍没过 ③⁰ 文案审核，"
              f"已**照常出图**落到 {out_dir}：")
        for k, items in pending.items():
            print(f"   · {k}：")
            for it in items:
                print(f"       - {it}")
        print("   🔴 脚本**没有**替你选处置（三个选项的代价完全不同，判定权在用户）：\n"
              "      ① 放大目检后觉得能用 ⇒ 直接用（③⁰ 是筛子不是判官，OCR 也会读错）。\n"
              "      ② 点名字样再重掷 ⇒ ⚠️ 本站 `gen_image.py` **还没有 `--keep-text`**，"
              "现在重掷 = 原路重掷，多半同样的错（先给 gen_image.py 补这个参数才真管用）。\n"
              "      ③ 退回 overlay（`RENDER_V2_COPY_OCR=0` 重跑这几个模块）⇒ 文案像素级精确，"
              "**但会有双影风险**（overlay 是「盖」不是「擦」，由 ③½ 去查）。\n"
              "      ④ 改 `mode: composite` ⇒ 全分辨率精确、不调 AI，**但要先有干净透明抠图件**"
              "（cutout.py 在同事机器上不稳，是兜底不是常规解）。")

    # 🆕 停机横幅：**放在最末尾、原样打印**（契约 §6 要"醒目横幅 + 停机"）。
    #   ⛔ 别摘要、别改写、别只打一句"有商标成分"——横幅里列着【命中成分 · 出处 · 通用名替换建议】，
    #     那三样正是 Bowen 回话需要的全部信息；摘掉了他没法回，人就只能再跑一遍脚本。
    #   放最后是因为并发日志几百行，最后一屏才是人真会读的地方。
    if stops:
        print("\n" + "═" * 72)
        print(f"🛑 停机：{' '.join(stops)} 需要【Bowen 本人回一句话】才能继续。\n"
              f"   ⛔ 不是脚本出错（那是退出码 1）、⛔ 不是检查没跑成（那是 2）、⛔ 更不是通过。"
              f"整脚本以退出码 {FACTS_STOP_CODE} 结束。")
        # 🔴 停机与真失败可以同时发生。退出码只能有一个 ⇒ 取 3（不问就没法继续，问是前置动作），
        #   但**必须明说还有别的问题**：否则同事看见 3 只去问 Bowen，回来重跑又踩同一堆 ❌。
        if fails or _bad:
            print(f"   ⚠️ 本次【同时】还有 {len(fails) + len(_bad)} 项真失败/废图（上面的 ❌ 各行）。"
                  f"退出码取 {FACTS_STOP_CODE} 只是因为停机询问是前置动作，"
                  f"⛔ 别以为问完 Bowen 就万事大吉 —— 那些也要一并修。")
        for k, banner in stops.items():
            print(f"\n──  {k} 的原始横幅（原样透传，⛔ 未改写）  ──\n{banner}")
        print("\n" + "═" * 72)
        print("   👉 拿这份横幅去问 Bowen：这些商标成分能不能用？\n"
              "      · 全部/部分同意 → 把同意的成分名写进 product.json 的 m7.facts.trademark_ok，"
              "并把他的原话回填进 facts._approved，然后重跑 build + 本脚本。\n"
              "      · 都不同意 → m7.facts.mode 改 \"demo\"（保留剂量结构、成分名换品类通用名，"
              "⛔ 图上不出现任何商标），重跑。\n"
              "      🔴 Bowen 2026-08-09 定：**他说同意就算数，⛔ 别要求他提供授权方或授权文件**。\n"
              "      🔴 但商标风险本身仍在（阿里被投诉即删图/扣分）—— 同意的是我们承担这个风险，"
              "不是风险消失了。")
        sys.exit(FACTS_STOP_CODE)
    # 🔴 退出码判据 —— 每加一道闸门就必须往这里挂一次，否则那道闸门等于只是打印。
    #   2026-08-05 那次翻车正是【5 张废图 + 退出码 0】：③½ 明明能看出双影，却没挂进退出码。
    #     stops        🆕 子脚本退出码 3 =【需要人答复】（m7 商标成分未获同意）—— 已在**上面**
    #                  单独 sys.exit(3) 掉了，⛔ 绝不并进下面这个 1：3 和 1 撞码 = 人会去修一个
    #                  不存在的 bug，而正确动作只是去问 Bowen 一句话（契约 §7 的原话教训）。
    #     fails        某模块根本没出成图（⛔ 已把 stops 排除在外，理由见 fails 那行注释）
    #     scene_bads   ③½ --scene 重画了我方文案 = 双影，且 ③½R 自动重掷 SCENE_RETRIES 轮后仍在
    #                  （重掷清掉的不会留在这里；剩下的 = 结构病，先改版式，composite 是第 3 级兜底）
    #     scene_errs   ③½【没跑成】（检测器缺失/中间件缺失/跑挂）—— 🔴 V2-6（Bowen 2026-08-06 定调）：
    #                  以前这三种情况 return False = 静默按通过，而提示语自己写着"⛔ 别当成通过"。
    #                  它是【双影图被交付】的唯一通道，现在 fail-closed：宁可停，不可静默放行。
    #     layout_bads  ④ 产品压到文字（P1-15：以前只打一行 ⚠️ 就放行，同一次跑里照打
    #                  「✅ 成品 / ✅ 完成 N/N」+ 退出码 0 —— 独立回检实测复现，判定它与双影
    #                  是同一个病，也正是 08-05 那张 m1 压住大标题 80px 漏网的完整机制）
    #     pending      🆕 I-72 ③⁰ 文案审核重掷用尽仍不过 —— 图**照常出了**（ok=True），
    #                  但门禁没过就必须挂退出码：闸门报了错却不挡交付，等于没有闸门。
    #                  ⛔ 别因为"图出来了"把它算通过。
    #     spec_bads    🆕 I-74 ⑤ 产品包装上原厂印的规格数字被改（净含量/粒数）—— 与 layout_bads 同级：
    #                  它是**产品信息造假**，比压字更硬。
    #     🔴 spec_unchecked（⑤ 退出码 2 = 没跑成）**故意不在这一行里**，⛔ 别"顺手补上"：
    #                  Windows 云 OCR 不可用就会落到那一态，挂了退出码 = 同事那边每批必红 ——
    #                  `verify_label` 旧版正是这么假报的（v1.20 才改成退 0 + 人工核对提示）。
    #                  它靠的是**抬头行的计数 + 上面那段 🟠 点名 + 每张日志里的限定词**去被看见，
    #                  ⛔ 但它也绝不能被当成通过（那是另一头的病）。这两条同时成立才是这一态的定义。
    if fails or scene_bads or scene_errs or layout_bads or layout_errs or pending or spec_bads:
        sys.exit(1)
    # 🆕 I-86⒊：这一整段人工核对指引**只对走 V2 的那些成立** —— composite / 无 swap 的图
    #   压根没进过 AI，拿 `--scene` 的注意事项去核它们，等于把人的注意力浪费在不可能发生的问题上
    #   （而真正要核的"产品件是不是本款"反而没人提，那正是 P1-16 交出白袋子的那次）。
    if done_v2:
        print(f"\n   🔴 走 V2 场景替换的这 {len(done_v2)} 张（{' '.join(done_v2)}）"
              f"逐张 Read 放大核产品印刷小字（--scene 会改）。")
    if COPY_OCR_ON and done_v2:
        # 🔴 ⛔ 别在这条路上打"双影 → 重掷"那句：走 ③⁰ 的图**一张都没 overlay** ⇒ 没有双影源，
        #    打了只会教人去查一个结构上不存在的问题。这条路真正要人眼看的是【版式漂移/被切】。
        print("   · **我方文案**：内容已由 ③⁰ 逐条核过（OCR），但**版式与字体是 AI 模仿的** —— "
              "整块可能漂几到二十几 px、也可能被画布切掉一截（③⁰ 是筛子不是判官，字全对也可能被削）。"
              "\n     ⇒ 重点核【四边完整 + 相对位置】。看着实在不像我们的版式，就把那张退回 overlay："
              "`RENDER_V2_COPY_OCR=0` 只重跑那个模块（代价：可能双影，由 ③½ 去查）。")
    elif done_v2:
        print("   · **我方文案**双影 → 重掷那一张（"
              + (f"本脚本已自动掷 {SCENE_RETRIES} 轮" if SCENE_RETRIES
                 else "⚠️ 自动重掷被 RENDER_V2_SCENE_RETRIES=0 关掉了，要自己重跑")
              + "），仍中才改版式；composite 是第 3 级兜底。")
    if done_v2:
        print("   · **产品自印**小字/规格被改（净含量、营养成分表）→ 重掷没用（AI 每次都会改），"
              "那张走合成法（swap 加 \"mode\": \"composite\"）；"
              "确需像素级精确由用户明确要求才走抠图（references/cutout.md）。")
    # 🆕 I-74：⑤ 已经把上面这条的**数字**那一半接成机器闸门了，但它只管数字 ——
    #   ⛔ 别让人读成"产品自印字已经全机器守住了"，那就把人眼从另一半上撤走了。
    # 🔴🔴 I-83（2026-08-18）：这一句原来是**无条件**打印的绝对陈述「⑤ 已机器核过…」，
    #   例外从句只覆盖 `spec_unchecked`（当时 = 退出码 2）。而六图实测 ⑤ 的四种表现里
    #   **一次都没真正核到净含量**：m1 假红 · d1 一个 token 没读到却 PASS ·
    #   d2/d3「各尺度不一致 → 按设计放过」。同事读到那句会以为净含量被机器守住了，实际没有。
    #   ⇒ 改成**按实际状态分支**：只有真核到（⑤ 退 0）的模块才配得上"已机器核过"这四个字。
    #   ⛔ 别再合并成一句"已核过 + 例外" —— 那正是把「未校验」读成「校验过了」的病灶本身。
    if SPEC_CHECK_ON:
        if spec_ok:
            print(f"     └ ⑤ 已机器核过【数字+单位】那一类（净含量/粒数/条数）的是这 {len(spec_ok)} 张："
                  f"{' '.join(spec_ok)}。"
                  "🔴 但成分名、认证标、口味这些**字母类**改动它一概查不出 —— 那半仍要人眼放大核。")
        if spec_unchecked:
            print(f"     └ 🟠 【产品规格未自动校验】这 {len(spec_unchecked)} 张："
                  f"{' '.join(spec_unchecked)} —— ⑤ 没跑成 / 产品区一个规格 token 都没读到 /"
                  f" 各尺度判定不一致（原因见上面各自的 🟠）。\n"
                  f"       ⛔ 这**不是**「核过了」：这几张的净含量/粒数**没有任何机器看过**，"
                  f"数字那一半也得人眼放大 300%+ 逐个核。")
        if done_v2 and not spec_ok and not spec_unchecked:
            # 走 V2 却一张都没进 ⑤（理论上到不了，留着防将来加分支时静默漏掉）。⛔ 别说"已核过"。
            print("     └ ⚠️ ⑤ 这一批**一张都没跑到**，而本批有走 V2 的模块 —— 这是脚本 bug 或"
                  "闸门被半路跳过了，⛔ 别当「核过了」，往上翻各自的 ⑤ 日志。")
    # 🆕 I-86⒊：composite / 无 swap 的那几张单独说 —— 它们的核对重点与上面**正相反**。
    if done_comp or done_plain:
        print(f"\n   🧩 这 {len(done_comp) + len(done_plain)} 张**没进过 AI**"
              f"（合成法 composite {' '.join(done_comp) or '—'} · 通用件无 swap {' '.join(done_plain) or '—'}）："
              f"产品像素原样贴、文案由 HTML 原分辨率渲 ⇒ 不可能双影、不可能被改规格、也不会糊。\n"
              f"      ⛔ 上面那几条 `--scene` 的注意事项对它们**不成立**，⑤ 产品规格闸门也不跑它们"
              f"（机制上改不了，⛔ 不是「没查」）。\n"
              f"      🔴 它们真正要核的是另一件事：**产品槽里放的是不是本款产品**"
              f"（占位件/别款抠图放进去照样全绿出图，见 P1-16 那次交出无品牌白袋）。")


if __name__ == "__main__":
    main()
