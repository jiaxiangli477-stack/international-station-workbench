#!/usr/bin/env python3
"""用 gpt-image-2 生成产品场景/口味素材（白底），供主图合成用。

⛔ 禁止用 AI 生成的东西（红线，会造假 + 法规风险）：
     工厂 / 车间 / 产线 / 实验室 · 认证 logo 与证书 · 专利证书与专利号 · 客户证言
   这些必须用真实素材。AI 生成 = 伪造企业资质。

✅ 适合 AI 生成的：水果/水花/冰块、冲泡后的饮品杯、粉末质感、剖面微距等口味与场景件。

关键 prompt 经验（都是实测踩出来的）:
  · 加 `floating in mid-air, NO water puddle, no pool, no surface, no reflection,
    nothing beneath` —— 不写这句，AI 会把水果画成"泡在水洼里"，那摊水洼被水花围死，
    Flood Fill 从四边够不进去，会留成一块不透明白板，贴蓝底就是白斑。
    源头写死比事后抠图省事得多。
  · 风格块一字不动（见 STYLE），保证 10 款产品出图质感一致。
  · 未指定品牌时模型会自己编 logo 和文案 → 要么 prompt 锁死标签，要么喂参考图。

用法:
    python gen_image.py "cut mango with water splash" -o mango.png
    python gen_image.py --probe                       # 探活（出图前先跑）
    # 场景替换：把图1产品换进图2场景里原产品的位置（图2 必须是自家/授权图，禁竞品实拍图）
    python gen_image.py "the black cylinder jar" --scene scene2.png --product product1.png -o swapped.png

    # 🆕 生活/人物使用场景图【两步法】—— 场景贴真实用途 + 产品走中转 API 同步（禁本地贴图）
    #    作业指导见 references/scene-swap.md §生活/人物场景。至少一张场景带人物。
    # 第1步 文生图出场景，加 --lifestyle（套生活摄影块，⛔别用默认白底块=会死板），产品位留"无品牌占位物"：
    python gen_image.py "a woman resting on a sofa at home after a workout, a plain unbranded supplement pouch on the coffee table in front of her" --lifestyle -o scene_base.png
    # 第2步 用 --scene 把【本款真实产品图】换进占位处（产品保真）：
    python gen_image.py "the bottle on the nightstand" --scene scene_base.png --product 本款产品_白底.png -o scene_final.png
    # ⛔ 别先出场景再本地 compose 贴抠图产品——会浮、会穿帮。
"""
import argparse, base64, json, os, ssl, sys, urllib.error, urllib.request
from pathlib import Path


def _open(req):
    """统一发请求：把生图上游的临时故障（5xx/429）翻译成人话，别甩原始 traceback。"""
    try:
        with urllib.request.urlopen(req, timeout=540, context=_ssl_context()) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        if e.code in (429, 500, 502, 503, 504):
            sys.exit(f"生图上游暂时不可用（通道 {creds()[2]}，HTTP {e.code}）——上游临时故障、非本地问题。等几分钟重试即可。")
        raise

sys.path.insert(0, str(Path(__file__).parent))
from _compat import get_secret, missing_secret_help   # noqa: E402  （必须最先 import：修 Windows 编码）


def _ssl_context() -> ssl.SSLContext:
    """返回做【正常证书校验】的 SSL context —— ⛔ 不是关闭校验（那是拿安全换跑通，禁）。
    python.org 装的 Python（尤其 macOS）常没把系统 CA 接上 → HTTPS 全报
    CERTIFICATE_VERIFY_FAILED。优先用 certifi 的 CA 包（pip 生态标准做法），
    没有再退回系统默认。generate 和 edit 两条调用都走它。"""
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _png_from_data(d) -> bytes:
    """从 images 响应里取 PNG 字节。两种返回都认：
       · b64_json —— gpt-image-2 直接内嵌 base64；
       · url ——【实测 2026-07-30】TokenStation 有时把 edits 路由到别的后端
         （如 firefly-gpt-image-4k-1x1），只回一个图片链接 → 得再下载一次。
       不认这两种就会把"其实已生成的图"误报成失败（老逻辑只读 b64_json 踩过）。"""
    item = (d.get("data") or [{}])[0]
    if item.get("b64_json"):
        return base64.b64decode(item["b64_json"])
    if item.get("url"):
        req = urllib.request.Request(item["url"], headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(req, timeout=180, context=_ssl_context()) as r:
                return r.read()
        except urllib.error.URLError as e:
            sys.exit(f"图已生成但下载失败（{item['url']}）：{e}")
    err = json.dumps(d.get("error", d), ensure_ascii=False)[:300]
    if "No available compatible accounts" in err:
        sys.exit("中转账号池临时空了（非永久故障，稍后自行恢复）。\n"
                 "  等几分钟重试。⛔ 别改用 gpt-image-1/1.5 —— 这个分组根本没有它们。")
    sys.exit(f"生成失败: {err}")

# 风格块：一字不动。改它 = 10 款产品质感不一致。
STYLE = ("commercial e-commerce product photography, clean studio lighting, "
         "soft even softbox with subtle top rim light, high detail, photorealistic, 8k, "
         "sharp focus, minimal soft shadow, no text, no watermark, no logo, "
         "square 1:1 composition")

# 白底 + 悬空。不写这段就会得到"泡在水洼里"的素材，抠图必留白板。
ISOLATE = ("isolated on pure white seamless background, floating in mid-air, "
           "NO water puddle, no pool, no standing water, no surface, no table, "
           "no reflection, nothing beneath")

# 🆕 生活/人物场景风格块（`--lifestyle` 专用，Bowen 2026-07-31 定，与国内 skill 对称）：
# ⛔ 生活场景【绝不】套 STYLE / ISOLATE —— 那两块是"白底悬空影棚产品照"，套到生活场景上
#    会得到无菌、发死、产品像悬浮标本的画（同事反馈"死板、不好看、嵌入不自然"的根因）。
# ✅ 这块给的是【真实生活摄影】方向：镜头 / 光质 / 氛围 / 景深 / 构图都写厚，让画面接地、自然。
# 不锁死画面比例（1:1 / 4:5 竖 / 横 由 --size 决定；竖构图在 subject 里补 "vertical portrait framing"）。
# 用途：主图 / 详情页里"谁在什么场合用"的生活/使用场景照的【第1步 文生图底图】。第2步再 --scene 换真产品。
LIFESTYLE_STYLE = (
    "authentic lifestyle photography, candid editorial style, real-life documentary feel, "
    # 镜头 + 景深：中焦大光圈、浅景深、背景自然虚化 —— 治"平、贴、假"
    "shot on a 50mm lens at f/2.0, shallow depth of field, softly blurred background bokeh, "
    # 光质 + 氛围：自然窗光/柔和方向光、暖调、有空气感的时刻，不是影棚硬光
    "soft natural window light with gentle directional shadows, warm inviting ambience, "
    "airy atmospheric mood, subtle film grain, "
    # 构图 + 环境：非居中三分法、真实道具与生活环境、不摆拍
    "off-center rule-of-thirds composition, lived-in real environment with natural props, "
    "genuine relaxed unposed moment, "
    # 保底质感（不含 white/studio/floating）
    "photorealistic, high detail, 8k, sharp focus on the subject, "
    "no text, no watermark, no logo"
)

# 锚点模式（--anchor）：拿一张【已批准的产品图 A0】做图生图，换构图/摆放但【锁死包装身份】。
# 作业指导 + 三种摆放方式的完整提示词见 references/anchor-placement.md。
# 这两段是【通用锚点锁定 + 反向约束】，脚本自动加在你给的摆放提示词前后，同事不会漏。
# 🔴 每次都用【原始 A0】当锚点，⛔ 别拿上一张生成图当下一张锚点（防包装漂移累积）。
# 🔴 edit 不保证小字像素级不变 → 出图后必跑 verify_label.py + 人工放大（见文档末"重要限制"）。
ANCHOR_LOCK = (
    "Use the attached anchor image as the sole source of truth for product identity. "
    "The product package must remain visually unchanged: same pouch/bottle/box shape, same "
    "front-facing orientation, same color blocking, same label layout, same typography hierarchy, "
    "same LIFEWORTH / ODM mark, same product name, flavor, claims, badges and specifications. "
    "Do not redesign, redraw, simplify, replace, rotate, open, reshape, recolor, or relabel the package. "
    "Do not invent a new package, alternate flavor, alternate claims, alternate logo, or different product format. "
    "Do not use any previously generated image as the product reference. "
    "Only change the scene, background, lighting, scale, crop, and placement of the approved anchor product. "
    "Keep one approved product package only."
)
ANCHOR_NEGATIVE = (
    "Negative constraints: no redesigned packaging, no altered label, no rewritten product name, "
    "no changed flavor, no changed count, no changed claims, no second finished package, no duplicate "
    "product, no floating distorted package, no warped typography, no fake certification, no FDA Approved, "
    "no cure, no treat, no disease claims, no watermark, no gibberish text, no collage, no unfinished "
    "template, no placeholder box."
)

# 场景替换模式（--scene）：把【产品图/图1】里的产品，精准替换进【场景图/图2】里原本那个产品/物体的位置，
# 其余元素（背景/道具/构图）一律不动。传两张图：--scene <图2 底图> + --product <图1 产品>。
# 🔴🔴 用途红线（防侵权铁律）：场景底图只能用【我们自己拍的 / 自己 AI 生成的 / 有授权的】图。
#   ⛔ 绝不许拿【竞品的实拍/营销图】当场景底图换产品 —— 那是复刻竞品实拍与构图，是侵权。
#   竞品图只能"借构图思路"、另起一张我们自己的场景。作业指导见 references/scene-swap.md。
# 🔴 edit 不保证产品小字像素级不变 → 出图后必跑 verify_label.py + 人工放大核对。
SCENE_REPLACE = (
    "You are given two images: the FIRST is the SCENE image, the SECOND is the PRODUCT reference image. "
    "Precisely place the product from the PRODUCT reference image into the SCENE, replacing the existing "
    "product or object that currently occupies that spot. Keep the product's original shape, material, "
    "color, texture, label layout, typography and every fine detail exactly unchanged. "
    # 🔴 保持比例 + 多件都保留（能量胶实测：单占位会把盒拉高变形、还会丢掉条包）
    "Keep the product's NATURAL proportions and aspect ratio — scale it UNIFORMLY; do NOT stretch, "
    "elongate, squash, rotate or distort it. If the PRODUCT reference shows MULTIPLE pieces (e.g. a box AND "
    "a sachet/stick), you MUST keep ALL pieces, standing side by side exactly as shown — do not drop any piece. "
    "Re-match perspective, scale, color temperature, brightness, saturation and lighting direction to the "
    "scene environment. Fix any unrealistic overlap, edges and occlusion. Add natural highlights, a soft "
    "contact shadow, environmental reflections and a realistic cast shadow. Remove all visual seams so the "
    "product blends completely with the scene in lighting, space and atmosphere. "
    "Change nothing else: keep the background, props, other objects, framing and overall composition of the "
    "SCENE identical."
)

# 🆕 多引用一次生成（--element）：产品 + 元素(产品色载体/配件)一次性提交、一次重绘同时换。
# 实测（能量胶）：比"先换产品再换元素"分步做好——少一层累积漂移、比例更稳。
# ⚠️ 每个 --element 是 image[2]、image[3]…，subject/--raw 提示词里要点名"用 image N 换掉场景里的哪个占位物"。
SCENE_MULTI_HINT = (
    "\n\nADDITIONAL ELEMENT reference images follow the product (image 3, image 4, ...). "
    "Replace each corresponding placeholder element in the SCENE (e.g. the fruit / flavor element in a corner) "
    "with the matching element reference, keeping a natural fresh look and the same position. "
    "Every element must correspond to THIS product (flavor/theme) — do not leave any other product's element."
)
SCENE_NEGATIVE = (
    "Negative constraints: do not redesign, redraw, relabel, recolor, reshape or rotate the product; do not "
    "alter the product name, flavor, count, claims, badges or specifications; do not change the scene "
    "background, props, other objects, framing or composition; no duplicate product, no second package, no "
    "warped typography, no gibberish text, no fake certification, no FDA Approved, no watermark, no added "
    "text, no collage."
)


# 🔴 出图质量档默认 = medium（Bowen 2026-08-01 拍板，两套 skill 对称）：
#   实测（生图前后读 total_usage 取差值）：low≈¥0.05/张(偏糙) · medium≈¥0.12/张(清晰一档) · high 中转会降级成 medium 拿不到。
#   🔴 成本杠杆【只有 quality + 模型分档】——老通道 TokenStation 不遵守 `size`（请求 1024² 实回 1254²/1122×1402）；
#     deepkey 则由**模型名**定尺寸（`-1k`/`-2k`/`-4k`）。⛔ 两条通道下 `size` 都控不了成本。
#   想省成本单张手动 `--quality low`；⛔ 别指望 --size 控成本。
QUALITY_DEFAULT = "medium"

# ⚠️ 必须自带 User-Agent：TokenStation 上了 WAF，黑名单屏蔽默认的 `Python-urllib/x.y`
#    （实测：urllib 默认 UA → HTTP 502 "upstream access forbidden"；任意正常 UA → 200）。
#    不改这行，脚本会被上游当爬虫挡掉，稳定 502，而 curl 却能通——极易误判成"账号池抖动"。
USER_AGENT = "lifeworth-b2b-image/1.0"


# 🔴 生图通道 = **deepkey**（Bowen 2026-08-06 起改；两套 skill 对称）
#   为什么换：deepkey 提供**按分辨率分档的型号**（`gpt-image-2-1k` / `-2k` / `-4k` = 1024² / 2048² / 2880²），
#   尺寸由【模型名】精确控制；而 TokenStation 的 `gpt-image-2` **不遵守 `size` 参数**
#   （实测请求 1024² 实回 1122×1402 / 1254² 等，尺寸由模型自己定）。同批实测 deepkey 还快约 1.85 倍、并发不排队。
#   🔴 **默认仍是 1K**（`gpt-image-2-1k`）—— Bowen 2026-08-06：「默认 1k 即可，不要 2k，2k 成本较高」。
#     ⛔ 别把默认改成 `-2k`/`-4k`：本项目版式主图 1000²、详情页产品最多 1536px，2K 只是白烧钱。
#
# 🔴 **deepkey 的两把 key 分组不重叠，必须分开存**（都是 51 位，肉眼分不出，弄混了报错还看不懂）：
#     · **生图组**（本脚本用）：`DEEPKEY_IMAGE_API_KEY` / `DEEPKEY_IMAGE_BASE_URL` —— 里面**没有** gpt-5.x 文本/视觉模型
#     · **文本组**：`DEEPKEY_TEXT_API_KEY` / `DEEPKEY_TEXT_BASE_URL` —— 里面**没有**生图模型
#   ⚠️ 所以 `verify_label.py` 的云 OCR 走**文本组**（见下面 `OCR_PROVIDERS` / `creds_ocr()`），
#     ⛔ 绝不能共用这一组生图凭据。两把 key 都是 51 位、肉眼分不出，必须分行分组写清楚。
#
# 🔴 **按【组】配对取值，⛔ 不许跨组拼**：key 取 deepkey、base 取 TokenStation = 把 deepkey 的 key
#   发给 TokenStation，必然 401 而且看不出原因。所以下面是"一组里 key 和 base 都齐才算数"，
#   不是逐个字段各自找最先有的那个（老写法就是后者，混配了也不报警）。
#   组内别名顺序 = 优先级：显式 `*_IMAGE_*` > 通用 `DEEPKEY_*` > 老通道 `TOKENSTATION_*` / `OPENAI_*`。
#   （老通道保留：同事还没配 deepkey 时照样能跑，行为一字未变。）
PROVIDERS = [
    ("deepkey",
     ["DEEPKEY_IMAGE_API_KEY", "DEEPKEY_API_KEY"],
     ["DEEPKEY_IMAGE_BASE_URL", "DEEPKEY_BASE_URL"]),
    ("tokenstation",
     ["TOKENSTATION_API_KEY", "OPENAI_API_KEY"],
     ["TOKENSTATION_BASE_URL", "OPENAI_BASE_URL", "OPENAI_API_BASE"]),
]
# 每条通道的默认型号。⛔ 别给 tokenstation 填 `-1k`：那边没有分档型号，会直接报「模型不存在」。
DEFAULT_MODEL = {"deepkey": "gpt-image-2-1k", "tokenstation": "gpt-image-2"}

# 🔴 云 OCR（`verify_label.py` 在非 macOS 上读图取字）用的是**文本/视觉模型**（现行 `gpt-5.5`，
#   见 verify_label.py 的 CLOUD_OCR_MODEL），而 deepkey 的**生图组 key 里没有任何文本模型**
#   ⇒ ⛔ 它绝不能共用上面那组生图凭据。所以单列一张通道表：
#   **现行走 deepkey 文本组**（Bowen 2026-08-06 定）；TokenStation 只作兜底 ——
#   ⚠️ 实测 TokenStation 的 gpt-5.x 视觉调用回 **HTTP 503**，那条兜底路目前是不通的，别指望它。
#   ⛔ 别把 DEEPKEY_IMAGE_* 加进这张表 —— 加了就是拿生图 key 去调文本模型，必然失败且看不出原因。
#   🔴 **表里只有 deepkey 文本组这一档，⛔ 别把 TokenStation 加回来当兜底**（Bowen 2026-08-06 定）：
#     实测 `GET /v1/models`，TokenStation 这把 key 的分组里**只有 gpt-image-2 一个模型**，
#     根本没有任何 gpt-5.x —— 所以调它必回 HTTP 503，那不是临时故障、是模型不在组里。
#     把一个**已知不通**的档留在兜底位，唯一效果是制造"我有兜底"的错觉：
#     没配 DEEPKEY_TEXT_* 的机器会一路落到它、503、抛 CloudOCRUnavailable、
#     然后 verify_label 打一句"退回人工核对"**并退出码 0** —— 标签检查根本没跑，退出码却是绿的。
#     摘掉之后，缺凭据就直接点名「缺 DEEPKEY_TEXT_*」，指向明确、可执行。
OCR_PROVIDERS = [
    ("deepkey-text", ["DEEPKEY_TEXT_API_KEY"], ["DEEPKEY_TEXT_BASE_URL"]),
]

_CREDS: dict = {}


def _pick(providers: list, what: str, hint: list) -> tuple:
    """按【组】配对取凭据，返回 `(base_url, key, provider)`。

    🔴 为什么是"整组齐了才算"而不是 key/base 各自找最先有值的那个（老写法）：
      各自找会拼出 **key 来自 A 家、base 指向 B 家** 的组合 —— 把 A 的 key 发给 B，
      必然 401，而报错里完全看不出是配串了。2026-08-06 换 deepkey 时这个坑就在眼前。
    取值顺序：环境变量 → 项目 .env → ~/.zshrc（详见 _compat.py）。
    ⛔ 别改回只读 ~/.zshrc：那是 macOS+zsh 专属路径，Windows 同事直接卡死在这。
    """
    if what in _CREDS:
        return _CREDS[what]
    got = get_secret(*[n for _p, ks, bs in providers for n in ks + bs])
    for prov, ks, bs in providers:
        key = next((got[n] for n in ks if got.get(n)), None)
        base = next((got[n] for n in bs if got.get(n)), None)
        if key and base:                       # 🔴 整组齐了才用，⛔ 不跨组拼
            _CREDS[what] = (base.rstrip("/"), key, prov)
            return _CREDS[what]
    sys.exit(missing_secret_help(hint))


_WARNED_LEGACY = False


def creds() -> tuple:
    """**生图**凭据 `(base_url, key, provider)`。⛔ 别改回只返回两个值 —— 调用方要靠 provider 决定默认型号。

    🔴 落回老通道时**要出声**（每进程一次）：老通道能用，但它不遵守 `size`，
      实测请求 1024² 会实回 1122×1402 之类，而 render_v2 的 cover+center-crop 会把多出来的边裁掉
      ⇒ 画面边缘内容跟你以为的不一样。不打这句的话，人只会觉得"图怎么怪怪的"。
    """
    global _WARNED_LEGACY
    got = _pick(PROVIDERS, "image", [
        "DEEPKEY_IMAGE_API_KEY + DEEPKEY_IMAGE_BASE_URL（生图通道，现行默认）",
        "或老通道 TOKENSTATION_API_KEY + TOKENSTATION_BASE_URL",
        "（自查三组凭据通不通：python scripts/check_env.py）",
    ])
    if got[2] == "tokenstation" and not _WARNED_LEGACY:
        _WARNED_LEGACY = True
        print("⚠️ 生图走的是【老通道 TokenStation】（没配 DEEPKEY_IMAGE_*，已自动落回）。可以用，但要知道两件事：")
        print("   · 型号只有 gpt-image-2，**不遵守 size** —— 实测请求 1024² 会实回 1122×1402 之类，")
        print("     render_v2 随后按画布等比缩放+居中裁，**边缘内容会被裁掉**（不是 bug，是没得选）。")
        print("   · 实测比 deepkey 慢约 1.8 倍（54.9s vs 30s）。")
        print("   👉 想走 deepkey：配上 DEEPKEY_IMAGE_BASE_URL / DEEPKEY_IMAGE_API_KEY（见 .env.example）。")
    return got


def creds_ocr() -> tuple:
    """**云 OCR**（verify_label）凭据 `(base_url, key, provider)`。⛔ 别拿 creds() 顶替它，见 OCR_PROVIDERS 注释。"""
    return _pick(OCR_PROVIDERS, "ocr", [
        "DEEPKEY_TEXT_API_KEY + DEEPKEY_TEXT_BASE_URL（云 OCR 唯一通道，deepkey【文本组】）",
        "⛔ 别拿生图组的 DEEPKEY_IMAGE_* 顶替：那一组里没有任何文本模型",
        "⛔ TOKENSTATION_* 也顶不了：实测那把 key 的分组里只有 gpt-image-2 一个模型，没有 gpt-5.x",
        "（自查三组凭据通不通：python scripts/check_env.py）",
    ])


def model() -> str:
    """本次用哪个生图型号：`GEN_IMAGE_MODEL` 覆盖 > 按通道取默认。
    ⛔ 别改回模块级常量：默认值取决于走的是哪条通道，import 的时候还不知道。"""
    return os.environ.get("GEN_IMAGE_MODEL") or DEFAULT_MODEL[creds()[2]]


# 🔴 分辨率策略（Bowen 2026-07-31 定，2026-08-06 换 deepkey 后照旧）：出图【默认 1K，绝不 2K】。
#   🔴 换 deepkey 之后尺寸其实由**模型名**决定（`gpt-image-2-1k` = 1024²），`size` 只是配合；
#     这道归一仍然留着 —— 它挡的是"某处手滑传了 2048x2048"，两条通道下都是一层保险。
#   · gpt-image-2 只认这三个尺寸；本项目版式里 2K 根本用不到（主图 1000²、详情页产品最多 1536px），
#     出 2K 只是白烧 token+时间。所有生图都在 call()/call_edit() 这个唯一入口归一到 1K 家族，
#     任何 2K/超大请求按长宽比降到 1K 并告警 —— 从代码层堵死"不小心出 2K"。
ALLOWED_SIZES = {"1024x1024", "1536x1024", "1024x1536"}


def _norm_size(size: str) -> str:
    """把任何尺寸归一到 gpt-image-2 支持的 1K 家族；2K/非法值降到 1K 并告警（默认 1K，禁 2K）。"""
    s = (size or "").lower().strip()
    if s in ALLOWED_SIZES:
        return s
    try:
        w, h = (int(x) for x in s.split("x"))
    except Exception:
        print(f"⚠️ 尺寸 {size!r} 无法解析 → 按 1K 方图 1024x1024 出。")
        return "1024x1024"
    snapped = "1536x1024" if w > h else ("1024x1536" if h > w else "1024x1024")
    if max(w, h) > 1536:
        print(f"⚠️ 请求尺寸 {size} 超过 1K 上限 → 按【默认 1K，禁 2K】归一到 {snapped}。")
    else:
        print(f"ℹ️ 尺寸 {size} 非 gpt-image-2 支持值 → 归一到 {snapped}（1K 家族）。")
    return snapped


def call(prompt: str, size: str = "1024x1024", quality: str = QUALITY_DEFAULT) -> bytes:
    size = _norm_size(size)
    base, key, _prov = creds()
    req = urllib.request.Request(
        f"{base}/v1/images/generations",
        data=json.dumps({"model": model(), "prompt": prompt, "size": size, "quality": quality, "n": 1}).encode(),
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json",
                 "User-Agent": USER_AGENT},
    )
    d = _open(req)   # 单张 ~49 秒，超时给足（_open 统一处理临时故障）
    return _png_from_data(d)


# 🔴 edits 输入图上限（pitfalls.md §9，实测）：
#   喂 1254² → 540 秒无响应超时；缩到 1024² → 76 秒正常返回。
#   以前全靠人记着先缩（库里 cpm2-pouch-clean.png 正好 1254²，踩过一次），
#   现在在【唯一出口】_multipart 里自动缩 —— 不管从 --anchor / --scene / --product / --element
#   哪条路进来，上传前一律过这一关。
# ⚠️ 只缩【发给 API 的内存副本】，⛔ 绝不回写用户磁盘上的源文件。
# ⚠️ 与 _norm_size() 无关：那个管【出图尺寸】，这个管【输入图尺寸】，两回事，别互相搬。
EDIT_MAX_SIDE = 1024


def _fit_for_edit(path: Path) -> bytes:
    """返回可以直接上传的图片字节：最长边 >1024 就 LANCZOS 等比缩到 1024，否则原样返回。

    ⛔ 已经 ≤1024 的图【原字节直接返回】—— 不重新编码（省掉无谓的画质损失和耗时）。
    ⚠️ 透明件（RGBA / LA / 带 transparency 的 P）必须保住 alpha，缩完仍存 PNG。"""
    raw = path.read_bytes()
    try:
        import io
        from PIL import Image
    except ImportError:
        print(f"⚠️ 没装 Pillow，跳过 edits 输入图尺寸自检：{path.name}"
              f"（>{EDIT_MAX_SIDE}² 会让 /v1/images/edits 挂死，见 pitfalls.md §9）")
        return raw
    try:
        with Image.open(io.BytesIO(raw)) as im:
            w, h = im.size
            if max(w, h) <= EDIT_MAX_SIDE:
                return raw                      # ← 没超限：原样上传，不动一个字节
            scale = EDIT_MAX_SIDE / max(w, h)
            nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
            # 保 alpha：P/LA 这类模式 resize 前先转成带 alpha 的 RGBA，别把透明底压成黑边。
            mode = im.mode
            if mode in ("RGBA", "LA"):
                im = im.convert("RGBA")
            elif mode == "P":
                im = im.convert("RGBA" if "transparency" in im.info else "RGB")
            elif mode not in ("RGB", "L"):
                im = im.convert("RGB")
            lanczos = getattr(Image, "LANCZOS", None) or Image.Resampling.LANCZOS
            buf = io.BytesIO()
            im.resize((nw, nh), lanczos).save(buf, format="PNG")
    except Exception as e:
        print(f"⚠️ 读不了 {path.name}（{e}）→ 原样上传，尺寸自检跳过。")
        return raw
    print(f"↘️  edits 输入图超限自动缩：{path.name} {w}×{h} → {nw}×{nh}"
          f"（LANCZOS，只改上传副本，源文件不动；>{EDIT_MAX_SIDE}² 会 540 秒超时，见 pitfalls.md §9）")
    return buf.getvalue()


def _multipart(fields: dict, images) -> tuple:
    """手搓 multipart/form-data（只用 stdlib，跨平台不引第三方库）。
    images 可以是单个 Path，也可以是 Path 列表（场景替换要同时喂场景图+产品图）。
    多图时字段名用 image[]（gpt-image edits 的数组写法）；单图沿用 image（--anchor 老路径不变）。
    每张图上传前都过 _fit_for_edit()：超 1024² 自动缩（pitfalls.md §9）。"""
    if isinstance(images, (str, Path)):
        images = [images]
    images = [Path(p) for p in images]
    field = "image" if len(images) == 1 else "image[]"
    boundary = "----lifeworthAnchorBoundary7MA4YWxkTrZu0gW"
    out = []
    for k, v in fields.items():
        out.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode()
        )
    for img in images:
        out.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{field}"; '
            f'filename="{img.name}"\r\nContent-Type: image/png\r\n\r\n'.encode()
            + _fit_for_edit(img) + b"\r\n"
        )
    out.append(f"--{boundary}--\r\n".encode())
    return b"".join(out), boundary


def call_edit(prompt: str, images, size: str = "1024x1024", quality: str = QUALITY_DEFAULT) -> bytes:
    """图生图：走中转的 /v1/images/edits 端点。
    images = 单张（--anchor 锚点图）或 [场景图, 产品图]（--scene 场景替换）。"""
    size = _norm_size(size)
    base, key, _prov = creds()
    body, boundary = _multipart({"model": model(), "prompt": prompt, "size": size, "quality": quality, "n": "1"}, images)
    req = urllib.request.Request(
        f"{base}/v1/images/edits",
        data=body,
        headers={"Authorization": f"Bearer {key}",
                 "Content-Type": f"multipart/form-data; boundary={boundary}",
                 "User-Agent": USER_AGENT},
    )
    d = _open(req)
    return _png_from_data(d)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("subject", nargs="?", help="主体描述 / 或 --anchor 模式下的【摆放构图提示词】")
    ap.add_argument("-o", "--out")
    ap.add_argument("--size", default="1024x1024",
                    help="🔴 默认 1K，禁 2K：只出 1024x1024 / 1536x1024 / 1024x1536；传更大会自动归一到 1K 家族"
                         "（⚠️ 老通道 TokenStation 不遵守 size；deepkey 由模型名 -1k/-2k/-4k 定尺寸。两边 size 都控不了成本）")
    ap.add_argument("--quality", default=QUALITY_DEFAULT, choices=["low", "medium", "high"],
                    help="🔴 质量档=成本杠杆（size 控不了成本）：默认 medium(≈¥0.12/张,清晰)；low(≈¥0.05,偏糙) 省成本；high 中转会降级成 medium")
    ap.add_argument("--raw", action="store_true", help="只用 subject 原文，不套风格块/白底块（或锚点锁定块）")
    ap.add_argument("--lifestyle", action="store_true",
                    help="🆕 生活/人物场景底图模式：套【生活摄影风格块 LIFESTYLE_STYLE】而非白底影棚块。"
                         "用于生活/使用场景照的【第1步文生图底图】，产品位留无品牌占位物，再 --scene 换真产品。"
                         "⛔ 别对生活场景用默认(白底)模式——会死板。见 references/scene-swap.md")
    ap.add_argument("--anchor", help="锚点图生图：给一张【已批准产品图 A0】路径，换构图但锁包装身份。"
                                     "subject 传摆放提示词，见 references/anchor-placement.md")
    ap.add_argument("--scene", help="场景替换：给【场景底图/图2】路径（被编辑对象），配合 --product。"
                                    "🔴 底图只能用自家/授权图，禁竞品实拍图。见 references/scene-swap.md")
    ap.add_argument("--product", help="场景替换模式下【要替换进场景的产品图/图1】路径（产品身份锁死）")
    ap.add_argument("--element", action="append", metavar="IMG",
                    help="🆕 一次生成多引用：额外的元素件（产品色载体/配件，如柑橘水花）。可重复给多个。"
                         "会和 --product 一起提交、一次重绘同时换。⚠️ 元素必须对应本产品；建议配 --raw 写清"
                         "'用 image N 换掉哪个占位物'。见 references/scene-swap.md【生产工作流 v2】")
    ap.add_argument("--probe", action="store_true", help="探活：出图前先确认服务可用")
    a = ap.parse_args()

    if a.probe:
        try:
            call("a red apple on pure white background", "1024x1024", "low")  # 探活用最便宜档
            print(f"✅ {model()} 可用（通道 {creds()[2]}）")   # 🔴 打真实型号+通道，别写死
        except SystemExit as e:
            print(f"❌ {e}"); sys.exit(1)
        return

    # 锚点模式：图生图，换摆放/场景但锁死包装身份（详情页 vs 主图各出一版，减少视觉疲劳）
    if a.anchor:
        anchor = Path(a.anchor)
        if not anchor.exists():
            sys.exit(f"锚点图不存在: {anchor}")
        if not (a.subject and a.out):
            sys.exit("锚点模式要给 subject（摆放构图提示词）和 -o 输出路径")
        # --raw：只用你写的；否则自动前置锚点锁定、后置反向约束（同事不会漏）
        prompt = a.subject if a.raw else f"{ANCHOR_LOCK}\n\n{a.subject}\n\n{ANCHOR_NEGATIVE}"
        out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(call_edit(prompt, anchor, a.size, a.quality))
        print(f"✅ {out}  ({out.stat().st_size/1024:.0f}KB)  ← 锚点图生图")
        print("   🔴 必做验收：python verify_label.py 核对标签 + 人工放大看包装文字/规格/口味没漂移。")
        print("      漂移了直接废弃重跑，⛔ 别拿这张当下一次锚点。")
        return

    # 场景替换模式：把 --product（产品/图1）精准换进 --scene（场景/图2）里原产品的位置，其余不动。
    # 🔴 场景底图只能用自家拍的/自己 AI 生成的/有授权的；⛔ 禁用竞品实拍图当底图（复刻=侵权）。
    if a.scene:
        scene = Path(a.scene)
        if not scene.exists():
            sys.exit(f"场景底图不存在: {scene}")
        if not (a.product and Path(a.product).exists()):
            sys.exit("场景替换要给 --product <产品图/图1> 且文件存在")
        if not a.out:
            sys.exit("场景替换要给 -o 输出路径")
        product = Path(a.product)
        # 🆕 额外元素件（产品色载体/配件）：和产品一起一次提交、一次重绘同时换（比分步稳，能量胶实测）
        elements = []
        for e in (a.element or []):
            ep = Path(e)
            if not ep.exists():
                sys.exit(f"元素件不存在: {ep}")
            elements.append(ep)
        # --raw：只用你写的 subject；否则套内置场景替换提示词 + 反向约束（subject 用来点名"换掉场景里的哪个物体"）
        if a.raw:
            prompt = a.subject or SCENE_REPLACE
        else:
            parts = [SCENE_REPLACE]
            if a.subject:
                parts.append(f"The specific object in the SCENE to replace with the product is: {a.subject}.")
            if elements:
                parts.append(SCENE_MULTI_HINT)      # 有元素件时加"image 3+ 换对应占位元素"
            parts.append(SCENE_NEGATIVE)
            prompt = "\n\n".join(parts)
        out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
        # 顺序固定：image[0]=场景（底图），image[1]=产品，image[2..]=元素件
        out.write_bytes(call_edit(prompt, [scene, product, *elements], a.size, a.quality))
        tail = f" + {len(elements)} 元素件一次生成" if elements else ""
        print(f"✅ {out}  ({out.stat().st_size/1024:.0f}KB)  ← 场景替换（图2 换上图1 产品{tail}）")
        print("   🔴 侵权红线：确认场景底图是自家/授权图，不是竞品实拍图。")
        print("   🔴 必做验收：verify_label.py 核对标签 + 人工放大看产品文字/规格没漂移，看融合有没有穿帮。")
        return

    if not (a.subject and a.out):
        sys.exit("要给 subject 和 -o 输出路径（或用 --probe / --anchor / --scene）")
    # 三条文生图路径：--raw 只用原文；--lifestyle 套生活摄影块（不套白底）；默认套白底影棚块。
    if a.raw:
        prompt = a.subject
    elif a.lifestyle:
        prompt = f"{a.subject}, {LIFESTYLE_STYLE}"        # 🆕 生活场景：接地、自然、有景深
    else:
        prompt = f"{a.subject}, {ISOLATE}, {STYLE}"       # 白底素材：悬空影棚，供抠图/合成
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(call(prompt, a.size, a.quality))
    print(f"✅ {out}  ({out.stat().st_size/1024:.0f}KB)")
    if a.lifestyle:
        print("   🎬 生活场景底图（产品位应是无品牌占位物）→ 下一步 --scene 换本款真产品。")
        print("   👉 先 Read 目检：光影自然/接地？产品位是占位物？无多余 logo/文字/竞品外观？")
    else:
        print("   👉 下一步：Read 这张图目检（拼写/是否有多余 logo/有没有水洼），再抠图。")


if __name__ == "__main__":
    main()
