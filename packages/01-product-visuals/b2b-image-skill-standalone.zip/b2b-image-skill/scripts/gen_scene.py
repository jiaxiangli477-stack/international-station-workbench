#!/usr/bin/env python3
"""生活/使用场景照【一键 glue】：--lifestyle 出底图 → --scene 换真产品 → 验收提示，串成一条命令。

用途：主图 / 详情页里"谁在什么场合用"的生活 / 使用场景照素材（海外 B2B listing）。
出一张要顺序跑两步 gpt-image-2（手跑容易漏、容易忘加 --lifestyle → 出白底死板图），本脚本串起来。
与国内 skill 的 `gen_scene.py` 对称——差别只在合规口径（见下铁律）。

机制（= V2 render_v2.py 第②步同引擎，"替换方法"一致）：
  · 换产品这一步 = `gen_image.py --scene`（同样的 SCENE_REPLACE 提示词、保比例、多件保留）。
  · ⚠️ 生活场景底图是 `--lifestyle` 文生图的【生活照】，里面**没有 HTML 文案层**
    → 所以【不走】render_v2.py 的 render-HTML底图 / overlay-锁文案两步（那两步对场景照用不上）。
    版式里的标题·卖点·徽章在【外层模块 HTML】里，由 build.py + render.py 出，与本脚本无关。

🔴 出图铁律（都写进了 references/scene-swap.md，脚本只是把步骤串起来，不替你判断）：
  · 场景要【先推导后生成】：先想清这款产品适用哪些场景，⛔ 别套"运动/办公/居家"三件套硬匹配。
  · base_prompt 六格填厚（谁·动作/何时·何场合/占位产品/环境道具/取景·构图），风格块 --lifestyle 自动加。
  · 底图只能用自家/授权/自己生成的（本脚本第1步就是自己生成，天然合规）；⛔ 竞品实拍图当底图=侵权。
  · 产品自印小字会被 --scene 重绘改（大字保真、满身小字的罐必漂）→ 出完必逐条放大核，
    漂了就【重跑 --scene】（换角度/多试几张）。⛔ 别自作主张切抠图：V2 场景替换是默认路径
    （Bowen 2026-07-31）。**唯一的切换条件是「有人明确说走抠图模式」** —— ⛔ 不是"小字漂了就切"、
    也不是"看着需要精确就切"，那条旧规则已废除；走法见 `references/cutout.md`（白底产品用 flood，⛔ 别用 rembg）。
  · 🔴 **国际站合规（比国内宽）**：海外 B2B 补剂**可以讲用法/用时/生活方式**（含睡前/居家/运动）——
    人物做真实使用动作、使用时刻都 OK。但仍守：① 画面别出现真实认证 logo / 他人品牌 / 竞品外观；
    ② 文字若带功能/健康表达 → 【改成零宣称：纯规格 / 品类 / 服务能力】，⛔ 阿里禁任何 FDA 内容
       （连免责段本身都禁，别从产品实物标签面搬过来），见 `compliance.md` §3 / `copy-compliance.md` §2.1；
       仍禁 cure/treat/disease 类疾病·疗效词。出图后跑 `verify_copy.py`。

用法（两种）:
    # A. 批量：配置文件（推荐，一组场景一次跑完）
    python gen_scene.py scenes.json -o out/
    #   配置结构见 assets/schemas/scene-set.example.json（顶层 product/size 兜底，每个场景可覆盖）

    # B. 单张：命令行直接给（快速试一张）
    python gen_scene.py --name scene_gym \
        --base-prompt "a young woman ... after a home workout, ... a plain unbranded supplement pouch on the coffee table, ... vertical portrait framing" \
        --product ../assets/library/product-assets/xxx_white.png \
        --subject "the unbranded supplement pouch on the coffee table" \
        --size 1024x1536 -o out/

    python gen_scene.py --probe        # 出图前先探活（透传给 gen_image.py）
"""
import argparse, json, os, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （必须 import：修 Windows 管道输出 emoji 崩溃）

SCRIPTS = Path(__file__).resolve().parent
GEN = SCRIPTS / "gen_image.py"
PY = sys.executable or "python"

# 🆕 并发出场景（Bowen 2026-07-31）：TokenStation 实测支持 4 路真并发 → 一批场景同时出，提速约 3-4 倍。
# 每张内部两步（--lifestyle → --scene）仍串行；场景之间并发。RENDER_V2_WORKERS 可覆盖（1=串行）。
WORKERS = max(1, int(os.environ.get("RENDER_V2_WORKERS", "4")))


def _run(cmd: list, out: list) -> None:
    """跑子步骤（gen_image.py），输出【收集进 out】（并发时按场景缓冲，避免交织）。失败 raise（不 sys.exit，线程安全）。

    🔴 成功时也要收 stderr（2026-08-04，与 render_v2._run 同一处理）：子脚本可能在退出码 0 的情况下
       往 stderr 打【跳过检查/降级】类的醒目提示（render.py 的"引用逃出了构建目录"就是），只收 stdout
       会让它彻底静默 = "不报错、只安静出错图"。非空才 append，不刷屏。
       失败时【不在这里】收：stderr 已由下面的异常带走，再 append 会打两遍。"""
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.stdout.strip():
        out.append("   " + r.stdout.rstrip().replace("\n", "\n   "))
    if r.returncode != 0:
        raise RuntimeError(f"步骤失败（退出码 {r.returncode}）：{' '.join(str(c) for c in cmd)}\n{r.stderr.rstrip()}")
    if r.stderr.strip():
        out.append("   " + r.stderr.rstrip().replace("\n", "\n   "))


def _clean(d: dict) -> dict:
    """丢掉 _ 开头的注释键（和 build.py / render_v2.py 一个约定）。"""
    return {k: v for k, v in d.items() if not str(k).startswith("_")}


def one_scene(name: str, base_prompt: str, product: Path, subject: str,
              elements: list, size: str, out_dir: Path, keep: bool):
    """出一张生活/使用场景照：① --lifestyle 出底图 → ② --scene 换真产品。
    返回 (name, 日志字符串, 成功bool)。🆕 并发安全：不 print、不 sys.exit。"""
    out = []
    try:
        if not product.exists():
            raise RuntimeError(f"{name}: 真产品图不存在 {product}")
        base = out_dir / f"{name}_base.png"
        final = out_dir / f"{name}.png"

        # ① 生活场景底图（--lifestyle 自动套生活摄影块；产品位是 base_prompt 里写的无品牌占位物）
        out.append(f"—— {name} · 第1步 出生活场景底图（--lifestyle）——")
        _run([PY, str(GEN), base_prompt, "--lifestyle", "--size", size, "-o", str(base)], out)

        # ② 换真产品（= V2 的 --scene 替换：保比例/多件保留，同一个引擎）
        out.append(f"—— {name} · 第2步 --scene 换真产品 ——")
        gcmd = [PY, str(GEN), subject, "--scene", str(base), "--product", str(product),
                "--size", size, "-o", str(final)]
        for el in elements:
            el = _clean(el) if isinstance(el, dict) else {}
            ep = el.get("product")
            if not ep:
                continue
            epath = Path(ep)
            if not epath.exists():
                raise RuntimeError(f"{name}: 元素件不存在 {epath}")
            gcmd += ["--element", str(epath)]
        _run(gcmd, out)

        if not keep:
            base.unlink(missing_ok=True)
        out.append(f"✅ {name}: 生活/使用场景照 → {final}")
        out.append("   👉 放大核（V2 同款）：①产品【自己印的小字/规格】有没有被 --scene 改乱（AI 重绘，最易漂）"
                   "②融合有无穿帮③画面无真实认证 logo/他人品牌/竞品外观。")
        out.append("   🔴 产品自印小字可能被重绘 → 出图后逐条放大核，漂了【重跑 --scene】（换角度/多试）；"
                   "确需像素级精确时，由用户明确要求才走抠图（⛔ 不自动切）——"
                   "只有你/同事明确说走抠图模式时才走，走法见 references/cutout.md。"
                   "文字若带功能表达 → 改成零宣称/纯规格；⛔ 阿里禁任何 FDA 内容（含免责段本身），"
                   "见 compliance.md §3 / copy-compliance.md §2.1。跑 verify_copy.py。")
        return name, "\n".join(out), True
    except Exception as e:  # noqa: BLE001
        out.append(f"❌ {name} 失败：{e}")
        return name, "\n".join(out), False


def resolve_product(rel: str, base_dir: Path) -> Path:
    """产品/元素相对路径：批量模式相对配置文件目录，单张 CLI 相对 cwd。"""
    p = Path(rel)
    return p if p.is_absolute() else (base_dir / p).resolve()


def main() -> None:
    ap = argparse.ArgumentParser(description="生活/使用场景照一键出图（--lifestyle 底图 → --scene 换真产品）")
    ap.add_argument("config", nargs="?", help="场景配置 JSON（批量模式）；见 assets/schemas/scene-set.example.json")
    ap.add_argument("-o", "--out", help="成品输出目录")
    ap.add_argument("--keep", action="store_true", help="保留中间底图（默认删）")
    ap.add_argument("--probe", action="store_true", help="探活（透传给 gen_image.py）")
    # 单张 CLI 模式
    ap.add_argument("--name", help="单张模式：文件名（如 scene_gym）")
    ap.add_argument("--base-prompt", help="单张模式：底图六格提示词（风格块 --lifestyle 自动加）")
    ap.add_argument("--product", help="单张模式：真产品图路径")
    ap.add_argument("--subject", help="单张模式：换掉场景里哪个占位物（如 the pouch on the table）")
    ap.add_argument("--size", default="1024x1536", help="尺寸（竖=1024x1536 默认 / 方=1024x1024 / 横=1536x1024）")
    a = ap.parse_args()

    if a.probe:
        out = []
        try:
            _run([PY, str(GEN), "--probe"], out)
        except Exception as e:  # noqa: BLE001
            out.append(str(e))
        print("\n".join(out))
        return

    if not a.out:
        sys.exit("要给 -o 输出目录")
    out_dir = Path(a.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    # 批量模式：读配置
    if a.config:
        cfg_path = Path(a.config).resolve()
        cfg = _clean(json.loads(cfg_path.read_text(encoding="utf-8")))
        base_dir = cfg_path.parent
        top_product = cfg.get("product")
        top_size = cfg.get("size", a.size)
        scenes = cfg.get("scenes") or []
        if not scenes:
            sys.exit(f"❌ 配置里没有 scenes 数组：{cfg_path}")
        # 解析所有场景（串行、快），再并发出图
        tasks = []
        for sc in scenes:
            sc = _clean(sc)
            name = sc.get("name")
            base_prompt = sc.get("base_prompt")
            subject = sc.get("subject", "")
            if not (name and base_prompt and subject):
                sys.exit(f"❌ 场景缺字段（name/base_prompt/subject 必填）：{sc}")
            prod_rel = sc.get("product") or top_product
            if not prod_rel:
                sys.exit(f"❌ {name}: 没有 product（场景内或顶层都要有一处）")
            tasks.append((name, base_prompt, resolve_product(prod_rel, base_dir), subject,
                          sc.get("elements") or [], sc.get("size", top_size)))

        # 🆕 并发出图（≤WORKERS 路）：输出按提交顺序缓冲后统一打印（不交织）；某张失败不影响其他
        print(f"生活/使用场景照批量：{len(tasks)} 张，≤{WORKERS} 路并发 → {out_dir}")
        results = {}
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            futs = {t[0]: ex.submit(one_scene, *t, out_dir, a.keep) for t in tasks}
            for t in tasks:
                name, log, ok = futs[t[0]].result()
                print("\n" + log)
                results[name] = ok
        fails = [n for n, ok in results.items() if not ok]
        print(f"\n✅ 完成 {len(results) - len(fails)}/{len(results)} 张 → {out_dir}")
        if fails:
            print(f"   ❌ 失败：{' '.join(fails)}（往上翻各自 log）")
            sys.exit(1)
        print("   🔴 逐张 Read 放大核产品印刷小字（--scene 会改），错就那张【重跑 --scene】（换角度/多试）；"
              "确需像素级精确时由用户明确要求才走抠图（⛔ 不自动切）——"
              "只有你/同事明确说走抠图模式时才走，走法见 references/cutout.md。")
        return

    # 单张 CLI 模式
    if not (a.name and a.base_prompt and a.product and a.subject):
        sys.exit("单张模式要给 --name --base-prompt --product --subject（或给配置文件走批量）")
    _n, log, ok = one_scene(a.name, a.base_prompt, resolve_product(a.product, Path.cwd()), a.subject,
                            [], a.size, out_dir, a.keep)
    print(log)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
