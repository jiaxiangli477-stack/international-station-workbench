"""跨平台兜底。所有脚本第一行 import 它，别绕过。

两件事，都是「不修就在 Windows 上安静炸掉」的：

1. Windows 控制台编码
   脚本的提示里有 ✅ ⛔ 🔴。Windows 的 locale 编码是 GBK，装不下这些字符。
   直接在终端跑时 Python 走 WriteConsoleW 还能显示，**但 Claude Code / Codex 是用管道
   接走 stdout 的** —— 一旦是管道，Python 就退回 locale 编码 → UnicodeEncodeError 崩溃。
   而报错内容通篇在讲 codec，跟真实原因（"你在 Windows 上跑"）毫无关系，极难自查。
   → 这里强制把 stdout/stderr 设成 UTF-8，用户不需要配 PYTHONUTF8 也能跑。

2. 密钥读取
   原来只会翻 ~/.zshrc —— 那是 macOS + zsh 的专属路径，Windows 根本没这文件。
   → 改成三级兜底：环境变量 → 项目 .env → ~/.zshrc（Mac 老配置的向后兼容）。
"""
# 🔴 必须在所有 import 之前（2026-08-05）：让类型注解【延迟求值】，
#    否则 `-> Path | None` 这种 3.10+ 新语法会在 def 时就被求值 →
#    Python 3.9 直接 TypeError，而【所有脚本都 import 本文件】= 整套跑不起来。
#    实测：macOS 自带的 /usr/bin/python3 就是 3.9.6。
#    这一行支持 3.7+，加了它就不需要再对外声明"最低 Python 版本"。
from __future__ import annotations

import os
import sys
from pathlib import Path


def _fix_stdio() -> None:
    """Windows 管道输出下强制 UTF-8，否则 emoji 直接崩。Mac/Linux 上是空操作。"""
    for stream in (sys.stdout, sys.stderr):
        try:
            if stream and hasattr(stream, "reconfigure") and (stream.encoding or "").lower() not in ("utf-8", "utf8"):
                stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass  # 兜底失败也不能让脚本挂在这一步


_fix_stdio()


def _parse_env_file(path: Path) -> dict:
    """极简 .env 解析。不引第三方库——这套脚本的依赖越少，同事装环境越不容易翻车。"""
    out = {}
    try:
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            line = line.removeprefix("export ").strip()   # 兼容直接从 .zshrc 抄过来的写法
            if "=" not in line:
                continue
            k, v = line.split("=", 1)
            out[k.strip()] = v.strip().strip('"').strip("'")
    except OSError:
        pass
    return out


def find_env_file() -> Path | None:
    """找 .env：先从当前工作目录往上找，再从脚本所在位置往上找。

    两条路都要走，因为这两个位置经常不是一回事：
      · 工作目录 —— 同事在自己的项目根目录跑脚本，.env 放那儿最自然；
      · 脚本位置 —— skill 装在 <项目>/.claude/skills/ 下，往上走也能摸到项目根。
    只找一条的话，另一种摆法就读不到，而报错只会说"读不到配置"，人根本猜不到是为什么。

    这样无论从哪个目录跑、用 Claude 还是 Codex，都读同一份配置——
    不依赖终端会话、不依赖 shell 类型，Mac 和 Windows 写法完全一致。
    """
    roots = []
    try:
        roots.append(Path.cwd().resolve())
    except OSError:
        pass                                    # 工作目录被删了之类的极端情况
    roots.append(Path(__file__).resolve().parent)

    seen = set()
    for root in roots:
        for d in [root] + list(root.parents):
            if d in seen:
                continue
            seen.add(d)
            cand = d / ".env"
            if cand.is_file():
                return cand
    return None


def get_secret(*names: str) -> dict:
    """按 环境变量 → .env → ~/.zshrc 的顺序取配置，返回 {名字: 值}，取不到的键不出现。

    ⚠️ 永远不要把返回值打印出来。
    """
    found = {n: os.environ[n] for n in names if os.environ.get(n)}
    if len(found) == len(names):
        return found

    env_file = find_env_file()
    if env_file:
        data = _parse_env_file(env_file)
        for n in names:
            if n not in found and data.get(n):
                found[n] = data[n]
    if len(found) == len(names):
        return found

    # 向后兼容：Bowen 这台 Mac 的老配置在 ~/.zshrc，而 agent 的 bash 不自动加载它
    zshrc = Path.home() / ".zshrc"
    if zshrc.is_file():
        data = _parse_env_file(zshrc)
        for n in names:
            if n not in found and data.get(n):
                found[n] = data[n]
    return found


def missing_secret_help(names: list) -> str:
    """配置读不到时给人话，而不是让人去猜。"""
    env_file = find_env_file()
    where = f"（已找到 {env_file}，但里面没有这些键）" if env_file else "（没找到 .env 文件）"
    return (
        f"读不到配置：{', '.join(names)} {where}\n"
        f"\n"
        f"最省事的修法 —— 在项目根目录建一个名为 .env 的文件，按【三组】写（⛔ 别互相顶替）：\n"
        f"    # 生图（gen_image.py，默认型号 gpt-image-2-1k）\n"
        f"    DEEPKEY_IMAGE_BASE_URL=https://deepkey.top\n"
        f"    DEEPKEY_IMAGE_API_KEY=sk-你自己的生图密钥\n"
        f"    # 云 OCR（verify_label.py 非 macOS 读图，模型 gpt-5.5）—— ⛔ 生图组那把顶不了，它没有文本模型\n"
        f"    DEEPKEY_TEXT_BASE_URL=https://deepkey.top\n"
        f"    DEEPKEY_TEXT_API_KEY=sk-你自己的文本密钥\n"
        f"    # 老通道兜底（没配 deepkey 的机器靠它；生图用 gpt-image-2）\n"
        f"    TOKENSTATION_BASE_URL=https://tokenstation.top\n"
        f"    TOKENSTATION_API_KEY=sk-你自己的密钥\n"
        f"\n"
        f"  🔴 .env 绝不能提交 Git、发微信、截图。密钥一人一把，别共用。\n"
        f"  📖 详细步骤见项目根目录的 环境配置-Mac.md / 环境配置-Windows.md\n"
        f"\n"
        f"（也支持环境变量。Mac 配在 ~/.zshrc 的话，agent 的 bash 不会自动加载，\n"
        f"  得先 source ~/.zshrc；Windows 用 setx 后必须重开终端。.env 没这些麻烦。）"
    )
