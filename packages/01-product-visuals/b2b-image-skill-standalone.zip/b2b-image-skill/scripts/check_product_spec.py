#!/usr/bin/env python3
"""产品【规格数字】被改检查 —— 守「AI 把包装上原厂印的净含量/粒数改掉」这一层。

═══ 为什么需要它（2026-08-17 真出图当场逮到，不是推演）═══
`--scene` 把整张图交给 AI 重绘，**产品包装上原厂印的规格数字会被改**：
  实证：d1 源产品图印 `NET WT. 360G` `(12.70 OZ)`，成品变成 `NET WT. 300G` `(12.70 OZ)`
        —— 12.70 oz = 360.0 g，两个数字**自相矛盾**；而净含量是买家下单要看的规格。
而出图管线里【没有任何机器闸门守这一层】，四道检查全绿放行：
  · check_copy_ocr  按设计**只核我方 HTML 文案**，不核产品自印字；
  · check_layout    只查产品有没有压住文字；
  · qc.py           只量颜色配比；
  · verify_label.py **根本不在 render_v2 链路里**（只是 QC 清单上的人工步骤）。
本脚本补的就是这一格：**源产品图 vs 成品产品区，规格数字有没有变**。

═══ 三条硬约束（都是实测定的，⛔ 别凭感觉改）═══
① **必须放大到 3x 再 OCR**。实测成品 d1.png(1500×864)：1x / 2x 都**读不到**产品净含量，
   3x 才读到 `NETWT:300G`。
② **必须裁产品区**再比对。整图 3x 会把我方文案里那个**正确的** `30 Sticks • 360g`
   一起读进来，把真实矛盾**掩盖掉**（源图 360G 在整图里"找得到"⇒ 判成没改）。
③ **判据只能靠「数字 + 单位」，⛔ 不能靠字母**。OCR 会把 `NET` 读成 `KET`/`NETWT:`，
   靠字母比对必然假报。

═══ 判据（⛔ 别扩大：这套 skill 反复在治的病是「假报把人训练成无视告警」）═══
【判据①】唯一决定退出码，**三态**（🔴 2026-08-17 / I-83 改：旧版把三档含义压成一档 PASS）。
   规格 token = 数字 + 单位（G/KG/MG/MCG/OZ/LB/ML/L/STICKS/CAPSULES/SERVINGS/COUNT…）。
     · **1（判废）**：同一单位、数字不同、且源图那个数字在产品区里一个都找不到，
                      **且所有尺度都这么判、读出来的新数字还互相对得上**
                      （各尺度读出不同的错数字 = OCR 在瞎猜，⇒ 归 2 不归 1，实测 d2 220G vs 226G）；
     · **0（PASS）**：源图的每**个** token 都**至少有一个尺度原样读到**、且没有任何尺度判它被改
                      —— 只有这一档能说"核过了"（某个尺度漏读只是没证据，不算矛盾）；
     · **2（未校验）**：源图有 token 但产品区**完全读不到**（框没套准 / OCR 读不动），
                        或**各尺度判定互相打架**。⛔ 这两种旧版都打 PASS —— 六图实测的结果是
                        本闸门**一次都没真正核到净含量**，而它就是为这件事生的。放过 = 把不确定
                        写成确定。
     · 成品多出来的 token ⇒ 只告警（不影响退出码）。
【判据②】只告警，⛔ 不进退出码。成品产品区【内部单位自洽】：同时读到质量的公制值与
   英制值（G↔OZ、KG↔LB），换算后偏差 >5% 就点名（d1 那张：300G vs 12.70OZ 差 20%）。
   ⚠️ 它只告警，是因为 **OCR 常漏读其中一个**（实测 d1 的 `(12.70 OZ)` 无论怎么裁怎么放大
   都读成 `【122002）`），做成硬判据必假报。

═══ 双尺度交叉验证（防假报，实测逼出来的）═══
🔴 实测：d3（**未被改**）用一个偏紧的产品框 + 单跑 3x，OCR 把糊掉的净含量读成 `0G`
   ⇒ 判据① 会当成「G 单位数字从 360 变成 0」**假报**。所以：
   **在 3x 和 4x 两个尺度各读一遍，只有两次都判「被改」才判 1**。另外过滤掉数字为 0 的
   token（`0 G` 不是真规格）。实测这条不影响真阳性：d1 在 3x/4x、松框/紧框下都稳定判 1。
   🔴 **两次不一致 ⇒ 退出码 2（未校验），⛔ 不再"按设计放过"打 PASS**（I-83）：
   不一致的含义是"这个数字机器没看清"，不是"这个数字没被改"。宁可漏判 1，也**不许**把
   "没看清"写成"看过了没问题" —— 后者会让人以为净含量已被机器守住。

═══ 产品区怎么定（🔴 I-81 改过，先读这段再动手）═══
  1. `--box x,y,w,h`（成品像素坐标）—— 显式，**最可靠，也是框套不准时的正解**。
     `product.json` 里给该模块写 `"swap": {"spec_box": [x, y, w, h]}`，render_v2 会透传成 `--box`。
  2. `--build-dir/--html/--size` —— 起一次 Chrome 跑 DOM 探针。探针**模板**复用
     `check_layout.build_probe()`，但**选择器用本文件的 `SPEC_SELECTORS`（窄，只收主产品槽）**，
     ⛔ 不是 `check_layout.PRODUCT_SELECTORS`（宽，连 `img.scene` 都收）—— 两张表的用途正相反，
     共用一份就是 I-81 那两种相反的翻车。
     ⚠️ **这个框只是起点、不是真值**：它量的是【底图 DOM】，而 `--scene` 每次都在**移动并放大
     产品**（2026-08-17 实测：m2 左移 9px · m1 左移 26px · d3 左移 58px/宽 +19% · d1 左移 110px/
     放大 16%）。框没套准 ⇒ 产品区读不到 token ⇒ 按 I-83 **退 2（未校验）**，⛔ 不会静默 PASS。
  3. 两者都没给（或探针找不到主产品槽）⇒ **退出码 2「没跑成」**，
     ⛔ 绝不用拍脑袋的默认比例静默出结果，也绝不当通过。

═══ OCR ═══
用 `verify_label.ocr(path)`，返回 **[(文字, 置信度), ...] 的 2 元组列表**。
🔴 按下标取值（`t[0]` / `t[1]`），⛔ 别写元组解包 —— 国内有人把它改成三元组，
   当场让另一道闸门 `ValueError` 整个跑不起来。
macOS 走系统 Vision（本地、**零成本**，可随便跑）；Windows 落 deepkey 文本组的云 OCR，
云 OCR 不可用 ⇒ 退出码 2（没跑成）+ 打印人工核对清单，⛔ 不假报成失败。

═══ 退出码 ═══
  0 = **逐个核实过、没被改**（⛔ 只有这一档能对外说"净含量已机器核过"）
  1 = 规格数字被改（判废）
  2 = **未校验** —— 没跑成（产品区定不了 / OCR 跑不了 / 图读不了），
      **或跑成了但没能核实**（产品区读不到 token / 各尺度打架）。⛔ 既不当通过也不当失败。
      🔴 调用方（render_v2 收尾）必须按三态分支说话，⛔ 别对 2 也打"已机器核过"。

═══ 用法 ═══
  python3 check_product_spec.py 成品.png --src 源产品图.png --box 900,150,470,670
  python3 check_product_spec.py build/d1.png --src cut/pouch.png \
          --build-dir build --html d1.html --size 750x432
  python3 check_product_spec.py --selftest
"""

import argparse
import base64
import json
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （必须 import：修 Windows 管道输出下 emoji 崩溃）

# ── 单位表 ────────────────────────────────────────────────────────────────
# 归一化：复数/别名 → 规范单位。⛔ 别随手往里加"看着像单位"的词：单位表越大，
#    「同一单位、数字不同」的碰撞面越大，假报越多。
UNIT_CANON = {
    "KG": "KG", "G": "G", "GRAM": "G", "GRAMS": "G", "MG": "MG", "MCG": "MCG", "UG": "MCG",
    "OZ": "OZ", "LB": "LB", "LBS": "LB",
    # 🔴 FLOZ（液量盎司）必须和 OZ（质量盎司）**分开**：混在一起会让判据②
    #    拿 "2.1 FL OZ" 去和克数换算 → 必假报。normalize_blob 会把 "FL. OZ." 折成 FLOZ。
    "FLOZ": "FLOZ",
    "ML": "ML", "L": "L",
    "STICK": "STICK", "STICKS": "STICK",
    "CAPSULE": "CAPSULE", "CAPSULES": "CAPSULE", "CAPS": "CAPSULE",
    "TABLET": "TABLET", "TABLETS": "TABLET",
    "SOFTGEL": "SOFTGEL", "SOFTGELS": "SOFTGEL",
    "GUMMY": "GUMMY", "GUMMIES": "GUMMY",
    "SACHET": "SACHET", "SACHETS": "SACHET",
    "PACKET": "PACKET", "PACKETS": "PACKET",
    "SERVING": "SERVING", "SERVINGS": "SERVING",
    "COUNT": "COUNT", "CT": "COUNT",
    "IU": "IU",
}
# 长的排前面，否则 `KG` 会先被 `G` 吃掉半截、`LBS` 被 `LB` 截断。
_UNIT_ALT = "|".join(sorted(UNIT_CANON, key=len, reverse=True))
# (?<![\d,]) 挡住 "1,000 G" 里被切出来的 "000"；\s{0,2} 兼容 "360G" 与 "12.70 OZ"；
# (?![A-Z])  挡住 "360GRAMS" 被读成 360G 这类截断（GRAMS 自己在表里，会整词命中）。
TOKEN_RE = re.compile(r"(?<![\d,])(\d+(?:\.\d+)?)\s{0,2}(" + _UNIT_ALT + r")(?![A-Z])")

# 质量单位换算成克（判据②用）
TO_GRAM = {"G": 1.0, "KG": 1000.0, "MG": 0.001, "MCG": 1e-6, "OZ": 28.349523125, "LB": 453.59237}
METRIC_MASS = {"G", "KG", "MG", "MCG"}
IMPERIAL_MASS = {"OZ", "LB"}
MASS_TOL = 0.05          # 判据②：公制/英制换算偏差超过 5% 才点名
DEFAULT_SCALES = (3, 4)  # 🔴 3x 是硬底线（1x/2x 读不动）；4x 只作交叉验证

# ── 产品区选择器（🔴 I-81：本表**只属于本脚本**，⛔ 别 import check_layout.PRODUCT_SELECTORS）──
# 一份选择器表被两个用途共用 = 结构性必错，因为两个用途要的范围**正相反**：
#   · `check_layout` 要**尽量宽**的网 —— 凡是可能盖住字的都得抓，所以它收了 `img.scene`
#     （注释自己写着「也会探进文字区」）；
#   · 本脚本要**尽量窄**的框 —— 只圈「印着规格数字的那个主产品」。
# 2026-08-17 六图实测，拿宽网当窄框用出了两种相反的翻车：
#   · m1 **假红判废**：`img.scene` 的芒果 left=112 把左侧文案栏整个吞进并集 ⇒ 产品区
#     x=63 y=166 w=920 h=827 几乎整张画布 ⇒ OCR 把**我方药丸文案 `5g Creatine Monohydrate`**
#     当成产品自印规格 ⇒ 报「360G 被改成 5G」退出码 1。
#   · d1 **假绿放行**：并集框 x=1032..1471，而 `--scene` 把产品挪到了 x=933..1385
#     ⇒ 产品区一个 token 都没读到 ⇒ 旧版打 ✅ PASS（现在归 2，见 I-83）。
# ⛔ 加模板时只往这里加**主产品槽**；次包装/场景件/三品并排一律别加。
SPEC_SELECTORS = [
    "img.main",        # m1-brand-hero.html / m2-pain-hook.html 的主包装
    ".main img",       # 同上的 wrapper 写法
    ".prod img",       # d1-hero.html
    ".prodwrap img",   # d3-formula.html
    ".pcard img",      # d2-benefits.html
    # ⛔ 故意不收：img.scene（水果/冲泡杯，会探进文案栏）、img.second（条包，规格与主袋不同）、
    #    img.p（d4 三品并排，三款各自的规格互相打架）。它们仍归 check_layout 管。
]


# ── 纯函数区（--selftest 直接测这几个，不碰 OCR / 不碰真图）─────────────────
def normalize_blob(lines):
    """OCR 行列表 → 一条大写文本。
    用空格拼接**相邻行**：包装上的 `30` / `STICKS` 常被 OCR 拆成两行，拼起来才认得出
    「数字 + 单位」。全角数字/括号一并折成半角；`1,000` 的千分位逗号去掉。"""
    txt = " ".join(str(x) for x in lines)
    txt = txt.translate(str.maketrans("０１２３４５６７８９（）．", "0123456789()."))
    txt = re.sub(r"(?<=\d),(?=\d{3}(?!\d))", "", txt)
    txt = txt.upper()
    # "2.1 FL OZ" / "FL. OZ." → FLOZ（液量盎司，⛔ 不能落到质量 OZ 上）
    txt = re.sub(r"\bFL\.?\s{0,2}OZ\.?", "FLOZ", txt)
    return txt


def fmt_num(s):
    """数字归一化：'12.70' 与 '12.7' 视为同一个数。"""
    v = float(s)
    return f"{v:g}"


def extract_tokens(lines):
    """从 OCR 行列表提取规格 token，返回 set[(数字字符串, 规范单位)]。
    ⛔ 过滤掉数字为 0 的 token：`0 G` 不是真规格，是 OCR 把糊字读崩的产物
       （实测 d3 未被改的图就吐过 `0G`，不滤会直接假报）。"""
    blob = normalize_blob(lines)
    out = set()
    for num, unit in TOKEN_RE.findall(blob):
        n = fmt_num(num)
        if float(n) == 0:
            continue
        out.add((n, UNIT_CANON[unit]))
    return out


def judge_changed(src_tokens, fin_tokens):
    """判据①（单次尺度）：返回 (changed, missing, extra)。
    changed = [(单位, 源数字, 成品里同单位的数字们)] —— 同一单位、数字不同、
              且**源图那个数字在产品区里一个都找不到**（跨单位也找不到）。
    missing = [(数字, 单位)]  源图有、成品该单位一个 token 都没读到 ⇒ 只告警。
    extra   = [(数字, 单位)]  成品多出来的 ⇒ 只告警。"""
    fin_by_unit = {}
    for n, u in fin_tokens:
        fin_by_unit.setdefault(u, set()).add(n)
    fin_nums_any = {n for n, _ in fin_tokens}

    changed, missing = [], []
    for n, u in sorted(src_tokens):
        same_unit = fin_by_unit.get(u)
        if not same_unit:
            missing.append((n, u))          # OCR 漏读方向 → 只告警
        elif n in same_unit or n in fin_nums_any:
            pass                            # 原样保留
        else:
            changed.append((u, n, sorted(same_unit)))
    extra = sorted(t for t in fin_tokens if t not in src_tokens)
    return changed, missing, extra


def check_unit_coherence(fin_tokens):
    """判据②（只告警）：成品产品区内部，公制质量 vs 英制质量换算是否自洽。
    返回 [(公制token, 英制token, 相对偏差)]，偏差 > MASS_TOL 才返回。"""
    met = [(n, u) for n, u in fin_tokens if u in METRIC_MASS]
    imp = [(n, u) for n, u in fin_tokens if u in IMPERIAL_MASS]
    bad = []
    for mn, mu in sorted(met):
        for inn, iu in sorted(imp):
            a = float(mn) * TO_GRAM[mu]
            b = float(inn) * TO_GRAM[iu]
            if a <= 0 or b <= 0:
                continue
            # 分母取 min：偏差按「小的那个」算，和人读标签时的直觉一致
            # （300g vs 12.70oz=360g ⇒ 说成「差 20%」而不是 17%）。反正只告警。
            dev = abs(a - b) / min(a, b)
            if dev > MASS_TOL:
                bad.append(((mn, mu), (inn, iu), dev))
    return bad


# ── OCR 包装 ──────────────────────────────────────────────────────────────
class NotRun(Exception):
    """本脚本没跑成（产品区定不了 / OCR 不可用 / 图读不了）→ 退出码 2，⛔ 不是通过也不是失败。"""


def ocr_lines(img_path, box, scale, tmpdir, min_conf, dump=None):
    """裁产品区 → 放大 scale 倍 → OCR。返回 OCR 文字行列表。
    🔴 `verify_label.ocr()` 返回的是 **[(文字, 置信度)] 的 2 元组列表** ——
       这里**按下标取值** `t[0]`/`t[1]`，⛔ 不做元组解包：万一哪天有人把它改成 3 元组，
       解包会当场 ValueError 把整道闸门打死（国内已经踩过一次）。"""
    from PIL import Image
    from verify_label import CloudOCRUnavailable, ocr
    try:
        im = Image.open(img_path).convert("RGB")
    except Exception as e:  # noqa: BLE001
        raise NotRun(f"读不了图片 {img_path}：{type(e).__name__} {e}")
    if box:
        x, y, w, h = box
        x0, y0 = max(0, int(x)), max(0, int(y))
        x1, y1 = min(im.width, int(x + w)), min(im.height, int(y + h))
        if x1 - x0 < 8 or y1 - y0 < 8:
            raise NotRun(f"产品区裁出来是空的：box={box} 图尺寸={im.size}")
        im = im.crop((x0, y0, x1, y1))
    im = im.resize((im.width * scale, im.height * scale), Image.LANCZOS)
    out = Path(tmpdir) / f"crop_{scale}x.png"
    im.save(out)
    if dump:
        im.save(dump)
    try:
        res = ocr(str(out))
    except CloudOCRUnavailable as e:
        raise NotRun(f"云 OCR 不可用（{e}）")
    except SystemExit as e:
        raise NotRun(f"OCR 退出：{e}")
    # 按下标取值，⛔ 别解包
    return [str(t[0]) for t in res if len(t) < 2 or float(t[1]) >= min_conf]


# ── 产品区：复用 check_layout 的 DOM 探针 ──────────────────────────────────
GROW_PAD = 2.0   # 停在挡路件外侧留 2 CSS px，别贴着切


def _grow_box(box, blockers, limits, grow):
    """把产品框往【四周的空白处】各长一圈，长到贴上挡路件为止。box/blockers 都是 CSS px 的
    (l, t, r, b)；limits = 画布 (0, 0, cw, ch)；grow = 最多长原框的百分之几。

    🔴 为什么要长（I-81 ⒉）：框量的是【底图 DOM】，而 `--scene` 每次都在移动并放大产品
       —— 2026-08-17 实测 I-74 那张真阳性，包装上被改掉的 `NET WT. 300G` 落在 DOM 框
       **左边 67px 处**，不长就一个 token 都读不到、真阳性从判 1 掉成判 2。
    🔴 为什么不能随便长：长过头会把**别的东西**吞进产品区，读出它们的「数字+单位」当成
       "产品自印规格" —— 那就是 I-81 里 m1 假红的病（吞进我方药丸 `5g Creatine Monohydrate`
       ⇒ 报「360G 被改成 5G」）。所以只往**空白**长：
         · 我方文案的**文字墨迹**（不是元素盒，见 I-82）；
         · **邻居产品槽**（`img.second` 条包印着自己的 `12G`、`img.scene` 水果、`img.p` 三品并排）。
       挡路件若**横跨**原框那条边（说明它本来就和主产品叠着），该边**一步都不长**。
    ⛔ 别改成"按背景色/连通区域找产品真实外接框"：2026-08-17 在 m1/d1/d2/d3 四张真图上实测过，
       窗口里除了产品还有水果、条包、白卡片、渐变蓝斜带，掩码覆盖率 45%~96%，**四张里三张直接
       把整个搜索窗口原样吐回来**，等于没收窄（详见交回报告）。挡路件法是实测能用的那个。
    """
    l, t, r, b = box
    L0, T0, R0, B0 = limits
    gx, gy = (r - l) * grow, (b - t) * grow
    L, T, R, B = max(L0, l - gx), max(T0, t - gy), min(R0, r + gx), min(B0, b + gy)
    for bl, bt, br, bb in blockers:
        if bt < b and bb > t:                     # 纵向和原框有交叠 ⇒ 管左右
            if br <= l:
                L = max(L, br + GROW_PAD)         # 在左边挡着
            elif bl < l:
                L = l                             # 横跨左边缘 ⇒ 左边不许长
            if bl >= r:
                R = min(R, bl - GROW_PAD)
            elif br > r:
                R = r
        if bl < r and br > l:                     # 横向和原框有交叠 ⇒ 管上下
            if bb <= t:
                T = max(T, bb + GROW_PAD)
            elif bt < t:
                T = t
            if bt >= b:
                B = min(B, bt - GROW_PAD)
            elif bb > b:
                B = b
    # 长出来的框永远含住原框（挡路件夹得太紧时不至于反而缩掉）
    return (min(L, l), min(T, t), max(R, r), max(B, b))


def probe_product_box(build_dir, html_name, size, port, chrome_path, img_size, margin, grow):
    """起一次 Chrome，跑探针量出**主产品槽**的位置，映射到成品像素。
    🔴 探针**模板**复用 check_layout（`build_probe()`，避免两份 JS 分叉），但**选择器用本文件的
       `SPEC_SELECTORS`（窄）**，⛔ 不是 check_layout.PRODUCT_SELECTORS（宽）—— 见 SPEC_SELECTORS
       上面那段 I-81 的病史。
    ⚠️ 本框量的是【底图 DOM】，而 `--scene` 每次都在**移动并放大产品**（实测 d1 左移 110px /
       放大 16%）⇒ 这个框只是起点，不是真值。框没套准 ⇒ 产品区读不到 token ⇒ 按 I-83 退 2
       （未校验），⛔ 不会静默 PASS。真要准，用 `--box`（product.json 的 `swap.spec_box` 透传）。"""
    from check_layout import PRODUCT_SELECTORS, _contain_rect, build_probe
    from render import find_chrome, free_port, http_ok

    # 邻居槽 = check_layout 那张宽表里**不属于主产品**的部分（次包装 img.second / 场景件 img.scene /
    # 三品并排 img.p …）。它们不是产品区，但产品区**不许长过去**（见下面 _grow_box）。
    others = [s for s in PRODUCT_SELECTORS if s not in SPEC_SELECTORS]
    PROBE = build_probe(SPEC_SELECTORS, others)

    build = Path(build_dir).resolve()
    src_html = build / html_name
    if not src_html.exists():
        raise NotRun(f"找不到 {src_html}")
    try:
        cw, ch = (int(x) for x in str(size).lower().split("x"))
    except Exception:  # noqa: BLE001
        raise NotRun(f"--size 格式应为 750x432，收到 {size!r}")

    chrome = chrome_path or find_chrome()
    inj_html = src_html.read_text(encoding="utf-8")
    inj = inj_html.replace("</body>", PROBE + "</body>") if "</body>" in inj_html else inj_html + PROBE
    probe_html = build / f"__speccheck__{html_name}"
    probe_html.write_text(inj, encoding="utf-8")

    free_port(port)
    srv = subprocess.Popen([sys.executable, "-m", "http.server", str(port)], cwd=build,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        base = f"http://127.0.0.1:{port}"
        for _ in range(40):
            if http_ok(f"{base}/{probe_html.name}"):
                break
            time.sleep(0.25)
        else:
            raise NotRun(f"本地服务器起不来或 {probe_html.name} 404")
        res = subprocess.run(
            [chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars",
             "--force-device-scale-factor=1", f"--window-size={cw},{ch}",
             "--virtual-time-budget=3000", "--dump-dom", f"{base}/{probe_html.name}"],
            capture_output=True, timeout=120)
        dom = res.stdout.decode("utf-8", "replace")
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=10)
        except Exception:  # noqa: BLE001
            srv.kill()
        probe_html.unlink(missing_ok=True)

    m = re.search(r'data-layoutcheck="([A-Za-z0-9+/=]+)"', dom)
    if not m:
        raise NotRun("DOM 探针没回传数据（dump-dom 里没有 data-layoutcheck）——多半 JS 没跑起来，"
                     "换新版 Chrome 或用 --chrome 指定。")
    data = json.loads(base64.b64decode(m.group(1)).decode("utf-8"))
    prods = data.get("prods") or []
    if not prods:
        raise NotRun(f"DOM 探针没找到【主产品槽】（试过 {' '.join(SPEC_SELECTORS)}）。"
                     f"该模块若确有主产品图 = 选择器没覆盖到，请把它的 class 补进 "
                     f"check_product_spec.SPEC_SELECTORS（⛔ 别补进 check_layout 那张宽表就以为好了，"
                     f"两张表是分开的）；⛔ 这不是通过，本脚本按「没跑成」退出。")

    # object-fit:contain 下图像真正渲染出的矩形（和 check_layout 判遮挡时用的是同一个函数）
    rects = [_contain_rect((p["l"], p["tp"], p["w"], p["h"]), p.get("nw") or 0, p.get("nh") or 0)
             for p in prods]
    # 🔴 探针偶发会量到 0 宽/0 高（Chrome 那一跑图片还没加载完，元素被撑成 0）——
    #    实测 2026-08-17 m1 十跑撞上过一次。不挡住的话会算出 w=0 的框，再一路走到
    #    「裁出来是空的」，报错信息完全指错方向。这里当场按「没跑成」退，⛔ 不静默出结果。
    rects = [r for r in rects if r[2] >= 1 and r[3] >= 1]
    if not rects:
        raise NotRun("DOM 探针量到的产品槽是 0 宽/0 高（多半是那一跑图片没加载完）——重跑一次；"
                     "老复现就把 --virtual-time-budget 调大，或直接给 --box。")
    l = min(r[0] for r in rects); t = min(r[1] for r in rects)
    r_ = max(r[0] + r[2] for r in rects); b = max(r[1] + r[3] for r in rects)

    iw, ih = img_size
    sx, sy = iw / cw, ih / ch      # 🔴 x/y 分开算：--scene 出的图可能被各向异性拉伸（见 I-72）
    if abs(sx - sy) / max(sx, sy) > 0.02:
        print(f"⚠️ 成品图比例与模块 CSS 尺寸不一致（sx={sx:.3f} sy={sy:.3f}）——"
              f"图被拉伸过（I-72 那类），产品区映射只能算近似，判 FAIL 前请放大目检。")
    mw, mh = (r_ - l) * margin, (b - t) * margin
    base = (l - mw, t - mh, r_ + mw, b + mh)          # CSS px，四角式 (l,t,r,b)

    # 🔴 I-81 ⒉：DOM 框只是**起点**，成品上产品已经被 `--scene` 挪过位、放大过
    #    （实测 d1 左移 110px / 放大 16%）。所以把框往【空白处】长一圈，长到贴上邻居为止。
    blockers = [(o["l"], o["tp"], o["l"] + o["w"], o["tp"] + o["h"])
                for o in (data.get("others") or []) if o["w"] >= 1 and o["h"] >= 1]
    blockers += [(t_["l"], t_["tp"], t_["l"] + t_["w"], t_["tp"] + t_["h"])
                 for t_ in (data.get("texts") or [])]
    grown = _grow_box(base, blockers, (0, 0, cw, ch), grow)

    def to_px(bx):
        x0, y0 = max(0, bx[0] * sx), max(0, bx[1] * sy)
        x1, y1 = min(iw, bx[2] * sx), min(ih, bx[3] * sy)
        return tuple(int(round(v)) for v in (x0, y0, x1 - x0, y1 - y0))

    # 🔴 返回【两个】候选框，两个都读、token 取并集（见 run() 里那段注释）。
    tight, loose = to_px(base), to_px(grown)
    return [("紧框", tight)] if loose == tight else [("紧框", tight), ("松框", loose)]


# ── 主流程 ────────────────────────────────────────────────────────────────
def run(args):
    from PIL import Image
    fin_path, src_path = Path(args.finished), Path(args.src)
    for p in (fin_path, src_path):
        if not p.exists():
            raise NotRun(f"找不到文件：{p}")
    try:
        img_size = Image.open(fin_path).size
    except Exception as e:  # noqa: BLE001
        raise NotRun(f"读不了成品图 {fin_path}：{type(e).__name__} {e}")

    scales = [int(s) for s in str(args.scales).split(",") if s.strip()]
    if not scales or min(scales) < 3:
        raise NotRun(f"--scales 至少要含 3（1x/2x 实测读不到产品小字），收到 {args.scales!r}")

    # ① 定产品区。🔴 可能不止一个候选：DOM 框量的是【底图】，而 --scene 会挪动/放大产品
    #    ⇒ 「紧框」（贴 DOM）和「松框」（往空白处长）各读一遍，token 取**并集**。
    #    为什么取并集：两个框谁对不知道，但**多读到一个源图上的数字 = 多一份"没被改"的证据**，
    #    而判废只在「源图那个数字哪个框都读不到、且同单位读出别的数字」时发生 ⇒ 并集只会
    #    让判废更难、不会更容易，方向和本脚本"宁可漏一点绝不做噪声机器"一致。
    #    实测（2026-08-17）：m1 只有紧框读得到 360G（松框把条包/画布边一起吞进去，OCR 反而丢字）；
    #    I-74 真阳性只有松框读得到被改的 300G（DOM 框整个偏右 67px）—— **两个都要，少一个就翻车**。
    if args.box:
        try:
            b_ = tuple(int(float(v)) for v in args.box.split(","))
            assert len(b_) == 4
        except Exception:  # noqa: BLE001
            raise NotRun(f"--box 格式应为 x,y,w,h，收到 {args.box!r}")
        boxes = [("显式框", b_)]
        how = "显式 --box"
    elif args.build_dir and args.html:
        boxes = probe_product_box(args.build_dir, args.html, args.size, args.port,
                                  args.chrome, img_size, args.margin, args.grow)
        how = (f"DOM 探针 {args.build_dir}/{args.html} @{args.size}，外扩 {args.margin:.0%}"
               f"；松框再往空白处长 ≤{args.grow:.0%}（挡路件=我方文字墨迹与邻居产品槽）")
    else:
        raise NotRun("定不了产品区：既没给 --box，也没给 --build-dir/--html。"
                     "⛔ 本脚本不会拍脑袋用一个默认比例 —— 请显式给一个。")

    print("=" * 64)
    print(f"【产品规格检查】成品 {fin_path.name} {img_size[0]}×{img_size[1]}")
    print(f"  源产品图 : {src_path.name}")
    print(f"  产品区定法 : {how}")
    for nm, bx in boxes:
        print(f"    · {nm} x={bx[0]} y={bx[1]} w={bx[2]} h={bx[3]}")
    print(f"  OCR 尺度 : {'x / '.join(str(s) for s in scales)}x（3x 是硬底线；多尺度=交叉验证防假报）")

    # ② 逐尺度 OCR
    with tempfile.TemporaryDirectory() as td:
        src_tok_per_scale, fin_tok_per_scale = {}, {}
        for sc in scales:
            src_lines = ocr_lines(src_path, None, sc, td, args.min_conf)
            src_tok_per_scale[sc] = extract_tokens(src_lines)
            print(f"\n  ── {sc}x ──")
            print(f"     源图规格 token : {sorted(src_tok_per_scale[sc]) or '（无）'}")
            fin_tok_per_scale[sc] = set()
            for i, (nm, bx) in enumerate(boxes):
                dump = args.dump_crop if (args.dump_crop and sc == scales[0] and i == 0) else None
                fin_lines = ocr_lines(fin_path, bx, sc, td, args.min_conf, dump=dump)
                toks = extract_tokens(fin_lines)
                fin_tok_per_scale[sc] |= toks
                print(f"     产品区{nm} token : {sorted(toks) or '（无）'}")
                if args.verbose:
                    print(f"     [{nm} OCR] {fin_lines}")
            if len(boxes) > 1:
                print(f"     产品区并集 token : {sorted(fin_tok_per_scale[sc]) or '（无）'}")
            if args.verbose:
                print(f"     [源图 OCR] {src_lines}")

    # 源图 token 取【各尺度交集】：只认多个尺度都稳定读到的规格，源图侧的糊字噪声先滤掉
    src_tokens = set.intersection(*src_tok_per_scale.values())
    if not src_tokens:
        print("\n⚠️ 源产品图上**没读到任何规格 token**（数字+单位）—— 没有可比对的基准。")
        print("   这不是通过：可能源图本来就没印规格，也可能 OCR 读不动。请人工放大核对。")
        return 2

    # ③ 判据①：每个尺度各判一次，🔴 只有【所有尺度都判「被改」且新数字对得上】才判废
    per_scale = {sc: judge_changed(src_tokens, fin_tok_per_scale[sc]) for sc in scales}
    changed_units = {sc: {c[0] for c in per_scale[sc][0]} for sc in scales}
    changed_got = {sc: {c[0]: set(c[2]) for c in per_scale[sc][0]} for sc in scales}
    missing_toks = {sc: set(per_scale[sc][1]) for sc in scales}
    # 🔴 判废要过两道交叉验证：①同一单位在**所有尺度**都被判「被改」；
    #    ②各尺度**读出来的新数字还得对得上**（至少有一个共同值）。
    #    ⛔ 别只留 ①：2026-08-17 d2 真图实测，3x 把糊掉的净含量读成 `220G`、4x 读成 `226G`
    #    —— 放大看那行其实是 `3?0G`（没被改），只是糊到认不出。两个尺度读出**不同**的错数字
    #    正是"OCR 在瞎猜"的指纹；只按单位对齐就会把它判成废图（假红）。
    fail_units = {u for u in set.intersection(*(changed_units[sc] for sc in scales))
                  if set.intersection(*(changed_got[sc][u] for sc in scales))}

    print("\n" + "=" * 64)
    print("【判据①】源产品图的规格数字，在成品产品区里有没有被改")
    unverified = []     # 🔴 I-83：既没核实、也没判废的 token —— 这些一律进退出码 2
    for n, u in sorted(src_tokens):
        verdicts, statuses = [], []
        for sc in scales:
            ch = {c[0]: c for c in per_scale[sc][0]}
            if u in ch:
                verdicts.append(f"{sc}x→被改成 {'/'.join(ch[u][2])}{u}")
                statuses.append("changed")
            elif (n, u) in missing_toks[sc]:
                verdicts.append(f"{sc}x→没读到")
                statuses.append("missing")
            else:
                verdicts.append(f"{sc}x→原样")
                statuses.append("ok")
        # 🔴 「核实通过」= **至少一个尺度把源图那个数字原样读到了**，且**没有任何尺度判它被改**。
        #    某个尺度漏读只是"没证据"（噪声方向），不是"矛盾"；另一个尺度读到 = 正面证据，够了。
        #    （⛔ 别改成"每个尺度都要读到"：m1 实测 3x 漏读 / 4x 读到 360G，那样会把一张
        #      真核过的图打成"未校验"，等于把噪声当不确定，属于另一种假报。）
        if u in fail_units:
            mark = "🔴"
        elif all(st == "changed" for st in statuses):
            mark = "🟠"
            unverified.append((n, u, "各尺度都说被改，但**读出来的新数字互相对不上**"
                                    "（OCR 在瞎猜的指纹，不足以判废）"))
        elif "changed" not in statuses and "ok" in statuses:
            mark = "✅"
        else:
            mark = "🟠"
            why = "产品区完全读不到（框没套准 / OCR 读不动）" if "changed" not in statuses \
                else "各尺度判定互相打架（有的尺度读成被改、有的读不到）"
            unverified.append((n, u, why))
        print(f"  {mark} {n}{u}  [{'  '.join(verdicts)}]")

    fail = bool(fail_units)
    # 🔴 I-83（2026-08-17 六图实测逼出来的）：旧版把三档含义压成一档 PASS ——
    #    「产品区一个 token 都没读到」只 ⚠️ 告警仍 PASS（d1）、「各尺度不一致」按设计放过仍 PASS
    #    （d2/d3）⇒ 六张图里本闸门**一次都没真正核到净含量**，而它就是为这件事生的。
    #    现在这两种一律归退出码 2「未校验」：⛔ 放过等于把不确定写成确定。
    if unverified and not fail:
        print(f"\n🟠 有 {len(unverified)} 个规格 token **没能核实**（既不能说被改，也不能说没被改）：")
        for n, u, why in unverified:
            print(f"     · {n}{u} —— {why}")

    extra_all = sorted(set.intersection(*[set(per_scale[sc][2]) for sc in scales])) if scales else []
    if extra_all:
        print(f"\nℹ️ 产品区多出来的 token（源图没有，可能是 OCR 噪声，也可能是 AI 加的，只告警）：")
        for n, u in extra_all:
            print(f"     · {n}{u}")

    # ④ 判据②：只告警，⛔ 不进退出码
    print("\n" + "=" * 64)
    print("【判据②】产品区内部单位自洽（公制 ↔ 英制质量换算）—— 🔴 只告警，不判废")
    bad = []
    for sc in scales:
        bad += [(sc, *b) for b in check_unit_coherence(fin_tok_per_scale[sc])]
    if bad:
        for sc, (mn, mu), (inn, iu), dev in bad:
            print(f"  ⚠️ {sc}x：{mn}{mu} 与 {inn}{iu} 换算差 {dev:.0%}（>{MASS_TOL:.0%}）"
                  f" —— 包装自相矛盾，必有一个是假的，人工放大确认。")
    else:
        print("  · 没同时读到公制与英制质量值 ⇒ 这条判不了（OCR 常漏读其中一个，属正常）。")

    print("\n" + "=" * 64)
    if fail:
        print("❌ 判定：FAIL —— 产品包装上原厂印的【规格数字被改了】，这张不能用。")
        for sc in scales:
            for u, n, got in per_scale[sc][0]:
                print(f"   · {sc}x：源图 {n}{u} → 产品区读到 {'/'.join(got)}{u}")
        print("   🔴 净含量/粒数是买家下单要看的规格，改了= 产品信息造假。重跑或改走合成法。")
        return 1
    if unverified:
        n_ok = len(src_tokens) - len(unverified)
        print(f"🟠 判定：未校验 —— 源图 {len(src_tokens)} 个规格 token 里，"
              f"有 {len(unverified)} 个**没能核实**（核实到 {n_ok} 个）。这既不是通过也不是失败。")
        for n, u, why in unverified:
            print(f"   · {n}{u}：{why}")
        print("   🔴 ⛔ 别当 ✅ 划过去。要么给准框（--box x,y,w,h / product.json 的 swap.spec_box），")
        print("      要么把源产品图与成品并排放大到 300%+ 人工逐个核净含量/粒数/条数。")
        print("   （为什么会读不到：产品区框来自【底图 DOM】，而 --scene 每次都会移动并放大产品，见 I-81。）")
        return 2
    print("✅ 判定：PASS —— 源图的规格数字，在成品产品区里【逐个核实过】且没被改。")
    print("🔴 提醒：本脚本只是筛子不是判官 —— 只拦「数字变了」这一类，")
    print("   包装上的成分名/认证标/口味等**字母类**改动它一概查不出，仍须放大目检。")
    return 0


# ── selftest ──────────────────────────────────────────────────────────────
def selftest():
    """造正反例证明判据逻辑对（不依赖真图、不调 OCR）。
    ⛔ 只测「该报的报了」不够 —— 一半用例专门测「不该报的没报」。"""
    fails = []

    def ck(name, got, want):
        ok = got == want
        print(f"  {'✅' if ok else '🔴'} {name}\n       得到 {got}\n       期望 {want}" if not ok
              else f"  ✅ {name}")
        if not ok:
            fails.append(name)

    print("【A】tokenizer（数字+单位；⛔ 不靠字母）")
    ck("A1 真实 OCR 串 NETWT:300G（冒号、无空格）",
       extract_tokens(["NETWT:300G"]), {("300", "G")})
    ck("A2 源图串 NET WT.360G（点号）",
       extract_tokens(["NET WT.360G"]), {("360", "G")})
    ck("A3 OCR 把 NET 读成 KET 也照样命中（判据不靠字母）",
       extract_tokens(["KET WT.360G"]), {("360", "G")})
    ck("A4 跨行 30 / STICKS 拼得起来",
       extract_tokens(["30", "STICKS"]), {("30", "STICK")})
    ck("A5 12.70 OZ + 全角括号",
       extract_tokens(["（12.70 OZ）"]), {("12.7", "OZ")})
    ck("A6 KG 不被 G 截断", extract_tokens(["1.5KG"]), {("1.5", "KG")})
    ck("A7 LBS 归一到 LB", extract_tokens(["2 LBS"]), {("2", "LB")})
    ck("A8 360GRAMS 不被截成 360G（整词命中 GRAMS→G）",
       extract_tokens(["360GRAMS"]), {("360", "G")})
    ck("A9 千分位 1,000 G 不被切成 000 G",
       extract_tokens(["1,000 G"]), {("1000", "G")})
    ck("A10 0G 被滤掉（OCR 读崩的产物，不是真规格）",
       extract_tokens(["NEIWL0G"]), set())
    ck("A11 纯文字不产 token", extract_tokens(["VOLT-HYDRATE", "AQUA FRESH"]), set())
    ck("A12 数字无单位不产 token", extract_tokens(["12 007", "町TM30"]), set())
    ck("A13 12.70 与 12.7 归一成同一个数",
       extract_tokens(["12.70 OZ"]), extract_tokens(["12.7 OZ"]))
    ck("A14 16 POPS x 62 ml (2.1 FL OZ) → 62ML + 2.1FLOZ（FLOZ 不落到质量 OZ）",
       extract_tokens(["16 POPS x 62 ml (2.1 FL OZ)"]), {("62", "ML"), ("2.1", "FLOZ")})
    ck("A15 FLOZ 不参与质量换算（⛔ 否则 2.1FLOZ vs 62ML 之类必假报）",
       check_unit_coherence({("2.1", "FLOZ"), ("360", "G")}), [])

    print("\n【B】判据①：该报的报了")
    S = {("360", "G"), ("30", "STICK")}
    ch, mi, ex = judge_changed(S, {("300", "G"), ("30", "STICK")})
    ck("B1 360G→300G 判「被改」", (ch, mi), ([("G", "360", ["300"])], []))
    ch, mi, ex = judge_changed({("60", "CAPSULE")}, {("90", "CAPSULE")})
    ck("B2 60 粒→90 粒 判「被改」", ch, [("CAPSULE", "60", ["90"])])

    print("\n【B'】判据①：🔴 不该报的没报")
    ch, mi, ex = judge_changed(S, {("360", "G"), ("30", "STICK")})
    ck("B3 完全一致 → 不报", (ch, mi, ex), ([], [], []))
    ch, mi, ex = judge_changed(S, {("30", "STICK")})
    ck("B4 该单位一个都没读到（OCR 漏读）→ 只告警，⛔ 不判废",
       (ch, mi), ([], [("360", "G")]))
    ch, mi, ex = judge_changed(S, set())
    ck("B5 产品区一个 token 都没读到 → 只告警", ch, [])
    ch, mi, ex = judge_changed(S, {("360", "G"), ("30", "STICK"), ("12.7", "OZ")})
    ck("B6 成品多出 token → 只算 extra 告警", (ch, ex), ([], [("12.7", "OZ")]))
    # 走真实路径（extract_tokens 会把 12.70 归一成 12.7），⛔ 别手搓未归一的 token 集
    ch, mi, ex = judge_changed(extract_tokens(["NET WT (12.70 OZ)"]),
                               extract_tokens(["NETWT.12.7OZ"]))
    ck("B7 12.70 vs 12.7 不算被改", ch, [])
    ch, mi, ex = judge_changed(S, {("360", "G"), ("360", "ML")})
    ck("B8 同数字换了单位（360G→360ML）→ 不判废（数字没变，只当 extra）", ch, [])

    print("\n【C】双尺度交叉验证（实测 d3 未被改的图在紧框 3x 会吐 0G）")
    s3 = judge_changed(S, {("300", "G")})[0]
    s4 = judge_changed(S, {("300", "G")})[0]
    ck("C1 两尺度都判被改 → FAIL", bool(s3 and s4), True)
    s3 = judge_changed(S, {("5", "G")})[0]
    s4 = judge_changed(S, set())[0]
    ck("C2 只有一个尺度判被改 → 不一致 → 放过（只告警）", bool(s3) and bool(s4), False)

    print("\n【C'】🔴 各尺度读出**不同**的错数字 ⇒ 不判废（d2 实测 220G vs 226G）")
    got3 = {c[0]: set(c[2]) for c in judge_changed(S, {("220", "G")})[0]}
    got4 = {c[0]: set(c[2]) for c in judge_changed(S, {("226", "G")})[0]}
    ck("C3 220G vs 226G 两尺度对不上 → 交集为空 → 不判废",
       bool(got3["G"] & got4["G"]), False)
    g3 = {c[0]: set(c[2]) for c in judge_changed(S, {("300", "G")})[0]}
    g4 = {c[0]: set(c[2]) for c in judge_changed(S, {("300", "G")})[0]}
    ck("C4 300G vs 300G 两尺度对得上 → 判废（I-74 真阳性）",
       bool(g3["G"] & g4["G"]), True)

    print("\n【D】判据②：单位自洽（只告警）")
    bad = check_unit_coherence({("300", "G"), ("12.7", "OZ")})
    ck("D1 300G vs 12.70OZ 偏差 >5% → 点名", len(bad) == 1 and bad[0][2] > 0.05, True)
    ck("D1' 偏差就是 ~20%", f"{bad[0][2]:.0%}", "20%")
    ck("D2 360G vs 12.70OZ（真值）→ 不点名",
       check_unit_coherence({("360", "G"), ("12.7", "OZ")}), [])
    ck("D3 只有公制 → 判不了，不点名", check_unit_coherence({("360", "G")}), [])
    ck("D4 1LB vs 454G → 不点名（换算对得上）",
       check_unit_coherence({("454", "G"), ("1", "LB")}), [])

    print("\n" + "=" * 64)
    if fails:
        print(f"🔴 selftest FAIL：{len(fails)} 条不通过 —— {fails}")
        return 1
    print("✅ selftest 全部通过（正例会报、反例不报）")
    return 0


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("finished", nargs="?", help="成品图（--scene / 合成后的最终 PNG）")
    ap.add_argument("--src", help="源产品图（原厂包装图，规格的标准答案）")
    ap.add_argument("--box", help="产品区 x,y,w,h（成品像素坐标）")
    ap.add_argument("--build-dir", help="构建目录（用 check_layout DOM 探针定产品区时给）")
    ap.add_argument("--html", help="模块 HTML 名，如 d1.html")
    ap.add_argument("--size", default="750x432", help="该模块的 CSS 尺寸，如 750x432")
    ap.add_argument("--margin", type=float, default=0.06, help="探针框外扩比例（默认 6%%）")
    ap.add_argument("--grow", type=float, default=0.30,
                    help="探针框再往【空白处】长的上限比例（默认 30%%；挡路件=我方文字墨迹与"
                         "邻居产品槽。--scene 会挪动/放大产品，不长就读不到，见 I-81）")
    ap.add_argument("--port", type=int, default=8749, help="探针本地服务器端口")
    ap.add_argument("--chrome", default=None, help="Chrome 路径")
    ap.add_argument("--scales", default=",".join(str(s) for s in DEFAULT_SCALES),
                    help="OCR 放大倍数，逗号分隔（🔴 至少含 3；多个=交叉验证防假报）")
    ap.add_argument("--min-conf", type=float, default=0.0,
                    help="OCR 置信度下限（默认 0：净含量小字实测只有 0.30，一卡就全没了）")
    ap.add_argument("--dump-crop", default=None, help="把裁出的产品区存一份，方便人工核对")
    ap.add_argument("--verbose", action="store_true", help="打印 OCR 原始行")
    ap.add_argument("--selftest", action="store_true", help="只跑判据逻辑自测，不碰真图")
    a = ap.parse_args()

    if a.selftest:
        sys.exit(selftest())
    if not a.finished or not a.src:
        ap.print_usage()
        print("\n🔴 缺参数：需要 成品图 与 --src 源产品图。（或用 --selftest 只测判据逻辑）")
        sys.exit(2)
    try:
        sys.exit(run(a))
    except NotRun as e:
        print("=" * 64)
        print(f"⚠️ 本脚本【没跑成】—— 这不是通过，也不是失败。原因：{e}")
        print("🔴 产品规格这道关不能省，改人工/agent 核对：")
        print("   把源产品图与成品并排放大到 300%+，逐个核对包装上印的")
        print("   净含量(NET WT / g / oz)、粒数(count/capsules)、条数(sticks)、服用量 —— 有一个数字不一样就废掉重跑。")
        sys.exit(2)


if __name__ == "__main__":
    main()
