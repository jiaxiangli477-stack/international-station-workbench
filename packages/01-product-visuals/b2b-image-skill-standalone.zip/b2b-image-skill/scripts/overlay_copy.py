#!/usr/bin/env python3
"""场景替换法的【文案锁定】收尾：把 HTML 模板的纯文案层叠加到「换好产品的成品图」上。

为什么需要（2026-07-30 能量胶实测）：
  `gen_image.py --scene`（gpt-image-2 edits）是**重绘整张图**，文案也过一遍 AI →
  卖点条/较小文案会被改（实测 pill "20g Sachet"→"Saciet"、大标题的字母也可能错位）。
  本脚本渲染一版【隐藏所有产品图 + 背景透明】的**纯文案层**，alpha 叠到成品上 →
  **我方文案 100% 来自 HTML、像素级精确**（大标题 N 完整、pill 正确、无断字、无接缝）。
  🔴 ⛔ 但【盖不住】--scene 重绘出的那份错位文案（overlay 是盖不是擦）= 双影，由 check_scene_text.py 检出。
     🔴 双影的第一处置是**重掷那一张 --scene**（随机走样，换一版通常就干净了），不是改 mode:composite
     —— 完整三级阶梯见 references/scene-swap.md §我方文案双影的处置阶梯（composite 是第 3 级兜底）。

为什么不用蒙版/区域合成（都试过，不可靠）：
  · 竖切合成：切到跨产品区的字就**断字**（实测切断 COMBUSTION 的 N）。
  · 差异蒙版：产品周围留**占位袋残影**，且当文案与产品像素重叠时根本分不开。
  → **叠加（把文字盖在最上层）比挖补（从别处切一块填进来）稳**：文字永远落在 HTML 定的精确位置。

⛔ 唯一救不了的：**产品自己印的小字**（净含量/营养表，在产品区、归 AI 重绘，实测钾值 22→23）。
   → 小字漂了重跑 --scene（换角度/多试）；确需像素级精确由用户明确要求才走抠图。

用法:
    # 先 build 出底图(文案+占位产品)、gen_image --scene 换真产品得到 <swapped.png>，再:
    python overlay_copy.py <build_dir> <html_name> <swapped.png> <out.png> --size 1000x1000
    python overlay_copy.py build d1.html out/d1_swapped.png out/d1_final.png --size 750x380

⛔ 🔴 V2-6b：**这样手工分步跑 = 没有双影检测**（`render_v2.py` 才会在本步之后接 ③½ check_scene_text）。
   本脚本收尾会把那条命令拼好打印出来，**跑完它才算出完图**；不想操心就走一键：
       python render_v2.py <product.json> <build_dir> -o <out_dir> --modules <key>
"""
import argparse, subprocess, sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （必须 import：修 Windows 管道输出下 emoji 崩溃）
from render import find_chrome, free_port, http_ok   # 复用 render.py 的跨平台工具，别重写

try:
    from PIL import Image
except ImportError:
    sys.exit("需要 Pillow：pip install pillow")


# ══════════════════════════════════════════════════════════════════════════════
# 🔴 透明化选择器清单 —— **全库唯一一份**（2026-08-05 P1-6 从字符串拼接里提出来）
#    加一个新容器 = 在这个 tuple 里加一行，⛔ 别再在别处拼第二串。
#    每条选择器**各自成一条 CSS 规则**（不合并成逗号组）：CSS 里一组选择器只要有一条
#    不被浏览器支持，**整组规则会被整体丢弃** —— `.pcard:has(> img)` 这种就有这个风险，
#    拆开写能保证一条失效不牵连其它条。
#
# 🔴🔴 选择器必须【收窄到画布/产品容器】，⛔ 禁用裸 class 名 —— **同名 class 在不同模板里语义可能相反**：
#    · `.c`：m1/m2/m3/m5/m6 是**画布**（该透），但 d5-certs 里的 `.c` 是**五张白色证书卡**、
#      d8-record 里的 `.c card-w` 是白卡（都不该透）。全库 20 个模板核过：
#      **当画布用的 `.c` 无一例外都同时带 `bg-diagonal`** → 只写 `.c.bg-diagonal`，⛔ 别加回裸 `.c`。
#    · `.pcard`：d2-benefits 里的 `.pcard` 是装**产品图**的浅蓝卡（#EAF2FD，直接子元素是 <img>，该透——
#      不透的话 d2 产品位会被这张浅蓝卡盖住，实测合成图该处 = #EAF2FD 而非成品）；
#      而 d3-formula 里的 `.pcard` 是**三张纯文字问答白卡**（#fff，子元素只有 .pq/.pa，产品另在 .prodwrap）。
#      裸 `.pcard` 实测把 d3 三张白卡整块挖空（文案层多 45 万 alpha=0 像素，白卡底/圆角/投影
#      全退化成 --scene 的 AI 重绘版）→ 用 `.pcard:has(> img)` 只命中「包着产品图的那个 pcard」。
#    · 画布容器三种写法都要清，少一种整层就是不透明的、alpha_composite 会把成品整张盖掉：
#      主图 = `.c bg-diagonal`（m1/m2/m3/m5/m6），但 m4-cert-wall 用的是 `.canvas bg-diagonal`；
#      详情页 = `.m`（`_detail.css` 里 `.m` 的规则），背景在 .m-blue/.m-white/.m-lt 上；个别模块还在自己
#      <style> 里直接覆写 `.m{background:...}`（如 d5-multiformat）→ 只清 `.c` 会让 d1/d3
#      只剩版式没产品、d2 整块退回底图（已实测的 bug）。
#
# 🔴 现状：全库当前只有 d2 的产品被【不透明容器】包着，所以这里只处理它。但**同类容器还有一堆**
#    （d-factory-gallery `.card`#fff、d-reviews `.simg .sh`#fff、d5-multiformat `.ph`#dbe6f5、
#     m3 `.frame`#eef4ff、m4 `.card`#fff、d4-packaging `.cell`#fff），只是这些模块今天没有 swap 段
#    所以不走 overlay、暴露不出来。⛔ **新模板接 swap 前，必须逐个核该模板里容器的背景与语义**
#    （`.pcard`/`.c` 都已经踩过坑），别照抄这串选择器就当万能。
_TRANSPARENT_SELECTORS = (
    "html",
    "body",
    ".canvas",
    ".m",
    ".m-blue",
    ".m-white",
    ".m-lt",
    ".pcard:has(> img)",
    ".c.bg-diagonal",
    ".canvas.bg-diagonal",
)

# 斜切装饰伪元素：要 `display:none` 而不是 `background:transparent`（它们本身就是纯背景块）。
_HIDE_PSEUDO_SELECTORS = (".bg-diagonal::before", ".bg-diagonal::after")


def _override_css(hide: str) -> str:
    """造纯文案层的注入 CSS：清背景 + 去斜切伪元素 + 隐藏产品图。

    `!important` 保证压过模板内联 <style> 里的同名规则。
    ⛔ 选择器清单只从 `_TRANSPARENT_SELECTORS` / `_HIDE_PSEUDO_SELECTORS` 来，别在这里手写。
    """
    rules = [f"{sel}{{background:transparent!important}}" for sel in _TRANSPARENT_SELECTORS]
    rules += [f"{sel}{{display:none!important}}" for sel in _HIDE_PSEUDO_SELECTORS]
    rules.append(f"{hide}{{display:none!important}}")
    return "<style>" + "".join(rules) + "</style>"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("build_dir")
    ap.add_argument("html_name")
    ap.add_argument("swapped", help="gen_image --scene 换好真产品的成品图")
    ap.add_argument("out")
    ap.add_argument("--size", default="1000x1000",
                    help="底图【当初渲染时】的尺寸(主图1000x1000/详情页如750x380)。"
                         "文案层按这个尺寸渲、再缩放对齐成品——尺寸不对文案会错位。")
    ap.add_argument("--hide", default="img",
                    help="要隐藏的元素选择器(默认 img=隐藏所有产品/成分图；"
                         "模板若有【属于文案的图标 img】要保留，改传具体产品类如 '.main,.second,.scene')")
    # 详情页文案层要 @2x 才和 @2x 成品对齐、字才锐（主图 1x）。渲染窗口 = size×scale。
    ap.add_argument("--scale", type=int, default=1, choices=[1, 2])
    ap.add_argument("--port", type=int, default=8792)
    ap.add_argument("--chrome", default=None)
    a = ap.parse_args()

    build = Path(a.build_dir).resolve()
    src = build / a.html_name
    if not src.exists():
        sys.exit(f"找不到 {src}")
    swapped_p = Path(a.swapped).resolve()
    if not swapped_p.exists():
        sys.exit(f"找不到成品图 {swapped_p}")
    w, h = (int(x) for x in a.size.lower().split("x"))
    chrome = a.chrome or find_chrome()

    # 造纯文案层 HTML：隐藏产品图 + 背景透明（连 bg-diagonal 的斜切伪元素一起去掉）
    # ⛔ 选择器清单在文件顶部的 `_TRANSPARENT_SELECTORS`（全库唯一一份），要加容器改那里。
    override = _override_css(a.hide)
    html = src.read_text(encoding="utf-8")
    html = html.replace("</head>", override + "</head>") if "</head>" in html else override + html
    tl_html = build / (src.stem + "_textlayer.html")
    tl_html.write_text(html, encoding="utf-8")
    tl_png = build / (src.stem + "_textlayer.png")

    free_port(a.port)
    srv = subprocess.Popen(
        [sys.executable, "-m", "http.server", str(a.port)],
        cwd=build, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    try:
        base = f"http://127.0.0.1:{a.port}"
        for _ in range(40):
            if http_ok(f"{base}/{tl_html.name}"):
                break
            time.sleep(0.25)
        else:
            sys.exit("服务器起不来或文案层 HTML 404")
        # 🔴 --default-background-color=00000000 = 透明底；本脚本用 --virtual-time-budget 等字体加载完
        #    ⚠️ render.py 的 Chrome 命令目前【没有】这个参数，别当成两边一致。
        subprocess.run([
            chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars",
            "--default-background-color=00000000", "--virtual-time-budget=15000",
            "--run-all-compositor-stages-before-draw",
            f"--force-device-scale-factor={a.scale}",
            f"--window-size={w},{h}", f"--screenshot={tl_png}", f"{base}/{tl_html.name}",
        ], capture_output=True, timeout=120)
    finally:
        srv.terminate()
        srv.wait(timeout=10)

    if not tl_png.exists():
        sys.exit("文案层没渲出来（Chrome 没产出 PNG）")
    layer = Image.open(tl_png).convert("RGBA")
    swapped = Image.open(swapped_p).convert("RGBA")
    # 文案层按底图尺寸渲的；缩放到成品尺寸对齐（gpt-image-2 常把成品返成 1024/2880，与底图尺寸不同）
    #
    # 🔴🔴 I-24 补的判据（2026-08-17）：**纯缩放没问题，比例不符才是病**。
    #   `--scene` 只会返回 1:1 / 3:2 / 2:3 三种比例。若这里拿到的 `swapped` 是**模型原始返回**
    #   （而不是已经按 G-2 归一回画布的那张），它的比例与文案层不同 ⇒ 下面这句 `resize` 就把
    #   **文案层各向异性拉伸**到那个比例上 ⇒ 字被拉胖/拉瘦、且与产品位置对不上 = 双影的另一半。
    #   · **自动路径（`render_v2.py`）免疫**：它传的是已归一裁回画布的 `_fit`，比例天然一致。
    #   · **手工分步跑会中**：文档里那条命令传的是 `--scene` 的直接产物。
    #   ⇒ 只在**比例**对不上时出声（≤2% 视为同比例，是取整误差）。⛔ 不改退出码：
    #     这是调试路径，判定权在人；但绝不能让它**静默**发生 —— 静默正是本 skill 反复在治的病。
    if layer.size != swapped.size:
        la, sa = layer.size[0] / layer.size[1], swapped.size[0] / swapped.size[1]
        if abs(la - sa) / sa > 0.02:
            print(f"⚠️🔴 文案层 {layer.size}（比例 {la:.3f}）与成品 {swapped.size}（比例 {sa:.3f}）"
                  f"**比例不符 {abs(la-sa)/sa*100:.1f}%** —— 下面这步会把文案层【各向异性拉伸】，"
                  f"字会变形并与产品对不上（= 双影的几何成因，见 references/scene-swap.md 的双影处置阶梯 ㊁）。")
            print(f"   👉 你多半是把 `--scene` 的**原始返回**直接喂进来了。正确做法：先按 G-2 把它"
                  f"归一并裁回画布尺寸，再叠文案 —— 或者直接跑 `render_v2.py`（它已内建 G-2）。")
        layer = layer.resize(swapped.size)
    out_img = swapped.copy()
    out_img.alpha_composite(layer)                 # 🔴 文案盖在最上层（加法，不是挖补）
    out_p = Path(a.out)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    out_img.convert("RGB").save(out_p)

    hist = layer.split()[3].histogram()
    tot = sum(hist) or 1
    opaque = 100 * (tot - hist[0]) / tot          # 非透明像素占比
    print(f"✅ {out_p.name}  文案层已叠加（文案像素级精确，来自 HTML）  非透明 {opaque:.0f}%")

    # ══════════════════════════════════════════════════════════════════════════
    # 🔴 闸门（2026-08-05 P1-6 加）：文案层【应该】绝大部分透明——它只有文字/徽章/线条。
    #    非透明占比一高 = 某个容器的背景没被清掉 → alpha_composite 会把换好产品的底图盖回去，
    #    而这件事【不报错、不影响退出码、图也能出来】，只是产品是旧的（P0-2 就是这么活了一个月：
    #    脚本从头到尾都在打印「非透明 100%」，铁证一直在日志里，只是没人拦）。
    #
    # ── 实测基线（2026-08-05，work-collagen-pm 一整套，默认 `--hide img`）───────────
    #    详情 12 块：dc 3 / dfac 12 / d1 17 / d2 30 / d6 42 / d7 52 / d3 53 /
    #               d9 64 / d5 67 / df 71 / d4 75 / drev 76
    #    主图 6 张：m1 11 / m2 34 / m5 36 / m4 62 / m3 70 / m6 73
    #    d2 另按生产用的 `--hide '.pcard img'` 复测 = 30%（与默认一致）。
    #
    # 🔴 60% 这条告警线为什么留着（别急着往上调）：**今天真正走 overlay 的只有带 swap 段的
    #    m1/m2/d1/d2/d3**，实测 11/34/17/30/53% —— 全部低于 60，这条线在现行出图路径上
    #    **零误报**。基线里 >60% 的 8 个模块（m4/m3/m6/d9/d5/df/d4/drev）是**文字/白卡密集**
    #    的合法模块，今天都没有 swap 段、不走本脚本；**将来给它们接 swap 时，头一次告警属预期**，
    #    请对照上面的基线值判断（一致=正常，明显更高=真有容器没清），⛔ 别顺手把线调上去。
    # 🔴 90% 是硬失败线。⛔ 别为了让某张图通过就调阈值（同 A3 教训：阈值是用来暴露问题的）。
    if opaque > 90:
        # 🔴 硬失败时【删掉那张无效成品】：它长得跟正常成品一模一样（只是产品是旧的），
        #    留在出图目录里迟早被人当成品捡走交付 —— 这正是本闸门要防的那件事。
        #    排查线索改留在文案层 HTML/PNG 上（它们本来就不删），错误信息里给了路径。
        out_p.unlink(missing_ok=True)
        sys.exit(
            f"❌ 文案层非透明 {opaque:.0f}% —— 这一层几乎是实心的，叠上去等于把产品盖掉，成品无效。\n"
            f"   八成是这张模板里有【新的容器 class】没被透明化。\n"
            f"   ⚠️ 已删掉刚写出的无效成品 {out_p.name}（免得被当好图捡走）；\n"
            f"      排查看文案层：{tl_html}\n"
            f"   修法：打开 {tl_html.name}，找到包住产品/整块内容的最外层容器，\n"
            f"        把它的 class 加进本脚本顶部的 _TRANSPARENT_SELECTORS\n"
            f"        （现有：{' / '.join(_TRANSPARENT_SELECTORS)}）。\n"
            f"   ⛔ 选择器要【收窄到画布/产品容器】，禁用裸 class 名（`.c`/`.pcard` 都踩过坑，\n"
            f"     同名 class 在别的模板里可能是不该透的白卡）。\n"
            f"   ⛔ 别用调低阈值的方式绕过去。")
    if opaque > 60:
        print(f"   ⚠️ 文案层非透明 {opaque:.0f}% 偏高（现行 swap 模块实测 11–53%）——"
              f"对照本脚本里的实测基线：与该模块基线一致=正常（文字/白卡密集），"
              f"明显更高=八成有容器没清 → 放大核产品有没有被局部盖住，有就加容器 class。")
    if opaque < 1:
        print(f"   ⚠️ 文案层非透明 {opaque:.0f}% ——【几乎全透明】，文案可能一个字都没渲上去"
              f"（字体没加载 / --hide 选择器把文字也一起藏了）。Read 成品确认文案在不在。")
    print("   ⛔ 产品自己印的小字仍来自 --scene 的 AI 重绘（净含量/营养表在产品区）——"
          "→ 小字漂了重跑 --scene（换角度/多试）；确需像素级精确由用户明确要求才走抠图")
    print("   👉 现在 Read 成品放大核：①我方文案已锁精确 ②产品印刷小字/规格有没有漂 ③融合有无穿帮。")

    # ══════════════════════════════════════════════════════════════════════════
    # 🔴 V2-6b（2026-08-06）：**手工分步跑到这里，双影检测一次都没跑过。**
    #    `render_v2.py` 那条一键命令里，③ 之后紧接着就是 ③½ check_scene_text；而分步跑
    #    （scene-swap.md 的手工分步小节、本文件顶部的用法示例）到 overlay 就收工了 ⇒ 双影零拦截。
    #    overlay 是【盖】不是【擦】：AI 那份错位的文案仍从旁边透出来，图看着很"完整"。
    #    这里把那条命令直接拼好打出来 —— 本脚本已知 build/key/size/scale/成品路径，用户只需复制粘贴。
    #    ⛔ 别改成"自动帮他跑一遍"：本脚本是纯合成步骤，不该顺手起 Chrome 跑别的闸门
    #      （端口会撞进调用方的段，见 render_v2.py 的 PORT_BASE 注释）。
    _key = src.stem
    _base_guess = build / "v2" / f"{_key}_base.png"
    # 🔴 路径必须带引号：本项目的真实路径里就有空格（"claude code" / "B2B image"），
    #    不引的话打出来的命令**复制粘贴跑不了**（验收时逮到）。双引号在 zsh/bash/cmd.exe 里都成立。
    _q = lambda p: f'"{p}"'  # noqa: E731
    _base_arg = _q(_base_guess) if _base_guess.exists() else "<步骤①渲的底图.png>"
    # 解释器用 sys.executable，⛔ 别写死 "python"：这台 Mac 上只有 `python3`，
    #    打出来的命令会 `command not found`（验收时逮到）。同事的 Windows 同理（py/python3 混装）。
    _cmd = (f"{_q(sys.executable or 'python')} {_q(Path(__file__).parent / 'check_scene_text.py')} {_q(build)} {_key} "
            f"--base {_base_arg} --after {_q(out_p)} --size {a.size}"
            + (f" --scale {a.scale}" if a.scale != 1 else "") + f" --port {a.port}")
    print("\n   ⛔ 【还没查双影】—— 手工分步跑不含双影检测（--scene 会重画我方文案，"
          "overlay 盖不住那份错位残影）。⛔ 没跑这一步不许交付：")
    print(f"      {_cmd}")
    print(f"      退出码：0=未检出 · 1=**检出双影** · 2=没跑成 ⛔ 不算通过。")
    # 🔴 V2-7（Bowen 2026-08-06）：双影的第一处置是【重掷】。`render_v2.py` 会自动重掷
    #    （RENDER_V2_SCENE_RETRIES，默认 2 轮），但**手工分步跑没有这个循环** ——
    #    所以这里必须明说"自己把换产品和锁文案两步再跑一遍"，⛔ 别让人看见退 1 就直接去改
    #    mode:composite（那是第 3 级兜底，依赖 cutout.py 抠图、同事机器上不稳）。阶梯在 scene-swap.md。
    #
    # 🔴 ⛔ 这里【不许写序号】（I-43⒠，2026-08-16）：全库同时跑着**两套都叫"步"的编号** ——
    #    `render_v2.py` 内部是 ①render ②--scene ③overlay ③½查双影 ④查压字（overlay = ③），
    #    而 `scene-swap.md` 手工分步跑小节的正文是 1渲底图 2换产品 3填留白位 4锁文案 5验收（overlay = 4）。
    #    本行原文曾写「第 3 步 overlay_copy」、md 侧写「第 4 步 overlay_copy」，**同一个脚本两个序号**，
    #    读者照哪个都可能跑错一步。⇒ 一律**点名脚本**，别报序号。
    print(f"      🔴 退 1（检出双影）时的第一处置 = **重掷这一张**：双影是 --scene 每次重绘文案的"
          f"随机走样，换一版通常就干净了。")
    print(f"      ⚠️ 分步跑**没有自动重掷** —— 自己把【`gen_image --scene` 换产品】和"
          f"【`overlay_copy`（本脚本）锁文案】原样再跑一遍，然后重跑上面那条检测；掷两三次仍中，"
          f"才是结构病（改版式），composite 是第 3 级兜底。")
    print(f"      👉 完整三级阶梯：references/scene-swap.md §我方文案双影的处置阶梯。")
    if not _base_guess.exists():
        print(f"      （把 <步骤①渲的底图.png> 换成你在步骤① render.py 渲出来的那张底图）")
    print("      👉 或者别分步：`python render_v2.py <product.json> <build> -o <out> --modules "
          f"{_key}` 一条命令把渲底图→换产品→锁文案→查双影（检出自动重掷）→查压字每一环串起来跑完。")


if __name__ == "__main__":
    main()
