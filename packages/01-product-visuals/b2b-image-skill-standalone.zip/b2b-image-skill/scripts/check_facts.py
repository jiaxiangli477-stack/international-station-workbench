#!/usr/bin/env python3
"""m7 营养成分表（Supplement Facts）数据校验器 —— 纯代码、离线、零成本、可复现。

它只管 **数字和成分**：%DV 算得对不对、单位合不合法、剂型物理上做不做得出来、
每一行有没有出处、有没有踩专利原料商标。⛔ 不调任何大模型，不联网，跑一次不花钱。

用法
────
    python3 scripts/check_facts.py <product.json>              # 校验 + 回填 dv（默认写）
    python3 scripts/check_facts.py <product.json> --dry-run    # 只校验，不写文件
    python3 scripts/check_facts.py <product.json> --fix        # 连【手填错的 dv】也一并改成算出来的值
    python3 scripts/check_facts.py <product.json> --dv-table <路径>   # 换一份 DV 表（默认 assets/schemas/dv_table.json）
    python3 scripts/check_facts.py --selftest                  # 内置自测：验 DV 表 + 验本脚本逻辑

退出码（🔴 严格照 m7 契约 §7，⛔ 别自己加码）
──────────────────────────────────────────
    0  通过
    1  数据错误 —— %DV 算错 / 缺 source / 单位非法 / 剂型不可行 / demo 档出现商标
    2  没跑成 —— 文件读不到、json 坏了、DV 表缺失。🔴 绝不当通过
    3  需要人答复 —— 扫到专利/商标成分且未获 Bowen 同意（停机等回复）

    ⚠️ `1` 和 `3` 必须分开：`1` 是"数据本身错了，改数字"，`3` 是"没人拍板，改不了"。
       两者撞码的后果（V2-6 踩过）：人对着一张根本没查过的图瞎改。
    ⚠️ 同时命中 3 和 1 时 **返回 3**：商标没定，配方可能整个换掉，先改数字是白改。
       两类问题都会完整打印出来，不会因为返回 3 就把数据错误藏起来。

三个脚本的分工（⛔ 别互相顶替）
─────────────────────────────
    check_facts.py  （本脚本）纯代码 · 管【数字与成分】· 会拦（1/3）
                    %DV 计算与比对、旧版 DV 识别、单位换算、剂型可行性、source 必填、商标停机
    verify_copy.py  纯代码 · 管【文案词】· 会拦（1）
                    疾病/治疗宣称、FDA 字样、错误认证表述、绝对化词、联系方式
    review_facts.py LLM 顾问 · 管【配方逻辑是否讲得通】· 🔴 只报不拦
                    剂量是否离谱、成分组合是否合理、有没有明显反常识——它给意见，人拍板

数据源
──────
    所有 DV 数值、单位换算系数、进位规则都在 assets/schemas/dv_table.json 里，
    每一条都带 `_source`（法规条文 + URL + 取用日期）。
    🔴 本脚本里 **不硬编任何一个 DV 数字**。要改数 → 改那份 json，别改这里。

回填约定
────────
    校验通过的行会把结果写回 `row["dv"]`，格式是【显示用字符串】：`"250%"` 或 `"†"`。
    （必须是字符串：既要装百分比，也要装 † = Daily Value not established。）
    同时写一行 `row["_dv_calc"]` 作审计留痕（`_` 开头，build.py / verify_copy.py 都会跳过）。
    build.py 的 facts_html() 只负责把它渲染出来，⛔ 不要在那边再算一遍。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _compat  # noqa: F401  跨平台 UTF-8 兜底（Windows 管道下不修会崩）

HERE = Path(__file__).resolve().parent
DEFAULT_DV_TABLE = HERE.parent / "assets" / "schemas" / "dv_table.json"

# ── 退出码（契约 §7）──────────────────────────────────────────────
EXIT_OK = 0
EXIT_DATA_ERROR = 1
EXIT_NOT_RUN = 2
EXIT_NEEDS_ANSWER = 3

# ── 专利/商标原料词表 ────────────────────────────────────────────
# 🔴 与 references/copy-compliance.md §1.4 同源。改词【先改那份文档，再同步这里】，
#    否则文档和脚本会各说各话——这类漂移我们已经踩过。
#    BioPerine 是本次（2026-08-09）新增：黑胡椒提取物在补剂配方里出现率极高，
#    原词表漏了它，等于滴剂/胶囊配方最常见的一个商标查不出来。
TRADEMARK_INGREDIENTS = {
    # 商标名（小写，去连字符后比对） : 通用名替换建议
    "creapure":  "high-purity creatine monohydrate",
    "ksm66":     "ashwagandha root extract (standardized withanolides)",
    "astragin":  "astragalus & panax notoginseng root extract blend",
    "sensoril":  "ashwagandha root and leaf extract",
    "albion":    "amino acid chelated mineral (e.g. magnesium bisglycinate)",
    "capsimax":  "capsicum fruit extract (capsaicinoids)",
    "teacrine":  "theacrine",
    "carnosyn":  "beta-alanine",
    "bioperine": "black pepper fruit extract (piperine)",
}
# 原样展示用（报告里把 ksm66 打回 KSM-66，人才认得出）
TRADEMARK_DISPLAY = {
    "creapure": "Creapure", "ksm66": "KSM-66", "astragin": "AstraGin",
    "sensoril": "Sensoril", "albion": "Albion", "capsimax": "Capsimax",
    "teacrine": "TeaCrine", "carnosyn": "CarnoSyn", "bioperine": "BioPerine",
}
# ── 商标符号：真符号 + ASCII / 全角替代写法 ──────────────────────────────────
# 🔴 只认 ® ™ 两个字符是不够的（2026-08-09 实测漏洞）：`Zynamite®` 拦得住，
#    `Zynamite(R)` 就**直接放行**。而词表只有 9 个词、穷举不了世上的原料品牌 ——
#    文档自己写着"词表穷举不了，见到符号就按本条办"，那这个"符号"就必须包含人手敲得出来的写法：
#    键盘上没有 ® 的人（尤其 Windows/GBK 环境的同事）打的就是 (R)；从 PDF/网页复制来的可能是全角（R）。
#    覆盖：® ™ ℠ · (R) (TM) (SM) · 全角（R）（TM） · 方括号 [R] [TM]，大小写不敏感、中间允许空格。
# ⛔ 别把这条放宽到"任何括号里的单字母" —— `Vitamin K2 (as MK-7)` 这类形式说明会被整片误伤。
_TM_MARK = r"(?:[®™℠]|[(（\[]\s*(?:R|TM|SM)\s*[)）\]])"
TM_MARK_RX = re.compile(_TM_MARK, re.IGNORECASE)
# 商标名候选 = 符号【前面】那一串词
TM_NAMED_RX = re.compile(r"([A-Za-z0-9][A-Za-z0-9\-\s\.]{0,30}?)\s*(" + _TM_MARK + r")", re.IGNORECASE)

# ── source 可核验形态（P0-3，2026-08-09 新增）────────────────────────────────
# 🔴 为什么这一关非有不可：此前 source **非空即过** —— 每行都改成 `"随便写的"` 也照样 exit 0。
#    而 %DV 是【从 amount 反算的】⇒ **编造的剂量必然配上一个算得完全正确的 %DV**，
#    成品看起来比抄来的还可信。这正是本 skill 病史里「钠500/钾200/镁60mg 全套返工」那次的形状：
#    数字是编的，但每一项校验都是绿的。
# ⛔ 判【告警】不判硬失败：合理的口头来源（"Bowen 微信发的成分表照片"）写不出 URL，
#    硬拦会把对的路一起堵死。这一关的目的不是禁止，是**把"编一个来源"的成本从零抬起来**：
#    编不出可核验形态 → 脚本点名 → 人得解释这行数从哪来。
# 判据（命中任一即算"可核验"）：
#    ① URL —— http(s):// 或 www.（竞品/自家 listing 链接、亚马逊商品页）
#    ② 文件路径/文件名 —— 带图片或表格扩展名，且**能在信息表所在目录下真找到**
#       （找不到 → 单独告警"写了文件名却找不到"，比笼统说"没出处"有用得多）
#    ③ 编号 —— 阿里 listing 编号（≥10 位数字）/ 亚马逊 ASIN（B0 + 9 位）/ SKU 号
#    ④ 点名了人 —— 含 Bowen / 老板 / 客户（口头与图片来源的兜底，可追到人就还能问）
#    ⑤ 🆕 **点名了哪个产品/哪张图** = 【具体品项名】+ 载体（主图 / 背标 / Supplement Facts …）
#       —— 例：`站上【女性肌酸粉】主图 Supplement Facts`、`亚马逊【Ghost Hydration Stick】背标`。
#
# 🔴 ⑤ 是 2026-08-18（I-89⒣）补的，理由：这条规则原先**与 `compliance.md §3.5` 直接打架** ——
#    §3.5 的取数阶梯第 2 级原文就是「翻**站上同类产品的主图**」、第 3 级「从竞品标签取，
#    `source` **写清是哪个竞品/哪张图**」，而旧判据把这两种写法一律判成"核不动"
#    ⇒ 被文档指为字段样例的 `product.example.json` 自己踩满 10 条告警，
#    ⇒ 照文档做的人每次都被脚本骂，规则本身也一个字没进文档（全库 grep「核不动」零命中）。
#    ⇒ 现在的口径：**点名到「哪个产品/哪张图/哪个竞品品项」就算可核验**（去得到、看得到）；
#      **只说"同类/类似/Top 品/竞品"这种泛指的仍然报**（那才是 §3.5 说的"写清"没做到）。
# ⛔ 别把这条规则整个删掉 —— 它拦的是"source 填了等于没填"，那是真问题（病史：钠500/钾200/
#    镁60mg 全套编造返工，每一项校验当时都是绿的）。
_SRC_URL_RX = re.compile(r"(https?://|www\.)", re.IGNORECASE)
_SRC_FILE_RX = re.compile(r"[^\s，,；;（）()、]+\.(?:jpg|jpeg|png|webp|gif|bmp|heic|pdf|xlsx?|csv|docx?|txt|json)\b",
                          re.IGNORECASE)
_SRC_ID_RX = re.compile(r"\b(?:B0[A-Z0-9]{8}|\d{10,})\b")
_SRC_WHO_RX = re.compile(r"bowen|柏坤|老板|客户提供|客户给", re.IGNORECASE)

# ⑤ 的两个要件，**必须同时满足**（只有其一都不算）：
#   (a) 点名 —— 用【】「」《》『』"" 把**具体品项名**括出来。要求括号是因为它是本 skill
#       信息表里既有的写法，而且机器无从判断裸文本里哪一段是"品名"；括起来 = 人明确指认。
#   (b) 载体 —— 说清这个数是从哪儿读来的（主图 / 背标 / Supplement Facts / 详情页 …），
#       否则"【女性肌酸粉】"只是个产品名，不构成"这个数从哪来"。
_SRC_NAMED_RX = re.compile(r"[【「《『]\s*([^】」》』]{2,40}?)\s*[】」》』]"
                           r"|[“\"]\s*([^”\"]{2,40}?)\s*[”\"]")
_SRC_CARRIER_RX = re.compile(
    r"主图|详情页|背标|罐身|袋身|包装|标签|成分表|配方表|属性表|商品页|listing|supplement\s*facts",
    re.IGNORECASE)
# 括号里填的还是泛指词 → 不算点名（"【同类产品】主图" 与 "站上同类主图" 一样核不动）。
_SRC_VAGUE_RX = re.compile(
    r"^(同类(产品)?|类似(产品|品)?|相似品?|同款|竞品|对标品?|某款?|某个|该产品|本款|同上|"
    r"top\s*\d*\s*品?|待核|待补|待定|tbd|\?+)$", re.IGNORECASE)


def _source_names_an_item(src: str) -> bool:
    """⑤ 判据：source 有没有点名到【哪个具体产品/品项】+【哪张图/哪个载体】。"""
    if not _SRC_CARRIER_RX.search(src):
        return False
    for m in _SRC_NAMED_RX.finditer(src):
        name = (m.group(1) or m.group(2) or "").strip()
        if name and not _SRC_VAGUE_RX.match(name):
            return True
    return False

VALID_UNITS = ("mg", "g", "ug", "IU")
VALID_MODES = ("real", "sample", "demo")
EMPTY_EQUIVALENT = {"", "-", "--", "n/a", "na", "none", "null", "tbd", "?", "待定", "待补", "无"}


# ══════════════════════════════════════════════════════════════════
# 小工具
# ══════════════════════════════════════════════════════════════════
def norm_name(s: str) -> str:
    """成分名归一化：小写 → 去括号内容 → 去标点 → 压空格。

    'Vitamin K2 (as Menaquinone-7)' → 'vitamin k2'
    'Zinc (as Zinc Bisglycinate)'   → 'zinc'
    """
    s = (s or "").lower()
    s = re.sub(r"\([^)]*\)", " ", s)          # 去掉括号里的形式说明
    s = s.replace("®", " ").replace("™", " ")
    s = re.sub(r"[^a-z0-9\-\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def norm_tm(s: str) -> str:
    """商标名归一化：**先摘掉商标符号**，再小写 + 去掉所有非字母数字。

    `KSM-66` / `KSM 66` / `KSM66` / `KSM-66®` / `KSM-66 (R)` / `KSM-66（R）` → 全都是 `ksm66`。
    🔴 摘符号这一步不能省：不摘的话 `(R)` 里那个 R 会被当成名字的一部分（→ `ksm66r`），
       Bowen 在 trademark_ok 里写 `KSM-66 (R)` 就白同意了 —— 人会以为闸门坏了（2026-08-09 实测过）。
    """
    s = TM_MARK_RX.sub(" ", s or "")
    return re.sub(r"[^a-z0-9]", "", s.lower())


def round_half_up(x: float) -> int:
    """整数四舍五入。⛔ 别用内置 round()——它是银行家舍入，37.5 和 36.5 的方向不一样，
    会让『同一份数据两次跑出不同结果』这种最难查的问题冒出来。"""
    return int(Decimal(str(x)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def food_increment_round(pct: float, steps: list) -> int:
    """常规食品（Nutrition Facts）的进位阶梯，21 CFR 101.9(c)(8)(iii)。
    补充剂本该用整数百分比，但竞品标签常按这套写——用来判『不是算错，是进位规则不同』。"""
    for st in steps:
        upto = st.get("upto")
        inc = float(st.get("increment", 1))
        if upto is None or pct <= float(upto):
            return int(round_half_up(pct / inc) * inc)
    return round_half_up(pct)


def fmt_num(x) -> str:
    """1500.0 → '1500'；37.5 → '37.5'。报告里别出现一串没意义的 .0"""
    if isinstance(x, float) and x == int(x):
        return str(int(x))
    return str(x)


# ══════════════════════════════════════════════════════════════════
# DV 表
# ══════════════════════════════════════════════════════════════════
class DVTable:
    def __init__(self, data: dict):
        self.raw = data
        self.nutrients = data.get("nutrients", {})
        self.units = data.get("units", {})
        self.to_mg = {k: float(v) for k, v in (self.units.get("to_mg") or {}).items()}
        self.rules = data.get("rules", {})
        self.dosage = data.get("dosage_form", {})
        self.no_dv_kw = [k.lower() for k in (data.get("no_dv_hint_keywords", {}).get("keywords") or [])]
        # 全局 alias → key 索引，按长度倒序：'vitamin b12' 必须先于 'vitamin b1' 命中，
        # 'calcium ascorbate'（维C）必须先于 'calcium'（钙）命中。
        idx = []
        for key, n in self.nutrients.items():
            for a in n.get("aliases", []):
                idx.append((norm_name(a), key))
        idx.sort(key=lambda t: -len(t[0]))
        self.alias_index = idx

    def match(self, name: str):
        """返回 (nutrient_key, matched_alias) 或 (None, None)。"""
        n = norm_name(name)
        if not n:
            return None, None
        for alias, key in self.alias_index:
            if n == alias or n.startswith(alias + " ") or (" " + alias + " ") in (" " + n + " "):
                return key, alias
        return None, None

    def mass_mg(self, amount: float, unit: str):
        """把 (量, 单位) 折成 mg。IU 不是质量单位 → 返回 None。"""
        f = self.to_mg.get(unit)
        return None if f is None else amount * f

    def looks_like_no_dv(self, name: str) -> bool:
        n = norm_name(name)
        return any(kw in n for kw in self.no_dv_kw)


def load_dv_table(path: Path) -> DVTable:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not data.get("nutrients"):
        raise ValueError(f"{path} 里没有 nutrients 段，这份 DV 表是坏的")
    return DVTable(data)


# ══════════════════════════════════════════════════════════════════
# 报告收集器
# ══════════════════════════════════════════════════════════════════
class Report:
    def __init__(self):
        self.errors = []    # 硬错 → 退出码 1
        self.warns = []     # 告警 → 不改退出码
        self.infos = []
        self.tm_pending = []   # 待 Bowen 答复的商标命中 → 退出码 3

    def err(self, where, what, how):
        self.errors.append((where, what, how))

    def warn(self, where, what, how=""):
        self.warns.append((where, what, how))

    def info(self, msg):
        self.infos.append(msg)


# ══════════════════════════════════════════════════════════════════
# 1) 商标 / 专利成分扫描
# ══════════════════════════════════════════════════════════════════
def _walk_strings(obj, path="m7"):
    """递归吐出 (路径, 字符串)。⛔ 跳过 `_` 开头的键——那是注释/取数依据，不上图。"""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(k, str) and k.startswith("_"):
                continue
            yield from _walk_strings(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _walk_strings(v, f"{path}[{i}]")
    elif isinstance(obj, str):
        yield path, obj


def scan_trademarks(facts: dict, rows: list, report: Report, mode: str):
    """扫专利原料商标 + ®/™ 符号。

    命中且不在 facts.trademark_ok 里 → 进 report.tm_pending（退出码 3，停机等 Bowen）。
    命中但已同意 → 放行（否则每改一版配方就卡一次，人会开始无脑跳过这一关）。
    🔴 demo 档命中 = 硬错：demo 的定义就是"Bowen 拒了专利成分后的降级版"，图上不许有任何商标。
    ⛔ 全程不要求 Bowen 提供授权方/授权文件 —— 他说"同意"就够了（契约 §6）。
    """
    ok_raw = facts.get("trademark_ok") or []
    if not isinstance(ok_raw, list):
        report.err("m7.facts.trademark_ok", "不是数组", '改成数组，例：["KSM-66"]；没有就写 []')
        ok_raw = []
    approved = {norm_tm(x) for x in ok_raw if isinstance(x, str)}

    # 每行的出处，供横幅里直接列出来（人要判断"这个商标是从哪抄来的"）
    src_of = {}
    for r in rows:
        if isinstance(r, dict) and isinstance(r.get("name"), str):
            src_of[norm_tm(r["name"])] = str(r.get("source") or "（该行没填 source）")

    hits = {}   # norm_tm -> {"display","where","source","suggest"}

    for where, text in _walk_strings(facts, "m7.facts"):
        low_norm = norm_tm(text)
        for tm, suggest in TRADEMARK_INGREDIENTS.items():
            if tm in low_norm:
                if tm in hits:
                    continue
                src = next((s for k, s in src_of.items() if tm in k), None)
                hits[tm] = {
                    "display": TRADEMARK_DISPLAY.get(tm, tm),
                    "where": where,
                    "source": src or "（未定位到对应行，人工查）",
                    "suggest": suggest,
                    "known": True,
                }
        # 商标符号：即使不在词表里，带符号的原料名一样是别人的注册商标。
        # 🔴 认的是 ® ™ ℠ **和** (R) / (TM) / （R） 这些手敲写法（见 _TM_MARK 上面那段）。
        for m in TM_NAMED_RX.finditer(text):
            cand = m.group(1).strip()
            sym = m.group(2)
            key = norm_tm(cand)
            if not key or key in hits:
                continue
            if any(key.endswith(tm) or tm in key for tm in TRADEMARK_INGREDIENTS):
                continue  # 已被词表覆盖（词表那一轮会给出更准的通用名建议）
            src2 = src_of.get(key) or next((s for k, s in src_of.items() if key and key in k), None)
            hits[key] = {
                "display": f"{cand}{sym}",
                "where": where,
                "source": src2 or "（未定位到对应行，人工查）",
                "suggest": "换成不带 ® / ™ / (R) 的品类通用名（成分本身可以留，商标名不能留）",
                "known": False,
            }

    for key, h in hits.items():
        if mode == "demo":
            report.err(
                h["where"],
                f"demo 档出现商标成分「{h['display']}」",
                "demo = 专利成分被拒后的降级版，图上⛔不许有任何商标。"
                f"把成分名换成品类通用名（建议：{h['suggest']}）",
            )
            continue
        # 🔴 **全等**匹配，⛔ 不许再用后缀/包含匹配（2026-08-09 修）。
        #   旧写法是 `key.endswith(a) or a.endswith(key)`，等于给了一条整片放行商标的后门：
        #     · trademark_ok: ["pure"]   → "creapure".endswith("pure") → **Creapure 被放行**
        #     · trademark_ok: ["e","6"]  → **Creapure + KSM-66 同时放行**
        #   写法差异（KSM66 / KSM-66® / KSM-66 (R) 要互认）已经由 norm_tm 归一化解决了，
        #   模糊匹配在这里【一点用都没有，只有后门】。
        if key in approved:
            report.info(f"✅ 商标成分「{h['display']}」已在 trademark_ok 里，放行（不再重复拦）")
            continue
        report.tm_pending.append(h)


def print_trademark_banner(pending: list, facts: dict, other_errors: int):
    line = "═" * 74
    print("\n" + line)
    print("🛑  停机：扫到专利 / 商标原料成分，需要 Bowen 拍板后才能继续出图")
    print(line)
    for h in pending:
        print(f"\n  · 命中成分：{h['display']}")
        print(f"    出现位置：{h['where']}")
        print(f"    出　　处：{h['source']}")
        print(f"    通用名替换建议：{h['suggest']}")
    print("\n" + "-" * 74)
    print("要问 Bowen 的就一句话（⛔ 不要问他要授权方 / 授权文件 / 合同，说『同意』就够了）：")
    names = " / ".join(h["display"] for h in pending)
    print(f"  「营养成分表里要用到 {names}，这是别家的注册商标。用还是不用？」")
    print("\n他回复后照着做：")
    print("  · 全部同意 → 把商标名写进 m7.facts.trademark_ok，")
    print('              并把 _approved 回填成「Bowen 2026-XX-XX 同意使用 XXX」，重跑本脚本')
    print("  · 只同意几个 → 同意的写进 trademark_ok，其余换成上面的通用名")
    print("  · 都不同意 → m7.facts.mode 改成 \"demo\"，成分名全换品类通用名（图上会打红字：本张已降级为纯版式演示）")
    print("\n⚠️ 风险提示：即使 Bowen 同意，商标风险本身依旧在——")
    print("   阿里国际站被原料商投诉即可能删图 / 扣分。同意 ≠ 安全，只是他愿意担这个风险。")
    if other_errors:
        print(f"\n⚠️ 另外还有 {other_errors} 条数据错误（见上方 ❌ 列表）。")
        print("   先等 Bowen 回复——配方可能整个换掉，现在改数字是白改。")
    print(line)


# ══════════════════════════════════════════════════════════════════
# 2) 单行校验：source / 单位 / %DV / 旧版 DV
# ══════════════════════════════════════════════════════════════════
def parse_declared_dv(raw):
    """把已填的 dv 解析成 (类型, 值)。
    类型：'none'(没填) | 'dagger'(†/*) | 'num'(数值) | 'bad'(看不懂)"""
    if raw is None:
        return "none", None
    if isinstance(raw, (int, float)) and not isinstance(raw, bool):
        return "num", float(raw)
    if isinstance(raw, str):
        s = raw.strip()
        if s == "" :
            return "none", None
        if s in ("†", "*", "**", "†%"):
            return "dagger", None
        if re.fullmatch(r"<\s*1\s*%?", s):
            return "lt1", None
        m = re.match(r"^[<~≈]?\s*([\d.]+)\s*%?$", s)
        if m:
            return "num", float(m.group(1))
        return "bad", s
    return "bad", raw


def check_source_form(label: str, src: str, base, report: Report) -> None:
    """source 的【可核验形态】校验（告警级，见 _SRC_*_RX 上面那段）。"""
    if _SRC_URL_RX.search(src):
        return
    if _SRC_ID_RX.search(src):
        return
    if _SRC_WHO_RX.search(src):
        return
    # ⑤ 点名到哪个产品/哪张图（compliance.md §3.5 第 2/3 级教的正是这种写法）
    if _source_names_an_item(src):
        return
    m = _SRC_FILE_RX.search(src)
    if m:
        cand = m.group(0)
        found = False
        if base is not None:
            p = Path(cand)
            try:
                found = (p if p.is_absolute() else (base / p)).exists()
                if not found:
                    # 只写了文件名（没写目录）也认：在信息表目录下递归找一遍
                    found = any(True for _ in base.rglob(p.name))
            except OSError:
                found = False
        if found:
            return
        report.warn(label, f"source 里写了文件「{cand}」，但在 {base} 下【找不到这个文件】",
                    "要么把文件放进来（信息表同目录/子目录），要么把出处改成能核验的形态"
                    "（链接 / listing 编号 / 谁给的）。⛔ 别留一个查无此文件的文件名当出处。")
        return
    # 一份表里十行都核不动是常事（照着示例填的最容易这样）。逐行都印整段改法会把报告刷爆、
    # 反而没人看 —— 所以**每行都点名**（不点名就没人改），但整段改法只讲第一次。
    if getattr(report, "_said_source", False):
        report.warn(label, f"source 同样【核不动】：{src[:60]!r}", "改法同上第一条。")
        return
    report._said_source = True
    report.warn(
        label, f"source 写了，但【核不动】：{src[:60]!r}",
        "这一关是 2026-08-09 新加的：此前 source 非空即过，每行填「随便写的」也能一路绿灯 —— "
        "而 %DV 是从 amount 反算的，编出来的剂量必然配一个算得完全正确的 %DV，成品比抄来的还像真的。\n"
        "          改成可核验的形态（五选一）：①链接（竞品/自家 listing/亚马逊商品页）；"
        "②文件名（Bowen 给的成分表照片，放进信息表同目录）；③编号（阿里 listing 编号 / ASIN）；"
        "④点名给的人（如「Bowen 2026-08-09 微信发的配方表」）；"
        "⑤**点名到哪个产品 + 哪张图**（compliance.md §3.5 第 2/3 级教的写法，"
        "把品项名用【】括出来：`站上【女性肌酸粉】主图 Supplement Facts`、"
        "`亚马逊【Ghost Hydration Stick】背标`）。\n"
        "          ⛔ 差别只在**点没点名**：「站上同类主图」「竞品标签」「类目 Top 品」是泛指 —— "
        "一个字都核不动；括出具体品项名就去得到、看得到。"
        "真是口头来源就把【谁、什么时候、给的什么】写清楚。",
    )


def check_row(i, row, dv: DVTable, report: Report, fix: bool, base=None):
    """校验一行，返回 (要写回的 dv 字符串 或 None, 该行折成 mg 的固形物量 或 None)。"""
    where = f"m7.facts.rows[{i}]"
    if not isinstance(row, dict):
        report.err(where, "这一行不是对象", "每行必须是 {name, amount, unit, source, ...}")
        return None, None

    name = row.get("name")
    label = f"{where} 「{name}」" if name else where

    # ── name ────────────────────────────────────────────────
    if not isinstance(name, str) or name.strip() == "":
        report.err(where, "name 空", "填成分名，例：\"Vitamin D3\"")
        return None, None

    # ── source 每行必填（skill 铁律：无源就问 Bowen，不许填空）──
    src = row.get("source")
    if not isinstance(src, str) or src.strip().lower() in EMPTY_EQUIVALENT:
        report.err(
            label, f"source 缺失或为空（当前值：{src!r}）",
            "每行都要写清这个数字是从哪来的：竞品标签链接 / 客户提供的成分表照片文件名 / 站上同类主图。"
            "⛔ 编不出来就问 Bowen，不许填空、不许写 N/A。",
        )
    else:
        check_source_form(label, src.strip(), base, report)

    # ── amount ──────────────────────────────────────────────
    amount = row.get("amount")
    if isinstance(amount, bool) or not isinstance(amount, (int, float)):
        report.err(label, f"amount 不是数字（当前：{amount!r}）",
                   "写成纯数字，例：50（⛔ 别写 \"50 mg\" 这种带单位的字符串）")
        return None, None
    amount = float(amount)
    if amount <= 0:
        report.err(label, f"amount = {fmt_num(amount)}，必须 > 0", "填真实剂量；这一行不该出现就删掉")
        return None, None

    # ── unit 合法性 ─────────────────────────────────────────
    unit = row.get("unit")
    if unit not in VALID_UNITS:
        hint = ""
        if isinstance(unit, str) and unit.lower() in ("mcg", "µg", "μg"):
            hint = "（json 里【统一写 ug】，渲染时才变成 µg）"
        elif isinstance(unit, str) and unit.lower() in ("ml", "l", "mL"):
            hint = "（体积不是剂量单位，成分行只能用质量单位）"
        report.err(label, f"unit 非法：{unit!r}{hint}",
                   f"只许写 {' / '.join(VALID_UNITS)} 之一")
        return None, None

    key, alias = dv.match(name)
    nut = dv.nutrients.get(key) if key else None

    # ── IU 换算（只有维生素 A/D/E 有官方系数）────────────────
    conv_note = ""
    mass_mg = None
    if unit == "IU":
        iu = (nut or {}).get("iu")
        if not iu:
            report.err(label, "写了 IU，但这个成分没有官方 IU→质量 换算系数",
                       "IU 只对维生素 A / D / E 有 FDA 官方换算（见 dv_table.json 的 iu 段）。"
                       "其余成分请直接填 mg / ug。")
            return None, None
        if "ug_per_iu" in iu:
            mass_mg = amount * float(iu["ug_per_iu"]) * dv.to_mg["ug"]
            conv_note = f"{fmt_num(amount)} IU × {iu['ug_per_iu']} = {fmt_num(amount * float(iu['ug_per_iu']))} ug"
        elif "mg_per_iu" in iu:
            mass_mg = amount * float(iu["mg_per_iu"])
            conv_note = f"{fmt_num(amount)} IU × {iu['mg_per_iu']} = {fmt_num(mass_mg)} mg"
        note = iu.get("_note")
        if note:
            report.warn(label, "用了 IU，换算系数依赖原料型号", note)
    else:
        mass_mg = dv.mass_mg(amount, unit)

    declared_kind, declared_val = parse_declared_dv(row.get("dv"))
    if declared_kind == "bad":
        report.err(label, f"dv 看不懂：{declared_val!r}",
                   "dv ⛔ 不许手填 —— 删掉这个字段，本脚本会算好回填")
    elif declared_kind != "none" and not str(row.get("_dv_calc") or "").strip():
        # 🔴 P2-10：契约写的是"dv ⛔ 不许手填"，但实现一直是"**填错**才拦" —— 手填一个碰巧对的值
        #    静默通过，等于把契约里最硬的那句话架空了。
        #    怎么区分"手填"和"脚本回填"：回填时会同时写一行 `_dv_calc` 审计留痕（apply_writes），
        #    有 dv 却没有 _dv_calc ⇒ 这个数是人敲进去的。
        #    ⛔ 只告警不硬失败：值对时硬拦会把人堵在一个无害的状态上，而这一条要治的是**习惯**。
        report.warn(label, f"dv = {row.get('dv')!r} 是【手填】的（没有 _dv_calc 审计留痕）",
                    "dv ⛔ 不许手填 —— 删掉这个字段，本脚本会按 dv_table.json 算好并回填，"
                    "同时写一行 _dv_calc 记明依据。手填的问题不在这次对不对，"
                    "而在于图上印的到底是哪一套算法没人分得清；改了 amount 之后手填值也不会跟着变。")

    # ── 没有 DV 的成分 → † ──────────────────────────────────
    if nut is None:
        if declared_kind in ("num", "lt1"):
            shown = f"{fmt_num(declared_val)}%" if declared_kind == "num" else "<1%"
            report.err(
                label, f"填了 %DV = {shown}，但这个成分在 DV 表里查不到",
                "两种可能：①它本来就没有 DV（植物提取物/氨基酸/复配 blend）→ 删掉 dv，脚本会打 †；"
                "②DV 表漏收了 → ⛔ 别自己往 dv_table.json 里补数，"
                "先去 21 CFR 101.9(c)(8)(iv) 查到原文再补，并把 URL 写进 _source。",
            )
            return None, mass_mg
        if dv.looks_like_no_dv(name):
            report.info(f"† {label}：FDA 未设 DV 的成分（植物提取物 / 氨基酸 / 复配 blend 一类），"
                        f"打 † 是对的（21 CFR 101.36(b)(3)：Daily Value not established）")
        else:
            report.warn(
                label, "DV 表里没有这个成分 → 打 †",
                "如果它其实是维生素/矿物质，说明 DV 表漏收了：去 21 CFR 101.9(c)(8)(iv) 查原文补进 "
                "assets/schemas/dv_table.json，⛔ 别凭记忆写数。",
            )
        return "†", mass_mg

    # ── 算 %DV ──────────────────────────────────────────────
    dv_unit = nut.get("unit")
    dv_mg = dv.mass_mg(float(nut["dv"]), dv_unit)
    if dv_mg is None or dv_mg <= 0 or mass_mg is None:
        report.err(label, "DV 表里这条数据有问题（dv/unit 缺失或非法）", f"检查 dv_table.json 的 nutrients.{key}")
        return None, mass_mg

    pct = mass_mg / dv_mg * 100.0
    pct_round = round_half_up(pct)
    # 舍入后是 0% 但实际 > 0：⛔ 别在标上写 "0%"，那看着像坏了、也会被买家质疑。
    # 21 CFR 101.36(b)(2)(iii)(C) 对 DRV 类成分明写要用 "<1%"；RDI 类没明写，
    # 但 "<1%" 同样是真话且明显好过 "0%"，所以两类统一这么处理，并提示人：这个剂量本身可能没意义。
    tiny = 0 < pct < 1
    if tiny:
        report.warn(label, f"%DV 只有 {pct:.2f}%，舍入后是 0%",
                    "已按 \"<1%\" 写（21 CFR 101.36(b)(2)(iii)(C) 对 DRV 类成分就是这么规定的）。"
                    "⚠️ 顺带想一下：这个剂量小到没有营养学意义，是不是抄错了单位、或者这一行本就不该上表？")

    calc = (f"{fmt_num(amount)} {unit}" + (f" → {conv_note}" if conv_note else "")
            + f" ÷ DV {fmt_num(float(nut['dv']))} {nut.get('label_unit') or dv_unit} × 100 = {pct:.2f}% → {pct_round}%")

    if nut.get("caveat"):
        report.warn(label, "口径提醒", nut["caveat"])
    if nut.get("requires_manual_conversion"):
        report.warn(label, "这一项的 %DV 需要人工确认换算口径",
                    "脚本按『填进来的量已经是法规要求的口径』直接算了，口径填错不会报错，只会算出一个看着很像真的假数。")

    # ── 与已填值比对 ────────────────────────────────────────
    if declared_kind == "lt1":
        if not tiny:
            report.err(label, f"填了 <1%，但实际是 {pct_round}%", f"删掉 dv 字段，脚本会填 {pct_round}%")
        return "<1%", mass_mg
    if declared_kind == "dagger":
        report.err(label, f"填了 †，但这个成分有 DV（{fmt_num(float(nut['dv']))} {nut.get('label_unit') or dv_unit}）",
                   f"删掉 dv 字段，脚本会填 {pct_round}%")
    elif declared_kind == "num" and abs(declared_val - pct_round) > 0.5:
        # 是不是用了常规食品的进位阶梯？
        food_pct = food_increment_round(pct, dv.rules.get("food_increment_rounding", {}).get("steps", []))
        if abs(declared_val - food_pct) <= 0.5:
            report.warn(
                label, f"填的 {fmt_num(declared_val)}% 用的是【常规食品】的进位阶梯（21 CFR 101.9(c)(8)(iii)）",
                f"补充剂应按整数百分比 = {pct_round}%（21 CFR 101.36(b)(2)(iii)(C)）。"
                f"{'已按 --fix 改成 ' + str(pct_round) + '%' if fix else '加 --fix 重跑可自动改'}",
            )
            if not fix:
                return None, mass_mg
        else:
            legacy = describe_legacy_match(nut, mass_mg, declared_val, dv)
            fix_hint = (f"已按 --fix 改成 {pct_round}%" if fix
                        else f"删掉这一行的 dv 字段（dv ⛔ 不许手填），或加 --fix 重跑自动改成 {pct_round}%")
            report.err(
                label,
                f"%DV 算错：标的是 {fmt_num(declared_val)}%，按现行 DV 应该是 {pct_round}%\n"
                f"          {calc}" + (f"\n          🔎 {legacy}" if legacy else ""),
                fix_hint,
            )
            if not fix:
                return None, mass_mg

    return ("<1%" if tiny else f"{pct_round}%"), mass_mg


def describe_legacy_match(nut: dict, mass_mg: float, declared_val: float, dv: DVTable):
    """算出来对不上时，试试 2016 年前的旧 DV。对上了 = 这份表是从老标签抄的，没重算。"""
    cands = []
    if nut.get("dv_legacy_as_ug") is not None:
        cands.append((float(nut["dv_legacy_as_ug"]) * dv.to_mg["ug"],
                      f"{fmt_num(nut.get('dv_legacy'))} {nut.get('legacy_unit')}（≈{fmt_num(nut['dv_legacy_as_ug'])} ug）"))
    if nut.get("dv_legacy_as_mg") is not None:
        cands.append((float(nut["dv_legacy_as_mg"]),
                      f"{fmt_num(nut.get('dv_legacy'))} {nut.get('legacy_unit')}（天然型 ≈{fmt_num(nut['dv_legacy_as_mg'])} mg）"))
    if nut.get("dv_legacy_as_mg_synthetic") is not None:
        cands.append((float(nut["dv_legacy_as_mg_synthetic"]),
                      f"{fmt_num(nut.get('dv_legacy'))} {nut.get('legacy_unit')}（合成型 ≈{fmt_num(nut['dv_legacy_as_mg_synthetic'])} mg）"))
    if not cands and nut.get("dv_legacy") is not None and nut.get("legacy_unit") in dv.to_mg:
        cands.append((float(nut["dv_legacy"]) * dv.to_mg[nut["legacy_unit"]],
                      f"{fmt_num(nut['dv_legacy'])} {nut['legacy_unit']}"))

    for legacy_mg, desc in cands:
        if legacy_mg <= 0:
            continue
        legacy_pct = round_half_up(mass_mg / legacy_mg * 100.0)
        if abs(declared_val - legacy_pct) <= 0.5:
            return (f"这是 **2016 年前的旧 DV**：按旧 DV {desc} 算正好是 {legacy_pct}%。"
                    f"说明这份成分表是从老标签直接抄来的、没按现行 DV 重算 —— "
                    f"⚠️ 同一份表里的其他行八成也有同样的问题，逐行核。")
    if cands:
        legacy_pct = round_half_up(mass_mg / cands[0][0] * 100.0)
        return (f"也不是旧 DV：按 2016 年前的旧 DV {cands[0][1]} 算是 {legacy_pct}%，"
                f"和标的 {fmt_num(declared_val)}% 也对不上 —— 这个数字来路不明，回去查出处。")
    return ""


# ══════════════════════════════════════════════════════════════════
# 3) 剂型可行性
# ══════════════════════════════════════════════════════════════════
_SERVING_RX = re.compile(
    r"([\d][\d,\.]*)\s*"
    r"(ml|milliliter|milliliters|l|liter|liters|"
    r"mg|g|gram|grams|"
    r"capsule|capsules|cap|caps|tablet|tablets|tab|tabs|softgel|softgels|"
    r"gummy|gummies|chew|chews|lozenge|lozenges)\b",
    re.IGNORECASE,
)

_VOLUME_UNITS = {"ml": 1.0, "milliliter": 1.0, "milliliters": 1.0, "l": 1000.0, "liter": 1000.0, "liters": 1000.0}
_MASS_UNITS = {"mg": 1.0, "g": 1000.0, "gram": 1000.0, "grams": 1000.0}
_COUNT_UNITS = {"capsule", "capsules", "cap", "caps", "tablet", "tablets", "tab", "tabs",
                "softgel", "softgels", "gummy", "gummies", "chew", "chews", "lozenge", "lozenges"}


def parse_serving(serving: str):
    """解析 serving_size → ('volume', mL) / ('mass', mg) / ('count', 粒数) / (None, None)。
    一个 serving_size 里可能同时有粒数和克重（'2 capsules (1,200 mg)'）→ 优先取质量/体积，那更硬。"""
    if not isinstance(serving, str):
        return None, None
    found = {"volume": None, "mass": None, "count": None}
    for m in _SERVING_RX.finditer(serving):
        try:
            val = float(m.group(1).replace(",", ""))
        except ValueError:
            continue
        u = m.group(2).lower()
        if u in _VOLUME_UNITS and found["volume"] is None:
            found["volume"] = val * _VOLUME_UNITS[u]
        elif u in _MASS_UNITS and found["mass"] is None:
            found["mass"] = val * _MASS_UNITS[u]
        elif u in _COUNT_UNITS and found["count"] is None:
            found["count"] = val
    if found["mass"] is not None:
        return "mass", found["mass"]
    if found["volume"] is not None:
        return "volume", found["volume"]
    if found["count"] is not None:
        return "count", found["count"]
    return None, None


def check_dosage_form(facts: dict, solids_mg: float, skipped: int, dv: DVTable, report: Report):
    """固形物总量 vs 单份体积/重量/粒数。

    为什么要单独有这一关：%DV 全对、单位全对，配方照样可能【物理上做不出来】。
    Bowen 那张参考图就是把一份胶囊配方原样搬进 2 mL 滴剂——2 mL 里塞 2,005 mg 固形物 + 甘油载体。

    为什么分【告警】和【硬失败】两档（阈值与依据全在 dv_table.json 的 dosage_form 段，改那里）：
      · 告警档用的是估算密度（水 1.0 g/mL），估算就可能估错，硬拦会误伤浓缩液体 → 只提醒。
      · 硬失败档用的是【最宽松】的密度上限（甘油 1.2613 g/cm³，PubChem CID 753）。
        连这个上限都装不下，就不是估算误差能解释的了 —— 那是配方本身不成立。
      · 粒数型（胶囊/片）的每粒填充上限是厂内经验值、dv_table.json 里标着 _待核，
        所以【永远只告警】。拿一个没核实的数去硬拦别人的配方，比不拦更糟。
    """
    serving = facts.get("serving_size")
    if not isinstance(serving, str) or serving.strip() == "":
        report.err("m7.facts.serving_size", "没填",
                   '填单份用量，例："2 mL" / "2 capsules" / "5 g"（剂型可行性这一关靠它）')
        return
    kind, val = parse_serving(serving)
    if solids_mg <= 0:
        report.warn("m7.facts", "算不出固形物总量", "所有行的单位都不是质量单位？剂型可行性这一关没跑到。")
        return
    if skipped:
        report.warn("m7.facts", f"有 {skipped} 行没算进固形物总量（单位非法/量非法）",
                    "先把上面的行错改掉，剂型可行性才算得准。")

    conf = dv.dosage or {}
    total_txt = f"固形物合计 {fmt_num(round(solids_mg, 2))} mg，单份 {serving}"

    if kind is None:
        act = conf.get("unknown_form_action", "warn")
        msg = ("看不懂这个剂型（支持 mL / L / g / mg / 粒数）。"
               "🔴 剂型可行性这一关【没跑到】，⛔ 别当它通过了 —— 人工核一遍：这么多料装得进去吗？")
        (report.err if act == "error" else report.warn)("m7.facts.serving_size", f"{total_txt}", msg)
        return

    if kind == "volume":
        c = conf.get("liquid", {})
        dense = float(c.get("generous_density_mg_per_ml", 1261.0))
        nominal = float(c.get("nominal_density_mg_per_ml", 1000.0))
        warn_f = float(c.get("warn_solid_fraction", 0.35))
        fail_f = float(c.get("fail_solid_fraction", 0.70))
        fail_cap = val * dense * fail_f
        warn_cap = val * nominal * warn_f
        if solids_mg > fail_cap:
            report.err(
                "m7.facts", f"剂型不可行：{total_txt}",
                f"{fmt_num(val)} mL 液体按最宽松的载体密度（甘油 {fmt_num(dense/1000)} g/mL）算，单份总质量也只有 "
                f"{fmt_num(round(val*dense))} mg；固形物 {fmt_num(round(solids_mg))} mg 已占 "
                f"{solids_mg/(val*dense)*100:.0f}%（阈值 {fail_f*100:.0f}%），剩不下溶剂 → 做不成可滴出的液体。\n"
                f"          改法（三选一）：①加大单份体积（如 2 mL → 5 mL 或 10 mL）；"
                f"②砍剂量或砍成分（这本来就是胶囊配方直接搬过来的典型症状）；"
                f"③剂型改成胶囊 / 粉剂。⛔ 别只改图上的数字不改配方逻辑。",
            )
        elif solids_mg > warn_cap:
            report.warn(
                "m7.facts", f"剂型偏挤：{total_txt}",
                f"按水密度估，固形物已占单份质量约 {solids_mg/(val*nominal)*100:.0f}%（告警线 {warn_f*100:.0f}%）。"
                f"能不能做出来取决于溶解度，人工核一下；做不出来就加大单份体积。",
            )
        else:
            report.info(f"✅ 剂型可行性：{total_txt}，固形物约占单份质量 {solids_mg/(val*nominal)*100:.0f}%（按水密度估）")

    elif kind == "mass":
        c = conf.get("mass", {})
        warn_f = float(c.get("warn_solid_fraction", 0.90))
        if solids_mg > val:
            report.err("m7.facts", f"剂型不可行：{total_txt}",
                       f"固形物 {fmt_num(round(solids_mg))} mg 已经超过标示的单份重量 {fmt_num(val)} mg —— "
                       f"这是纯算术，不含任何假设。改单份重量或改配方。")
        elif solids_mg > val * warn_f:
            report.warn("m7.facts", f"剂型偏挤：{total_txt}",
                        f"固形物占单份重量 {solids_mg/val*100:.0f}%（告警线 {warn_f*100:.0f}%），"
                        f"几乎没有辅料（抗结/流动/调味）空间，人工核。")
        else:
            report.info(f"✅ 剂型可行性：{total_txt}，固形物约占 {solids_mg/val*100:.0f}%")

    else:  # count
        c = conf.get("count", {})
        cap = float(c.get("max_fill_mg_per_unit", 800.0)) * val
        tail = "（⚠️ 每粒填充上限是厂内经验值、dv_table.json 里标着 _待核 → 本档【只告警不硬拦】）"
        if solids_mg > cap:
            report.warn("m7.facts", f"剂型可能装不下：{total_txt}",
                        f"按每粒约 {fmt_num(float(c.get('max_fill_mg_per_unit', 800.0)))} mg 估，"
                        f"{fmt_num(val)} 粒最多约 {fmt_num(round(cap))} mg，固形物 {fmt_num(round(solids_mg))} mg 超了。"
                        f"确认胶囊号数与粉体堆密度，或加粒数 / 砍剂量。{tail}")
        else:
            report.info(f"✅ 剂型可行性：{total_txt}，估算装得下{tail}")


# ══════════════════════════════════════════════════════════════════
# 主流程
# ══════════════════════════════════════════════════════════════════
def check_facts(spec: dict, dv: DVTable, report: Report, fix: bool, base=None):
    """返回 (要写回的 {行号: dv字符串}, mode)。base = 信息表所在目录（用来核 source 里的文件路径）。"""
    m7 = spec.get("m7")
    if not isinstance(m7, dict):
        report.err("m7", "product.json 里没有 m7 段", "按 m7 契约 §2 补上（H1 / SUB / facts）")
        return {}, None
    facts = m7.get("facts")
    if not isinstance(facts, dict):
        report.err("m7.facts", "没有 facts 段", "按 m7 契约 §2 补上（mode / serving_size / rows / ...）")
        return {}, None

    mode = facts.get("mode")
    if mode not in VALID_MODES:
        report.err("m7.facts.mode", f"mode 非法：{mode!r}",
                   f"只许 {' / '.join(VALID_MODES)}（real=本款真实配方 · sample=参考配方 · demo=专利成分被拒后的降级版）")
        mode = mode if isinstance(mode, str) else None

    rows = facts.get("rows")
    if not isinstance(rows, list) or not rows:
        report.err("m7.facts.rows", "rows 空或不是数组", "至少填一行成分；一行都填不出来就别上 m7")
        return {}, mode

    # 商标扫描（先扫：它可能让整份配方作废）
    scan_trademarks(facts, rows, report, mode or "sample")

    if facts.get("trademark_ok") and not (facts.get("_approved") or "").strip():
        report.warn("m7.facts._approved", "trademark_ok 里有东西，但 _approved 是空的",
                    '回填审计痕迹，例："Bowen 2026-08-09 同意使用 KSM-66"。'
                    "⛔ 别去要授权文件，记一句『谁 何时 同意了什么』就够。")

    # 逐行
    writes = {}
    solids_mg = 0.0
    skipped = 0
    for i, row in enumerate(rows):
        val, mass = check_row(i, row, dv, report, fix, base)
        if val is not None:
            writes[i] = val
        if mass is None:
            skipped += 1
        else:
            solids_mg += mass

    # servings_per_container（不影响剂型，但空着图上会缺一格）
    spc = facts.get("servings_per_container")
    if not isinstance(spc, (int, float)) or isinstance(spc, bool) or spc <= 0:
        report.warn("m7.facts.servings_per_container", f"缺失或非法（当前：{spc!r}）",
                    "填正整数，例：30。图上这一格空着很显眼。")

    check_dosage_form(facts, solids_mg, skipped, dv, report)

    if mode == "sample":
        report.info("ℹ️ mode = sample → 图上必须挂 compliance.md §3.5 的【上下两条】免责原文（一字照抄，别翻译）")
    elif mode == "demo":
        report.info("🔴 mode = demo → 这张是【纯版式演示】，成分名必须全是品类通用名，收尾要打红字告知")
    elif mode == "real":
        report.info("ℹ️ mode = real → 真实配方，须可核实；图上只挂 "
                    "'Ingredients and dosage can be customized.'（⛔ 不挂 'Sample formula shown.'）")

    return writes, mode


def apply_writes(spec: dict, writes: dict, rows_note: dict):
    for i, val in writes.items():
        row = spec["m7"]["facts"]["rows"][i]
        row["dv"] = val
        if i in rows_note:
            row["_dv_calc"] = rows_note[i]


def print_report(report: Report):
    for msg in report.infos:
        print(f"  {msg}")
    if report.warns:
        print()
        for where, what, how in report.warns:
            print(f"  ⚠️  {where}：{what}")
            if how:
                print(f"      → {how}")
    if report.errors:
        print()
        for where, what, how in report.errors:
            print(f"  ❌ {where}：{what}")
            print(f"      → 改法：{how}")


# ── 自测 ─────────────────────────────────────────────────────────
def selftest(dv: DVTable) -> int:
    """内置自测：验 DV 表关键值 + 验本脚本的算法。⛔ 改 dv_table.json 或本脚本后必须跑一遍。"""
    fails = []
    checked = [0]

    def eq(got, want, name):
        checked[0] += 1
        if got != want:
            fails.append(f"{name}: 得到 {got}，应为 {want}")

    # DV 表关键值（Bowen 那张参考图的两处错，正是这两条查出来的）
    eq(dv.nutrients["vitamin_d"]["dv"], 20, "现行 DV 维生素 D = 20 ug")
    eq(dv.nutrients["vitamin_k"]["dv"], 120, "现行 DV 维生素 K = 120 ug")
    eq(dv.nutrients["vitamin_k"]["dv_legacy"], 80, "旧 DV 维生素 K = 80 ug")
    eq(dv.nutrients["vitamin_d"]["iu"]["iu_per_ug"], 40.0, "维生素 D 1 ug = 40 IU")

    # 算法
    eq(round_half_up(50 / 20 * 100), 250, "D3 50 ug → 250%")
    eq(round_half_up(45 / 120 * 100), 38, "K2 45 ug → 38%")
    eq(round_half_up(45 / 80 * 100), 56, "K2 45 ug 按旧 DV → 56%（这就是参考图上那个 56%）")
    eq(round_half_up(37.5), 38, "round_half_up 不能是银行家舍入")
    eq(round_half_up(36.5), 37, "round_half_up 不能是银行家舍入")

    # 名字匹配
    eq(dv.match("Vitamin D3 (as Cholecalciferol)")[0], "vitamin_d", "匹配 Vitamin D3")
    eq(dv.match("Vitamin K2 (as MK-7)")[0], "vitamin_k", "匹配 Vitamin K2")
    eq(dv.match("Vitamin B12")[0], "vitamin_b12", "Vitamin B12 不能被 B1 抢走")
    eq(dv.match("Calcium Ascorbate")[0], "vitamin_c", "Calcium Ascorbate 是维C 不是钙")
    eq(dv.match("Passion Flower Extract")[0], None, "植物提取物不该匹配到任何 DV")

    # 剂型
    eq(parse_serving("2 mL"), ("volume", 2.0), "解析 2 mL")
    eq(parse_serving("2 capsules (1,200 mg)"), ("mass", 1200.0), "粒数+克重时取克重")
    eq(parse_serving("2 capsules"), ("count", 2.0), "解析 2 capsules")

    # 商标归一化（🔴 三种写法必须互认，否则 Bowen 同意的写法和图上印的写法差一个符号就白同意）
    eq(norm_tm("KSM-66®"), "ksm66", "KSM-66® 归一化")
    eq(norm_tm("BioPerine®"), "bioperine", "BioPerine® 归一化")
    eq(norm_tm("KSM66"), "ksm66", "KSM66 归一化")
    eq(norm_tm("KSM-66 (R)"), "ksm66", "KSM-66 (R) 归一化（2026-08-09：不摘 (R) 会变成 ksm66r）")
    eq(norm_tm("KSM-66（R）"), "ksm66", "KSM-66（R）全角归一化")
    eq(norm_tm("Zynamite(TM)"), "zynamite", "Zynamite(TM) 归一化")

    # 商标符号识别：词表【外】的原料品牌只能靠符号逮住，所以四种写法都得认
    # （2026-08-09 实测漏洞：Zynamite® 拦得住，Zynamite(R) 直接放行）
    for s in ("Zynamite®", "Zynamite(R)", "Zynamite（R）", "Zynamite(TM)", "Zynamite™"):
        eq(bool(TM_NAMED_RX.search(s + " Mangifera Extract")), True, f"符号识别 {s}")
    # ⛔ 不许误伤成分名里的形式说明括号
    for s in ("Vitamin K2 (as MK-7)", "Zinc (as Zinc Bisglycinate)", "Magnesium (Citrate)"):
        eq(bool(TM_NAMED_RX.search(s)), False, f"⛔ 不该误判为商标：{s}")

    # source 可核验形态（P0-3）
    _r = Report()
    check_source_form("t", "随便写的", None, _r)
    eq(len(_r.warns), 1, "source「随便写的」必须告警")
    for good in ("https://detail.1688.com/offer/123.html", "Bowen 2026-08-09 微信给的配方表",
                 "亚马逊 ASIN B0CJK2XQ9F 标签", "阿里 listing 编号 1601234567890",
                 # ⑤ 点名到哪个产品/哪张图（I-89⒣，= compliance.md §3.5 第 2/3 级教的写法）
                 "站上【女性肌酸粉】主图 Supplement Facts（同为 12g 条包×30）",
                 "亚马逊对标品【Ghost Hydration Stick】背标 Supplement Facts",
                 "站上【女性肌酸粉】主图 Supplement Facts🔴数值待核：实跑须重新读图"):
        _r2 = Report()
        check_source_form("t", good, None, _r2)
        eq(len(_r2.warns), 0, f"可核验的 source 不该告警：{good}")
    # 🔴 反例：⑤ 放宽后**仍然要报**的几种（⛔ 别把这条规则放成"有个括号就过"）
    for bad in ("站上同类产品的主图",                      # 泛指，没点名 → §3.5 说的"写清"没做到
                "亚马逊对标品：类目 Top 品标签",            # 同上
                "【同类产品】主图",                        # 括号里还是泛指词
                "待核",                                    # 纯占位
                "【女性肌酸粉】"):                          # 只有品名、没说从哪张图读的
        _r3 = Report()
        check_source_form("t", bad, None, _r3)
        eq(len(_r3.warns), 1, f"仍然核不动的 source 必须告警：{bad}")

    # DV 表结构完整性（有人手改 json 时最容易改坏的几处）
    for key, n in dv.nutrients.items():
        checked[0] += 1
        if not isinstance(n.get("dv"), (int, float)) or n["dv"] <= 0:
            fails.append(f"nutrients.{key}.dv 不是正数")
        elif n.get("unit") not in dv.to_mg:
            fails.append(f"nutrients.{key}.unit={n.get('unit')!r} 不在 units.to_mg 里（只许 mg/g/ug）")
        elif not n.get("aliases"):
            fails.append(f"nutrients.{key} 没有 aliases，永远匹配不上")
    checked[0] += 1
    if not (dv.raw.get("_source", {}).get("current_dv", {}).get("url")):
        fails.append("_source.current_dv.url 缺失 —— 数字没有出处 = 不许用")

    # 🔴 商标归一：写法差一个符号就不该白同意（这几条是 2026-08-09 实测踩出来的）
    for raw in ("KSM-66", "KSM 66", "KSM66", "KSM-66®", "KSM-66™", "KSM-66 (R)", "KSM-66（R）"):
        eq(norm_tm(raw), "ksm66", f"norm_tm({raw!r}) 必须归到 ksm66")

    # 🔴 **防分叉断言**（I-77，2026-08-17）：`verify_copy` 曾自带一份不摘 `(R)` 的 _norm_tm，
    #    build.py 那条路靠适配层绕过去了，单独跑 verify_copy.py 的人却一直在踩。
    #    ⛔ 谁再在 verify_copy 里写回本地实现、且行为对不上，这条当场红灯。
    #    ⚠️ 比的是**行为不是身份**：本脚本直接跑时自己是 `__main__`，verify_copy import 到的
    #       `check_facts` 是另一个模块对象 ⇒ `is` 永远不成立（第一版就是这么假报的）。
    try:
        import verify_copy as _vc_probe
        for raw in ("KSM-66", "KSM 66", "KSM66", "KSM-66®", "KSM-66™", "KSM-66 (R)", "KSM-66（R）"):
            checked[0] += 1
            if _vc_probe._norm_tm(raw) != norm_tm(raw):
                fails.append(f"verify_copy._norm_tm 又分叉了：{raw!r} → "
                             f"{_vc_probe._norm_tm(raw)!r}，应与 check_facts.norm_tm 一致 "
                             f"({norm_tm(raw)!r})。改法：`from check_facts import norm_tm as _norm_tm`")
    except Exception as e:      # noqa: BLE001
        checked[0] += 1
        fails.append(f"import verify_copy 失败，防分叉断言没跑成：{type(e).__name__}: {e}")

    if fails:
        print("❌ 自测不通过：")
        for f in fails:
            print(f"   · {f}")
        return EXIT_DATA_ERROR
    print(f"✅ 自测通过（{checked[0]} 项）。DV 表版本 {dv.raw.get('_版本')} · 取用日期 {dv.raw.get('_取用日期')}")
    return EXIT_OK


def main(argv):
    ap = argparse.ArgumentParser(
        description="m7 营养成分表数据校验器（%DV / 单位 / 剂型 / source / 商标）",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    ap.add_argument("spec", nargs="?", help="product.json 路径")
    ap.add_argument("--dv-table", default=str(DEFAULT_DV_TABLE), help="DV 表路径（默认 assets/schemas/dv_table.json）")
    ap.add_argument("--dry-run", action="store_true", help="只校验，不回填 dv")
    ap.add_argument("--fix", action="store_true", help="连手填错的 dv 也一并改成算出来的值（仍会报错并返回 1，好让人看见改了什么；重跑一次即 0）")
    ap.add_argument("--selftest", action="store_true", help="内置自测（验 DV 表 + 验算法）")
    args = ap.parse_args(argv[1:])

    # DV 表
    dvp = Path(args.dv_table)
    if not dvp.is_file():
        print(f"❌ 读不到 DV 表：{dvp}")
        print("   → 它是 %DV 计算的唯一数据源，缺了这一关【没跑成】（退出码 2），⛔ 别当通过。")
        return EXIT_NOT_RUN
    try:
        dv = load_dv_table(dvp)
    except Exception as e:
        print(f"❌ DV 表解析失败：{dvp}\n   {type(e).__name__}: {e}")
        return EXIT_NOT_RUN

    if args.selftest:
        return selftest(dv)

    if not args.spec:
        ap.print_help()
        return EXIT_NOT_RUN

    sp = Path(args.spec)
    if not sp.is_file():
        print(f"❌ 读不到 product.json：{sp}")
        return EXIT_NOT_RUN
    try:
        spec = json.loads(sp.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"❌ product.json 解析失败：{sp}\n   {type(e).__name__}: {e}")
        return EXIT_NOT_RUN

    print(f"── check_facts.py · {sp.name} ──")
    print(f"   DV 表：{dvp.name}（版本 {dv.raw.get('_版本')} · 取用 {dv.raw.get('_取用日期')} · 21 CFR 101.9(c)(8)(iv)/(c)(9)）\n")

    report = Report()
    writes, mode = check_facts(spec, dv, report, args.fix, sp.parent)
    print_report(report)

    # 回填
    if writes and not args.dry_run:
        notes = {}
        for i, val in writes.items():
            notes[i] = f"check_facts.py 按现行 FDA DV 算出，⛔ 不许手改（{dv.raw.get('_取用日期')} 版 DV 表）"
        apply_writes(spec, writes, notes)
        sp.write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"\n  ✍️  已把 {len(writes)} 行的 dv 回填进 {sp.name}（格式：\"250%\" / \"†\"）")
    elif writes:
        print(f"\n  （--dry-run：{len(writes)} 行的 dv 算好了但没写；去掉 --dry-run 即回填）")

    n_err = len(report.errors)
    n_warn = len(report.warns)
    print(f"\n合计：❌ 错误 {n_err} · ⚠️ 告警 {n_warn} · 🛑 待答复商标 {len(report.tm_pending)}")

    if report.tm_pending:
        print_trademark_banner(report.tm_pending, spec["m7"]["facts"], n_err)
        return EXIT_NEEDS_ANSWER   # 🔴 3 优先于 1：商标没定，改数字是白改（说明见文件顶部）
    if n_err:
        print("→ 上面每条都写了具体改法。改完重跑本脚本，直到 0 错误再出图。")
        return EXIT_DATA_ERROR

    print("→ ✅ 数字与成分这一关过了。")
    print("   ⚠️ 本脚本【只查数字和成分】，还差两关：")
    print("      · verify_copy.py —— 文案词（疾病宣称 / FDA / 绝对化词）")
    print("      · review_facts.py —— 配方逻辑是否讲得通（LLM 顾问，只报不拦）")
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main(sys.argv))
