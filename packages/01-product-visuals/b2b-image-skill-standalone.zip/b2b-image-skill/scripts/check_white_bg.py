#!/usr/bin/env python3
"""白底检查：元素件 / 产品图有没有【该透明却是白底】的问题。

为什么需要（2026-07-31 胶原蛋白果冻条实测翻车）：
  主图的 scene / 产品 槽应该放【透明抠图件】或走 --scene 融合。若误把一张【白底】
  产品/元素图直接塞进这些槽 → 渲染时会在彩色（宝蓝）背景上贴出一个**白方块**，明显不达标。
  qc.py 只量颜色配比、量不出这种白框；人工目检也漏过 → 加这道自动关堵住。

判定（只看图片【边缘一圈】= 背景所在，不看中间产品本体，所以白色产品也不会误判）：
  · 边缘大部分【透明】(alpha≈0)            → ✅ PASS（干净抠图件）
  · 边缘【不透明】且大多【近白】           → ❌ FAIL 白底（会在彩底上现白框，必须返工）
  · 边缘【不透明】但不近白（整图铺满照片）  → ⚠️ 提示（非透明；若是整幅照片槽=正常，若该浮空=也不对）

返工怎么修：
  · 抠图法：python scripts/cutout.py 白底图 透明件.png  （白底产品 flood 最稳）
  · 或走 V2 场景替换：把真产品放 product.json 的 swap.product，images 槽放透明占位件。

用法：
  python scripts/check_white_bg.py 图1.png 图2.png ...      # 逐张判定，有 FAIL 退出码 1
  python scripts/check_white_bg.py 图.png --preview          # 额外出一张贴宝蓝底的预览，肉眼看白框
  python scripts/check_white_bg.py 图.png --on-color FFFFFF  # 指定它将落在的底色（默认宝蓝 1E6FE6）
"""
import argparse, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （修 Windows 管道 emoji 崩溃）

try:
    from PIL import Image
except ImportError:
    sys.exit("需要 Pillow：pip install pillow")

BRAND_BLUE = (30, 111, 230)   # #1E6FE6，主图/详情页彩色模块底色


def scan(path, white_thresh=232):
    """判定一张图边缘背景是不是【该透明却白底】。返回 dict。"""
    im = Image.open(path).convert("RGBA")
    W, H = im.size
    # 缩略到 ≤256 加速；边缘背景在缩略后仍在（只是抗锯齿，不影响近白/透明判定）
    t = im.copy()
    t.thumbnail((256, 256))
    tw, th = t.size
    px = t.load()
    m = max(2, round(0.03 * min(tw, th)))     # 采样【外圈一圈】= 背景所在
    ring = []
    for y in range(th):
        for x in range(tw):
            if x < m or x >= tw - m or y < m or y >= th - m:
                ring.append(px[x, y])
    n = len(ring) or 1
    transp = sum(1 for r, g, b, a in ring if a < 25) / n
    opaque = [(r, g, b, a) for r, g, b, a in ring if a >= 200]
    op_frac = len(opaque) / n
    white = sum(1 for r, g, b, a in opaque
                if r >= white_thresh and g >= white_thresh and b >= white_thresh)
    white_frac = white / (len(opaque) or 1)

    if transp >= 0.85:
        verdict = "ok"          # 干净透明件
    elif op_frac >= 0.5 and white_frac >= 0.6:
        verdict = "white_bg"    # ❌ 白底，会现白框
    elif op_frac >= 0.5:
        verdict = "opaque_other"  # ⚠️ 非透明、非白（整幅照片就正常）
    else:
        verdict = "ok"          # 边缘多为半透明柔边/阴影 → 放行
    return {"path": str(path), "size": (W, H), "verdict": verdict,
            "transparent_edge": round(transp, 2), "opaque_edge": round(op_frac, 2),
            "white_edge": round(white_frac, 2)}


def preview(path, on_color=BRAND_BLUE):
    """把图贴在底色上出一张预览，白框会一眼看出来。"""
    im = Image.open(path).convert("RGBA")
    bg = Image.new("RGBA", im.size, on_color + (255,))
    bg.alpha_composite(im)
    out = Path(path).with_name(Path(path).stem + "_白底检查_底色.png")
    bg.convert("RGB").save(out)
    return out


ICON = {"ok": "✅ PASS", "white_bg": "❌ FAIL 白底", "opaque_other": "⚠️ 非透明"}


def main():
    ap = argparse.ArgumentParser(description="白底检查：元素件/产品图该透明却白底 → 返工")
    ap.add_argument("images", nargs="+")
    ap.add_argument("--preview", action="store_true", help="额外贴底色出预览图，肉眼看白框")
    ap.add_argument("--on-color", default=None, help="落底色 HEX（默认宝蓝 1E6FE6）")
    ap.add_argument("--quiet", action="store_true", help="只打 FAIL")
    a = ap.parse_args()
    oc = BRAND_BLUE
    if a.on_color:
        h = a.on_color.lstrip("#"); oc = tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

    bad = []
    for p in a.images:
        if not Path(p).exists():
            print(f"⚠️ 找不到 {p}"); continue
        r = scan(p)
        if a.quiet and r["verdict"] != "white_bg":
            pass
        else:
            print(f"{ICON[r['verdict']]}  {Path(p).name}  "
                  f"(边缘 透明{r['transparent_edge']:.0%} 不透明{r['opaque_edge']:.0%} 近白{r['white_edge']:.0%})")
        if r["verdict"] == "white_bg":
            bad.append(p)
            if a.preview:
                print(f"      预览: {preview(p, oc).name}")
        elif a.preview:
            preview(p, oc)

    if bad:
        print(f"\n❌ {len(bad)} 张【白底】元素件/产品图 —— 在彩色底上会现白方块，必须返工：")
        for p in bad:
            print(f"   · {Path(p).name}")
        print("   修：python scripts/cutout.py 白底图 透明件.png  （或走 V2 --scene 场景替换）")
        print("   确属该白底（如白底主图 s5）→ 把该槽加进 product.json 模块的 images._allow_white_bg。")
        sys.exit(1)
    print("\n✅ 未发现白底问题。（仍建议 Read 出图肉眼复核元素件融合。）")


if __name__ == "__main__":
    main()
