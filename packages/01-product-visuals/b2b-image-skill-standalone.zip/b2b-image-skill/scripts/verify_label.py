#!/usr/bin/env python3
"""标签验收 —— 比对「原图」与「AI 生成图」上的文字是否被改动。

用法：
    .venv-rembg/bin/python 验标签.py 原图.jpg 生成图.png

为什么需要它：
    gpt-image-2 的 /v1/images/edits 是重新生成、不是修图，会篡改包装文字。
    实测原气兔子被改「速度力量类」→「耐苞力粟类」、「SPEED AND STRENGTH」→
    「ENDURANCE AND STRENGTH」——后者是国标运动营养食品的另一个注册类目，
    属于产品信息造假。而这种改动肉眼扫一遍很容易漏掉（本项目已漏判多次）。

判据（三道，缺一不可）：
    ① --expect  原图上必须存在的关键文字，生成图里必须原样出现。
    ② --forbid  绝不允许出现的错词（如把「速度力量类」改成「耐力类」）。
    ③ 全量 OCR 对比，列出疑似改写供人工复核。

⚠️ 为什么不能只靠「两边 OCR 对比」：
    实测原图（镭射面反光 + 手持模糊）OCR 全是乱码「随建力量炎)」「NEATRTONFO0D」，
    而 AI 生成图的字很干净、OCR 读得准 —— 两边质量不对等，直接 diff 会漏判也会误判。
    所以关键文字必须由人从原图高清放大处**先定成标准答案**，再拿来卡生成图。
    ①② 是硬判据，③ 只作参考。

配套（本项目实测的标准答案，抄了直接用）：
    原气兔子：--expect "运动营养食品|速度力量类|SPEED AND STRENGTH|瓜拉纳提取物|一水肌酸|苹果口味"
              --forbid "耐力|耐苞|ENDURANCE"
    T-BOOSTER：--expect "SANTOS MUSCLE NUTRITION|T-BOOSTER|CAPSULES|SUPERBOOSTER|120 CAPSULES"
"""

import argparse
import difflib
import os
import platform
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401  （必须 import：修 Windows 管道输出下 emoji 崩溃）

# ── 跨平台 OCR（Bowen 2026-07-31，C+A 方案）──────────────────────────────
# macOS：走系统自带 Vision OCR（离线、快、准）。
# 非 macOS（同事 Windows）：走【云 OCR】—— 用 gen_image 的 `creds_ocr()`（**deepkey 文本组**，
#   ⛔ 不是生图组：那一组里没有任何文本模型），调 gpt-5.x 视觉模型读图取字，本机零新依赖。
# 云 OCR 不可用（没配 key / 没网 / 模型读不了图）→ 抛 CloudOCRUnavailable →
#   main 退回【人工/agent 核对提示】+ **退出码 0**（"本机跑不了自动筛" ≠ "校验失败"，不再假报 exit 1）。
# ⚠️ 旧版：非 macOS 直接 sys.exit（退出码 1），被同事 Windows / Codex 当成"命令失败"卡流程 —— 本次修掉。
IS_MAC = platform.system() == "Darwin" and not os.environ.get("VERIFY_LABEL_FORCE_CLOUD")
# 非 macOS 云 OCR 用的视觉模型。可用环境变量 VERIFY_LABEL_MODEL 覆盖。
# 🔴 2026-08-06 Bowen 定：云 OCR 也走 deepkey，模型用 **gpt-5.5**。
#   实测（deepkey 文本组，同一张测试图）：gpt-5.5 ✅ 6.7s · gpt-5.4-mini ✅ 2.3s，两者都读对；
#   而**老通道 TokenStation 的 gpt-5.4-mini 回 HTTP 503**（云 OCR 在那边本来就是废的）。
#   ⚠️ 这个模型名归【文本组】的 key 管；⛔ 别指望生图组的 key 能调它。
CLOUD_OCR_MODEL = os.environ.get("VERIFY_LABEL_MODEL", "gpt-5.5")


class CloudOCRUnavailable(Exception):
    """非 macOS 且云 OCR 也跑不了（没配 key / 没网 / 模型不支持读图）→ 退回人工核对，不算失败。"""


def _ocr_vision(path, langs=("zh-Hans", "en-US")):
    """macOS Vision OCR，返回 [(文字, 置信度)]。"""
    import Quartz  # 延迟 import：非 macOS 装不上 pyobjc，也不需要
    import Vision
    url = Quartz.CFURLCreateFromFileSystemRepresentation(
        None, str(path).encode("utf-8"), len(str(path).encode("utf-8")), False
    )
    src = Quartz.CGImageSourceCreateWithURL(url, None)
    if src is None:
        raise SystemExit(f"读不了图片: {path}")
    img = Quartz.CGImageSourceCreateImageAtIndex(src, 0, None)

    out = []
    handler = Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(img, None)
    req = Vision.VNRecognizeTextRequest.alloc().init()
    req.setRecognitionLevel_(0)          # 0 = accurate
    req.setUsesLanguageCorrection_(False)  # 关掉纠错，否则会把乱码"修"成正常词，掩盖问题
    req.setRecognitionLanguages_(list(langs))
    handler.performRequests_error_([req], None)

    for obs in req.results() or []:
        cand = obs.topCandidates_(1)
        if cand:
            out.append((cand[0].string(), float(cand[0].confidence())))
    return out


def _ocr_cloud(path):
    """非 macOS：云端视觉模型读图取字（deepkey 文本组，走 gen_image 的 creds_ocr()）。返回 [(文字, 置信度)]。
    云模型不给逐条置信度 → 统一给 0.95（读得准）。任何不可用 → 抛 CloudOCRUnavailable。"""
    import base64 as _b64
    import json as _json
    import urllib.request as _u
    try:
        # 🔴 用 creds_ocr()（文本/视觉通道），⛔ 不是 creds()（生图通道）——
        #   2026-08-06 生图换到 deepkey 后两者分家了：生图组的 key 里没有任何文本模型。
        from gen_image import creds_ocr, USER_AGENT, _ssl_context
        base, key, _prov = creds_ocr()   # 没配 key/base 时会 sys.exit → 下面 SystemExit 接住
    except SystemExit as e:
        raise CloudOCRUnavailable(f"没配云 OCR 凭据 DEEPKEY_TEXT_*（{e}）")
    except Exception as e:  # noqa: BLE001
        raise CloudOCRUnavailable(f"读取凭据失败：{type(e).__name__} {e}")

    img = _b64.b64encode(Path(path).read_bytes()).decode()
    prompt = ("OCR this product package image. List EVERY piece of text visible, one item per line, "
              "exactly as printed — keep the original language, digits, units and punctuation. "
              "Do NOT translate, do NOT correct spelling, do NOT add any commentary. Output only the text lines.")
    body = _json.dumps({"model": CLOUD_OCR_MODEL, "temperature": 0, "seed": 7,
                        "messages": [{"role": "user", "content": [
        {"type": "text", "text": prompt},
        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img}"}},
    ]}]}).encode()  # temperature=0+seed：锁随机性，同图两次读一致（否则判据①偶发假阴、③假报改写）
    req = _u.Request(f"{base}/v1/chat/completions", data=body,
                     headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json",
                              "User-Agent": USER_AGENT})
    try:
        with _u.urlopen(req, timeout=120, context=_ssl_context()) as r:
            d = _json.loads(r.read())
    except Exception as e:  # noqa: BLE001  网络/HTTP/超时都退回人工，不当"校验失败"
        raise CloudOCRUnavailable(f"云 OCR 调用失败（{type(e).__name__} {e}）")
    try:
        text = d["choices"][0]["message"]["content"]
    except Exception:  # noqa: BLE001
        raise CloudOCRUnavailable(f"云 OCR 返回异常：{str(d)[:200]}")
    lines = [ln.strip(" -•\t·") for ln in (text or "").splitlines() if ln.strip()]
    if not lines:
        raise CloudOCRUnavailable("云 OCR 没读到任何文字（图太糊？）")
    return [(ln, 0.95) for ln in lines]


def ocr(path, langs=("zh-Hans", "en-US")):
    """平台分发：macOS 用系统 Vision，其他平台用云 OCR（deepkey 文本组的视觉模型）。"""
    if IS_MAC:
        return _ocr_vision(path, langs)
    return _ocr_cloud(path)


def _print_manual_fallback(reason, expect, forbid):
    """A 兜底：云 OCR 不可用时，打印【人工 / agent 核对提示】。退出码由调用方给 0（不是失败）。"""
    print("=" * 56)
    print("⚠️ 本机跳过【自动】标签校验 —— 这【不是】校验失败，也不代表图有问题。")
    print(f"   原因：{reason}")
    print("   （macOS 用系统 Vision；非 macOS 本应走 deepkey 文本组的云 OCR，当前不可用才走到这。）")
    print()
    print("🔴 标签核对这道关不能省 —— 改人工 / 让 AI agent 逐条核对（同样有效）：")
    print("  1. 原图 + AI 生成图并排放大到 200%+；")
    print("  2. 逐字核对下面清单，重点盯：注册类目 / 成分名 / 含量数字 / 认证标（AI 最爱改这四样）；")
    if expect:
        print("     必须原样出现（--expect）：")
        for e in expect:
            print(f"        · {e}")
    if forbid:
        print("     绝不许出现（--forbid）：")
        for f in forbid:
            print(f"        · {f}")
    if not (expect or forbid):
        print("     （没给 --expect/--forbid → 至少人工比对两图所有包装文字）")
    print("  3. 用 Codex / Claude 的：直接 Read 这两张图，按上面清单逐条核对（agent 读图比人眼稳）；")
    print("  4. ⛔ 中文包装禁 AI 重绘，拿不准直接别用生成图。")
    print("=" * 56)


def norm(s):
    """归一化：去空白、统一括号、去掉 OCR 常见噪声，避免误报。"""
    s = s.strip()
    s = s.replace("（", "(").replace("）", ")")
    s = re.sub(r"\s+", "", s)
    return s


def check_expect_forbid(gen_path, expect, forbid, min_conf):
    """硬判据：关键文字必须原样出现；错词一个都不许有。
    OCR 会把字读错，所以用「去掉所有非字母数字汉字后做子串匹配」放宽一点，
    但仍能抓住「力量→耐力」这种真改动。

    🆕 云 OCR【双跑交叉验证】（Bowen 2026-07-31，对文案准确性更保险）：云 OCR 非确定，
       一次可能偶发漏读 → 读两次，**expect 必须两次都在、forbid 任一次检出就算命中、两次不一致=可疑**。
       只有"两次都干净"才 PASS。macOS Vision 确定 → 读一次即可。"""
    runs = 1 if IS_MAC else 2
    blobs, norm_raws = [], []
    for _ in range(runs):
        raw = [t for t, c in ocr(gen_path) if c >= min_conf]
        blobs.append(norm("".join(raw)).upper())
        norm_raws.append([norm(t).upper() for t in raw])

    fails = []
    tag = "（云 OCR 双跑交叉验证）" if runs > 1 else ""
    print("=" * 56)
    print(f"【判据①】原图关键文字是否原样出现在生成图{tag}")
    for e in expect:
        key = norm(e).upper()
        hits = [key in b for b in blobs]
        if all(hits):
            print(f"  ✅ {e}")
        elif any(hits):   # 两次不一致 = 云 OCR 不稳/文案可疑，当成没过
            print(f"  ⚠️ {e}  ← 云 OCR 两次读【不一致】(一次有一次无)，可疑，🔴 必须人工放大确认")
            fails.append(f"云 OCR 两次不一致（可疑改写）: {e}")
        else:
            print(f"  🔴 {e}")
            fails.append(f"关键文字丢失/被改写: {e}")

    if forbid:
        print(f"\n【判据②】是否出现禁止词（AI 篡改的典型痕迹）{tag}")
        # OCR 会把 ENDURANCE 读成 BOUFAVCEAIDSTRENGIH 这种乱码，精确匹配挡不住，
        # 所以再对每一条 OCR 结果做模糊相似度比对。forbid 保守：任一轮命中就算检出。
        for f in forbid:
            key = norm(f).upper()
            hit_runs = [key in b for b in blobs]
            near = None
            if not any(hit_runs):
                for nr in norm_raws:
                    for t in nr:
                        for i in range(max(1, len(t) - len(key) + 1)):
                            if difflib.SequenceMatcher(None, key, t[i:i + len(key)]).ratio() >= 0.6:
                                near = t
                                break
                        if near:
                            break
                    if near:
                        break
            if any(hit_runs):
                where = "两次都" if all(hit_runs) else "某一次"
                print(f"  🔴 {f}  ← 精确检出（{where}）！")
                fails.append(f"出现禁止词: {f}")
            elif near:
                print(f"  🔴 {f}  ← 模糊检出于 OCR「{near}」，须人工放大确认")
                fails.append(f"疑似出现禁止词: {f}（OCR 读作 {near}）")
            else:
                print(f"  ✅ {f}")
    return fails


def compare(src_path, gen_path, min_conf, min_len):
    a = [(t, c) for t, c in ocr(src_path) if c >= min_conf and len(norm(t)) >= min_len]
    b = [(t, c) for t, c in ocr(gen_path) if c >= min_conf and len(norm(t)) >= min_len]
    A = [norm(t) for t, _ in a]
    B = [norm(t) for t, _ in b]
    Bset = set(B)

    print(f"原图 OCR  : {len(A)} 条")
    print(f"生成图 OCR: {len(B)} 条")
    print()

    missing, changed, ok = [], [], []
    for t in A:
        if t in Bset:
            ok.append(t)
            continue
        # 找最接近的一条，判断是"被改写"还是"整条丢失"
        near = difflib.get_close_matches(t, B, n=1, cutoff=0.5)
        if near:
            changed.append((t, near[0]))
        else:
            missing.append(t)

    if ok:
        print(f"✅ 原样保留 {len(ok)} 条")
        for t in ok[:40]:
            print(f"     {t}")
    if changed:
        print(f"\n🔴 疑似被改写 {len(changed)} 条 —— 这是最危险的，必须逐条人工确认：")
        for src, gen in changed:
            print(f"     原图: {src}")
            print(f"     生成: {gen}")
            print()
    if missing:
        print(f"\n⚠️ 原图有、生成图未读到 {len(missing)} 条")
        print("   （可能被改写成 OCR 认不出的乱码，也可能只是 OCR 漏读——必须放大人工确认）")
        for t in missing:
            print(f"     {t}")

    extra = [t for t in B if t not in set(A)]
    if extra:
        print(f"\nℹ️ 生成图多出 {len(extra)} 条（常为 OCR 噪声，仅供参考）")
        for t in extra[:15]:
            print(f"     {t}")

    print("\n" + "=" * 56)
    if changed:
        print("❌ 判定：FAIL —— 检出文字改写，不得使用")
        return 1
    if missing:
        print("⚠️ 判定：需人工复核 —— 有文字未在生成图中读到")
        return 2
    print("✅ 判定：PASS —— 原图全部文字均原样出现在生成图中")
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("source", type=Path, help="原图（真实照片）")
    p.add_argument("generated", type=Path, help="AI 生成图")
    p.add_argument("--expect", default="", help="原图必须原样保留的关键文字，用 | 分隔")
    p.add_argument("--forbid", default="", help="绝不允许出现的错词，用 | 分隔")
    p.add_argument("--min-conf", type=float, default=0.3, help="OCR 置信度下限")
    p.add_argument("--min-len", type=int, default=2, help="忽略过短的碎片")
    args = p.parse_args()

    expect = [s for s in args.expect.split("|") if s.strip()]
    forbid = [s for s in args.forbid.split("|") if s.strip()]

    try:
        fails = []
        if expect or forbid:
            fails = check_expect_forbid(args.generated, expect, forbid, args.min_conf)
            print()

        print("=" * 56)
        print("【判据③】全量 OCR 对比（参考，原图模糊时噪声大）")
        compare(args.source, args.generated, args.min_conf, args.min_len)
    except CloudOCRUnavailable as e:
        # 非 macOS 且云 OCR 跑不了 → 退回人工/agent 核对，退出码 0（不是失败）
        _print_manual_fallback(e, expect, forbid)
        sys.exit(0)

    print("\n" + "=" * 56)
    if fails:
        print("❌ 最终判定：FAIL —— 不得使用")
        for f in fails:
            print("   ·", f)
        _manual_recheck_banner()
        sys.exit(1)
    if expect:
        print("✅ 最终判定：PASS —— 关键文字全部原样保留，无禁止词")
    _manual_recheck_banner()
    sys.exit(0)


def _manual_recheck_banner():
    """🔴 醒目提醒：脚本只是初筛，PASS 也必须人工再核一轮（Bowen 2026-07-31 要求）。"""
    bar = "🔴" * 30
    print("\n" + bar)
    print("🔴  脚本只是【初筛】，不是判官 —— 无论 PASS/FAIL，都【必须】人工再核一轮：")
    print("🔴    1. 逐张放大到 200%+，对照原图【逐字】看：产品包装印的字 / 规格 / 成分 / 含量 有没有变；")
    print("🔴    2. 我方文案（标题 / 卖点 / 认证 / CTA）有没有错位、被产品盖住、或被改；")
    print("🔴    3. 🈶 中文小字乱码风险最高（实测 膳→赡），详情页 1920 偏软更要盯；")
    print("🔴    4. 有一个字不对 → 整张废弃重跑，别将就。")
    print(bar)


if __name__ == "__main__":
    main()
