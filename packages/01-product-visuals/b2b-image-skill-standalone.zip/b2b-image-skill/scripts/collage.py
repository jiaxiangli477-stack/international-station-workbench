#!/usr/bin/env python3
"""产品合集拼图 —— 主图三下方通栏用。

把一批【白底】产品图裁到产品外框、底对齐、等间距铺在白底长条上，
底部留一条空带给白药丸文案（.cap 会叠在图内底部，别让产品下沿被挡）。

用法:
  python collage.py <产品图目录> -o <输出.png> [--pick 0 4 7 ...] [--h 512 --w 1812]
  # 不给 --pick 就按文件名排序全用；给了就只用这些序号（先跑一次看打印的清单定序号）
  # 选图原则：~7 款，把【格式】(袋/罐/盒/瓶/滴管/条) 和【配色】都拉开

设计要点（改过就照 references/main-images.md §5 复核）:
  - 画布贴合下方画框比例（≈906×256，约 3.5:1 → 默认 1812×512）
  - 产品底线 BASELINE 抬到给底部留 ~128px 空带，白药丸压上去不挡产品下沿
  - 白底产品图直接贴白底画布无缝，不必抠透明；floodfill 仅用来求产品外框
"""
import argparse, glob, os
from PIL import Image, ImageDraw

MAGENTA = (255, 0, 255)


def tight_crop(path, pad=8, thresh=22):
    """展平到白底 → 四角 floodfill 吃近白 → 按非白区域紧裁。返回白底紧裁图。"""
    im = Image.open(path).convert("RGBA")
    white = Image.new("RGBA", im.size, (255, 255, 255, 255))
    white.alpha_composite(im)
    rgb = white.convert("RGB")
    probe = rgb.copy()
    w, h = probe.size
    for xy in [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)]:
        ImageDraw.floodfill(probe, xy, MAGENTA, thresh=thresh)
    px = probe.load()
    minx, miny, maxx, maxy = w, h, 0, 0
    for y in range(0, h, 2):
        for x in range(0, w, 2):
            if px[x, y] != MAGENTA:
                minx, maxx = min(minx, x), max(maxx, x)
                miny, maxy = min(miny, y), max(maxy, y)
    if maxx <= minx:                       # 整张都判成背景（非白底图？）→ 原图返回
        return rgb
    box = (max(0, minx - pad), max(0, miny - pad), min(w, maxx + pad), min(h, maxy + pad))
    return rgb.crop(box)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src_dir", help="产品图目录（*.png，白底）")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--pick", type=int, nargs="*", help="只用这些序号（按文件名排序）")
    ap.add_argument("--w", type=int, default=1812)
    ap.add_argument("--h", type=int, default=512)
    ap.add_argument("--baseline", type=int, default=384, help="产品底线 y；下方留白给文案药丸")
    ap.add_argument("--top", type=int, default=26)
    ap.add_argument("--margin", type=int, default=44)
    ap.add_argument("--gap", type=int, default=26)
    a = ap.parse_args()

    files = sorted(glob.glob(os.path.join(a.src_dir, "*.png")))
    for i, f in enumerate(files):
        print(f"  [{i}] {os.path.basename(f)}")
    idx = a.pick if a.pick else list(range(len(files)))
    crops = [tight_crop(files[i]) for i in idx]

    maxh = a.baseline - a.top
    avail = a.w - 2 * a.margin - a.gap * (len(crops) - 1)
    widths = [round(c.width * (maxh / c.height)) for c in crops]
    H = maxh
    if sum(widths) > avail:                # 超宽就统一降高
        H = int(maxh * avail / sum(widths))
        widths = [round(c.width * (H / c.height)) for c in crops]
    scaled = [c.resize((widths[i], round(c.height * (H / c.height))), Image.LANCZOS)
              for i, c in enumerate(crops)]

    canvas = Image.new("RGB", (a.w, a.h), (255, 255, 255))
    x = a.margin + (avail - sum(widths)) // 2
    for im in scaled:
        canvas.paste(im, (x, a.baseline - im.height))
        x += im.width + a.gap
    canvas.save(a.out)
    print(f"✅ {a.out}  {canvas.size}  产品H@1x≈{H // 2}  用了 {len(scaled)} 款")


if __name__ == "__main__":
    main()
