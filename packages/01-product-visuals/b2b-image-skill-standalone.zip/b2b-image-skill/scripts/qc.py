#!/usr/bin/env python3
"""出图 QC：量一张主图的色彩配比，并给出可执行的判断。

为什么必须跑它，而不是"看一眼觉得还行"：
  · 有一次 CSS 注释没闭合，把整条 .scene 规则吃掉了 —— 产品色载体根本没渲染出来。
    肉眼看着"还行"，是配比数字（产品色不升反降）露的馅。
  · 有一次把车间照换上去，视觉上明显更好，但蓝占比从 51.6% 冲到 79.5%，
    整条缩略图带更疲劳了 —— 这是眼睛看单张时发现不了的。

🆕 第二档【品牌色保真 I-84】：上面那五个是【蓝占多少】，这一档是【蓝还是不是那个蓝】。
  I-72 之前，"背景一个像素不许改"这条铁律的执行者是 HTML/CSS 本身（hex 写死、物理上改不了）；
  I-72 把整张画布交给 AI 重绘之后执行者没了 —— 这一档是接手的那个。
  ⛔ 它是告警级，永远不接退出码。

⚠️ 但也别反过来迷信数字。指标是代理量，不是真相：
  · 一张"蓝色车间照片"和"一块纯蓝色板"在这里都算蓝，可眼睛不会这么读——
    照片有人脸、景深、纹理，是缓解疲劳的；色板不是。
  · 所以 QC 数字用来抓【异常】（某项突然掉了/爆了），不用来当美学裁判。
    出图后永远还要 Read 一眼真图。

用法:
    python3 qc.py 主图1.png [主图2.png ...]
    python3 qc.py 详情.png --role detail
    python3 qc.py *.png --json      # 机器可读
"""
import argparse, colorsys, json, statistics, sys

from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （必须 import：修 Windows 管道输出下 emoji 崩溃）

try:
    from PIL import Image
except ImportError:
    sys.exit("需要 Pillow：pip install pillow")

# 目标来自视觉模板系统 Part 1.5 规则5
TARGET = {"blue": 50, "neutral": 35, "product": 15, "lime": 5}

# ── I-84 品牌色保真 ────────────────────────────────────────────────────────
# 为什么要单开这一档：上面那五个配比数字量的是【蓝占多少】，量不出【蓝是不是那个蓝】。
# 实测四个样本色相全是 215.x —— 品牌 #1E6FE6(30,111,230)=215.7 · m7 对照(43,119,231)=215.7
# · m2(28,106,215)=215.0 · **漂了的 m1(7,81,186)=215.2** ⇒ 漂移 100% 落在明度上，
# 色相一动不动，所以「190≤色相≤250 且饱和>25」这一口径在设计上就看不见它。
#
# 🔴 这条铁律原来的执行者是 HTML/CSS 本身（_brand.css 把 hex 写死，物理上改不了）。
#    I-72 默认路径把整张画布交给 AI 重绘之后执行者没了，而没有任何东西接手 —— 这一档就是接手的。
# ⛔ 告警级，永不接退出码：假报会把人训练成无视告警，比不报更糟。
BRAND_BLUE = (30, 111, 230)   # --blue   #1E6FE6
BRAND_LIME = (204, 255, 0)    # --lime   #CCFF00
# 详情页底色按 _detail.css 轮转（.m-blue / .m-white / .m-lt），三种都是合法底，取最近的一个比。
DETAIL_BGS = [("宝蓝底 .m-blue", BRAND_BLUE), ("白底 .m-white", (255, 255, 255)),
              ("浅蓝底 .m-lt", (230, 241, 251))]

# 阈值怎么标定出来的（拿 2026-08-17 六图 + 四张纯 HTML 底图跑出来的，⛔ 别凭感觉调）：
#   背景 Δ 的物理下限是 15.3 而不是 0 —— `.bg-diagonal::after` 那层 6% 白蒙版把 #1E6FE6
#   抬成 30*.94+255*.06=(43.5,119.6,231.5) ⇒ 渲成 (43,119,231)，Δ 恰好 15.3。
#   实测：纯 HTML 底图 m7_base/d1_base=15.3、d2_base=0.0、d3_base=0.0（=零假报）；
#         AI 守住的 m2=15.9、d2=1.7、d3=1.0；AI 漂了的 **m1=61.0、d1=43.3**。
#   16 与 43 之间是空的 ⇒ 阈值取 30（≈ 基准的 2 倍，两边各留 14 分余量）。
BG_WARN = 30
#   亮绿：纯 HTML 一律精确命中 Δ0.0；AI 最差 d3=19.0、m2=9.8 ⇒ 阈值 40。
LIME_WARN = 40
#   样本太少时数字没意义（d2 整块只有一条 78×5 的亮绿短横，采到 12 个点，
#   中位色被抗锯齿边拉成 (112,182,34) ⇒ 报 Δ122 是纯假报）。低于这个数只报「样本不足」。
LIME_MIN_N = 200
QUANT = 6          # 分桶粒度：1 会被渐变噪声打散（m1 最大桶只剩 8%），6 起 m1 能聚到 14%


def _dist(a, b) -> float:
    return ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2) ** 0.5


def _dominant(pix: list):
    """按 QUANT 粒度分桶，返回【最大桶的中位色】+ 它占样本的比例。

    为什么不是直接取全体中位色：m7 是「宝蓝底 + 深藏蓝面板」，全体中位色落在藏蓝上（Δ147），
    量的其实是另一块合法品牌色。取最大桶 = 取那块真正的背景场。
    """
    if not pix:
        return None, 0.0
    buckets = defaultdict(list)
    for c in pix:
        buckets[(c[0] // QUANT, c[1] // QUANT, c[2] // QUANT)].append(c)
    best = max(buckets.values(), key=len)
    med = tuple(round(statistics.median(c[i] for c in best)) for i in range(3))
    return med, len(best) / len(pix)


def audit(path: Path, step: int = 2) -> dict:
    im = Image.open(path).convert("RGB")
    w, h = im.size
    px = im.load()
    c = {"blue": 0, "neutral": 0, "product": 0, "lime": 0, "other": 0}
    tot = 0
    # 背景带 = 外圈 3% 边框。⚠️ 取样必须避开产品/文字/照片区，而这三样在所有模板里都在画面【内部】，
    #    外圈是唯一稳定干净的背景带。
    marg = max(4, round(min(w, h) * 0.03))
    ring, lime_px = [], []
    for y in range(0, h, step):
        for x in range(0, w, step):
            r, g, b = px[x, y]
            tot += 1
            if x < marg or x >= w - marg or y < marg or y >= h - marg:
                ring.append((r, g, b))
            hh, ll, ss = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
            hh *= 360; ss *= 100; ll *= 100
            if ss < 12 and ll > 82:
                c["neutral"] += 1                      # 白/留白
            elif 190 <= hh <= 250 and ss > 25:
                c["blue"] += 1                         # 骨架蓝（含深蓝斜切、袋身蓝）
            elif 60 <= hh <= 95 and ss > 60 and ll > 40:
                c["lime"] += 1                         # 荧光绿 CTA
                # ⚠️ 亮绿取样要排除橙黄产品干扰：芒果/柑橘的高光会蹭进 60–95 这段色相，
                #    第一次标定就踩过（中位色被拉成 (245,198,37)）。#CCFF00 的 g−r=+51，
                #    所以判据要求【绿压过红】—— 橙黄是 r≥g，一刀就切干净。
                if g - r >= 25:
                    lime_px.append((r, g, b))
            elif (hh < 60 or hh > 320) and ss > 30:
                c["product"] += 1                      # 产品色（橙/黄/红系）
            else:
                c["other"] += 1                        # 中间调/照片
    bg, bg_share = _dominant(ring)
    lime, _ = _dominant(lime_px)
    return {k: round(v / tot * 100, 1) for k, v in c.items()} | {
        "size": f"{w}×{h}", "bg_rgb": bg, "bg_share": round(bg_share * 100, 1),
        "lime_rgb": lime, "lime_n": len(lime_px)}


def brand_fidelity(r: dict, role: str) -> tuple:
    """返回 (报告行 list, 告警行 list)。⛔ 告警级 —— 调用方不许把它接进退出码。"""
    lines, warns = [], []
    bg = r.get("bg_rgb")
    if bg:
        if role == "detail":
            name, ref = min(DETAIL_BGS, key=lambda t: _dist(bg, t[1]))
        else:
            name, ref = "宝蓝底 --blue", BRAND_BLUE   # 主图背景永远是它（_brand.css / main-images.md §0）
        dd = _dist(bg, ref)
        # 基准不是 0：宝蓝底带 .bg-diagonal 那层 6% 白蒙版，纯 HTML 的物理下限就是 15.3；
        # 白底/浅蓝底没有蒙版，纯 HTML 实测精确命中 0.0。
        base = 15.3 if ref == BRAND_BLUE else 0.0
        flag = "🔴" if dd > BG_WARN else ("·" if dd > 20 else "✅")
        lines.append(f"  {flag} 背景 rgb{bg}（占背景带 {r['bg_share']}%） vs {name} → Δ{dd:.1f}"
                     f"（基准 {base} / 阈值 {BG_WARN}）")
        if dd > BG_WARN:
            warns.append(f"🔴 品牌色漂移：背景 rgb{bg} 离 {name} Δ{dd:.1f}，超阈值 {BG_WARN}"
                         "（纯 HTML 底图的物理下限是 15.3）。"
                         "⛔ 色相是对的、漂的是明度 —— 配比那五个数字看不见它，别拿「蓝占比正常」当过关。"
                         "根因是 I-72 把整张画布交给 AI 重绘；真正的解是让这块背景走 composite/HTML 渲染"
                         "（色号写死在 _brand.css 里，物理上改不了），而不是重掷。")
    lime = r.get("lime_rgb")
    if r["lime_n"] < LIME_MIN_N:
        lines.append(f"  · 亮绿样本不足（{r['lime_n']} < {LIME_MIN_N} 个采样点）—— 不判，数字没意义")
    elif lime:
        dl = _dist(lime, BRAND_LIME)
        flag = "🔴" if dl > LIME_WARN else ("·" if dl > 20 else "✅")
        lines.append(f"  {flag} 亮绿 rgb{lime}（{r['lime_n']} 点） vs --lime #CCFF00 → Δ{dl:.1f}"
                     f"（基准 0.0 / 阈值 {LIME_WARN}）")
        if dl > LIME_WARN:
            warns.append(f"🔴 品牌色漂移：亮绿 rgb{lime} 离 #CCFF00 Δ{dl:.1f}，超阈值 {LIME_WARN}"
                         "（纯 HTML 渲的亮绿实测精确命中 Δ0.0，漂了就是 AI 重绘过）")
    return lines, warns


# 猜「无产品的纯模板/实拍位」用的文件名关键词。
# ⛔ 别把光秃秃的 "supplement" 加进来：产品文件名里太常见（m1-supplement-scene.png 这种），
#    加了会把**主角图**误判成 template，等于把"产品色偏低"那道闸门对它关掉（假阴比假警更隐蔽）。
#    所以只认 m7 本身和 supplement-facts 这类**复合词**。
TEMPLATE_HINTS = ("m4", "m5", "m6", "m7", "cert", "认证", "factory", "工厂", "process", "流程",
                  "facts", "supplement-facts", "supplement_facts", "supplement facts",
                  "nutrition-facts", "成分表", "营养成分")


# 详情页模块前缀（d1–d9 + 4 个附加件）。
# ⛔ 别把它们落进 scene 的兜底分支：详情页跑 scene 口径【必红两条】，而把纯 HTML 底图
#    （零 AI）跑一遍同样两条红、而且更红 ⇒ 这四个配比数字对详情页零信息量。
#    更糟的是它给的整改建议（加水果+水花/冲泡杯）对 d2/d3 是文档【明令禁止】的动作
#    （detail-page.md：d3 产品色 ⛔ 不做加法）—— 照着做就是照着错的做。
DETAIL_HINTS = tuple(f"d{i}" for i in range(1, 10)) + ("df", "dfac", "dc", "drev")


def guess_role(name: str) -> str:
    """按文件名猜角色。猜错不致命，可用 --role 覆盖。"""
    n = name.lower()
    stem = Path(n).stem
    if stem.startswith(DETAIL_HINTS):
        return "detail"       # 详情页模块（宽 750，配比目标另算）
    if any(k in n for k in TEMPLATE_HINTS):
        return "template"     # 纯模板/实拍位，本来就没有产品
    if any(k in n for k in ("m3", "brand", "定制")):
        return "lineup"       # 多产品并排，产品色由包装本身决定
    return "scene"            # 有产品色载体（水果/冲泡杯）的主角图


def verdict(r: dict, role: str, name_is_m2: bool = False) -> list:
    """只报会真正害人的问题，不当美学裁判。

    产品色这条【只对 scene 角色有意义】：
      · m4 认证墙 / m5 工厂 / m6 流程 本来就没有产品 —— 报"产品色偏低"是假警。
      · m7 营养成分表（2026-08-09 新增）整张就是【深蓝底 + 反白表格】，卖的是配方能力不是"这瓶货"，
        构图里根本不放产品 —— 不归到 template 就是**每跑一次假警一次**（新增模块最容易漏这一步：
        guess_role 只认 m4/m5/m6 时，m7 会落进 scene 的兜底分支）。
      · m3 多产品并排的产品色由包装实物决定（深蓝罐+白袋+橙盒实测就 3–5%），
        硬塞水果只会让产品挤成一团，还违反"素材禁跨图复用"。
    假警会训练人忽略警告，比不报更糟，所以按角色分开判。
    """
    out = []
    if role == "detail":
        # 详情页只走品牌色保真那一档。50/35/15/5 是【主图】配比目标，对详情页零信息量：
        # 拿纯 HTML 底图（零 AI）跑主图口径，d1_base 亮绿 5.5%、产品色 2.0%，两条都红且比成品更红。
        return out
    if r["lime"] > TARGET["lime"]:
        out.append(f"🔴 荧光绿 {r['lime']}% > 5% —— 亮绿只能做 CTA/高亮，超了会稀释行动点")
    if role == "scene" and r["product"] < 6:
        out.append(f"🔴 产品色 {r['product']}% 偏低 —— 这张图应该有产品色载体（水果+水花/冲泡杯）。"
                   "先确认它真的渲染出来了：CSS 规则被静默吃掉时就是这个症状（实测踩过，"
                   "注释没闭合导致整条规则失效）。另注意：放大白袋子不产生产品色，白袋子七成是白的。"
                   + (" ⚠️ 但这张是 m2：`m2-pain-hook.html` 根本没有 IMG_SCENE 槽"
                      "（实测 m1 有 1 个、m2 是 0）—— 这条对 m2 是【结构性误报】，"
                      "⛔ 别为了把数字做上去给 m2 加水果/冲泡杯，那是改模板不是改图。" if name_is_m2 else ""))
    if r["blue"] > 78:
        out.append(f"🟡 蓝 {r['blue']}% 过高 —— 整条缩略图带会读成一片蓝。"
                   "⛔ 主图背景不能改（老板模板锁死）。可动的是：产品色载体/产品放大/换素材/版式轮换。")
    if role == "scene" and r["neutral"] < 8:
        out.append(f"🟡 留白 {r['neutral']}% 极低 —— 画面可能过满")
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("images", nargs="+")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--role", choices=["scene", "lineup", "template", "detail"], default=None,
                    help="scene=有产品色载体的主角图(m1) · lineup=多产品并排(m3) · "
                         "template=无产品的纯模板/实拍位(m4/m5/m6/m7) · "
                         "detail=详情页模块(d1–d9/df/dfac/dc/drev，只判品牌色保真，"
                         "50/35/15/5 是主图口径不适用)。不给则按文件名猜。")
    a = ap.parse_args()

    results = {}
    for f in a.images:
        p = Path(f)
        if not p.exists():
            print(f"跳过（不存在）: {f}", file=sys.stderr)
            continue
        r = audit(p) | {"role": a.role or guess_role(p.name)}
        r["bg_delta"] = round(min(_dist(r["bg_rgb"], ref) for _, ref in (
            DETAIL_BGS if r["role"] == "detail" else [("", BRAND_BLUE)])), 1) if r["bg_rgb"] else None
        r["lime_delta"] = (round(_dist(r["lime_rgb"], BRAND_LIME), 1)
                           if r["lime_rgb"] and r["lime_n"] >= LIME_MIN_N else None)
        results[p.name] = r

    if a.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return

    print(f"{'图':<28}{'角色':<9}{'蓝':>7}{'留白':>8}{'产品色':>8}{'亮绿':>7}{'其他':>7}")
    print(f"{'目标':<28}{'':<9}{'≈50':>7}{'≈35':>8}{'≈15':>8}{'<5':>7}{'—':>7}")
    print("─" * 78)
    for name, r in results.items():
        print(f"{name[:27]:<28}{r['role']:<9}{r['blue']:>6.1f}%{r['neutral']:>7.1f}%"
              f"{r['product']:>7.1f}%{r['lime']:>6.1f}%{r['other']:>6.1f}%")
    print("\n品牌色保真（I-84）—— ⛔ 告警级，不接退出码；量的是【蓝是不是那个蓝】，"
          "上面五个配比数字量的只是【蓝占多少】")
    for name, r in results.items():
        lines, _ = brand_fidelity(r, r["role"])
        print(f"{name}")
        for ln in lines:
            print(ln)

    for name, r in results.items():
        vs = verdict(r, r["role"], name_is_m2="m2" in name.lower())
        vs += brand_fidelity(r, r["role"])[1]
        for v in vs:
            print(f"\n{name}\n  {v}")
    # 「整套蓝占比跨度」讲的是【主图缩略图带】连排会不会疲劳，详情页是竖着往下滚的，不适用。
    blues = [r["blue"] for r in results.values() if r["role"] != "detail"]
    if len(blues) > 1:
        print(f"\n整套蓝占比跨度 {min(blues):.1f}% – {max(blues):.1f}%"
              f"（跨度 {max(blues)-min(blues):.1f} 个点）")
        if max(blues) - min(blues) < 15:
            print("  🟡 跨度偏窄 —— 各图色调过于接近，连排会疲劳。"
                  "看 references/main-images.md 的「版式轮换/照片主导」两条杠杆。")


if __name__ == "__main__":
    main()
