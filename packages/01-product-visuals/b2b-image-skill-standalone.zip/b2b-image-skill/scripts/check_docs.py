#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_docs.py —— 文档一致性检查（纯本地 · 零依赖 · 零成本 · 秒级）

跑法：
    python scripts/check_docs.py                 # 五项全查
    python scripts/check_docs.py --links         # 只查断链
    python scripts/check_docs.py --commands      # 只查出图命令
    python scripts/check_docs.py --specs         # 只查说明字段口径（.json 里 _ 开头键的说明文字）
    python scripts/check_docs.py --counts        # 只查详情页块数口径
    python scripts/check_docs.py --linerefs      # 只查行号式引用
    python scripts/check_docs.py --selftest      # 自检（正反例都造，确认该报的报了、不该报的没报）

退出码：0 = 干净 ｜ 1 = 有问题 ｜ 2 = 没跑成（⛔ 绝不当通过）

────────────────────────────────────────────────────────────────
它查五件事，都是"文档写了但没人保证它成立"那一类：

【① 断链】(V2-27) —— 文档里指向 skill 内部的路径，文件/目录是不是真的存在。
   只查**声称在 skill 里**的路径（首段是 assets/ references/ scripts/ library/），
   ⛔ 不查 build/ out/ png/ work/ 这些运行时才产生的目录，也不查外部路径和 URL。
   为什么只查这一类：精度。断链的真实病例（`new-product.md` 指 `assets/detail/…`
   那个整个不存在的目录）全都在这个形状里，而运行时路径查了只会刷屏假警。

【② 出图命令】(V2-35②) —— 🔴 这条是防复发闸门，不是整洁项。
   同一个病已经复发 3 次：**改了顶部原则声明就当改完了，而能被复制粘贴执行的
   命令还是旧路径**（国内 v2.10 → V2-26 → 2026-08-07 的「默认路径根本没被走到」）。
   判据（整改方案 §0.6 那把尺）：**声明写在哪不重要，能被执行的命令写的是什么才算数。**

   所以这里只认"看着就能跑"的行：带 `python` / `bash` 且提到 render.py /
   render_detail.sh|bat。这类行必须带 ⚙️备选标记，否则报警。
   ⛔ 描述性的提及（脚本表里那一行「render.py | HTML → 精确尺寸 PNG」）不算命令，不管。

   .py 也扫，但**只扫 print 出来的**（运行时提示比文档危害更大：每出一张图就教
   agent 一次旧路径）。脚本内部 subprocess 调 render.py 是实现，不在此列。

【③ 说明字段口径】(I-43⒜⒝) —— ② 只认【带 python/bash 的可执行行】，
   于是一整类**描述句**一条都没被逮到，而 agent 出图时照抄的恰恰是它们：
     · `build.py` 顶部 docstring 曾写「…供 render.py 出图」
     · `product.example.json` 的 `_说明` 曾写「填完跑 build.py → render.py → qc.py」
   🔴 example.json 的 `_` 注释键是**事实上的操作手册**，比 SKILL.md 影响更直接。
   扫描面 = **只有** `.json` 里键名以 `_` 开头的字符串值。
   ⛔ **别把 `.py` 的模块 docstring 加回来**：第一版加了，实测 6 条命中里 5 条是假报
   （脚本 docstring 提 render.py 基本都在说【依赖/实现】）。详见 `check_specs` 的 docstring。

【④ 详情页块数口径】(I-43⒝) —— 数字会过期，而过期的数字长得和对的一模一样。
   真值不写死在本文件里，**从 `build.py` 的 `DETAIL_FULL` / `TEMPLATE_FILES` 现算**，
   算出来对不上就自己先喊（⛔ 免得这条闸门自己变成下一个过期常量）。
   病例：`detail.example.json` 曾写「9 模块」并给出 `--only d1..d9`
   （正是 `detail-page.md` ⛔ 明令禁止那条，会让 df/dfac/dc/drev 静默不出）。
   🔴 判据只认【「9 模块」+ 已作废的 d1..d9 序列】这两样。⛔ 别加「N 张图」「N 块」那类泛化判据
   —— 第一版加了，实测 7 条命中里 6 条是假报（理由写在 `_DEAD_ONLY_RE` 上方）。

【⑤ 行号式引用】(I-69) —— `文件:行号` / 「某文件 第 N 行」一律不许再写。
   国内立此规时实测：24+7 条里 **7 条（29%）本来就已指错**，最险的两条被当作
   "脚本纪律的出处"而目标行早已变成空行。本站同样逮到活的：三处「`detail-page.md`
   第 57 行」指的其实是**尺寸表里 d2 那一行**。
   🔴 判据刻意收窄，避免误伤**同页表格的第 N 行**这类正当说法：
     · `文件.ext:数字` —— 无歧义，一律报。
     · 「第 N 行」—— 只有文件名 /「本文」/「本文件」**紧挨在它前面**才报
       （⛔ 不是"同一行里出现过"就算 —— 那版实测 2 条命中全是假报，见 `_CN_LINEREF_RE`）。
       于是「主线表第 1 行」「日志第 18 行」这些正当用法不会被误伤。
   真的需要保留某处，在同一行写 `check_docs: 行号ok` 放行（⛔ 别滥用）。
"""
from __future__ import annotations

import argparse
import ast
import json
import re
import sys
import tempfile
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent

# ── 扫描范围 ────────────────────────────────────────────────────────────────
# CHANGELOG 是历史存档：里面的旧命令是"当时确实这么写的"，改了反而失真。
SKIP_DIRS = {"_archive", "__pycache__", ".git", "build", "out", "png", "node_modules"}
SKIP_FILES = {"CHANGELOG.md"}

# ── ① 断链 ─────────────────────────────────────────────────────────────────
# 只认首段是这几个的路径 = 声称"我在 skill 包里"。别的一律不管（见模块头注释）。
INTERNAL_ROOTS = ("assets/", "references/", "scripts/", "library/")

# 从 markdown 里捞候选路径：`反引号包住的` + [markdown](链接) + 裸路径
_TOKEN_RE = re.compile(r"`([^`\n]+)`|\]\(([^)\s]+)\)|(?<![\w/`(])((?:assets|references|scripts|library)/[^\s`)\]，。；：、|>*]+)")
# 占位符 / 通配 / 外链：出现这些字符就不是一条确定的路径，跳过
_PLACEHOLDER = set("<>{}*?…|$ ")


def _iter_docs(root: Path, suffixes=(".md",), skip_files=SKIP_FILES):
    for p in sorted(root.rglob("*")):
        if p.suffix not in suffixes or not p.is_file():
            continue
        if p.name in skip_files:
            continue
        if any(part in SKIP_DIRS for part in p.relative_to(root).parts):
            continue
        yield p


def _candidates(line: str):
    for m in _TOKEN_RE.finditer(line):
        raw = m.group(1) or m.group(2) or m.group(3) or ""
        raw = raw.strip()
        if not raw or raw.startswith(("http", "mailto:", "#")):
            continue
        # 反引号里常包着一整条命令 —— 把里面的内部路径再捞一层
        if m.group(1) and " " in raw:
            for tok in raw.split():
                if tok.startswith(INTERNAL_ROOTS) and not (_PLACEHOLDER & set(tok)):
                    yield tok.strip("\"'（）()，。、")
            continue
        if _PLACEHOLDER & set(raw):
            continue
        raw = raw.lstrip("./")
        if raw.startswith(INTERNAL_ROOTS):
            yield raw.rstrip("，。、；：)")


def _exists(rel: str) -> bool:
    """能落到 skill 里任一合法位置就算活的。library/ 是 assets/library/ 的惯用简写。"""
    cands = [SKILL / rel]
    if rel.startswith("library/"):
        cands.append(SKILL / "assets" / rel)
    return any(c.exists() for c in cands)


def check_links(root: Path) -> list:
    bad = []
    for doc in _iter_docs(root):
        for i, line in enumerate(doc.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            for rel in _candidates(line):
                if not _exists(rel):
                    bad.append((doc.relative_to(root), i, rel))
    return bad


# ── ② 出图命令 ─────────────────────────────────────────────────────────────
# 旧路径的三个入口。render_v2.py 里含 "render_v2" 要先排除掉，别把默认路径自己报了。
_LEGACY_RE = re.compile(r"(?<!_v2/)(?<!_)\brender\.py\b|\brender_detail\.(?:sh|bat)\b")
# "看着就能跑" = 带解释器/shell 前缀。没有它的就是描述，不是命令。
# ⛔ 别把 `sh` 放进来：`\bsh\b` 会匹配 `render_detail.sh` 的扩展名本身，
#    于是每一处【提到】这个文件的描述行都被当成命令 —— 实测误报 3 处。
_RUNNABLE_RE = re.compile(r"\b(?:python3?|bash)\b")
# 同一行里明说"别跑它" = 这是禁令不是命令，放行（禁令正是我们要的口径）
_NEGATIONS = ("⛔", "别跑", "不是自己跑", "不要跑")
# 带上这些字样 = 已经明说它是备选/补渲工具 → 放行
_MARKERS = ("⚙️", "备选", "补渲", "纯渲染", "check_docs: ok")
# 往前看几行找标记（⚙️备选 的小标题常在代码块上方）
_LOOKBACK = 5
_LOOKAHEAD = 1


def _marked(lines: list, idx: int) -> bool:
    lo = max(0, idx - _LOOKBACK)
    hi = min(len(lines), idx + 1 + _LOOKAHEAD)
    return any(any(mk in lines[j] for mk in _MARKERS) for j in range(lo, hi))


# 🔴 skill 包**外面**、但必须一起管的文件：项目根 `AGENTS.md` 是同事 Codex 的必读件。
#    独立回检实测：本批把 skill 内的旧路径全清干净之后，`AGENTS.md` 仍写着
#    「`render.py` 出图 → `qc.py` 查配比」—— 而 `--root` 默认 = skill 根 ⇒ 这道闸门
#    **结构性永远扫不到它**。这正是 memory 里「同事 Codex 绕过脚本」那类事故的文本源头。
# ⛔ 别改成"把 `--root` 指到项目根" —— 实测那样会扫进旧 worktree / 镜像仓 / `.claude 2`
#    这些副本，一次 40+ 条命中，绝大多数是垃圾目录 ⇒ 又是一道没人看的告警。
#    这里只点名**确定要管的那一个文件**。
def _extra_docs() -> list:
    try:
        p = SKILL.parents[2] / "AGENTS.md"
    except IndexError:
        return []
    return [p] if p.is_file() else []


def check_commands(root: Path) -> list:
    bad = []
    extra = _extra_docs() if root == SKILL else []
    for doc in list(_iter_docs(root, suffixes=(".md", ".py"))) + extra:
        if doc.name == Path(__file__).name:      # 别把本文件的说明当违规
            continue
        lines = doc.read_text(encoding="utf-8", errors="replace").splitlines()
        for i, line in enumerate(lines):
            if not (_LEGACY_RE.search(line) and _RUNNABLE_RE.search(line)):
                continue
            # .py 只管打印出来的（运行时提示），内部 subprocess 调用是实现细节
            if doc.suffix == ".py" and "print(" not in line:
                continue
            if any(neg in line for neg in _NEGATIONS):
                continue
            if _marked(lines, i):
                continue
            # `_extra_docs()` 的那份在 root 外面 ⇒ relative_to 会抛，退回打绝对路径
            try:
                shown = doc.relative_to(root)
            except ValueError:
                shown = doc
            bad.append((shown, i + 1, line.strip()[:110]))
    return bad


# ── ③ 说明字段口径 ─────────────────────────────────────────────────────────
# 取的是"给人看的字段"：`.json` 里 `_` 开头键的字符串值（本库的注释键约定）。
# `_spec_texts` 保留了 `.py` 分支供将来复用，但 `check_specs` **只调 `.json`**（理由见其 docstring）。
def _spec_texts(doc: Path):
    """产出 (定位串, 文本行)。定位串刻意用【键路径 / 字段名】而不是行号（见 ⑤ 的规约）。"""
    try:
        src = doc.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return
    if doc.suffix == ".py":
        try:
            ds = ast.get_docstring(ast.parse(src))
        except SyntaxError:
            return
        for line in (ds or "").splitlines():
            yield "模块 docstring", line
        return

    try:
        obj = json.loads(src)
    except (json.JSONDecodeError, ValueError):
        return

    def walk(node, path, under_comment):
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, f"{path}.{k}" if path else str(k),
                     under_comment or str(k).startswith("_"))
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]", under_comment)
        elif isinstance(node, str) and under_comment:
            for line in node.splitlines():
                yield_buf.append((path, line))

    yield_buf = []
    walk(obj, "", False)
    for item in yield_buf:
        yield item


def check_specs(root: Path) -> list:
    """🔴 只扫 `.json` 的 `_` 注释键 —— ⛔ 别再把 `.py` 模块 docstring 加回来。

    第一版扫了 `.py` docstring，实测 **6 条命中里 5 条是假报**：脚本 docstring 里提
    `render.py` 绝大多数是在说【依赖/实现】而不是在把它当默认路径推销 ——
    `check_layout`「复用 render.py 那套 Chrome」、`check_scene_text`「依赖：Pillow + 本目录的
    render.py」、`render_v2`「① render.py 渲底图」全是正当描述，机器分不出来。
    83% 假报接进闸门 = 人被训练成无视告警，正是本轮整改要根治的病。
    而 I-43 的真实病灶本来就在 `.json`：**agent 出图时照抄的是 example.json**。
    """
    bad = []
    for doc in _iter_docs(root, suffixes=(".json",)):
        for where, line in _spec_texts(doc):
            if not _LEGACY_RE.search(line):
                continue
            if any(neg in line for neg in _NEGATIONS) or any(mk in line for mk in _MARKERS):
                continue
            bad.append((doc.relative_to(root), where, line.strip()[:110]))
    return bad


# ── ④ 详情页块数口径 ──────────────────────────────────────────────────────
# 真值从 build.py 现算，⛔ 别在本文件里写死（免得这条闸门自己变成下一个过期常量）。
def _build_truth() -> dict:
    src = (SKILL / "scripts" / "build.py").read_text(encoding="utf-8", errors="replace")
    detail_full, tpl = None, None
    for node in ast.parse(src).body:
        if not isinstance(node, ast.Assign):
            continue
        names = [t.id for t in node.targets if isinstance(t, ast.Name)]
        if "DETAIL_FULL" in names:
            detail_full = ast.literal_eval(node.value)
        elif "TEMPLATE_FILES" in names:
            tpl = ast.literal_eval(node.value)
    if detail_full is None or tpl is None:
        raise RuntimeError("build.py 里读不到 DETAIL_FULL / TEMPLATE_FILES —— 常量改名了？")
    n_main = len([k for k in tpl if k.startswith("m")])
    return {"detail": len(detail_full), "main": n_main, "total": len(detail_full) + n_main,
            "seq": detail_full}


# 同一行里出现这些 = 正在【否定/警告】这个旧数字，放行（`⛔ 别再按「9 模块」出图` 正是我们要的口径）
_COUNT_OK = ("⛔", "别再", "不是 9", "不是9", "老坑", "根因", "老的", "还在跑", "check_docs: ok")
_DEAD_ONLY_RE = re.compile(r"--only\s+d1(?:\s+d\d\b){3,}|\bd1\s*(?:\.\.|…|~|～)\s*d9\b")

# 🔴 ⛔ 别再加「N 张图」「N 块」这类泛化判据 —— 第一版加了，实测 **7 条命中里 6 条是假报**：
#    「10 款 ≠ 90 张图」「5 张图的页脚位」「用到它的 5 张图已重跑」「其余 9 块通用件只渲底图」
#    （最后一条还是**算对的**：d1/d2/d3 换产品 + 其余 9 块 = 12）。
#    「张图 / 块」在中文里就是通用量词，不带上下文根本判不出对错。
#    ⇒ 只留【无歧义】的那条：已作废的 `--only d1..d9` 序列。
#    check_env.py 那句「等出完 21 张图」（国内 8+13 口径污染）确实是真病，但它是**孤例**，
#    直接改掉即可，⛔ 不值得为它养一条 86% 假报的规则。


# ⛔ 判据刻意只盯【已作废的「9 模块」这个说法】，不写成"凡是 != 12 就报"：
#    「核心 **8** 块 + **4** 附加件」是正当说法，一刀切会把它一起误伤。
# ⛔ 也刻意**不认裸「9 块」** —— `detail-page.md`「其余 **9 块**通用件只渲底图」是算对的
#    （d1/d2/d3 换产品 + 其余 9 块 = 12），实测就是被这条误伤的。
# `(?<!第)(?<!第 )` = 放过「第9模块」「第 9 模块」这种**序数**用法（当前库里没有，
# 但序数和计数长得一模一样，先堵上）。⚠️ Python 的 lookbehind 必须定长 ⇒ 只能这样并列两条。
_DEAD_BLOCK_RE = re.compile(r"(?<![\d])(?<!第)(?<!第 )9\s*模块")


def check_counts(root: Path, truth: dict) -> list:
    bad = []
    # 这条闸门自己的前提：9 之所以是错的，是因为现役核心序列已经不是那 9 块了。
    # 前提不成立就先喊，⛔ 别拿一把自己都过期了的尺子去量别人。
    if truth["detail"] != 12:
        bad.append((Path("scripts/check_docs.py"), 0, f"DETAIL_FULL 现在是 {truth['detail']} 块",
                    "🔴 本规则的「9 块已作废」判据是按 12 块写的，请同批复核 _DEAD_BLOCK_RE"))
    for doc in _iter_docs(root, suffixes=(".md", ".py", ".json")):
        if doc.name == Path(__file__).name:
            continue
        lines = doc.read_text(encoding="utf-8", errors="replace").splitlines()
        for i, line in enumerate(lines, 1):
            if any(ok in line for ok in _COUNT_OK):
                continue
            if _DEAD_ONLY_RE.search(line):
                bad.append((doc.relative_to(root), i, line.strip()[:110],
                            f"d1..d9 是已作废序列，会漏掉 4 个附加件；用 --detail-all（{' '.join(truth['seq'])}）"))
                continue
            if _DEAD_BLOCK_RE.search(line):
                bad.append((doc.relative_to(root), i, line.strip()[:110],
                            f"详情页是 {truth['detail']} 块（build.py DETAIL_FULL），不是 9 模块"))
    return bad


# ── ⑤ 行号式引用 ───────────────────────────────────────────────────────────
# `文件.ext:数字` 无歧义，一律报；「第 N 行」只在同行出现文件名/「本文」时才报
# （放过「表第 1 行」「日志第 18 行」这类同页表格行的正当说法）。
_LINEREF_RE = re.compile(r"[A-Za-z_][\w.-]*\.(?:py|md|json|html|css|sh|bat)[:：]\d+(?:\s*[-–~]\s*\d+)?")
# 🔴 文件名必须**紧挨着**「第 N 行」才算文件行号引用（中间只容得下引号/空格这类装饰）。
#    第一版只要求"同一行里出现过文件名"，实测 2 条命中**全是假报**：
#      · `SKILL.md`「（每单必读，见上方「先分流」主线表**第 1 行**）」—— 同页表格行，
#        只因同句提了 `compliance.md` 就被逮
#      · `CHANGELOG.md`「藏在日志**第 18 行**」—— 同句提了 `AGENTS.md`
#    ⇒ 加邻接约束后两条都放行，而真病例「`detail-page.md` 第 57 行」「本文第 57 行」仍被逮。
_CN_LINEREF_RE = re.compile(
    r"(?:[\w.-]+\.(?:py|md|json|html|css|sh|bat)|本文件|本文)[`）)\"'」》\s]{0,4}第\s*\d+\s*行")
_LINEREF_OK = "check_docs: 行号ok"


def _template_stem_re():
    """🔴 模板常被【去掉扩展名】引用：`d5-certs:21` / `d2-benefits:24` / `d3-formula:22`。

    这三条正是本批在 `overlay_copy.py` 里手工修掉的形态，而 `_LINEREF_RE` 认不出来
    （它要求带 `.html` 之类扩展名）⇒ 同一个病复发时闸门拦不住。
    ⛔ 别改成"任何 `词:数字`"来兜底 —— 那会把 `bottom:16px`、`port:8620`、`ratio:0.85`
    全逮进来（独立回检就在裸正则上实测到这类假报）。这里**只认盘上真实存在的模板名**，
    模板改名/新增自动跟着变，零维护、零假报。
    """
    tpl = SKILL / "assets" / "templates"
    stems = sorted({p.stem for p in tpl.glob("*.html")} | {p.stem for p in tpl.glob("*.css")}) if tpl.is_dir() else []
    if not stems:
        return None
    return re.compile(r"(?<![\w-])(?:%s)[:：]\d+(?:\s*[-–~]\s*\d+)?" % "|".join(re.escape(s) for s in stems))


_TPL_LINEREF_RE = _template_stem_re()


def check_line_refs(root: Path) -> list:
    bad = []
    # CHANGELOG 对 ①② 是冻结存档，但**指错的指针仍然是指错的指针** ⇒ ⑤ 照查
    for doc in _iter_docs(root, suffixes=(".md", ".py", ".json"), skip_files=set()):
        if doc.name == Path(__file__).name:
            continue
        lines = doc.read_text(encoding="utf-8", errors="replace").splitlines()
        for i, line in enumerate(lines, 1):
            if _LINEREF_OK in line:
                continue
            for rx in (_LINEREF_RE, _TPL_LINEREF_RE, _CN_LINEREF_RE):
                if rx is None:
                    continue
                m = rx.search(line)
                if m:
                    bad.append((doc.relative_to(root), i, m.group(0), line.strip()[:100]))
                    break
    return bad


# ── 自检 ───────────────────────────────────────────────────────────────────
def selftest() -> int:
    """五条规则各造正反例 —— 🔴 只测"该报的报了"不够，必须同时测"不该报的没报"。

    ⚠️ 正例夹具里有几行是**实测被第一版误伤过的真实原文**（见各段 🔴 注释），
    它们是回归位：谁把判据放宽回去，selftest 当场红。⛔ 别为了"让规则更全"把它们删掉。
    """
    ok = True
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        (root / "references").mkdir()
        (root / "bad.md").write_text(
            "指到不存在的东西：`references/根本没有这份.md`\n"
            "```bash\npython scripts/render.py build/ m1.html out.png\n```\n",
            encoding="utf-8")
        (root / "good.md").write_text(
            "⚙️ 备选（补渲单块）：\n```bash\npython scripts/render.py build/ m1.html out.png\n```\n"
            "默认：`python scripts/render_v2.py product.json build/ -o out/`\n",
            encoding="utf-8")

        cmds = check_commands(root)
        hit = {str(f) for f, _, _ in cmds}
        if "bad.md" not in hit:
            print("❌ selftest：反例里的裸 render.py 命令没被报出来"); ok = False
        if "good.md" in hit:
            print("❌ selftest：带 ⚙️备选 标记的正例被误报了"); ok = False

        # 断链走真实 SKILL 根，只验正则捞不捞得到（避免改全局状态）
        got = list(_candidates("见 `references/根本没有这份.md` 和 `assets/library/render/`"))
        if "references/根本没有这份.md" not in got:
            print("❌ selftest：断链候选没捞到反引号里的路径"); ok = False
        if list(_candidates("占位符不该被当路径：`references/<产品名>.md`")):
            print("❌ selftest：占位符路径被当成真路径了"); ok = False

        # ── ③ 说明字段（只扫 .json 的 _ 键）────────────────────────────
        (root / "spec_bad.json").write_text(json.dumps({
            "_说明": ["填完跑 build.py → render.py → qc.py。"],
            "note": "这条不是 _ 开头的键，跑 render.py 也不该报",
        }, ensure_ascii=False), encoding="utf-8")
        (root / "spec_good.json").write_text(json.dumps({
            "_说明": ["⚙️备选：build.py → render.py 是纯渲染路径，不是默认路径。",
                    "⛔ 别单跑 render.py 出带产品的模块 —— 双影/压字一个都不查。"],
        }, ensure_ascii=False), encoding="utf-8")
        # 🔴 回归位：`.py` 模块 docstring 里提 render.py 是【依赖/实现】描述，实测 5/6 假报 ⇒ 已收窄，不许再报
        (root / "spec_py.py").write_text(
            '"""依赖：Pillow + 本目录的 render.py（Chrome 定位/端口/探活），零新依赖。"""\n',
            encoding="utf-8")
        hit = {str(f) for f, _, _ in check_specs(root)}
        for name, want in (("spec_bad.json", True), ("spec_good.json", False), ("spec_py.py", False)):
            if (name in hit) != want:
                print(f"❌ selftest ③：{name} 期望{'报' if want else '不报'}，实际相反"); ok = False

        # ── ④ 块数口径 ────────────────────────────────────────────────
        truth = {"detail": 12, "main": 7, "total": 19, "seq": ["d1", "d2"]}
        (root / "cnt_bad.md").write_text(
            "详情页 9 模块信息表（d1-d9）。\n"
            "用法：python build.py detail.json -o build/ --only d1 d2 d3 d4 d5 d6 d7 d8 d9\n", encoding="utf-8")
        # 🔴 下面每一行都是实测被第一版误伤过的真实原文，全部必须放行
        (root / "cnt_good.md").write_text(
            "⛔ 别再按「9 模块」出图（--only d1..d9 会漏 4 个附加件）。\n"
            "完整 12 块 = 核心 8 块 + 4 附加件；一套 19 张图。\n"
            "**10 款 ≠ 90 张图**：d4-d9 全店复用 → **30 张产品图 + 1 套 6 张通用**。\n"
            "# ② 出图：d1/d2/d3 自动换真产品；其余 9 块通用件只渲底图（不调 AI、不花钱）\n"
            "用到它的 5 张图已重跑（05 的 m1/m2/m3 + 06/09 的 m3）。\n"
            "# 即使有人还在跑老的 `--only d1..d9`，也会被这行拦一下，不会静默少交。\n"
            "详情页第 9 模块的底色按与邻段交替来定。\n", encoding="utf-8")
        hit = {str(f) for f, _, _, _ in check_counts(root, truth)}
        if "cnt_bad.md" not in hit:
            print("❌ selftest ④：过期的「9 模块」/ d1..d9 没报出来"); ok = False
        if "cnt_good.md" in hit:
            print("❌ selftest ④：正当的量词说法被误报了（90 张图 / 其余 9 块 / 5 张图 / 老的 d1..d9）"); ok = False

        # ── ⑤ 行号式引用 ──────────────────────────────────────────────
        (root / "ref_bad.md").write_text(
            "序列见 `detail-page.md` 第 57 行。\n"
            "详细序列见本文第 57 行。\n"
            "见 `build.py:80` 那个常量。\n"
            "而 d5-certs:21 是五张白色证书卡。\n"        # 🔴 去扩展名的模板引用，_LINEREF_RE 认不出
            , encoding="utf-8")
        # 🔴 下面两行是实测被第一版误伤过的真实原文（同页表格行，只因同句提了文件名就被逮）
        (root / "ref_good.md").write_text(
            "1. **动手前** → 读 `compliance.md`（每单必读，见上方「先分流」主线表第 1 行）。\n"
            "而这条规则当时藏在日志第 18 行、正文一个字没有。同批把 `AGENTS.md` 补齐到同一口径。\n"
            "序列见 `detail-page.md` 开头「完整交付 = 12 块」那句。\n"
            "历史留档：`build.py:80`  check_docs: 行号ok\n"
            "CSS 声明不是行号：`.cap{position:absolute;bottom:16px}`，端口 port:8620，阈值 ratio:0.85。\n"
            "第 9 模块是序数用法（⑤ 不管计数，这行只验它不被 ⑤ 误伤）。\n", encoding="utf-8")
        hit = [(str(f), tok) for f, _, tok, _ in check_line_refs(root)]
        names = {f for f, _ in hit}
        if len([1 for f, _ in hit if f == "ref_bad.md"]) < 4:
            print(f"❌ selftest ⑤：四种行号式引用没都报出来（含去扩展名的模板引用），实际 {hit}"); ok = False
        if "ref_good.md" in names:
            print(f"❌ selftest ⑤：同页表格行/放行标记被误报了 {hit}"); ok = False

    print("✅ selftest 通过" if ok else "❌ selftest 失败")
    return 0 if ok else 1


def main() -> int:
    ap = argparse.ArgumentParser(
        description="文档一致性检查：断链 · 出图命令 · 说明字段口径 · 详情页块数 · 行号式引用")
    ap.add_argument("--links", action="store_true", help="只查断链")
    ap.add_argument("--commands", action="store_true", help="只查出图命令")
    ap.add_argument("--specs", action="store_true", help="只查说明字段口径（.json 的 _ 键）")
    ap.add_argument("--counts", action="store_true", help="只查详情页块数口径")
    ap.add_argument("--linerefs", action="store_true", help="只查行号式引用")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--root", default=str(SKILL), help="扫描根目录（默认 = skill 根）")
    a = ap.parse_args()

    if a.selftest:
        return selftest()

    root = Path(a.root).resolve()
    if not root.is_dir():
        print(f"❌ 根目录不存在：{root}")
        return 2

    picked = any((a.links, a.commands, a.specs, a.counts, a.linerefs))
    do_links = a.links or not picked
    do_cmds = a.commands or not picked
    do_specs = a.specs or not picked
    do_counts = a.counts or not picked
    do_refs = a.linerefs or not picked
    rc = 0

    if do_links:
        bad = check_links(root)
        if bad:
            rc = 1
            print(f"\n❌ 断链 {len(bad)} 处 —— 文档指到了 skill 里不存在的东西：")
            for f, ln, rel in bad:
                print(f"   {f}:{ln}  →  {rel}")
            print("   👉 要么把文件补进包里，要么改指针指到真实存在的那份。")
            print("   ⛔ 别只改指针不开目标文件确认 —— 「改指针要验证目标里真有那条内容」。")
        else:
            print("✅ 断链检查：0 处（所有指向 skill 内部的路径都活着）")

    if do_cmds:
        bad = check_commands(root)
        if bad:
            rc = 1
            print(f"\n❌ 出图命令 {len(bad)} 处没带 ⚙️备选标记 —— 这些是【会被复制粘贴执行】的旧路径命令：")
            for f, ln, txt in bad:
                print(f"   {f}:{ln}  {txt}")
            print("   👉 默认路径 = `render_v2.py`（换真产品 + 锁文案 + 查双影/压字）。")
            print("      render.py / render_detail.sh 只是【纯渲染工具】：不换产品、不查双影。")
            print("      保留它们没问题，但那一行（或上方 5 行内）必须写明 ⚙️备选 / 补渲 / 纯渲染。")
            print("   🔴 这条闸门存在的理由：同一个病已复发 3 次 —— 改了声明没改能跑的命令。")
        else:
            print("✅ 出图命令检查：0 处裸 render.py（默认路径没被旧命令架空）")

    if do_specs:
        bad = check_specs(root)
        if bad:
            rc = 1
            print(f"\n❌ 说明字段口径 {len(bad)} 处 —— 这些是 agent 出图时【照抄的操作手册】：")
            for f, where, txt in bad:
                print(f"   {f}  〔{where}〕  {txt}")
            print("   👉 默认路径 = `render_v2.py`。要保留 render.py 的说法，请写明它是 ⚙️备选纯渲染。")
        else:
            print("✅ 说明字段口径：0 处（example.json 的 _ 说明键没在教旧路径）")

    if do_counts:
        try:
            truth = _build_truth()
        except Exception as e:                              # noqa: BLE001
            print(f"❌ 块数口径：读不到 build.py 的真值 —— {type(e).__name__}: {e}")
            print("⛔ 这是【没跑成】不是【通过】。")
            return 2
        bad = check_counts(root, truth)
        if bad:
            rc = 1
            print(f"\n❌ 详情页块数口径 {len(bad)} 处 —— 数字过期了，而过期的数字长得和对的一模一样：")
            for f, ln, txt, why in bad:
                print(f"   {f}:{ln}  {txt}\n       ↳ {why}")
        else:
            print(f"✅ 详情页块数口径：0 处（详情页 {truth['detail']} 块 / 主图 {truth['main']} 张 / 一套 {truth['total']} 张）")

    if do_refs:
        bad = check_line_refs(root)
        if bad:
            rc = 1
            print(f"\n❌ 行号式引用 {len(bad)} 处 —— 行号会漂，指错了还长得像指对了：")
            for f, ln, tok, txt in bad:
                print(f"   {f}:{ln}  「{tok}」  {txt}")
            print("   👉 改成引【函数名 / 常量名 / 小节标题 / 选择器名 / 原句】。")
            print("   🔴 改指针前必须打开目标文件确认那条内容真的在 —— 国内立此规时实测 29% 本来就已指错。")
            print(f"   ⚠️ 确属【同页表格第 N 行】这类正当说法，在该行写 `{_LINEREF_OK}` 放行。")
        else:
            print("✅ 行号式引用：0 处")

    print("\n" + ("✅ 文档一致性检查通过" if rc == 0 else "❌ 有问题，见上"))
    return rc


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:                                  # noqa: BLE001
        print(f"❌ check_docs.py 没跑成：{type(e).__name__}: {e}")
        print("⛔ 这是【没跑成】不是【通过】—— 退出码 2。")
        sys.exit(2)
