#!/usr/bin/env python3
"""V2 场景替换的【我方文案被 AI 重画】闸门 —— 专治「标题双影」这类静默错图。

■ 它堵的是哪个坑（2026-08-05 胶原蛋白全套 18 张真实出图）
  V2 默认路径（⛔ 别按"几步"记，环节数改过 —— I-43⒠）：① `build`→`render.py` 出底图 →
  ② `gen_image.py --scene` 换真产品 → ③ `overlay_copy.py` 把 HTML 纯文案层叠回去 →
  ③½ **本脚本**查双影 → ④ `check_layout.py` 查压字。
  ② 是把**整张画布**交给 gpt-image-2 重绘，AI 顺手把**我方英文文案**
  也重画了并且位移几十像素；③ 只是把正确文案**盖**在最上层（加法，不是挖补），
  AI 那份错位的残影仍然从旁边透出来 ⇒ **一句话印两遍 = 双影**。
  当天 m1 / m2 / d1 / d2 / d3 五张全中（d1 整个左栏偏移约 70px），而 `render_v2.py`
  报「✅ 完成 18/18 模块」、**退出码 0**、闸门全绿。这个脚本就是把那次「没人拦」的地方补上一道闸门。

  🔴 `overlay_copy.py` 里 P1-6 那道「非透明占比」闸门**测不到它**：这 5 张的非透明占比
     17/34/17/30/53%，全部落在正常基线内。**「整层盖住」和「文字重影」是两种失败，需要两道闸门。**

■ 判据（为什么这么判，别改成"整框比像素"）
  在**每个文字元素的包围盒**内，比较「换产品前的底图 `_base`」与「换产品后的成品」。
  正常的 `--scene` 只该动产品，文字区域应几乎不变。但**光看"框内变了多少"会误伤**：
  产品本来就允许变，而且换上去的真产品常常**超出占位件的框**、探进文字框的空白处
  （本次 m1 实测就是这样：真产品比占位件宽 1.48 倍，袋子顶边切过大标题字底）。
  所以用**两个指标一起判**，缺一不可：

    ringExtra（新增墨迹）= 在「底图文字笔画向外扩一圈」的环带里，
                            底图是**空白**、成品却**变化很大**的像素占比。
                            —— 双影的残影就落在这一圈里。
    lostInk（原字被盖） = 底图的**笔画像素**里，成品变化很大的占比。
                            —— ③ 是把正确文案**原样盖**回去的，所以真双影时原字**分毫不动**（≈0）；
                               而"产品压住文字"是把笔画**吃掉**（lostInk 明显 >0）。

  ⇒ 判定「AI 重画了我方文案」= ringExtra ≥ 12% **且** lostInk ≤ 5%。
  🔴 lostInk 这一条**不许删**：删了它，"产品正常地挪到文字框空白处"会被判成双影。
     产品压字是**另一个**缺陷，归 `check_layout.py` 管，不该由本脚本报。
  另外，落在**产品图元素框内**的环带像素直接不算 —— 那块地方本来就该变。

■ 阈值哪来的（⛔ 不许拍脑袋改；要改先把下面这张表重跑一遍）
  阈值**沿用国内 skill**（`b2b-image-domestic-skill/scripts/check_scene_text.py`，A3-6 / v2.23），
  它的验证集是国内 8 组实测（坏 m1/m2/t01/t02 双影 + 好 m1/m2/t02 合成法 + 对照 t01 产品压字）：
    · ringExtra 判定线 0.12：卡在「非双影最高 0.076」与「双影主证据 0.14–0.43」之间。
    · lostInk 判定线 0.05：真双影最高 0.026，产品压字 0.154。
  🔴 **两站阈值必须一样**（两站不对称正是这次翻车的根因）—— 要改一边先改另一边，并各自重跑对照表。

  国际站这边（2026-08-05 P1-9 移植时）用胶原蛋白那套图做了双向实测。
  ⚠️ **原写「判对 8/8」已作废**（独立回检 2026-08-05 晚）：下表 8 行里 **4 行是自比空转**、
     第 5 行也已无法复现（见表下说明）⇒ 真正有效的只有 **4 组**（3 坏 + 1 真阴性族）。

    组别            模块  最像双影的那个文字元素          ringExtra  lostInk  退出码
    坏(合成双影)    m1   MADE FOR YOUR BRAND              0.529    0.000    1（检出 12 处）
    坏(合成双影)    m2   Nighttime Berry Blend            0.542    0.000    1（检出 15 处）
    坏(合成双影)    d1   COLLAGEN & ASHWAGANDHA           0.505    0.000    1（检出 14 处）
    好(合成法)      m1   （全部元素）                      0.000    0.000    0   ⛔ 空转
    好(合成法)      m2   （全部元素）                      0.000    0.000    0   ⛔ 空转
    好(合成法)      d1   （全部元素）                      0.000    0.000    0   ⛔ 空转
    好(合成法)      d2   （全部元素）                      0.000    0.000    0   ⛔ 空转
    好(合成法)      d3   （全部元素）                      0.000    0.000    0   ⛔ 空转

  🔴 **上表 4 行标「空转」的作废**（2026-08-05 独立回检查出）：那 4 组的 `--base` 与 `--after`
     **md5 逐字节相同** —— 拿一个文件跟它自己比，必然 0.000，不构成任何阴性证据。
     ⚠️ **m1 那行同样作废**（回检复核）：它声称的对照底图（`build-main/v2/m1_base.png`）已不在库里，
     用交付件里现存的那对文件同样 md5 相同 ⇒ **5 行阴性全部无效**。⛔ 别照这张表调阈值。
     补做的**真阴性**（两图真有差异：同一 HTML 改产品几何后重渲，文字区不动）：

    组别            模块  最像双影的那个文字元素          ringExtra  lostInk  退出码
    真阴性 A1(温和) m1   （h508→560, left538→545）        0.000    —        0
    真阴性 A2(激进) m1   COLLAGEN &（产品探进文字框空白） 0.040    —        0
    真阴性 A3(最狠) m1   COLLAGEN &（库里真实存在的旧几何 0.065    —        0
                         h700/left470/bottom150 + 真产品件，可复现）

  ✅ **真阳性（唯一一次真花钱跑的）**：2026-08-05 用 `detail.json`（V2 配置）对 d1 真调
     `gen_image --scene`（medium，≈¥0.12）→ 检出 7 处，最高
     `NIGHTTIME BERRY BLEND` ringExtra **0.515**、`COLLAGEN & ASHWAGANDHA` 0.379，退出码 1。
     **这是真 AI 重绘产生的双影，不是合成的** —— 上面那三行 0.5x 的「坏(合成双影)」是移植期
     用位移法造的，两者要分清，别混着引用。

  📌 **可复现的真实余量（2026-08-05 晚回检复算，⛔ 以这组为准）**：
     真阴性最高 **0.065**（A3，库里真实存在的旧几何）↔ 判定线 **0.12** ↔ 合成阳性最低 **0.187**（8px 偏移那档）。
     ⚠️ 我先前写的「阴性 0.040 / 阳性最低 0.135」两个数**都不准**：0.040 漏了更狠的 A3；
     0.135 **在表里根本找不到出处**（与已作废的"8.3%"是同一类无出处数字）。
     余量约 0.055 ↔ 0.067，两侧都不宽 —— **换模板/换字号后必须重跑本表**，别默认它还成立。

  ⚠️ 坏样本是**合成的**（真 V2 成品当天已被合成法版覆盖，重跑一张 ¥0.12）：
     `after = 底图整体位移 (11,17)px` 再 `alpha_composite` 上 **overlay_copy 真产出的
     `<key>_textlayer.png`` —— 这正是双影的物理成因（AI 那份错位的 + 正确那份原样盖回）。
     ⛔ 别用"半透明整图混合"造假双影：那种合成里原文案自己就掉墨了（lostInk 抬高），会被否掉，
        国内那边踩过这个坑。
  ⚠️ **原写的「阴性对照 5/5 不误报，补上了国内的零实测缺口」是夸大了** —— 5 组里 4 组是自比空转（见上）。
     真正有效的阴性是 m1 那组 + 后补的 A1/A2 两组，**3 组**；「正常成品会不会误报」这个缺口
     只补了一部分（仍**没有**一张真的"好的 V2 成品"，见下方「已知没验到的」）。

■ ⛔ 已知没验到的（别当它是万无一失的判官，出图仍要放大目检）
  · **没有一张真的"好的 V2 成品"**（走了 --scene、AI 忠实重绘、文案没漂）。上面的阴性对照是
    合成法出的图（产品像素零改动 ⇒ 文字区逐字节相同 ⇒ 必然 0.000），它证明的是"脚本不乱报"，
    **不等于**证明"AI 轻微重绘不会误报"。真遇到误报：先目检，确认没双影再谈调阈值，并把那张图加进表。
  · 只验过实心字。描边字、半透明字、文字压在照片上的模块没有样本。
  · 单字符/图标这类环带不足 200 px 的元素直接跳过（统计噪声大）。
  · 🔴 **lostInk 一票否决的残余风险**：如果 `--scene` 重画时顺手改了文字区的底色/对比度，
    原字像素也会跟着变 ⇒ lostInk 抬高 ⇒ 真双影可能被否掉。处理：**超线但被 lostInk 否掉的元素
    一律打醒目告警并点名**（见输出里的 `vetoed` 段），按未检出继续，但要求人放大目检。
    ⛔ 别因为这个风险就放宽 GHOST_LOST_MAX —— 先拿到一张「底色被改 + 真双影」的样本，再按数据调。

■ 🔴 与国内那份的唯一实现差异：**取元素矩形的机制**
  国内靠 `chrome_shot.py`（常驻 Chrome + CDP over WebSocket）`eval_on()` 直接拿 JS 返回值。
  **国际站没有 `chrome_shot.py`** —— 这边 `render.py` 走 `chrome --headless=new --screenshot`，
  `check_layout.py` 走 `chrome --headless=new --dump-dom` + 探针把结果 base64 塞进根节点属性。
  ⇒ 本脚本**照 `check_layout.py` 那套**（同法实现，不是另起炉灶）：
     注入探针 HTML → `http.server` 起在构建目录 → `--dump-dom` → 正则抠 base64 → json。
  为什么不直接 `import check_layout` 的取框代码：那段逻辑写在它的 `main()` 里、没有可复用的函数，
  而且它的探针只收 `.prod/.prodwrap/...` 选择器命中的产品图（P1-12 正在改这个选择器）；
  本脚本要的是**页面上所有 `<img>`**（用来把"本来就该变"的产品区从环带里刨掉），口径不同。
  ⛔ 别为了省事去改 `check_layout.py` 的探针把两者合一 —— 两个脚本的失败模式不同，闸门要各自独立。
  ✅ 相同的部分严格对齐：`leafText()` 探针**与 `check_layout.py` 的 PROBE 逐字同源**，
     改一边要改另一边；Chrome 定位 / 端口清理 / 存活探测统一 `from render import ...`。
  其余（差异测量、膨胀、掩码计数、判据、阈值、输出话术、退出码）与国内保持一致。

■ 用法（🔴 CLI 契约已和 render_v2 的接线方定死，⛔ 不许改参数名/退出码）
    python check_scene_text.py <build_dir> <module_key> \
        --base <base.png> --after <after.png> --size WxH [--scale N] [--port N] [--chrome PATH]

    # 例：主图 m1（画布 1000×1000 @1x）
    python check_scene_text.py build-main m1 --base build-main/v2/m1_base.png --after out/m1.png \
        --size 1000x1000
    # 例：详情 d1（画布 750×1200，@2x 出图 ⇒ 两张 PNG 都是 1500×2400）
    python check_scene_text.py build-detail d1 --base build-detail/v2/d1_base.png --after out/d1.png \
        --size 750x1200 --scale 2

    ⚠️ `--base` 要的是**换产品前**的底图（`render_v2.py` 的 `build/v2/<key>_base.png`）。
       render_v2 收尾会把 `_base/_swapped/_fit` 删掉（除非 `--keep`）—— 所以这道检查
       必须在**清理之前**跑。
    🔴 `--after` 必须是 **③ overlay_copy 叠完文案层之后**的成品（`out/<key>.png`），
       ⛔ **不能**传 ③ 之前的 `<key>_fit.png`。理由是判据的根：双影 = 「正确的字被原样叠回来了、
       旁边还多出 AI 那一份错位的」；叠之前图上**只有 AI 那一份**，`lostInk` 会整片超标 ⇒
       本判据会把真双影当成"没问题"放掉。传错时脚本会**退 2 并说明**（不会假装通过）。
    ⚠️ 两张图必须**同尺寸**（V2 里 `_fit` 已缩放回底图尺寸，overlay 的产出也是这个尺寸）。
       ⛔ 别拿 gen_image 直接吐出来的 `_swapped.png`（尺寸由模型自定，对不上）。

■ 退出码
    0 = 没检出我方文案被重画
    1 = 检出双影 —— 🔴 处置**首选是重掷这一张 `--scene`**（见下方检出分支打印的「处置阶梯」），
        ⛔ 别一上来就改合成法。`render_v2.py` 已按这个阶梯自动重掷（默认 2 轮）。
    2 = 没跑成（缺参数 / 图对不上 / Chrome 起不来 / 端口清不掉）—— ⛔ 绝不静默当"通过"

依赖：Pillow + 本目录的 render.py（Chrome 定位/端口/探活），零新依赖，Mac/Windows 同款。
"""
import argparse
import base64
import json
import re
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _compat  # noqa: F401,E402  （必须 import：修 Windows 管道输出下 emoji 崩溃）
# 复用 render.py 的 Chrome 定位 / 端口清理 / 存活探测，避免逻辑分叉（与 check_layout.py 同源）
from render import find_chrome, free_port, http_ok  # noqa: E402
from build import DETAIL_HEIGHTS  # noqa: E402  （详情页锁死高度，用来卡「--size 传错」）

try:
    from PIL import Image, ImageChops, ImageFilter
except ImportError:                                   # noqa: BLE001
    print("❌ 缺 Pillow。装一下：pip install pillow", file=sys.stderr)
    raise SystemExit(2)


# ── 判据参数（上面的文件头有实测出处；⛔ 改之前先重跑那张表，且两站要一起改）────────────────
INK_T = 60        # 灰度偏离本框底色 > 此值 = 笔画（墨迹）
BG_T = 25         # 灰度偏离本框底色 < 此值 = 空白（底色）
CHG_T = 60        # 底图↔成品 同一像素灰度差 > 此值 = 这个像素被改过
RING_FACTOR = 0.35   # 环带半径 ≈ 文字框高的 0.35（双影位移量级 = 几十像素）
RING_MIN_R, RING_MAX_R = 3, 40
GHOST_RING_RATIO = 0.12   # 环带新增墨迹占比 ≥ 此值 → 疑似残影
GHOST_LOST_MAX = 0.05     # 且原笔画被改动占比 ≤ 此值（否则那是"产品压字"，归 check_layout）
MIN_RING_PX = 200         # 环带太小的元素（图标/单字符）统计噪声大，不判
# 🔴 「文案压根没叠回去」的识别线：整页大面积的原字都被改掉 = --after 多半传成了 overlay【之前】
#    的中间件（_fit / _swapped）。那种输入下本判据的 lostInk 一票否决会把真双影全放掉 ⇒ 必须退 2 报错，
#    ⛔ 不能安静地打 ✅。（阈值取得很松：正确输入下 lostInk 最高的一个元素才 0.154。）
NOT_OVERLAID_LOST = 0.20      # 单个元素的 lostInk 超过它算"原字没了"
NOT_OVERLAID_MIN_N = 3        # 且这样的元素至少这么多个
NOT_OVERLAID_FRAC = 0.30      # 且占被测元素的比例超过它

# 探针：量每个文字元素和每张 img 的屏幕矩形（CSS px），base64 塞进根节点属性
# （base64 无引号/空格，--dump-dom 不会把它转义坏）。
# 🔴 leafText 与 check_layout.py 的 PROBE 是同一套口径，改一边要改另一边。
# 🔴 imgs 收的是**页面上所有 <img>**（不走 check_layout 那个产品选择器）：本脚本只拿它做"这块本来
#    就该变、别算进环带"的排除区，宁可多排除也别漏 —— 漏了会把正常换产品误报成双影。
PROBE = r"""
<script>
(function(){
  function leafText(){
    var out=[], w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null,false), n;
    while(n=w.nextNode()){
      var s=n.textContent.replace(/\s+/g,' ').trim();
      if(!s) continue;
      var el=n.parentElement; if(!el) continue;
      var r=el.getBoundingClientRect();
      if(r.width<1||r.height<1) continue;
      out.push({t:s.slice(0,44),l:r.left,tp:r.top,w:r.width,h:r.height});
    }
    return out;
  }
  var imgs=[].slice.call(document.querySelectorAll('img')).map(function(im){
    var r=im.getBoundingClientRect();
    return {l:r.left,tp:r.top,w:r.width,h:r.height};
  });
  var payload=JSON.stringify({imgs:imgs,texts:leafText()});
  document.documentElement.setAttribute('data-scenetextcheck',
      btoa(unescape(encodeURIComponent(payload))));
})();
</script>
"""


def die(msg: str) -> None:
    """没跑成 → 退 2。⛔ 绝不能退 0（那等于假装通过），也不能退 1（那是"检出"的意思）。"""
    print(f"❌ 没跑成：{msg}", file=sys.stderr)
    raise SystemExit(2)


def _mask_count(m) -> int:
    """0/255 掩膜里 255 的像素数。"""
    return m.histogram()[255]


def _dilate(mask, r: int):
    """把 0/255 掩膜向外扩 r 像素。分多次小核 MaxFilter —— 大核 MaxFilter 慢得离谱。"""
    out = mask
    while r > 0:
        k = min(4, r)
        out = out.filter(ImageFilter.MaxFilter(2 * k + 1))
        r -= k
    return out


def _rect_px(r: dict, scale: int, w: int, h: int):
    """CSS px 矩形 → 图像像素矩形 (x0,y0,x1,y1)，并裁进画布。"""
    x0 = max(0, int(r["l"] * scale))
    y0 = max(0, int(r["tp"] * scale))
    x1 = min(w, int((r["l"] + r["w"]) * scale))
    y1 = min(h, int((r["tp"] + r["h"]) * scale))
    return x0, y0, x1, y1


def measure(base_img, after_img, texts, imgs, scale: int):
    """逐个文字元素量 ringExtra / lostInk。返回 [(文字, ringExtra, lostInk, 环带像素数), …]。"""
    W, H = base_img.size
    prod_boxes = [_rect_px(i, scale, W, H) for i in imgs]
    rows, seen = [], set()
    for e in texts:
        x0, y0, x1, y1 = _rect_px(e, scale, W, H)
        if x1 - x0 < 4 or y1 - y0 < 4:
            continue
        sig = (e["t"], x0, y0, x1, y1)
        if sig in seen:          # 同一元素被多个文本节点重复报，量一次就够
            continue
        seen.add(sig)

        b = base_img.crop((x0, y0, x1, y1))
        a = after_img.crop((x0, y0, x1, y1))
        # 本框底色 = 出现次数最多的灰度（文字框里背景总是占多数）
        hist = b.histogram()
        bg = max(range(256), key=lambda i: hist[i])
        dev = ImageChops.difference(b, Image.new("L", b.size, bg))
        ink = dev.point(lambda v: 255 if v > INK_T else 0)      # 底图的笔画
        blank = dev.point(lambda v: 255 if v < BG_T else 0)     # 底图的空白
        changed = ImageChops.difference(b, a).point(lambda v: 255 if v > CHG_T else 0)

        n_ink = _mask_count(ink)
        if n_ink == 0:           # 这个框里根本没渲出字（空元素/纯占位），没什么可比的
            continue
        lost = _mask_count(ImageChops.multiply(ink, changed)) / n_ink

        r = max(RING_MIN_R, min(RING_MAX_R, int(RING_FACTOR * (y1 - y0))))
        ring = ImageChops.subtract(_dilate(ink, r), ink)
        # 产品图元素框内的环带不算：那块地方本来就该被 --scene 换掉
        for px0, py0, px1, py1 in prod_boxes:
            ox0, oy0 = max(px0, x0), max(py0, y0)
            ox1, oy1 = min(px1, x1), min(py1, y1)
            if ox1 > ox0 and oy1 > oy0:
                ring.paste(0, (ox0 - x0, oy0 - y0, ox1 - x0, oy1 - y0))
        n_ring = _mask_count(ring)
        if n_ring < MIN_RING_PX:
            continue
        extra = _mask_count(ImageChops.multiply(ImageChops.multiply(blank, changed), ring)) / n_ring
        rows.append((e["t"], extra, lost, n_ring))
    return rows


def grab_boxes(build: Path, html_name: str, w: int, h: int, port: int, chrome: str):
    """起一次无头 Chrome（--dump-dom + 注入探针，与 check_layout.py 同法），把文字/图片矩形取回来。

    🔴 任何失败都归「没跑成」→ die() 退 2，⛔ 不能当"没检出"放行。
    量的是 CSS px：固定 `--force-device-scale-factor=1`，与 --scale 无关（矩形再乘 scale）。
    """
    src_html = build / html_name
    probe_html = build / f"__scenetextcheck__{html_name}"   # ⚠️ 文件名与 check_layout 的临时件错开
    try:
        html = src_html.read_text(encoding="utf-8")
    except Exception as e:       # noqa: BLE001
        die(f"读不了 {src_html}：{e}")
    inj = html.replace("</body>", PROBE + "</body>") if "</body>" in html else html + PROBE
    try:
        probe_html.write_text(inj, encoding="utf-8")
    except Exception as e:       # noqa: BLE001
        die(f"写不了探针临时文件 {probe_html}：{e}")

    srv = None
    try:
        free_port(port)
        srv = subprocess.Popen(
            [sys.executable, "-m", "http.server", str(port)],
            cwd=build, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        base_url = f"http://127.0.0.1:{port}"
        for _ in range(40):
            if http_ok(f"{base_url}/{probe_html.name}"):
                break
            time.sleep(0.25)
        else:
            die(f"本地服务器起不来，或 {probe_html.name} 404（端口 {port}）。"
                f"换个 --port 再试；端口一直被占就先关掉别的出图进程。")
        # --virtual-time-budget=5000：等 webfont 加载完再量框。字体没到位 → 文字框宽度全错 →
        # 这张检查的结论没有意义（国内 v2.4 踩过"字体竞态"这个坑）。
        res = subprocess.run(
            [chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars",
             "--force-device-scale-factor=1", f"--window-size={w},{h}",
             "--virtual-time-budget=5000", "--dump-dom", f"{base_url}/{probe_html.name}"],
            capture_output=True, timeout=180,
        )
        dom = res.stdout.decode("utf-8", "replace")
    except SystemExit:
        raise                    # die() 自己抛的，别被下面的兜底吞掉
    except Exception as e:       # noqa: BLE001
        die(f"起 Chrome 或读页面失败：{e}\n"
            f"   多半是 Chrome 没装/路径不对（用 --chrome 指定），或 {port} 端口被别人占着。")
    finally:
        if srv is not None:
            srv.terminate()
            try:
                srv.wait(timeout=10)
            except Exception:    # noqa: BLE001
                srv.kill()
        probe_html.unlink(missing_ok=True)

    m = re.search(r'data-scenetextcheck="([A-Za-z0-9+/=]+)"', dom)
    if not m:
        die("页面探针没回传数据（dump-dom 里找不到 data-scenetextcheck）—— 多半是 JS 没跑起来。"
            "换新版 Chrome，或用 --chrome 指定。")
    try:
        data = json.loads(base64.b64decode(m.group(1)).decode("utf-8"))
    except Exception as e:       # noqa: BLE001
        die(f"探针回传的数据解不开：{e}")
    if not isinstance(data, dict) or "texts" not in data:
        die("探针回传的数据里没有 texts —— JS 没跑完整。换个新版 Chrome 再试。")
    return data


def main() -> None:
    ap = argparse.ArgumentParser(
        description="V2 场景替换：查我方 HTML 文案有没有被 gpt-image-2 重画/位移（双影闸门）")
    ap.add_argument("build_dir", help="构建目录（build.py 的产物，里面有 <module_key>.html）")
    ap.add_argument("module_key", help="模块名，如 m1 / d1")
    ap.add_argument("--base", required=True, help="换产品【前】的底图 PNG（build/v2/<key>_base.png）")
    ap.add_argument("--after", required=True, help="换产品【后】的成品 PNG（overlay_copy 之后那张）")
    ap.add_argument("--size", required=True, help="该模块的画布尺寸 WxH（CSS px，如 1000x1000 / 750x1200）")
    ap.add_argument("--scale", type=int, default=None,
                    help="出图倍率（主图 1、详情页 2）。不传就按图的实际尺寸÷画布推断。")
    # 🔴 默认端口 8749：`references/pitfalls.md §11` 划定 —— 8580–8619 手工并发、8620–8676
    #    render_v2 自动分配、8747/8748/8792 是 render/check_layout/overlay_copy 的默认口。
    #    8749 三段都不撞，也不在国内 skill 的 {8747,8748,8792}+slot*10 族里。
    #    render_v2 调本脚本时会显式传本模块专属端口，这个默认值只影响手工单跑。
    ap.add_argument("--port", type=int, default=8749, help="本地服务器端口（默认 8749）")
    ap.add_argument("--chrome", default=None, help="Chrome 可执行文件路径（默认自动找）")
    a = ap.parse_args()

    build = Path(a.build_dir).resolve()
    html = f"{a.module_key}.html"
    if not (build / html).exists():
        die(f"构建目录里没有 {build / html} —— 先 build.py 出这个模块，或 <module_key> 写错了。")

    try:
        w, h = (int(x) for x in a.size.lower().split("x"))
    except Exception:            # noqa: BLE001
        die(f"--size 得写成 WxH（如 1000x1000 / 750x1200），现在是「{a.size}」。")
    # --size 传错 → 文字框全部错位 → 结论没有意义。主图锁 1000×1000，详情页锁 750×DETAIL_HEIGHTS。
    if a.module_key.startswith("m") and (w, h) != (1000, 1000):
        die(f"--size 不对：主图 {a.module_key} 锁死 1000x1000，你传的是 {a.size}。\n"
            f"   ⛔ 尺寸传错 → 文字框全部错位 → 这张检查的结论没有意义。")
    if a.module_key in DETAIL_HEIGHTS and (w, h) != (750, DETAIL_HEIGHTS[a.module_key]):
        die(f"--size 不对：详情 {a.module_key} 锁死 750x{DETAIL_HEIGHTS[a.module_key]}，你传的是 {a.size}。\n"
            f"   ⛔ 尺寸传错 → 文字框全部错位 → 这张检查的结论没有意义。")

    base_p, after_p = Path(a.base), Path(a.after)
    for p, what in ((base_p, "--base 底图"), (after_p, "--after 成品图")):
        if not p.exists():
            die(f"找不到 {what}：{p}\n"
                f"   （底图是 render_v2 的 build/v2/<key>_base.png；它收尾会删，这道检查要在清理前跑。）")
    try:
        base_img = Image.open(base_p).convert("L")
        after_img = Image.open(after_p).convert("L")
    except Exception as e:       # noqa: BLE001
        die(f"图读不开：{e}")

    if base_img.size != after_img.size:
        die(f"两张图尺寸对不上：底图 {base_img.size[0]}×{base_img.size[1]}，"
            f"成品 {after_img.size[0]}×{after_img.size[1]}。\n"
            f"   本判据靠逐像素对齐，尺寸不同就没法比。\n"
            f"   👉 --after 只能传 **overlay_copy 之后的成品**（out/<key>.png）。\n"
            f"   ⛔ 别传 <key>_fit.png：那是 overlay 之前的，原字整片不在原位 ⇒ lostInk 全线超标 "
            f"⇒ 真双影会被静默放行（判据前提见本文件头注释）。\n"
            f"   ⛔ 也别传 gen_image 直接吐出的 <key>_swapped.png（尺寸由模型自定）。")
    iw, ih = base_img.size
    if iw % w or ih % h or iw // w != ih // h:
        die(f"图的尺寸 {iw}×{ih} 不是画布 {w}×{h} 的整数倍 —— "
            f"--size 传错了，或者这两张图不是这个模块的。")
    scale = iw // w
    if scale < 1:
        die(f"图比画布还小（{iw}×{ih} vs {w}×{h}）—— --size 传错了。")
    if a.scale is not None and a.scale != scale:
        die(f"--scale {a.scale} 与图的实际倍率对不上：{iw}×{ih} ÷ {w}×{h} = @{scale}x。\n"
            f"   要么 --scale 传错，要么这两张 PNG 不是这个模块/这个倍率出的。")

    data = grab_boxes(build, html, w, h, a.port, a.chrome or find_chrome())
    try:
        rows = measure(base_img, after_img, data["texts"], data.get("imgs", []), scale)
    except Exception as e:       # noqa: BLE001
        die(f"比对时出错：{e}")

    print(f"🔎 {a.module_key}：画布 {w}×{h} @{scale}x，查了 {len(rows)} 个文字元素")
    print(f"   底图 {base_p}\n   成品 {after_p}")

    # 🔴 先卡「--after 传错了」：整页大面积原字都不在原位 = 我方文案层还没叠回去。
    #    这种输入下 lostInk 一票否决会把**真双影全部放掉** ⇒ 必须退 2，⛔ 不能打 ✅。
    gone = [r for r in rows if r[2] > NOT_OVERLAID_LOST]
    if rows and len(gone) >= NOT_OVERLAID_MIN_N and len(gone) / len(rows) > NOT_OVERLAID_FRAC:
        die(f"{len(gone)}/{len(rows)} 个文字元素的**原字整片不在原位**了 —— "
            f"--after 多半传成了 overlay_copy【之前】的中间件（<key>_fit.png / _swapped.png）。\n"
            f"   本判据要的是 ③ **叠完文案层之后**的成品：双影的特征是「正确的字还在、旁边多出一份错位的」，\n"
            f"   叠之前只有 AI 那一份，判据不成立（会把真双影当成「没问题」放掉）。\n"
            f"   👉 把这一步挪到 overlay_copy 之后、清理 build/v2 中间件之前，--after 传 out/<key>.png。")

    hits = [r for r in rows if r[1] >= GHOST_RING_RATIO and r[2] <= GHOST_LOST_MAX]
    vetoed = [r for r in rows if r[1] >= GHOST_RING_RATIO and r[2] > GHOST_LOST_MAX]
    if not hits:
        clean = [r for r in rows if r not in vetoed]
        worst = max(clean, key=lambda r: r[1], default=None)
        if worst:
            print(f"   新增墨迹最高的一个：「{worst[0][:24]}」{worst[1]*100:.1f}%"
                  f"（判定线 {GHOST_RING_RATIO*100:.0f}%）")
        if vetoed:
            # ⛔ 别只打个百分比就说"未检出"——那读起来像脚本坏了。说清为什么它超线还放行。
            print(f"   ⚠️ 另有 {len(vetoed)} 个文字元素**新增墨迹超线**"
                  f"（最高 {max(r[1] for r in vetoed)*100:.1f}%），"
                  f"但它们的**原字同时被改掉了**（最高 {max(r[2] for r in vetoed)*100:.1f}%，"
                  f"超过 {GHOST_LOST_MAX*100:.0f}% 的线）：")
            for t, extra, lost, _n in sorted(vetoed, key=lambda r: -r[1])[:4]:
                print(f"      · 「{t[:24]}」新增 {extra*100:.1f}% / 原字被改 {lost*100:.1f}%")
            print(f"      → 不符合双影特征（双影时正确文案被原样叠回去，原字**分毫不动**），"
                  f"**按未检出处理**。")
            print(f"      ⛔ 但这不等于「没问题」：更像①产品压到文字（跑 check_layout.py）"
                  f"或② --scene 把底色/对比度也改了。🔴 这几处必须放大目检。")
        print(f"✅ {a.module_key}：没检出我方文案被 --scene 重画。"
              f"（🔴 是筛子不是判官，出图仍要放大目检标题有没有重影）")
        return

    print(f"❌ {a.module_key}：检出【我方文案被 --scene 重画并位移】{len(hits)} 处 —— 就是【标题双影】，这张不能要：")
    for t, extra, lost, n_ring in sorted(hits, key=lambda r: -r[1]):
        print(f"   · 「{t[:32]}」 字周边新增墨迹 {extra*100:.1f}%"
              f"（判定线 {GHOST_RING_RATIO*100:.0f}%，环带 {n_ring} px）；"
              f"原字未被覆盖 {lost*100:.1f}% ⇒ 正确文案还在、旁边多出一份错位的 = 双影")
    # 🔴 处置阶梯（V2-7，Bowen 2026-08-06 定；口径必须与 references/scene-swap.md
    #   §我方文案双影的处置阶梯、render_v2.py 汇总、以及国内 skill v2.26 逐条一致）。
    #   为什么第 1 级是重掷、而不是像 2026-08-05 P1-10 首版那样直接推合成法：
    #     · 双影是 `--scene` 每次重绘我方文案时的**随机走样**，不是必然 —— 整改前的旧版
    #       就是靠「废弃重跑」交付的（scene-swap.md 原话「任一条不过 → 废弃重跑，别硬用」），
    #       从没把双影图交出去过。重掷 = 重新掷这个骰子，成本 ≈ 1 次 gen_image 调用。
    #     · 合成法要先有干净透明抠图件，而 cutout.py 在同事机器上不稳（Bowen 2026-08-06 定：
    #       「抠图这条路不行，还是走 V2」）—— 拿它当双影的常规解 = 把人推进一条走不通的路。
    #   ⛔ 别把第 1 级删了直接跳第 3 级；也⛔别把 mode:composite 写成"唯一处置"。
    #   ⚠️ 本分支在 render_v2 自动重掷时会被反复调用 —— 所以第 ① 句就必须点明"脚本已在替你掷"，
    #     ⛔ 别让人在脚本还要自己掷两轮的时候先动手改 JSON。
    print(f"   👉 处置阶梯（⛔ 按顺序来，别直接跳到第 3 级）：")
    print(f"      ① **重掷这一张 `--scene`** —— 双影是 AI 每次重绘文案的随机走样，换一版通常就干净了。")
    print(f"         `render_v2.py` 已自动重掷（轮数看 RENDER_V2_SCENE_RETRIES，默认 2；设 0 关掉）"
          f"—— ⛔ 它还在替你掷的时候别先动手改 JSON。")
    print(f"         手工单跑就是把 {a.module_key} 再走一遍 render_v2（同一条命令即可）。")
    print(f"      ② **连着重掷都还中** ⇒ 不是运气问题，是这张模板的结构病："
          f"我方文案压在产品区 / 文案太密、AI 绕不开。")
    print(f"         → 改版式（文字挪出产品区、缩短文案、让出留白）后重出；先跑 check_layout.py 看重叠。")
    # 🔴 第 ③ 级的措辞必须与 scene-swap.md 的阶梯、render_v2 汇总那段一致：「**改版式也解决不了**才用」。
    #   ⛔ 别写成"只留给产品自印小字"——那等于把阶梯砍成两级，同一次运行里两段输出对第 ③ 级说法不同。
    print(f"      ③ **合成法 mode:composite（兜底）** —— ② 改版式也解决不了，才轮到它。")
    print(f"         它真正不可替代的是另外两类（和双影无关，那两类直接写、不用先重掷）："
          f"【产品自印小字要分毫不差】（净含量/营养成分表，AI 每次都改、重掷没用）"
          f"和【详情页要产品全分辨率清晰】。")
    print(f"         走法：product.json / detail.json 的 {a.module_key}.swap 段加 \"mode\": \"composite\"，"
          f"重跑 render_v2；它会跳过 --scene 和 overlay_copy，把透明产品件直接进模板槽用 Chrome 渲"
          f"（不调 AI、产品像素零改动）。缺透明件就先 cutout.py 抠一张。")
    print(f"         ⛔ 依赖 cutout.py 抠出干净透明件、同事机器上不稳 —— 别拿它当双影的常规解。")
    print(f"      （为什么 overlay 救不了：见 overlay_copy.py 头注释 —— 它是把正确文案**盖**上去，"
          f"盖不掉 AI 在旁边多画的那一份。）")
    raise SystemExit(1)


if __name__ == "__main__":
    main()
