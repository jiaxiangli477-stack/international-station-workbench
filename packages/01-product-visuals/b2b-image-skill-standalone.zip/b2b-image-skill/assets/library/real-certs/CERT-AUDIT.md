# LIFEWORTH 真实证书审计 · 2026-07-14（全部已收：6项认证 + HKGCC）

## 文件清单（原图，未脱敏——公开使用前须做脱敏版）
| 文件名 | 证书 | 状态 |
|--------|------|------|
| `cert-nsf-gmp.png` | NSF-GMP (NSF/ANSI 455-2) | ✅ 有效至 2026-10-05 |
| `cert-fssc22000.png` | FSSC 22000 (含 ISO22000) | ✅ 有效至 2028-09-02 |
| `cert-haccp.png` | HACCP (CQC) | ✅ 有效至 2028-08-28 |
| `cert-iso22000-EXPIRED.jpg` | ISO 22000 (CTI 独立证) | ⚠️ 过期 2025-10-30 |
| `cert-fda-registration-EXPIRED.jpg` | FDA 注册 (Registrar Corp) | ⚠️ 过期 2025-12-31（已部分脱敏） |
| `cert-halal-jiabei.png` | HALAL (佳贝授权) | ⚠️ 主体非 Lifeworth |
| `cert-hkgcc-freesale.jpg` | HKGCC 自由销售证明 | ➕ 贸易文件(2022) |


来源：Bowen 提供。敏感字段（编号/QR/信用代码）此处**不完整记录**（脱敏原则）。
⚠️ 图片文件本身尚未入库——聊天粘贴图无法直接写盘，需 Bowen 把原始文件放磁盘后我再脱敏保存。
Bowen 说明：先用这些；ISO/FDA 有新版本再补；HALAL 由佳贝(Jiabei)授权 Lifeworth 使用。

| # | 证书 | 机构 | 主体 | 有效期 | 状态 |
|---|------|------|------|--------|------|
| 1 | **NSF-GMP**（NSF/ANSI 455-2 膳补 GMP）| NSF International(ANAB) | Shenzhen Lifeworth ✓ | 2022-08-12→**2026-10-05** | ✅ 有效（⚠️ 3个月后到期，尽快续） |
| 2 | **FSSC 22000**（含 ISO22000:2018）| CQC | Shenzhen Lifeworth ✓ | 2025-09-03→**2028-09-02** | ✅ 有效 |
| 3 | **HACCP** | CQC | Shenzhen Lifeworth ✓ | 2025-08-29→**2028-08-28** | ✅ 有效 |
| 4 | ISO 22000:2018（独立证）| CTI | Shenzhen Lifeworth | 2022-10-31→**2025-10-30** | ⚠️ 过期（被 FSSC22000 覆盖） |
| 5 | FDA Certificate of Registration | **Registrar Corp（第三方非FDA）** | 已脱敏 | 至 **2025-12-31** | ⚠️ 过期+措辞受限，待续期 |
| 6 | HALAL 清真 | 印尼 BPJPH/MUI | **Jiabei佳贝（授权 Lifeworth 使用）** | 2024-06-25 | ⚠️ 主体非 Lifeworth，凭授权用，需留授权文件+核实范围 |
| + | Certificate of Free Sale 自由销售证明 | HKGCC 香港总商会 | Shenzhen Lifeworth | 2022-09-30 | ➕ 贸易文件非质量认证 |

## 出图宣称口径核对——阿里只上五证 ✅

> 🔴 **持有六张 ≠ 图上写六项。** 上面逐张审计说的是「**我们手里有什么**」（事实，含已过期件，别删）；
> 这一节说的是「**阿里图上能写什么**」（口径，Bowen 2026-08-04 拍板）。两者不一致是正常的。

**阿里出图只用五证**（认证墙五格，文案写 5 不写 6）：
NSF-GMP ✅ · FSSC 22000 ✅ · HACCP ✅ · Free Sale (HKGCC) ➕(贸易文件非质量认证) · HALAL for Ingredient ⚠️(凭佳贝授权，主体非 Lifeworth)

⛔ **已停用、不上墙的两张**（证书仍在库，只是不出现在图上）：
- **FDA 注册**（`cert-fda-registration-EXPIRED.jpg`）—— 阿里禁任何 FDA 字样，含 `Registered`
- **ISO 22000 独立证**（`cert-iso22000-EXPIRED.jpg`）—— 表述由 FSSC 22000 覆盖

## 认证墙建议
- **固定五格（3+2 居中）**：**NSF-GMP · FSSC 22000 · HACCP · Certificate of Free Sale (HKGCC) · HALAL for Ingredient**
- **头牌三张（有效 + Lifeworth 主体，最稳）**：**NSF-GMP · FSSC 22000 · HACCP**；HALAL 凭佳贝授权用、留授权文件；Free Sale 是贸易文件，别单称它"认证"
- ⛔ **别加回来**：FDA-registered facility（阿里禁 FDA 字样）、ISO 22000 独立证（由 FSSC 22000 覆盖）
- **注意**：NSF 证书标 "NSF Confidential / must be returned upon request" → 公开 listing 用 **NSF GMP 徽标/mark**，不宜直接贴整张机密证书原件；买家索要再出脱敏件。

## 脱敏规范（每张遮盖）
**白色**色块覆盖：证书编号/Cert No/Ref No/Certification Number、二维码 QR、COID、统一社会信用代码、Auth Code、DUNS、FS 号。保留：机构 logo、标准名、有效期、主体名、公司名。

## 产出（2026-07-14 已完成）
- `desensitized/` — 7 张脱敏版（白色块遮编号/QR/信用代码，逐张目检确认已盖住）。公开 listing / 认证墙用这批。
- `logos/` — 抠出的机构徽标：`logo-nsf.png`(NSF+GMP CERTIFIED)、`logo-nsf-roundel.png`、`logo-fssc22000.png`、`logo-haccp.png`、`logo-cqc.png`。⚠️ 从带水印证书裁出，有极淡 LIFEWORTH 水印；做正式认证墙建议向 NSF/FSSC/CQC 官方要矢量 logo 更清。
- 原图（未脱敏）保留在本目录根，存档/买家索要时用。
