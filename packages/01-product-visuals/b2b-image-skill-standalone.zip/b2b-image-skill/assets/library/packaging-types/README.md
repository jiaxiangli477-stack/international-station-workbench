# 包装形态素材（详情页 D4 · Customized Packaging）

D4 网格用的 9 张包材图。**全店通用、固定不改**，任何产品都复用同一批。

🔗 **接线方式**：`build.py` 的 `GENERIC_ASSETS["d4"]=("packaging-types","icons")` 把本目录整个拷进
构建目录的 `icons/`，模板 `d4-packaging.html` 直接引 `icons/<文件名>`。⛔ **不走 product.json 的 images**，
增删图要**同步改模板里的 `<img src>` 和文案**（文件名即引用）。

| 文件（= 模板 icons/ 引用名） | 名称 | MOQ（包材起订量，写死在模板） |
|---|---|---|
| cardboard.png | Paper Box | 500 |
| petbox.png | PET/PP/PVC Box | 2000 |
| powdercan.png | Powder Can | 100 |
| papercan.png | Paper Can | 1000 |
| tin.png | Tin | 3000 |
| capsulebottle.png | Capsule/Tablet Bottle | 500 |
| dropper.png | Dropper Bottle | 500 |
| coffeecup.png | Coffee Capsule Cup | 10000 |
| foil.png | Foil Packet | 10000 |

> 🔴 这里的 MOQ 是**包材起订量**（Foil Packet 10000 之类），是公司口径的常量，**写死在
> `d4-packaging.html` 里**；与 d7/d9 的**成品起订量** `{{MOQ}}`（每款不同、走 globals）是两回事，别混。

## ⚠️ 当前是临时占位图，等真图替换
这 9 张是从旧线上图 `素材/详情页04.jpg` **裁切 + 抠白底**得到的（清晰度/水印残留有损）。
Bowen 会提供每种包装的**素材原图**。到手后：
1. 抠成白底（浅色包装用 `cutout.py` flood，见 `references/cutout.md`）；
2. 用**同名文件**覆盖本目录对应 png；
3. `build.py detail.json --only d4` 重新构建出图即可，模板/信息表都不用动。

> 命名保持不变就零改动；若真图文件名不同，记得同步 `d4-packaging.html` 的 `<img src="icons/…">`。
