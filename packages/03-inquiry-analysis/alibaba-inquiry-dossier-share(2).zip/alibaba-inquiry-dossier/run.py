"""Standalone Accio -> verified collection -> original inquiry HTML."""
import argparse, importlib.util, json, os, shutil, sys, uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'engine'))
import bridge_runtime, weekly_update as weekly, inquiry_calendar

def load_discovery():
    spec=importlib.util.spec_from_file_location('discovery',ROOT/'engine/accio_discovery.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def bootstrap(work):
    if os.name!='nt':raise ValueError('此桥接包针对 Windows Accio Work')
    m=load_discovery(); node=m.find_node();cli=m.find_workctl();mcp=m.find_mcp_script()
    if not all((node,cli,mcp)):raise ValueError('未找到 Accio 自带 Node 或 CLI；查看 references/安装与使用.md')
    folder=work/'bridge/bin';folder.mkdir(parents=True)
    for name,target in [('workctl',cli),('accio-mcp-cli',mcp)]:
        if any(c in str(node)+str(target) for c in ('%','!','\n','\r','"')):raise ValueError('运行时路径含不支持字符')
        (folder/(name+'.cmd')).write_text('@echo off\r\n"'+str(node)+'" "'+str(target)+'" %*\r\n',encoding='utf-8')
    env=bridge_runtime.child_environment(folder/'workctl.cmd',os.environ)
    env['PATH']=str(folder)+os.pathsep+env.get('PATH','')
    env['PYTHONDONTWRITEBYTECODE']='1'
    temp=work/'temp';temp.mkdir();env['TEMP']=env['TMP']=str(temp)
    identity=work/'identity.json'
    weekly.run([folder/'workctl.cmd','workflow','chat-analysis','resolve-id','--output-file',identity,'--format','json'],work,120,env)
    data=json.loads(identity.read_text(encoding='utf-8-sig'))
    if not str(data.get('CURRENT_SELF_ALIID') or '').isdigit():raise ValueError('当前店铺身份不可核验')
    return folder,env,data

def main():
    p=argparse.ArgumentParser(description='独立询盘分析：使用原版 HTML 生成器')
    p.add_argument('action',choices=['accounts','run'])
    p.add_argument('--start');p.add_argument('--end');p.add_argument('--seller',help='resolve-id 返回的业务员 aliId；all 表示全部')
    p.add_argument('--store-id',help='预期店铺 aliId，防止误店采集')
    p.add_argument('--output',default=str(ROOT/'runs'))
    p.add_argument('--skip-public',action='store_true',help='跳过公网核验，在报告注明')
    a=p.parse_args()
    if a.action=='run':
        from calendar_periods import window
        window('custom',a.start,a.end)
        if not a.seller or not a.store_id:p.error('run 必须指定 --seller 和 --store-id')
    work=Path(a.output).resolve()/uuid.uuid4().hex;work.mkdir(parents=True)
    bridge,env,identity=bootstrap(work)
    members=[{'aliId':str(identity['CURRENT_SELF_ALIID']),'name':identity.get('CURRENT_NAME','当前账号')}]
    members.extend(identity.get('otherMembers') or [])
    if a.action=='accounts':
        print(json.dumps({'storeId':str(identity['CURRENT_SELF_ALIID']),'accounts':members},ensure_ascii=False,indent=2));return
    expected=str(identity['CURRENT_SELF_ALIID'])
    if expected!=a.store_id:raise ValueError('登录店铺与 --store-id 不一致')
    ids={str(m.get('aliId') or '') for m in members}
    if a.seller!='all' and a.seller not in ids:raise ValueError('业务员不属于当前店铺')
    env['INQUIRY_SELLER_ID']=a.seller
    engine=work/'collection';engine.mkdir()
    for f in (ROOT/'engine').glob('*.py'):shutil.copy2(f,engine/f.name)
    print('正在采集并验证指定期间；保持 Accio 登录及店铺不变。',flush=True)
    inquiry_calendar.collect(engine,bridge,expected,{'start':a.start,'end':a.end},env=env,progress=lambda msg:print(msg,flush=True))
    weekly.require_identity(bridge,work/'identity-after.json',expected,env)
    command=[sys.executable,ROOT/'engine/run_scoped.py','--source',engine/'inquiry','--output',work/'report','--seller',a.seller,'--start',a.start,'--end',a.end]
    if a.skip_public:command.append('--skip-public')
    print(weekly.run(command,work,14400,env),flush=True)
    (work/'COMPLETE.json').write_text(json.dumps({'status':'COMPLETE','store':expected,'seller':a.seller,'start':a.start,'end':a.end,'publicChecks':not a.skip_public},ensure_ascii=False),encoding='utf-8')

if __name__=='__main__':
    try:main()
    except Exception as exc:
        # No raw gateway output or credential exceptions are printed.
        print('未完成：'+(str(exc) if isinstance(exc,(ValueError,weekly.SyncError)) else type(exc).__name__),file=sys.stderr)
        sys.exit(1)
