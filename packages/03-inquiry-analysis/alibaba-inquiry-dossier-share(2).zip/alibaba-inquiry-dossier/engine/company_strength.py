import re
LEVELS = ['强', '中-强', '中', '弱-中', '弱', '待核验']
_LEVEL_MIN = {'强': 70, '中-强': 55, '中': 40, '弱-中': 25, '弱': 0}
P_ORDER = ['P0 重点追', 'P1 正常跟', 'P2 小额快周转', 'P3 有价值·待激活', 'P4 先索取主体']
P_DESC = {'P0 重点追': '实力够、需求也明确 —— 配专属报价，可谈私标/独家/账期', 'P1 正常跟': '实力中等或需求明确其一 —— 按标准流程跟，别过度投入', 'P2 小额快周转': '实力偏弱但需求清楚 —— 小额快周转，全额走 Trade Assurance', 'P3 有价值·待激活': '主体/规模看着不错但没谈出需求 —— 别催单，定期发新品与产能信息养着', 'P4 先索取主体': '公开渠道查不到主体 —— 谈单前必须索取注册号/官网/公司全称/税号'}
_YEAR_RE = re.compile('(?:since|est(?:ablished|\\.)?|founded|来自|成立)[^\\d]{0,12}((?:19|20)\\d{2})', re.I)
_EMP_RE = re.compile('\\b(\\d{1,6})\\+?\\s*(?:employees|staff|workers|people|团队)', re.I)
_CTRY_RE = re.compile('\\b(\\d{1,3})\\s*(?:countries|country|markets|国家)', re.I)
INTENT_KEYS = {'price': ('price', 'quote', 'quotation', 'cost', 'how much', 'pricing', 'fob', 'exw', 'usd', '$', '报价', '价格', '单价', 'цена', 'precio'), 'moq': ('moq', 'minimum order', 'quantity', 'pcs', 'units', 'qty', 'container', '起订', '数量', '整柜', 'шт', 'cantidad'), 'sample': ('sample', 'samples', 'prototype', '打样', '样品', '寄样', 'образец', 'muestra'), 'spec': ('spec', 'formula', 'flavor', 'flavour', 'packaging', 'bottle', 'sachet', 'stick', '规格', '配方', '口味', '包装', 'sabor', 'вкус'), 'cert': ('certificate', 'coa', 'gmp', 'haccp', 'iso', 'fda', '认证', '证书', 'сертификат'), 'payment': ('payment', 'deposit', 't/t', 'l/c', 'proforma', 'pi', '付款', '定金', '信用证', 'предоплата', 'pago'), 'shipping': ('shipping', 'delivery', 'lead time', 'dhl', 'fedex', 'freight', 'air', 'sea', '交期', '运费', '物流', 'доставка', 'envío'), 'oem': ('oem', 'odm', 'private label', 'white label', '贴牌', '定制', '代工', '私标', '自有品牌', 'marca propia')}
try:
    from extract_entities import is_junk_domain as _junk_dom
except Exception:

    def _junk_dom(d):
        return (d or '').lower() in ('gmail.com', 'hotmail.com', 'yahoo.com', 'outlook.com', 'live.com', 'icloud.com', 'qq.com', '163.com', 'mail.com')

def _has(text, keys):
    t = (text or '').lower()
    return any((k in t for k in keys))

def _hit_count(text, keys):
    t = (text or '').lower()
    return sum((1 for k in keys if k in t))

def score(rec):
    rec = rec or {}
    rdap = rec.get('rdap') or {}
    site = rec.get('site') or {}
    prof = rec.get('profile') or {}
    reg = rec.get('registry') or {}
    why, gaps = ([], [])
    dims = {}
    A = 0
    _ent = '、'.join(prof.get('legal_entities') or []) or (rec.get('entity') or '').strip()
    if _ent:
        A += 10
        why.append('主体名：%s +10' % _ent[:36])
    else:
        gaps.append('站上未见法律主体名（可索取注册号）')
    if reg.get('hit'):
        A += 12
        _h = (reg.get('hits') or [{}])[0]
        why.append('工商库命中「%s」(公司号 %s) +12' % (_h.get('name', ''), _h.get('number', '')))
    if rdap.get('registered'):
        A += 6
        age = rdap.get('age_years')
        why.append('域名 %s 已注册%s +6' % (rdap.get('domain'), '，%.1f 年' % age if isinstance(age, float) else ''))
        if isinstance(age, float) and age >= 2:
            A += 4
            why.append('域名注册 ≥2 年（非临时站）+4')
    elif rdap.get('registered') is False:
        gaps.append('域名未注册，不能作主体佐证')
    dims['A 主体真实性'] = min(A, 22)
    B = 0
    _blob = ' '.join([prof.get('title') or '', ' '.join(prof.get('size_hints') or []), site.get('desc') or '', site.get('title') or ''])
    m = _YEAR_RE.search(_blob)
    if m:
        try:
            yrs = 2026 - int(m.group(1))
        except Exception:
            yrs = 0
        if yrs >= 15:
            B += 9
            why.append('经营约 %d 年（≥15 年） +9' % yrs)
        elif yrs >= 7:
            B += 6
            why.append('经营约 %d 年（≥7 年） +6' % yrs)
        elif yrs >= 3:
            B += 3
            why.append('经营约 %d 年（≥3 年） +3' % yrs)
    else:
        gaps.append('拿不到经营年限（官网 about 页通常有 since 年份）')
    if _EMP_RE.search(_blob) or _CTRY_RE.search(_blob):
        B += 4
        why.append('站上有员工数/覆盖国家线索 +4')
    if prof.get('ecommerce'):
        B += 6
        why.append('独立站带购物车/结算（真在卖货，非纯展示）+6')
    _ind = len(set(prof.get('industry') or []) | set(site.get('industry') or []))
    if _ind >= 3:
        B += 5
        why.append('品类/行业关键词 %d 类（经营面宽） +5' % _ind)
    elif _ind >= 1:
        B += 2
        why.append('品类/行业关键词 %d 类 +2' % _ind)
    dims['B 经营规模'] = min(B, 24)
    C = 0
    if site.get('reachable') and (not site.get('parked')):
        C += 6
        why.append('官网在营 +6')
    elif site.get('parked'):
        gaps.append('官网是停放/待售页，不是在营主体')
    if prof.get('phones'):
        C += 4
        why.append('站上留了电话 %s（可直接约通话）+4' % prof['phones'][0])
    _mails = [m for m in rec.get('emails') or [] if not _junk_dom(m.split('@')[-1])]
    if _mails:
        C += 3
        why.append('企业域名邮箱 %s +3' % _mails[0])
    _soc = len(prof.get('socials') or [])
    if _soc >= 2:
        C += 3
        why.append('独立站挂着 %d 个社媒账号 +3' % _soc)
    elif _soc == 1:
        C += 1
        why.append('独立站挂着 1 个社媒账号 +1')
    dims['C 渠道暴露面'] = min(C, 16)
    D = 0
    v, lg, sl = (rec.get('views'), rec.get('logins'), rec.get('sellers'))
    if isinstance(v, int):
        if v >= 200:
            D += 6
        elif v >= 100:
            D += 5
        elif v >= 50:
            D += 3
        elif v >= 20:
            D += 1
        if v >= 50:
            why.append('90 天浏览 %d 个产品 +%d' % (v, 6 if v >= 200 else 5 if v >= 100 else 3))
    if isinstance(lg, int):
        if lg >= 20:
            D += 6
            why.append('90 天登录 %d 天（高频活跃）+6' % lg)
        elif lg >= 10:
            D += 4
            why.append('90 天登录 %d 天 +4' % lg)
        elif lg >= 5:
            D += 2
            why.append('90 天登录 %d 天 +2' % lg)
    if isinstance(sl, int):
        if sl >= 40:
            D += 6
            why.append('90 天接触 %d 家供应商（大采购网络）+6' % sl)
        elif sl >= 20:
            D += 4
            why.append('90 天接触 %d 家供应商 +4' % sl)
        elif sl >= 10:
            D += 2
            why.append('90 天接触 %d 家供应商 +2' % sl)
    _lv = (rec.get('level') or '').upper()
    if _lv.endswith('4'):
        D += 4
        why.append('平台买家等级 L4（最高）+4')
    elif _lv.endswith('3'):
        D += 3
        why.append('平台买家等级 L3 +3')
    elif _lv.endswith('2'):
        D += 1
        why.append('平台买家等级 L2 +1')
    dims['D 采购能力'] = min(D, 22)
    E = 0
    if re.search('(?:\\d+(?:[.,]\\d+)?)\\s*(?:usd|us\\$|\\$|eur|rub|rmb|cny)', rec.get('price') or '', re.I):
        E += 5
        why.append('聊天里有具体单价 +5')
    elif rec.get('price'):
        E += 2
        why.append('聊天里出现过价格相关表述 +2')
    if re.search('\\d[\\d,]{1,8}\\s*(?:pcs|units?|pieces?|boxes?|bottles?|sachets?|sticks?|kg|tons?|шт)', rec.get('qty') or '', re.I):
        E += 4
        why.append('聊天里有具体数量 +4')
    _ct = rec.get('chat_text') or ''
    if _has(_ct, INTENT_KEYS['sample']):
        E += 3
        why.append('聊到打样/样品 +3')
    if _has(_ct, INTENT_KEYS['oem']):
        E += 2
        why.append('聊到私标/代工 +2')
    if (rec.get('nbuy') or 0) >= 3 and (rec.get('nsell') or 0) >= 2:
        E += 2
        why.append('双向沟通（买家 %d 条 / 我方 %d 条）+2' % (rec['nbuy'], rec['nsell']))
    dims['E 成交意向'] = min(E, 16)
    total = sum(dims.values())
    if not any([rec.get('emails'), rec.get('domains'), prof.get('fetched'), reg.get('hit'), rec.get('entity'), rdap.get('domain')]) and (not (rec.get('views') or rec.get('logins') or rec.get('sellers'))):
        return dict(score=0, level='待核验', dims=dims, why=why, gaps=gaps or ['无任何主体与行为证据'], verdict='P4 先索取主体', verdict_desc=P_DESC['P4 先索取主体'])
    lvl = '弱'
    for L in ('强', '中-强', '中', '弱-中'):
        if total >= _LEVEL_MIN[L]:
            lvl = L
            break
    has_intent = bool(rec.get('price') or rec.get('qty')) or _has(_ct, INTENT_KEYS['moq'])
    strong = lvl in ('强', '中-强')
    if strong and has_intent:
        p = 'P0 重点追'
    elif lvl == '中':
        p = 'P1 正常跟' if has_intent else 'P3 有价值·待激活'
    elif strong:
        p = 'P3 有价值·待激活'
    elif has_intent:
        p = 'P1 正常跟' if lvl == '弱-中' else 'P2 小额快周转'
    else:
        p = 'P3 有价值·待激活' if lvl == '弱-中' else 'P4 先索取主体'
    if not why:
        p = 'P4 先索取主体'
    return dict(score=total, level=lvl, dims=dims, why=why, gaps=gaps, verdict=p, verdict_desc=P_DESC[p], intent=has_intent)

def level_color(lvl):
    return {'强': '#2e9e5b', '中-强': '#3f8f57', '中': '#a86a11', '弱-中': '#c07a1e', '弱': '#c0392b', '待核验': '#94a3b8'}.get(lvl, '#94a3b8')
