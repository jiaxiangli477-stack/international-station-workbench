import re
BLOCKERS = {'DEAL': ('已成交 / 在途', '不是卡点：维持交付节奏，顺手谈复购与下一款'), 'NOT_REPLIED_US': ('我方未回复', '最优先：立刻回。用「一、优先行动」里的话术，开头致歉 + 直接回答他最后那个问题 + 问一个筛选问题'), 'NO_QUOTE': ('问了价没报价', '别再确认需求了，直接给阶梯价（首单量 / 中单量 / 大货量）+ MOQ + 交期，一句话说清'), 'QUOTED_SILENT': ('报价后失联', '不要重复报价。改成「二选一收口」：给他两个方案（起订量小/价格优）让他选一个，或直接约 15 分钟通话'), 'SAMPLE_PENDING': ('样品环节卡住', '把样品条件一次说清：样品费多少 / 运费谁付 / 几天发出 / 下单后是否返还，不给模糊答复'), 'SPEC_PENDING': ('规格配方未定', '主动给 2-3 个成熟配方或包装方案让他挑，别等他描述；挑完再报对应价格'), 'CERT_PENDING': ('资质资料未给', '把 GMP / HACCP / ISO / COA 模板打包一次发全，并说明「哪些证能提供、哪些不能」——资料给全最能建立信任'), 'PAYMENT_PENDING': ('付款条款未定', '给出可选付款方式（T/T 定金比例 / Trade Assurance）与对应优惠，把选择权交给他'), 'SHIPPING_PENDING': ('交期运费未确认', '给出明确的交期天数 + 两种运输方案（空运快/海运省）与到港预估，别只说「看数量」'), 'AWAIT_BUYER': ('等他回话', '别干等：发一条「新信息」而不是催（新配方 / 新包装 / 案例），再给一个明确的时间点'), 'CHITCHAT': ('全程没谈生意', '会话量不小但没有商业要素——改成一次性把产品目录 + 阶梯价 + 起订量发过去，把话题拉回「你要什么、要多少」'), 'CARD_ONLY': ('只发过卡片 / 打招呼', '低投入培育：发一次资质 + 主推款清单即可，不投打样资源')}
STAGE_OF = {'DEAL': '已成交 / 在途', 'NOT_REPLIED_US': '沟通中（球在我们）', 'NO_QUOTE': '谈价阶段（未出价）', 'QUOTED_SILENT': '已报价（球在买家）', 'SAMPLE_PENDING': '样品阶段（条件未定）', 'SPEC_PENDING': '定规格 / 配方阶段', 'CERT_PENDING': '资质 / 证书阶段', 'PAYMENT_PENDING': '付款条款阶段', 'SHIPPING_PENDING': '交期 / 物流阶段', 'AWAIT_BUYER': '已回复（球在买家）', 'CHITCHAT': '仅寒暄（未进入业务）', 'CARD_ONLY': '未启动（只发过卡片）'}
GAP_OF = {'NO_QUOTE': '我方消息里从未出现任何价格数字', 'CERT_PENDING': '买家要的资料我方一条都没给', 'SAMPLE_PENDING': '没给样品条件（费用/运费/天数）', 'PAYMENT_PENDING': '没给付款方式与对应优惠', 'SHIPPING_PENDING': '没给交期天数与运输方案', 'SPEC_PENDING': '没给可选规格/配方方案', 'QUOTED_SILENT': '报价后没有任何跟进动作', 'NOT_REPLIED_US': '买家最后一句还没人回', 'AWAIT_BUYER': '我方已答，但没给下一个时间点', 'CHITCHAT': '整场没有价格/数量/样品/条款任一要素', 'CARD_ONLY': '买家只发了卡片，我方也没引导', 'DEAL': '—'}
INTENT_KEYS = {'order': ('order', 'orders', 'reorder', 'purchase', 'tracking', 'shipment', '订单', '下单', '返单', 'заказ', 'заказы', 'pedido', 'pedidos', 'commande'), 'price': ('price', 'quote', 'quotation', 'cost', 'how much', 'pricing', 'discount', 'fob', 'exw', 'cif', '报价', '价格', '单价', '多少钱', 'цена', 'цену', 'стоимость', 'precio', 'precios', 'cuanto', 'cuánto', 'preço', 'prix', 'preis', 'سعر'), 'moq': ('moq', 'minimum order', 'quantity', 'pcs', 'units', 'qty', 'container', '起订', '数量', '整柜', 'шт', 'штук', 'количество', 'cantidad', 'cantidades', 'quantidade', 'quantité', 'menge', 'كمية'), 'sample': ('sample', 'samples', 'prototype', '打样', '样品', '寄样', 'образец', 'образцы', 'пробник', 'muestra', 'muestras', 'tester', 'amostra', 'amostras', 'échantillon', 'echantillon', 'muster', 'probe', 'عينة'), 'spec': ('spec', 'specification', 'formula', 'flavor', 'flavour', 'packaging', 'package', 'label', 'bottle', 'sachet', 'stick', 'jar', 'pouch', 'capsule', '规格', '配方', '口味', '包装', '标签', '剂型', 'вкус', 'состав', 'упаковка', 'дизайн', 'sabor', 'envase', 'empaque', 'diseño', 'rotulo', 'etiqueta', 'sabor', 'embalagem', 'goût', 'geschmack', 'verpackung'), 'cert': ('coa', 'msds', 'certificate', 'certification', 'gmp', 'iso', 'haccp', 'fda', 'halal', 'kosher', 'organic', 'non-gmo', 'test report', 'lab report', '认证', '证书', '资质', '检测报告', 'сертификат', 'сертификаты', 'certificado', 'certificados', 'certificat', 'zertifikat', 'شهادة'), 'payment': ('payment', 'deposit', 'invoice', 'trade assurance', 'paypal', 'tt', 't/t', 'l/c', 'letter of credit', 'pi', 'proforma', '付款', '定金', '信用证', '形式发票', 'предоплата', 'оплата', 'pago', 'pagos', 'pagamento', 'paiement', 'zahlung', 'دفعة'), 'shipping': ('shipping', 'delivery', 'lead time', 'eta', 'freight', 'dhl', 'fedex', 'air freight', 'sea freight', 'port', 'customs', '交期', '发货', '运费', '物流', '到港', '清关', 'доставка', 'отправка', 'сроки', 'envío', 'envio', 'entrega', 'frete', 'livraison', 'versand', 'توصيل'), 'oem': ('oem', 'odm', 'private label', 'custom', 'customiz', 'logo', 'own brand', '贴牌', '定制', '代工', '私标', '自有品牌', 'бренд', 'под своим брендом', 'marca propia', 'marca', 'marca própria', 'marque', 'marke', 'علامة')}
GIVEN_PATTERNS = {'price': '(?:\\d+(?:[.,]\\d+)?)\\s*(?:usd|us\\$|\\$|eur|rub|rmb|cny)|(?:usd|us\\$|\\$|eur|rub|rmb|cny)\\s*\\d+(?:[.,]\\d+)?|price\\s*(?:list|is|:)|报价|цена|precio', 'cert': 'coa|msds|gmp|haccp|iso\\s?\\d*|certificate|证', 'sample': 'sample|样品', 'payment': 'deposit|t/?t|trade assurance|payment term|invoice|定金|付款', 'shipping': 'lead time|shipping|delivery|dhl|fedex|air|sea|freight|days|交期|运费', 'spec': 'spec|formula|flavor|flavour|packaging|bottle|sachet|stick|规格|配方|口味|包装'}
DEAL_WORDS = ('已下样品', '已下单', '已经下单', '在途', '首单在走', '大货单', '大货订单', '已付款', '定金已付', 'purchase order', 'po sent', 'deposit paid', 'in transit')
DEAL_HINT_WORDS = DEAL_WORDS + ('大货', '已发货', '订单已', 'order placed', '返单')
ORDER_STRONG = ('tracking number', 'tracking no', 'order number', 'po number', 'order status', 'order update', 'update on my order', 'order arrived', 'order doing', 'when will my order', 'when will you ship', 'my current order', 'our current order', 'current order with', 'received my order', 'received the order', 'has been shipped', 'was shipped', 'already shipped', 'мой заказ', 'наш заказ', 'mi pedido actual', 'nuestro pedido actual', 'meu pedido atual', 'ma commande actuelle')
ORDER_BUYER = ('my order', 'our order', 'i ordered', 'we ordered', 'already ordered', 'already placed', 'order placed', 'received my order', 'received the order')
ORDER_BUYER_RE = ('\\b(repeat|re-?)\\s?order\\s+(has been|was|is being|got|arrived|already|is in)\\b', '\\b(already|just)\\s+(placed|sent|confirmed|made)\\s+(a\\s+|the\\s+|my\\s+|our\\s+)?(repeat|re-?)\\s?order\\b')
CARD_PREFIX = ('This is a', 'This is an')

def _fmt(t, n=110):
    t = re.sub('\\s+', ' ', t or '').strip()
    return t[:n] + '…' if len(t) > n else t

def _hit(text, keys):
    low = text.lower()
    for k in keys:
        if len(k) <= 3 and k.isalpha():
            if re.search('(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(k), low):
                return True
        elif k in low:
            return True
    return False

def analyze(msgs, wait_days=0, hint_text=''):
    real = [m for m in msgs or [] if not (m.get('content') or '').lstrip().startswith(CARD_PREFIX)]
    if not real:
        return dict(stage=STAGE_OF['CARD_ONLY'], blocker='CARD_ONLY', label=BLOCKERS['CARD_ONLY'][0], tip=BLOCKERS['CARD_ONLY'][1], detail='只有平台卡片，买家从未真正发言', gap=GAP_OF['CARD_ONLY'], ask='', buyer_last='', seller_last='', yield_pct=0, intents=[])
    buyer = [m for m in real if m.get('senderRole') == 'buyer']
    seller = [m for m in real if m.get('senderRole') != 'buyer']
    btxt = '\n'.join((m.get('content') or '' for m in buyer))
    stxt = '\n'.join((m.get('content') or '' for m in seller))
    allt = (btxt + '\n' + stxt).lower()
    intents = [k for k, keys in INTENT_KEYS.items() if _hit(btxt, keys)]
    n_biz = sum((1 for m in buyer if any((_hit(m.get('content') or '', keys) for keys in INTENT_KEYS.values()))))
    yld = int(round(100.0 * n_biz / max(1, len(buyer))))
    last_is_buyer = real[-1].get('senderRole') == 'buyer'
    b_last = _fmt(buyer[-1].get('content')) if buyer else ''
    s_last = _fmt(seller[-1].get('content')) if seller else ''
    _hint = (hint_text or '').lower()
    _blow = btxt.lower()
    _bre = None
    for _rx in ORDER_BUYER_RE:
        m = re.search(_rx, _blow, re.I)
        if m:
            _bre = m.group(0)
            break
    hit = [w for w in DEAL_HINT_WORDS if w in _hint] or [w for w in DEAL_WORDS if w in allt] or [w for w in ORDER_STRONG if w in allt] or [w for w in ORDER_BUYER if w in _blow] or ([_bre] if _bre else [])
    if hit:
        b = 'DEAL'
        _src = '内部备注' if hit[0] in DEAL_HINT_WORDS and hit[0] in _hint else '买家原话' if hit[0] in ORDER_BUYER and hit[0] in _blow else '聊天原文'
        return dict(stage=STAGE_OF[b], blocker=b, label=BLOCKERS[b][0], tip=BLOCKERS[b][1], detail='出现订单证据「%s」（%s）' % (hit[0], _src), gap=GAP_OF[b], ask=b_last, buyer_last=b_last, seller_last=s_last, yield_pct=yld, intents=intents)
    if last_is_buyer and buyer:
        b = 'NOT_REPLIED_US'
        det = '买家最后一句等了 %d 天' % wait_days if wait_days else '买家最后一句还没回'
        return dict(stage=STAGE_OF[b], blocker=b, label=BLOCKERS[b][0], tip=BLOCKERS[b][1], detail=det, gap=GAP_OF[b], ask=b_last, buyer_last=b_last, seller_last=s_last, yield_pct=yld, intents=intents)
    for key, b in (('cert', 'CERT_PENDING'), ('sample', 'SAMPLE_PENDING'), ('payment', 'PAYMENT_PENDING'), ('shipping', 'SHIPPING_PENDING'), ('price', 'NO_QUOTE'), ('spec', 'SPEC_PENDING')):
        if key in intents and (not re.search(GIVEN_PATTERNS[key], stxt, re.I)):
            ask = ''
            for m in reversed(buyer):
                if _hit(m.get('content') or '', INTENT_KEYS[key]):
                    ask = _fmt(m.get('content'), 120)
                    break
            return dict(stage=STAGE_OF[b], blocker=b, label=BLOCKERS[b][0], tip=BLOCKERS[b][1], detail='买家提过「%s」，我方消息里没有对应内容' % key, gap=GAP_OF[b], ask=ask or b_last, buyer_last=b_last, seller_last=s_last, yield_pct=yld, intents=intents)
    if re.search(GIVEN_PATTERNS['price'], stxt, re.I) and intents:
        return dict(stage=STAGE_OF['QUOTED_SILENT'], blocker='QUOTED_SILENT', label=BLOCKERS['QUOTED_SILENT'][0], tip=BLOCKERS['QUOTED_SILENT'][1], detail='我方已给过价格，之后买家没有再回', gap=GAP_OF['QUOTED_SILENT'], ask=b_last, buyer_last=b_last, seller_last=s_last, yield_pct=yld, intents=intents)
    if len(buyer) >= 2 and (not intents):
        return dict(stage=STAGE_OF['CHITCHAT'], blocker='CHITCHAT', label=BLOCKERS['CHITCHAT'][0], tip=BLOCKERS['CHITCHAT'][1], detail='买家发了 %d 条但没有任何商业要素（价格/数量/样品/规格/条款）' % len(buyer), gap=GAP_OF['CHITCHAT'], ask=b_last, buyer_last=b_last, seller_last=s_last, yield_pct=yld, intents=intents)
    if len(buyer) <= 1:
        return dict(stage=STAGE_OF['CARD_ONLY'], blocker='CARD_ONLY', label=BLOCKERS['CARD_ONLY'][0], tip=BLOCKERS['CARD_ONLY'][1], detail='买家只发了 %d 条，未进入实质沟通' % len(buyer), gap=GAP_OF['CARD_ONLY'], ask=b_last, buyer_last=b_last, seller_last=s_last, yield_pct=yld, intents=intents)
    return dict(stage=STAGE_OF['AWAIT_BUYER'], blocker='AWAIT_BUYER', label=BLOCKERS['AWAIT_BUYER'][0], tip=BLOCKERS['AWAIT_BUYER'][1], detail='我方已回复，球在买家那边', gap=GAP_OF['AWAIT_BUYER'], ask=b_last, buyer_last=b_last, seller_last=s_last, yield_pct=yld, intents=intents)

def aggregate(rows):
    from collections import Counter, defaultdict
    cnt, days, tiers = (Counter(), defaultdict(list), defaultdict(Counter))
    for r in rows:
        b = r.get('blocker')
        if not b:
            continue
        cnt[b] += 1
        d = r.get('blocker_days')
        if isinstance(d, int):
            days[b].append(d)
        tiers[b][r.get('tier')] += 1
    out = []
    for b, n in cnt.most_common():
        avg = round(sum(days[b]) / float(len(days[b])), 1) if days[b] else 0
        out.append(dict(code=b, label=BLOCKERS.get(b, ('-', ''))[0], tip=BLOCKERS.get(b, ('', ''))[1], n=n, avg_days=avg, tiers=dict(tiers[b])))
    return out
TAG_LABEL = {'order': '订单', 'price': '价格', 'moq': '数量', 'sample': '样品', 'spec': '规格', 'cert': '资质', 'payment': '付款', 'shipping': '交期', 'oem': '贴牌'}
PRICE_RE = re.compile('(?:\\d+(?:[.,]\\d+)?)\\s*(?:usd|us\\$|\\$|eur|rub|rmb|cny)|(?:usd|us\\$|\\$|eur|rub|rmb|cny)\\s*\\d+', re.I)
QTY_RE = re.compile('\\b\\d[\\d,]{1,8}\\s*(?:pcs|units?|pieces?|boxes?|bottles?|sachets?|sachects?|sticks?|strips?|bags?|jars?|kg|kgs|tons?|шт|штук)\\b', re.I)

def key_messages(msgs, limit=8):
    real = [(i, m) for i, m in enumerate(msgs or []) if not (m.get('content') or '').lstrip().startswith(CARD_PREFIX)]
    if not real:
        return []
    picks = {}
    for i, m in real:
        t = m.get('content') or ''
        low = t.lower()
        tags = []
        if PRICE_RE.search(t):
            tags.append('价格')
        if QTY_RE.search(t):
            tags.append('数量')
        for k, keys in INTENT_KEYS.items():
            if _hit(t, keys):
                tags.append(TAG_LABEL.get(k, k))
        picks[i] = list(dict.fromkeys(tags)) or []
    picks[real[-1][0]] = list(dict.fromkeys(picks.get(real[-1][0], []) + ['最后一句']))
    for i, m in real[:3]:
        if m.get('senderRole') == 'buyer':
            picks[i] = list(dict.fromkeys(picks.get(i, []) + ['开场']))
            break
    keep = [i for i, tags in picks.items() if tags]
    if not keep:
        keep = [real[-1][0]]
    if len(keep) > limit:
        must = {real[-1][0]}
        others = [i for i in keep if i not in must]
        keep = sorted(must | set(others[:max(1, limit - 1)]))
    out = []
    for i in sorted(keep)[-limit:]:
        m = msgs[i]
        out.append(dict(i=i, sender='买家' if m.get('senderRole') == 'buyer' else '我方', tags=picks.get(i) or [], time=str(m.get('sendTime') or '')[:16], text=re.sub('\\s+', ' ', m.get('content') or '').strip()[:400]))
    return out

def key_ratio(msgs):
    real = [(i, m) for i, m in enumerate(msgs or []) if not (m.get('content') or '').lstrip().startswith(CARD_PREFIX)]
    if not real:
        return 0
    return int(round(100.0 * len(key_messages(msgs, limit=99)) / len(real)))
