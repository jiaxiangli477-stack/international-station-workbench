import json, sys
from pathlib import Path
import weekly_update

def collect_contacts(engine, bridge, expected, start, end, env=None):
    result = weekly_update.run([sys.executable, Path(__file__).parent / 'contact_enrichment.py', '--engine', engine, '--bridge', bridge, '--expected', str(expected), '--start', start, '--end', end], engine, timeout=7200, env=env)
    return json.loads(result)
