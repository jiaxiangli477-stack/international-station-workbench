import glob
import json
import os
import re
import shutil
import string
import subprocess
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(HERE, 'bin')
HOME = os.path.expanduser('~')
APPDATA = os.environ.get('APPDATA', '')
LOCALAPPDATA = os.environ.get('LOCALAPPDATA', '')
PORT = '4097'

def _f(p):
    return bool(p) and os.path.isfile(p)

def _d(p):
    return bool(p) and os.path.isdir(p)

def find_node():
    cands = []
    if os.environ.get('ACCIO_NODE_BIN'):
        cands.append(os.environ['ACCIO_NODE_BIN'])
    w = shutil.which('node')
    if w:
        cands.append(w)
    cands += glob.glob(os.path.join(APPDATA, 'Accio', 'pre-install', '*', 'node', 'node.exe'))
    cands += glob.glob(os.path.join(HOME, '.workbuddy', 'binaries', 'node', 'versions', '*', 'node.exe'))
    cands += [os.path.join(LOCALAPPDATA, 'Programs', 'nodejs', 'node.exe'), 'C:\\Program Files\\nodejs\\node.exe', 'C:\\Program Files (x86)\\nodejs\\node.exe', '/usr/local/bin/node', '/usr/bin/node']
    for c in cands:
        if _f(c):
            return c
    return None

def _drive_roots():
    if os.name != 'nt':
        return []
    return [ch + ':\\' for ch in string.ascii_uppercase if os.path.isdir(ch + ':\\')]

def _probe_mcp(base):
    p = os.path.join(base, 'resources', 'accio-mcp-cli', 'accio-mcp.mjs')
    return p if _f(p) else None

def find_mcp_script():
    env = os.environ.get('ACCIO_MCP_SCRIPT')
    if _f(env):
        return env
    for b in [os.path.join(LOCALAPPDATA, 'Programs', 'Accio'), os.path.join(APPDATA, 'Accio'), 'C:\\Program Files\\Accio', 'C:\\Program Files (x86)\\Accio']:
        hit = _probe_mcp_in_root(b)
        if hit:
            return hit
    a = os.path.join(APPDATA, 'Accio')
    if _d(a):
        for depth in range(1, 5):
            g = glob.glob(os.path.join(a, *['*'] * depth, 'accio-mcp.mjs'))
            if g:
                return g[0]
    for root in _drive_roots():
        try:
            lv1 = [e.path for e in os.scandir(root) if e.is_dir()]
        except Exception:
            continue
        for d in lv1:
            hit = _probe_mcp_in_root(d)
            if hit:
                return hit
        for d in lv1:
            try:
                lv2 = [e.path for e in os.scandir(d) if e.is_dir()]
            except Exception:
                continue
            for d2 in lv2:
                hit = _probe_mcp_in_root(d2)
                if hit:
                    return hit
    return None

def _probe_mcp_in_root(base):
    hit = _probe_mcp(base)
    if hit:
        return hit
    for depth in range(1, 3):
        for g in glob.glob(os.path.join(base, *['*'] * depth, 'resources', 'accio-mcp-cli', 'accio-mcp.mjs')):
            return g
    return None

def find_workctl():
    hits = []
    for root in [os.path.join(LOCALAPPDATA, 'pnpm', 'global'), os.path.join(LOCALAPPDATA, 'pnpm')]:
        for name in ('workctl.js', 'workctl.cjs'):
            hits += glob.glob(os.path.join(root, '**', 'node_modules', '@accio-ai', 'cli', 'bin', name), recursive=True)
    for p in [os.path.join(APPDATA, 'npm', 'node_modules', '@accio-ai', 'cli', 'bin', 'workctl.js'), os.path.join(HOME, 'AppData', 'Roaming', 'npm', 'node_modules', '@accio-ai', 'cli', 'bin', 'workctl.js'), '/usr/local/lib/node_modules/@accio-ai/cli/bin/workctl.js', '/usr/local/lib/node_modules/@accio-ai/cli/bin/workctl.cjs']:
        hits.append(p)
    for p in glob.glob(os.path.join(LOCALAPPDATA, 'pnpm', 'store', '*', 'links', '@accio-ai', 'cli', '*')):
        for name in ('workctl.js', 'workctl.cjs'):
            c = os.path.join(p, 'bin', name)
            if _f(c):
                hits.append(c)
    hits = [h for h in hits if _f(h)]
    if hits:
        hits.sort(key=os.path.getmtime, reverse=True)
        return hits[0]
    return None

def listening_pid(port=PORT):
    try:
        out = subprocess.run(['netstat', '-ano'], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=30, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)).stdout or ''
    except Exception:
        return None
    for line in out.splitlines():
        if ':%s ' % port in line and 'LISTENING' in line.upper():
            m = re.split('\\s+', line.strip())
            if m and m[-1].isdigit():
                return m[-1]
    return None

def _cred_from(path, note):
    try:
        d = json.load(open(path, encoding='utf-8'))
    except Exception as e:
        return {'token': '', 'user': '', 'url': '', 'note': '读取失败 %s: %s' % (path, e), 'file': path, 'account_dir': ''}
    acct = os.path.dirname(os.path.dirname(os.path.dirname(path)))
    return {'token': (d.get('password') or '').strip(), 'user': (d.get('username') or 'phoenix').strip(), 'url': d.get('url') or 'http://localhost:4097', 'note': note, 'file': path, 'account_dir': acct}

def find_credentials():
    files = glob.glob(os.path.join(HOME, '.accio', 'accounts', '*', '.accio', 'runtime', 'gateway-cli.json'))
    if not files:
        return {'token': '', 'user': '', 'url': '', 'file': '', 'account_dir': '', 'note': '未找到 gateway-cli.json（Accio 可能没登录或没运行）'}
    pid = listening_pid()
    for p in files:
        try:
            d = json.load(open(p, encoding='utf-8'))
        except Exception:
            continue
        if pid and str(d.get('pid')) == str(pid):
            return _cred_from(p, 'pid=%s 匹配监听进程（%s）' % (pid, p))
    p = max(files, key=os.path.getmtime)
    return _cred_from(p, '按 pid 未匹配，回退到最近修改的文件 %s' % p)
