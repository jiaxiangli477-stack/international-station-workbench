import re
from datetime import date as _date
PLATFORM_PROBE = []
COMPANIES = {}
ASK_COMMON = ['公司注册全称 + 注册号（美国 EIN / 欧盟 VAT / 各国营业执照）', '官网或品牌页面链接', '首单预估数量与目标上架时间']
ASK = {'_default': dict(need=ASK_COMMON + ['采购品类与首单量', '是否有本地销售渠道/品牌'], script='Thanks for reaching out. So I can quote properly instead of guessing, could you share:\n1) your company name and website,\n2) the products and quantities you are considering,\n3) your target market and launch timing?\nI will come back with a formulation proposal, MOQ and price tiers.')}

def _num(t, label):
    m = re.search(re.escape(label) + '\\s*[:：]\\s*([\\d,]+)', t or '')
    return int(m.group(1).replace(',', '')) if m else None

def persona_metrics(persona):
    t = (persona or {}).get('buyer_persona') or ''
    return {'views': _num(t, 'Number of Products Viewed in the Last 90 Days'), 'logins': _num(t, 'Number of Login Days in the Last 90 Days'), 'msg_days': _num(t, 'Number of Days Messaging Sellers in the Last 90 Days'), 'sellers': _num(t, 'Number of Sellers Contacted in the Last 90 Days')}

def top_categories(persona, n=3):
    t = (persona or {}).get('buyer_persona') or ''
    out = []
    for blk in re.findall('<category \\d+>(.*?)</category \\d+>', t, re.S):
        name = re.search('Category Name:\\s*(.+)', blk)
        click = re.search('Click Count[^:]*:\\s*(\\d+)', blk)
        comm = re.search('Communication Count[^:]*:\\s*(\\d+)', blk)
        if not name:
            continue
        leaf = name.group(1).strip().split('/')[-1].strip()
        out.append((leaf, int(comm.group(1)) if comm else 0, int(click.group(1)) if click else 0))
    out.sort(key=lambda x: (-x[1], -x[2]))
    return out[:n]

def chat_facts(msgs):
    txt = '\n'.join((m.get('content') or '' for m in msgs or []))
    f = {}
    qty = re.findall('\\b(\\d[\\d,]{0,8})\\s*(units?|pcs|pieces|bottles|boxes|box|tubs?|sachets?|sachects?|servings?|kg|tons?|strips?)\\b', txt, re.I)
    if qty:
        f['数量'] = '、'.join(('%s %s' % (a, b.lower()) for a, b in qty[:4]))
    pr = re.findall('(?:USD|US\\$|\\$)\\s?(\\d+(?:[.,]\\d+)?)', txt, re.I)
    if pr:
        f['价格'] = '、'.join(('USD ' + x for x in dict.fromkeys(pr)))[:60]
    ph = [x.strip() for x in re.findall('(?:\\+?\\d[\\d \\-()]{7,16}\\d)', txt) if len(re.sub('\\D', '', x)) >= 9]
    if ph:
        f['电话'] = '、'.join(list(dict.fromkeys(ph))[:2])
    addr = re.findall('([^\\n]{0,60}(?:calle|torre|galp[oó]n|street|st\\.|no\\.\\s*\\d+|box\\s*\\d+)[^\\n]{0,60})', txt, re.I)
    if addr:
        f['地址'] = addr[0].strip()[:110]
    comp = re.findall("(?:a nombre de|on behalf of|name of|we are)\\s+([A-Z][\\w&.,\\'\\- ]{2,45})", txt)
    if comp:
        f['公司提及'] = '、'.join(dict.fromkeys([c.strip() for c in comp]))[:80]
    return f

def influence_label(m):
    s = m.get('sellers')
    if s is None:
        return (None, '无行为数据')
    if s >= 40:
        lv, txt = ('高', '90 天接触 **%d 个供应商** —— 典型「多源比价型」，同时在与多家谈' % s)
    elif s >= 20:
        lv, txt = ('中高', '90 天接触 %d 个供应商，比价范围较广' % s)
    elif s >= 8:
        lv, txt = ('中', '90 天接触 %d 个供应商，属正常询盘节奏' % s)
    else:
        lv, txt = ('低', '90 天仅接触 %d 个供应商，触点集中（更容易做独家）' % s)
    return (lv, txt)

def main_business(persona, msgs):
    t = (persona or {}).get('buyer_persona') or ''
    clicked = []
    for x in re.findall('Product Category:\\s*([^\\n]+)', t):
        leaf = x.strip().split('/')[-1].strip()
        if leaf and leaf not in clicked:
            clicked.append(leaf)
    strong = [(n, c) for n, c, _ in top_categories(persona, 6) if c >= 2]
    if clicked:
        extra = '；另有类目沟通 %s' % '、'.join(('%s×%d' % (n, c) for n, c in strong[:2])) if strong else ''
        return '**实际点开过**：%s%s' % ('、'.join(clicked[:2]), extra)
    if strong:
        return '；'.join(('%s（沟通 %d 次）' % (n, c) for n, c in strong[:2]))
    if msgs:
        return '无有效类目信号（平台记录的类目为随机浏览）'
    return '—'

def ask_for(name):
    return ASK.get(name) or ASK['_default']
RISK_WORDS = ('pt141', 'pt-141', 'nad+', 'ss31', 'kpv', 'peptid', 'glutationa', 'glutathione', '处方', '研究用肽')

def auto_profile(c):
    k = c.get('crm') or {}
    note = k.get('displayName') or ''
    tags = k.get('tags') or []
    stage = k.get('stage') or ''
    ms = c.get('messages') or []
    nb = sum((1 for m in ms if m.get('senderRole') == 'buyer'))
    ns = len(ms) - nb
    txt = ' '.join((m.get('content') or '' for m in ms)).lower()
    ch = c.get('channel') or 'TM'
    last_buyer = ''
    for m in reversed(ms):
        if m.get('senderRole') == 'buyer':
            last_buyer = (m.get('content') or '').strip()
            break
    if any((w in txt for w in RISK_WORDS)):
        grade = 'R'
        intent = '涉管制成分（肽类 / 谷胱甘肽等），不能以膳食补充剂承接'
        action = '书面划界并留存；可给氨基酸 / 肌酸 / 蛋白类替代方案看能否转化'
    elif '优质商机' in tags or '重要客户' in tags or stage == 'ORDER_NEGOTIATION' or any((w in note for w in ('大单', '大货', '样品客户', '已下样品', '已下单'))):
        grade = 'A'
        intent = note or last_buyer[:80] or ('阶段已达 %s' % stage if stage else ch + ' 询盘')
        action = '订单议价阶段的客户被晾着是流程问题：先回复，顺势把数量 / 交期 / 付款方式一次谈完' if stage == 'ORDER_NEGOTIATION' else '团队已标注为重点（标签 %s ｜ 备注 %s）—— 按备注里记录的方向推进' % ('、'.join(tags) or '-', note or '-')
    elif nb >= 2:
        grade = 'B'
        intent = last_buyer[:80] or note or ch + ' 询盘'
        action = '买家有持续互动：按其最后一条消息的具体问题给出可执行答复，并问首单量'
    else:
        grade = 'C'
        intent = last_buyer[:80] or note or ch + ' 询盘（无后续互动）'
        action = '低频培育：发一次资质 + 品类清单即可，别投入打样资源'
    return dict(grade=grade, intent=note or (last_buyer[:90] if last_buyer else ch + ' 询盘'), risk='', action=action, bg='', meddic=None, prob=None, talk=None, region='', tag='、'.join((t for t in tags if t)) or '', auto=True, _stage=stage, _note=note, _channel=ch, _nb=nb, _ns=ns)
QUALITY_TIERS = ['优质客户', '潜力客户', '普通客户', '无效 / 风险']
QCAP = {'chat': 12, 'info': 8, 'bg': 10, 'crm': 3}
QPILLAR_LABEL = [('chat', '聊天记录'), ('bg', '背调结论'), ('info', '客户信息'), ('crm', '内部CRM')]
MATURE_MARKETS = ('US', 'GB', 'UK', 'DE', 'FR', 'AU', 'CA', 'NL', 'BE', 'ES', 'IT', 'PL', 'SE', 'CH', 'AT', 'DK', 'NO', 'FI', 'IE', 'AE', 'SA', 'KW', 'IL', 'SG', 'JP', 'KR', 'MY', 'MX', 'BR', 'CL', 'CO', 'PE', 'AR', 'ZA')
INTENT_GROUPS = [('询价报价', ('price', 'quote', 'quotation', 'how much', 'cost', 'fob', 'exw', '报价', '价格', '单价', '多少钱')), ('数量MOQ', ('moq', 'minimum order', 'quantity', 'container', 'pallet', 'carton', '数量', '起订', '整柜', '装箱')), ('交期物流', ('lead time', 'shipping', 'delivery', 'eta', 'freight', 'air freight', 'sea freight', 'dhl', 'fedex', '交期', '发货', '物流', '到货', '海运', '空运')), ('样品打样', ('sample', 'samples', 'prototype', 'sample order', '样品', '打样', '寄样')), ('付款条款', ('payment', 'deposit', 'invoice', 'trade assurance', 'paypal', 'tt', 't/t', 'l/c', 'letter of credit', 'pi', '定金', '付款', '信用证', '形式发票')), ('OEM贴牌', ('oem', 'odm', 'private label', 'custom', 'customiz', 'logo', 'formula', 'flavor', '贴牌', '代工', '定制', '配方', '私标', '口味')), ('认证合规', ('coa', 'msds', 'gmp', 'iso', 'certificate', 'specification', 'spec sheet', 'label', 'ingredient', '认证', '检测', '标签', '规格', '成分'))]
CO_SUFFIX = re.compile("\\b([A-Z][A-Za-z&\\.\\'\\- ]{2,44}?(?:S\\.A\\.S|S\\.A|SAS|SRL|S\\.R\\.L|GmbH|LLC|Ltd|Limited|Inc|Pty|SDN\\s*BHD|B\\.V|BV|AB|Oy|SpA|Pte|Corp|Group|Trading|Imports?|Exports?|Distribut\\w*))\\b")
WEB_RE = re.compile('https?://|\\bwww\\.|(?<![\\w@])[a-z0-9\\-]{2,}\\.(?:com|net|org|io|co|br|mx|de|fr|uk|es|it|nl|au|in|kr|jp|sg|ae|sa|za|cl|pe|ar|cn|vn|th|id|ph)\\b', re.I)
TEL_RE = re.compile('\\+?\\d[\\d \\-()]{7,18}\\d')
ADDR_RE = re.compile('(?:calle|torre|galp[oó]n|avenida|av\\.|carretera|carrera|street|st\\.|road|rd\\.|floor|suite|box\\s*\\d+|no\\.\\s*\\d+)', re.I)
DEAL_WORDS = ('已下样品', '已下单', '已经下单', '在途', '首单', '大货', '大单', '成交', '已付款', '定金已付', 'order placed', 'ordered', 'deposit paid', 'purchase order')

def _kw(txt, kw):
    if len(kw) <= 4:
        return re.search('(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(kw), txt) is not None
    return kw in txt

def _span_days(ms):
    ds = sorted(set(((m.get('sendTime') or '')[:10] for m in ms or [] if (m.get('sendTime') or '')[:10])))
    if len(ds) < 2:
        return 1
    try:
        return max(1, (_date.fromisoformat(ds[-1]) - _date.fromisoformat(ds[0])).days + 1)
    except Exception:
        return 1

def identity_signals(msgs):
    raw = '\n'.join((m.get('content') or '' for m in msgs or []))
    out = []
    if CO_SUFFIX.search(raw):
        out.append('公司名')
    if WEB_RE.search(raw):
        out.append('网站')
    if any((len(re.sub('\\D', '', x)) >= 9 for x in TEL_RE.findall(raw))):
        out.append('电话')
    if ADDR_RE.search(raw):
        out.append('地址')
    return out

def quality_of(c, persona=None, strength=None):
    k = c.get('crm') or {}
    note = k.get('displayName') or ''
    tags = k.get('tags') or []
    stage = k.get('stage') or ''
    lvl = (c.get('contactLevel') or '') or ((persona or {}).get('buyer_level') or '')
    ms = c.get('messages') or []
    nb = sum((1 for m in ms if m.get('senderRole') == 'buyer'))
    ns = len(ms) - nb
    txt = '\n'.join((m.get('content') or '' for m in ms)).lower()
    st = strength or {}
    pm = persona_metrics(persona) if persona is not None else {}
    facts = chat_facts(ms)
    sigs = identity_signals(ms)
    days = _span_days(ms)
    zero = {'chat': 0, 'info': 0, 'bg': 0, 'crm': 0}
    if any((w in txt for w in RISK_WORDS)):
        return dict(tier='无效 / 风险', score=0, risk=True, pillars=dict(zero), pcap=dict(QCAP), reasons=['命中风险词：涉管制成分（肽类 / 谷胱甘肽等），不能以膳食补充剂承接'])
    if nb == 0:
        return dict(tier='无效 / 风险', score=0, risk=False, pillars=dict(zero), pcap=dict(QCAP), reasons=['买家全程未发言（只有系统卡片 / 我方单方消息），不构成真实询盘'])
    buckets = {'chat': [], 'info': [], 'bg': [], 'crm': []}

    def hit(b, add, why):
        buckets[b].append((why, add))
    if nb >= 4:
        hit('chat', 3, '买家发言 %d 条（高频互动）' % nb)
    elif nb >= 2:
        hit('chat', 2, '买家发言 %d 条（有跟进）' % nb)
    else:
        hit('chat', 1, '买家仅发言 1 条')
    if nb >= 2 and ns >= 1:
        hit('chat', 2, '双向沟通（买家 %d 条 / 我方 %d 条）' % (nb, ns))
    ihits = [g[0] for g in INTENT_GROUPS if any((_kw(txt, w) for w in g[1]))]
    if ihits:
        hit('chat', min(4, len(ihits)), '聊天谈到%s' % '、'.join(ihits[:5]))
    if facts.get('价格'):
        hit('chat', 2, '谈到具体单价：%s' % facts['价格'][:40])
    if facts.get('数量'):
        hit('chat', 1, '谈到具体数量：%s' % facts['数量'][:40])
    if days >= 14:
        hit('chat', 2, '沟通跨度 %d 天（长线跟进中）' % days)
    elif days >= 3:
        hit('chat', 1, '沟通跨度 %d 天' % days)
    g = (st.get('strength') or {}).get('level') or st.get('grade') or ''
    _sb = (st.get('strength') or {}).get('score')
    _sbase = '%s%s' % ((st.get('basis') or '')[:60], '（实力 %s 分）' % _sb if _sb is not None else '')
    if g == '强':
        hit('bg', 7, '实力评级=强：%s' % _sbase)
    elif g == '中-强':
        hit('bg', 6, '实力评级=中-强：%s' % _sbase)
    elif g == '中':
        hit('bg', 4, '实力评级=中：%s' % _sbase)
    elif g == '弱-中':
        hit('bg', 2, '实力评级=弱-中')
    elif g == '弱':
        hit('bg', 1, '实力评级=弱（仅线索级证据）')
    vf = st.get('verify') or ''
    ev_auto = st.get('evidence')
    if ev_auto is None:
        if len(vf) > 10 and (not any((w in vf for w in ('无公司名可查', '无公司名', '未识别', '无公开', '无可查', '无法核实', '未核验', '没有可核验', '无从下手', '未检索到', '查不到')))):
            hit('bg', 2, '公网核实已有结论：%s' % vf[:80])
    elif any((e in ('域名已注册', '官网在营', '工商库命中', '行业匹配', '域名未注册', '工商库无命中', '官网停放') for e in ev_auto)):
        hit('bg', 2, '公网核验有公开源结论：%s' % '、'.join(ev_auto))
    deal_src = '%s %s %s' % (st.get('scale') or '', st.get('rel') or '', txt)
    if any((w in deal_src for w in DEAL_WORDS)):
        hit('bg', 3, '背调/聊天抓到成交硬证据（已下单 / 在途 / 大货 / 已付款）')
    if lvl.endswith('4'):
        hit('info', 3, '平台买家等级 L4（最高）')
    elif lvl.endswith('3'):
        hit('info', 2, '平台买家等级 L3')
    elif lvl.endswith('2'):
        hit('info', 1, '平台买家等级 L2')
    cc = (((persona or {}).get('buyer_country_code') or c.get('contactCountry') or '') or '').upper()
    if cc:
        hit('info', 1, '国家/市场可识别：%s' % cc)
        if cc in MATURE_MARKETS:
            hit('info', 1, '成熟 / 高客单市场')
    if len(sigs) >= 2:
        hit('info', 2, '聊天透露 %s（主体可追溯）' % '、'.join(sigs[:4]))
    elif len(sigs) == 1:
        hit('info', 1, '聊天透露 %s' % sigs[0])
    sl = pm.get('sellers')
    if sl and sl >= 40:
        hit('info', 2, '90 天接触 %d 家供应商（采购极活跃）' % sl)
    elif sl and sl >= 20:
        hit('info', 1, '90 天接触 %d 家供应商' % sl)
    vw, lg = (pm.get('views'), pm.get('logins'))
    if vw and vw >= 100 or (lg and lg >= 10):
        hit('info', 1, '90 天平台活跃（浏览 %s / 登录 %s 天）' % (vw or '-', lg or '-'))
    hot = [t for t in tags if t in ('优质商机', '重要客户')]
    if hot:
        hit('crm', 2, '内部 CRM 标签「%s」' % '、'.join(hot))
    if stage == 'ORDER_NEGOTIATION':
        hit('crm', 2, '内部销售阶段=订单议价')
    elif stage == 'REQUIREMENT':
        hit('crm', 1, '内部销售阶段=需求确认')
    if any((w in note for w in ('已下样品', '已下单', '成交', '大单', '大货', '样品客户'))):
        hit('crm', 1, '内部备注显示已成交/大单：%s' % note[:24])
    ps = {b: min(QCAP[b], sum((x[1] for x in buckets[b]))) for b in QCAP}
    score = sum(ps.values())
    reasons = ['【%s】%s +%d' % (lab, why, add) for b, lab in QPILLAR_LABEL for why, add in buckets[b]]
    A, B, C, D = (ps['chat'], ps['info'], ps['bg'], ps['crm'])
    if A >= 7 and C >= 4 and (B >= 3) or (A >= 9 and B >= 5) or (C >= 8 and A + B >= 8):
        tier = '优质客户'
    elif A >= 4 and B + C >= 4 and (score >= 9) or score >= 14:
        tier = '潜力客户'
    elif score >= 4:
        tier = '普通客户'
    else:
        tier = '无效 / 风险'
    return dict(tier=tier, score=score, risk=False, pillars=ps, pcap=dict(QCAP), reasons=reasons, chat=A, info=B, bg=C, crm=D, span_days=days, signals=sigs)
