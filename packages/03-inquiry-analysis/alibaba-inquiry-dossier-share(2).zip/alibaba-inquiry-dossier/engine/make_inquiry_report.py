import csv
import io
import json
import os
import re
import sys
from datetime import datetime
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
INQ = os.path.join(HERE, 'inquiry')
from inquiry_analysis import ANALYSIS, REGION_PLAYBOOK
from inquiry_strength import STRENGTH
import inquiry_dossier as DO
import inquiry_charts as CH
from customer_rows import build_rows as _build_rows
from customer_table_html import report_extras as _report_extras, owner_stats_of as _owner_stats
import customer_table_html as CT
AUTO, AUTO_META, ENT = ({}, {}, {})
_vp = os.path.join(INQ, 'verify_auto.json')
if os.path.isfile(_vp):
    try:
        _v = json.load(open(_vp, encoding='utf-8'))
        AUTO = _v.get('buyers') or {}
        AUTO_META = dict(generated=_v.get('generated'), sources=_v.get('sources'))
    except Exception:
        AUTO = {}
_ep = os.path.join(INQ, 'entities.json')
if os.path.isfile(_ep):
    try:
        ENT = json.load(open(_ep, encoding='utf-8')).get('buyers') or {}
    except Exception:
        ENT = {}

def st_of(nm):
    s = STRENGTH.get(nm)
    if s:
        return s
    return AUTO.get(nm) or {}
GRADE_LABEL = {'A': 'A 重点推进', 'B': 'B 常规跟进', 'C': 'C 低优先', 'R': 'R 风险'}
GRADE_ORDER = {'A': 0, 'B': 1, 'C': 2, 'R': 3}
GRADE_COLOR = {'A': '#2e9e5b', 'B': '#1c5fa8', 'C': '#94a3b8', 'R': '#c0392b'}
STRENGTH_COLOR = {'强': '#2e9e5b', '中-强': '#3f8f57', '中': '#1c5fa8', '中（潜力型）': '#1c5fa8', '中（信息不足）': '#7a8794', '弱-中': '#a86a11', '弱': '#94a3b8', '弱（初期）': '#94a3b8', '弱（体量未知）': '#94a3b8', '待核验': '#c0392b', '不建议承接': '#c0392b'}
STAGE_LABEL = {'CONNECTION': '初次接触', 'REQUIREMENT': '需求确认', 'ORDER_NEGOTIATION': '订单议价', '': '未标注', None: '未标注'}
STAGE_COLOR = {'CONNECTION': '#94a3b8', 'REQUIREMENT': '#1c5fa8', 'ORDER_NEGOTIATION': '#2e9e5b'}

def esc(s):
    return str(s if s is not None else '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')

def md(s):
    t = esc(s)
    t = re.sub('\\*\\*(.+?)\\*\\*', '<b>\\1</b>', t)
    return t.replace('\n', '<br>')

def plain(s, n=None):
    t = re.sub('\\*\\*(.+?)\\*\\*', '\\1', str(s if s is not None else ''))
    t = t.replace('\n', ' ')
    if n:
        t = t[:n]
    return esc(t)

def load():
    conv = json.load(open(os.path.join(INQ, 'conversations.json'), encoding='utf-8'))
    buyers = json.load(open(os.path.join(INQ, 'buyers.json'), encoding='utf-8'))
    return (conv, buyers)

def persona_bits(p):
    t = ((p or {}).get('persona') or {}).get('buyer_persona') or ''
    if not t:
        return None
    v = re.search('Number of Products Viewed in the Last 90 Days:\\s*(\\d+)', t)
    l = re.search('Number of Login Days in the Last 90 Days:\\s*(\\d+)', t)
    cats = re.findall('Category Name:\\s*(.+)', t)
    clk = re.findall("User's Click Count on Products in This Category:\\s*(\\d+)", t)
    com = re.findall("User's Communication Count for Products in This Category:\\s*(\\d+)", t)
    top = cats[0].strip() if cats else '-'
    if top != '-' and clk:
        top += '（点击 %s / 沟通 %s）' % (clk[0], com[0] if com else '0')
    return {'views': v.group(1) if v else '-', 'logins': l.group(1) if l else '-', 'top': top}

def meddic_total(a):
    d = a.get('meddic') or {}
    return sum((d.get(k, 0) for k in ('M', 'E', 'D', 'Dp', 'I', 'C')))

def main():
    conv, buyers = load()
    win, store = (conv['window'], conv['store'])
    cs = conv['conversations']
    real = [c for c in cs if (c.get('contactName') or '') != 'Assistant Eva']
    eva = len(cs) - len(real)
    bmap = {b.get('contactName'): b for b in buyers}
    login = store.get('loginId') or ''
    label = '%s（主账号 %s）' % (login, store.get('name')) if login else store.get('name') or ''
    stats = {}
    _sp = os.path.join(INQ, 'fetch_stats.json')
    if os.path.isfile(_sp):
        try:
            stats = json.load(open(_sp, encoding='utf-8'))
        except Exception:
            stats = {}
    n_auto = 0
    for c in real:
        nm = c.get('contactName') or ''
        if nm not in ANALYSIS:
            ANALYSIS[nm] = DO.auto_profile(c)
            n_auto += 1
    analyzed_raw = [c for c in real if (ANALYSIS.get(c.get('contactName') or '') or {}).get('meddic')]
    _seen = {}
    for c in analyzed_raw:
        nm = c.get('contactName') or ''
        if nm not in _seen or len(c.get('messages') or []) > len(_seen[nm].get('messages') or []):
            _seen[nm] = c
    analyzed = list(_seen.values())
    from collections import Counter as _Counter
    qmap, qconv = ({}, {})
    _workbench_rows = (_build_rows() or ([], {}))[0]
    _workbench_strength = {r['name']: r['strength'] for r in _workbench_rows}
    for c in real:
        nm = c.get('contactName') or ''
        q = DO.quality_of(c, bmap.get(nm), dict(st_of(nm), strength=_workbench_strength[nm]))
        qconv[c.get('conversationId')] = q
        if nm not in qmap or q['score'] > qmap[nm]['score']:
            qmap[nm] = q
    qcnt = _Counter((q['tier'] for q in qmap.values()))
    QTIERS = ['优质客户', '潜力客户', '普通客户', '无效 / 风险']
    QCOLOR = {'优质客户': '#2e9e5b', '潜力客户': '#1c5fa8', '普通客户': '#94a3b8', '无效 / 风险': '#c0392b'}
    PILLAR_COLOR = {'chat': '#1c5fa8', 'bg': '#2e9e5b', 'info': '#b8860b', 'crm': '#94a3b8'}
    PILLAR_SHORT = {'chat': '聊天记录', 'bg': '背调结论', 'info': '客户信息', 'crm': '内部CRM'}

    def pillarbar(q):
        ps = (q or {}).get('pillars') or {}
        if not ps:
            return ''
        cap = (q or {}).get('pcap') or DO.QCAP
        out = []
        for b in ('chat', 'bg', 'info', 'crm'):
            v, m = (ps.get(b, 0), cap.get(b, 1))
            col = PILLAR_COLOR[b] if v else '#cbd5e1'
            out.append('<span style="display:inline-block;padding:1px 6px;margin:0 3px 3px 0;border-radius:4px;font-size:10.5px;font-weight:700;color:#fff;background:%s" title="%s %d/%d">%s %d/%d</span>' % (col, PILLAR_SHORT[b], v, m, PILLAR_SHORT[b], v, m))
        return ''.join(out)
    pending = []
    for c in real:
        ms = c.get('messages') or []
        if ms and ms[-1].get('senderRole') == 'buyer' and ('[Card]' not in (ms[-1].get('content') or '')):
            pending.append((c, ms[-1]))

    def gk(c):
        return GRADE_ORDER.get((ANALYSIS.get(c.get('contactName') or '') or {}).get('grade', 'C'), 2)
    real_sorted = sorted(real, key=lambda c: (gk(c), -meddic_total(ANALYSIS.get(c.get('contactName') or '') or {})))
    d0, d1 = (win['since'][:10].replace('-', ''), win['until'][:10].replace('-', ''))

    def probnum(c):
        p = (ANALYSIS.get(c.get('contactName') or '') or {}).get('prob', '0')
        m = re.search('(\\d+)', str(p))
        return int(m.group(1)) if m else 0
    ranked = sorted(analyzed, key=lambda c: -probnum(c))
    H = []
    H.append('<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">')
    H.append('<meta name="viewport" content="width=device-width,initial-scale=1">')
    H.append('<title>询盘客户背调与资格评估 %s</title>' % esc(label))
    H.append('<style>\n*{box-sizing:border-box}\nbody{margin:0;background:#eef1f5;color:#1f2733;font:13px/1.68 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif}\n.wrap{max-width:1320px;margin:0 auto;padding:22px}\n.rhead{background:#16324f;color:#fff;border-radius:12px;padding:20px 24px;margin-bottom:16px}\n.rt{font-size:21px;font-weight:800}.rs{margin-top:7px;font-size:12px;opacity:.9;line-height:1.85}\n.rprint{background:#f5c518;color:#1f2733;border:0;border-radius:8px;padding:9px 16px;font-size:13px;font-weight:700;cursor:pointer}\n.flex{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}\nsection{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:16px 18px;margin-bottom:14px}\nh2{font-size:16px;font-weight:800;color:#16324f;margin:0 0 14px;padding-left:10px;border-left:4px solid #f5c518}\nh2 .hsub{font-size:12px;font-weight:500;color:#7a8794;margin-left:8px}\nh3{font-size:14px;font-weight:800;color:#16324f;margin:18px 0 9px}\n.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(138px,1fr));gap:10px;margin-bottom:14px}\n.kpi{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px}\n.kpi .l{font-size:12px;color:#7a8794}.kpi .v{font-size:24px;font-weight:800;color:#16324f;margin-top:2px}\n.kpi .s{font-size:11px;color:#93a1b0}\n.kpi.alert{border-color:#f7c7c7;background:#fff6f6}.kpi.alert .v{color:#c0392b}\ntable{width:100%;border-collapse:collapse}\nth{background:#f1f5f9;color:#334155;font-size:12px;text-align:left;padding:9px 8px;border-bottom:2px solid #e2e8f0;white-space:nowrap}\ntd{padding:9px 8px;border-bottom:1px solid #eef2f6;font-size:12.5px;vertical-align:top}\ntr:hover td{background:#f8fbfd}\n.badge{display:inline-block;padding:2px 9px;border-radius:10px;font-size:11px;font-weight:700;white-space:nowrap}\n.b-A{background:#e8f5e9;color:#1b7a35}.b-B{background:#e7f0fb;color:#1c5fa8}\n.b-C{background:#f1f3f5;color:#6b7280}.b-R{background:#fdecea;color:#c0392b}\n.mc{text-align:center;font-variant-numeric:tabular-nums}\n.mc .s2{display:inline-block;width:17px;height:17px;line-height:17px;border-radius:4px;font-size:11px;font-weight:700;color:#fff}\n.s2-0{background:#d7dde5}.s2-1{background:#e8a33d}.s2-2{background:#2e9e5b}\n.pbar{display:inline-block;min-width:44px;padding:2px 8px;border-radius:9px;font-size:11px;font-weight:700;background:#eef2f7;color:#334155}\n.p-hi{background:#e8f5e9;color:#1b7a35}.p-mid{background:#fff5e6;color:#a86a11}.p-lo{background:#f1f3f5;color:#6b7280}\n.bcard{border:1px solid #e2e8f0;border-radius:10px;margin-bottom:13px;overflow:hidden}\n.bcard .bh{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:11px 15px;background:#f7fafc;border-bottom:1px solid #e8eef4}\n.bcard .bn{font-size:14.5px;font-weight:800;color:#16324f}\n.bcard .bm{font-size:11.5px;color:#7a8794;margin-top:2px}\n.bcard .bb{padding:13px 15px}\n.row{margin-bottom:9px}\n.row .k{display:inline-block;min-width:70px;color:#8b98a6;font-size:11.5px;font-weight:700;vertical-align:top}\n.row .v{display:inline;font-size:12.5px}\n.act{background:#fffdf3;border-left:3px solid #f5c518;padding:9px 12px;border-radius:0 6px 6px 0;margin-top:9px;font-size:12.5px}\n.risk{background:#fff6f6;border-left:3px solid #e74c3c;padding:9px 12px;border-radius:0 6px 6px 0;margin-top:9px;font-size:12.5px}\n.reg{background:#f4f8fd;border-left:3px solid #3d7ebd;padding:9px 12px;border-radius:0 6px 6px 0;margin-top:9px;font-size:12.5px}\n.chat{margin-top:11px;border-top:1px dashed #e2e8f0;padding-top:10px}\n.msg{display:flex;gap:9px;margin-bottom:5px;font-size:12px}\n.msg .t{color:#a0aab5;white-space:nowrap;font-variant-numeric:tabular-nums}\n.msg .w{font-weight:700;white-space:nowrap;min-width:34px}\n.msg.in .w{color:#1c5fa8}.msg.out .w{color:#8a6d3b}\n.msg .c{word-break:break-word}\n.script{background:#0f1f2e;color:#e6edf3;border-radius:8px;padding:13px 15px;margin-top:11px;\n  font:12px/1.75 Consolas,Menlo,"Microsoft YaHei",monospace;white-space:pre-wrap;word-break:break-word}\n.script .h{color:#f5c518;font-weight:700;font-family:inherit}\n.copy{float:right;background:#f5c518;color:#1f2733;border:0;border-radius:6px;padding:3px 10px;font-size:11px;font-weight:700;cursor:pointer}\n.mono{font-family:Consolas,Menlo,monospace;font-size:11.5px;color:#64748b}\n.pill{display:inline-block;background:#fdecea;color:#c0392b;border-radius:9px;padding:1px 8px;font-size:11px;font-weight:700}\n.pri{display:inline-block;background:#16324f;color:#fff;border-radius:9px;padding:1px 8px;font-size:11px;font-weight:700}\n.foot{text-align:center;color:#93a1b0;font-size:11.5px;padding:14px 0}\n.dash{display:grid;gap:14px}\n.dash.c2{grid-template-columns:minmax(240px,300px) 1fr}\n.dash.c2b{grid-template-columns:1fr 1fr}\n@media(max-width:900px){.dash.c2,.dash.c2b{grid-template-columns:1fr}}\n.panel{border:1px solid #e8eef4;border-radius:10px;padding:13px 15px;background:#fcfdff}\n.panel .pt{font-size:12.5px;font-weight:800;color:#16324f;margin-bottom:9px}\n.panel .ps{font-size:11.5px;color:#8b98a6;margin-top:8px;line-height:1.6}\n.toc{position:sticky;top:0;z-index:60;background:rgba(255,255,255,.94);backdrop-filter:blur(6px);\n border:1px solid #dbe3ea;border-radius:10px;padding:8px 12px;margin:0 0 14px;display:flex;gap:6px;flex-wrap:wrap;align-items:center}\n.toc a{font-size:12px;color:#16324f;text-decoration:none;padding:4px 9px;border-radius:99px;background:#eef2f6}\n.toc a:hover{background:#16324f;color:#fff}\n.toc .tbtn{font-size:12px;border:1px solid #c9d4e0;background:#fff;color:#47566b;border-radius:99px;padding:4px 10px;cursor:pointer}\n.toc .tbtn:hover{background:#16324f;color:#fff;border-color:#16324f}\nsection{scroll-margin-top:58px}\nsection h2{cursor:pointer;user-select:none}\nsection h2::after{content:\'\x15BE\';float:right;color:#94a3b8;font-size:13px}\nsection.collapsed h2::after{content:\'\x15B8\'}\nsection.collapsed > *:not(h2){display:none}\n.chips{display:flex;gap:6px;flex-wrap:wrap;margin:2px 0 12px}\n.chips a{font-size:11.5px;color:#1c5fa8;background:#eaf1fa;border-radius:99px;padding:3px 9px;text-decoration:none}\n.chips a:hover{background:#1c5fa8;color:#fff}\n@media print{body{background:#fff}.rprint,.copy,.toc,.chips{display:none}\n section.collapsed > *:not(h2){display:revert !important}\n section,.bcard{break-inside:avoid;page-break-inside:avoid}}\n</style></head><body><div class="wrap">')
    H.append('<div class="rhead"><div class="flex"><div>')
    H.append('<div class="rt">询盘客户背调与资格评估</div>')
    H.append('<div class="rs">店铺账号 <b>%s</b> ｜ 窗口 %s ~ %s<br><b>会话 %d 个</b>（询盘 %d + TM %d；已剔除 %d 个机器人卡）｜ <b>消息 %d 条</b>（抓取覆盖 %d 个子账号）<br>评估方法：平台数据核查 + 公司核实 + MEDDIC 六维打分 + SPIN 跟进话术 ｜ 其中 <b>%d 个</b>高优先客户做了逐条精细研判，其余 <b>%d 个</b>按平台数据自动分级 ｜ 生成 %s</div>' % (esc(label), esc(win['since'][:16].replace('T', ' ')), esc(win['until'][:16].replace('T', ' ')), len(cs), stats.get('inquiry_conversations', '-'), stats.get('tm_conversations', '-'), eva, sum((len(c.get('messages') or []) for c in cs)), stats.get('accounts', '-'), len(analyzed), n_auto, datetime.now().strftime('%Y-%m-%d %H:%M')))
    H.append('</div><button class="rprint" onclick="window.print()">打印 / 存为PDF</button></div></div>')
    nA = sum((1 for c in real if (ANALYSIS.get(c.get('contactName') or '') or {}).get('grade') == 'A'))
    nR = sum((1 for c in real if (ANALYSIS.get(c.get('contactName') or '') or {}).get('grade') == 'R'))
    talkn = sum((1 for c in real if (ANALYSIS.get(c.get('contactName') or '') or {}).get('talk')))
    H.append('<div class="kpis">')
    H.append('<div class="kpi" style="border-left:4px solid #2e9e5b"><div class="l">优质客户</div><div class="v">%d</div><div class="s">聊天 + 背调 + 客户信息三支柱均有硬证据</div></div>' % qcnt.get('优质客户', 0))
    H.append('<div class="kpi" style="border-left:4px solid #1c5fa8"><div class="l">潜力客户</div><div class="v">%d</div><div class="s">有真实互动，可培育</div></div>' % qcnt.get('潜力客户', 0))
    H.append('<div class="kpi" style="border-left:4px solid #c0392b"><div class="l">无效 / 风险</div><div class="v">%d</div><div class="s">买家未发言 / 泛泛询价 / 涉管制成分</div></div>' % qcnt.get('无效 / 风险', 0))
    H.append('<div class="kpi"><div class="l">真实买家会话</div><div class="v">%d</div><div class="s">已剔除 %d 个机器人卡</div></div>' % (len(real), eva))
    H.append('<div class="kpi alert"><div class="l">待我方回复</div><div class="v">%d</div><div class="s">最后一句是买家说的</div></div>' % len(pending))
    H.append('<div class="kpi"><div class="l">A 级重点推进</div><div class="v">%d</div><div class="s">含自动分级</div></div>' % nA)
    H.append('<div class="kpi alert"><div class="l">R 级风险</div><div class="v">%d</div><div class="s">合规 / 主体存疑</div></div>' % nR)
    H.append('<div class="kpi"><div class="l">已备好话术</div><div class="v">%d</div><div class="s">可直接复制发送</div></div>' % talkn)
    H.append('</div>')
    H.append('<div class="toc">')
    _sep = '<span style="display:inline-block;width:1px;height:15px;background:#cfd8e3;margin:0 7px;vertical-align:middle"></span>'
    _grp = '<span style="font-size:11px;color:#8a98a6;font-weight:800;letter-spacing:.5px;margin:0 4px 0 1px">%s</span>'
    for _gi, (_gname, _items) in enumerate([('必读', [('sr', '结论与行动'), ('sb', '背调结论汇总')]), ('要执行', [('s1', '优先行动+话术'), ('s12', '成交卡点'), ('s9', '分层总表')]), ('看数据', [('s0', '仪表盘'), ('s4', '分级总表'), ('s11', '业务员'), ('s10', '优质客户')]), ('要明细', [('s2', 'MEDDIC'), ('s3', '背调·主体'), ('s13', '背调·公司'), ('s5', '逐个深度背调'), ('s6', '地区打法'), ('s7', '风险合规'), ('s8', '运营问题')])]):
        if _gi:
            H.append(_sep)
        H.append(_grp % _gname)
        for _a, _t in _items:
            H.append('<a href="#%s">%s</a>' % (_a, _t))
    H.append(_sep)
    H.append('<button class="tbtn" onclick="collapseAll(true)">全部折叠</button><button class="tbtn" onclick="collapseAll(false)">全部展开</button><button class="tbtn" onclick="window.scrollTo({top:0,behavior:\'smooth\'})">回到顶部</button>')
    H.append('<div class="mono" style="font-size:11.5px;color:#7a8794;margin-top:6px"><b>怎么读：</b>只有 3 分钟 → 看「结论与行动」（评估 / 方向 / 动作三段）；要动手 → 「优先行动+话术」「成交卡点」；要查细节 → 「要明细」里的章节默认折叠，点标题展开。</div></div>')
    try:
        _rv = _build_rows()
        if _rv:
            _rrows = _rv[0]
            import deal_blocker as _DB2
            _bst = _DB2.aggregate(_rrows)
            import inq_brief as _IB
            H.append('<section id="sr"><h2>结论与行动 <span class="hsub">三问：这批客户什么水平（评估）→ 往哪打（方向）→ 这周做什么（动作）</span></h2>')
            H.append('<div class="ctbl">%s</div>' % _IB.build(_rrows, _bst))
            H.append('</section>')
            H.append('<section id="sb"><h2>背调结论汇总 <span class="hsub">邮箱 → 域名 → 官网 → 工商库 → Gravatar → YouTube → 独立站 → 社媒，八路证据一张表，每个客户一句结论 + 下一步</span></h2>')
            H.append('<div class="ctbl">%s</div>' % CT.frag_backdive(_rrows))
            H.append('</section>')
    except Exception as _e:
        print('  复盘要点生成失败（不阻断报告）:', _e)
    cnt = {'A': 0, 'B': 0, 'C': 0, 'R': 0}
    for c in real:
        g = (ANALYSIS.get(c.get('contactName') or '') or {}).get('grade', 'C')
        cnt[g] = cnt.get(g, 0) + 1
    donut_items = [(GRADE_LABEL[k], cnt[k], GRADE_COLOR[k]) for k in ('A', 'B', 'C', 'R')]
    plot = []
    for c in analyzed:
        nm = c.get('contactName') or ''
        a = ANALYSIS.get(nm) or {}
        plot.append((nm, probnum(c), meddic_total(a), len(c.get('messages') or []), a.get('grade', 'C')))
    wait_items = []
    for c, last in pending:
        try:
            w = (datetime.now() - datetime.fromisoformat(last.get('sendTime'))).days
        except Exception:
            w = 0
        wait_items.append(((c.get('contactName') or '')[:14], w))
    wait_items.sort(key=lambda x: -x[1])
    radars = []
    for c in ranked[:6]:
        nm = c.get('contactName') or ''
        a = ANALYSIS.get(nm) or {}
        d = a.get('meddic') or {}
        radars.append((nm, a.get('grade', 'C'), [d.get(k, 0) for k in ('M', 'E', 'D', 'Dp', 'I', 'C')]))
    H.append('<section id="s0"><h2>决策仪表盘 <span class="hsub">一屏看全局：结构、优先级、紧迫度</span></h2>')
    H.append('<div class="dash c2">')
    H.append('<div class="panel"><div class="pt">客户分级构成</div>%s<div class="ps">A 级 %d 个值得投打样资源，R 级 %d 个先核验主体再谈。</div></div>' % (CH.donut(donut_items), cnt['A'], cnt['R']))
    H.append('<div class="panel"><div class="pt">优先级矩阵 <span style="font-weight:400;color:#8b98a6">横轴 拿单概率 · 纵轴 MEDDIC 资格分 · 气泡 消息量 · 颜色 分级</span></div>%s<div class="ps">右上「优先攻」= 资格高且概率高，今天就要动；左上「培育」= 资格好但还没到火候；右下「快赢」= 好谈但体量小；左下「暂放」。</div></div>' % CH.scatter(sorted(plot, key=lambda p: -p[2])))
    H.append('</div>')
    if wait_items:
        H.append('<div class="dash c2b" style="margin-top:14px">')
        H.append('<div class="panel"><div class="pt">待我方回复的等待天数 <span style="font-weight:400;color:#8b98a6">≥3 天标红</span></div>%s</div>' % CH.barh(wait_items, unit=' 天', hi_from=3))
        from collections import Counter
        ccn = Counter()
        for c in real:
            b = bmap.get(c.get('contactName')) or {}
            p = b.get('persona') or {}
            code = p.get('buyer_country_code') or c.get('contactCountry') or '未知'
            ccn[code] += 1
        H.append('<div class="panel"><div class="pt">买家国家分布</div>%s</div>' % CH.barh(sorted(ccn.items(), key=lambda x: -x[1])[:9], unit=' 人', rowh=24))
        H.append('</div>')
    sord = ['CONNECTION', 'REQUIREMENT', 'ORDER_NEGOTIATION']
    scnt = {}
    for c in real:
        sk = (c.get('crm') or {}).get('stage') or ''
        scnt[sk] = scnt.get(sk, 0) + 1
    stages = [(STAGE_LABEL.get(k, k), scnt.get(k, 0), STAGE_COLOR.get(k, '#94a3b8')) for k in sord]
    un = scnt.get('', 0)
    if un:
        stages.append(('未标注', un, '#cbd5e1'))
    if any((v for _, v, _ in stages)):
        H.append('<div class="dash" style="margin-top:14px"><div class="panel"><div class="pt">内部 CRM 销售阶段 <span style="font-weight:400;color:#8b98a6">运营在后台自己打的阶段 —— 比任何算法推断都准</span></div>%s<div class="ps">越往下越接近成交。「订单议价」阶段的客户还被晾着，说明是流程问题，不是客户问题。</div></div></div>' % CH.funnel(stages))
    H.append('<h3>客户质量分层 <span style="font-weight:400;color:#8a98a6;font-size:12px">档位由「聊天记录 / 背调结论 / 客户信息」三类客观证据决定，内部 CRM 标签只作辅助加分</span></h3>')
    H.append('<div class="dash c2">')
    H.append('<div class="panel"><div class="pt">质量构成（按买家去重，共 %d 个买家）</div>%s<div class="ps">优质 %d ｜ 潜力 %d ｜ 普通 %d ｜ 无效·风险 %d。</div><div class="ps" style="margin-top:6px"><b>四支柱权重</b>（每次判定都逐条列出命中项）：<br><span style="display:inline-block;padding:1px 6px;border-radius:4px;font-size:10.5px;font-weight:700;color:#fff;background:#1c5fa8">聊天记录 ≤12</span> <span style="display:inline-block;padding:1px 6px;border-radius:4px;font-size:10.5px;font-weight:700;color:#fff;background:#2e9e5b">背调结论 ≤10</span> <span style="display:inline-block;padding:1px 6px;border-radius:4px;font-size:10.5px;font-weight:700;color:#fff;background:#b8860b">客户信息 ≤8</span> <span style="display:inline-block;padding:1px 6px;border-radius:4px;font-size:10.5px;font-weight:700;color:#fff;background:#94a3b8">内部CRM ≤3</span><br>聊天 = 意图类型（询价/数量/交期/样品/付款/OEM/认证）+ 具体单价与数量 + 双向互动 + 沟通跨度；背调 = 主体实力评级 + 公网核实结论 + 是否已有成交/在途；客户信息 = 公司/地址/电话/网站等身份线索 + 国家与市场 + 平台等级 + 90 天采购活跃度。<br><b>档位门槛</b>：优质 = 聊天与背调同时达标（或深聊+身份可核）；潜力 = 有真实互动且至少两支柱有分；普通 = 单项有分；无效 = 买家未发言 / 泛泛询价 / 涉管制成分。</div></div>' % (len(qmap), CH.donut([(t, qcnt.get(t, 0), QCOLOR[t]) for t in QTIERS if qcnt.get(t)]), qcnt.get('优质客户', 0), qcnt.get('潜力客户', 0), qcnt.get('普通客户', 0), qcnt.get('无效 / 风险', 0)))
    top_q = sorted([(v['score'], k, v) for k, v in qmap.items() if v['tier'] == '优质客户'], reverse=True)[:16]
    H.append('<div class="panel"><div class="pt">优质客户清单（前 %d 个）<span style="font-weight:400;color:#8b98a6">含四支柱得分与命中依据</span></div>' % len(top_q))
    H.append('<table style="margin-top:2px"><tbody>')
    for sc, nm, q in top_q:
        c0 = next((x for x in real if (x.get('contactName') or '') == nm), {})
        note = ((c0.get('crm') or {}).get('displayName') or '').strip()
        why = '；'.join(q['reasons'][:5])
        tail = '\u3000·\u3000' + esc(note[:24]) if note else ''
        H.append('<tr><td style="white-space:nowrap"><b>%s</b><div class="mono">%s 分%s</div><div style="margin-top:4px">%s</div></td><td>%s</td></tr>' % (esc(nm[:18]), sc, tail, pillarbar(q), md(why)))
    H.append('</tbody></table></div>')
    H.append('</div>')
    H.append('</section>')
    H.append('<section id="s1"><h2>一、优先行动 <span class="hsub">按等待时长排序 · 每条都配了可直接复制的英文回复</span></h2>')
    rows = []
    for c, last in pending:
        a = ANALYSIS.get(c.get('contactName') or '') or {}
        try:
            wait = (datetime.now() - datetime.fromisoformat(last.get('sendTime'))).days
        except Exception:
            wait = 0
        rows.append((wait, c, last, a))
    rows.sort(key=lambda x: (-x[0], GRADE_ORDER.get(x[3].get('grade', 'C'), 2)))
    H.append('<table><thead><tr><th>等待</th><th>客户</th><th>渠道</th><th>等级</th><th>接待</th><th>客户最后一句</th><th>为什么急</th></tr></thead><tbody>')
    for wait, c, last, a in rows:
        nm = c.get('contactName') or ''
        H.append('<tr><td>%s</td><td><b>%s</b><div class="mono">%s</div></td><td>%s</td><td><span class="badge b-%s">%s</span></td><td>%s</td><td>%s</td><td>%s</td></tr>' % ('<span class="pill">%d 天</span>' % wait if wait >= 3 else '<span class="mono">%d 天</span>' % wait, esc(nm), esc(c.get('contactLoginId')), esc(c.get('channel') or 'TM'), a.get('grade', 'C'), GRADE_LABEL.get(a.get('grade', 'C'), ''), esc('/'.join(c.get('_owners') or [])), esc((last.get('content') or '')[:90]), md(a.get('risk') or a.get('intent') or '')))
    H.append('</tbody></table>')
    H.append('<h3>可直接复制的跟进话术（英文原文，改方括号内容即可发）</h3>')
    for wait, c, last, a in rows:
        if not a.get('talk'):
            continue
        H.append('<div style="margin-bottom:11px"><div style="font-size:12.5px;font-weight:700;color:#16324f;margin-bottom:5px">%s · 等待 %d 天 · %s</div>' % (esc(c.get('contactName')), wait, esc(a.get('intent', ''))[:60]))
        H.append('<div class="script">%s</div></div>' % esc(a['talk'].strip()))
    H.append('</section>')
    H.append('<section id="s2"><h2>二、MEDDIC 资格评估 <span class="hsub">M 痛点量化 / E 决策人 / D 决策标准 / D 决策流程 / I 痛点识别 / C 内部支持</span></h2>')
    H.append('<div class="mono" style="margin-bottom:10px">打分 0-2（灰=0 未触及，橙=1 部分，绿=2 明确），满分 12。概率为结合地区门槛后的综合估计，不是纯数学结果。</div>')
    H.append('<div class="mono" style="margin-bottom:8px">精细评估覆盖 <b>%d 个</b>高优先客户（其余 %d 个按平台数据自动分级，见「四、客户分级总表」）。</div>' % (len(analyzed), n_auto))
    H.append('<table><thead><tr><th>客户</th><th>等级</th>' + ''.join(('<th class="mc">%s</th>' % k for k in ('M', 'E', 'D', 'D', 'I', 'C'))) + '<th class="mc">合计</th><th class="mc">拿单概率</th><th>关键判断</th></tr></thead><tbody>')
    for c in analyzed:
        nm = c.get('contactName') or ''
        a = ANALYSIS.get(nm) or {}
        d = a.get('meddic') or {}
        tot = meddic_total(a)
        pv = str(a.get('prob') or '-')
        pn = probnum(c)
        pcls = 'p-hi' if pn >= 60 else 'p-mid' if pn >= 30 else 'p-lo'
        H.append('<tr><td><b>%s</b></td><td><span class="badge b-%s">%s</span></td>' % (esc(nm), a.get('grade', 'C'), a.get('grade', 'C')))
        for k in ('M', 'E', 'D', 'Dp', 'I', 'C'):
            v = d.get(k, 0)
            H.append('<td class="mc"><span class="s2 s2-%d">%d</span></td>' % (v, v))
        H.append('<td class="mc"><b>%d</b>/12</td>' % tot)
        H.append('<td class="mc"><span class="pbar %s">%s</span></td>' % (pcls, esc(pv)))
        H.append('<td>%s</td></tr>' % plain(a.get('risk') or a.get('intent') or '', 74))
    H.append('</tbody></table>')
    H.append('<h3>Top 6 资格画像 <span style="font-weight:400;color:#8a98a6;font-size:12px">六轴各 0-2 分，越外圈越充分 —— 一眼看出短板在哪</span></h3>')
    H.append(CH.radar_grid(radars, cols=3))
    H.append('<div class="mono">六轴：痛点量化、决策人、决策标准、决策流程、痛点识别、内部支持，各 0–2 分。分数表示当前证据充分程度，不代表客户最终价值。</div>')
    H.append('</section>')

    def _bucket(g):
        g = g or ''
        if g.startswith('强'):
            return '强'
        if g.startswith('中'):
            return '中'
        if g.startswith('弱'):
            return '弱'
        return '待核验 / 不承接'
    bcnt = {}
    for c in real_sorted:
        s = st_of(c.get('contactName') or '')
        b = _bucket(s.get('grade'))
        bcnt[b] = bcnt.get(b, 0) + 1
    borders = ['强', '中', '弱', '待核验 / 不承接']
    H.append('<section id="s3"><h2>三、客户主体档案 <span class="hsub">公司 · 人员 · 规模 · 主营 · 影响力 · 谈判杠杆</span></h2>')
    H.append('<div class="mono" style="margin-bottom:10px">数据来源按可信度排序：<b>①平台 CRM 字段</b>（销售阶段 / 内部标签 / 会话备注 / 关系建立时间，是销售团队自己打的，最硬）＞ <b>②聊天原文里的具体数字</b>（数量 / 单价 / 包装规格）＞ <b>③公网核实</b>＞ ④平台行为。公网查不到不等于没实力 —— 恰恰相反，「有历史成交 + 谈定单价」比任何工商资料都可靠。</div>')
    if AUTO:
        GORD = ['中-强', '中', '弱-中', '弱', '待核验']
        GCOL = {'中-强': '#3f8f57', '中': '#1c5fa8', '弱-中': '#a86a11', '弱': '#94a3b8', '待核验': '#c0392b'}
        gcnt = _Counter(((AUTO.get(nm) or {}).get('grade') or '待核验' for nm in AUTO))
        ndom = sum((1 for v in AUTO.values() if (v.get('rdap') or {}).get('domain')))
        nreg_ok = sum((1 for v in AUTO.values() if (v.get('rdap') or {}).get('registered')))
        nreg_no = sum((1 for v in AUTO.values() if (v.get('rdap') or {}).get('registered') is False))
        nsite = sum((1 for v in AUTO.values() if (v.get('site') or {}).get('reachable') and (not (v.get('site') or {}).get('parked'))))
        npark = sum((1 for v in AUTO.values() if (v.get('site') or {}).get('parked')))
        nch = sum((1 for v in AUTO.values() if (v.get('registry') or {}).get('hit')))
        nch_no = sum((1 for v in AUTO.values() if (v.get('registry') or {}).get('supported') and (v.get('registry') or {}).get('hit') is False))
        nsup = sum((1 for v in AUTO.values() if (v.get('registry') or {}).get('supported') is False and v.get('registry')))
        H.append('<h3>3-0 主体公网核验（自动） <span style="font-weight:400;color:#8a98a6;font-size:12px">对每个客户的可核验主体跑一遍公开数据源 —— 查过什么、查到什么、查不到的为什么</span></h3>')
        n_web = sum((gcnt.get(g, 0) for g in ('中-强', '中')))
        n_clue = sum((gcnt.get(g, 0) for g in ('弱-中', '弱')))
        n_ctry = sum((1 for v in ENT.values() if v.get('country')))
        H.append('<div class="kpis">')
        H.append('<div class="kpi" style="border-left:4px solid #2e9e5b"><div class="l">有公网实证</div><div class="v">%d</div><div class="s">域名/官网/工商库查到实据</div></div>' % n_web)
        H.append('<div class="kpi" style="border-left:4px solid #a86a11"><div class="l">线索级可追溯</div><div class="v">%d</div><div class="s">有公司名/电话/地址/邮箱可核</div></div>' % n_clue)
        H.append('<div class="kpi alert"><div class="l">待核验</div><div class="v">%d</div><div class="s">无任何可核验主体信息</div></div>' % gcnt.get('待核验', 0))
        H.append('<div class="kpi"><div class="l">国家可识别</div><div class="v">%d<small>/%d</small></div><div class="s">登录名前缀即国家码，100%% 覆盖</div></div>' % (n_ctry, len(ENT) or len(AUTO)))
        H.append('</div>')
        H.append('<div class="ps" style="margin:-4px 0 10px">口径：<b>有公网实证</b>（%d）＝ 域名已注册且在营官网 / 工商库命中；<b>线索级可追溯</b>（%d）＝ 聊天里给出了公司名、电话、地址或企业邮箱，但还没查实；<b>待核验</b>（%d）＝ 这些买家全身上下只有一个昵称，公开渠道无从下手，只能向客户索取。国家用登录名前 2 位（ISO 码）判定，不依赖客户自填，比平台画像里的国家字段覆盖高得多。</div>' % (n_web, n_clue, gcnt.get('待核验', 0)))
        H.append('<div class="dash c2">')
        H.append('<div class="panel"><div class="pt">核验结果分布</div>%s<div class="ps">%s</div></div>' % (CH.donut([(g, gcnt.get(g, 0), GCOL[g]) for g in GORD if gcnt.get(g)]), ' ｜ '.join(('%s %d' % (g, gcnt.get(g, 0)) for g in GORD if gcnt.get(g)))))
        H.append('<div class="panel"><div class="pt">用了哪些源、拿到什么</div><table style="margin-top:2px"><tbody><tr><td><b>RDAP</b><div class="mono">rdap.org</div></td><td>域名是否注册、注册/到期日、注册商</td><td class="mono">查到 %d 个域名：已注册 %d ｜ <b>未注册 %d</b></td></tr><tr><td><b>客户官网</b><div class="mono">站点抓取</div></td><td>是否在营 / 是否停放页 / 行业是否匹配 / 联系方式</td><td class="mono">在营 %d ｜ 停放或待售 %d</td></tr><tr><td><b>英国公司注册处</b><div class="mono">Companies House</div></td><td>按公司名检索主体、公司号、状态</td><td class="mono">命中 %d ｜ 未命中 %d ｜ 该国无免费库 %d</td></tr><tr><td><b>Gravatar</b><div class="mono">个人邮箱核验</div></td><td>该邮箱是否注册过头像（等于「真人日常在用」的旁证）</td><td class="mono">查了 %d 个邮箱，命中 %d 个</td></tr><tr><td><b>YouTube</b><div class="mono">用户名存在性</div></td><td>由邮箱本地段/客户给的用户名推断同名频道是否存在</td><td class="mono">查了 %d 个用户名，命中 %d 个</td></tr><tr><td><b>不可用源（如实标注）</b></td><td>USPTO（403）｜ bizapedia（订阅）｜ OpenCorporates（JS）｜ <b>LinkedIn 999</b>｜ <b>Instagram 登录墙</b>｜ <b>TikTok 无法区分</b>｜ <b>Facebook 拦截</b>｜ <b>Bing 搜索返回无关结果</b>｜ <b>DuckDuckGo 人机验证</b>｜ <b>emailrep.io 无 key 限流</b></td><td class="mono">不硬凑，不假装查过；要更深需 LinkedIn 会话或付费 key</td></tr></tbody></table><div class="ps">「未注册」和「停放页」是<b>负证据</b>：域名查不到或解析到待售页，说明买家给的邮箱/网站不是在营主体，签约前必须索取注册号再谈条款。</div></div>' % (ndom, nreg_ok, nreg_no, nsite, npark, nch, nch_no, sum((1 for v in AUTO.values() if v.get('emails'))), sum((1 for v in AUTO.values() if v.get('gravatar'))), sum((1 for v in AUTO.values() if v.get('youtube'))) or sum((1 for v in AUTO.values() if v.get('mail_kind'))), sum((1 for v in AUTO.values() if v.get('youtube'))), nsup))
        H.append('</div>')
        vrows = [(nm, v) for nm, v in AUTO.items() if v.get('grade') not in (None, '待核验')]
        vrows.sort(key=lambda x: (GORD.index(x[1].get('grade') or '待核验'), x[0]))
        if vrows:
            H.append('<table style="margin-top:10px"><thead><tr><th>客户</th><th>核验档</th><th>主体 / 域名</th><th>核验结论（自动抓取的原话）</th></tr></thead><tbody>')
            for nm, v in vrows:
                rd = v.get('rdap') or {}
                st = v.get('site') or {}
                sub = ' ｜ '.join((x for x in [rd.get('domain') or '', '注册于 ' + rd['created'] if rd.get('created') else '', (st.get('title') or '')[:40]] if x))
                H.append('<tr><td style="white-space:nowrap"><b>%s</b></td><td><span style="display:inline-block;padding:2px 9px;border-radius:99px;font-size:11.5px;font-weight:700;color:#fff;background:%s">%s</span></td><td>%s</td><td>%s</td></tr>' % (esc(nm), GCOL.get(v.get('grade'), '#8b98a6'), esc(v.get('grade') or ''), md(sub or '-'), md(v.get('verify') or '-')))
            H.append('</tbody></table>')
        H.append('<div class="reg" style="margin-top:10px"><b>个人邮箱 / 社媒能查到什么（实测，不含猜测）：</b>本期 %d 个客户给了邮箱（个人邮箱 %d 个、企业邮箱 %d 个），Gravatar 命中 %d 个（命中=该邮箱是真人日常在用）。社媒平台侧本机实测<b>基本查不动</b>：LinkedIn 返回 999、Instagram 登录墙、TikTok 存在与否返回同一页面、Facebook 直接拦截、Bing 搜索接口返回无关结果、DuckDuckGo 出人机验证、emailrep.io 无 key 限流 429。所以只有三条<b>能验证</b>的路：① 客户给的企业邮箱域 → RDAP + 官网核验；② Gravatar / YouTube 用户名存在性；③ <b>客户自己的独立站页脚</b> → 直接抓出 IG / Facebook / LinkedIn / TikTok 账号（本期靠这条拿到 %d 个客户的社媒，见「十三、公司档案」）。要更深的社媒穿透，需要额外的额度或接口（LinkedIn 登录会话，或 Hunter / emailrep 之类付费 key）——需要的话告诉我，我接上。</div>' % (sum((1 for v in AUTO.values() if v.get('emails'))), sum((1 for v in AUTO.values() if v.get('mail_kind') == '个人邮箱')), sum((1 for v in AUTO.values() if v.get('mail_kind') == '企业邮箱')), sum((1 for v in AUTO.values() if v.get('gravatar'))), sum((1 for v in AUTO.values() if (v.get('profile') or {}).get('socials')))))
        H.append('<div class="reg" style="margin-top:10px"><b>剩下 %d 个为什么查不到：</b>不是没查，是这些买家在聊天和平台字段里<b>都没有可核验主体</b> —— 没公司名、没域名、没企业邮箱，只有一个昵称。这类客户统一标「待核验」，并在谈判前索取：<b>公司注册号 / 官网 / 公司全称 / 税号</b>；拿到任一项即可在下一期核验里自动升级。</div>' % gcnt.get('待核验', 0))
    H.append('<h3>3-1 平台核查结论 <span style="font-weight:400;color:#8a98a6;font-size:12px">先把平台能给「买家公司信息」的通道全部试过一遍，结果如实列出 —— 这决定了后面哪些人能出公司档案</span></h3>')
    H.append('<div class="reg"><b>核心结论：</b>本期 %d 个买家（其中询盘 %d 个），<b>平台侧 0 个持有已验证的企业身份</b> —— 平台身份裁决接口对绝大多数返回「身份信息完全缺失的未验证买家」。也就是说，<b>这些账号在阿里系统里就是个人账号 —— 没有公司名、没有企业邮箱、没有工商背书</b>。这本身就是最重要的商业判断：<b>无企业主体的买家 = 低客单、强比价、无品牌议价</b>，正确的谈单姿势是「小额快周转 + 全额走 Trade Assurance」，而不是陪他打样半年。（注：本店结论由 `verify_companies.py` 实测得出，数字随店铺数据自动变化。）</div>' % (len({c.get('contactName') or '' for c in real if (c.get('contactName') or '') and c.get('contactName') != 'Assistant Eva'}), sum((1 for c in real if (c.get('channel') or '') == '询盘'))))
    H.append('<table><thead><tr><th style="width:118px">通道</th><th>命令</th><th>结果</th></tr></thead><tbody>')
    for ch, cmd, res in DO.PLATFORM_PROBE:
        H.append('<tr><td><b>%s</b></td><td class="mono">%s</td><td>%s</td></tr>' % (esc(ch), esc(cmd), md(res)))
    H.append('</tbody></table>')
    H.append('<h3>3-2 可查实主体档案 <span style="font-weight:400;color:#8a98a6;font-size:12px">能从聊天线索 + 公开工商/商标库核实到主体的，给出完整公司档案</span></h3>')
    if not DO.COMPANIES:
        H.append('<div class="mono">本期无可核实主体。</div>')
    for nm, co in DO.COMPANIES.items():
        a = ANALYSIS.get(nm) or {}
        H.append('<div class="bcard" style="margin-bottom:14px">')
        H.append('<div class="bh"><div><div class="bn">%s</div><div class="bm">%s ｜ 买家 %s ｜ 核实可信度：%s</div></div><span class="badge b-%s">%s</span></div>' % (esc(co['name']), esc(co['tier']), esc(nm), esc(co.get('confidence', '-')), a.get('grade', 'C'), GRADE_LABEL.get(a.get('grade', 'C'), '')))
        H.append('<div class="bb">')
        H.append('<table style="margin:0 0 10px"><tbody>')
        for k, v in co['facts']:
            H.append('<tr><td style="width:104px;white-space:nowrap"><b>%s</b></td><td>%s</td></tr>' % (esc(k), md(v)))
        H.append('</tbody></table>')
        H.append('<div class="row"><span class="k">规模判断</span><span class="v">%s</span></div>' % md(co['size_verdict']))
        H.append('<div class="row"><span class="k">市场影响力</span><span class="v">%s</span></div>' % md(co['influence']))
        H.append('<div class="act"><b>对我方什么意思：</b>%s</div>' % md(co['implication']))
        H.append('<div class="reg"><b>信息来源：</b>%s</div>' % esc(' ｜ '.join(co['sources'])))
        H.append('</div></div>')
    H.append('<h3>3-3 逐个客户：主体 · 人员 · 规模 · 主营 · 影响力 <span style="font-weight:400;color:#8a98a6;font-size:12px">拿不到工商数据的人，用平台真实指标量化（不是猜）</span></h3>')
    H.append('<table><thead><tr><th>客户</th><th>主体核实</th><th>人员</th><th>规模与意向（聊天实证）</th><th>主营 / 采购方向</th><th>采购活跃度（影响力代理）</th><th>还缺什么</th></tr></thead><tbody>')
    for c in real_sorted:
        nm = c.get('contactName') or ''
        a = ANALYSIS.get(nm) or {}
        b = bmap.get(nm) or {}
        p = b.get('persona') or {}
        s = st_of(nm)
        co = DO.COMPANIES.get(nm)
        k = c.get('crm') or {}
        ms = c.get('messages') or []
        cf = DO.chat_facts(ms)
        mt = DO.persona_metrics(p)
        lv, _ = DO.influence_label(mt)
        if co:
            ent = '<b>%s</b><div class="mono">%s</div>' % (esc(co['name']), esc(co['tier']))
        else:
            _av = AUTO.get(nm) or {}
            _rd = _av.get('rdap') or {}
            _si = _av.get('site') or {}
            _bits = []
            if _av.get('entity'):
                _bits.append('<b>%s</b>' % esc(_av['entity']))
            elif (_av.get('registry') or {}).get('hits'):
                _bits.append('<b>%s</b>' % esc(_av['registry']['hits'][0]['name']))
            if _rd.get('domain'):
                _bits.append('%s%s' % (esc(_rd['domain']), '（注册于 %s）' % _rd['created'][:10] if _rd.get('created') else ''))
            if _si.get('reachable') and (not _si.get('parked')):
                _bits.append('官网在营')
            elif _si.get('parked'):
                _bits.append('域名停放页')
            elif _si.get('reachable') is False and _rd.get('domain'):
                _bits.append('官网不可访问')
            if _av.get('grade') and _av['grade'] != '待核验':
                ent = '<span style="display:inline-block;padding:1px 7px;border-radius:99px;font-size:10.5px;font-weight:700;color:#fff;background:%s">自动核验 %s</span><div class="mono" style="margin-top:3px">%s</div>' % (STRENGTH_COLOR.get(_av['grade']) or '#8b98a6', esc(_av['grade']), '<br>'.join(_bits) if _bits else '—')
            elif _bits:
                ent = '<span class="mono">待核验</span><div class="mono">%s</div>' % '<br>'.join(_bits)
            else:
                ent = '<span class="badge b-R">个人账号 · 无可核验主体</span><div class="mono">无公司名/域名/企业邮箱</div>'
        people = '%s<div class="mono">等级 %s · 邮箱 %s<br>接待 %s</div>' % (esc(nm), esc(p.get('buyer_level') or '-'), esc(k.get('contactEmail') or '未提供'), esc('/'.join(c.get('_owners') or [])))
        if cf.get('电话'):
            people += '<div class="mono">电话 %s</div>' % esc(cf['电话'])
        scale = []
        if cf.get('数量'):
            scale.append('聊天提到 %s' % cf['数量'])
        if cf.get('价格'):
            scale.append(cf['价格'])
        if s.get('crm'):
            scale.append(plain(s['crm'], 58))
        if not scale:
            scale.append(plain(s.get('scale') or '无量化信号', 76))
        biz = DO.main_business(p, ms)
        need = DO.ask_for(nm)['need']
        H.append('<tr><td><b>%s</b><div class="mono">%s</div></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (esc(nm), esc(GRADE_LABEL.get(a.get('grade', 'C'), '')), ent, people, '<br>'.join((esc(x) for x in scale)), md(biz) if biz != '—' else '<span class="mono">无类目行为数据</span>', '%s<div class="mono">浏览 %s · 登录 %s 天 · 沟通 %s 天</div>' % ('<b>%s</b>' % lv if lv else '-', mt.get('views') if mt.get('views') is not None else '-', mt.get('logins') if mt.get('logins') is not None else '-', mt.get('msg_days') if mt.get('msg_days') is not None else '-'), '<br>'.join((md(x) for x in need[:3]))))
    H.append('</tbody></table>')
    H.append('<div class="mono" style="margin-top:8px;color:#7a8794">「采购活跃度」= 平台 90 天「接触过的供应商数」，是<b>影响力与议价习惯</b>最接近的量化代理：接触越多说明同时在跟多家谈、比价能力强、越难做独家；越少说明触点集中、越容易绑定。<br>「主营 / 采购方向」来自平台记录的类目沟通与点击次数，不是推测。「还缺什么」= 拿到公司档案必须补的资料，话术见「一、优先行动」。</div>')
    H.append('<h3>3-4 实力评级与谈判杠杆</h3>')
    H.append('<div class="dash c2">')
    H.append('<div class="panel"><div class="pt">客户实力构成</div>%s<div class="ps">「强」= 有成交/单价共识/在途订单；「待核验 / 不承接」= 主体存疑或需求本身不可承接。</div></div>' % CH.donut([(k, bcnt.get(k, 0), {'强': '#2e9e5b', '中': '#1c5fa8', '弱': '#94a3b8', '待核验 / 不承接': '#c0392b'}.get(k, '#8b98a6')) for k in borders if bcnt.get(k)]))
    fl = [(nm, s.get('flag')) for nm, s in STRENGTH.items() if s.get('flag')]
    fl.sort(key=lambda x: GRADE_ORDER.get((ANALYSIS.get(x[0]) or {}).get('grade', 'C'), 2))
    H.append('<div class="panel"><div class="pt">内部标注与事实冲突 <span style="font-weight:400;color:#8b98a6">建议复核的 %d 条</span></div>' % len(fl))
    if fl:
        H.append('<table style="margin-top:2px"><tbody>')
        for nm, f in fl:
            H.append('<tr><td style="white-space:nowrap"><b>%s</b></td><td>%s</td></tr>' % (esc(nm), md(f)))
        H.append('</tbody></table>')
    else:
        H.append('<div class="mono">无</div>')
    H.append('<div class="ps">这些是「团队自己打的标签 / 备注」与客观事实对不上的地方 —— 比客户本身更值得先改。</div></div>')
    H.append('</div>')
    H.append('<div class="mono" style="margin:2px 0 8px;color:#7a8794">下表为逐个客户的实力评级依据与谈判杠杆（完整版，含内部 CRM 与公网核实）。</div>')
    H.append('<table><thead><tr><th>客户</th><th class="mc">实力</th><th>主体识别与公网核实</th><th>合作时长</th><th>体量信号</th><th>内部 CRM 评价</th><th>怎么用这个信息谈单</th></tr></thead><tbody>')
    for c in real_sorted:
        nm = c.get('contactName') or ''
        s = st_of(nm)
        a = ANALYSIS.get(nm) or {}
        sg = s.get('grade') or '未评级'
        scolor = STRENGTH_COLOR.get(sg) or STRENGTH_COLOR.get(_bucket(sg)) or '#8b98a6'
        src_mark = '<div class="mono" style="margin-top:2px">自动核验</div>' if s.get('auto') else '<div class="mono" style="margin-top:2px">人工研判</div>' if s else ''
        if s.get('auto'):
            _rd = s.get('rdap') or {}
            _si = s.get('site') or {}
            _rg = s.get('registry') or {}
            body = []
            if _rd.get('domain'):
                body.append('域名 %s%s' % (_rd['domain'], ' ｜ 注册于 %s' % _rd.get('created') if _rd.get('created') else ''))
            if _si.get('title'):
                body.append('官网「%s」%s' % (_si['title'][:60], '（停放页）' if _si.get('parked') else ''))
            if _rg.get('hits'):
                body.append('工商库：%s' % '、'.join(('%s(%s)' % (h['name'][:40], h['number']) for h in _rg['hits'][:2])))
            H.append('<tr><td style="white-space:nowrap"><b>%s</b><div class="mono">%s</div></td><td class="mc"><span style="display:inline-block;padding:2px 9px;border-radius:99px;font-size:11.5px;font-weight:700;color:#fff;background:%s">%s</span>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (esc(nm), esc(GRADE_LABEL.get(a.get('grade', 'C'), '')), scolor, esc(sg), src_mark, md(s.get('entity') or '无公司名'), '<br>'.join((esc(x) for x in body)) or '-', md(s.get('basis') or '-'), md(s.get('verify') or '-'), '<span class="mono">自动核验不含谈判建议，需人工补</span>'))
            continue
        H.append('<tr><td style="white-space:nowrap"><b>%s</b><div class="mono">%s</div></td><td class="mc"><span style="display:inline-block;padding:2px 9px;border-radius:99px;font-size:11.5px;font-weight:700;color:#fff;background:%s">%s</span>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (esc(nm), esc(GRADE_LABEL.get(a.get('grade', 'C'), '')), scolor, esc(sg), src_mark, md(s.get('entity') or '-'), md(s.get('rel') or '-'), plain(s.get('scale') or '-', 150), md(s.get('crm') or '-'), md(s.get('leverage') or '-')))
    H.append('</tbody></table></section>')
    H.append('<section id="s4"><h2>四、客户分级总表 <span class="hsub">含所在市场的合规门槛</span></h2>')
    H.append('<table><thead><tr><th>判定</th><th>质量档</th><th>四支柱得分</th><th>客户</th><th>渠道</th><th>国家</th><th>平台等级</th><th>接待</th><th>消息</th><th>最后往来</th><th>核心诉求</th><th>市场门槛（第一句）</th></tr></thead><tbody>')
    for c in real_sorted:
        nm = c.get('contactName') or ''
        a = ANALYSIS.get(nm) or {}
        b = bmap.get(nm) or {}
        p = b.get('persona') or {}
        ms = c.get('messages') or []
        auto_mark = ' <span class="mono">[自动]</span>' if a.get('auto') else ''
        _q = qconv.get(c.get('conversationId')) or {'tier': '-', 'score': ''}
        H.append('<tr><td><span class="badge b-%s">%s</span></td><td><span style="display:inline-block;padding:2px 8px;border-radius:99px;font-size:11px;font-weight:700;color:#fff;background:%s">%s</span><div class="mono">%s 分</div></td><td style="white-space:nowrap">%s</td><td><b>%s</b>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%d</td><td class="mono">%s</td><td>%s</td><td class="mono">%s</td></tr>' % (a.get('grade', 'C'), GRADE_LABEL.get(a.get('grade', 'C'), ''), QCOLOR.get(_q['tier'], '#94a3b8'), esc(_q['tier']), _q['score'], pillarbar(_q), esc(nm), auto_mark, esc(c.get('channel') or 'TM'), esc(p.get('buyer_country_code') or c.get('contactCountry') or '-'), esc(p.get('buyer_level') or '-'), esc('/'.join(c.get('_owners') or [])), len(ms), esc(str(ms[-1].get('sendTime'))[:16] if ms else '-'), plain(a.get('intent', '-'), 70), plain((a.get('region') or '').split('：')[-1][:40])))
    H.append('</tbody></table></section>')
    card_pool = sorted(real_sorted, key=lambda c: (0 if c in [x for x, _ in pending] else 1, GRADE_ORDER.get((ANALYSIS.get(c.get('contactName') or '') or {}).get('grade', 'C'), 2), -len(c.get('messages') or [])))
    card_list = card_pool[:45]
    H.append('<section id="s5"><h2>五、客户逐个深度背调 <span class="hsub">默认摊开优先级最高的 12 个（每个都带「关键往来」摘录）；其余折叠，点标题展开。完整聊天默认折叠，需要复盘细节再点开 —— 全量 %d 个，明细见 CSV</span></h2>' % len(card_list))
    H.append('<div class="chips">')
    for _i, _c in enumerate(card_list):
        H.append('<a href="#card%d">%s</a>' % (_i, esc((_c.get('contactName') or '')[:18])))
    H.append('</div><div class="cards">')
    _FOLD_AT = 12
    for _ci, c in enumerate(card_list):
        if _ci == _FOLD_AT and len(card_list) > _FOLD_AT:
            H.append(CT.fold_open('展开其余 %d 个客户的深度卡片（优先级较低，卡片内同样有「关键往来」+ 可展开完整聊天）' % (len(card_list) - _FOLD_AT), count='%d 个' % (len(card_list) - _FOLD_AT)))
        nm = c.get('contactName') or ''
        a = ANALYSIS.get(nm) or {}
        b = bmap.get(nm) or {}
        p = b.get('persona') or {}
        pb = persona_bits(p) or {}
        ms = c.get('messages') or []
        tot = meddic_total(a)
        H.append('<div class="bcard" id="card%d">' % _ci)
        H.append('<div class="bh"><div><div class="bn">%s</div><div class="bm">%s · %s · 平台等级 %s · 接待 %s · %d 条消息 · MEDDIC %d/12 · 概率 %s</div></div><span class="badge b-%s">%s</span></div>' % (esc(nm), esc(c.get('contactLoginId') or ''), esc(p.get('buyer_country_code') or c.get('contactCountry') or '-'), esc(p.get('buyer_level') or '-'), esc('/'.join(c.get('_owners') or [])), len(ms), tot, esc(str(a.get('prob') or '-')), a.get('grade', 'C'), GRADE_LABEL.get(a.get('grade', 'C'), '')))
        H.append('<div class="bb">')
        _qc = qconv.get(c.get('conversationId')) or {}
        if _qc.get('tier'):
            H.append('<div class="row"><span class="k">质量分层</span><span class="v"><b style="color:%s">%s</b>（%s 分）%s</span></div>' % (QCOLOR.get(_qc.get('tier'), '#94a3b8'), esc(_qc.get('tier')), esc(_qc.get('score', '')), pillarbar(_qc)))
        if _qc.get('reasons'):
            H.append('<div class="row"><span class="k">分层依据</span><span class="v">%s</span></div>' % md('；'.join(_qc['reasons'][:8])))
        H.append('<div class="row"><span class="k">核心诉求</span><span class="v">%s</span></div>' % md(a.get('intent', '-')))
        if pb:
            H.append('<div class="row"><span class="k">平台标签</span><span class="v">90 天浏览 <b>%s</b> 个产品 / 登录 <b>%s</b> 天；主打类目：%s</span></div>' % (esc(pb['views']), esc(pb['logins']), esc(pb['top'])))
        if a.get('tag'):
            H.append('<div class="row"><span class="k">标签解读</span><span class="v">%s</span></div>' % md(a['tag']))
        H.append('<div class="row"><span class="k">公司/公网核实</span><span class="v">%s</span></div>' % md(a.get('bg', '-')))
        st = st_of(nm)
        if st and st.get('auto'):
            _rd = st.get('rdap') or {}
            _si = st.get('site') or {}
            _rg = st.get('registry') or {}
            H.append('<div class="row"><span class="k">实力评级</span><span class="v"><span style="display:inline-block;padding:2px 10px;border-radius:99px;font-size:11.5px;font-weight:700;color:#fff;background:%s">%s</span><span class="mono">\u3000自动核验（RDAP / 官网 / 工商库）</span>\u3000%s</span></div>' % (STRENGTH_COLOR.get(st.get('grade')) or '#8b98a6', esc(st.get('grade') or '待核验'), md(st.get('basis') or '')))
            if st.get('entity'):
                H.append('<div class="row"><span class="k">主体识别</span><span class="v">%s</span></div>' % md(st['entity']))
            if _rd.get('domain'):
                _age = _rd.get('age_years')
                H.append('<div class="row"><span class="k">域名核验</span><span class="v"><b>%s</b>\u3000注册于 %s%s%s</span></div>' % (esc(_rd['domain']), esc(_rd.get('created') or '-'), '（%.1f 年）' % _age if isinstance(_age, float) else '', '\u3000注册商 %s' % esc(_rd.get('registrar')) if _rd.get('registrar') else ''))
            if _si.get('domain'):
                H.append('<div class="row"><span class="k">官网核验</span><span class="v">%s</span></div>' % md((('已停放/待售 — ' if _si.get('parked') else '在营 — ') if _si.get('reachable') is not None else '') + ('「%s」' % _si.get('title') if _si.get('title') else '') + ('\u3000行业匹配：%s' % '、'.join(_si.get('industry') or []) if _si.get('industry') else '')))
            if _rg.get('hits'):
                H.append('<div class="row"><span class="k">工商库</span><span class="v">%s</span></div>' % md('；'.join(('%s（公司号 %s）' % (h['name'], h['number']) for h in _rg['hits'][:3]))))
            H.append('<div class="row"><span class="k">核验结论</span><span class="v">%s</span></div>' % md(st.get('verify') or '-'))
        elif st:
            H.append('<div class="row"><span class="k">实力评级</span><span class="v"><span style="display:inline-block;padding:2px 10px;border-radius:99px;font-size:11.5px;font-weight:700;color:#fff;background:%s">%s</span><span class="mono">\u3000人工研判</span>\u3000%s</span></div>' % (STRENGTH_COLOR.get(st.get('grade')) or '#8b98a6', esc(st.get('grade') or '未评级'), md(st.get('basis') or '')))
            H.append('<div class="row"><span class="k">主体识别</span><span class="v">%s</span></div>' % md(st.get('entity') or '-'))
            H.append('<div class="row"><span class="k">合作时长</span><span class="v">%s</span></div>' % md(st.get('rel') or '-'))
            H.append('<div class="row"><span class="k">体量信号</span><span class="v">%s</span></div>' % md(st.get('scale') or '-'))
            H.append('<div class="row"><span class="k">渠道/市场</span><span class="v">%s</span></div>' % md(st.get('channel') or '-'))
            H.append('<div class="row"><span class="k">内部 CRM</span><span class="v">%s</span></div>' % md(st.get('crm') or '-'))
            H.append('<div class="row"><span class="k">公网核实</span><span class="v">%s</span></div>' % md(st.get('verify') or '-'))
            H.append('<div class="act"><b>谈判杠杆：</b>%s</div>' % md(st.get('leverage') or '-'))
            if st.get('flag'):
                H.append('<div class="risk"><b>内部标注异常：</b>%s</div>' % md(st['flag']))
        if a.get('region'):
            H.append('<div class="reg"><b>市场门槛：</b>%s</div>' % md(a['region']))
        if a.get('risk'):
            H.append('<div class="risk"><b>风险 / 注意：</b>%s</div>' % md(a['risk']))
        H.append('<div class="act"><b>建议动作：</b>%s</div>' % md(a.get('action', '-')))
        H.append(CT.key_msgs_html(ms, limit=8))
        _full = ['<div class="chat">']
        for m in ms:
            role = m.get('senderRole') or ''
            _full.append('<div class="msg %s"><span class="t">%s</span><span class="w">%s</span><span class="c">%s</span></div>' % ('in' if role == 'buyer' else 'out', esc(str(m.get('sendTime') or '')[:16]), '买家' if role == 'buyer' else '我方', esc((m.get('content') or '')[:600])))
        if not ms:
            _full.append('<div class="mono">（无消息）</div>')
        _full.append('</div>')
        H.append(CT.fold('展开完整聊天 %d 条' % len(ms), ''.join(_full), count='卡点：%s' % esc(a.get('blocker_label') or '-')))
        H.append('</div></div>')
    if len(card_list) > _FOLD_AT:
        H.append(CT.fold_close())
    H.append('</div></section>')
    H.append('<section id="s6"><h2>六、分市场进入门槛与打法</h2><div class="reg">本次未核验各市场最新监管要求。请依据本次目标市场和产品配方另行核实。</div></section>')
    H.append('<section id="s7"><h2>七、风险与合规</h2>')
    risk_rows = []
    for c in real:
        text = ' '.join((str(m.get('content') or '') for m in c.get('messages', []))).lower()
        terms = [word for word in DO.RISK_WORDS if word in text]
        if terms:
            risk_rows.append((c.get('contactName') or '未命名', terms))
    if risk_rows:
        for name, terms in risk_rows:
            H.append('<div class="risk"><b>%s</b>：聊天含待核验词 %s；需人工核实业务适配及法规要求。</div>' % (esc(name), esc('、'.join(terms))))
    else:
        H.append('<div class="reg">本次规则未命中特定风险词；不代表已完成法规或客户信用审核。</div>')
    H.append('</section>')
    from collections import Counter as _C
    own = _C()
    pending_count = 0
    for c in real:
        own[c.get('sellerName') or c.get('sellerAliId') or '未知账号'] += 1
        messages = sorted(c.get('messages') or [], key=lambda m: str(m.get('sendTime') or ''))
        if messages and messages[-1].get('senderRole') == 'buyer':
            pending_count += 1
    H.append('<section id="s8"><h2>八、本次暴露的运营问题</h2><div class="panel"><div class="pt">本次账号会话分布</div>%s</div>' % CH.barh(sorted(own.items(), key=lambda x: -x[1]), unit=' 个会话', rowh=24, pad_l=120))
    H.append('<p>本次有 %d 条会话以买家消息结束，请结合完整聊天人工确认是否待回复；单账号分析不用于判断全店分配是否均衡。</p></section>' % pending_count)
    _built = _build_rows()
    if _built:
        _rows, _meta = _built
        _tcnt = _Counter((r['tier'] for r in _rows))
        _css, _js, _secs = _report_extras(_rows, _tcnt, _owner_stats(_rows))
        H.append(_css)
        for _a, _t, _sub, _body in _secs:
            H.append('<section id="%s"><h2>%s <span class="hsub">%s</span></h2>%s</section>' % (_a, _t, _sub, _body))
        H.append(_js)
        H.append("<script>ctBind('ctTierBox');</script>")
    H.append('<div class="foot">数据来源：阿里巴巴国际站 TradeManager 接口（workctl icbu tm）；主体公网核验：rdap.org 域名注册数据 + 客户官网抓取 + 英国公司注册处（USPTO / bizapedia / OpenCorporates 网页版本机不可用，已如实标注）；窗口受平台限制最长 7 天；平台标签为该账号近 90 天行为；地区合规为公开资料核查，具体以当地最新法规为准 ｜ 生成 %s</div>' % datetime.now().strftime('%Y-%m-%d %H:%M'))
    H.append("<script>document.querySelectorAll('section h2').forEach(function(h){ h.addEventListener('click', function(){ h.parentElement.classList.toggle('collapsed'); });});function collapseAll(v){ document.querySelectorAll('section').forEach(function(sec){ sec.classList.toggle('collapsed', v); });}</script>")
    H.append('</div></body></html>')
    out = os.path.join(INQ, '询盘客户背调分析_%s.html' % d1)
    html = ''.join(H)
    for _a in ('s2', 's3', 's5', 's6', 's7', 's8', 's10', 's11', 's13'):
        html = html.replace('<section id="%s">' % _a, '<section id="%s" class="collapsed">' % _a)
    with open(out, 'w', encoding='utf-8') as f:
        f.write(html)
    csvp = os.path.join(INQ, '询盘聊天记录_%s_%s.csv' % (d0, d1))
    with open(csvp, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['店铺', label, '窗口', '%s ~ %s' % (win['since'][:16], win['until'][:16])])
        w.writerow([])
        w.writerow(['时间', '客户', '客户账号', '国家', '平台等级', '接待账号', '方向', '内容', '会话ID'])
        for c in real_sorted:
            b = bmap.get(c.get('contactName')) or {}
            p = b.get('persona') or {}
            for m in c.get('messages') or []:
                w.writerow([m.get('sendTime'), c.get('contactName'), c.get('contactLoginId'), p.get('buyer_country_code') or c.get('contactCountry') or '', p.get('buyer_level') or '', '/'.join(c.get('_owners') or []), '买家' if m.get('senderRole') == 'buyer' else '我方', (m.get('content') or '').replace('\n', ' '), c.get('conversationId')])
    csvb = os.path.join(INQ, '客户分级清单_%s.csv' % d1)
    with open(csvb, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['判定', '质量档', '质量分', '判定依据', '聊天记录分', '背调结论分', '客户信息分', '内部CRM分', '客户', '账号', '国家', '平台等级', '90天浏览', '90天登录', '主打类目', '接待账号', '消息数', '最后往来', 'MEDDIC合计', 'M', 'E', 'D标准', 'D流程', 'I', 'C', '拿单概率', '实力评级', '背调来源', '实力依据', '主体识别', '合作时长', '体量信号', '渠道/市场', '内部CRM阶段', '内部CRM标签', '内部CRM备注', '公网核实', '谈判杠杆', '内部标注异常', '核心诉求', '公司/公网核实', '市场门槛', '风险', '建议动作', '英文跟进话术'])
        for c in real_sorted:
            nm = c.get('contactName') or ''
            a = ANALYSIS.get(nm) or {}
            b = bmap.get(nm) or {}
            p = b.get('persona') or {}
            pb = persona_bits(p) or {}
            d = a.get('meddic') or {}
            s = st_of(nm)
            k = c.get('crm') or {}
            ms = c.get('messages') or []
            _q = qconv.get(c.get('conversationId')) or {'tier': '-', 'score': '', 'reasons': []}
            w.writerow([GRADE_LABEL.get(a.get('grade', 'C'), ''), _q['tier'], _q['score'], '；'.join(_q.get('reasons') or []), (_q.get('pillars') or {}).get('chat', ''), (_q.get('pillars') or {}).get('bg', ''), (_q.get('pillars') or {}).get('info', ''), (_q.get('pillars') or {}).get('crm', ''), nm, c.get('contactLoginId'), p.get('buyer_country_code') or c.get('contactCountry') or '', p.get('buyer_level') or '', pb.get('views', ''), pb.get('logins', ''), pb.get('top', ''), '/'.join(c.get('_owners') or []), len(ms), ms[-1].get('sendTime') if ms else '', meddic_total(a), d.get('M', ''), d.get('E', ''), d.get('D', ''), d.get('Dp', ''), d.get('I', ''), d.get('C', ''), a.get('prob') or '', s.get('grade', ''), '自动核验' if s.get('auto') else '人工研判' if s else '无', s.get('basis', ''), s.get('entity', ''), s.get('rel', ''), s.get('scale', ''), s.get('channel', ''), STAGE_LABEL.get(k.get('stage'), k.get('stage') or ''), '、'.join(k.get('tags') or []), (k.get('displayName') or '').strip(), s.get('verify', ''), s.get('leverage', ''), s.get('flag', ''), a.get('intent', ''), a.get('bg', ''), a.get('region', ''), a.get('risk', ''), a.get('action', ''), (a.get('talk') or '').strip()])
    print('已生成:')
    for p in [out, csvp, csvb]:
        print('  %-52s %7.1f KB' % (os.path.basename(p), os.path.getsize(p) / 1024))
    print()
    print('排行榜（A/B 级按拿单概率）:')
    for c in ranked:
        nm = c.get('contactName') or ''
        a = ANALYSIS.get(nm) or {}
        print('  %-8s %-22s MEDDIC %2d/12  概率 %-5s  %s' % (a.get('grade'), nm, meddic_total(a), a.get('prob') or '', (a.get('intent') or '')[:40]))
if __name__ == '__main__':
    main()
