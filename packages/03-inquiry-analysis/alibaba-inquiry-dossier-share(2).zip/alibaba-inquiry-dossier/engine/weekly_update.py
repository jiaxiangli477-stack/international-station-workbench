import os, subprocess, sys
from pathlib import Path

class SyncError(Exception):
    pass

def run(command, cwd, timeout=60, env=None):
    env = dict(os.environ if env is None else env)
    if str(command[0]).endswith('.cmd'):
        import bridge_runtime
        env = bridge_runtime.child_environment(command[0], env)
    env['PYTHONIOENCODING'] = 'utf-8'
    completed = subprocess.run([str(x) for x in command], cwd=(Path(cwd).resolve().drive + os.sep if os.name == 'nt' and str(command[0]).endswith('.cmd') else str(cwd)), env=env, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=timeout, shell=os.name == 'nt' and str(command[0]).endswith('.cmd'))
    if completed.returncode:
        raise SyncError('采集失败，检查 Accio 登录及账号权限；原始输出未展示')
    return completed.stdout

def require_identity(bridge, output, expected, env=None):
    import json
    output = Path(output)
    run([Path(bridge) / 'workctl.cmd', 'workflow', 'chat-analysis', 'resolve-id', '--output-file', output, '--format', 'json'], output.parent, timeout=120, env=env)
    if str(json.loads(output.read_text(encoding='utf-8-sig')).get('CURRENT_SELF_ALIID') or '') != str(expected):
        raise SyncError('店铺身份变化，停止采集')
