import io
import json
import os
import sys
from collections import OrderedDict
from datetime import datetime
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
INQ = os.path.join(HERE, 'inquiry')
from inquiry_analysis import ANALYSIS
from inquiry_strength import STRENGTH
import inquiry_dossier as DO
import deal_blocker as DB
import company_strength as CS
DASH = '-'
CARD_PREFIX = ('This is a', 'This is an')

def _load(name, default):
    p = os.path.join(INQ, name)
    if not os.path.isfile(p):
        return default
    try:
        return json.load(io.open(p, encoding='utf-8'))
    except Exception:
        return default

def load_inputs():
    conv = _load('conversations.json', {}) or {}
    buyers = _load('buyers.json', []) or []
    ent = (_load('entities.json', {}) or {}).get('buyers') or {}
    _vraw = _load('verify_auto.json', {}) or {}
    auto = _vraw.get('buyers') or {}
    meta = dict(generated=_vraw.get('generated'), sources=_vraw.get('sources'))
    return (conv, buyers, ent, auto, meta)

def st_of(nm, auto):
    s = STRENGTH.get(nm)
    if s:
        return s
    return auto.get(nm) or {}
TOPIC_HINT = [('collagen', 'collagen'), ('creatine', 'creatine'), ('whey', 'protein'), ('protein', 'protein'), ('pre workout', 'pre-workout'), ('pre-workout', 'pre-workout'), ('electrolyte', 'electrolyte hydration'), ('gummy', 'gummies'), ('sachet', 'stick packs'), ('stick', 'stick packs'), ('coffee', 'instant coffee'), ('vitamin', 'vitamins'), ('fiber', 'dietary fiber'), ('probiotic', 'probiotics'), ('glutathione', 'glutathione'), ('energy', 'energy products'), ('pouch', 'energy pouches')]

def auto_talk(row):
    if not row.get('nbuy'):
        return ''
    nm = (row.get('name') or '').strip()
    first = nm.split(' ')[0] if nm else 'there'
    src = ((row.get('biz') or '') + ' ' + (row.get('intent') or '') + ' ' + (row.get('qty') or '')).lower()
    topic = ''
    for k, v in TOPIC_HINT:
        if k in src:
            topic = v
            break
    about = ' about the %s' % topic if topic else ''
    owner = (row.get('owners') or '').split('/')[0].strip()
    sign = ' —%s' % owner if owner and owner != '-' else ''
    return 'Hi %s — thanks for reaching out%s. So I can come back with an accurate offer, could you confirm three things:\n1) Target quantity for the first order, and the pack size (bottles / stick packs / boxes).\n2) Your market, and whether you need private label with your own brand.\n3) Your target launch date.\nOnce I have these I will send the spec sheet and a firm quotation.%s' % (first, about, sign)

def build_rows():
    conv, buyers, ENT, AUTO, AUTO_META = load_inputs()
    convs = conv.get('conversations') or []
    win = conv.get('window') or {}
    store = conv.get('store') or {}
    bmap = {b.get('contactName'): b for b in buyers}
    real = [c for c in convs if (c.get('contactName') or '') != 'Assistant Eva']
    if not real:
        return None
    bybuyer = OrderedDict()
    for c in real:
        nm = c.get('contactName') or ''
        g = bybuyer.setdefault(nm, dict(name=nm, convs=[], msgs=[], owners=set(), channels=set(), last=None, last_role=None))
        g['convs'].append(c)
        g['msgs'].extend(c.get('messages') or [])
        g['owners'].update(c.get('_owners') or [])
        g['channels'].add(c.get('channel') or 'TM')
        ms = c.get('messages') or []
        if ms:
            t = ms[-1].get('sendTime') or ''
            if not g['last'] or t > g['last']:
                g['last'], g['last_role'] = (t, ms[-1].get('senderRole'))
    for _g in bybuyer.values():
        _g['msgs'].sort(key=lambda m: m.get('sendTime') or '')
    rows = []
    for nm, g in bybuyer.items():
        p = (bmap.get(nm) or {}).get('persona') or {}
        e = ENT.get(nm) or {}
        st = st_of(nm, AUTO)
        a = ANALYSIS.get(nm) or DO.auto_profile(next((c for c in g['convs']), {}))
        d = a.get('meddic') or {}
        mt = DO.persona_metrics(p)
        cf = DO.chat_facts(g['msgs'])
        nb = sum((1 for m in g['msgs'] if m.get('senderRole') == 'buyer' and (not (m.get('content') or '').lstrip().startswith(CARD_PREFIX))))
        ns = len(g['msgs']) - nb
        cc = e.get('country') or (p.get('buyer_country_code') or '').upper()
        _str_rec = dict(rdap=st.get('rdap') or {}, site=st.get('site') or {}, profile=st.get('profile') or {}, registry=st.get('registry') or {}, emails=e.get('emails') or [], entity=st.get('entity') or '', domains=e.get('domains') or [], level=p.get('buyer_level') or '', views=mt.get('views'), logins=mt.get('logins'), sellers=mt.get('sellers'), price=cf.get('价格') or '', qty=cf.get('数量') or '', chat_text=' '.join((m.get('content') or '' for m in g['msgs']))[:4000], nbuy=nb, nsell=ns)
        strength = CS.score(_str_rec)
        st = dict(st, strength=strength)
        qs = [DO.quality_of(c, bmap.get(nm), st) for c in g['convs']]
        q = max(qs, key=lambda x: x['score'])
        wait = DASH
        if g['last_role'] == 'buyer' and g['last']:
            try:
                wait = (datetime.now() - datetime.fromisoformat(g['last'])).days
            except Exception:
                wait = DASH
        rows.append(dict(tier=q['tier'], score=q['score'], chat=q['pillars']['chat'], bg=q['pillars']['bg'], info=q['pillars']['info'], crm=q['pillars']['crm'], name=nm, login=e.get('loginId') or '', country=cc or '', region='成熟市场' if cc in DO.MATURE_MARKETS else '新兴/其他' if cc else '未知', level=p.get('buyer_level') or '', channel='/'.join(sorted(g['channels'])), nconv=len(g['convs']), nbuy=nb, nsell=max(0, ns), span=q.get('span_days') or 1, owners='/'.join(sorted(g['owners'])) or DASH, last=(g['last'] or '')[:16], pending='是' if g['last_role'] == 'buyer' else '', wait=wait, meddic=sum((d.get(k, 0) for k in ('M', 'E', 'D', 'Dp', 'I', 'C'))), prob=a.get('prob') or '', grade=st.get('grade') or '', src='人工研判' if STRENGTH.get(nm) else '自动核验' if AUTO.get(nm) else '无', basis=st.get('basis') or '', verify=st.get('verify') or '', qty=cf.get('数量') or '', price=cf.get('价格') or '', signals='、'.join(e.get('signals') or []) or DASH, mail_kind=e.get('mail_kind') or '', emails=e.get('emails') or [], gravatar=bool(st.get('gravatar')), youtube=st.get('youtube') or [], social=e.get('social') or [], handles=e.get('handles') or [], profile=st.get('profile') or {}, gravatar_names=st.get('gravatar_names') or [], gravatar_users=st.get('gravatar_users') or [], rdap=st.get('rdap') or {}, site=st.get('site') or {}, registry=st.get('registry') or {}, bg_evidence=st.get('evidence') or [], bg_grade=st.get('grade') or '', phone_regions=[x for x in e.get('phone_regions') or [] if x and x[1]], views=mt.get('views'), logins=mt.get('logins'), sellers=mt.get('sellers'), biz=DO.main_business(p, g['msgs']), intent=(a.get('intent') or '')[:120], action=(a.get('action') or '')[:200], talk=(a.get('talk') or '')[:300], reasons=q['reasons'], signals_list=e.get('signals') or [], ask=DO.ask_for(nm)['need']))
        rows[-1]['strength'] = strength
        rows[-1]['talk_auto'] = '' if rows[-1]['talk'] else auto_talk(rows[-1])
        _hint = ' '.join([a.get('intent') or '', a.get('action') or '', st.get('scale') or '', st.get('rel') or '', (g['convs'][0].get('crm') or {}).get('displayName') or ''])
        _bl = DB.analyze(g['msgs'], wait_days=wait if isinstance(wait, int) else 0, hint_text=_hint)
        rows[-1].update(stage=_bl['stage'], blocker=_bl['blocker'], blocker_label=_bl['label'], blocker_tip=_bl['tip'], blocker_detail=_bl['detail'], blocker_days=wait if isinstance(wait, int) else rows[-1]['span'] or 0, blocker_buyer_last=_bl['buyer_last'], blocker_seller_last=_bl['seller_last'], blocker_gap=_bl.get('gap') or '', blocker_ask=_bl.get('ask') or '', chat_yield=_bl['yield_pct'], chat_intents=_bl['intents'], key_msgs=DB.key_messages(g['msgs'], limit=8))
    order = {t: i for i, t in enumerate(DO.QUALITY_TIERS)}
    rows.sort(key=lambda r: (order.get(r['tier'], 9), -r['score'], -r['nbuy']))
    meta = dict(win=win, store=store, n_conv=len(real), auto=AUTO, auto_meta=AUTO_META, ent=ENT, real=real, bmap=bmap)
    return (rows, meta)
