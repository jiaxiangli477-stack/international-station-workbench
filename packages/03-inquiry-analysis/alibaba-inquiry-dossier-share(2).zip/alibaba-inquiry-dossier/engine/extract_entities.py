import collections
import io
import json
import os
import re
import sys
from collections import OrderedDict
HERE = os.path.dirname(os.path.abspath(__file__))
INQ = os.path.join(HERE, 'inquiry')
ISO2 = {'ad': '安道尔', 'ae': '阿联酋', 'af': '阿富汗', 'ag': '安提瓜和巴布达', 'al': '阿尔巴尼亚', 'am': '亚美尼亚', 'ao': '安哥拉', 'ar': '阿根廷', 'at': '奥地利', 'au': '澳大利亚', 'az': '阿塞拜疆', 'ba': '波黑', 'bb': '巴巴多斯', 'bd': '孟加拉国', 'be': '比利时', 'bf': '布基纳法索', 'bg': '保加利亚', 'bh': '巴林', 'bi': '布隆迪', 'bj': '贝宁', 'bn': '文莱', 'bo': '玻利维亚', 'br': '巴西', 'bs': '巴哈马', 'bt': '不丹', 'bw': '博茨瓦纳', 'by': '白俄罗斯', 'bz': '伯利兹', 'ca': '加拿大', 'cd': '刚果(金)', 'cf': '中非', 'cg': '刚果(布)', 'ch': '瑞士', 'ci': '科特迪瓦', 'cl': '智利', 'cm': '喀麦隆', 'cn': '中国', 'co': '哥伦比亚', 'cr': '哥斯达黎加', 'cu': '古巴', 'cv': '佛得角', 'cy': '塞浦路斯', 'cz': '捷克', 'de': '德国', 'dj': '吉布提', 'dk': '丹麦', 'dm': '多米尼克', 'do': '多米尼加', 'dz': '阿尔及利亚', 'ec': '厄瓜多尔', 'ee': '爱沙尼亚', 'eg': '埃及', 'er': '厄立特里亚', 'es': '西班牙', 'et': '埃塞俄比亚', 'fi': '芬兰', 'fj': '斐济', 'fr': '法国', 'ga': '加蓬', 'gb': '英国', 'gd': '格林纳达', 'ge': '格鲁吉亚', 'gh': '加纳', 'gm': '冈比亚', 'gn': '几内亚', 'gr': '希腊', 'gt': '危地马拉', 'gy': '圭亚那', 'hn': '洪都拉斯', 'hr': '克罗地亚', 'ht': '海地', 'hu': '匈牙利', 'id': '印尼', 'ie': '爱尔兰', 'il': '以色列', 'in': '印度', 'iq': '伊拉克', 'ir': '伊朗', 'is': '冰岛', 'it': '意大利', 'jm': '牙买加', 'jo': '约旦', 'jp': '日本', 'ke': '肯尼亚', 'kg': '吉尔吉斯斯坦', 'kh': '柬埔寨', 'km': '科摩罗', 'kr': '韩国', 'kw': '科威特', 'kz': '哈萨克斯坦', 'la': '老挝', 'lb': '黎巴嫩', 'lc': '圣卢西亚', 'lk': '斯里兰卡', 'lr': '利比里亚', 'ls': '莱索托', 'lt': '立陶宛', 'lu': '卢森堡', 'lv': '拉脱维亚', 'ly': '利比亚', 'ma': '摩洛哥', 'md': '摩尔多瓦', 'me': '黑山', 'mg': '马达加斯加', 'mk': '北马其顿', 'ml': '马里', 'mm': '缅甸', 'mn': '蒙古', 'mr': '毛里塔尼亚', 'mt': '马耳他', 'mu': '毛里求斯', 'mv': '马尔代夫', 'mw': '马拉维', 'mx': '墨西哥', 'my': '马来西亚', 'mz': '莫桑比克', 'na': '纳米比亚', 'ne': '尼日尔', 'ng': '尼日利亚', 'ni': '尼加拉瓜', 'nl': '荷兰', 'no': '挪威', 'np': '尼泊尔', 'nz': '新西兰', 'om': '阿曼', 'pa': '巴拿马', 'pe': '秘鲁', 'pg': '巴新', 'ph': '菲律宾', 'pk': '巴基斯坦', 'pl': '波兰', 'ps': '巴勒斯坦', 'pt': '葡萄牙', 'py': '巴拉圭', 'qa': '卡塔尔', 'ro': '罗马尼亚', 'rs': '塞尔维亚', 'ru': '俄罗斯', 'rw': '卢旺达', 'sa': '沙特', 'sb': '所罗门群岛', 'sc': '塞舌尔', 'sd': '苏丹', 'se': '瑞典', 'sg': '新加坡', 'si': '斯洛文尼亚', 'sk': '斯洛伐克', 'sl': '塞拉利昂', 'sm': '圣马力诺', 'sn': '塞内加尔', 'so': '索马里', 'sr': '苏里南', 'sv': '萨尔瓦多', 'sy': '叙利亚', 'sz': '斯威士兰', 'td': '乍得', 'tg': '多哥', 'th': '泰国', 'tj': '塔吉克斯坦', 'tl': '东帝汶', 'tm': '土库曼斯坦', 'tn': '突尼斯', 'to': '汤加', 'tr': '土耳其', 'tt': '特立尼达', 'tw': '中国台湾', 'tz': '坦桑尼亚', 'ua': '乌克兰', 'ug': '乌干达', 'uk': '英国', 'us': '美国', 'uy': '乌拉圭', 'uz': '乌兹别克斯坦', 've': '委内瑞拉', 'vn': '越南', 'ye': '也门', 'za': '南非', 'zm': '赞比亚', 'zw': '津巴布韦'}
SELF_WORDS = ('our company', 'our factory')
FREE_MAIL = ('gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'qq.com', '163.com', '126.com', 'icloud.com', 'protonmail.com', 'proton.me', 'live.com', 'aol.com', 'mail.com', 'yandex.com', 'gmx.com', 'web.de', 'rediffmail.com', 'foxmail.com', 'msn.com', 'me.com', 'googlemail.com', 'zoho.com', 'naver.com', 'hanmail.net', 'daum.net', 'tutanota.com', 'yandex.ru', 'mail.ru', 'internet.ru', 'list.ru', 'bk.ru', 'inbox.ru', 'sina.com', 'sohu.com', 'yeah.net', '21cn.com', 'tom.com', 'docs.google.com', 'drive.google.com', 'sheets.google.com', 'translate.google.com', 'sites.google.com', 'google.com', 'privaterelay.appleid.com', 'appleid.com')
FREE_LABELS = ('yahoo', 'hotmail', 'outlook', 'live', 'gmail', 'googlemail', 'aol', 'proton', 'yandex', 'gmx', 'mail', 'msn', 'icloud', 'rediffmail', 'zoho', 'tutanota', 'naver', 'hanmail', 'daum', 'web', 'sina', 'sohu', 'foxmail', 'docs', 'privaterelay', 'drive', 'sheets', 'translate', 'sites')
NOISE_DOM = ('facebook.com', 'instagram.com', 'tiktok.com', 'linkedin.com', 'youtube.com', 'youtu.be', 'wa.me', 't.me', 'pinterest.com', 'twitter.com', 'x.com', 'snapchat.com', 'threads.net', 'wixsite.com', 'blogspot.com', 'wordpress.com', 'godaddysites.com', 'shopify.com', 'myshopify.com', 'canva.com', 'weebly.com', 'squarespace.com', 'sedo.com', 'afternic.com', 'dan.com', 'amazon.com', 'ebay.com', 'etsy.com', 'wikipedia.org', 'googleusercontent.com', 'gstatic.com', 'cloudflare.com', 'wix.com', 'mystrikingly.com', 'webnode.page', 'linkedin.cn', 'alibaba.com', 'aliexpress.com', '1688.com')
ALIBABA_DOM = ('alibaba.com', 'aliexpress.com', '1688.com', 'alibabacloud.com')

def is_junk_domain(d):
    d = (d or '').lower().strip()
    if not d or '.' not in d:
        return True
    if d in NOISE_DOM or d in FREE_MAIL:
        return True
    if any((d.endswith('.' + a) for a in ALIBABA_DOM)):
        return True
    parts = d.split('.')
    if len(parts) < 2:
        return True
    if len(parts) == 2 and parts[0] in ('com', 'co', 'net', 'org', 'gov', 'edu', 'ac', 'or', 'ne'):
        return True
    if parts[0] in FREE_LABELS:
        return True
    if len(parts) >= 3 and parts[-2] in ('com', 'co', 'net', 'org', 'in') and (parts[-3] in FREE_LABELS):
        return True
    return False
LEGAL_SUFFIX = 'S\\.A\\.S|S\\.A|SAS|S\\.L|S\\.R\\.L|SRL|S\\.p\\.A|SpA|GmbH\\s*&\\s*Co\\.?\\s*KG|GmbH|AG|L\\.L\\.C|LLC|Ltd\\.?|Limited|Inc\\.?|Incorporated|Corp\\.?|Corporation|Pty\\.?\\s*Ltd|SDN\\.?\\s*BHD|B\\.?V\\.?|N\\.?V\\.?|A/S|ApS|Oy|OÜ|Pte\\.?\\s*Ltd|Co\\.?,?\\s*Ltd|Kft|D\\.O\\.O|d\\.o\\.o|SIA|UAB|TOO|LLP|Zrt|K\\.K'
CO_RE = re.compile("\\b((?:[A-Z][\\w&\\.\\'\\-]*)(?:\\s+(?:[A-Z][\\w&\\.\\'\\-]*|of|and|&)){0,4}\\s+(?:" + LEGAL_SUFFIX + '))\\.?')
INTRO_RE = re.compile("(?:my\\s+company(?:\\s+name)?\\s*(?:is|:)\\s*|our\\s+company(?:\\s+name)?\\s*(?:is|:)\\s*|company\\s*name\\s*[:\\-]\\s*|we\\s+are\\s+(?:called\\s+)?|i\\s+am\\s+from\\s+|i\\'m\\s+from\\s+|(?:我(?:们)?(?:的)?公司(?:叫|名称|是|：|:)\\s*))([A-Z][A-Za-z&\\.\\'\\-]*(?:\\s+[A-Z][A-Za-z&\\.\\'\\-]*){0,4})")
ADDR_RE = re.compile('[^\\n]{0,70}(?:calle|torre|galp[oó]n|avenida|carretera|carrera|callejón|street|road\\b|avenue|floor|suite|building|bldg|plaza|block|sector|box\\s*\\d+|km\\s*\\d+)[^\\n]{0,70}', re.I)
TEL_RE = re.compile('\\+?\\d[\\d \\-()\\.]{7,18}\\d')
DATE_RE = re.compile('^\\d{1,2}[./\\-]\\d{1,2}[./\\-]\\d{2,4}$')
DASHQTY_RE = re.compile('^\\d{1,4}-\\d{1,4}-\\d{1,4}$')
QTY_NEAR = ('moq', 'quantity', 'qty', 'price', 'usd', 'kg', 'pcs', 'units', 'pieces', 'boxes', 'bottles', 'servings', 'days', 'weeks', 'months', 'discount', 'cost', 'per unit')
DOM_RE = re.compile('(?<![\\w@])((?:[a-z0-9](?:[a-z0-9\\-]{0,61}[a-z0-9])?\\.)+(?:com|net|org|io|co|biz|info|store|shop|health|fit|ltd|llc|group|br|mx|de|fr|uk|es|it|nl|be|at|ch|se|no|dk|fi|ie|pt|gr|pl|cz|sk|hu|ro|bg|hr|si|lt|lv|ee|ua|ru|kz|by|az|ge|am|il|tr|jo|kw|qa|bh|om|lb|in|pk|bd|lk|np|my|sg|th|vn|id|ph|kr|jp|tw|hk|cn|au|nz|za|ng|ke|gh|eg|ma|tn|dz|et|tz|ug|cm|ci|sn|ar|cl|pe|co|ec|ve|py|uy|bo|cr|pa|gt|do))(?![a-z0-9])', re.I)
BRAND_RE = re.compile('["“”\\\']([A-Z][A-Za-z0-9&\\\'\\- ]{2,28})["“”\\\']|«([A-Za-z0-9&\\\'\\- ]{2,28})»')
SOCIAL_RE = re.compile('(?:instagram\\.com|instagr\\.am|facebook\\.com|fb\\.me|tiktok\\.com|linkedin\\.com|youtube\\.com|youtu\\.be|x\\.com|twitter\\.com|wa\\.me|t\\.me|pinterest\\.com|snapchat\\.com|threads\\.net)/[^\\s,;)\\]"\\\'<>]{2,60}', re.I)
AT_HANDLE_RE = re.compile('(?<![\\w.@])@([A-Za-z][A-Za-z0-9._]{2,28})\\b')
BRAND_INTRO_RE = re.compile("(?:(?:our|my|the)\\s+(?:brand|label)(?:\\s+name)?\\s*(?:is|:)\\s*|(?:brand|label)\\s*(?:name)?\\s*[:\\-]\\s*|we\\s+(?:sell|market|distribute)\\s+(?:it\\s+)?(?:under\\s+)?(?:the\\s+)?(?:name|brand)\\s+)([A-Z][A-Za-z0-9&\\'\\-]*(?:\\s+[A-Z][A-Za-z0-9&\\'\\-]*){0,3})")
PRODUCT_HINT = ('supplement', 'powder', 'capsule', 'gummy', 'gummies', 'tablet', 'sachet', 'collagen', 'whey', 'creatine', 'pre workout', 'pre-workout', 'bcaa', 'eaa', 'electrolyte', 'vitamin', 'protein', 'coffee', 'softgel', 'liquid', 'jelly', 'glutathione', 'probiotic', 'omega', 'fiber', 'mushroom', 'gummies', 'stick', 'drink', 'shake', 'bar ', 'flavor', 'flavour', 'formula', 'private label')
NOISE_TOKENS = ('gmp', 'iso', 'haccp', 'coa', 'msds', 'fda', 'ddp', 'cif', 'fob', 'exw', 'moq', 'oem', 'odm', 'sku', 'asap', 'nad', 'pqq', 'gpc', 'cdp', 'pump', 'dhl', 'fedex', 'tnt', 'ups', 'ems', 'tt', 'lc', 'pi', 'ok', 'hi', 'hello', 'thanks', 'dear', 'yes', 'no', 'sir', 'madam', 'tel', 'order', 'product', 'price', 'sample', 'china', 'usa', 'uk', 'eu', 'fy', 'qty', 'usd', 'eur', 'sgs', 'tuv', 'bpa', 'hala', 'kosher', 'non-gmo', 'vegan', 'trade assurance', 'customer', 'supplier')
CARD_MARK = ('this is a', 'card', 'product id', 'inquiry id', 'order id', 'product name is', 'shipping address is china', 'our company')

def _clean_co(s):
    s = re.sub('\\s+', ' ', s).strip(' .,;:')
    return s

def _is_self(s):
    low = s.lower()
    return any((w in low for w in SELF_WORDS))

def _is_noise(s):
    toks = [t for t in re.split('[\\s&,\\./]+', s.lower()) if t]
    if not toks:
        return True
    if all((t in NOISE_TOKENS for t in toks)):
        return True
    return _is_self(s)

def _looks_product(s):
    low = s.lower()
    body = re.sub('\\b(' + LEGAL_SUFFIX + ')\\b', '', low, flags=re.I)
    return any((w in body for w in PRODUCT_HINT))
CALLING = {'1': 'US/CA', '7': 'RU/KZ', '20': 'EG', '27': 'ZA', '30': 'GR', '31': 'NL', '32': 'BE', '33': 'FR', '34': 'ES', '36': 'HU', '39': 'IT', '40': 'RO', '41': 'CH', '43': 'AT', '44': 'GB', '45': 'DK', '46': 'SE', '47': 'NO', '48': 'PL', '49': 'DE', '51': 'PE', '52': 'MX', '54': 'AR', '55': 'BR', '56': 'CL', '57': 'CO', '58': 'VE', '60': 'MY', '61': 'AU', '62': 'ID', '63': 'PH', '64': 'NZ', '65': 'SG', '66': 'TH', '81': 'JP', '82': 'KR', '84': 'VN', '86': 'CN', '90': 'TR', '91': 'IN', '92': 'PK', '94': 'LK', '95': 'MM', '98': 'IR', '212': 'MA', '213': 'DZ', '216': 'TN', '218': 'LY', '220': 'GM', '221': 'SN', '225': 'CI', '233': 'GH', '234': 'NG', '237': 'CM', '251': 'ET', '254': 'KE', '255': 'TZ', '256': 'UG', '263': 'ZW', '264': 'NA', '351': 'PT', '352': 'LU', '353': 'IE', '354': 'IS', '356': 'MT', '357': 'CY', '358': 'FI', '359': 'BG', '370': 'LT', '371': 'LV', '372': 'EE', '380': 'UA', '420': 'CZ', '421': 'SK', '501': 'BZ', '502': 'GT', '503': 'SV', '504': 'HN', '505': 'NI', '506': 'CR', '507': 'PA', '591': 'BO', '593': 'EC', '595': 'PY', '598': 'UY', '673': 'BN', '852': 'HK', '853': 'MO', '855': 'KH', '856': 'LA', '880': 'BD', '886': 'TW', '960': 'MV', '961': 'LB', '962': 'JO', '963': 'SY', '964': 'IQ', '965': 'KW', '966': 'SA', '967': 'YE', '968': 'OM', '971': 'AE', '972': 'IL', '973': 'BH', '974': 'QA', '975': 'BT', '976': 'MN', '977': 'NP'}

def phone_region(raw):
    raw = (raw or '').strip()
    if not raw.startswith('+'):
        return ('', '')
    dg = re.sub('\\D', '', raw)
    for n in (3, 2, 1):
        cc = dg[:n]
        if cc in CALLING:
            return ('+' + cc, CALLING[cc])
    return ('', '')

def country_of_login(login_id):
    p = (login_id or '')[:2].lower()
    return (p.upper(), ISO2.get(p, '')) if p in ISO2 else ('', '')

def _is_card(content):
    t = (content or '').lstrip()
    return t.startswith(('This is a', 'This is an')) or '[Card]' in t or 'card. The product' in t or ('card. Inquiry id' in t)

def _near_id(txt, i, span=46):
    seg = txt[max(0, i - span):i + span].lower()
    return any((w in seg for w in ('id is', 'id:', 'product id', 'inquiry id', 'order id', 'product name', 'item id', 'sku', 'product card', 'order number', 'tracking', 'track no', 'awb', 'waybill', 'reference number', 'track number', 'shipment no')))

def crm_fields(crm):
    k = crm or {}
    mail = (k.get('contactEmail') or '').strip().lower()
    comp = (k.get('customerBuyerName') or '').strip()
    return (mail, comp)

def extract_for(msgs):
    companies, domains, emails, phones, addrs, brands = (OrderedDict() for _ in range(6))
    bt = []
    for m in msgs:
        if _is_card(m.get('content')):
            continue
        if m.get('senderRole') == 'buyer':
            bt.append(m.get('content') or '')
    btxt = '\n'.join(bt)
    for m in CO_RE.finditer(btxt):
        s = _clean_co(m.group(1))
        if len(s) >= 5 and (not _is_noise(s)) and (not _looks_product(s)):
            companies[s] = companies.get(s, 0) + 1
    for m in INTRO_RE.finditer(btxt):
        s = _clean_co(re.split('[.,;!?\\n]', m.group(1))[0])
        if not 3 <= len(s) <= 60 or _is_noise(s) or _looks_product(s + ' ltd'):
            continue
        if not all((w[:1].isupper() or w.lower() in ('of', 'and', 'the', '&') for w in s.split())):
            continue
        companies[s] = companies.get(s, 0) + 1
    for m in DOM_RE.finditer(btxt):
        d = m.group(1).lower()
        if is_junk_domain(d):
            continue
        if len(d) < 6 or d.count('.') > 3 or len(d.split('.')[0]) < 3:
            continue
        if d.startswith('www.'):
            d = d[4:]
        if is_junk_domain(d):
            continue
        domains[d] = domains.get(d, 0) + 1
    for m in re.finditer('[\\w\\.\\-]+@[\\w\\-]+\\.[a-z]{2,}', btxt, re.I):
        e = m.group(0).lower()
        if not e.startswith(('noreply', 'no-reply', 'service@alibaba')) and e.split('@')[0] not in ('info', 'contact'):
            emails[e] = emails.get(e, 0) + 1
    for m in TEL_RE.finditer(btxt):
        raw = m.group(0).strip()
        digits = re.sub('\\D', '', raw)
        if not 8 <= len(digits) <= 14 or DATE_RE.match(raw) or DASHQTY_RE.match(raw):
            continue
        if _near_id(btxt, m.start()):
            continue
        seg = btxt[max(0, m.start() - 40):m.start() + 40].lower()
        if any((w in seg for w in QTY_NEAR)):
            continue
        if len(digits) >= 13 and (digits.startswith(('1601', '1000', '1602')) or not raw.startswith('+')):
            continue
        if set(digits) == {'0'} or digits.endswith('000000'):
            continue
        phones[raw] = phones.get(raw, 0) + 1
    for m in ADDR_RE.finditer(btxt):
        a = re.sub('\\s+', ' ', m.group(0)).strip()
        low = a.lower()
        if not 15 <= len(a) <= 150:
            continue
        if not re.search('\\d', a):
            continue
        if any((w in low for w in CARD_MARK)) or 'our company' in low:
            continue
        if '?' in a or any((w in low for w in ('moq', 'price', 'quantity', 'how many'))):
            continue
        if 'china' in low and ('广东' in a or '广州' in a or '深圳' in a):
            continue
        addrs[a] = addrs.get(a, 0) + 1
    for m in BRAND_RE.finditer(btxt):
        b = (m.group(1) or m.group(2) or '').strip()
        if 3 <= len(b) <= 28 and (not _is_noise(b)) and (not _looks_product(b)):
            brands[b] = brands.get(b, 0) + 1
    for m in BRAND_INTRO_RE.finditer(btxt):
        b = _clean_co(re.split('[.,;!?\\n]', m.group(1))[0])
        if 3 <= len(b) <= 28 and (not _is_noise(b)) and (not _looks_product(b)):
            brands[b] = brands.get(b, 0) + 1
    social, handles = (OrderedDict(), OrderedDict())
    for m in SOCIAL_RE.finditer(btxt):
        u = re.sub('\\s+$', '', m.group(0)).lower()
        social[u] = social.get(u, 0) + 1
    for m in AT_HANDLE_RE.finditer(btxt):
        h = m.group(1).lower()
        if h in NOISE_TOKENS or len(h) < 4:
            continue
        if h.endswith(('gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com')):
            continue
        handles[h] = handles.get(h, 0) + 1
    for e in list(emails):
        loc = e.split('@')[0]
        if len(loc) >= 4 and re.search('[a-z]{3}', loc) and (not re.fullmatch('[a-z]{1,2}\\d{6,}', loc)):
            handles.setdefault(loc.replace('.', ''), handles.get(loc.replace('.', ''), 0) + 1)

    def ranked(d, n):
        return [k for k, _ in sorted(d.items(), key=lambda x: -x[1])[:n]]
    return dict(companies=ranked(companies, 5), domains=ranked(domains, 5), emails=ranked(emails, 3), phones=ranked(phones, 3), addresses=ranked(addrs, 3), brands=ranked(brands, 5), social=ranked(social, 4), handles=ranked(handles, 3))

def main():
    conv = json.load(io.open(os.path.join(INQ, 'conversations.json'), encoding='utf-8'))
    buyers = []
    bpath = os.path.join(INQ, 'buyers.json')
    if os.path.isfile(bpath):
        buyers = json.load(io.open(bpath, encoding='utf-8'))
    bmap = {b.get('contactName'): b for b in buyers}
    convs = [c for c in conv['conversations'] if (c.get('contactName') or '') != 'Assistant Eva']
    agg = OrderedDict()
    for c in convs:
        nm = c.get('contactName') or ''
        _k = c.get('crm') or {}
        e = agg.setdefault(nm, dict(loginId=c.get('contactLoginId') or '', aliId=c.get('contactAliId') or '', channels=set(), owners=set(), msgs=[], emails_crm=[], buyerName=''))
        e['channels'].add(c.get('channel') or 'TM')
        e['owners'].update(c.get('_owners') or [])
        e['msgs'].extend(c.get('messages') or [])
        _m, _b = crm_fields(c.get('crm'))
        if _m and _m not in e['emails_crm']:
            e['emails_crm'].append(_m)
        if _b and (not e['buyerName']):
            e['buyerName'] = _b
    out = OrderedDict()
    for nm, e in agg.items():
        f = extract_for(e['msgs'])
        _mails = list(e.get('emails_crm') or [])
        if _mails:
            f['emails'] = list(dict.fromkeys(_mails + f['emails']))[:3]
        _comp = (e.get('buyerName') or '').strip()
        if _comp and _comp.lower() not in ('none', 'null') and (not _is_noise(_comp)):
            f['companies'] = list(dict.fromkeys(([_comp] if len(_comp) >= 3 else []) + f['companies']))[:5]
        cc, cn = country_of_login(e['loginId'])
        p = (bmap.get(nm) or {}).get('persona') or {}
        nb = sum((1 for m in e['msgs'] if m.get('senderRole') == 'buyer' and (not _is_card(m.get('content')))))
        sig = []
        for k, lab in (('companies', '公司名'), ('domains', '自有域名'), ('emails', '邮箱'), ('phones', '电话'), ('addresses', '地址'), ('brands', '品牌名'), ('social', '社交链接')):
            if f[k]:
                sig.append(lab)
        mails = f['emails']
        kinds = []
        for _m in mails:
            _dom = _m.split('@')[-1].lower()
            kinds.append('企业邮箱' if _dom not in FREE_MAIL and (not is_junk_domain(_dom)) else '个人邮箱')
        if '企业邮箱' in kinds:
            sig.append('企业邮箱')
        out[nm] = dict(loginId=e['loginId'], aliId=e['aliId'], channels='/'.join(sorted(e['channels'])), owners=sorted(e['owners']), n_msgs=len(e['msgs']), n_buyer=nb, country=cc, country_name=cn, persona_country=(p.get('buyer_country_code') or '').upper(), level=p.get('buyer_level') or '', companies=f['companies'], domains=f['domains'], emails=f['emails'], mail_kind='/'.join(dict.fromkeys(kinds)), phones=f['phones'], addresses=f['addresses'], brands=f['brands'], social=f['social'], handles=f['handles'], signals=sig, phone_regions=[phone_region(x) for x in f['phones']])
    shared = collections.Counter()
    for v in out.values():
        for d in v['domains']:
            shared[d] += 1
    for v in out.values():
        keep = [d for d in v['domains'] if shared[d] < 3]
        v['links'] = [d for d in v['domains'] if shared[d] >= 3]
        v['domains'] = keep
        v['signals'] = [s for s in v['signals'] if not (s == '自有域名' and (not keep))]
    dst = os.path.join(INQ, 'entities.json')
    with io.open(dst, 'w', encoding='utf-8') as fh:
        fh.write(json.dumps(dict(store=conv.get('store'), window=conv.get('window'), buyers=out), ensure_ascii=False, indent=1))
    c = collections.Counter()
    for v in out.values():
        c['buyers'] += 1
        c['有国家'] += 1 if v['country'] else 0
        for k in ('companies', 'domains', 'emails', 'phones', 'addresses', 'brands'):
            c[k] += 1 if v[k] else 0
    print('已生成 %s' % dst)
    print('  ' + ' ｜ '.join(('%s %d' % (k, v) for k, v in c.items())))
    nd = sum((len(v['domains']) for v in out.values()))
    nc = sum((len(v['companies']) for v in out.values()))
    print('  候选域名 %d 个 / 候选公司名 %d 个' % (nd, nc))
if __name__ == '__main__':
    sys.exit(main())
