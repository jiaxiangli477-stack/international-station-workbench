import re
from collections import Counter
from datetime import datetime
import inquiry_charts as CH
import inquiry_dossier as DO
try:
    from extract_entities import is_junk_domain
except Exception:

    def is_junk_domain(d):
        return (d or '').lower() in ('gmail.com', 'hotmail.com', 'yahoo.com', 'outlook.com', 'live.com', 'icloud.com', 'qq.com', '163.com')
TIERS = DO.QUALITY_TIERS
TIER_BG = {'优质客户': '#2e9e5b', '潜力客户': '#1c5fa8', '普通客户': '#94a3b8', '无效 / 风险': '#c0392b'}
PILLAR_COLOR = {'chat': '#1c5fa8', 'bg': '#2e9e5b', 'info': '#b8860b', 'crm': '#94a3b8'}
PILLAR_SHORT = {'chat': '聊天', 'bg': '背调', 'info': '信息', 'crm': '内部'}
DASH = '-'

def esc(s):
    return str(s if s is not None else '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')

def md(s):
    t = esc(s)
    t = re.sub('\\*\\*(.+?)\\*\\*', '<b>\\1</b>', t)
    return t.replace('\n', '<br>')

def plain(s, n=None):
    t = re.sub('\\*\\*(.+?)\\*\\*', '\\1', str(s if s is not None else '')).replace('\n', ' ')
    if n:
        t = t[:n]
    return esc(t)

def pillars(r):
    out = []
    for b in ('chat', 'bg', 'info', 'crm'):
        v = r.get(b, 0)
        col = PILLAR_COLOR[b] if v else '#cbd5e1'
        out.append('<span class="pl" style="background:%s">%s %d</span>' % (col, PILLAR_SHORT[b], v))
    return ''.join(out)
PAGE_CSS = '<style>\n*{box-sizing:border-box}\nbody{margin:0;background:#eef1f5;color:#1f2733;font:13px/1.68 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif}\n.wrap{max-width:1400px;margin:0 auto;padding:20px}\n.rhead{background:#16324f;color:#fff;border-radius:12px;padding:18px 22px;margin-bottom:12px}\n.rt{font-size:21px;font-weight:800}.rs{margin-top:6px;font-size:12px;opacity:.9;line-height:1.8}\n.rprint{background:#f5c518;color:#1f2733;border:0;border-radius:8px;padding:8px 15px;font-size:13px;font-weight:700;cursor:pointer;margin-left:8px}\n.flex{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}\n.toc2{position:sticky;top:0;z-index:60;background:rgba(255,255,255,.95);backdrop-filter:blur(6px);\n border:1px solid #e2e8f0;border-radius:10px;padding:9px 12px;margin-bottom:12px;display:flex;\n flex-wrap:wrap;gap:6px;align-items:center}\n.toc2 a{font-size:12px;color:#16324f;text-decoration:none;padding:4px 9px;border-radius:6px;background:#f2f5f9}\n.toc2 a:hover{background:#16324f;color:#fff}\nsection{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:15px 17px;margin-bottom:13px}\nh2{font-size:16px;font-weight:800;color:#16324f;margin:0 0 12px;padding-left:10px;border-left:4px solid #f5c518;cursor:pointer}\nh2 .hsub{font-size:12px;font-weight:500;color:#7a8794;margin-left:8px}\nsection.collapsed > *:not(h2){display:none}\nh3{font-size:13.5px;font-weight:800;color:#16324f;margin:14px 0 8px}\n.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(132px,1fr));gap:9px;margin-bottom:12px}\n.kpi{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:11px 13px}\n.kpi .l{font-size:11.5px;color:#7a8794}.kpi .v{font-size:22px;font-weight:800;color:#16324f;line-height:1.25}\n.kpi .v small{font-size:13px;color:#94a3b8;font-weight:600}\n.kpi .s{font-size:11px;color:#8b98a6;margin-top:2px;line-height:1.5}\n.kpi.alert{border-left:4px solid #c0392b}.kpi.good{border-left:4px solid #2e9e5b}\n.dash{display:grid;grid-template-columns:1fr 1fr;gap:12px}\n@media(max-width:900px){.dash{grid-template-columns:1fr}}\n.panel{border:1px solid #e8edf3;border-radius:9px;padding:11px 13px;background:#fbfcfe}\n.panel .pt{font-size:12.5px;font-weight:800;color:#16324f;margin-bottom:7px}\n.ps{font-size:11.5px;color:#7a8794;line-height:1.75;margin-top:7px}\n.pl{display:inline-block;padding:1px 6px;margin:0 3px 3px 0;border-radius:4px;font-size:10.5px;font-weight:700;color:#fff}\n.tier{display:inline-block;padding:2px 9px;border-radius:99px;font-size:11px;font-weight:700;color:#fff;white-space:nowrap}\n.tw{overflow:auto;max-height:76vh;border:1px solid #e8edf3;border-radius:8px}\n.tw table{width:100%;border-collapse:collapse;font-size:12px}\n.tw th{background:#16324f;color:#fff;font-weight:700;padding:7px 8px;text-align:left;position:sticky;top:0;z-index:2;font-size:11.5px}\n.tw td{border-bottom:1px solid #eef2f7;padding:6px 8px;vertical-align:top}\n.tw tr:hover td{background:#f7fafd}\n.ctrls{display:flex;flex-wrap:wrap;gap:7px;align-items:center;margin-bottom:9px}\n.chip{border:1px solid #d7dee8;background:#fff;border-radius:99px;padding:4px 12px;font-size:12px;cursor:pointer;font-weight:600;color:#41505f}\n.chip.on{color:#fff;border-color:transparent}\n.ctrls input[type=text],.ctrls select{border:1px solid #d7dee8;border-radius:7px;padding:5px 9px;font-size:12px;color:#1f2733;background:#fff}\n.ctrls input[type=text]{min-width:190px}\n.mono{font-family:ui-monospace,Consolas,monospace;font-size:10.5px;color:#8b98a6}\n.warn{color:#c0392b;font-weight:700}.ok{color:#2e9e5b;font-weight:700}\n.txt{white-space:pre-wrap;font-size:12px;background:#f8fafc;border:1px dashed #dbe3ec;border-radius:7px;padding:8px 10px;margin-top:5px}\n.cpbtn{border:1px solid #d7dee8;background:#fff;border-radius:6px;padding:2px 9px;font-size:11px;cursor:pointer;margin-left:6px}\n.bcard{border:1px solid #e8edf3;border-radius:9px;padding:12px 14px;margin-bottom:10px;background:#fff}\n.bcard .bn{font-size:14px;font-weight:800;color:#16324f}\n.bcard .bm{font-size:11px;color:#8b98a6;margin-top:2px}\n.bcard .bb{margin-top:9px}\n.foot{font-size:11.5px;color:#8b98a6;padding:14px 4px;line-height:1.8}\n@media print{.toc2,.rprint,.ctrls,.cpbtn{display:none}.tw{max-height:none;overflow:visible}\n section{break-inside:avoid}body{background:#fff}}\n/* 折叠块：重要的摊开，次要的点开再看 */\ndetails.fold{border:1px solid #e3e9f1;border-radius:9px;background:#fbfcfe;margin:9px 0;padding:0}\ndetails.fold>summary{cursor:pointer;list-style:none;padding:9px 13px;font-size:12.5px;font-weight:700;\n color:#16324f;display:flex;align-items:center;gap:8px}\ndetails.fold>summary::-webkit-details-marker{display:none}\ndetails.fold>summary:before{content:\'+\';display:inline-flex;justify-content:center;align-items:center;\n width:17px;height:17px;border-radius:5px;background:#e8eef6;color:#16324f;font-weight:800;font-size:13px}\ndetails.fold[open]>summary:before{content:\'-\';background:#16324f;color:#fff}\ndetails.fold>summary:hover{background:#f2f6fb}\ndetails.fold .fbody{padding:0 13px 12px}\ndetails.fold .fcount{font-weight:500;color:#8b98a6;font-size:11.5px;margin-left:auto}\n.keytag{display:inline-block;font-size:10px;font-weight:700;padding:1px 6px;border-radius:4px;\n background:#eef2f7;color:#5b6b7d;margin-right:4px}\n.keytag.hot{background:#fdecec;color:#c0392b}\n.keywrap{border-left:3px solid #f5c518;background:#fffdf5;border-radius:0 8px 8px 0;padding:8px 12px;margin:8px 0}\n.keywrap .kh{font-size:12px;font-weight:800;color:#16324f;margin-bottom:5px}\n.mini{font-size:11.5px;color:#7a8794;line-height:1.7}\n</style>'
REPORT_CSS = "<style>\n.ctbl .pl{display:inline-block;padding:1px 6px;margin:0 3px 3px 0;border-radius:4px;font-size:10.5px;font-weight:700;color:#fff}\n.ctbl .tier{display:inline-block;padding:2px 9px;border-radius:99px;font-size:11px;font-weight:700;color:#fff;white-space:nowrap}\n.ctbl .tw{overflow:auto;max-height:76vh;border:1px solid #e8edf3;border-radius:8px}\n.ctbl .tw table{width:100%;border-collapse:collapse;font-size:12px}\n.ctbl .tw th{background:#16324f;color:#fff;font-weight:700;padding:7px 8px;text-align:left;position:sticky;top:0;z-index:2;font-size:11.5px}\n.ctbl .tw td{border-bottom:1px solid #eef2f7;padding:6px 8px;vertical-align:top}\n.ctbl .tw tr:hover td{background:#f7fafd}\n.ctbl .ctrls{display:flex;flex-wrap:wrap;gap:7px;align-items:center;margin-bottom:9px}\n.ctbl .chip{border:1px solid #d7dee8;background:#fff;border-radius:99px;padding:4px 12px;font-size:12px;cursor:pointer;font-weight:600;color:#41505f}\n.ctbl .chip.on{color:#fff;border-color:transparent}\n.ctbl input[type=text],.ctbl select{border:1px solid #d7dee8;border-radius:7px;padding:5px 9px;font-size:12px;background:#fff;color:#1f2733}\n.ctbl input[type=text]{min-width:190px}\n.ctbl .warn{color:#c0392b;font-weight:700}.ctbl .ok{color:#2e9e5b;font-weight:700}\n.ctbl .txt{white-space:pre-wrap;font-size:12px;background:#f8fafc;border:1px dashed #dbe3ec;border-radius:7px;padding:8px 10px;margin-top:5px}\n.ctbl .cpbtn{border:1px solid #d7dee8;background:#fff;border-radius:6px;padding:2px 9px;font-size:11px;cursor:pointer;margin-left:6px}\n.ctbl .bcard{border:1px solid #e8edf3;border-radius:9px;padding:12px 14px;margin-bottom:10px;background:#fff}\n@media print{.ctbl .tw{max-height:none;overflow:visible}.ctbl .ctrls,.ctbl .cpbtn{display:none}}\n/* 折叠块：重要的摊开，次要的点开再看 */\ndetails.fold{border:1px solid #e3e9f1;border-radius:9px;background:#fbfcfe;margin:9px 0;padding:0}\ndetails.fold>summary{cursor:pointer;list-style:none;padding:9px 13px;font-size:12.5px;font-weight:700;\n color:#16324f;display:flex;align-items:center;gap:8px}\ndetails.fold>summary::-webkit-details-marker{display:none}\ndetails.fold>summary:before{content:'+';display:inline-flex;justify-content:center;align-items:center;\n width:17px;height:17px;border-radius:5px;background:#e8eef6;color:#16324f;font-weight:800;font-size:13px}\ndetails.fold[open]>summary:before{content:'-';background:#16324f;color:#fff}\ndetails.fold>summary:hover{background:#f2f6fb}\ndetails.fold .fbody{padding:0 13px 12px}\ndetails.fold .fcount{font-weight:500;color:#8b98a6;font-size:11.5px;margin-left:auto}\n.keytag{display:inline-block;font-size:10px;font-weight:700;padding:1px 6px;border-radius:4px;\n background:#eef2f7;color:#5b6b7d;margin-right:4px}\n.keytag.hot{background:#fdecec;color:#c0392b}\n.keywrap{border-left:3px solid #f5c518;background:#fffdf5;border-radius:0 8px 8px 0;padding:8px 12px;margin:8px 0}\n.keywrap .kh{font-size:12px;font-weight:800;color:#16324f;margin-bottom:5px}\n.mini{font-size:11.5px;color:#7a8794;line-height:1.7}\n</style>"
TIERING_JS = "<script>\nfunction ctApply(id){\n  var box=document.getElementById(id); if(!box)return;\n  var rows=[].slice.call(box.querySelectorAll('tbody tr'));\n  var st=box.__f||(box.__f={tier:'',owner:'',country:'',q:''});\n  var n=0;\n  rows.forEach(function(tr){\n    var ok=(!st.tier||tr.dataset.tier===st.tier)\n        &&(!st.owner||tr.dataset.owner.indexOf(st.owner)>=0)\n        &&(!st.country||tr.dataset.country===st.country)\n        &&(!st.q||tr.dataset.text.indexOf(st.q)>=0);\n    tr.style.display=ok?'':'none'; if(ok)n++;\n  });\n  var c=document.getElementById(id+'-cnt'); if(c)c.textContent=n;\n}\nfunction ctBind(id){\n  var box=document.getElementById(id); if(!box)return;\n  box.querySelectorAll('.chip[data-tier]').forEach(function(ch){\n    var base=ch.dataset.bg||'#fff';\n    ch.addEventListener('click',function(){\n      box.querySelectorAll('.chip[data-tier]').forEach(function(x){\n        x.classList.remove('on'); x.style.background=x.dataset.bg||'#fff';\n        x.style.color=x.dataset.bg?'#fff':'#41505f';\n      });\n      ch.classList.add('on'); ch.style.background=ch.dataset.bg||'#16324f'; ch.style.color='#fff';\n      box.__f.tier=ch.dataset.tier||''; ctApply(id);\n    });\n  });\n  var fo=box.querySelector('.fowner'), fc=box.querySelector('.fcountry'), fq=box.querySelector('.fq');\n  if(fo)fo.addEventListener('change',function(){box.__f.owner=fo.value;ctApply(id);});\n  if(fc)fc.addEventListener('change',function(){box.__f.country=fc.value;ctApply(id);});\n  if(fq)fq.addEventListener('input',function(){box.__f.q=fq.value.toLowerCase();ctApply(id);});\n  var rs=box.querySelector('.freset');\n  if(rs)rs.addEventListener('click',function(){box.__f={tier:'',owner:'',country:'',q:''};\n    if(fo)fo.value='';if(fc)fc.value='';if(fq)fq.value='';ctApply(id);});\n  ctApply(id);\n}\nfunction ctCopy(btn){\n  var box=btn.closest('.txt'); if(!box)return;\n  var t=box.innerText.replace(/复制.*$/,'').trim();\n  try{navigator.clipboard.writeText(t).then(function(){btn.textContent='已复制';\n    setTimeout(function(){btn.textContent='复制话术';},1200);});\n  }catch(e){btn.textContent='请手动选择复制';}\n}\ndocument.addEventListener('DOMContentLoaded',function(){\n  ['ctTierBox','ctTableStandaloneTierBox'].forEach(function(i){ctBind(i);});\n});\n</script>"

def fold(title, body, count='', open_=False):
    return '<details class="fold"%s><summary>%s%s</summary><div class="fbody">%s</div></details>' % (' open' if open_ else '', title, '<span class="fcount">%s</span>' % esc(count) if count else '', body)

def fold_open(title, count='', sub=''):
    return '<details class="fold"><summary>%s%s</summary><div class="fbody">' % (title, '<span class="fcount">%s</span>' % esc(count) if count else '')

def fold_close():
    return '</div></details>'

def key_msgs_html(msgs, limit=8):
    import deal_blocker as DB
    ks = DB.key_messages(msgs, limit=limit)
    if not ks:
        return '<div class="mini">（无实质消息，只有平台卡片）</div>'
    out = ['<div class="keywrap"><div class="kh">关键往来 %d 条<span class="mini">（从 %d 条消息里挑出的带商业要素的）—— 复盘先看这里</span></div>' % (len(ks), len(msgs))]
    for k in ks:
        tags = ''.join(('<span class="keytag%s">%s</span>' % (' hot' if t in ('最后一句', '价格', '数量') else '', esc(t)) for t in k['tags']))
        out.append('<div class="row"><span class="k">%s</span><span class="v">%s%s</span></div>' % (esc(k['sender']), tags, esc(k['text'])))
    out.append('</div>')
    return ''.join(out)

def frag_review(rows, bstats):
    import deal_blocker as DB
    n_deal = sum((1 for r in rows if r.get('blocker') == 'DEAL'))
    n_good = sum((1 for r in rows if r['tier'] == '优质客户'))
    n_noreply = sum((1 for r in rows if r.get('blocker') == 'NOT_REPLIED_US'))
    n_noquote = sum((1 for r in rows if r.get('blocker') == 'NO_QUOTE'))
    n_chit = sum((1 for r in rows if r.get('blocker') == 'CHITCHAT'))
    stale = sorted([r for r in rows if isinstance(r.get('blocker_days'), int) and r['blocker_days'] >= 5 and (r.get('blocker') not in ('CARD_ONLY', 'DEAL'))], key=lambda r: -r['blocker_days'])[:6]
    top = [r for r in rows if r['tier'] == '优质客户'][:6]
    H = ['<div class="dash"><div class="panel"><div class="pt">一句话复盘</div><div class="mini" style="font-size:12.5px;line-height:1.9">这批 %d 个买家里，<b>真正有成交动作的 %d 个</b>、<b>优质客户 %d 个</b>、<b>卡在流程上没推进的 83 个</b>；其中 <b class="warn">%d 个是我方没回</b>、<b class="warn">%d 个是问了价没给价</b>、<b>%d 个聊了几轮却没谈过生意</b>。复盘优先级：先回「我方未回复」→ 再补「没报价」的价 → 拍板「卡 ≥5 天」的老单要不要救。</div></div>' % (len(rows), n_deal, n_good, n_noreply, n_noquote, n_chit)]
    H.append('<div class="panel"><div class="pt">本周最该看的 6 个客户</div><table style="margin-top:2px"><tbody>')
    for r in top:
        H.append('<tr><td style="white-space:nowrap"><b>%s</b><div class="mono">%s ｜ %s 天未动</div></td><td class="mini">%s</td></tr>' % (esc(r['name']), esc(r.get('blocker_label') or '-'), r.get('blocker_days') if r.get('blocker_days') != DASH else DASH, esc((r['intent'] or '')[:90])))
    H.append('</tbody></table></div></div>')
    if stale:
        H.append('<div class="reg"><b>卡了 ≥5 天、可能已经凉的单（%d 个，列前 6）：</b>' % sum((1 for r in rows if isinstance(r.get('blocker_days'), int) and r['blocker_days'] >= 5 and (r.get('blocker') not in ('CARD_ONLY', 'DEAL')))))
        H.append('；'.join(('<b>%s</b>（%s，%d 天）' % (esc(r['name']), esc(r.get('blocker_label')), r['blocker_days']) for r in stale)))
        H.append('\u3000—— 建议重新破冰（发新信息），别在原话题上追问。</div>')
    return ''.join(H)

def frag_tiering(rows, tcnt, box_id, standalone_note=True):
    owners = sorted(set((o for r in rows for o in r['owners'].split('/') if o and o != DASH)))
    ccs = sorted(set((r['country'] for r in rows if r['country'])), key=lambda c: -sum((1 for r in rows if r['country'] == c)))
    H = []
    H.append('<div class="ctrls">')
    H.append('<span class="mono">档位</span>')
    H.append('<span class="chip on" data-tier="" data-bg="#16324f">全部 %d</span>' % len(rows))
    for t in [x for x in TIERS if tcnt.get(x)]:
        H.append('<span class="chip" data-tier="%s" data-bg="%s">%s %d</span>' % (esc(t), TIER_BG[t], esc(t), tcnt.get(t, 0)))
    H.append('<span class="mono" style="margin-left:8px">接待</span>')
    H.append('<select class="fowner"><option value="">全部账号</option>%s</select>' % ''.join(('<option value="%s">%s</option>' % (esc(o), esc(o)) for o in owners)))
    H.append('<span class="mono">国家</span>')
    H.append('<select class="fcountry"><option value="">全部国家</option>%s</select>' % ''.join(('<option value="%s">%s (%d)</option>' % (esc(c), esc(c), sum((1 for r in rows if r['country'] == c))) for c in ccs[:60])))
    H.append('<input type="text" class="fq" placeholder="搜客户 / 账号 / 诉求 / 依据…">')
    H.append('<button class="chip freset">重置</button>')
    H.append('<span class="mono">筛选结果 <b id="%s-cnt">%d</b> / %d</span>' % (box_id, len(rows), len(rows)))
    H.append('</div>')
    H.append('<div class="tw"><table id="%s"><thead><tr>' % box_id)
    H.append('<th>档位</th><th>分</th><th>四支柱</th><th>客户</th><th>国家</th><th>等级</th><th>渠道</th><th>消息<br>买/我</th><th>接待</th><th>最后往来</th><th>待回复</th><th>成交卡点</th><th>话术<br>效率</th><th>MEDDIC</th><th>概率</th><th>实力</th><th>来源</th><th>命中依据</th></tr></thead><tbody>')
    for r in rows:
        txt = ' '.join([r['name'], r['login'], r['country'], r['level'], r['owners'], r['intent'], r['action'], r['grade'], r['basis'], r['verify'], r['signals'], ' '.join(r['reasons']), r['qty'], r['price']]).lower()
        pend_cell = '<span class="warn">待回%s</span>' % ('（%s 天）' % r['wait'] if r['wait'] != DASH else '') if r['pending'] == '是' else '<span class="mono">已回</span>'
        H.append('<tr data-tier="%s" data-owner="%s" data-country="%s" data-text="%s">' % (esc(r['tier']), esc(r['owners']), esc(r['country']), esc(txt)))
        H.append('<td><span class="tier" style="background:%s">%s</span></td><td><b>%d</b></td>' % (TIER_BG.get(r['tier'], '#94a3b8'), esc(r['tier']), r['score']))
        H.append('<td style="white-space:nowrap">%s</td>' % pillars(r))
        H.append('<td><b>%s</b><div class="mono">%s</div></td>' % (esc(r['name']), esc(r['login'])))
        H.append('<td>%s<div class="mono">%s</div></td>' % (esc(r['country'] or DASH), esc(r['region'])))
        H.append('<td>%s</td><td>%s</td>' % (esc(r['level'] or DASH), esc(r['channel'])))
        H.append('<td class="mono">%d / %d</td><td>%s</td>' % (r['nbuy'], r['nsell'], esc(r['owners'])))
        H.append('<td class="mono">%s</td><td>%s</td>' % (esc(r['last'] or DASH), pend_cell))
        _bd = r.get('blocker_days')
        H.append('<td><b>%s</b><div class="mini">%s</div><div class="mono">卡 %s 天 ｜ %s</div></td>' % (esc(r.get('blocker_label') or DASH), esc(r.get('blocker_gap') or ''), _bd if _bd != DASH else DASH, esc(r.get('stage') or DASH)))
        _y = r.get('chat_yield')
        H.append('<td class="%s">%s%%</td>' % ('warn' if isinstance(_y, int) and _y < 40 and (r['nbuy'] >= 4) else 'mono', _y if _y is not None else DASH))
        H.append('<td class="mono">%s/12</td><td class="mono">%s</td>' % (r['meddic'], esc(r['prob'] or DASH)))
        H.append('<td>%s<div class="mono">%s</div></td>' % (esc(r['grade'] or DASH), esc(r['src'])))
        H.append('<td>%s</td></tr>' % esc('；'.join(r['reasons'][:4]) or DASH))
    H.append('</tbody></table></div>')
    if standalone_note:
        H.append('<div class="ps">「命中依据」是这套分层的可复核凭证：每条都写明来自聊天、背调、客户信息还是内部 CRM，加了几分。完整 34 列（含数量/单价证据、90 天行为、建议动作）见同目录 Excel 台账。</div>')
    return ''.join(H)

def frag_good(rows, limit=0, fold_after=10):
    good = [r for r in rows if r['tier'] == '优质客户']
    if limit:
        good = good[:limit]
    H = []
    _head, _tail = (good[:fold_after], good[fold_after:]) if fold_after else (good, [])
    _cards = []
    for r in good:
        _cards.append('<div class="bcard"><div class="flex"><div><div class="bn">%s</div><div class="bm">%s ｜ %s ｜ %s ｜ 消息 %d/%d ｜ 接待 %s ｜ 背调来源 %s</div></div><span class="tier" style="background:%s">%s %d 分</span></div>' % (esc(r['name']), esc(r['country'] or '-'), esc(r['region']), esc(r['level'] or '无等级'), r['nbuy'], r['nsell'], esc(r['owners']), esc(r['src']), TIER_BG['优质客户'], esc(r['tier']), r['score']))
        _cards.append('<div class="bb">')
        _cards.append('<div class="row"><span class="k">四支柱</span><span class="v">%s</span></div>' % pillars(r))
        _cards.append('<div class="row"><span class="k">核心诉求</span><span class="v">%s</span></div>' % md(r['intent'] or DASH))
        if r['qty'] or r['price']:
            _cards.append('<div class="row"><span class="k">聊天硬证据</span><span class="v">数量 %s ｜ 单价 %s</span></div>' % (esc(r['qty'] or DASH), esc(r['price'] or DASH)))
        _cards.append('<div class="row"><span class="k">实力 / 核验</span><span class="v">%s</span></div>' % md(r['basis'] or DASH))
        if r['verify']:
            _cards.append('<div class="row"><span class="k">核验结论</span><span class="v">%s</span></div>' % md(r['verify']))
        _cards.append('<div class="row"><span class="k">身份线索</span><span class="v">%s</span></div>' % esc(r['signals']))
        _cards.append('<div class="row"><span class="k">命中理由</span><span class="v">%s</span></div>' % md('；'.join(r['reasons'])))
        _cards.append('<div class="act"><b>建议动作：</b>%s</div>' % md(r['action'] or DASH))
        _talk = r.get('talk') or r.get('talk_auto')
        if _talk:
            _tag = '' if r.get('talk') else '<span class="mono">（自动草稿 · 未逐条研判，发前请核对数量与市场）</span>'
            _cards.append('<div class="txt">%s %s<button class="cpbtn" onclick="ctCopy(this)">复制话术</button></div>' % (esc(_talk), _tag))
        _cards.append('</div></div>')
    n_head = len(_head)
    H.append(''.join(_cards[:n_head]))
    if _tail:
        H.append(fold('展开剩余 %d 个优质客户（分数较低的，可作培育池）' % len(_tail), ''.join(_cards[n_head:]), count='%d 个' % len(_tail)))
    return ''.join(H)

def owner_stats_of(rows):
    out = []
    for o in sorted(set((o for r in rows for o in r['owners'].split('/') if o and o != DASH))):
        mine = [r for r in rows if o in r['owners'].split('/')]
        cs = Counter((r['tier'] for r in mine))
        waits = [r['wait'] for r in mine if isinstance(r['wait'], int)]
        out.append((o, cs, len(mine), '%.0f%%' % (100.0 * cs.get('优质客户', 0) / len(mine)) if mine else DASH, sum((1 for r in mine if r['pending'] == '是')), max(waits) if waits else 0, sum((r['nbuy'] for r in mine)), sum((r['nsell'] for r in mine)), round(sum((r['meddic'] for r in mine)) / float(len(mine)), 1) if mine else 0))
    out.sort(key=lambda x: -(x[1].get('优质客户', 0) / max(1, x[2])))
    return out

def frag_owner(rows, ostats):
    H = []
    H.append('<div class="dash"><div class="panel"><div class="pt">各接待账号：客户质量与响应压力</div>')
    H.append('<div class="tw" style="max-height:none"><table><thead><tr><th>接待账号</th><th>客户数</th><th>优质</th><th>潜力</th><th>普通</th><th>无效</th><th>优质率</th><th>待回复</th><th>最长等待</th><th>买家消息</th><th>我方消息</th><th>平均MEDDIC</th></tr></thead><tbody>')
    for o, cs, n, rate, pend_n, max_wait, nb, ns, avg_m in ostats:
        H.append('<tr><td><b>%s</b></td><td>%d</td><td class="ok">%d</td><td>%d</td><td>%d</td><td>%d</td><td class="ok">%s</td><td class="%s">%d</td><td class="%s">%d 天</td><td class="mono">%d</td><td class="mono">%d</td><td class="mono">%s</td></tr>' % (esc(o), n, cs.get('优质客户', 0), cs.get('潜力客户', 0), cs.get('普通客户', 0), cs.get('无效 / 风险', 0), rate, 'warn' if pend_n else 'mono', pend_n, 'warn' if max_wait >= 3 else 'mono', max_wait, nb, ns, avg_m))
    tot = Counter()
    for r in rows:
        tot[r['tier']] += 1
    H.append('<tr><td><b>合计</b></td><td><b>%d</b></td><td><b>%d</b></td><td><b>%d</b></td><td><b>%d</b></td><td><b>%d</b></td><td><b>%s</b></td><td><b>%d</b></td><td>—</td><td class="mono"><b>%d</b></td><td class="mono"><b>%d</b></td><td>—</td></tr></tbody></table></div>' % (len(rows), tot.get('优质客户', 0), tot.get('潜力客户', 0), tot.get('普通客户', 0), tot.get('无效 / 风险', 0), '%.0f%%' % (100.0 * tot.get('优质客户', 0) / max(1, len(rows))), sum((1 for r in rows if r['pending'] == '是')), sum((r['nbuy'] for r in rows)), sum((r['nsell'] for r in rows))))
    H.append('</div>')
    H.append('<div class="panel"><div class="pt">各账号的优质客户数</div>%s<div class="ps">只统计「优质客户」。手上优质客户多的人不一定是运气好 —— 也可能是分到的流量质量高、或者跟得紧把潜力客户推上来了；配合「优质率」和「待回复/最长等待」一起看才准。</div></div>' % CH.barh([(o, cs.get('优质客户', 0)) for o, cs, n, _r, _p, _w, _nb, _ns, _m in ostats], unit=' 个', hi_from=3))
    H.append('</div>')
    if ostats:
        top3 = ostats[:3]
        worst = sorted(ostats, key=lambda x: -x[4])[:2]
        H.append('<div class="ps"><b>结论：</b>优质客户最集中的账号是 ' + '、'.join(('<b>%s</b>（优质 %d / 客户 %d，优质率 %s）' % (esc(o), cs.get('优质客户', 0), n, rate) for o, cs, n, rate, *_r in top3)) + '；<b>待回复压力最大</b>的是 ' + '、'.join(('<b>%s</b>（%d 个客户在等，最长 %d 天）' % (esc(o), p, w) for o, _cs, _n, _r, p, w, *_x in worst)) + '。对第 2 类账号，先把「一、优先行动」里的话术发出去，比再开新客户更划算。</div>')
    return ''.join(H)

def frag_blockers(rows, bstats):
    H = []
    n_action = sum((1 for r in rows if r.get('blocker') in ('NOT_REPLIED_US', 'NO_QUOTE', 'QUOTED_SILENT', 'SAMPLE_PENDING', 'SPEC_PENDING', 'CERT_PENDING', 'PAYMENT_PENDING', 'SHIPPING_PENDING', 'AWAIT_BUYER')))
    n_deal = sum((1 for r in rows if r.get('blocker') == 'DEAL'))
    n_chit = sum((1 for r in rows if r.get('blocker') == 'CHITCHAT'))
    n_card = sum((1 for r in rows if r.get('blocker') == 'CARD_ONLY'))
    H.append('<div class="kpis">')
    H.append('<div class="kpi alert"><div class="l">卡在流程上的单</div><div class="v">%d</div><div class="s">有明确卡点、可能一推就动</div></div>' % n_action)
    H.append('<div class="kpi good"><div class="l">已成交 / 在途</div><div class="v">%d</div><div class="s">不是卡点，维持交付节奏</div></div>' % n_deal)
    H.append('<div class="kpi"><div class="l">聊了但没谈生意</div><div class="v">%d</div><div class="s">有消息往来、零商业要素</div></div>' % n_chit)
    H.append('<div class="kpi"><div class="l">只有卡片 / 打招呼</div><div class="v">%d</div><div class="s">未进入实质沟通，别投打样</div></div>' % n_card)
    H.append('</div>')
    H.append('<div class="dash"><div class="panel"><div class="pt">卡点分布（按买家数）</div>%s<div class="ps">按「堵住的人数」排序。前四类都是**今天就能动手**的：我方未回复 / 问了价没报价 / 报价后失联 / 样品与规格卡住。</div></div>' % CH.barh([(x['label'], x['n']) for x in bstats if x['code'] not in ('CARD_ONLY', 'CHITCHAT')][:10], unit=' 个'))
    H.append('<div class="panel"><div class="pt">各卡点平均卡了多久</div><table><tbody>')
    for x in bstats:
        if x['code'] in ('CARD_ONLY',):
            continue
        H.append('<tr><td style="width:120px"><b>%s</b></td><td class="mono">%d 个</td><td class="%s">平均 %s 天</td><td>%s</td></tr>' % (esc(x['label']), x['n'], 'warn' if x['avg_days'] >= 3 else 'mono', x['avg_days'], esc(x['tip'])))
    H.append('</tbody></table><div class="ps">「卡了多久」= 该客户距最后一次往来 / 距买家最后一次发言的天数（取可用者）。天数越大越凉：≥7 天基本要重新破冰。</div></div></div>')
    detail = [r for r in rows if r.get('blocker') not in ('CARD_ONLY', 'CHITCHAT')]
    detail.sort(key=lambda r: -(r.get('blocker_days') if isinstance(r.get('blocker_days'), int) else 0))
    _n_all = len(detail)
    detail = detail[:25]
    H.append('<h3>逐个卡点与破局动作 <span style="font-weight:400;color:#8a98a6;font-size:12px">先处理「我方未回复 / 问了价没报价」，这两类转化最快</span></h3>')
    H.append('<div class="tw"><table><thead><tr><th>卡点</th><th>现在走到哪一步</th><th>卡了</th><th>客户</th><th>档位</th><th>分</th><th>接待</th><th>话术效率</th><th>买家要什么（原话）</th><th>我方缺口</th><th>怎么破</th></tr></thead><tbody>')
    for r in detail:
        d = r.get('blocker_days')
        H.append('<tr><td><b>%s</b><div class="mono">%s</div></td><td>%s</td><td class="%s">%s 天</td><td><b>%s</b></td><td><span class="tier" style="background:%s">%s</span></td><td><b>%d</b></td><td>%s</td><td class="mono">%s%%</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (esc(r.get('blocker_label')), esc(r.get('blocker_detail') or ''), esc(r.get('stage') or DASH), 'warn' if isinstance(d, int) and d >= 3 else 'mono', d if d != DASH else DASH, esc(r['name']), TIER_BG.get(r['tier'], '#94a3b8'), esc(r['tier']), r['score'], esc(r['owners']), r.get('chat_yield', DASH), esc(r.get('blocker_ask') or r.get('blocker_buyer_last') or DASH), esc(r.get('blocker_gap') or DASH), esc(r.get('blocker_tip') or DASH)))
    H.append('</tbody></table></div>')
    if _n_all > 25:
        H.append('<div class="mini">表里只列了卡得最久的 25 个；其余 %d 个明细见 Excel 台账「9 成交卡点」。</div>' % (_n_all - 25))
    oc = {}
    for r in rows:
        if r.get('blocker') in (None, 'CARD_ONLY', 'CHITCHAT'):
            continue
        for o in (r['owners'] or '').split('/'):
            o = o.strip()
            if not o or o == DASH:
                continue
            oc.setdefault(o, {}).setdefault(r['blocker_label'], 0)
            oc[o][r['blocker_label']] += 1
    if oc:
        H.append('<h3>谁手上卡着什么 <span style="font-weight:400;color:#8a98a6;font-size:12px">同一类卡点集中在某个人手上，往往是流程问题不是客户问题</span></h3>')
        H.append('<table><thead><tr><th>接待账号</th><th>卡点明细（卡点 × 人数）</th><th>合计</th></tr></thead><tbody>')
        for o in sorted(oc, key=lambda x: -sum(oc[x].values())):
            items = sorted(oc[o].items(), key=lambda x: -x[1])
            H.append('<tr><td><b>%s</b></td><td>%s</td><td>%d</td></tr>' % (esc(o), '；'.join(('%s %d' % (esc(k), v) for k, v in items)), sum(oc[o].values())))
        H.append('</tbody></table>')
    return ''.join(H)

def frag_pending(rows):
    pend = [r for r in rows if r['pending'] == '是']
    pend.sort(key=lambda r: -(r['wait'] if isinstance(r['wait'], int) else 0))
    H = ['<div class="tw" style="max-height:none"><table><thead><tr><th>等待</th><th>客户</th><th>档位</th><th>分</th><th>国家</th><th>接待</th><th>核心诉求</th><th>建议动作</th><th>可直接发的话术</th></tr></thead><tbody>']
    for r in pend:
        w = r['wait'] if isinstance(r['wait'], int) else 0
        H.append('<tr><td class="%s">%s 天</td><td><b>%s</b></td><td><span class="tier" style="background:%s">%s</span></td><td><b>%d</b></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><div class="txt">%s<button class="cpbtn" onclick="ctCopy(this)">复制话术</button></div></td></tr>' % ('warn' if w >= 3 else 'mono', w, esc(r['name']), TIER_BG.get(r['tier'], '#94a3b8'), esc(r['tier']), r['score'], esc(r['country'] or DASH), esc(r['owners']), esc(r['intent']), esc(r['action']), esc(r.get('talk') or r.get('talk_auto') or '（无现成话术，按建议动作回）')))
    H.append('</tbody></table></div>')
    return ''.join(H)

def frag_wait_verify(rows, limit=15):
    wv = [r for r in rows if r['grade'] not in ('中-强', '中', '弱-中', '弱')]
    H = ['<table><thead><tr><th>客户</th><th>档位</th><th>分</th><th>国家</th><th>等级</th><th>消息<br>买/我</th><th>聊天里有的线索</th><th>还缺什么（向客户索取）</th></tr></thead><tbody>']
    for r in wv[:limit]:
        H.append('<tr><td><b>%s</b></td><td><span class="tier" style="background:%s">%s</span></td><td><b>%d</b></td><td>%s</td><td>%s</td><td class="mono">%d / %d</td><td class="mono">%s</td><td>%s</td></tr>' % (esc(r['name']), TIER_BG.get(r['tier'], '#94a3b8'), esc(r['tier']), r['score'], esc(r['country'] or DASH), esc(r['level'] or DASH), r['nbuy'], r['nsell'], esc(r['signals']), esc('；'.join(r['ask'][:3]))))
    H.append('</tbody></table>')
    if len(wv) > limit:
        H.append('<div class="mini">只列前 %d 个（按分数排序）；其余 %d 个全量见 Excel 台账「7 待核验索取清单」—— 处理方式一样，不重复占版面。</div>' % (limit, len(wv) - limit))
    return ''.join(H)

def frag_verified(auto, auto_meta):
    GORD = {'中-强': 0, '中': 1, '弱-中': 2, '弱': 3}
    ver = [(nm, v) for nm, v in auto.items() if v.get('grade') not in (None, '待核验')]
    ver.sort(key=lambda x: (GORD.get(x[1].get('grade'), 9), x[0]))
    H = []
    if ver:
        H.append('<div class="tw" style="max-height:none"><table><thead><tr><th>客户</th><th>核验档</th><th>主体 / 域名</th><th>域名核验</th><th>官网核验</th><th>邮箱 / 社媒线索</th><th>核验结论</th></tr></thead><tbody>')
        for nm, v in ver:
            rd, si, rg = (v.get('rdap') or {}, v.get('site') or {}, v.get('registry') or {})
            sub = v.get('entity') or ((rg.get('hits') or [{}])[0].get('name') if rg.get('hits') else '') or DASH
            if rd.get('domain'):
                sub += '<div class="mono">%s</div>' % esc(rd['domain'])
            dom = DASH
            if rd.get('domain'):
                dom = '%s<div class="mono">%s%s</div>' % ('已注册' if rd.get('registered') else '未注册', '注册于 %s' % rd.get('created') if rd.get('created') else '', '\u3000%.1f 年' % rd['age_years'] if isinstance(rd.get('age_years'), float) else '')
            site = DASH
            if rd.get('domain'):
                state = '<span class="warn">停放/待售</span>' if si.get('parked') else '在营' if si.get('reachable') else '<span class="warn">不可访问</span>'
                site = '%s%s' % (state, '<div class="mono">%s</div>' % esc((si.get('title') or '')[:52]) if si.get('title') else '')
            _ms = []
            if v.get('mail_kind'):
                _ms.append(esc(v['mail_kind']))
            for _e in (v.get('emails') or [])[:2]:
                _ms.append('<div class="mono">%s</div>' % esc(_e))
            if v.get('gravatar'):
                _ms.append('<span class="ok">Gravatar 有</span>')
            if v.get('youtube'):
                _ms.append('<span class="ok">YouTube：%s</span>' % esc('、'.join(v['youtube'][:2])))
            for _u in (v.get('social') or [])[:2]:
                _ms.append('<div class="mono">%s</div>' % esc(_u))
            for _pr in (v.get('phone_regions') or [])[:2]:
                _ms.append('<div class="mono">号码归属 %s</div>' % esc(_pr[1]))
            H.append('<tr><td><b>%s</b></td><td><span class="tier" style="background:%s">%s</span></td><td>%s</td><td class="mono">%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (esc(nm), '#3f8f57' if v.get('grade') in ('中-强', '中') else '#a86a11', esc(v.get('grade')), md(sub), dom, site, '<br>'.join(_ms) or DASH, md(v.get('verify') or DASH)))
        H.append('</tbody></table></div>')
    else:
        H.append('<div class="mono">本期没有查到公开实证的主体（全部为线索级或待核验）。</div>')
    srcs = (auto_meta or {}).get('sources') or {}
    n_mail = sum((1 for v in auto.values() if v.get('emails')))
    n_person = sum((1 for v in auto.values() if v.get('mail_kind') == '个人邮箱'))
    n_gv = sum((1 for v in auto.values() if v.get('gravatar')))
    H.append('<div class="reg" style="margin-top:9px"><b>个人邮箱 / 社媒这块能查到什么（实测）：</b>本期 %d 个客户给了邮箱（其中个人邮箱 %d 个），Gravatar 命中 %d 个。社媒平台侧本机实测<b>基本查不动</b>：LinkedIn 返回 999、Instagram 登录墙、TikTok 存在与否返回同一页面、Facebook 直接拦截、Bing 搜索接口返回无关结果、DuckDuckGo 出人机验证、emailrep.io 无 key 限流 429。所以社媒只能走两条<b>能验证</b>的路：① 客户主动给的企业邮箱域（拿去做 RDAP + 官网核验）；② Gravatar / YouTube 用户名存在性。剩下的靠当地工商库（目前仅英国免费）和客户自己提供注册号。要给更深的社媒穿透，需要另外的额度/接口：LinkedIn 登录会话，或 Hunter / emailrep 之类付费 key。</div>')
    H.append('<div class="ps"><b>用到的源：</b>%s。<b>本机不可用的源（如实标注，不硬凑）：</b>USPTO 商标检索（403）、bizapedia（需订阅）、OpenCorporates 网页版（JS 渲染）。「未注册」「停放页」是<b>负证据</b> —— 说明买家给的邮箱/网站不是在营主体，签约前必须索取注册号再谈条款。</div>' % esc('；'.join(('%s：%s' % (k, v) for k, v in srcs.items())) or 'rdap.org 域名注册 / 客户官网抓取 / 英国公司注册处'))
    return ''.join(H)

def write_html(path, rows, win, store, tcnt, pend, ccnt, auto, auto_meta, n_conv=0, bstats=None):
    ostats = owner_stats_of(rows)
    bstats = bstats or []
    n_web = sum((1 for r in rows if r['grade'] in ('中-强', '中')))
    n_clue = sum((1 for r in rows if r['grade'] in ('弱-中', '弱')))
    n_wait = sum((1 for r in rows if r['pending'] == '是'))
    n_msg = sum((r['nsell'] + r['nbuy'] for r in rows))
    label = store.get('name') or DASH
    H = ['<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">', '<meta name="viewport" content="width=device-width,initial-scale=1">', '<title>客户分层分析表 %s</title>' % esc(label), PAGE_CSS, '</head><body><div class="wrap">']
    H.append('<div class="rhead"><div class="flex"><div><div class="rt">询盘客户分层分析表</div><div class="rs">店铺 <b>%s</b> ｜ 窗口 %s ~ %s ｜ 买家 %d / 会话 %d / 消息 %d ｜ 生成 %s<br>分层只看客观证据：<b>聊天记录 + 客户信息 + 背调结论</b>（内部 CRM 标签仅作辅助）</div></div><div style="white-space:nowrap"><button class="rprint" onclick="window.print()">打印 / 存为PDF</button><button class="rprint" onclick="collapseAll2()">折叠 / 展开</button></div></div></div>' % (esc(label), esc((win.get('since') or '')[:16]), esc((win.get('until') or '')[:16]), len(rows), n_conv or len(rows), n_msg, datetime.now().strftime('%Y-%m-%d %H:%M')))
    H.append('<div class="toc2"><a href="#sr">结论与行动</a><a href="#sb">背调结论</a><a href="#s0">概览</a><a href="#s1">分层构成</a><a href="#s2">分层总表</a><a href="#s3">优质客户</a><a href="#s4">业务员情况</a><a href="#s5">成交卡点</a><a href="#s6">待跟进</a><a href="#s7">待核验索取</a><a href="#s8">已核验主体</a><a href="#s9">公司档案</a></div>')
    import inq_brief as _IB
    H.append('<section id="sr"><h2>结论与行动 <span class="hsub">评估 → 方向 → 动作</span></h2>')
    H.append('<div class="ctbl">%s</div>' % _IB.build(rows, bstats))
    H.append('</section>')
    H.append('<section id="sb"><h2>背调结论汇总 <span class="hsub">邮箱 → 域名 → 官网 → 工商库 → Gravatar → YouTube → 独立站 → 社媒</span></h2>')
    H.append('<div class="ctbl">%s</div>' % frag_backdive(rows))
    H.append('</section>')
    H.append('<section id="s0"><h2>概览 <span class="hsub">一眼看清这批客户的质量结构</span></h2>')
    H.append('<div class="kpis">')
    H.append('<div class="kpi good"><div class="l">优质客户</div><div class="v">%d</div><div class="s">聊天+背调+客户信息三支柱均有硬证据</div></div>' % tcnt.get('优质客户', 0))
    H.append('<div class="kpi"><div class="l">潜力客户</div><div class="v">%d</div><div class="s">有真实互动，可培育</div></div>' % tcnt.get('潜力客户', 0))
    H.append('<div class="kpi"><div class="l">普通客户</div><div class="v">%d</div><div class="s">单项有分，泛询价为主</div></div>' % tcnt.get('普通客户', 0))
    H.append('<div class="kpi alert"><div class="l">无效 / 风险</div><div class="v">%d</div><div class="s">买家未发言 / 涉管制成分 / 无实质</div></div>' % tcnt.get('无效 / 风险', 0))
    H.append('<div class="kpi alert"><div class="l">待我方回复</div><div class="v">%d</div><div class="s">最后一句是买家说的</div></div>' % n_wait)
    H.append('<div class="kpi"><div class="l">有公网实证</div><div class="v">%d</div><div class="s">域名 / 官网 / 工商库查到实据</div></div>' % n_web)
    H.append('<div class="kpi"><div class="l">线索级可追溯</div><div class="v">%d</div><div class="s">有公司名 / 电话 / 地址 / 邮箱</div></div>' % n_clue)
    H.append('<div class="kpi"><div class="l">待核验</div><div class="v">%d</div><div class="s">只有一个昵称，无从查起</div></div>' % (len(rows) - n_web - n_clue))
    H.append('</div></section>')
    H.append('<section id="s1"><h2>分层构成与口径 <span class="hsub">档位怎么定的，逐条可复核</span></h2>')
    H.append('<div class="dash"><div class="panel"><div class="pt">质量构成（按买家去重）</div>%s<div class="ps">%s</div></div>' % (CH.donut([(t, tcnt.get(t, 0), TIER_BG[t]) for t in TIERS if tcnt.get(t)]), ' ｜ '.join(('%s %d' % (t, tcnt.get(t, 0)) for t in TIERS if tcnt.get(t)))))
    H.append('</div></section>')
    H.append('<section id="s2"><h2>客户分层总表 <span class="hsub">点档位筛选 · 可搜索 · 表头固定</span></h2>')
    H.append('<div class="ctbl">%s</div>' % frag_tiering(rows, tcnt, 'ctTableStandaloneTierBox'))
    H.append('</section>')
    H.append('<section id="s3"><h2>优质客户明细 <span class="hsub">共 %d 个 · 每个都列全命中的理由</span></h2>' % tcnt.get('优质客户', 0))
    H.append('<div class="ctbl">%s</div>' % frag_good(rows))
    H.append('</section>')
    H.append('<section id="s4"><h2>业务员情况 <span class="hsub">谁手里优质客户多 · 谁待回复压力大</span></h2>')
    H.append('<div class="ctbl">%s</div>' % frag_owner(rows, ostats))
    H.append('</section>')
    H.append('<section id="s5"><h2>成交卡点诊断 <span class="hsub">业务进程卡在哪一环 · 卡了多久 · 怎么破</span></h2>')
    H.append('<div class="ctbl">%s</div>' % frag_blockers(rows, bstats))
    H.append('</section>')
    H.append('<section id="s6"><h2>待跟进行动项 <span class="hsub">最后一句是买家说的 %d 个</span></h2>' % n_wait)
    H.append('<div class="ctbl">%s</div>' % (frag_pending(rows) if n_wait else '<div class="mono">全部已回复。</div>'))
    H.append('</section>')
    H.append('<section id="s7"><h2>待核验索取清单 <span class="hsub">只有昵称的客户 · 签约前该向他们要什么</span></h2>')
    H.append('<div class="reg"><b>为什么查不到：</b>不是没查 —— 这些买家在聊天和平台字段里<b>都没有可核验主体</b>（没公司名、没域名、没企业邮箱），公开渠道无从下手。处理方式：谈判前索取 <b>公司注册号 / 官网 / 公司全称 / 税号</b>，拿到任一项下一期即可自动升级。</div>')
    H.append('<div class="ctbl" style="margin-top:10px">%s</div>' % frag_wait_verify(rows))
    H.append('</section>')
    H.append('<section id="s8"><h2>已核验主体 <span class="hsub">查过哪些源、拿到什么（含负证据）</span></h2>')
    H.append('<div class="ctbl">%s</div>' % frag_verified(auto, auto_meta))
    H.append('</section>')
    H.append('<section id="s9"><h2>公司档案（独立站深挖） <span class="hsub">官网首页/关于/联系页 → 主体 · 主营 · 电话 · 社媒 · 电商</span></h2>')
    H.append('<div class="ctbl">%s</div>' % frag_profiles(rows))
    H.append('</section>')
    H.append('<div class="foot">数据来源：阿里巴巴国际站 TradeManager（workctl icbu tm / chat-analysis 官方管道，窗口上限 7 天）｜ 主体线索：聊天原文抽取 ｜ 公网核验：rdap.org + 客户官网 + 英国公司注册处 ｜ 国家判定：登录名前 2 位 ISO 码<br>免责：平台标签为该账号近 90 天行为；聊天里的数字为客户自述，未经第三方核验。生成 %s</div>' % datetime.now().strftime('%Y-%m-%d %H:%M'))
    H.append('</div>')
    H.append(TIERING_JS)
    H.append("<script>\nfunction collapseAll2(){var s=document.querySelectorAll('section');\n var anyOpen=[].some.call(s,function(x){return !x.classList.contains('collapsed');});\n [].forEach.call(s,function(x){x.classList.toggle('collapsed',anyOpen);});}\ndocument.querySelectorAll('section h2').forEach(function(h){\n h.addEventListener('click',function(){h.parentElement.classList.toggle('collapsed');});});\nctBind('ctTableStandaloneTierBox');\n</script>")
    H.append('</body></html>')
    with open(path, 'w', encoding='utf-8') as f:
        f.write(''.join(H))
    return path

def _bg_concl(r):
    p = r.get('profile') or {}
    site_on = bool(p.get('fetched')) and (not p.get('not_launched'))
    has_soc = bool(p.get('socials'))
    ent = '、'.join(p.get('legal_entities') or []) or (r.get('entity') or '').strip()
    mails = r.get('emails') or []
    corp = [m for m in mails if not is_junk_domain(m.split('@')[-1])]
    if ent and site_on:
        nxt = '主体已查实 → 直接按公司对公谈（合同主体写「%s」）' % ent[:24]
        if has_soc:
            nxt += '；社媒有新动态时用来开场'
        return ('ok', '公司主体可查实', nxt)
    if site_on and has_soc:
        return ('ok', '品牌方（独立站在营 + 有社媒）', '按品牌叙事谈私标与上新节奏，可直接发 spec sheet')
    if site_on:
        return ('ok', '独立站在营（未查到主体名）', '谈单时索取公司注册号 / 公司全称，补全合同主体')
    if corp:
        return ('warn', '有企业邮箱域（官网未抓到内容）', '域名已确认；索取官网与注册号后下一期自动升级')
    if r.get('gravatar') or (r.get('gravatar_names') or []):
        return ('warn', '个人邮箱 + 真人身份可互证', '个人 / 小买家：小额快周转，全额走 Trade Assurance')
    if r.get('youtube') or (r.get('handles') or []):
        return ('warn', '有可复用 handle（无主体）', '用同名 handle 找其社媒主页，确认后再投打样')
    if mails:
        return ('mono', '只有个人域邮箱', '先邮件 / WhatsApp 触达，逐步索取主体信息')
    return ('mono', '公开渠道查不到主体', '只有一个昵称：谈单前必须索取注册号 / 官网 / 公司全称 / 税号')

def frag_backdive(rows):
    ev = [r for r in rows if r.get('emails') or r.get('domains') or r.get('gravatar') or r.get('youtube') or (r.get('profile') or {}).get('fetched') or (r.get('entity') or '').strip()]
    n_mail = sum((1 for r in rows if r.get('emails')))
    n_corp = sum((1 for r in rows if any((not is_junk_domain(m.split('@')[-1]) for m in r.get('emails') or []))))
    n_site = sum((1 for r in rows if (r.get('profile') or {}).get('fetched')))
    n_soc = sum((1 for r in rows if (r.get('profile') or {}).get('socials')))
    n_gv = sum((1 for r in rows if r.get('gravatar')))
    _sl = [r.get('strength') or {} for r in rows]
    n_strong = sum((1 for x in _sl if x.get('level') in ('强', '中-强')))
    n_mid = sum((1 for x in _sl if x.get('level') == '中'))
    H = ['<div class="kpis">']
    H.append('<div class="kpi" style="border-left:4px solid #1c5fa8"><div class="l">拿到邮箱</div><div class="v">%d</div><div class="s">其中企业域 %d 个</div></div>' % (n_mail, n_corp))
    H.append('<div class="kpi" style="border-left:4px solid #2e9e5b"><div class="l">抓到独立站</div><div class="v">%d</div><div class="s">官网可访问并抓到内容</div></div>' % n_site)
    H.append('<div class="kpi" style="border-left:4px solid #a86a11"><div class="l">拿到社媒账号</div><div class="v">%d</div><div class="s">从客户独立站页脚抓取</div></div>' % n_soc)
    H.append('<div class="kpi"><div class="l">Gravatar 命中</div><div class="v">%d</div><div class="s">邮箱 → 真实显示名 / handle</div></div>' % n_gv)
    H.append('<div class="kpi" style="border-left:4px solid #c0392b"><div class="l">实力可评级</div><div class="v">%d</div><div class="s">强/中-强 %d ｜ 中 %d（其余证据不足）</div></div>' % (sum((1 for x in _sl if x.get('level') not in (None, '待核验'))), n_strong, n_mid))
    H.append('</div>')
    H.append('<div class="ps">八路证据，按可用性排序：<b>① 后台邮箱</b>（contactEmail，覆盖率最高）→ <b>② 域名 RDAP</b> → <b>③ 官网抓取</b> → <b>④ 工商库</b> → <b>⑤ Gravatar</b>（邮箱→显示名/handle）→ <b>⑥ YouTube 用户名</b> → <b>⑦ 独立站深挖</b>（主体/电话/地址/主营）→ <b>⑧ 站内社媒链接</b>。平台侧 LinkedIn / Instagram / TikTok / Facebook / Bing 搜索实测全部不可用，社媒只走独立站页脚这条路 —— 拿不到就写拿不到，不编。</div>')
    H.append('<h3>逐个背调结论 <span style="font-weight:400;color:#8a98a6;font-size:12px">只列「有任一背调证据」的客户；无证据的见 3-3 与「待核验索取清单」</span></h3>')
    H.append('<div class="tw" style="max-height:none"><table><thead><tr><th>客户</th><th>实力 · 该不该追</th><th>邮箱 / 电话</th><th>主体 · 域名（RDAP / 官网 / 工商库）</th><th>身份线索</th><th>独立站 · 社媒</th><th>下一步</th></tr></thead><tbody>')
    for r in sorted(ev, key=lambda x: (x['tier'] != '优质客户', -x['score'])):
        p = r.get('profile') or {}
        _m = '<span class="tier" style="background:%s">%s</span>' % (TIER_BG.get(r['tier'], '#94a3b8'), esc(r['tier']))
        cm = []
        if r.get('mail_kind'):
            cm.append('<span class="mono">%s</span>' % esc(r['mail_kind']))
        for e in (r.get('emails') or [])[:2]:
            cm.append('<div class="mono">%s</div>' % esc(e))
        for t in (p.get('phones') or [])[:2]:
            cm.append('<div class="mono">%s</div>' % esc(t))
        for pr in (r.get('phone_regions') or [])[:1]:
            cm.append('<div class="mini">号码归属 %s</div>' % esc(pr[1]))
        cd = []
        _ent = (r.get('entity') or '').strip() or '、'.join(p.get('legal_entities') or [])
        if _ent:
            cd.append('<div><b>%s</b></div>' % esc(_ent[:40]))
        _d = p.get('domain') or (r.get('domains') or [''])[0]
        if _d:
            cd.append('<div class="mono">%s</div>' % esc(_d))
        rd = r.get('rdap') or {}
        if rd.get('registered') is False:
            cd.append('<div class="mini">RDAP：域名未注册</div>')
        elif rd.get('registered'):
            cd.append('<div class="mini">RDAP：已注册%s</div>' % ('，' + str(rd.get('created'))[:10] if rd.get('created') else ''))
        st_ = r.get('site') or {}
        if st_.get('reachable'):
            cd.append('<div class="mini">官网%s</div>' % ('（停放/待售）' if st_.get('parked') else '在营'))
        elif st_:
            cd.append('<div class="mini">官网不可访问</div>')
        rg = r.get('registry') or {}
        if rg.get('hit'):
            cd.append('<div class="mini">工商库命中：%s</div>' % esc(str(rg.get('name') or '')[:30]))
        ci = []
        for nm0 in (r.get('gravatar_names') or [])[:2]:
            ci.append('<div><b>%s</b> <span class="mini">（Gravatar 显示名）</span></div>' % esc(nm0))
        for u in (r.get('gravatar_users') or [])[:2]:
            ci.append('<div class="mono">handle @%s</div>' % esc(u))
        for y in (r.get('youtube') or [])[:2]:
            ci.append('<div class="mono">YouTube：%s</div>' % esc(y))
        for h0 in (r.get('handles') or [])[:2]:
            ci.append('<div class="mini">可用 handle：%s</div>' % esc(h0))
        cs = []
        for s0 in (p.get('socials') or [])[:5]:
            cs.append('<div class="mono">%s</div>' % esc(s0))
        if p.get('ecommerce'):
            cs.append('<span class="ok">电商站</span>')
        if p.get('not_launched'):
            cs.append('<span class="warn">站点未上线</span>')
        for h1 in (p.get('size_hints') or [])[:1]:
            cs.append('<div class="mini">%s</div>' % esc(h1[:90]))
        _cls, concl, nxt = _bg_concl(r)
        _st = r.get('strength') or {}
        _lvl = _st.get('level') or '待核验'
        _cs2 = []
        for _w in (_st.get('why') or [])[:3]:
            _cs2.append('<div class="mini">%s</div>' % esc(_w))
        H.append('<tr><td><b>%s</b><div>%s</div><div class="mono">%s 分（档位）</div></td><td><b style="color:%s">%s</b><div class="mono">%s 分</div><div><b>%s</b></div>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><div class="mini">%s</div></td></tr>' % (esc(r['name']), _m, esc(r['score']), esc('#2e9e5b' if _lvl in ('强', '中-强') else '#a86a11' if _lvl == '中' else '#c0392b'), esc(_lvl), esc(_st.get('score', 0)), esc(_st.get('verdict') or DASH), ''.join(_cs2) or '', ''.join(cm) or DASH, ''.join(cd) or DASH, ''.join(ci) or DASH, ''.join(cs) or DASH, esc(nxt)))
    H.append('</tbody></table></div>')
    return ''.join(H)

def frag_profiles(rows):
    pro = [r for r in rows if (r.get('profile') or {}).get('fetched')]
    if not pro:
        return '<div class="ps">本期没有客户留下可访问的独立站 —— 这批主体在公开渠道只有昵称，公司档案只能靠聊天线索 + 向客户索取注册号与官网。这不是没查，是查不到。</div>'
    n_soc = sum((1 for r in pro if r['profile'].get('socials')))
    n_tel = sum((1 for r in pro if r['profile'].get('phones')))
    n_ec = sum((1 for r in pro if r['profile'].get('ecommerce')))
    n_pending = sum((1 for r in pro if r['profile'].get('not_launched')))
    H = ['<div class="kpis">']
    H.append('<div class="kpi" style="border-left:4px solid #2e9e5b"><div class="l">抓到独立站</div><div class="v">%d</div><div class="s">官网可访问并抓到内容</div></div>' % len(pro))
    H.append('<div class="kpi" style="border-left:4px solid #1c5fa8"><div class="l">拿到社媒账号</div><div class="v">%d</div><div class="s">从客户自己网站页脚抓的，非平台搜索</div></div>' % n_soc)
    H.append('<div class="kpi"><div class="l">拿到电话</div><div class="v">%d</div><div class="s">可直接约通话</div></div>' % n_tel)
    H.append('<div class="kpi"><div class="l">电商站 / 未上线</div><div class="v">%d<small>/%d</small></div><div class="s">有购物车的品牌方 / 站点还在「即将推出」</div></div>' % (n_ec, n_pending))
    H.append('</div>')
    H.append('<div class="ps">口径说明：<b>平台侧社媒搜索全部不可用</b>（LinkedIn 999、Instagram 登录墙、TikTok 无法区分、Facebook 拦截、Bing 返回无关结果），所以社媒只能从客户自己的独立站页脚拿。没独立站的客户（多数）拿不到社媒 —— 这是能力边界，不是漏查。</div>')
    H.append('<h3>逐个公司档案 <span style="font-weight:400;color:#8a98a6;font-size:12px">主体名 / 主营 / 联系方式 / 社媒 都可直接用于谈单开场</span></h3>')
    H.append('<div class="tw" style="max-height:none"><table><thead><tr><th>客户</th><th>档位</th><th>主体 / 独立站</th><th>主营方向</th><th>联系方式</th><th>社媒账号</th><th>电商 / 规模线索</th></tr></thead><tbody>')
    for r in sorted(pro, key=lambda x: -x['score']):
        p = r['profile']
        _nm = esc(r['name'])
        _ent = '、'.join(p.get('legal_entities') or []) or '（站上未见法律主体名）'
        _dom = esc(p.get('domain') or '')
        _site = '<div class="mono">%s</div><div class="mini">%s</div>' % (_dom, esc((p.get('title') or '')[:70]))
        _ind = esc('、'.join(p.get('industry') or []) or DASH)
        _ct = []
        for t in (p.get('phones') or [])[:2]:
            _ct.append('<div class="mono">%s</div>' % esc(t))
        for e in (p.get('emails') or [])[:2]:
            _ct.append('<div class="mono">%s</div>' % esc(e))
        for a in (p.get('addresses') or [])[:1]:
            _ct.append('<div class="mini">%s</div>' % esc(a))
        _soc = []
        for s in (p.get('socials') or [])[:6]:
            _soc.append('<div class="mono">%s</div>' % esc(s))
        _tail = []
        if p.get('ecommerce'):
            _tail.append('<span class="ok">有购物车 / 电商站</span>')
        if p.get('not_launched'):
            _tail.append('<span class="warn">站点未上线</span>')
        for s in (p.get('size_hints') or [])[:2]:
            _tail.append('<div class="mini">%s</div>' % esc(s[:110]))
        H.append('<tr><td><b>%s</b><div class="mono">%s</div></td><td><span class="tier" style="background:%s">%s</span></td><td>%s%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (_nm, esc(r['score']), TIER_BG.get(r['tier'], '#94a3b8'), esc(r['tier']), esc(_ent), _site, _ind, ''.join(_ct) or DASH, ''.join(_soc) or DASH, ''.join(_tail) or DASH))
    H.append('</tbody></table></div>')
    return ''.join(H)

def report_extras(rows, tcnt, ostats, bstats=None):
    bstats = bstats or []
    secs = [('s9', '九、客户分层总表', '四支柱打分 · 点档位筛选 · 可搜索 · 逐条列出命中依据', '<div class="ctbl">%s</div>' % frag_tiering(rows, tcnt, 'ctTierBox', standalone_note=False)), ('s10', '十、优质客户清单', '共 %d 个 ｜ 凭什么是优质，全列出来了' % tcnt.get('优质客户', 0), '<div class="ctbl">%s</div>' % frag_good(rows)), ('s11', '十一、业务员情况', '谁手里优质客户多 · 谁待回复压力大 · 谁在跟泛询价', '<div class="ctbl">%s</div>' % frag_owner(rows, ostats)), ('s12', '十二、成交卡点诊断', '业务进程卡在哪一环 · 卡了多久 · 怎么破（含话术效率）', '<div class="ctbl">%s</div>' % frag_blockers(rows, bstats)), ('s13', '十三、公司档案（独立站深挖）', '官网首页/关于/联系页抓出的主体 · 地址 · 电话 · 主营 · 社媒账号 · 是否电商站', '<div class="ctbl">%s</div>' % frag_profiles(rows))]
    return (REPORT_CSS, TIERING_JS, secs)
