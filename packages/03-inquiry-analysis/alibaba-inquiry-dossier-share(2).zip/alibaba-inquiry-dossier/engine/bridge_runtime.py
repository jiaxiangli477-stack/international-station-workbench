import importlib.util
from pathlib import Path
from urllib.parse import urlsplit

def child_environment(executable, env):
    setup = Path(__file__).parent / 'accio_discovery.py'
    spec = importlib.util.spec_from_file_location('accio_discovery', setup)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    creds = module.find_credentials()
    url = urlsplit(creds.get('url', ''))
    if not creds.get('note', '').startswith('pid=') or not creds.get('token') or url.scheme != 'http' or (url.hostname not in ('localhost', '127.0.0.1', '::1')) or (url.port != 4097):
        raise ValueError('未找到当前 Accio 本地网关，请确认已登录并运行')
    result = dict(env)
    result.update(ACCIO_GATEWAY_TOKEN=creds['token'], ACCIO_GATEWAY_USERNAME=creds.get('user') or 'phoenix', ACCIO_LOCAL_GATEWAY_URL=creds['url'])
    return result
