NAVY = '#16324f'
GOLD = '#f5c518'
GRID = '#e2e8f0'
TXT = '#334155'
MUT = '#8b98a6'
GCOLOR = {'A': '#2e9e5b', 'B': '#1c5fa8', 'C': '#94a3b8', 'R': '#c0392b'}
AXES = ['M 痛点量化', 'E 决策人', '决策标准', '决策流程', 'I 痛点识别', 'C 内部支持']
AXES_SHORT = ['M', 'E', '标准', '流程', 'I', 'C']

def _esc(s):
    return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')

def donut(items, size=240, thick=42):
    total = sum((v for _, v, _ in items)) or 1
    cx = cy = size / 2.0
    r = (size - thick) / 2.0 - 6
    out = ['<svg viewBox="0 0 %d %d" width="100%%" style="max-width:%dpx">' % (size, size, size)]
    import math
    a0 = -90.0
    for label, val, color in items:
        if val <= 0:
            continue
        sweep = 360.0 * val / total
        a1 = a0 + sweep
        large = 1 if sweep > 180 else 0
        x0 = cx + r * math.cos(math.radians(a0))
        y0 = cy + r * math.sin(math.radians(a0))
        x1 = cx + r * math.cos(math.radians(a1))
        y1 = cy + r * math.sin(math.radians(a1))
        out.append('<path d="M %.2f %.2f A %.2f %.2f 0 %d 1 %.2f %.2f" fill="none" stroke="%s" stroke-width="%.1f" stroke-linecap="butt"/>' % (x0, y0, r, r, large, x1, y1, color, thick))
        mid = (a0 + a1) / 2.0
        lx = cx + (r + thick / 2.0 + 0) * math.cos(math.radians(mid))
        ly = cy + (r + thick / 2.0 + 0) * math.sin(math.radians(mid))
        if sweep > 22:
            out.append('<text x="%.1f" y="%.1f" text-anchor="middle" dominant-baseline="middle" font-size="11" font-weight="700" fill="#fff">%d</text>' % (lx, ly, round(100.0 * val / total)))
        a0 = a1
    out.append('<text x="%.1f" y="%.1f" text-anchor="middle" font-size="27" font-weight="800" fill="%s">%d</text>' % (cx, cy - 4, NAVY, total))
    out.append('<text x="%.1f" y="%.1f" text-anchor="middle" font-size="11" fill="%s">买家总数</text>' % (cx, cy + 15, MUT))
    out.append('</svg>')
    lg = ['<div style="display:flex;flex-wrap:wrap;gap:10px 16px;margin-top:6px">']
    for label, val, color in items:
        lg.append('<span style="font-size:12px;display:inline-flex;align-items:center;gap:5px"><i style="width:10px;height:10px;border-radius:3px;background:%s;display:inline-block"></i>%s <b>%d</b></span>' % (color, _esc(label), val))
    lg.append('</div>')
    return ''.join(out) + ''.join(lg)

def barh(items, unit='', hi_from=None, w=560, rowh=26, pad_l=104):
    n = len(items)
    h = n * rowh + 10
    vmax = max([v for _, v in items] or [1]) or 1
    bar_w = w - pad_l - 52
    out = ['<svg viewBox="0 0 %d %d" width="100%%" style="max-width:%dpx">' % (w, h, w)]
    for i, (label, val) in enumerate(items):
        y = i * rowh + 4
        bw = max(2.0, bar_w * val / vmax)
        hi = hi_from is not None and val >= hi_from
        color = GCOLOR['R'] if hi else NAVY
        out.append('<text x="%d" y="%.1f" text-anchor="end" font-size="12" fill="%s" dominant-baseline="middle">%s</text>' % (pad_l - 10, y + rowh / 2.0 - 3, TXT, _esc(label)))
        out.append('<rect x="%d" y="%.1f" width="%d" height="%.1f" rx="4" fill="#eef2f7"/>' % (pad_l, y + 3, bar_w, rowh - 12))
        out.append('<rect x="%d" y="%.1f" width="%.1f" height="%.1f" rx="4" fill="%s"><title>%s: %s%s</title></rect>' % (pad_l, y + 3, bw, rowh - 12, color, _esc(label), val, unit))
        out.append('<text x="%d" y="%.1f" font-size="12" font-weight="700" fill="%s" dominant-baseline="middle">%s%s</text>' % (pad_l + bw + 7, y + rowh / 2.0 - 3, color, val, unit))
    out.append('</svg>')
    return ''.join(out)

def scatter(points, w=760, h=460):
    pad_l, pad_r, pad_t, pad_b = (58, 26, 30, 46)
    iw, ih = (w - pad_l - pad_r, h - pad_t - pad_b)
    out = ['<svg viewBox="0 0 %d %d" width="100%%" style="max-width:%dpx">' % (w, h, w)]
    xm, ym = (pad_l + iw * 0.3, pad_t + ih * (1 - 6 / 12.0))
    out.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="#f2faf4"/>' % (xm, pad_t, pad_l + iw - xm, ym - pad_t))
    out.append('<rect x="%d" y="%.1f" width="%.1f" height="%.1f" fill="#fbfcfe"/>' % (pad_l, pad_t, xm - pad_l, ym - pad_t))
    out.append('<rect x="%d" y="%.1f" width="%.1f" height="%.1f" fill="#f8f9fb"/>' % (pad_l, ym, xm - pad_l, pad_t + ih - ym))
    out.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="#fffdf5"/>' % (xm, ym, pad_l + iw - xm, pad_t + ih - ym))
    out.append('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" stroke="%s"/>' % (pad_l, pad_t + ih, pad_l + iw, pad_t + ih, GRID))
    out.append('<line x1="%d" y1="%d" x2="%d" y2="%.1f" stroke="%s"/>' % (pad_l, pad_t, pad_l, pad_t + ih, GRID))
    out.append('<line x1="%.1f" y1="%d" x2="%.1f" y2="%.1f" stroke="#c9d4e0" stroke-dasharray="4 4"/>' % (xm, pad_t, xm, pad_t + ih))
    out.append('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" stroke="#c9d4e0" stroke-dasharray="4 4"/>' % (pad_l, ym, pad_l + iw, ym))
    for gx in (0, 25, 50, 75, 100):
        x = pad_l + iw * gx / 100.0
        out.append('<text x="%.1f" y="%.1f" text-anchor="middle" font-size="11" fill="%s">%d%%</text>' % (x, pad_t + ih + 18, MUT, gx))
    for gy in range(0, 13, 3):
        y = pad_t + ih * (1 - gy / 12.0)
        out.append('<text x="%d" y="%.1f" text-anchor="end" font-size="11" fill="%s" dominant-baseline="middle">%d</text>' % (pad_l - 8, y, MUT, gy))
    out.append('<text x="%.1f" y="%d" text-anchor="middle" font-size="11.5" font-weight="700" fill="%s">拿单概率 →</text>' % (pad_l + iw / 2.0, h - 8, TXT))
    out.append('<text x="14" y="%.1f" font-size="11.5" font-weight="700" fill="%s" transform="rotate(-90 14 %.1f)" text-anchor="middle">MEDDIC 总分 →</text>' % (pad_t + ih / 2.0, TXT, pad_t + ih / 2.0))
    pts = []
    for name, prob, med, msgs, grade in points:
        x = pad_l + iw * min(prob, 100) / 100.0
        y = pad_t + ih * (1 - med / 12.0)
        r = 7 + min(msgs, 60) * 0.2
        pts.append([x, y, r, name, grade, prob, med, msgs])
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            dx = pts[j][0] - pts[i][0]
            dy = pts[j][1] - pts[i][1]
            if (dx * dx + dy * dy) ** 0.5 < (pts[i][2] + pts[j][2]) * 0.78:
                ang = 0.6 + 0.5 * j
                pts[j][0] += 17 * __import__('math').cos(ang)
                pts[j][1] += 15 * __import__('math').sin(ang)
    q = [('优先攻（高概率·高资格）', pad_l + iw - 10, pad_t + 16, 'end', '#1b7a35'), ('培育（高资格·低概率）', pad_l + 10, pad_t + 16, 'start', '#1c5fa8'), ('快赢（高概率·低资格）', pad_l + iw - 10, pad_t + ih - 10, 'end', '#a86a11'), ('暂放（双低）', pad_l + 10, pad_t + ih - 10, 'start', '#8b98a6')]
    qboxes = []
    for t, x, y, anc, c in q:
        out.append('<text x="%.1f" y="%.1f" text-anchor="%s" font-size="11" fill="%s" opacity=".95" stroke="#ffffff" stroke-width="3.5" stroke-opacity=".92" paint-order="stroke">%s</text>' % (x, y, anc, c, t))
        w = 13 + len(t) * 11.6
        x0 = x - w if anc == 'end' else x
        qboxes.append((x0 - 3, y - 11, x0 + w + 3, y + 5))
    placed = list(qboxes)
    for x, y, r, name, grade, prob, med, msgs in pts:
        placed.append((x - r - 1, y - r - 1, x + r + 1, y + r + 1))

    def _fits(box):
        for b in placed:
            if not (box[2] < b[0] or box[0] > b[2] or box[3] < b[1] or (box[1] > b[3])):
                return False
        return True
    for x, y, r, name, grade, prob, med, msgs in pts:
        c = GCOLOR.get(grade, '#94a3b8')
        out.append('<circle cx="%.1f" cy="%.1f" r="%.1f" fill="%s" fill-opacity=".72" stroke="#fff" stroke-width="1.4"><title>%s｜概率 %s%%｜MEDDIC %d/12｜%d 条消息｜%s 级</title></circle>' % (x, y, r, c, _esc(name), prob, med, msgs, grade))
        lbl = name[:15]
        wx = 10 + len(lbl) * 6.6
        cand = [(0, r + 13), (0, -(r + 6)), (r + 7, 4), (-(r + 7), 4), (0, r + 25), (0, -(r + 18)), (r + 7, -11), (-(r + 7), -11), (0, r + 37), (0, -(r + 30)), (r + 7, 16), (-(r + 7), 16), (0, r + 49), (0, -(r + 42))]
        lx = ly = None
        for dx, dy in cand:
            tx = min(max(x + dx, pad_l + wx / 2 + 2), pad_l + iw - wx / 2 - 2)
            ty = y + dy
            if ty < pad_t + 11 or ty > pad_t + ih - 2:
                continue
            box = (tx - wx / 2, ty - 7, tx + wx / 2, ty + 4)
            if _fits(box):
                lx, ly = (tx, ty)
                placed.append(box)
                break
        if lx is not None:
            out.append('<text x="%.1f" y="%.1f" text-anchor="middle" font-size="10.5" fill="#3f4d5c" font-weight="600" stroke="#ffffff" stroke-width="2.4" stroke-opacity=".85" paint-order="stroke">%s</text>' % (lx, ly, _esc(lbl)))
    out.append('</svg>')
    return ''.join(out)

def radar_grid(series, cell=210, cols=3):
    import math
    rows = (len(series) + cols - 1) // cols
    w, h = (cell * cols, cell * rows)
    out = ['<svg viewBox="0 0 %d %d" width="100%%" style="max-width:%dpx">' % (w, h, w)]
    for idx, (name, grade, vals) in enumerate(series):
        ox = idx % cols * cell
        oy = idx // cols * cell
        cx = ox + cell / 2.0
        cy = oy + cell * 0.46
        R = cell * 0.27
        n = 6
        pts = []
        for i in range(n):
            a = -90 + i * 360.0 / n
            pts.append((cx + R * math.cos(math.radians(a)), cy + R * math.sin(math.radians(a)), a))
        for ring in (0.5, 1.0, 1.5, 2.0):
            poly = ' '.join(('%.1f,%.1f' % (cx + (p[0] - cx) * ring / 2.0, cy + (p[1] - cy) * ring / 2.0) for p in pts))
            out.append('<polygon points="%s" fill="none" stroke="%s" stroke-width="1"/>' % (poly, GRID))
        for p in pts:
            out.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="1"/>' % (cx, cy, p[0], p[1], GRID))
        poly = []
        for i, v in enumerate(vals):
            f = max(0.0, min(2.0, float(v))) / 2.0
            poly.append('%.1f,%.1f' % (cx + (pts[i][0] - cx) * f, cy + (pts[i][1] - cy) * f))
        c = GCOLOR.get(grade, '#94a3b8')
        out.append('<polygon points="%s" fill="%s" fill-opacity=".26" stroke="%s" stroke-width="2"/>' % (' '.join(poly), c, c))
        for xy in poly:
            x, y = xy.split(',')
            out.append('<circle cx="%s" cy="%s" r="2.6" fill="%s"/>' % (x, y, c))
        for i, p in enumerate(pts):
            rad = R + (24 if i == 3 else 17)
            lx = cx + rad * math.cos(math.radians(p[2]))
            ly = cy + rad * math.sin(math.radians(p[2]))
            out.append('<text x="%.1f" y="%.1f" text-anchor="middle" dominant-baseline="middle" font-size="10" fill="%s">%s</text>' % (lx, ly, MUT, AXES_SHORT[i]))
        tot = sum((int(v) for v in vals))
        out.append('<text x="%.1f" y="%.1f" text-anchor="middle" font-size="12" font-weight="700" fill="%s">%s</text>' % (cx, oy + 14, NAVY, _esc(name[:16])))
        out.append('<text x="%.1f" y="%.1f" text-anchor="middle" font-size="11" fill="%s">%d/12</text>' % (cx, oy + cell - 4, c, tot))
    out.append('</svg>')
    return ''.join(out)

def funnel(stages, w=520, rowh=54):
    n = len(stages)
    h = n * rowh + 8
    vmax = max([v for _, v, _ in stages] or [1]) or 1
    out = ['<svg viewBox="0 0 %d %d" width="100%%" style="max-width:%dpx">' % (w, h, w)]
    for i, (label, val, color) in enumerate(stages):
        y = i * rowh + 4
        bw = (w - 150) * (0.45 + 0.55 * (val / float(vmax)))
        x = (w - 150 - bw) / 2.0 + 4
        out.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%d" rx="6" fill="%s" fill-opacity=".9"><title>%s: %d</title></rect>' % (x, y, bw, rowh - 12, color, _esc(label), val))
        out.append('<text x="%.1f" y="%.1f" text-anchor="middle" dominant-baseline="middle" font-size="13" font-weight="800" fill="#fff">%d</text>' % (x + bw / 2.0, y + (rowh - 12) / 2.0, val))
        out.append('<text x="%d" y="%.1f" font-size="12" fill="%s" dominant-baseline="middle">%s</text>' % (w - 138, y + (rowh - 12) / 2.0, TXT, _esc(label)))
    out.append('</svg>')
    return ''.join(out)
