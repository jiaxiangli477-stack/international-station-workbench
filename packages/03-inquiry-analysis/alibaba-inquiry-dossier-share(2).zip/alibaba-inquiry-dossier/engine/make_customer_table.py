import io
import json
import os
import sys
from collections import Counter, OrderedDict, defaultdict
from datetime import datetime
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
INQ = os.path.join(HERE, 'inquiry')
from inquiry_analysis import ANALYSIS
from inquiry_strength import STRENGTH
import inquiry_dossier as DO
import inquiry_charts as CH
from customer_table_html import write_html
from customer_rows import build_rows
TIERS = DO.QUALITY_TIERS
TIER_COLOR = {'优质客户': 'FF2E9E5B', '潜力客户': 'FF1C5FA8', '普通客户': 'FF94A3B8', '无效 / 风险': 'FFC0392B'}
PILLAR_HEAD = ['聊天记录分', '背调结论分', '客户信息分', '内部CRM分']
DASH = '-'

def load_json(name, default):
    p = os.path.join(INQ, name)
    if not os.path.isfile(p):
        return default
    try:
        return json.load(io.open(p, encoding='utf-8'))
    except Exception:
        return default

def main():
    built = build_rows()
    if not built:
        print('没找到 inquiry/conversations.json 里的会话数据 —— 先跑 fetch_inquiries.py')
        return 1
    rows, _meta = built
    win, store = (_meta['win'], _meta['store'])
    AUTO, AUTO_META, ENT = (_meta['auto'], _meta['auto_meta'], _meta['ent'])
    real = _meta['real']
    d1_s = (win.get('until') or datetime.now().strftime('%Y-%m-%d'))[:10].replace('-', '')
    tcnt = Counter((r['tier'] for r in rows))
    tcnt = Counter((r['tier'] for r in rows))
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.chart import BarChart, Reference
    wb = Workbook()
    thin = Side(style='thin', color='FFD9DEE5')
    BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
    HEAD_FILL = PatternFill('solid', fgColor='FF16324F')
    HEAD_FONT = Font(color='FFFFFFFF', bold=True, size=10)
    TITLE_FONT = Font(bold=True, size=13, color='FF16324F')

    def style_header(ws, row=1, ncol=None):
        ncol = ncol or ws.max_column
        for i in range(1, ncol + 1):
            c = ws.cell(row=row, column=i)
            c.fill, c.font = (HEAD_FILL, HEAD_FONT)
            c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws.row_dimensions[row].height = 30
        ws.freeze_panes = ws.cell(row=row + 1, column=1)

    def widths(ws, spec):
        for col, w in spec.items():
            ws.column_dimensions[col].width = w
    _default = wb.active
    _default.title = '1 说明与口径'
    import deal_blocker as _DB0
    import inq_brief as _IB
    _bst0 = _DB0.aggregate(rows)
    _an = _IB.analyse(rows, _bst0)
    ws0 = wb.create_sheet('0 结论与行动', 0)
    wb.active = wb.sheetnames.index('1 说明与口径')
    ws0['A1'] = '结论与行动'
    ws0['A1'].font = TITLE_FONT
    ws0['A2'] = '店铺 %s ｜ 窗口 %s ~ %s ｜ 生成 %s' % (store.get('name') or DASH, (win.get('since') or '')[:16], (win.get('until') or '')[:16], datetime.now().strftime('%Y-%m-%d %H:%M'))
    _r0 = 4
    ws0.cell(row=_r0, column=1, value='① 评估').font = Font(bold=True, size=11, color='FF16324F')
    _r0 += 1
    for _k0, _v0 in [('优质 + 潜力', '%d / %d（占比 %s）' % (_an['good'], _an['n'], _IB._pct(_an['good'], _an['n'] or 1))), ('已成交 / 在途', '%d 个（有订单证据）' % _an['n_deal']), ('在等我们', '球在买家 %d 个 ｜ 我方未回复 %d 个 ｜ 最长等 %d 天' % (len(_an['pend']), _an['n_noreply'], _an['maxwait'])), ('背调覆盖', '有邮箱 %d ｜ 抓到独立站 %d ｜ 拿到社媒 %d ｜ Gravatar 命中 %d' % (_an['n_mail'], _an['n_site'], _an['n_soc'], _an['n_gv'])), ('客户实力', '强/中-强 %d ｜ 中 %d ｜ 弱-中 %d ｜ 弱 %d ｜ 待核验 %d' % (_an['s_lvl'].get('强', 0) + _an['s_lvl'].get('中-强', 0), _an['s_lvl'].get('中', 0), _an['s_lvl'].get('弱-中', 0), _an['s_lvl'].get('弱', 0), _an['s_lvl'].get('待核验', 0))), ('该追谁', 'P0 重点追 %d ｜ P1 正常跟 %d ｜ P2 小额快周转 %d ｜ P3 待激活 %d ｜ P4 先索取主体 %d' % (_an['s_verdict'].get('P0 重点追', 0), _an['s_verdict'].get('P1 正常跟', 0), _an['s_verdict'].get('P2 小额快周转', 0), _an['s_verdict'].get('P3 有价值·待激活', 0), _an['s_verdict'].get('P4 先索取主体', 0))), ('卡点总览', '｜'.join(('%s %d' % (x['label'], x['n']) for x in _bst0 if x['n'] and x['code'] != 'CARD_ONLY')))]:
        ws0.cell(row=_r0, column=1, value=_k0).font = Font(bold=True, size=10)
        ws0.cell(row=_r0, column=2, value=_v0).alignment = Alignment(wrap_text=True, vertical='top')
        _r0 += 1
    _r0 += 1
    ws0.cell(row=_r0, column=1, value='② 方向分析').font = Font(bold=True, size=11, color='FF16324F')
    _r0 += 1
    _dirs0 = [('市场方向（按优质+潜力）', [('%s（%s）' % (_IB._cn(c), c), '%d 个买家 ｜ 优质+潜力 %d（%s）' % (v['n'], v['good'], _IB._pct(v['good'], v['n']))) for c, v in _an['markets'][:6]] + [('结论', '主攻 %s' % '、'.join((_IB._cn(c) for c, _ in _an['markets'][:3])))]), ('品类方向（买家在问什么）', [(lab, '%d 个买家提到' % cnt) for lab, cnt in _an['products'][:6]] + ([('结论', '%s 是主需求，报价单按这个顺序排' % '、'.join((l for l, _ in _an['products'][:3])))] if _an['products'] else [])), ('客户类型方向', [(k, '%d 个 ｜ 优质+潜力 %d（%s）' % (v['n'], v['good'], _IB._pct(v['good'], v['n']))) for k, v in _an['ctypes']]), ('渠道方向', [(k, '%d 个 ｜ 优质+潜力 %d（%s）｜ 人均买家发言 %.1f 条' % (v['n'], v['good'], _IB._pct(v['good'], v['n']), v['msgs'] / max(1, v['n']))) for k, v in _an['channels']]), ('人的方向（看优质率，不看客户数）', [(o, '%d 个客户 ｜ 优质率 %s ｜ 待回复 %d ｜ 最长等待 %d 天' % (v['n'], _IB._pct(v['good'], v['n']), v['pend'], v['wait'])) for o, v in _an['owners']])]
    for _t0, _items0 in _dirs0:
        ws0.cell(row=_r0, column=1, value='  ' + _t0).font = Font(bold=True, size=10)
        _r0 += 1
        for _k1, _v1 in _items0:
            ws0.cell(row=_r0, column=1, value='     ' + str(_k1))
            ws0.cell(row=_r0, column=2, value=_v1).alignment = Alignment(wrap_text=True, vertical='top')
            _r0 += 1
    _r0 += 1
    ws0.cell(row=_r0, column=1, value='追击名单（P0/P1，按实力分）').font = Font(bold=True, size=11, color='FF16324F')
    _r0 += 1
    for _c4, _t4 in ((1, '客户'), (2, '实力'), (3, '等级'), (4, '该不该追'), (5, '凭什么')):
        cc = ws0.cell(row=_r0, column=_c4, value=_t4)
        cc.fill, cc.font = (HEAD_FILL, HEAD_FONT)
        cc.alignment = Alignment(horizontal='center', vertical='center')
    _r0 += 1
    for _rc in _an['chase'][:12]:
        _sc = _rc.get('strength') or {}
        ws0.cell(row=_r0, column=1, value=_rc['name'])
        ws0.cell(row=_r0, column=2, value='%s 分' % _sc.get('score', 0))
        ws0.cell(row=_r0, column=3, value=_sc.get('level') or '')
        ws0.cell(row=_r0, column=4, value=_sc.get('verdict') or '')
        ws0.cell(row=_r0, column=5, value='；'.join((_sc.get('why') or [])[:2]))
        ws0.cell(row=_r0, column=5).alignment = Alignment(wrap_text=True, vertical='top')
        _r0 += 1
    _r0 += 1
    ws0.cell(row=_r0, column=1, value='③ 动作建议（这周做什么）').font = Font(bold=True, size=11, color='FF16324F')
    _r0 += 1
    for _c2, _t2 in ((1, '动作'), (2, '对象/数量'), (3, '建议承接'), (4, '为什么先做'), (5, '预期')):
        cc = ws0.cell(row=_r0, column=_c2, value=_t2)
        cc.fill, cc.font = (HEAD_FILL, HEAD_FONT)
        cc.alignment = Alignment(horizontal='center', vertical='center')
    _r0 += 1
    for _x0 in _an['acts']:
        ws0.cell(row=_r0, column=1, value=_x0['act']).alignment = Alignment(wrap_text=True, vertical='top')
        ws0.cell(row=_r0, column=2, value='%d 个' % _x0['n'])
        ws0.cell(row=_r0, column=3, value=_x0['who'])
        ws0.cell(row=_r0, column=4, value=_x0['why']).alignment = Alignment(wrap_text=True, vertical='top')
        ws0.cell(row=_r0, column=5, value=_x0['exp'])
        _r0 += 1
    widths(ws0, {'A': 46, 'B': 34, 'C': 26, 'D': 56, 'E': 30})
    ws = wb.active
    ws.title = '1 说明与口径'
    ws['A1'] = '询盘客户分层分析表'
    ws['A1'].font = TITLE_FONT
    ws['A2'] = '店铺 %s ｜ 窗口 %s ~ %s ｜ 生成 %s' % (store.get('name') or DASH, (win.get('since') or '')[:16], (win.get('until') or '')[:16], datetime.now().strftime('%Y-%m-%d %H:%M'))
    lines = [('口径', ''), ('分层方式', '四支柱加权：聊天记录 ≤12 ｜ 背调结论 ≤10 ｜ 客户信息 ≤8 ｜ 内部 CRM ≤3（辅助）。档位 = 支柱门槛 + 总分双条件，不看内部标签单独定档。'), ('优质客户', '聊天 ≥7 且 背调 ≥4 且 客户信息 ≥3，或 聊天 ≥9 且 客户信息 ≥5，或 背调 ≥8 且（聊天+信息）≥8'), ('潜力客户', '聊天 ≥4 且（背调+信息）≥4 且总分 ≥9，或总分 ≥14'), ('普通客户', '总分 ≥4'), ('无效 / 风险', '买家全程未发言（只有系统卡片）／命中肽类等管制成分／总分 ≤3'), ('聊天记录柱', '买家发言条数、双向沟通、意图类型（询价报价/数量MOQ/交期物流/样品打样/付款条款/OEM贴牌/认证合规，每类 +1 上限 4）、聊天里的具体单价 +2 与数量 +1、沟通跨度 ≥14 天 +2'), ('背调结论柱', '人工逐条研判（inquiry_strength）或自动公网核验（verify_auto）：强 +7 / 中-强 +6 / 中 +4 / 弱-中 +2 / 弱 +1；公网核实有结论 +2；成交硬证据 +3。人工优先。'), ('客户信息柱', '公司名/网站/电话/地址（≥2 项 +2）、国家 +1 且成熟市场再 +1、平台等级 L4/L3/L2=3/2/1、90 天接触供应商 ≥40/≥20、90 天浏览 ≥100 或登录 ≥10 天'), ('内部 CRM 柱', '标签「优质商机/重要客户」+2、阶段订单议价 +2（需求确认 +1）、备注含成交 +1 —— 封顶 3 分'), ('国家怎么来', 'contactLoginId 前两位是 ISO 国家码（如 ae…/pl…），不依赖客户自填，覆盖 %d/%d' % (sum((1 for v in ENT.values() if v.get('country'))), len(rows))), ('', ''), ('数据来源', ''), ('平台', '阿里巴巴国际站 TradeManager（workctl icbu tm / chat-analysis 官方管道，窗口上限 7 天）'), ('主体线索', 'extract_entities.py：从聊天原文抽 公司名/域名/邮箱/电话/地址/品牌（离线，不判定）'), ('公网核验', 'verify_companies.py：RDAP 域名注册数据 + 客户官网抓取 + 英国公司注册处 + Gravatar（个人邮箱）+ YouTube 用户名存在性'), ('本机查不通的源', 'LinkedIn(999) / Instagram(登录墙) / TikTok(无法区分) / Facebook(拦截) / Bing 搜索(返回无关结果) / DuckDuckGo(人机验证) / emailrep.io(限流429) / USPTO(403) / bizapedia(需订阅) / OpenCorporates(JS 渲染) —— 不硬凑，不假装查过'), ('成交卡点', 'deal_blocker.py 规则判定：我方未回复 / 问了价没报价 / 报价后失联 / 样品 / 规格 / 付款 / 资质 / 交期 各环节；「话术效率%」= 带商业要素的买家消息占比'), ('', ''), ('本期覆盖', '买家 %d 个 ｜ 会话 %d 个 ｜ 消息 %d 条' % (len(rows), len(real), sum((r['nsell'] + r['nbuy'] for r in rows))))]
    for t in TIERS:
        lines.append((t, '%d 个（%.0f%%）' % (tcnt.get(t, 0), 100.0 * tcnt.get(t, 0) / max(1, len(rows)))))
    lines += [('有公网实证', '%d ｜ 线索级可追溯 %d ｜ 待核验 %d' % (sum((1 for r in rows if r['grade'] in ('中-强', '中'))), sum((1 for r in rows if r['grade'] in ('弱-中', '弱'))), sum((1 for r in rows if r['grade'] not in ('中-强', '中', '弱-中', '弱'))))), ('待我方回复', '%d 个买家的最后一句是自己说的（见「4 待跟进行动项」）' % sum((1 for r in rows if r['pending'] == '是'))), ('', ''), ('免责', '平台标签为该账号近 90 天行为；聊天原文里的数字为客户自述，未经第三方核验；自动核验只覆盖公开可得信息，查不到不等于不存在。')]
    r0 = 4
    for i, (k, v) in enumerate(lines):
        rr = r0 + i
        ws.cell(row=rr, column=1, value=k).font = Font(bold=True, size=10, color='FF16324F')
        ws.cell(row=rr, column=1).alignment = Alignment(vertical='top')
        c = ws.cell(row=rr, column=2, value=v)
        c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.column_dimensions['A'].width = 16
    ws.column_dimensions['B'].width = 118
    ws2 = wb.create_sheet('2 客户分层总表')
    head = ['质量档', '总分'] + PILLAR_HEAD + ['客户', '账号', '国家', '市场类型', '平台等级', '渠道', '会话数', '买家消息', '我方消息', '沟通跨度(天)', '接待账号', '最后往来', '待回复', '等待天数', '成交卡点', '卡在哪个环节', '卡了几天', '话术效率%', 'MEDDIC/12', '拿单概率', '实力评级', '背调来源', '实力依据 / 核验结论', '聊天-数量证据', '聊天-价格证据', '身份线索', '90天浏览', '90天登录', '90天接触供应商', '主打类目', '核心诉求', '建议动作']
    ws2.append(head)
    for r in rows:
        ws2.append([r['tier'], r['score'], r['chat'], r['bg'], r['info'], r['crm'], r['name'], r['login'], r['country'], r['region'], r['level'], r['channel'], r['nconv'], r['nbuy'], r['nsell'], r['span'], r['owners'], r['last'], r['pending'], r['wait'], r.get('blocker_label') or DASH, r.get('stage') or DASH, r.get('blocker_days'), r.get('chat_yield'), r['meddic'], r['prob'], r['grade'], r['src'], r['basis'] + ' ｜ ' + r['verify'] if r['basis'] else DASH, r['qty'] or DASH, r['price'] or DASH, r['signals'], r['views'] if r['views'] is not None else DASH, r['logins'] if r['logins'] is not None else DASH, r['sellers'] if r['sellers'] is not None else DASH, r['biz'], r['intent'], r['action']])
    style_header(ws2)
    widths(ws2, {'A': 12, 'B': 6, 'C': 10, 'D': 10, 'E': 10, 'F': 9, 'G': 18, 'H': 20, 'I': 7, 'J': 10, 'K': 9, 'L': 8, 'M': 7, 'N': 9, 'O': 9, 'P': 11, 'Q': 16, 'R': 17, 'S': 8, 'T': 9, 'U': 16, 'V': 14, 'W': 9, 'X': 9, 'Y': 10, 'Z': 10, 'AA': 11, 'AB': 10, 'AC': 46, 'AD': 22, 'AE': 20, 'AF': 20, 'AG': 10, 'AH': 10, 'AI': 14, 'AJ': 26, 'AK': 40, 'AL': 46})
    for i, r in enumerate(rows, start=2):
        c = ws2.cell(row=i, column=1)
        c.fill = PatternFill('solid', fgColor=TIER_COLOR.get(r['tier'], 'FF94A3B8'))
        c.font = Font(color='FFFFFFFF', bold=True, size=10)
        c.alignment = Alignment(horizontal='center', vertical='center')
        ws2.cell(row=i, column=2).font = Font(bold=True, size=10)
        if r['pending'] == '是':
            ws2.cell(row=i, column=19).font = Font(color='FFC0392B', bold=True, size=10)
            try:
                if int(r['wait']) >= 3:
                    ws2.cell(row=i, column=20).font = Font(color='FFC0392B', bold=True, size=10)
            except Exception:
                pass
        for col in (25, 32, 33):
            ws2.cell(row=i, column=col).alignment = Alignment(wrap_text=True, vertical='top')
        for col in (1, 2, 3, 4, 5, 6, 9, 10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 29, 30, 31):
            ws2.cell(row=i, column=col).alignment = Alignment(horizontal='center', vertical='center')
    ws2.auto_filter.ref = 'A1:AL%d' % (len(rows) + 1)
    ws3 = wb.create_sheet('3 优质客户明细')
    ws3.append(['客户', '总分', '聊天/背调/信息/内部', '国家', '平台等级', '消息(买/我)', '实力评级', '背调来源', '命中理由（逐条）', '建议动作'])
    for r in [x for x in rows if x['tier'] == '优质客户']:
        ws3.append([r['name'], r['score'], '%d / %d / %d / %d' % (r['chat'], r['bg'], r['info'], r['crm']), r['country'], r['level'], '%d / %d' % (r['nbuy'], r['nsell']), r['grade'], r['src'], '\n'.join(r['reasons']), r['action']])
    style_header(ws3)
    widths(ws3, {'A': 20, 'B': 6, 'C': 18, 'D': 7, 'E': 9, 'F': 11, 'G': 10, 'H': 10, 'I': 96, 'J': 46})
    for i in range(2, ws3.max_row + 1):
        ws3.cell(row=i, column=9).alignment = Alignment(wrap_text=True, vertical='top')
        ws3.cell(row=i, column=10).alignment = Alignment(wrap_text=True, vertical='top')
    ws4 = wb.create_sheet('4 待跟进行动项')
    ws4.append(['等待天数', '客户', '档位', '总分', '国家', '平台等级', '接待账号', '核心诉求', '建议动作', '英文跟进话术（无手写话术时为自动草稿，发前请核对）'])
    pend = [r for r in rows if r['pending'] == '是']
    pend.sort(key=lambda r: -(r['wait'] if isinstance(r['wait'], int) else 0))
    for r in pend:
        ws4.append([r['wait'], r['name'], r['tier'], r['score'], r['country'], r['level'], r['owners'], r['intent'], r['action'], r['talk'] or r.get('talk_auto') or ''])
    style_header(ws4)
    widths(ws4, {'A': 9, 'B': 20, 'C': 12, 'D': 6, 'E': 7, 'F': 9, 'G': 16, 'H': 40, 'I': 46, 'J': 74})
    for i in range(2, ws4.max_row + 1):
        for col in (8, 9, 10):
            ws4.cell(row=i, column=col).alignment = Alignment(wrap_text=True, vertical='top')
        try:
            if int(ws4.cell(row=i, column=1).value) >= 3:
                ws4.cell(row=i, column=1).font = Font(color='FFC0392B', bold=True, size=10)
        except Exception:
            pass
    ws5 = wb.create_sheet('5 业务员x档位')
    owners = sorted(set((o for r in rows for o in r['owners'].split('/') if o and o != DASH)))
    ws5.append(['接待账号'] + TIERS + ['合计', '优质率'])
    for o in owners:
        mine = [r for r in rows if o in r['owners'].split('/')]
        cnts = [sum((1 for r in mine if r['tier'] == t)) for t in TIERS]
        ws5.append([o] + cnts + [len(mine), '%.0f%%' % (100.0 * cnts[0] / len(mine)) if mine else DASH])
    tot = [sum((1 for r in rows if r['tier'] == t)) for t in TIERS]
    ws5.append(['合计'] + tot + [len(rows), '%.0f%%' % (100.0 * tot[0] / max(1, len(rows)))])
    style_header(ws5)
    widths(ws5, {'A': 18, 'B': 12, 'C': 12, 'D': 12, 'E': 12, 'F': 9, 'G': 9})
    for i in range(ws5.max_row, ws5.max_row + 1):
        for col in range(1, 8):
            ws5.cell(row=i, column=col).font = Font(bold=True, size=10)
    bc2 = BarChart()
    bc2.type, bc2.grouping = ('col', 'stacked')
    bc2.title = '各接待账号的客户质量构成'
    bc2.add_data(Reference(ws5, min_col=2, max_col=5, min_row=1, max_row=ws5.max_row - 1), titles_from_data=True)
    bc2.set_categories(Reference(ws5, min_col=1, min_row=2, max_row=ws5.max_row - 1))
    bc2.height, bc2.width = (9, 18)
    ws5.add_chart(bc2, 'I2')
    ws6 = wb.create_sheet('6 国家x档位')
    ccnt = defaultdict(Counter)
    for r in rows:
        ccnt[r['country'] or '未知'][r['tier']] += 1
    ws6.append(['国家', '市场类型'] + TIERS + ['合计', '优质+潜力'])
    for cc in sorted(ccnt, key=lambda c: -sum(ccnt[c].values())):
        cs = ccnt[cc]
        vals = [cs.get(t, 0) for t in TIERS]
        ws6.append([cc, '成熟市场' if cc in DO.MATURE_MARKETS else '新兴/其他'] + vals + [sum(vals), vals[0] + vals[1]])
    ws6.append(['合计', ''] + tot + [len(rows), tot[0] + tot[1]])
    style_header(ws6)
    widths(ws6, {'A': 9, 'B': 11, 'C': 12, 'D': 12, 'E': 12, 'F': 12, 'G': 9, 'H': 11})
    for col in range(1, 9):
        ws6.cell(row=ws6.max_row, column=col).font = Font(bold=True, size=10)
    ws7 = wb.create_sheet('7 待核验索取清单')
    ws7.append(['客户', '档位', '总分', '国家', '平台等级', '消息(买/我)', '最后往来', '聊天里有的线索', '还缺什么（向客户索取）', '核心诉求'])
    for r in rows:
        if r['grade'] in ('中-强', '中', '弱-中', '弱'):
            continue
        ws7.append([r['name'], r['tier'], r['score'], r['country'], r['level'], '%d / %d' % (r['nbuy'], r['nsell']), r['last'], r['signals'], '；'.join(r['ask'][:3]), r['intent']])
    style_header(ws7)
    widths(ws7, {'A': 20, 'B': 12, 'C': 6, 'D': 7, 'E': 9, 'F': 11, 'G': 17, 'H': 24, 'I': 52, 'J': 40})
    for i in range(2, ws7.max_row + 1):
        for col in (8, 9, 10):
            ws7.cell(row=i, column=col).alignment = Alignment(wrap_text=True, vertical='top')
    _rowmap = {r['name']: r for r in rows}
    ws8 = wb.create_sheet('8 已核验主体')
    ws8.append(['客户', '核验档', '主体识别', '域名', '域名注册于', '域名状态', '官网状态', '官网标题', '行业匹配', '工商库命中', '邮箱类型', '邮箱', 'Gravatar', 'Gravatar 显示名', 'YouTube 同名', '号码归属', '社媒（独立站页脚）', '实力分', '实力等级', '追击优先级', '实力依据', '核验结论', '背调结论', '下一步动作', '证据类型', '数据源'])
    from customer_table_html import _bg_concl
    for nm, v in sorted(AUTO.items(), key=lambda x: x[0]):
        if v.get('grade') == '待核验':
            continue
        rd, si, rg = (v.get('rdap') or {}, v.get('site') or {}, v.get('registry') or {})
        _pf = v.get('profile') or {}
        _st8 = (_rowmap.get(nm) or {}).get('strength') or {}
        _mini = {'profile': _pf, 'emails': v.get('emails') or [], 'entity': v.get('entity') or '', 'gravatar': v.get('gravatar'), 'gravatar_names': v.get('gravatar_names') or [], 'youtube': v.get('youtube') or [], 'handles': v.get('handles') or []}
        _c, _concl, _nxt = _bg_concl(_mini)
        ws8.append([nm, v.get('grade') or '', v.get('entity') or DASH, rd.get('domain') or DASH, rd.get('created') or DASH, '已注册' if rd.get('registered') else '未注册' if rd.get('registered') is False else DASH, DASH if not rd.get('domain') else '停放/待售' if si.get('parked') else '在营' if si.get('reachable') else '不可访问', (si.get('title') or DASH)[:60], '、'.join(si.get('industry') or []) or DASH, '；'.join(('%s(%s)' % (h['name'], h['number']) for h in (rg.get('hits') or [])[:2])) or DASH, v.get('mail_kind') or DASH, '、'.join((v.get('emails') or [])[:2]) or DASH, '有' if v.get('gravatar') else '无', '、'.join(v.get('gravatar_names') or []) or DASH, '、'.join(v.get('youtube') or []) or DASH, '、'.join((x[1] for x in (v.get('phone_regions') or [])[:2])) or DASH, '\n'.join((_pf.get('socials') or [])[:4]) or DASH, _st8.get('score', DASH), _st8.get('level') or DASH, _st8.get('verdict') or DASH, '；'.join((_st8.get('why') or [])[:3]) or DASH, v.get('verify') or DASH, _concl, _nxt, '、'.join(v.get('evidence') or []) or DASH, '、'.join(v.get('sources') or []) or DASH])
    style_header(ws8)
    widths(ws8, {'A': 20, 'B': 9, 'C': 26, 'D': 26, 'E': 12, 'F': 10, 'G': 11, 'H': 34, 'I': 24, 'J': 30, 'K': 10, 'L': 40, 'M': 9, 'N': 18, 'O': 20, 'P': 12, 'Q': 40, 'R': 8, 'S': 9, 'T': 14, 'U': 60, 'V': 60, 'W': 22, 'X': 46, 'Y': 22, 'Z': 30})
    for i in range(2, ws8.max_row + 1):
        for _c0 in (17, 21, 22, 23, 24):
            ws8.cell(row=i, column=_c0).alignment = Alignment(wrap_text=True, vertical='top')
        c = ws8.cell(row=i, column=2)
        c.fill = PatternFill('solid', fgColor='FF3F8F57' if c.value in ('中-强', '中') else 'FFA86A11')
        c.font = Font(color='FFFFFFFF', bold=True, size=10)
    import deal_blocker as DB
    bstats = DB.aggregate(rows)
    ws9 = wb.create_sheet('9 成交卡点')
    ws9.append(['卡点', '堵住客户数', '平均卡住天数', '优质', '潜力', '普通', '无效风险', '破局动作'])
    for x in bstats:
        t = x['tiers'] or {}
        ws9.append([x['label'], x['n'], x['avg_days'], t.get('优质客户', 0), t.get('潜力客户', 0), t.get('普通客户', 0), t.get('无效 / 风险', 0), x['tip']])
    ws9.append([])
    ws9.append(['客户', '档位', '分', '接待账号', '卡点', '现在走到哪一步', '卡了几天', '话术效率%', '买家要什么（原话）', '我方缺口', '关键往来摘录（复盘用，带标签）', '怎么破'])
    _hdr_row = ws9.max_row
    for r in sorted([x for x in rows if x.get('blocker') not in ('CARD_ONLY', 'CHITCHAT')], key=lambda x: -(x.get('blocker_days') if isinstance(x.get('blocker_days'), int) else 0)):
        ks = r.get('key_msgs') or []
        ws9.append([r['name'], r['tier'], r['score'], r['owners'], r.get('blocker_label'), r.get('stage'), r.get('blocker_days'), r.get('chat_yield'), r.get('blocker_ask') or r.get('blocker_buyer_last'), r.get('blocker_gap'), '\n'.join(('[%s] %s%s' % (k['sender'], '【%s】' % '/'.join(k['tags']) if k['tags'] else '', k['text'][:110]) for k in ks[:6])), r.get('blocker_tip')])
    for i in (1, ws9.max_row - len([x for x in rows if x.get('blocker') not in ('CARD_ONLY', 'CHITCHAT')]) - 2):
        for c in range(1, 9):
            cc = ws9.cell(row=i, column=c)
            cc.fill, cc.font = (HEAD_FILL, HEAD_FONT)
            cc.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    widths(ws9, {'A': 20, 'B': 12, 'C': 14, 'D': 11, 'E': 14, 'F': 16, 'G': 9, 'H': 9, 'I': 46, 'J': 26, 'K': 78, 'L': 44})
    for _i in range(_hdr_row + 1, ws9.max_row + 1):
        ws9.cell(row=_i, column=10).alignment = Alignment(wrap_text=True, vertical='top')
    ws9.freeze_panes = 'A2'
    ws10 = wb.create_sheet('10 公司档案')
    ws10.append(['客户', '档位', '分', '接待账号', '国家', '法律主体名', '独立站', '站标题', '主营方向', '电话', '邮箱', '地址', '社媒账号（独立站页脚抓取）', '是否电商站', '站点状态', '规模线索', '抓取页数'])
    _n_prof = 0
    for r in sorted([x for x in rows if (x.get('profile') or {}).get('fetched')], key=lambda x: -x['score']):
        p = r['profile']
        _n_prof += 1
        ws10.append([r['name'], r['tier'], r['score'], r['owners'], r['country'], '、'.join(p.get('legal_entities') or []) or DASH, p.get('domain') or DASH, (p.get('title') or '')[:100] or DASH, '、'.join(p.get('industry') or []) or DASH, '、'.join(p.get('phones') or []) or DASH, '、'.join(p.get('emails') or []) or DASH, '、'.join(p.get('addresses') or []) or DASH, '\n'.join(p.get('socials') or []) or DASH, '是' if p.get('ecommerce') else '否', '未上线（即将推出）' if p.get('not_launched') else '在营', ' ｜ '.join(p.get('size_hints') or []) or DASH, len(p.get('pages') or [])])
    for c in range(1, 18):
        cc = ws10.cell(row=1, column=c)
        cc.fill, cc.font = (HEAD_FILL, HEAD_FONT)
        cc.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    widths(ws10, {'A': 20, 'B': 10, 'C': 6, 'D': 12, 'E': 8, 'F': 30, 'G': 22, 'H': 40, 'I': 22, 'J': 18, 'K': 30, 'L': 34, 'M': 46, 'N': 10, 'O': 14, 'P': 42, 'Q': 9})
    for _i in range(2, ws10.max_row + 1):
        for _c in (8, 12, 13, 16):
            ws10.cell(row=_i, column=_c).alignment = Alignment(wrap_text=True, vertical='top')
    ws10.freeze_panes = 'A2'
    ch_ws = wb.create_sheet('11 图表数据')
    ch_ws['A1'], ch_ws['B1'] = ('档位', '买家数')
    for i, t in enumerate(TIERS, start=2):
        ch_ws.cell(row=i, column=1, value=t)
        ch_ws.cell(row=i, column=2, value=tcnt.get(t, 0))
    bc = BarChart()
    bc.title = '客户质量分层分布'
    bc.y_axis.title = '买家数'
    bc.add_data(Reference(ch_ws, min_col=2, min_row=1, max_row=1 + len(TIERS)), titles_from_data=True)
    bc.set_categories(Reference(ch_ws, min_col=1, min_row=2, max_row=1 + len(TIERS)))
    bc.height, bc.width = (8.5, 16)
    ws.add_chart(bc, 'D4')
    out = os.path.join(INQ, '客户分层分析表_%s.xlsx' % d1_s)
    wb.save(out)
    print('已生成 %s' % out)
    hpath = write_html(os.path.join(INQ, '客户分层分析表_%s.html' % d1_s), rows=rows, win=win, store=store, tcnt=tcnt, pend=pend, ccnt=ccnt, auto=AUTO, auto_meta=AUTO_META, n_conv=len(real))
    print('已生成 %s' % hpath)
    print('  客户 %d ｜ 会话 %d ｜ 待跟进 %d ｜ 待核验 %d ｜ 已核验 %d' % (len(rows), len(real), len(pend), ws7.max_row - 1, max(0, ws8.max_row - 1)))
    print('  分层：' + ' ｜ '.join(('%s %d' % (t, tcnt.get(t, 0)) for t in TIERS)))
    return 0
if __name__ == '__main__':
    sys.exit(main())
