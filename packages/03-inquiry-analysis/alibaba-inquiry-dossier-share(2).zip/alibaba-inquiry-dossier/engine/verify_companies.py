import argparse
from public_checks import build_public_opener, require_public_url
import gzip
import hashlib
import io
import json
import os
import re
import socket
import ssl
import sys
import time
import urllib.parse
import urllib.request
HERE = os.path.dirname(os.path.abspath(__file__))
INQ = os.path.join(HERE, 'inquiry')
CACHE = os.path.join(INQ, '.cache', 'verify')
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36'
TIMEOUT = 20
SLEEP = 0.4
PROXY_FALLBACK = 'http://127.0.0.1:10808'
INDUSTRY_HINT = ('supplement', 'nutrition', 'vitamin', 'collagen', 'protein', 'fitness', 'sports nutrition', 'health', 'wellness', 'nutraceutical', 'wholesale', 'gym', 'protein powder', 'creatine', 'gummies', 'sports', 'dietary', 'food', 'beverage', 'drink', 'coffee', 'pharma', 'distributor', 'import')
PARK_HINT = ('/lander', 'domain for sale', 'buy this domain', 'this domain is for sale', 'parked', 'sedoparking', 'godaddy.com/domainsearch', 'afternic', 'under construction', 'coming soon', 'default web site page', 'próximamente', 'proximamente', 'próximamente', 'em breve', 'bientôt', 'kommt bald', 'en construcción', 'en construccion', '敬请期待', '即将上线')
LEGAL_RE = re.compile("\\b([A-Z][\\w&\\.\\'\\-]*(?:\\s+[A-Z][\\w&\\.\\'\\-]*){0,4}\\s+(?:S\\.A\\.S|S\\.A|SAS|S\\.L|S\\.R\\.L|SRL|SpA|GmbH|AG|LLC|L\\.L\\.C|Ltd\\.?|Limited|Inc\\.?|Corp\\.?|Corporation|Pty\\.?\\s*Ltd|SDN\\.?\\s*BHD|B\\.?V\\.?|N\\.?V\\.?|A/S|ApS|Oy|Pte\\.?\\s*Ltd|Co\\.?,?\\s*Ltd))\\b")
SOCIAL_ON_SITE = re.compile('https?://(?:www\\.)?(instagram\\.com|facebook\\.com|linkedin\\.com|tiktok\\.com|youtube\\.com|x\\.com|twitter\\.com|pinterest\\.com)/[^\\s"\\\'<>()\\\\]{1,70}', re.I)
ADDR_RE = re.compile('.{0,90}?(?:Street|St\\.|Road|Rd\\.|Avenue|Ave\\.|Boulevard|Blvd|Suite|Floor|Unit\\s+\\d|Industrial|Pkwy|Drive|Lane|Ln\\.|Calle|Avenida|Rua|Rue|Strasse|Straße|Via|Viale).{0,90}', re.I)
ECOM_HINT = ('shopify', 'woocommerce', 'add to cart', 'add-to-cart', '/checkout', 'magento', 'bigcommerce', 'cart', 'add to bag')
SIZE_HINT = ('since\\s+(?:19|20)\\d{2}', 'est(?:ablished|\\.)?\\s*(?:19|20)\\d{2}', '\\b\\d{2,6}\\+?\\s+(?:employees|staff|workers|people)', '\\b\\d+\\s+countries', '\\b\\d+\\s+years?\\s+(?:of\\s+)?experience')
ABOUT_PATHS = ('/', '/about', '/about-us', '/aboutus', '/company', '/our-story', '/pages/about', '/contact', '/contact-us', '/pages/contact', '/pages/contact-us')
SOCIAL_SKIP = ('/sharer', '/share?', '/intent/', '/tr?id=', 'developer.', '/plugins/', '/help/', '/policies/', 'facebook.com/tr', 'youtube.com/embed', '/embed/')
try:
    from extract_entities import FREE_MAIL, is_junk_domain
except Exception:
    FREE_MAIL = ('gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'qq.com', '163.com', '126.com', 'icloud.com', 'protonmail.com', 'proton.me', 'live.com', 'aol.com', 'mail.com', 'yandex.com', 'gmx.com', 'web.de', 'rediffmail.com', 'foxmail.com')

    def is_junk_domain(d):
        return (d or '').lower() in FREE_MAIL

def _opener():
    proxy = os.environ.get('HTTPS_PROXY') or os.environ.get('HTTP_PROXY') or os.environ.get('https_proxy') or PROXY_FALLBACK
    ctx = ssl.create_default_context()
    ctx.check_hostname = True
    ctx.verify_mode = ssl.CERT_REQUIRED
    return build_public_opener()
OPENER = _opener()
socket.setdefaulttimeout(TIMEOUT)

def http_get(url, limit=200000):
    try:
        require_public_url(url)
        req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9', 'Accept-Encoding': 'gzip'})
        r = OPENER.open(req, timeout=TIMEOUT)
        raw = r.read(limit)
        if r.headers.get('Content-Encoding') == 'gzip' or raw[:2] == b'\x1f\x8b':
            try:
                raw = gzip.decompress(raw)
            except Exception:
                pass
        return (r.status, raw.decode(r.headers.get_content_charset() or 'utf-8', 'ignore'))
    except urllib.error.HTTPError as e:
        return (e.code, '')
    except Exception as e:
        return (0, str(e)[:120])

def _cache_path(kind, key):
    h = hashlib.sha1(('%s|%s' % (kind, key)).encode('utf-8')).hexdigest()[:16]
    return os.path.join(CACHE, '%s_%s.json' % (kind, h))

def cached(kind, key, fn, refresh=False):
    p = _cache_path(kind, key)
    if not refresh and os.path.isfile(p):
        try:
            return json.load(io.open(p, encoding='utf-8'))
        except Exception:
            pass
    out = fn()
    try:
        os.makedirs(CACHE, exist_ok=True)
        with io.open(p, 'w', encoding='utf-8') as fh:
            fh.write(json.dumps(out, ensure_ascii=False, indent=1))
    except Exception:
        pass
    time.sleep(SLEEP)
    return out

def rdap_domain(domain):
    st, txt = http_get('https://rdap.org/domain/%s' % urllib.parse.quote(domain))
    if st == 404:
        return dict(source='RDAP', domain=domain, registered=False, note='域名未注册')
    if st != 200 or not txt.strip().startswith('{'):
        return dict(source='RDAP', domain=domain, registered=None, note='RDAP 查询失败(%s)' % st)
    try:
        d = json.loads(txt)
    except Exception:
        return dict(source='RDAP', domain=domain, registered=None, note='RDAP 返回不可解析')
    ev = {}
    for e in d.get('events') or []:
        a = (e.get('eventAction') or '').lower()
        if a in ('registration', 'expiration', 'last changed'):
            ev[a] = (e.get('eventDate') or '')[:10]
    reg = ev.get('registration') or ''
    age = None
    if reg:
        try:
            age = round((time.time() - time.mktime(time.strptime(reg, '%Y-%m-%d'))) / 31557600.0, 1)
        except Exception:
            age = None
    return dict(source='RDAP', domain=domain, registered=True, created=reg, expires=ev.get('expiration', ''), age_years=age, registrar=d.get('registrar') or d.get('port43') or '', status=[s for s in d.get('status') or []][:3], nameservers=[n.get('ldhName', '') for n in d.get('nameservers') or []][:3], note='')

def site_probe(domain):
    tries = ['https://%s/' % domain, 'https://www.%s/' % domain, 'http://%s/' % domain]
    for u in tries:
        st, txt = http_get(u)
        if st != 200 or not txt:
            continue
        low = txt.lower()
        park = any((w in low for w in PARK_HINT)) and len(txt) < 4000 or re.search('window\\.location\\.href\\s*=\\s*["\\\']/lander', txt) is not None
        title = ''
        m = re.search('<title[^>]*>(.*?)</title>', txt, re.S | re.I)
        if m:
            title = re.sub('\\s+', ' ', m.group(1)).strip()[:120]
        desc = ''
        m = re.search('<meta[^>]+name=["\\\']description["\\\'][^>]+content=["\\\']([^"\\\']+)', txt, re.I)
        if m:
            desc = m.group(1).strip()[:200]
        text = re.sub('<(script|style)[^>]*>.*?</\\1>', ' ', low, flags=re.S | re.I)
        text = re.sub('<[^>]+>', ' ', text)
        text = re.sub('\\s+', ' ', text)
        hits = [w for w in INDUSTRY_HINT if w in text or w in low]
        legal = LEGAL_RE.findall(txt)
        mails = re.findall('[\\w\\.\\-]+@[\\w\\-]+\\.[a-z]{2,}', txt)
        mails = list(dict.fromkeys([m.lower() for m in mails if not m.lower().split('@')[0].startswith('noreply')]))[:2]
        tels = re.findall('\\+\\d[\\d \\-()\\.]{7,16}\\d', txt)[:2]
        return dict(source='SITE', domain=domain, url=u, reachable=True, parked=bool(park), title=title, desc=desc, industry=[h for h in hits][:6], legal_entities=list(dict.fromkeys(legal))[:3], emails=mails, phones=tels, note='站点疑似停放/待售页' if park else '')
    return dict(source='SITE', domain=domain, reachable=False, parked=None, note='官网不可访问（可能已停用或屏蔽海外访问）')

def company_profile(domain):
    pages = {}
    for pth in ABOUT_PATHS:
        u = 'https://%s%s' % (domain, pth)
        try:
            st, txt = http_get(u, limit=250000)
        except Exception:
            continue
        if st != 200 or not txt or len(txt) < 800:
            continue
        low = txt.lower()
        if '/lander' in low and 'window.location' in low:
            continue
        pages[pth] = txt
        if len(pages) >= 4:
            break
    if not pages:
        return dict(source='PROFILE', domain=domain, fetched=False, note='独立站抓不到内容（可能只挂在平台或屏蔽海外访问）')
    blob = '\n'.join(pages.values())
    text = re.sub('<(script|style|noscript)[^>]*>.*?</\\1>', ' ', blob, flags=re.S | re.I)
    text = re.sub('<[^>]+>', ' ', text)
    text = re.sub('\\s+', ' ', text)
    low = text.lower()
    m = re.search('<title[^>]*>(.*?)</title>', blob, re.S | re.I)
    title = re.sub('\\s+', ' ', m.group(1)).strip()[:120] if m else ''
    not_launched = any((w in low for w in PARK_HINT))
    socials = []
    for mm in SOCIAL_ON_SITE.finditer(blob):
        u = mm.group(0).rstrip('.,;)\'"').lower()
        if any((x in u for x in SOCIAL_SKIP)):
            continue
        if u not in socials:
            socials.append(u)

    def _ok_addr(a):
        a = re.sub('\\s+', ' ', a).strip()
        if not 18 <= len(a) <= 130:
            return ''
        if not re.search('\\d', a):
            return ''
        if any((w in a.lower() for w in ('£', 'us$', 'eur ', 'usd ', 'select', 'currency', '&amp;', 'shipping to', 'ship to', 'choose'))):
            return ''
        if a.count('GBP') or a.count('USD'):
            return ''
        return a
    addrs = list(dict.fromkeys([x for x in (_ok_addr(a) for a in ADDR_RE.findall(text)) if x]))[:2]
    tels = list(dict.fromkeys(re.findall('\\+\\d[\\d \\-()\\.]{7,16}\\d', text)))[:2]
    _bad_mail = ('sentry', 'wixpress', 'wix.com', 'godaddy', 'squarespace', 'shopify.com', 'example.com', 'domain.com', 'yourdomain', 'cloudflare', 'sentry.io')
    _asset = ('.png', '.jpg', '.jpeg', '.svg', '.webp', '.gif', '.css', '.js', '@2x', '@3x')
    mails = [x.lower() for x in re.findall('[\\w\\.\\-]+@[\\w\\-]+\\.[a-z]{2,}', blob) if not x.lower().split('@')[0].startswith(('noreply', 'no-reply')) and (not any((b in x.lower() for b in _bad_mail))) and (not any((x.lower().endswith(a) for a in _asset)))]
    mails = list(dict.fromkeys(mails))[:3]
    legal = list(dict.fromkeys(LEGAL_RE.findall(blob)))[:3]
    ind = [w for w in INDUSTRY_HINT if w in low][:6]
    ecom = [w for w in ECOM_HINT if w in low][:3]
    size = []
    for rx in SIZE_HINT:
        for m0 in re.finditer(rx, low, re.I):
            seg = re.sub('\\s+', ' ', text[max(0, m0.start() - 34):m0.end() + 34]).strip()
            if seg and seg not in size:
                size.append(seg)
    return dict(source='PROFILE', domain=domain, fetched=True, pages=sorted(pages), not_launched=not_launched, note='站点尚未上线（标题/正文是「即将推出」）' if not_launched else '', title=title, legal_entities=legal, industry=ind, addresses=addrs, phones=tels, emails=mails, socials=socials[:8], ecommerce=bool(ecom), ecom_hint=ecom, size_hints=size[:2])

def gravatar_check(email):
    em = (email or '').strip().lower()
    h = hashlib.md5(em.encode()).hexdigest()
    st, txt = http_get('https://gravatar.com/%s.json' % h, limit=40000)
    if st == 200 and txt.strip().startswith('{'):
        try:
            ent = (json.loads(txt).get('entry') or [{}])[0]
        except Exception:
            ent = {}
        name = (ent.get('displayName') or '').strip()
        user = (ent.get('preferredUsername') or '').strip()
        return dict(source='GRAVATAR', email=em, has_avatar=True, name=name, username=user, profile_url=ent.get('profileUrl') or '', note='Gravatar 有档案：显示名「%s」%s' % (name or '-', '，handle @%s' % user if user else ''))
    if st == 404:
        return dict(source='GRAVATAR', email=em, has_avatar=False, name='', username='', note='该邮箱未注册 Gravatar（不代表邮箱无效）')
    return dict(source='GRAVATAR', email=em, has_avatar=False, name='', username='', note='查询失败(%s)' % st)

def youtube_handle(handle):
    st, txt = http_get('https://www.youtube.com/@%s' % handle, limit=8000)
    if st == 200:
        return dict(source='YOUTUBE', handle=handle, exists=True, note='该用户名在 YouTube 存在同名频道')
    if st in (404, 0):
        return dict(source='YOUTUBE', handle=handle, exists=False, note='YouTube 无此用户名' if st == 404 else '查询失败(网络)')
    return dict(source='YOUTUBE', handle=handle, exists=None, note='查询失败(%s)' % st)

def companies_house(name, country):
    if country not in ('GB', 'UK'):
        return dict(source='REGISTRY', registry='companies-house', name=name, supported=False, note='该国无免费工商库（%s）' % (country or '未识别'))
    q = urllib.parse.quote_plus(re.sub('\\b(Ltd|Limited|LLC|Inc|Corp)\\b\\.?', '', name, flags=re.I).strip())
    st, txt = http_get('https://find-and-update.company-information.service.gov.uk/search?q=%s' % q)
    if st != 200:
        return dict(source='REGISTRY', registry='companies-house', name=name, supported=True, hit=None, note='检索失败(%s)' % st)
    hits = []
    for m in re.finditer('<a[^>]+href="(/company/[0-9A-Z]+)"[^>]*>(.*?)</a>', txt, re.S | re.I):
        nm = re.sub('\\s+', ' ', re.sub('<[^>]+>', '', m.group(2))).strip()
        if nm:
            hits.append(dict(number=m.group(1).split('/')[-1], name=nm))
    hits = hits[:3]
    key = re.sub('\\b(ltd|limited|llc|inc|corp)\\b\\.?', '', name.lower()).strip()
    exact = [h for h in hits if key and key in h['name'].lower()]
    return dict(source='REGISTRY', registry='companies-house', name=name, supported=True, hit=bool(exact), hits=hits, note='工商库命中（英国公司注册处）' if exact else '英国公司注册处未检索到同名主体')

def grade_of(bundle):
    rdap = bundle.get('rdap') or {}
    site = bundle.get('site') or {}
    reg = bundle.get('registry') or {}
    sig = bundle.get('signals') or []
    ev, why = ([], [])
    if reg.get('hit'):
        num = (reg.get('hits') or [{}])[0]
        ev.append('工商库命中')
        why.append('英国公司注册处检索到主体「%s」（公司号 %s）' % (num.get('name', ''), num.get('number', '')))
        if site.get('reachable') and (not site.get('parked')):
            why.append('官网在营：%s' % (site.get('title') or site.get('url')))
            ev.append('官网在营')
        return ('中-强', ev, why)
    if rdap.get('registered') and site.get('reachable') and (not site.get('parked')):
        age = rdap.get('age_years')
        why.append('自有域名 %s 已注册%s，官网在营「%s」' % (rdap.get('domain'), ' %.1f 年' % age if isinstance(age, float) else '', (site.get('title') or '')[:60]))
        if site.get('industry'):
            why.append('官网行业关键词匹配：%s' % '、'.join(site['industry'][:4]))
            return ('中-强', ['域名已注册', '官网在营', '行业匹配'], why)
        return ('中', ['域名已注册', '官网在营'], why)
    if rdap.get('registered') is False:
        why.append('邮箱/官网域名 %s 查询结果为**未注册**，不能作为主体佐证' % rdap.get('domain'))
        if reg.get('supported') and reg.get('hit') is False:
            why.append('工商库也未检索到同名主体 → 主体存疑，签约前必须索取注册号')
            return ('弱', ['域名未注册', '工商库无命中'], why)
    elif site.get('parked'):
        why.append('域名 %s 解析到停放/待售页面，不是在营主体' % rdap.get('domain'))
    elif site.get('reachable') is False and rdap.get('registered'):
        why.append('域名 %s 已注册但官网不可访问，仅能证明域名归属' % rdap.get('domain'))
        ev.append('域名已注册')
    if reg.get('supported') and reg.get('hit') is False:
        why.append('该国工商库未检索到同名主体（可能是别名/未注册/国别不符）')
        ev.append('工商库无命中')
    mail = bundle.get('mail') or []
    tube = bundle.get('tube') or []
    for m in mail:
        if m.get('has_avatar'):
            ev.append('邮箱有 Gravatar')
            _nm = m.get('name') or ''
            _u = m.get('username') or ''
            why.append('邮箱 %s 的 Gravatar 显示名「%s」%s（真人常用邮箱，可作身份互证）' % (m.get('email'), _nm or '-', '，handle @%s' % _u if _u else ''))
    for t in tube:
        if t.get('exists'):
            ev.append('YouTube 同名频道')
            why.append('用户名 %s 在 YouTube 存在同名频道（可作为品牌/个人主页佐证）' % t.get('handle'))
    n_strong = len([s for s in sig if s in ('公司名', '自有域名', '邮箱', '电话', '地址')])
    if n_strong >= 2 or '企业邮箱' in sig:
        why.append('聊天里主动给了 %s 等可追溯线索（合计 %d 类）' % ('、'.join(sig), n_strong))
        return ('弱-中', ev + ['身份线索≥2类'], why)
    if n_strong == 1:
        why.append('聊天里只有 1 类身份线索（%s），属线索级' % '、'.join(sig))
        return ('弱', ev + ['身份线索1类'], why)
    return ('待核验', ev, why or ['聊天与平台字段里都没有可核验的主体信息（无公司名/域名/邮箱/电话/地址）'])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--refresh', action='store_true', help='忽略缓存，全部重查')
    ap.add_argument('--limit', type=int, default=0, help='最多核验多少个主体（调试）')
    args = ap.parse_args()
    epath = os.path.join(INQ, 'entities.json')
    if not os.path.isfile(epath):
        print('缺少 %s —— 先跑 python extract_entities.py' % epath)
        return 1
    ent = json.load(io.open(epath, encoding='utf-8'))
    buyers = ent.get('buyers') or {}
    dom_owners, co_owners = ({}, {})
    for nm, v in buyers.items():
        for d in v.get('domains') or []:
            dom_owners.setdefault(d, []).append(nm)
        for e in v.get('emails') or []:
            d = e.split('@')[-1].lower()
            if not is_junk_domain(d):
                dom_owners.setdefault(d, []).append(nm)
    for nm, v in buyers.items():
        for c in v.get('companies') or []:
            co_owners.setdefault(c, []).append(nm)
    doms = sorted(dom_owners)
    cos = sorted(co_owners)
    if args.limit:
        doms, cos = (doms[:args.limit], cos[:args.limit])
    print('候选：域名 %d ｜ 公司名 %d' % (len(doms), len(cos)))
    mail_owners, handle_owners = ({}, {})
    for nm, v in buyers.items():
        for e in v.get('emails') or []:
            mail_owners.setdefault(e, []).append(nm)
        for h in v.get('handles') or []:
            handle_owners.setdefault(h, []).append(nm)
    mails, hand = (sorted(mail_owners), sorted(handle_owners))
    mail_res, hand_res = ({}, {})
    for i, e in enumerate(mails, 1):
        mail_res[e] = cached('gprof', e, lambda e=e: gravatar_check(e), args.refresh)
        print('  [%d/%d] 邮箱 %-46s Gravatar=%s' % (i, len(mails), e[:46], '有' if mail_res[e]['has_avatar'] else '无'))
    for i, h in enumerate(hand, 1):
        hand_res[h] = cached('yt', h, lambda h=h: youtube_handle(h), args.refresh)
        print('  [%d/%d] 用户名 %-44s YouTube=%s' % (i, len(hand), h[:44], '存在' if hand_res[h]['exists'] else '无'))
    prof_res = {}
    for i, d in enumerate(doms, 1):
        prof_res[d] = cached('prof', d, lambda d=d: company_profile(d), args.refresh)
        _pr = prof_res[d]
        print('  [档案 %d/%d] %-38s %s' % (i, len(doms), d, '抓到 %d 页｜社媒 %d 个｜地址 %d｜电话 %d' % (len(_pr.get('pages') or []), len(_pr.get('socials') or []), len(_pr.get('addresses') or []), len(_pr.get('phones') or [])) if _pr.get('fetched') else _pr.get('note') or '无内容'))
    dom_res, co_res = ({}, {})
    for i, d in enumerate(doms, 1):
        dom_res[d] = cached('dom', d, lambda d=d: dict(rdap=rdap_domain(d), site=site_probe(d)), args.refresh)
        print('  [%d/%d] %-40s %s' % (i, len(doms), d, '未注册' if dom_res[d]['rdap'].get('registered') is False else '在营' if dom_res[d]['site'].get('reachable') and (not dom_res[d]['site'].get('parked')) else '已注册/站点异常'))
    for i, c in enumerate(cos, 1):
        cc = (buyers.get(co_owners[c][0]) or {}).get('country') or ''
        co_res[c] = cached('co', c, lambda c=c, cc=cc: companies_house(c, cc), args.refresh)
        print('  [%d/%d] %-40s %s' % (i, len(cos), c[:40], '命中' if co_res[c].get('hit') else '未命中' if co_res[c].get('supported') else '该国无免费库'))
    out, stat = ({}, {})
    for nm, v in buyers.items():
        doms_here = list(v.get('domains') or [])
        for e in v.get('emails') or []:
            d = e.split('@')[-1].lower()
            if not is_junk_domain(d) and d not in doms_here:
                doms_here.append(d)
                v.setdefault('signals', [])
                if '企业邮箱' not in v['signals']:
                    v['signals'].append('企业邮箱')
        bundle = dict(signals=v.get('signals') or [])
        bundle['mail'] = [mail_res[e] for e in v.get('emails') or [] if e in mail_res]
        bundle['tube'] = [hand_res[h] for h in v.get('handles') or [] if h in hand_res]
        bundle['phone_regions'] = [x for x in v.get('phone_regions') or [] if x and x[1]]
        _prof = {}
        for _d in doms_here:
            if prof_res.get(_d, {}).get('fetched'):
                _prof = prof_res[_d]
                break
        if _prof:
            bundle['profile'] = _prof
            for _s in _prof.get('socials') or []:
                v.setdefault('signals', [])
                if '社媒链接(独立站)' not in v['signals']:
                    v['signals'].append('社媒链接(独立站)')
                break
        if doms_here:
            d = doms_here[0]
            bundle.update(rdap=dom_res.get(d, {}).get('rdap') or {}, site=dom_res.get(d, {}).get('site') or {})
        if v.get('companies'):
            c = v['companies'][0]
            bundle['registry'] = co_res.get(c, {})
        grade, ev, why = grade_of(bundle)
        stat[grade] = stat.get(grade, 0) + 1
        src = [s for s in ('RDAP', 'SITE', 'REGISTRY') if bundle.get(s.lower())]
        out[nm] = dict(entity=(v.get('companies') or [''])[0], profile=bundle.get('profile') or {}, mail_kind=v.get('mail_kind') or '', emails=v.get('emails') or [], gravatar=bool([m for m in bundle.get('mail') or [] if m.get('has_avatar')]), gravatar_names=[m.get('name') for m in bundle.get('mail') or [] if m.get('has_avatar') and m.get('name')], gravatar_users=[m.get('username') for m in bundle.get('mail') or [] if m.get('has_avatar') and m.get('username')], youtube=[t.get('handle') for t in bundle.get('tube') or [] if t.get('exists')], social=v.get('social') or [], phone_regions=bundle.get('phone_regions') or [], verify='；'.join(why) if why else '', grade=grade, basis='自动核验：' + ('、'.join(ev) if ev else '暂无可核验证据'), sources=src, evidence=ev, auto=True, evidence_count=len(ev), rdap=bundle.get('rdap') or {}, site=bundle.get('site') or {}, registry=bundle.get('registry') or {})
    dst = os.path.join(INQ, 'verify_auto.json')
    with io.open(dst, 'w', encoding='utf-8') as fh:
        fh.write(json.dumps(dict(generated=time.strftime('%Y-%m-%d %H:%M'), window=ent.get('window'), store=ent.get('store'), sources=dict(rdap='rdap.org 域名注册数据', site='客户官网抓取', registry='英国公司注册处（仅 GB）', gravatar='Gravatar 档案（邮箱 → 显示名 / handle / 头像）', youtube='YouTube 用户名存在性', profile='客户独立站深挖（首页/关于/联系页 → 公司名·地址·电话·主营·社媒·是否电商）'), buyers=out), ensure_ascii=False, indent=1))
    print()
    print('已生成 %s' % dst)
    for g in ('中-强', '中', '弱-中', '弱', '待核验'):
        if stat.get(g):
            print('  %-6s %d' % (g, stat[g]))
    return 0
if __name__ == '__main__':
    http_get.__doc__
    sys.exit(main())
