import argparse, json, shutil, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))
from scope_filter import filter_scope

def main():
    p = argparse.ArgumentParser()
    for key in ('source', 'output', 'seller', 'start', 'end'):
        p.add_argument('--' + key, required=True)
    p.add_argument('--skip-public', action='store_true')
    a = p.parse_args()
    source = Path(a.source).resolve()
    dest = Path(a.output).resolve()
    evidence = source / 'calendar-collection.json'
    if not evidence.is_file() or json.loads(evidence.read_text(encoding='utf-8-sig')).get('status') != 'VERIFIED':
        raise ValueError('来源缺少完整采集验证，不能生成报告')
    data = json.loads((source / 'conversations.json').read_text(encoding='utf-8-sig'))
    import inquiry_calendar
    inquiry_calendar.verified_part(source, str(data['store']['aliId']), {'start': a.start, 'end': a.end})
    scoped = filter_scope(data, a.seller, a.start, a.end)
    if not scoped['conversations']:
        raise ValueError('该账号期间无可核验消息，未生成报告')
    names = {}
    for c in data['conversations']:
        name = c.get('contactName') or ''
        if name:
            names.setdefault(name, set()).add(str(c.get('contactAliId') or ''))
    if any(not c.get('contactName') or not c.get('contactAliId') for c in scoped['conversations']):
        raise ValueError('买家身份不完整，停止筛选')
    chosen = {c.get('contactName') for c in scoped['conversations'] if c.get('contactName')}
    if any((len(names[n]) != 1 or '' in names[n] for n in chosen)):
        raise ValueError('买家名称与身份无法唯一对应，停止筛选')
    if dest.exists():
        raise ValueError('输出目录已存在，请使用新目录')
    shutil.copytree(ROOT, dest, ignore=shutil.ignore_patterns('__pycache__', 'inquiry'))
    out = dest / 'inquiry'
    out.mkdir()

    def write(name, value):
        (out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    write('conversations.json', scoped)
    buyers = json.loads((source / 'buyers.json').read_text(encoding='utf-8-sig'))
    write('buyers.json', [b for b in buyers if b.get('contactName') in chosen and str(b.get('contactAliId') or '') in names[b['contactName']]])
    rows = scoped['conversations']
    write('fetch_stats.json', {'window': {'start': a.start, 'end': a.end}, 'accounts': data['store']['accountCount'] if a.seller == 'all' else 1, 'conversations': len(rows), 'messages': sum((len(x['messages']) for x in rows)), 'inquiry_conversations': sum((x.get('channel') == '询盘' for x in rows)), 'tm_conversations': sum((x.get('channel') != '询盘' for x in rows))})
    contacts = source / 'contacts.json'
    if contacts.is_file():
        value = json.loads(contacts.read_text(encoding='utf-8-sig'))
        value['contacts'] = {k: v for k, v in value.get('contacts', {}).items() if k in chosen}
        write('contacts.json', value)
    scripts = ['extract_entities.py'] + ([] if a.skip_public else ['verify_companies.py']) + ['make_inquiry_report.py', 'make_customer_table.py']
    for script in scripts:
        r = subprocess.run([sys.executable, str(dest / script)], cwd=dest, capture_output=True, text=True, encoding='utf-8', errors='replace')
        if r.returncode:
            raise RuntimeError(script + ' 运行失败，未交付报告')
    reports = list(out.glob('询盘客户背调分析_*.html'))
    if len(reports) != 1 or reports[0].stat().st_size < 1000:
        raise RuntimeError('报告缺失')
    books=list(out.glob('*.xlsx'))
    if len(books)!=1: raise RuntimeError('Excel产物缺失')
    import openpyxl
    book=openpyxl.load_workbook(books[0],read_only=True)
    if len(book.sheetnames)!=12: raise RuntimeError('Excel工作表缺失')
    book.close()
    from html import escape
    for page in out.glob('*.html'):
        text = page.read_text(encoding='utf-8-sig')
        label = '已执行公开核验；未命中仍待核验' if not a.skip_public else '未执行公网核验'
        notice = '<div style="padding:12px;background:#eef5ef">统计范围：' + escape(a.start + ' 至 ' + a.end + ' · Asia/Shanghai · 业务员 ' + a.seller + ' · ' + label) + '</div>'
        import re
        page.write_text(re.sub('(<body\\b[^>]*>)', lambda m: m.group(1) + notice, text, count=1, flags=re.I), encoding='utf-8')
    print(str(reports[0]))
if __name__ == '__main__':
    main()
