import argparse
import io
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timedelta
HERE = os.path.dirname(os.path.abspath(__file__))
INQ = os.path.join(HERE, 'inquiry')
BIN = os.path.join(HERE, 'bin')
CLI = os.path.join(BIN, 'accio-mcp-cli')
if os.name == 'nt':
    CLI = CLI + '.cmd'
MAX_WINDOW_DAYS = 7
CHUNK = 40

def _run(args, timeout=180):
    exe = [CLI] if CLI.lower().endswith('.cmd') else ['bash', CLI]
    p = subprocess.run(exe + args, capture_output=True, text=True, encoding='utf-8', errors='ignore', timeout=timeout, cwd=(os.path.splitdrive(BIN)[0]+os.sep if os.name == 'nt' else BIN))
    return (p.stdout or '', p.stderr or '', p.returncode)

def call_tool(tool, payload, timeout=180):
    fp = os.path.join(INQ, '_tool_payload.json')
    io.open(fp, 'w', encoding='utf-8').write(json.dumps(payload, ensure_ascii=False))
    out, err, rc = _run(['call', tool, '--json-file', fp, '--raw'], timeout=timeout)
    if not out.strip():
        return dict(success=False, errorMsg=(err or 'no output')[:200])
    try:
        outer = json.loads(out)
        txt = outer['content'][0]['text'] if isinstance(outer.get('content'), list) else out
    except Exception:
        try:
            txt = out.encode('utf-8', 'ignore').decode('gbk', 'ignore')
        except Exception:
            return dict(success=False, errorMsg='输出无法解析: %s' % out[:160])
    try:
        return json.loads(txt)
    except Exception as e:
        return dict(success=False, errorMsg='解析失败: %s | %s' % (e, str(txt)[:160]))

def resolve_identity():
    wc = os.path.join(BIN, 'workctl')
    if os.name == 'nt':
        wc = wc + '.cmd'
    exe = [wc] if wc.lower().endswith('.cmd') else ['bash', wc]
    tmp = os.path.join(INQ, '_identity.json')
    p = subprocess.run(exe + ['workflow', 'chat-analysis', 'resolve-id', '--output-file', tmp], capture_output=True, text=True, encoding='utf-8', errors='ignore', timeout=180, cwd=(os.path.splitdrive(BIN)[0]+os.sep if os.name == 'nt' else BIN))
    m = re.search('\\{.*\\}', p.stdout or '', re.S)
    cur = json.loads(m.group(0)) if m else {}
    ident = {}
    if os.path.isfile(tmp):
        try:
            ident = json.load(io.open(tmp, encoding='utf-8'))
        except Exception:
            ident = {}
    members = []
    if cur.get('CURRENT_SELF_ALIID'):
        members.append(dict(aliId=str(cur['CURRENT_SELF_ALIID']), name=cur.get('CURRENT_NAME') or '', admin=True))
    for m2 in ident.get('otherMembers') or []:
        members.append(dict(aliId=str(m2.get('aliId')), name=('%s %s' % (m2.get('firstName') or '', m2.get('lastName') or '')).strip(), admin=False))
    return (cur, members)

def ms(datestr):
    return int(datetime.strptime(datestr, '%Y-%m-%d').timestamp() * 1000)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--start-date', default='')
    ap.add_argument('--end-date', default='')
    ap.add_argument('--days', type=int, default=7)
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()
    end = args.end_date or datetime.now().strftime('%Y-%m-%d')
    start = args.start_date or (datetime.strptime(end, '%Y-%m-%d') - timedelta(days=min(args.days, MAX_WINDOW_DAYS) - 1)).strftime('%Y-%m-%d')
    if (datetime.strptime(end, '%Y-%m-%d') - datetime.strptime(start, '%Y-%m-%d')).days >= MAX_WINDOW_DAYS:
        print('窗口不能 ≥ %d 天，已自动收窄' % MAX_WINDOW_DAYS)
        start = (datetime.strptime(end, '%Y-%m-%d') - timedelta(days=MAX_WINDOW_DAYS - 1)).strftime('%Y-%m-%d')
    cur, members = resolve_identity()
    print('当前登录：%s（%s）｜ 子账号 %d 个' % (cur.get('CURRENT_NAME'), cur.get('CURRENT_SELF_ALIID'), len(members) - 1))
    if args.dry_run:
        for m in members:
            print('   ', m['aliId'], m['name'])
        return 0
    s_ms, e_ms = (ms(start), ms(end) + 24 * 3600 * 1000 - 1)
    convs, fail = ({}, [])
    for i, m in enumerate(members, 1):
        r = call_tool('query_active_conversation_msg', dict(selfAliId=int(m['aliId']), activeStartTime=s_ms, activeEndTime=e_ms, msgStartTime=s_ms, msgEndTime=e_ms, domain='icbu'), timeout=240)
        if not r.get('success'):
            fail.append((m['name'] or m['aliId'], (r.get('errorMsg') or '')[:80]))
            print('  [%d/%d] %-14s 失败：%s' % (i, len(members), m['name'] or m['aliId'], (r.get('errorMsg') or '')[:60]))
            continue
        lst = (r.get('data') or {}).get('conversations') or []
        for c in lst:
            tok = c.get('chatToken')
            if tok:
                convs[tok] = dict(account=m['name'] or m['aliId'], selfAliId=int(m['aliId']), contactName=c.get('contactName'), contactAliId=c.get('contactAliId'), contactLoginId=c.get('contactLoginId'))
        print('  [%d/%d] %-14s 会话 %d 个' % (i, len(members), m['name'] or m['aliId'], len(lst)))
    print('共拿到 %d 个会话 token' % len(convs))
    if not convs:
        print('\n没有拿到任何会话 —— 检查：① Accio 是否登录了目标店铺；② 该店铺在 %s ~ %s 是否有会话' % (start, end))
        return 1
    by_acc = {}
    for tok, meta in convs.items():
        by_acc.setdefault(meta['selfAliId'], []).append(tok)
    rows, n_mail = ({}, 0)
    for acc, toks in by_acc.items():
        for j in range(0, len(toks), CHUNK):
            part = toks[j:j + CHUNK]
            r = call_tool('query_conversation_info', dict(selfAliId=acc, chatTokens=part), timeout=240)
            if not r.get('success'):
                print('  账号 %s 批次 %d 失败：%s' % (acc, j // CHUNK + 1, (r.get('errorMsg') or '')[:70]))
                continue
            for c in (r.get('data') or {}).get('conversations') or []:
                nm = c.get('contactName') or ''
                mail = c.get('contactEmail') or ''
                rows[nm] = dict(name=nm, email=mail, buyerName=c.get('customerBuyerName') or '', aliId=c.get('contactAliId'), loginId=c.get('contactLoginId') or '', country=(c.get('contactCountry') or '').upper(), level=c.get('contactLevel') or '', stage=c.get('stage') or '', tags=c.get('tags') or [], displayName=c.get('displayName') or '', createTime=c.get('conversationCreateTime') or '', account=(convs.get(toks[0], {}) or {}).get('account', ''), selfAliId=acc)
                if mail:
                    n_mail += 1
            time.sleep(0.3)
    dst = os.path.join(INQ, 'contacts.json')
    with io.open(dst, 'w', encoding='utf-8') as f:
        f.write(json.dumps(dict(store=cur, window=dict(start=start, end=end), generated=datetime.now().strftime('%Y-%m-%d %H:%M'), contacts=rows), ensure_ascii=False, indent=1))
    print('\n已生成 %s' % dst)
    print('  联系人 %d 个 ｜ 其中带邮箱 %d 个（%.0f%%）' % (len(rows), n_mail, 100.0 * n_mail / max(1, len(rows))))
    if fail:
        print('  未取到的账号 %d 个：%s' % (len(fail), '；'.join(('%s(%s)' % x for x in fail[:5]))))
    cpath = os.path.join(INQ, 'conversations.json')
    if os.path.isfile(cpath):
        d = json.load(io.open(cpath, encoding='utf-8'))
        cur_login = cur.get('selfLoginId') if isinstance(cur, dict) else ''
        cur_login = cur_login or (cur.get('CURRENT_SELF_ALIID') or '')
        conv_store = (d.get('store') or {}).get('aliId') or ''
        if conv_store and str(cur_login) and (str(cur_login) != str(conv_store)) and len(rows) and (not any(((c.get('contactName') or '') in rows for c in (d.get('conversations') or [])[:50]))):
            print('  ⚠ 当前登录（%s）与 conversations.json 的店铺（%s）不是同一家 —— 为防串店，本次不回写。要补这家店的邮箱请先切到对应店铺登录。' % (cur_login, conv_store))
            return 0
        n_write = 0
        for c in d.get('conversations') or []:
            k = c.setdefault('crm', {})
            hit = rows.get(c.get('contactName') or '')
            if hit:
                wrote = False
                if hit['email'] and k.get('contactEmail') != hit['email']:
                    k['contactEmail'] = hit['email']
                    wrote = True
                if hit['buyerName'] and k.get('customerBuyerName') != hit['buyerName']:
                    k['customerBuyerName'] = hit['buyerName']
                    wrote = True
                for f in ('stage', 'tags', 'displayName'):
                    if not k.get(f) and hit.get(f):
                        k[f] = hit[f]
                        wrote = True
                if wrote:
                    n_write += 1
        with io.open(cpath, 'w', encoding='utf-8') as f:
            f.write(json.dumps(d, ensure_ascii=False))
        print('  已回写 conversations.json：%d 个会话补上联系方式字段' % n_write)
    return 0
if __name__ == '__main__':
    sys.exit(main())
