"""Filter a verified collection by seller ID and inclusive Shanghai dates."""
from copy import deepcopy
from datetime import datetime, timezone, timedelta, date

TZ = timezone(timedelta(hours=8))

def day(value):
    if isinstance(value, (int, float)) or isinstance(value, str) and value.isdigit():
        stamp = float(value)
        return datetime.fromtimestamp(stamp / 1000 if stamp > 1e11 else stamp, timezone.utc).astimezone(TZ).date()
    if not isinstance(value, str):
        raise ValueError('消息缺少时间')
    dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
    return (dt.replace(tzinfo=TZ) if dt.tzinfo is None else dt.astimezone(TZ)).date()

def filter_scope(data, seller, start, end):
    first, last = date.fromisoformat(start), date.fromisoformat(end)
    if first > last or not seller:
        raise ValueError('无效日期或业务员账号')
    result = deepcopy(data)
    source_window = data.get('window', {})
    if str(source_window.get('since', ''))[:10] > start or str(source_window.get('until', ''))[:10] < end:
        raise ValueError('来源不覆盖所选区间')
    rows = []
    for row in result.get('conversations', []):
        if not row.get('sellerAliId'):
            raise ValueError('会话缺少业务员归属')
        if seller != 'all' and str(row['sellerAliId']) != str(seller):
            continue
        row['messages'] = [m for m in row.get('messages', []) if first <= day(m.get('sendTime')) <= last]
        if row['messages']:
            rows.append(row)
    result['conversations'] = rows
    result['window'] = {'since': start + 'T00:00:00', 'until': end + 'T23:59:59', 'timezone': 'Asia/Shanghai', 'basis': 'custom'}
    return result
