"""Offline end-to-end check with synthetic data only."""
import json, os, subprocess, sys, uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'engine'))
from inquiry_calendar import merge_parts, verified_part
from calendar_periods import chunks

def main():
    base=ROOT/'validation'/uuid.uuid4().hex;base.mkdir(parents=True)
    def put(p,d):p.write_text(json.dumps(d,ensure_ascii=False),encoding='utf-8')
    periods=chunks('2026-10-02','2026-10-11');assert len(periods)==2
    parts=[]
    for index,period in enumerate(periods):
        folder=base/str(index);folder.mkdir();work=folder/'.work';work.mkdir();parts.append((folder,period))
        rows=[]
        for seller,buyer in [('seller1','buyer1'),('seller2','buyer2')]:
            rows.append({'conversationId':'same-id','sellerAliId':seller,'sellerName':seller,'contactAliId':buyer,'contactName':'DEMO '+buyer,'contactLoginId':buyer,'contactCountry':'US','channel':'TM','crm':{'stage':'INQUIRY','tags':[]},'lastActiveTime':period['start']+'T12:00:00+08:00','messages':[{'sendTime':period['start']+'T12:00:00+08:00','senderRole':'buyer','content':'We need private label electrolyte powder, 1000 bags. Please quote.'},{'sendTime':period['start']+'T12:01:00+08:00','senderRole':'seller','content':'What target market and serving size do you need?'}]})
        meta={'startDate':period['start'],'endDate':period['end'],'failureRatio':0}
        raw=work/'conversations_all.json';put(raw,{'conversations':rows,'meta':dict(meta,totalAccounts=2,totalFailedAccounts=0,totalConversations=2)})
        msgs=[{'conversationId':c['conversationId'],'sellerAliId':c['sellerAliId'],'messages':[{'time':m['sendTime'],'from':m['senderRole'],'text':m['content']} for m in c['messages']]} for c in rows]
        put(work/'messages_all.json',{'conversations':msgs,'meta':dict(meta,sourceConversationFile=str(raw),totalInputConversations=2,sourceTotalConversations=2,totalMessages=4,totalConversationsWithMessages=2)})
        put(folder/'conversations.json',{'window':{'since':period['start']+'T00:00:00','until':period['end']+'T23:59:59'},'store':{'aliId':'123','name':'DEMO STORE','accountCount':2},'conversations':rows})
        put(folder/'buyers.json',[{'contactName':c['contactName'],'contactAliId':c['contactAliId'],'contactLoginId':c['contactLoginId'],'persona':{}} for c in rows])
    merged=base/'merged';stats=merge_parts(parts,merged,'123','2026-10-02','2026-10-11');assert stats['messages']==8
    try:merge_parts(parts[:1],base/'bad','123','2026-10-02','2026-10-11')
    except ValueError:pass
    else:raise AssertionError('missing segment accepted')
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
    command=[sys.executable,str(ROOT/'engine/run_scoped.py'),'--source',str(merged),'--output',str(base/'report'),'--seller','seller1','--start','2026-10-02','--end','2026-10-11','--skip-public']
    r=subprocess.run(command,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
    if r.returncode:print(r.stdout,r.stderr);return r.returncode
    scoped=json.loads((base/'report/inquiry/conversations.json').read_text(encoding='utf-8'))
    assert {c['sellerAliId'] for c in scoped['conversations']}=={'seller1'}
    reports=list((base/'report/inquiry').glob('*.html'));assert len(reports)==2
    assert 'DEMO buyer2' not in reports[0].read_text(encoding='utf-8')
    import openpyxl
    book=next((base/'report/inquiry').glob('*.xlsx'));w=openpyxl.load_workbook(book,read_only=True);assert len(w.sheetnames)==12;w.close()
    (ROOT/'VALIDATION.json').write_text(json.dumps({'syntax':'pending','offlinePipeline':'PASS','dateChunks':'PASS','sellerIsolation':'PASS','crossSellerConversationIds':'PASS','missingSegmentRejected':'PASS','htmlFiles':2,'workbookSheets':12,'liveAccio':'NOT_RUN','evidence':str(base)},indent=2),encoding='utf-8')
    print('OFFLINE_PIPELINE_PASS',base)
    return 0

if __name__=='__main__':sys.exit(main())
