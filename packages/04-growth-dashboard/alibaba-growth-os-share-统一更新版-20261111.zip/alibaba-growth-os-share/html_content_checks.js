/* Retired: preserve the original AI scoring and downstream panels. */
