# -*- coding: utf-8 -*-
"""
make_dashboard.py — 国际站经营数据面板 · 生成向导

给同事用的入口。双击「一键生成看板.bat」或直接运行本脚本即可。
它做四件事：
  1. 自动搭桥 + 环境自检（调 setup_env.py）
  2. 问你要哪段时间的数据（完整自然周数 / 月度历史月数 / 可选截止日）
  3. 自动读出当前 Accio 登录店铺的真实店名，写成店铺配置
  4. 按正确顺序跑完整条数据管线，最后生成看板并打开

设计原则：
  - 不写死任何店铺、日期、路径；换人换店直接可用
  - 每一步失败就停，给出中文排查方向，绝不带病继续
  - 全程输出同时写日志（logs/），出问题可回看
"""
import argparse
from pathlib import Path
import datetime
import glob
import io
import json
import os
import shutil
import subprocess
import sys
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE = os.path.join(HERE, 'engine')
BIN = os.path.join(HERE, 'bin')
WS = os.path.join(ENGINE, 'workspace')
LOGS = os.path.join(HERE, 'logs')
SETTINGS = os.path.join(HERE, 'settings.json')
HOME = os.path.expanduser('~')

_logf = None


# ------------------------------------------------------------------ 工具
def log(msg=''):
    print(msg, flush=True)
    if _logf:
        try:
            _logf.write(msg + '\n')
            _logf.flush()
        except Exception:
            pass


_EOF = False


def ask(prompt, default=None):
    """交互提问。读不到输入（EOF / 被自动化调用）时返回默认值，并置 _EOF。

    注意：不能用 sys.stdin.isatty() 判断——在本机后台运行时它仍返回 True，
    会导致「静默采用默认值」，在需要用户选择的场景（多店铺）会选错。用 EOF 才准。
    """
    global _EOF
    _EOF = False
    tip = ' [%s]' % default if default not in (None, '') else ''
    try:
        s = input('%s%s: ' % (prompt, tip)).strip()
    except (EOFError, KeyboardInterrupt):
        _EOF = True
        log('    （读不到交互输入，按默认值处理）')
        return default
    return s or default


def run(cmd, cwd, name, timeout=7200):
    """跑一步，实时输出并写日志。失败返回 False。"""
    log('\n>>> %s' % name)
    log('    $ %s' % ' '.join(cmd))
    env = dict(os.environ)
    env['PATH'] = BIN + os.pathsep + env.get('PATH', '')
    t0 = time.time()

    def _spawn(use_shell):
        return subprocess.Popen(cmd, cwd=cwd, env=env, shell=use_shell,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, encoding='utf-8', errors='replace', bufsize=1)

    try:
        p = _spawn(False)
    except (FileNotFoundError, OSError):
        # bin/ 下的 workctl / accio-mcp-cli 是 .cmd，Windows 下不经 shell 起不来。
        # 直接执行失败时回退到 shell=True（cmd 里会按 PATH 找到 .cmd）。
        try:
            p = _spawn(True)
        except Exception as e:
            log('    !! 无法启动: %s' % e)
            return False
    except Exception as e:
        log('    !! 无法启动: %s' % e)
        return False
    tail = []
    for line in p.stdout:
        line = line.rstrip('\n')
        if line:
            log('    ' + line)
            tail.append(line)
            tail = tail[-40:]
    try:
        p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        try:
            p.wait(timeout=30)
        except Exception:
            pass
        log('    !! 超时（> %d 秒），已强制结束' % timeout)
        return False
    dt = time.time() - t0
    if p.returncode != 0:
        log('    !! 失败（退出码 %d，耗时 %.0f 秒）' % (p.returncode, dt))
        log('    最后输出：')
        for t in tail[-8:]:
            log('      ' + t)
        return False
    log('    OK（耗时 %.0f 秒）' % dt)
    return True


def cli(tool_argv, timeout=180):
    """调一次网关 CLI（走 bin 桥接）。返回解析后的 JSON 或 None。"""
    env = dict(os.environ)
    env['PATH'] = BIN + os.pathsep + env.get('PATH', '')
    try:
        r = subprocess.run(tool_argv, capture_output=True, text=True, encoding='utf-8',
                           errors='replace', timeout=timeout, env=env, shell=True)
    except Exception:
        return None
    out = (r.stdout or '')
    i = out.find('{')
    if i < 0:
        return None
    try:
        return json.loads(out[i:])
    except Exception:
        return None


# ------------------------------------------------------- 1. 环境
def step_env():
    log('\n[1/5] 环境自检与自动搭桥')
    sys.path.insert(0, HERE)
    import setup_env
    r = setup_env.setup(verbose=False)
    log('    node      : %s' % (r.get('node') or '未找到'))
    log('    accio-mcp : %s' % (r.get('mcp') or '未找到'))
    log('    workctl   : %s' % (r.get('workctl') or '未找到'))
    log('    网关凭据  : %s' % ('已取到' if r.get('token') else '未取到'))
    log('    连通性    : %s' % r.get('msg'))
    if not r.get('ok'):
        log('\n[停止] 环境没准备好。请检查：')
        log('  1) Accio 桌面端是否已安装并正在运行')
        log('  2) 是否已在 Accio 里登录你的 Alibaba 国际站账号')
        log('  3) 若 CLI 装在非标准目录，可用环境变量指定后重试：')
        log('     set ACCIO_MCP_SCRIPT=<accio-mcp.mjs 路径>')
        return False
    return True


def ensure_deps():
    pass  # Unencrypted dashboard; no automatic dependency installation.


# ------------------------------------------------------- 2. 时间窗口
def step_period(args):
    from datetime import datetime, timedelta, timezone
    import datetime as dt
    as_of=args.as_of or datetime.now(timezone(timedelta(hours=8))).date().isoformat()
    dt.date.fromisoformat(as_of)
    weeks=args.weeks or 4; months=args.months or 6
    if not 1<=weeks<=52 or not 1<=months<=36: raise ValueError('周数1至52，月数1至36')
    os.environ['DASHBOARD_AS_OF']=as_of
    log('平台日期：'+as_of+'；默认展示最新已结束自然周，月报为完整自然月')
    return weeks,months,as_of


# ------------------------------------------------------- 3. 店铺身份
def _listening_pid(port='4097'):
    try:
        out = subprocess.run(['netstat', '-ano'], capture_output=True, text=True,
                             encoding='utf-8', errors='replace', timeout=30,
                             creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)).stdout or ''
    except Exception:
        return None
    for line in out.splitlines():
        if (':%s ' % port) in line and 'LISTENING' in line.upper():
            m = line.split()
            if m and m[-1].isdigit():
                return m[-1]
    return None


def _active_account():
    """按网关 pid 定位当前账号目录，取其中的 Alibaba label。

    新版 Accio（2026-11 起）的 connected-accounts.json 只写 label + connector_id，
    ali_id / company_name / login_id 全部不再落盘。这时只能靠 pid 认出「当前绑的是哪个
    账号目录」，再读该目录的 label —— 绝不能遍历全部目录去猜，否则会串到别家店。
    """
    files = glob.glob(os.path.join(HOME, '.accio', 'accounts', '*', '.accio',
                                   'runtime', 'gateway-cli.json'))
    pid = _listening_pid()
    cur = None
    if pid:
        for p in files:
            try:
                d = json.load(open(p, encoding='utf-8'))
            except Exception:
                continue
            if str(d.get('pid')) == str(pid):
                cur = os.path.dirname(os.path.dirname(os.path.dirname(p)))
                break
    if not cur:
        return None
    f = os.path.join(cur, 'connected-accounts.json')
    if not os.path.isfile(f):
        return None
    try:
        d = json.load(open(f, encoding='utf-8'))
    except Exception:
        return None
    for a in ((d.get('alibaba') or {}).get('accounts') or []):
        lb = (a.get('label') or '').strip()
        if lb:
            return {'company': lb, 'ali_id': '', 'login_id': lb}
    return None


def detect_accounts():
    """读出已连接的 Alibaba 店铺。

    两级来源：
    1. 强记录 —— metadata 里有数字 ali_id 且有公司全称（旧版 Accio）。这时严格筛，
       因为残缺记录会导致选错店、把别人的数据做成看板。
    2. 弱记录 —— 新版 Accio 只写 label，强记录为空时按网关 pid 认当前账号目录，
       只取那一条，不遍历全部目录。
    """
    accs = {}
    for p in glob.glob(os.path.join(HOME, '.accio', 'accounts', '*', 'connected-accounts.json')):
        try:
            d = json.load(open(p, encoding='utf-8'))
        except Exception:
            continue
        for a in ((d.get('alibaba') or {}).get('accounts') or []):
            m = a.get('metadata') or {}
            aid = str(m.get('ali_id') or '').strip()
            company = (m.get('company_name') or '').strip()
            if not aid.isdigit() or not company:
                continue
            if aid in accs:
                continue
            accs[aid] = {'company': company, 'ali_id': aid,
                         'login_id': (m.get('login_id') or a.get('label') or '').strip()}
    if accs:
        return list(accs.values())
    weak = _active_account()
    return [weak] if weak else []


def _pick_account(accs):
    if len(accs) == 1:
        return accs[0]
    log('    检测到多个已连接的 Alibaba 店铺：')
    for i, a in enumerate(accs, 1):
        log('      %d) %s（%s）' % (i, a['company'], a['ali_id']))
    v = ask('    请选择要做看板的那个（填序号）', '1')
    if _EOF:
        # 无法交互时不猜：选错店等于把别人的数据做成看板
        log('\n[停止] 有 %d 个店铺可做，但当前无法交互选择。' % len(accs))
        log('   请双击「一键生成看板.bat」手动选一个，')
        log('   或加参数指定店铺名： python make_dashboard.py --store-name "<上面列出的店铺名>"')
        return None
    try:
        return accs[max(0, min(len(accs) - 1, int(v) - 1))]
    except Exception:
        return accs[0]


def step_store(args, weeks, as_of):
    log('\n[3/5] 确认店铺身份')
    if not os.path.isdir(WS):
        log('    !! workspace 不存在，先部署引擎')
        return None
    existed = os.path.isfile(os.path.join(WS, 'stores.json'))
    _deploy()
    accs = detect_accounts()
    if not accs:
        if args.store_name:
            # Accio 在切换账号时会重写 connected-accounts.json，可能把 alibaba 条目清空，
            # 但网关取数其实还通着（实测：连接记录没了，754 个产品照样能拉到）。
            # 这种情况下用户已经明确指定了店名，不该拦住 —— store_id 留空，
            # 只影响「管理」页的跳转链接，不影响看板主体。
            log('    （Accio 连接记录里没读到已连接店铺，按指定店名继续。'
                'store_id 留空，仅影响「管理」页跳转链接）')
            accs = [{'company': args.store_name, 'ali_id': '', 'login_id': ''}]
        else:
            log('\n[停止] 没有从 Accio 读到任何已连接的 Alibaba 账号。')
            log('   请先在 Accio 里登录并连接你的国际站账号，然后重跑。')
            log('   （也可能是刚切换过账号，Accio 正在重写连接记录，等几秒再试）')
            return None

    prev = {}
    if args.reuse and existed:
        try:
            c = json.load(open(os.path.join(WS, 'stores.json'), encoding='utf-8'))
            prev = (c.get('stores') or {}).get(c.get('active')) or {}
            if prev.get('name') and not str(prev.get('name')).startswith('在此填写'):
                # 一个文件夹只对应一家店。若 Accio 现在已经切到别家，复用会串数据。
                cur = _active_account() or {}
                cur_lb = (cur.get('login_id') or '').strip()
                prev_lb = (prev.get('account_label') or '').strip()
                if cur_lb and prev_lb and cur_lb != prev_lb:
                    log('    !! Accio 当前绑定 %s，本文件夹上次用的是 %s' % (cur_lb, prev_lb))
                    log('       同一文件夹换店会串数据，已停止。换店请另建店铺文件夹。')
                    return None
                log('    复用上次配置：%s%s' % (
                    prev.get('name'), ('（%s）' % cur_lb) if cur_lb else ''))
                if cur_lb and not prev_lb:
                    prev['account_label'] = cur_lb
                    try:
                        json.dump(c, open(os.path.join(WS, 'stores.json'), 'w', encoding='utf-8'),
                                  ensure_ascii=False, indent=2)
                    except Exception:
                        pass
                return prev
        except Exception:
            pass

    if args.store_name:
        # 已显式指定店名：按名字匹配账号（匹配不到就用第一个），不再追问
        acc = next((a for a in accs if a['company'] == args.store_name), accs[0])
    else:
        acc = _pick_account(accs)
        if not acc:
            return None
    store_name = args.store_name or (acc['company'] or acc['login_id'])
    key = (acc['login_id'] or 'mystore').strip() or 'mystore'
    key = ''.join(ch for ch in key if ch.isalnum() or ch in '-_') or 'mystore'

    user_label = args.user_label
    if user_label is None:
        dflt = '%s (子账号)' % (acc['login_id'] or 'operator')
        user_label = ask('    顶部右侧显示的运营者', dflt) or dflt

    log('    店铺名: %s' % store_name)
    log('    账号  : %s' % (acc['ali_id'] or '-'))
    log('    运营者: %s' % user_label)

    cfg = {'active': key, 'stores': {key: {
        'name': store_name, 'full_name': store_name, 'user_label': user_label,
        'store_id': acc['ali_id'] or '', 'account_label': acc['login_id'] or '',
        'category': '', 'cate_id': 0,
        'db': 'stores/%s/database/alibaba_growth.db' % key,
        'raw': 'stores/%s/raw' % key,
        'img_map': 'stores/%s/img_map.json' % key}}}
    json.dump(cfg, open(os.path.join(WS, 'stores.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=2)
    log('    已写入 workspace/stores.json')
    return cfg['stores'][key]


def probe_cate():
    """从平台读出当前店铺的主类目 id，写回 stores.json。失败不阻塞主流程。"""
    sj = os.path.join(WS, 'stores.json')
    try:
        cfg = json.load(open(sj, encoding='utf-8'))
        key = cfg.get('active')
        st = (cfg.get('stores') or {}).get(key) or {}
        if int(st.get('cate_id') or 0) > 0:
            return
        w = json.load(open(os.path.join(WS, 'raw', '_window.json'), encoding='utf-8'))
        wk = (w.get('weeks') or [{}])[0]
        pf = os.path.join(WS, 'raw', '_cate_probe.json')
        with open(pf, 'w', encoding='utf-8') as f:
            json.dump({'advisorQueryParam': {'statisticsType': '7d',
                                             'startDate': wk.get('week_start'),
                                             'endDate': wk.get('week_end')}}, f)
        d = cli(['accio-mcp-cli', 'call', 'data_advisor_shop_summary', '--json-file', pf])
        try:
            os.remove(pf)
        except Exception:
            pass
        rows = (d or {}).get('data') or []
        cate = int((rows[0] or {}).get('cateId') or 0) if rows else 0
        if cate:
            st['cate_id'] = cate
            cfg['stores'][key] = st
            json.dump(cfg, open(sj, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
            log('\n>>> A1b 识别主类目: %s' % cate)
        else:
            log('\n>>> A1b 未能识别主类目（不影响主流程，「类目热品榜」可能为空）')
    except Exception as e:
        log('\n>>> A1b 主类目识别跳过（%s）' % e)


# ------------------------------------------------------- 4. 跑管线
def step_pipeline(weeks, months, as_of):
    log('\n[4/5] 拉取数据并计算（这一步最久，可放着自己跑）')
    py = sys.executable
    aof = ['--as-of', as_of] if as_of else []
    wk = ['--weeks', str(weeks)]

    # A1 拉数（同时生成 raw/_window.json，后面的主类目识别要靠它）
    if not run([py, 'fetch_new_store.py'] + aof + wk, WS, 'A1 拉取周/月/产品全量', 3600):
        return False, 'A1 拉取周/月/产品全量'

    # A1b 从平台读出主类目 id（写进 stores.json，供「类目热品榜」用）
    probe_cate()

    steps = [
        ('A2 建库并回填', ['init_store.py'] + aof + wk, 3600),
        ('A3 补齐缺失的表', ['create_missing_tables.py'], 600),
        ('A4 补齐缺失的列', ['fix_columns.py'], 600),
        ('B1 国家/渠道/关键词/类目热品', ['fetch_prep.py'], 1800),
        ('B2 同行标杆', ['fetch_peers.py'], 1200),
        ('B3 竞店 Top20', ['fetch_competitors.py'], 1200),
        ('B4 子账号客服', ['fetch_staff.py'], 1200),
        ('B5 国家地区入库', ['v4_fetch_region.py'], 1200),
        ('B6 类目热品入榜', ['v2_competitors.py'], 900),
        ('B7 同行入库', ['v4_ingest_peer.py'], 900),
        ('B8 客服入库', ['v4_ingest_staff.py'], 900),
    ]
    for name, script, to in steps:
        if not run([py] + script, WS, name, to):
            return False, name

    # 星等级（快照，按最近完整周的周日）
    try:
        w = json.load(open(os.path.join(WS, 'raw', '_window.json'), encoding='utf-8'))
        end = (w.get('weeks') or [{}])[0].get('week_end') or datetime.date.today().isoformat()
    except Exception:
        end = datetime.date.today().isoformat()
    star_out = os.path.join(WS, 'raw', 'star_rating_%s.json' % end.replace('-', ''))
    star = ['workctl', 'icbu', 'other', 'icbu-starrating-cgs-pc-page-data-open', '--yes',
            '--format', 'json', '--statDate', end, '--terminal', 'chrome', '-o', star_out]
    if os.path.isfile(os.path.join(BIN, 'workctl.cmd')) or os.path.isfile(os.path.join(BIN, 'workctl')):
        ok_star = run(star, WS, 'C1 拉取店铺星等级（%s）' % end, 600)
        if not ok_star:
            # 常见原因：workctl 的命令目录过期 —— 表现是 `workctl icbu --help`
            # 只剩一个 storefront 子命令。刷新一次目录再重试，别把星等级白白漏掉。
            log('\n>>> C1b 刷新 workctl 命令目录后重试')
            run(['workctl', 'cache', 'refresh'], WS, 'C1b 刷新命令目录', 300)
            ok_star = run(star, WS, 'C1 拉取店铺星等级（重试）', 600)
        if not ok_star:
            log('    （星等级仍失败，继续；只影响「管理」页的星等级，不影响其它板块）')
        else:
            if not run([py, 'v4_ingest_star.py'], WS, 'C2 星等级入库', 600):
                log('    （星等级入库失败，继续）')
    else:
        log('\n>>> C1 跳过星等级（本机没探测到 workctl）')

    steps2 = [
        ('C3 竞品全量', ['v4_competitors.py'], 1800),
        ('C4 竞店店铺级', ['stage_f_competitors.py'], 1200),
        ('D1 回填产品主图', [os.path.join(HERE, 'dashboard_product_images.py'), '--workspace', WS], 1800),
        ('D2 数据预处理', ['v4_prep_sections.py'], 1800),
        ('D3 市场趋势证据', ['v6_market_evidence.py'], 1800),
        ('D4 AI 五维评分', ['v4_score.py'], 1800),
        ('E1 月度大盘', ['v6_fetch_monthly.py', '--months', str(months)], 1800),
        ('E2 月度产品全量', ['v6_fetch_products_monthly.py'], 3600),
        ('E3 月度产品入库', ['v6_ingest_products_monthly.py'], 900),
        ('E4 广告花费（周+月）', ['v4_fetch_ads_report.py'], 1200),
        ('F1 产品360画像', ['stage_f_product360.py'], 1800),
        ('F2 Top20 改造方案', ['stage_f_plans20.py'], 1800),
        ('G1 判定合并', ['v4_judge.py'], 1800),
        ('G2 构建看板', ['v4_build.py'], 1200),
    ]
    for name, script, to in steps2:
        if not run([py] + script, WS, name, to):
            return False, name
    return True, ''


# ------------------------------------------------------- 5. 收尾
def _deploy():
    if not os.path.isdir(ENGINE):
        log('!! 缺少 engine/ 目录，包不完整')
        return False
    r = subprocess.run([sys.executable, os.path.join(ENGINE, 'start.py')],
                       cwd=ENGINE, capture_output=True, text=True,
                       encoding='utf-8', errors='replace')
    return r.returncode == 0


def step_finish():
    idx = os.path.join(WS, '经营数据面板.html')
    if not os.path.isfile(idx):
        log('\n[停止] 看板没生成，请把上面的报错发我。')
        return False
    log('\n[5/5] 完成')
    log('    看板位置: %s' % idx)
    log('    导出的经营数据面板.html可直接打开，交付该HTML即可。')
    try:
        os.startfile(idx)  # type: ignore[attr-defined]
        log('    已为你打开。')
    except Exception:
        log('    请手动双击打开上面的 index.html。')
    return True


def main():
    global _logf
    ap = argparse.ArgumentParser(description='国际站经营数据面板 · 生成向导')
    ap.add_argument('--weeks', type=int, default=None, help='同步最近 N 个完整自然周')
    ap.add_argument('--months', type=int, default=None, help='月度历史拉最近 N 个完整月')
    ap.add_argument('--as-of', default=None, help='数据截至日 YYYY-MM-DD')
    ap.add_argument('--store-name', default=None, help='覆盖自动检测到的店铺名')
    ap.add_argument('--user-label', default=None, help='覆盖顶部显示的运营者')
    ap.add_argument('--reuse', action='store_true', help='复用上次的店铺与时间设置，不再提问')
    ap.add_argument('--no-open', action='store_true', help='完成后不自动打开浏览器')
    args = ap.parse_args()

    os.makedirs(LOGS, exist_ok=True)
    lp = os.path.join(LOGS, 'run_%s.log' % time.strftime('%Y%m%d_%H%M%S'))
    _logf = open(lp, 'w', encoding='utf-8')

    log('=' * 62)
    log('国际站经营数据面板 · 生成向导')
    log('=' * 62)
    log('包目录: %s' % HERE)
    log('日志: %s' % lp)

    if not os.path.isdir(ENGINE):
        log('\n[停止] 包不完整：缺少 engine/ 目录。请重新解压完整压缩包。')
        return 1

    if os.environ.get("GOS_DASHBOARD_PASSWORD"):
        raise ValueError("本包导出未加密HTML，请清空本次进程的GOS_DASHBOARD_PASSWORD后再运行")
    ensure_deps()
    if not step_env():
        return 2

    weeks, months, as_of = step_period(args)

    if not _deploy():
        log('\n[停止] 引擎部署失败。')
        return 2

    store = step_store(args, weeks, as_of)
    # [本机补丁 2026-10-27] store_id 留空时不应拦住整个面板：Accio 连接记录里读不到
    # aliId 是常态（切号/子账号），指定了 --store-name 就继续。store_id 只影响「管理」页跳转。
    if not store:
        return 2
    if not store.get('store_id') and not args.store_name:
        log('\n[停止] 没读到店铺 aliId，且未显式指定 --store-name，无法确定店铺身份。')
        return 2
    if False:
        return 2

    json.dump({'weeks': weeks, 'months': months, 'as_of': as_of,
               'store': store.get('name'), 'updated': time.strftime('%Y-%m-%d %H:%M:%S')},
              open(SETTINGS, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    ok, failed = step_pipeline(weeks, months, as_of)
    if not ok:
        log('\n' + '=' * 62)
        log('[中断] 卡在「%s」。' % failed)
        log('常见原因：')
        log('  1) 该数据域在 Accio 里没授权 -> 去 Accio 重新连接/授权后重跑')
        log('  2) 店铺太新、该周期没有数据 -> 换更近的周期重试')
        log('  3) 网络中断 -> 直接重跑，已完成的步骤会自动复用')
        log('完整日志: %s' % lp)
        log('=' * 62)
        return 3

    from dashboard_integrity import apply
    apply(Path(WS))
    from export_html import export_single
    report=export_single(Path(WS)/"dashboard")
    log("单文件HTML："+str(report))

    if args.no_open:
        log('\n看板已生成: %s' % os.path.join(WS, 'dashboard', 'index.html'))
        return 0
    return 0 if step_finish() else 3


if __name__ == '__main__':
    try:
        sys.exit(main())
    finally:
        if _logf:
            _logf.close()


