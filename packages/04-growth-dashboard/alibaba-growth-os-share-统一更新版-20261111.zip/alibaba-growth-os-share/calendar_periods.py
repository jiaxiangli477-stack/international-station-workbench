"""Closed calendar reporting windows in the platform's Asia/Shanghai timezone.

平台自然周 = **周日至周六**（不是周一到周日）。
依据（2026-10-26 实测，youhealth 店）：
1. `data_advisor_shop_product` 传 `statisticsType=week`（不带日期）返回的 downloadUrl 里
   `statDate=2026-10-17`，是**周六**，即该周为 2026-10-11（周日）~ 2026-10-17（周六）。
2. 同一单品「平台周值」= 询盘1 / TM8 / 访客196 / 点击10；
   按 2026-10-11~10-17 逐日相加 = 1 / 8 / 196 / 10（完全一致）；
   按 2026-10-12~10-18 逐日相加 = 1 / 9 / 212 / 12（对不上）。
3. 后台直通车日期选择器「上周」显示 2026-10-18 ~ 2026-10-24；数据概览 x 轴刻度
   07-26~08-01、09-06~09-12 等都从**周日**起。三条证据指向同一个结论。

另外：**产品参谋的周数据比直通车落后**。2026-10-26 时产品接口最新可用周结束于 10-17，
而直通车报表已经能查 10-18~10-24。所以窗口必须以「产品接口返回的 statDate」为锚，
不能让日历自己推算，否则面板里产品和广告会落在不同的周上。
"""
from calendar import monthrange
from datetime import date, datetime, timedelta, timezone

SHANGHAI = timezone(timedelta(hours=8))

SUNDAY = 6      # date.weekday() 里周日=6
SATURDAY = 5    # 周六=5


def kind(start, end):
    """校验是否为平台口径的完整自然周（周日至周六）或完整自然月。"""
    first, last = date.fromisoformat(start), date.fromisoformat(end)
    if first.weekday() == SUNDAY and (last - first).days == 6:
        return 'week'
    if (first.day == 1 and first.year == last.year and first.month == last.month
            and last.day == monthrange(first.year, first.month)[1]):
        return 'month'
    raise ValueError('请选择完整平台自然周（周日至周六）或完整自然月（1日至月末），'
                     '不使用滚动7/30天或未结束期间')


def native_week(stat_date):
    """平台自然周以「结束日（周六）」作 statDate，返回 (start, end)。"""
    end = date.fromisoformat(stat_date)
    if end.weekday() != SATURDAY:
        raise ValueError('平台周 statDate 应为周六，实际是 %s（%s）' % (end, end.strftime('%a')))
    return end - timedelta(days=6), end


def previous_week(today=None):
    """最近一个已经结束的周日至周六（不含本周）。"""
    today = today or datetime.now(SHANGHAI).date()
    offset = (today.weekday() + 1) % 7          # 周日=0，周一=1 … 周六=6
    last = today - timedelta(days=offset + 1)   # 上周六
    return last - timedelta(days=6), last


def window(mode=None, start=None, end=None, today=None, anchor_end=None):
    """mode=week/previous_week/month/previous_month/custom；anchor_end 为平台 statDate。"""
    today = today or datetime.now(SHANGHAI).date()
    if anchor_end:
        first, last = native_week(anchor_end)
        if mode in (None, 'week', 'previous_week', 'month', 'previous_month'):
            return {'start': first.isoformat(), 'end': last.isoformat()}
    if mode in (None, 'week', 'previous_week'):
        first, last = previous_week(today)
    elif mode in ('month', 'previous_month'):
        last = today.replace(day=1) - timedelta(days=1)
        first = last.replace(day=1)
    elif mode == 'custom':
        try:
            first, last = date.fromisoformat(start or ''), date.fromisoformat(end or '')
        except (TypeError, ValueError):
            raise ValueError('请输入有效起止日期') from None
    else:
        raise ValueError('最近7天/本周未完结口径已停用，请选择自然周或自然月')
    kind(first.isoformat(), last.isoformat())
    if last >= today:
        raise ValueError('统计期间尚未结束，请选择完整自然周或自然月')
    return {'start': first.isoformat(), 'end': last.isoformat()}


def chunks(start, end):
    kind(start, end)
    first, last = date.fromisoformat(start), date.fromisoformat(end)
    out = []
    while first <= last:
        stop = min(first + timedelta(days=6), last)
        out.append({'start': first.isoformat(), 'end': stop.isoformat()})
        first = stop + timedelta(days=1)
    return out


def dashboard_windows(as_of, n_weeks=4, anchor_end=None):
    """W1..Wn 都是周日至周六；anchor_end（平台 statDate）优先于日历推算。"""
    if anchor_end:
        _, end = native_week(anchor_end)
    else:
        _, end = previous_week(as_of)
    weeks = []
    for index in range(n_weeks):
        stop = end - timedelta(days=7 * index)
        start = stop - timedelta(days=6)
        weeks.append({'idx': index + 1,
                      'week_start': start.isoformat(),
                      'week_end': stop.isoformat(),
                      'tag': 'w%d_%s-%s' % (index + 1, start.strftime('%Y%m%d'),
                                            stop.strftime('%m%d'))})
    month = window('previous_month', today=as_of)
    first = date.fromisoformat(month['start'])
    last = date.fromisoformat(month['end'])
    return {'as_of': as_of.isoformat(),
            'week_rule': 'sunday_to_saturday',
            'anchor': anchor_end,
            'weeks': weeks,
            'months': [{'key': 'month%d' % last.month,
                        'month_start': month['start'], 'month_end': month['end'],
                        'tag': 'month%d_%s-%s' % (last.month, first.strftime('%Y%m%d'),
                                                  last.strftime('%m%d'))}]}
