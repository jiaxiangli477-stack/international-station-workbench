# -*- coding: utf-8 -*-
"""
setup_env.py — 自动搭桥 + 环境自检

为什么需要它：
  看板的取数全部走 Accio 桌面端暴露的本地接口，而官方 CLI（accio-mcp-cli / workctl）
  原本只能在 Accio 内部跑。在外部终端跑，必须自己补上「node 路径 + CLI 实体路径 + 网关凭据」。
  每台机器这三样东西的位置都不一样，所以这里全部靠探测，不写死任何绝对路径。

做四件事：
  1. 找 node 运行时
  2. 找 accio-mcp.mjs（数据参谋 CLI 实体）
  3. 找 workctl.js（星等级 / 广告 CLI 实体）
  4. 读 ~/.accio 下当前本地网关的凭据（按监听 4097 的进程 pid 匹配，避免拿到旧账号失效的 token）

结果写成 bin/ 下的桥接脚本，供引擎调用；同时打印一份自检报告。
"""
import glob
import json
import os
import re
import shutil
import string
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(HERE, 'bin')
HOME = os.path.expanduser('~')
APPDATA = os.environ.get('APPDATA', '')
LOCALAPPDATA = os.environ.get('LOCALAPPDATA', '')
PORT = '4097'


def _f(p):
    return bool(p) and os.path.isfile(p)


def _d(p):
    return bool(p) and os.path.isdir(p)


# ---------------------------------------------------------------- 1. node
def find_node():
    cands = []
    if os.environ.get('ACCIO_NODE_BIN'):
        cands.append(os.environ['ACCIO_NODE_BIN'])
    w = shutil.which('node')
    if w:
        cands.append(w)
    # Accio 自带 node（最稳的兜底，装了 Accio 就有）
    cands += glob.glob(os.path.join(APPDATA, 'Accio', 'pre-install', '*', 'node', 'node.exe'))
    # 其他常见位置
    cands += glob.glob(os.path.join(HOME, '.workbuddy', 'binaries', 'node', 'versions', '*', 'node.exe'))
    cands += [
        os.path.join(LOCALAPPDATA, 'Programs', 'nodejs', 'node.exe'),
        r'C:\Program Files\nodejs\node.exe',
        r'C:\Program Files (x86)\nodejs\node.exe',
        '/usr/local/bin/node',
        '/usr/bin/node',
    ]
    for c in cands:
        if _f(c):
            return c
    return None


# ------------------------------------------------------- 2. accio-mcp.mjs
def _drive_roots():
    if os.name != 'nt':
        return []
    return [ch + ':\\' for ch in string.ascii_uppercase if os.path.isdir(ch + ':\\')]


def _probe_mcp(base):
    p = os.path.join(base, 'resources', 'accio-mcp-cli', 'accio-mcp.mjs')
    return p if _f(p) else None


def find_mcp_script():
    env = os.environ.get('ACCIO_MCP_SCRIPT')
    if _f(env):
        return env
    # 常见安装根
    for b in [os.path.join(LOCALAPPDATA, 'Programs', 'Accio'),
              os.path.join(APPDATA, 'Accio'),
              r'C:\Program Files\Accio',
              r'C:\Program Files (x86)\Accio']:
        hit = _probe_mcp_in_root(b)
        if hit:
            return hit
    # APPDATA\Accio 下浅层深搜（部分版本把 CLI 放在子目录）
    a = os.path.join(APPDATA, 'Accio')
    if _d(a):
        for depth in range(1, 5):
            g = glob.glob(os.path.join(a, *(['*'] * depth), 'accio-mcp.mjs'))
            if g:
                return g[0]
    # 各盘根往下 1~2 层：<盘>:\<目录>\resources\accio-mcp-cli\accio-mcp.mjs
    for root in _drive_roots():
        try:
            lv1 = [e.path for e in os.scandir(root) if e.is_dir()]
        except Exception:
            continue
        for d in lv1:
            hit = _probe_mcp_in_root(d)
            if hit:
                return hit
        for d in lv1:
            try:
                lv2 = [e.path for e in os.scandir(d) if e.is_dir()]
            except Exception:
                continue
            for d2 in lv2:
                hit = _probe_mcp_in_root(d2)
                if hit:
                    return hit
    return None


def _probe_mcp_in_root(base):
    """在给定的安装根下找 CLI：既支持 <root>/resources/... 也支持 <root>/<一层>/resources/..."""
    hit = _probe_mcp(base)
    if hit:
        return hit
    for depth in range(1, 3):
        for g in glob.glob(os.path.join(base, *(['*'] * depth), 'resources', 'accio-mcp-cli', 'accio-mcp.mjs')):
            return g
    return None


# ---------------------------------------------------------- 3. workctl.js
def find_workctl():
    hits = []
    # pnpm 全局目录层级不固定（global/<版本>/<哈希>/node_modules/...），用递归匹配
    for root in [os.path.join(LOCALAPPDATA, 'pnpm', 'global'),
                 os.path.join(LOCALAPPDATA, 'pnpm')]:
        for name in ('workctl.js', 'workctl.cjs'):
            hits += glob.glob(os.path.join(root, '**', 'node_modules', '@accio-ai', 'cli', 'bin', name),
                              recursive=True)
    for p in [os.path.join(APPDATA, 'npm', 'node_modules', '@accio-ai', 'cli', 'bin', 'workctl.js'),
              os.path.join(HOME, 'AppData', 'Roaming', 'npm', 'node_modules', '@accio-ai', 'cli', 'bin', 'workctl.js'),
              '/usr/local/lib/node_modules/@accio-ai/cli/bin/workctl.js',
              '/usr/local/lib/node_modules/@accio-ai/cli/bin/workctl.cjs']:
        hits.append(p)
    # pnpm store 的链接目录兜底
    for p in glob.glob(os.path.join(LOCALAPPDATA, 'pnpm', 'store', '*', 'links', '@accio-ai', 'cli', '*')):
        for name in ('workctl.js', 'workctl.cjs'):
            c = os.path.join(p, 'bin', name)
            if _f(c):
                hits.append(c)
    hits = [h for h in hits if _f(h)]
    if hits:
        hits.sort(key=os.path.getmtime, reverse=True)
        return hits[0]
    return None


# ------------------------------------------------------- 4. 网关凭据
def listening_pid(port=PORT):
    try:
        out = subprocess.run(['netstat', '-ano'], capture_output=True, text=True,
                             encoding='utf-8', errors='replace', timeout=30,
                             creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)).stdout or ''
    except Exception:
        return None
    for line in out.splitlines():
        if (':%s ' % port) in line and 'LISTENING' in line.upper():
            m = re.split(r'\s+', line.strip())
            if m and m[-1].isdigit():
                return m[-1]
    return None


def _cred_from(path, note):
    """从 gateway-cli.json 读出凭据。account_dir = 该文件所属的 Accio 账号目录。"""
    try:
        d = json.load(open(path, encoding='utf-8'))
    except Exception as e:
        return {'token': '', 'user': '', 'url': '', 'note': '读取失败 %s: %s' % (path, e),
                'file': path, 'account_dir': ''}
    # <账号目录>/.accio/runtime/gateway-cli.json -> <账号目录>
    acct = os.path.dirname(os.path.dirname(os.path.dirname(path)))
    return {'token': (d.get('password') or '').strip(),
            'user': (d.get('username') or 'phoenix').strip(),
            'url': (d.get('url') or 'http://localhost:4097'),
            'note': note, 'file': path, 'account_dir': acct}


def find_credentials():
    """按 pid 匹配当前网关凭据；匹配不到回退最近修改的文件。返回 dict。"""
    files = glob.glob(os.path.join(HOME, '.accio', 'accounts', '*', '.accio', 'runtime', 'gateway-cli.json'))
    if not files:
        return {'token': '', 'user': '', 'url': '', 'file': '', 'account_dir': '',
                'note': '未找到 gateway-cli.json（Accio 可能没登录或没运行）'}
    pid = listening_pid()
    for p in files:
        try:
            d = json.load(open(p, encoding='utf-8'))
        except Exception:
            continue
        if pid and str(d.get('pid')) == str(pid):
            return _cred_from(p, 'pid=%s 匹配监听进程（%s）' % (pid, p))
    p = max(files, key=os.path.getmtime)
    return _cred_from(p, '按 pid 未匹配，回退到最近修改的文件 %s' % p)


# ------------------------------------------------------- 写桥接脚本
def _qw(path):
    with open(path, 'w', encoding='ascii', newline='\r\n') as f:
        yield f


def write_shims(node, mcp, workctl, token, user, url):
    os.makedirs(BIN, exist_ok=True)
    # 凭据
    with open(os.path.join(BIN, '_token.cmd'), 'w', encoding='ascii', newline='\r\n') as f:
        f.write('@echo off\r\n')
        f.write('set "ACCIO_GATEWAY_TOKEN=%s"\r\n' % token)
        f.write('set "ACCIO_GATEWAY_USERNAME=%s"\r\n' % user)
        f.write('set "ACCIO_LOCAL_GATEWAY_URL=%s"\r\n' % url)
    with open(os.path.join(BIN, '_token.sh'), 'w', encoding='ascii', newline='\n') as f:
        f.write('export ACCIO_GATEWAY_TOKEN="%s"\n' % token)
        f.write('export ACCIO_GATEWAY_USERNAME="%s"\n' % user)
        f.write('export ACCIO_LOCAL_GATEWAY_URL="%s"\n' % url)
    # accio-mcp-cli
    with open(os.path.join(BIN, 'accio-mcp-cli.cmd'), 'w', encoding='ascii', newline='\r\n') as f:
        f.write('@echo off\n')
        f.write('setlocal\n')
        f.write('if not defined ACCIO_GATEWAY_TOKEN if exist "%~dp0_token.cmd" call "%~dp0_token.cmd"\n')
        f.write('if not defined ACCIO_GATEWAY_USERNAME set "ACCIO_GATEWAY_USERNAME=phoenix"\n')
        f.write('if not defined ACCIO_NODE_BIN set "ACCIO_NODE_BIN=%s"\n' % node)
        f.write('if not defined ACCIO_MCP_SCRIPT set "ACCIO_MCP_SCRIPT=%s"\n' % mcp)
        f.write('"%s" "%s" %%*\n' % (node, mcp))
    with open(os.path.join(BIN, 'accio-mcp-cli'), 'w', encoding='ascii', newline='\n') as f:
        f.write('#!/bin/sh\n')
        f.write('d="$(cd "$(dirname "$0")" && pwd)"\n')
        f.write('[ -f "$d/_token.sh" ] && . "$d/_token.sh"\n')
        f.write('exec "%s" "%s" "$@"\n' % (node, mcp))
    # workctl
    if workctl:
        with open(os.path.join(BIN, 'workctl.cmd'), 'w', encoding='ascii', newline='\r\n') as f:
            f.write('@echo off\n')
            f.write('setlocal\n')
            f.write('if not defined ACCIO_GATEWAY_TOKEN if exist "%~dp0_token.cmd" call "%~dp0_token.cmd"\n')
            f.write('if not defined ACCIO_GATEWAY_USERNAME set "ACCIO_GATEWAY_USERNAME=phoenix"\n')
            f.write('"%s" "%s" %%*\n' % (node, workctl))
        with open(os.path.join(BIN, 'workctl'), 'w', encoding='ascii', newline='\n') as f:
            f.write('#!/bin/sh\n')
            f.write('d="$(cd "$(dirname "$0")" && pwd)"\n')
            f.write('[ -f "$d/_token.sh" ] && . "$d/_token.sh"\n')
            f.write('exec "%s" "%s" "$@"\n' % (node, workctl))
    for n in ('accio-mcp-cli', 'workctl'):
        p = os.path.join(BIN, n)
        if os.path.exists(p):
            try:
                os.chmod(p, 0o755)
            except Exception:
                pass


# ------------------------------------------------------- 连通性自检
def verify(node, mcp, token, user, url):
    """跑一次最小查询，确认网关真的通。返回 (bool, 说明)。"""
    env = dict(os.environ)
    env['ACCIO_GATEWAY_TOKEN'] = token
    env['ACCIO_GATEWAY_USERNAME'] = user
    env['ACCIO_LOCAL_GATEWAY_URL'] = url
    try:
        r = subprocess.run([node, mcp, 'search', 'data_advisor'],
                           capture_output=True, text=True, encoding='utf-8',
                           errors='replace', timeout=120, env=env,
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except Exception as e:
        return False, '调用 CLI 异常: %s' % e
    out = (r.stdout or '') + (r.stderr or '')
    if 'data_advisor_shop_summary' in out:
        n = out.count('data_advisor_')
        return True, '网关连通，数据参谋工具 %d 个可用' % n
    if '401' in out or 'Unauthorized' in out or 'unauthorized' in out:
        return False, '网关返回 401：凭据过期。请确认 Accio 正在运行且已登录，然后重跑本脚本'
    return False, '未能确认连通。原始输出片段: %s' % out.strip()[:300]


def setup(verbose=True):
    """一键搭桥。返回 dict 结果，字段 ok / 各项路径 / 消息。"""
    res = {'ok': False, 'bin': BIN}
    node = find_node()
    mcp = find_mcp_script()
    wctl = find_workctl()
    cr = find_credentials()
    token, user, url, why = cr['token'], cr['user'], cr['url'], cr['note']

    res.update(node=node, mcp=mcp, workctl=wctl, token=token, cred_note=why,
               account_dir=cr.get('account_dir') or '')

    if verbose:
        print('--- 环境探测 ---')
        print('  node      : %s' % (node or '未找到'))
        print('  accio-mcp : %s' % (mcp or '未找到'))
        print('  workctl   : %s' % (wctl or '未找到（星等级/广告取数会跳过）'))
        print('  网关凭据  : %s' % ('已取到' if token else '未取到'))
        print('               %s' % why)

    missing = []
    if not node:
        missing.append('node 运行时')
    if not mcp:
        missing.append('accio-mcp.mjs')
    if not token:
        missing.append('网关凭据')
    if missing:
        res['msg'] = '缺少: %s' % '、'.join(missing)
        if verbose:
            print('\n[未通过] %s' % res['msg'])
            print('排查：Accio 桌面端是否已安装并正在运行？是否已登录你的 Alibaba 账号？')
            print('若 CLI 装在非标准位置，可用环境变量指定后重跑：')
            print('  ACCIO_MCP_SCRIPT=<路径>   ACCIO_NODE_BIN=<node 路径>')
        return res

    write_shims(node, mcp, wctl, token, user, url)
    ok, msg = verify(node, mcp, token, user, url)
    res['ok'] = ok
    res['msg'] = msg
    if verbose:
        print('\n--- 桥接脚本 ---')
        print('  已写入 %s' % BIN)
        print('\n--- 连通性 ---')
        print('  %s %s' % ('[OK]' if ok else '[未通过]', msg))
    return res


def main():
    print('=== 自动搭桥与环境自检 ===')
    print('包目录: %s' % HERE)
    r = setup()
    return 0 if r['ok'] else 2


if __name__ == '__main__':
    sys.exit(main())
