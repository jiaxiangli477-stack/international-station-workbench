# -*- coding: utf-8 -*-
"""客户「主体档案」—— 公司信息 / 人员 / 规模 / 主营 / 影响力。

一、平台核查结论（PLATFORM_PROBE）：我们把平台侧所有能拿「买家公司」的通道都试了一遍，
   结果如实列出。这条比单个客户更重要 —— 它说明为什么绝大多数客户拿不到工商数据（具体比例每次实测不同，见报告 3-0/3-1 的数字）。
二、可查实主体（COMPANIES）：有公司名/地址/电话/品牌可核的，给出完整档案。
三、可得信息（persona_metrics / main_business / chat_facts / influence_label）：
   平台能真实给到的「人员 / 规模 / 主营 / 采购活跃度」。
四、待补清单与索取话术（ASK）。
"""

import re
from datetime import date as _date

# ---------------------------------------------------------------- 平台核查
PLATFORM_PROBE = [
    ('买家画像', 'tm get-buyer-basic --contact-ali-id <aliId>',
     '通；但只返回 等级 / 国家 / 90 天行为，**无公司名、无邮箱**'),
    ('会话扩展信息', 'tm query-conversation-info --chatTokens <token> --selfAliId <id>',
     '通；拿到销售阶段 / 内部标签 / 备注 / 关系建立时间（多数有值），**仍无公司名**'),
    ('联系人公司字段', 'tm list-contact --chatTokens / --contactEncryptAliIdList',
     '**上游拒绝：no privilege**（该接口声称返回"公司"，本账号无权限）'),
    ('联系人全量', 'tm query-contact --type 0..3 --startVersion 0',
     '通；返回 `[null]` —— 主账号名下无 IM 好友记录'),
    ('平台身份裁决', 'tm bgcheck-judge --anchors ... --bgcheck_result ... --web_evidence ...',
     '通；**实测绝大多数返回「身份信息完全缺失的未验证买家」，ai_identity_type=unverifiable**，'
     '仅注入公司证据的个别账号仍是 UNDETERMINED（该接口不采纳外部证据进身份层）'),
    ('公司验证报告', 'trade supplier-verification-recall --supplier_name <名称>',
     '通；但**只索引阿里供应商**（查得到我们自己：莱华仕 NIT 级档案），查买家返回 `candidates: []`'),
    ('RFQ 详情公司字段', 'rfq rfq-detail-search --rfq-id <id> → companyInfo',
     '通；字段结构齐全（companyName / registeredAddress / website / annualPurchaseAmount），'
     '**但本周唯一一条 RFQ 的 companyName = "NA"（买家未披露）**'),
]

# ---------------------------------------------------------------- 可查实主体
COMPANIES = {
    'javier argoty': dict(
        name='LOGISTRADE GROUP COLOMBIA SAS',
        name_cn='哥伦比亚物流通达集团（简易股份公司）',
        tier='A · 已核实到工商登记',
        facts=[
            ('税号 NIT', '**901.490.725-0**（含校验位）'),
            ('法律形式', 'Sociedad por Acciones Simplificada (SAS) —— 简易股份公司'),
            ('成立时间', '**2021-06-01**（注册于 Cámara de Comercio de Pasto，商业登记号 260000210369）'),
            ('经营状态', 'Active（有效），2025-07-09 完成年检'),
            ('法定代表人', '**ARGOTY MONTENEGRO FRANCISCO JAVIER** —— 与买家名 javier argoty 完全对应，'
                          '确认同一主体'),
            ('注册地址', 'Pasto, Nariño（公司注册地）'),
            ('收件地址', 'Calle 12 No 87 121 Torre 4 Galpón 107, Cali —— 由买家 10-12 主动提供'),
            ('联系电话', '+57 315 0909098（买家 10-12 主动提供）'),
            ('主营', '**CIIU 4631 食品批发**（水果蔬菜、乳制品、蛋类、食用油、糖果烘焙、咖啡茶可可、调料等）'
                    '；兼营 7020 管理咨询、1399 其他纺织品制造'),
            ('出口规模', 'DIAN 出口商名录：**2024 年出口 USD 21,224 / 15,160 kg / 1 票**，'
                        '海关 Buenaventura，收货方 **TRANSOCEAN NORD GMBH（德国）**，HS 1511100000'),
            ('第二渠道', 'B2Brazil 企业页（**Unverified 未认证**）："frozen chicken legs in 20-kilo boxes, '
                        'banana flour, quinoa flour"，自述为**大宗消费品生产商 + 学校供餐项目供应商**，'
                        '主市场 Asia / South America，联系人署名 JAVIER'),
        ],
        size_verdict='**微型贸易商**。年出口额约 2.1 万美元、单一票货、单一海外买家、员工规模未披露。'
                     '2021 年成立的 SAS 在哥伦比亚属最常见的壳/小微结构，注册资本未公开。'
                     '主营是**食品批发**（鸡肉、香蕉粉、藜麦），不是保健品渠道。',
        influence='**本地流通环节的小角色，不是品牌方。** 学校供餐 + 大宗食品批发是他的基本盘；'
                  '保健品只是他试图拓品类。出口仅到德国一家贸易商，说明渠道能力有限。',
        implication='**给样品可以，但必须收样品费 + 对方自清关**（现有方案正确）。'
                    '**不要指望他做品牌定制**：他没有保健品零售渠道，最可能的是转售给本地小零售。'
                    '谈单第一句应该是「你们是否已持有 INVIMA 注册或本地持证进口商」——'
                    '哥伦比亚补剂必须由本地进口商持证注册，周期 6-12 个月；这个问题能立刻分辨他是真渠道还是试水。',
        sources=['哥伦比亚商会/Colfirma 工商档案（NIT 901490725）', 'DIAN 进出口商名录 2024',
                 'ImportGenius 海关记录 2024-10-17', 'B2Brazil 企业页（Unverified）',
                 '买家在 TM 里主动提供的收件地址与电话'],
        confidence='高（工商登记 + 海关记录 + 聊天自述三者互相印证）',
    ),

    'matthew ragnauth': dict(
        name='SALT & IRON（品牌名，未取得注册主体）',
        name_cn='—',
        tier='C · 品牌存在但主体无法核实',
        facts=[
            ('自称主体', '品牌 SALT & IRON，美国；**未提供公司全称、注册州、注册号、EIN**'),
            ('商标核查', '美国 USPTO（经 Justia 商标库）检索 "SALT & IRON"：'
                        '**没有任何第 5 类（膳食补充剂）商标**。同名商标共 2 件，均与他无关 ——'
                        '① Salt and Iron LLC（2016 年申请，**餐饮服务**）；'
                        '② 757 Finds LLC（2023 年申请，**紧身裤/防晒衣/T恤 服装类**）'),
            ('人名核查', '以 "Ragnauth" 检索商标权人：**0 件**。'
                        '公开检索该姓名的公司关联，仅见同名生物科技从业者（Andre Ragnauth，'
                        '纽约 Unifi Biotechnologies 联合创始人），**与本买家无证据关联，不做推断**'),
            ('自述体量', '要求对 **500 / 1,000 / 2,500 桶**成品分别报价（16 条款长函，含 NDA、'
                        '配方归属、变更控制、分包方披露、逐批 COA 等）'),
            ('客观矛盾', '平台 90 天只浏览 **6 个产品**；信中自述与我方存在**已结案纠纷**；'
                        '要求把 200 美元样品费转为**不可过期抵扣**'),
        ],
        size_verdict='**声明体量与实际行为严重不匹配，无法核实规模。** 要 2,500 桶的买家，'
                     '平台 90 天只看 6 个产品，属异常。品牌无商标、无实体、无名下公司。',
        influence='**市场影响力无法证实。** 品牌查无注册、公网查无官网与渠道痕迹。'
                  '值得注意的是信件的专业度（16 条条款、逐批 COA、配方归属、变更控制）**远超一般个体买家**，'
                  '说明对方懂合规流程 —— 这类人要么是专业买手/顾问，要么是在用法律条款把风险全推给我方。',
        implication='**先核验主体，再谈任何商务。** 要他提供：美国公司注册全称 + 注册州 + 注册号 + EIN + 官网。'
                    '在拿到之前：不披露配方、不投入打样、不做价格承诺、不承认 200 美元抵扣。'
                    '全部走 Alibaba Trade Assurance。'
                    '**内部标签「优质商机」建议复核** —— 在主体核验通过前，它不应享有优质商机的资源优先级。',
        sources=['USPTO 商标库（经 Justia 检索，"SALT & IRON" 与 "Ragnauth"）',
                 '平台 90 天行为数据（浏览 6 个产品）', '买家长函原文（TM 2026-10-13）'],
        confidence='中（证伪充分：商标、实体、规模三项均查无；但无法排除其使用未注册商标在线下经营）',
    ),
}

# ---------------------------------------------------------------- 待补清单 + 话术
ASK_COMMON = [
    '公司注册全称 + 注册号（美国 EIN / 欧盟 VAT / 各国营业执照）',
    '官网或品牌页面链接',
    '首单预估数量与目标上架时间',
]

ASK = {
    'Mads Jehg': dict(
        need=['品牌名与官网（他已在澳销售，应有品牌）', '首单实际数量（目前只谈定单价）',
              '公司主体（丹麦 dk 账号 / 澳洲市场，需确认签约主体）'],
        script='Hi Mads — glad the price works for you. To lock the first order I need three things:\n'
               '1) Your brand name and website, so I can match the label artwork and compliance wording.\n'
               '2) The exact quantity for order one (we quoted USD 4.70/unit at 30 sachets per unit).\n'
               '3) The contracting entity — invoice to your Danish company or the Australian one?\n'
               'Once I have these I will send the PI the same day.',
    ),
    'Orland Mata': dict(
        need=['订单号（我方内部即可查到，客户侧无需再要）', '复购计划与年度用量'],
        script='Hi Orland — apologies for the delay; let me give you the concrete answer:\n'
               'Your order is in [production / finishing / dispatch] and ships on [date], tracking [number].\n'
               'While we are at it: are you planning a repeat order this quarter, and do you want to lock the '
               'same formulation? If you share your expected annual volume I can quote you a tiered price.',
    ),
    'Lucas Hoffman': dict(
        need=['品牌名与公司主体', '首单数量', '目标上架市场与时间'],
        script='Hi Lucas — yes, we can add BCAA or EAAs. Concretely:\n'
               '· BCAA 2:1:1 or EAA blend, 3-7 g per serving — both standard for us\n'
               '· Cost impact is roughly USD [x] per unit at MOQ [n]\n'
               '· Formula sample in 7 days, retail sample in 14\n'
               'Two questions so I can quote precisely: what is your first order quantity, and which market '
               'are you launching in? Also, what brand name will this appear under?',
    ),
    'Ariyan Khan': dict(
        need=['**DGDA 进口注册证**或本地持证进口商', '公司名与营业执照', '采购品类与年用量'],
        script='Hi Ariyan — we have actually been connected since January and I noticed you have stayed very '
               'active in sports nutrition. Let me be useful instead of generic.\n'
               'Two questions first:\n'
               '1) Do you already hold a DGDA import registration for dietary supplements? '
               '(Bangladesh Bank now requires DGDA approval before banks will open an LC for supplement '
               'imports, so it changes how we structure order and payment.)\n'
               '2) Which products are you planning to launch in the next 3 months?',
    ),
    'javier argoty': dict(
        need=['INVIMA 注册证或本地持证进口商', '目标品类（保健品 or 继续食品批发）', '试销后的首单量'],
        script='Hola Javier — gracias por los datos de envío, ya los tengo registrados.\n'
               'Para no hacerle perder tiempo con la muestra, dos preguntas:\n'
               '1) ¿Ya cuentan con registro INVIMA o con un importador titular local? '
               '(Los suplementos requieren registro sanitario INVIMA con importador local, y el trámite '
               'toma 6-12 meses.)\n'
               '2) ¿Venderían los suplementos bajo marca propia o los distribuirían a su actual canal '
               'de alimentos institucionales?\n'
               'Con esas dos respuestas le preparo la cotización y las muestras van esta semana.',
    ),
    'matthew ragnauth': dict(
        need=['**美国公司注册全称 + 注册州 + 注册号 + EIN**', '官网/SALT & IRON 品牌页',
              '500 / 1,000 / 2,500 桶对应的**目标上架时间**'],
        script='Matthew — thank you for the detailed message.\n'
               'Before we go further I need to establish the contracting entity, since your letter correctly '
               'asks us to identify ours:\n'
               '1) Please provide the full registered company name, state of registration, registration number '
               'and EIN for SALT & IRON, plus your website.\n'
               '2) Our verified company email and the exact contractor entity will be sent once we are comparing '
               'like for like.\n'
               'On your point 6: the USD 200 credit cannot be accepted as a standing, non-expiring deduction '
               'before the new engagement is agreed in writing; it remains open for discussion.\n'
               'Everything will run through Alibaba Trade Assurance.',
    ),
    '_default': dict(
        need=ASK_COMMON + ['采购品类与首单量', '是否有本地销售渠道/品牌'],
        script='Thanks for reaching out. So I can quote properly instead of guessing, could you share:\n'
               '1) your company name and website,\n'
               '2) the products and quantities you are considering,\n'
               '3) your target market and launch timing?\n'
               'I will come back with a formulation proposal, MOQ and price tiers.',
    ),
}

# ---------------------------------------------------------------- 从平台数据算
def _num(t, label):
    m = re.search(re.escape(label) + r'\s*[:：]\s*([\d,]+)', t or '')
    return int(m.group(1).replace(',', '')) if m else None


def persona_metrics(persona):
    """从 buyer_persona 文本里抠出真实的 90 天行为指标。"""
    t = (persona or {}).get('buyer_persona') or ''
    return {
        'views': _num(t, 'Number of Products Viewed in the Last 90 Days'),
        'logins': _num(t, 'Number of Login Days in the Last 90 Days'),
        'msg_days': _num(t, 'Number of Days Messaging Sellers in the Last 90 Days'),
        'sellers': _num(t, 'Number of Sellers Contacted in the Last 90 Days'),
    }


def top_categories(persona, n=3):
    """按「沟通次数」排序的类目偏好 —— 这就是买家的主营/采购方向。"""
    t = (persona or {}).get('buyer_persona') or ''
    out = []
    for blk in re.findall(r'<category \d+>(.*?)</category \d+>', t, re.S):
        name = re.search(r'Category Name:\s*(.+)', blk)
        click = re.search(r'Click Count[^:]*:\s*(\d+)', blk)
        comm = re.search(r'Communication Count[^:]*:\s*(\d+)', blk)
        if not name:
            continue
        leaf = name.group(1).strip().split('/')[-1].strip()
        out.append((leaf, int(comm.group(1)) if comm else 0, int(click.group(1)) if click else 0))
    out.sort(key=lambda x: (-x[1], -x[2]))
    return out[:n]


def chat_facts(msgs):
    """从聊天原文里抽真实数字与标识（不是推测）。"""
    txt = '\n'.join((m.get('content') or '') for m in (msgs or []))
    f = {}
    qty = re.findall(r'\b(\d[\d,]{0,8})\s*(units?|pcs|pieces|bottles|boxes|box|tubs?|sachets?|sachects?|'
                     r'servings?|kg|tons?|strips?)\b', txt, re.I)
    if qty:
        f['数量'] = '、'.join('%s %s' % (a, b.lower()) for a, b in qty[:4])
    pr = re.findall(r'(?:USD|US\$|\$)\s?(\d+(?:[.,]\d+)?)', txt, re.I)
    if pr:
        f['价格'] = '、'.join('USD ' + x for x in dict.fromkeys(pr))[:60]
    ph = [x.strip() for x in re.findall(r'(?:\+?\d[\d \-()]{7,16}\d)', txt)
          if len(re.sub(r'\D', '', x)) >= 9]
    if ph:
        f['电话'] = '、'.join(list(dict.fromkeys(ph))[:2])
    addr = re.findall(r'([^\n]{0,60}(?:calle|torre|galp[oó]n|street|st\.|no\.\s*\d+|box\s*\d+)[^\n]{0,60})',
                      txt, re.I)
    if addr:
        f['地址'] = addr[0].strip()[:110]
    comp = re.findall(r'(?:a nombre de|on behalf of|name of|we are)\s+([A-Z][\w&.,\'\- ]{2,45})', txt)
    if comp:
        f['公司提及'] = '、'.join(dict.fromkeys([c.strip() for c in comp]))[:80]
    return f


def influence_label(m):
    """采购活跃度 → 一句话结论（数据全部来自平台 90 天行为）。"""
    s = m.get('sellers')
    if s is None:
        return None, '无行为数据'
    if s >= 40:
        lv, txt = '高', '90 天接触 **%d 个供应商** —— 典型「多源比价型」，同时在与多家谈' % s
    elif s >= 20:
        lv, txt = '中高', '90 天接触 %d 个供应商，比价范围较广' % s
    elif s >= 8:
        lv, txt = '中', '90 天接触 %d 个供应商，属正常询盘节奏' % s
    else:
        lv, txt = '低', '90 天仅接触 %d 个供应商，触点集中（更容易做独家）' % s
    return lv, txt


def main_business(persona, msgs):
    """主营/采购方向：优先用「实际点开过的产品类目」（有意图），其次用类目沟通次数。

    注意：类目偏好列表里大量条目是随机浏览（点击 0、沟通 1），直接列出来会误导 ——
    所以只有「沟通次数≥2」或「有实际点击记录」的类目才当成有效偏好，否则如实标注信号弱。
    """
    t = (persona or {}).get('buyer_persona') or ''
    clicked = []
    for x in re.findall(r'Product Category:\s*([^\n]+)', t):
        leaf = x.strip().split('/')[-1].strip()
        if leaf and leaf not in clicked:
            clicked.append(leaf)
    strong = [(n, c) for n, c, _ in top_categories(persona, 6) if c >= 2]
    if clicked:
        extra = '；另有类目沟通 %s' % '、'.join('%s×%d' % (n, c) for n, c in strong[:2]) if strong else ''
        return '**实际点开过**：%s%s' % ('、'.join(clicked[:2]), extra)
    if strong:
        return '；'.join('%s（沟通 %d 次）' % (n, c) for n, c in strong[:2])
    if msgs:
        return '无有效类目信号（平台记录的类目为随机浏览）'
    return '—'


def ask_for(name):
    return ASK.get(name) or ASK['_default']


# ---------------------------------------------------------------- 自动分级
RISK_WORDS = ('pt141', 'pt-141', 'nad+', 'ss31', 'kpv', 'peptid', 'glutationa', 'glutathione',
              '处方', '研究用肽')


def auto_profile(c):
    """对未逐条研判的客户做自动分级（基于平台数据，不假装是精细研判）。

    数据源全部真实：内部 CRM 阶段/标签/备注、聊天原文、消息结构。
    返回与 ANALYSIS 同构的 dict；meddic=None 表示未做精细评估。
    """
    k = c.get('crm') or {}
    note = (k.get('displayName') or '')
    tags = k.get('tags') or []
    stage = k.get('stage') or ''
    ms = c.get('messages') or []
    nb = sum(1 for m in ms if m.get('senderRole') == 'buyer')
    ns = len(ms) - nb
    txt = ' '.join((m.get('content') or '') for m in ms).lower()
    ch = c.get('channel') or 'TM'

    last_buyer = ''
    for m in reversed(ms):
        if m.get('senderRole') == 'buyer':
            last_buyer = (m.get('content') or '').strip()
            break

    if any(w in txt for w in RISK_WORDS):
        grade = 'R'
        intent = '涉管制成分（肽类 / 谷胱甘肽等），不能以膳食补充剂承接'
        action = '书面划界并留存；可给氨基酸 / 肌酸 / 蛋白类替代方案看能否转化'
    elif '优质商机' in tags or '重要客户' in tags or stage == 'ORDER_NEGOTIATION' \
            or any(w in note for w in ('大单', '大货', '样品客户', '已下样品', '已下单')):
        grade = 'A'
        intent = note or last_buyer[:80] or ('阶段已达 %s' % stage if stage else ch + ' 询盘')
        action = ('订单议价阶段的客户被晾着是流程问题：先回复，'
                  '顺势把数量 / 交期 / 付款方式一次谈完' if stage == 'ORDER_NEGOTIATION'
                  else '团队已标注为重点（标签 %s ｜ 备注 %s）—— 按备注里记录的方向推进'
                       % ('、'.join(tags) or '-', note or '-'))
    elif nb >= 2:
        grade = 'B'
        intent = (last_buyer[:80] or note or ch + ' 询盘')
        action = '买家有持续互动：按其最后一条消息的具体问题给出可执行答复，并问首单量'
    else:
        grade = 'C'
        intent = (last_buyer[:80] or note or ch + ' 询盘（无后续互动）')
        action = '低频培育：发一次资质 + 品类清单即可，别投入打样资源'

    return dict(grade=grade,
                intent=note or (last_buyer[:90] if last_buyer else (ch + ' 询盘')),
                risk='',
                action=action,
                bg='',
                meddic=None,
                prob=None,
                talk=None,
                region='',
                tag='、'.join(t for t in tags if t) or '',
                auto=True,
                _stage=stage, _note=note, _channel=ch,
                _nb=nb, _ns=ns)


# ---------------------------------------------------------------- 客户质量分层
# 档位只看四类**真实证据**，权重从高到低：
#   A 聊天记录（上限 12）—— 对话里到底谈了什么：意图类型、具体数量与单价、双向互动、沟通跨度
#   C 背调结论（上限 10）—— 主体实力评级 + 公网核实结论 + 是否已有成交/在途（inquiry_strength）
#   B 客户信息（上限  8）—— 买家身份可识别度：公司/地址/电话/网站、国家与市场、平台等级、90 天采购活跃度
#   D 内部 CRM（上限  3）—— 销售阶段 / 标签 / 备注，**只作辅助**，不能把客户单独抬成优质
# 档位不按总分单切，而是「支柱门槛 + 总分」双条件，防止某一柱灌水抬档。
QUALITY_TIERS = ['优质客户', '潜力客户', '普通客户', '无效 / 风险']
QCAP = {'chat': 12, 'info': 8, 'bg': 10, 'crm': 3}
QPILLAR_LABEL = [('chat', '聊天记录'), ('bg', '背调结论'), ('info', '客户信息'), ('crm', '内部CRM')]

MATURE_MARKETS = ('US', 'GB', 'UK', 'DE', 'FR', 'AU', 'CA', 'NL', 'BE', 'ES', 'IT', 'PL', 'SE', 'CH',
                  'AT', 'DK', 'NO', 'FI', 'IE', 'AE', 'SA', 'KW', 'IL', 'SG', 'JP', 'KR', 'MY',
                  'MX', 'BR', 'CL', 'CO', 'PE', 'AR', 'ZA')

INTENT_GROUPS = [
    ('询价报价', ('price', 'quote', 'quotation', 'how much', 'cost', 'fob', 'exw',
                 '报价', '价格', '单价', '多少钱')),
    ('数量MOQ', ('moq', 'minimum order', 'quantity', 'container', 'pallet', 'carton',
                '数量', '起订', '整柜', '装箱')),
    ('交期物流', ('lead time', 'shipping', 'delivery', 'eta', 'freight', 'air freight', 'sea freight',
                 'dhl', 'fedex', '交期', '发货', '物流', '到货', '海运', '空运')),
    ('样品打样', ('sample', 'samples', 'prototype', 'sample order', '样品', '打样', '寄样')),
    ('付款条款', ('payment', 'deposit', 'invoice', 'trade assurance', 'paypal', 'tt', 't/t',
                'l/c', 'letter of credit', 'pi', '定金', '付款', '信用证', '形式发票')),
    ('OEM贴牌', ('oem', 'odm', 'private label', 'custom', 'customiz', 'logo', 'formula', 'flavor',
                '贴牌', '代工', '定制', '配方', '私标', '口味')),
    ('认证合规', ('coa', 'msds', 'gmp', 'iso', 'certificate', 'specification', 'spec sheet',
                'label', 'ingredient', '认证', '检测', '标签', '规格', '成分')),
]

CO_SUFFIX = re.compile(
    r"\b([A-Z][A-Za-z&\.\'\- ]{2,44}?(?:S\.A\.S|S\.A|SAS|SRL|S\.R\.L|GmbH|LLC|Ltd|Limited|Inc|"
    r"Pty|SDN\s*BHD|B\.V|BV|AB|Oy|SpA|Pte|Corp|Group|Trading|Imports?|Exports?|Distribut\w*))\b")
WEB_RE = re.compile(r"https?://|\bwww\.|(?<![\w@])[a-z0-9\-]{2,}\.(?:com|net|org|io|co|br|mx|de|fr|"
                    r"uk|es|it|nl|au|in|kr|jp|sg|ae|sa|za|cl|pe|ar|cn|vn|th|id|ph)\b", re.I)
TEL_RE = re.compile(r"\+?\d[\d \-()]{7,18}\d")
ADDR_RE = re.compile(r"(?:calle|torre|galp[oó]n|avenida|av\.|carretera|carrera|street|st\.|road|rd\.|"
                     r"floor|suite|box\s*\d+|no\.\s*\d+)", re.I)
DEAL_WORDS = ('已下样品', '已下单', '已经下单', '在途', '首单', '大货', '大单', '成交', '已付款', '定金已付',
              'order placed', 'ordered', 'deposit paid', 'purchase order')


def _kw(txt, kw):
    """短词按词边界匹配，避免 tt / pi / coa 这类缩写误命中。"""
    if len(kw) <= 4:
        return re.search(r'(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(kw), txt) is not None
    return kw in txt


def _span_days(ms):
    """会话跨度（天）—— 反映跟进是长线还是一次性。"""
    ds = sorted(set((m.get('sendTime') or '')[:10] for m in (ms or []) if (m.get('sendTime') or '')[:10]))
    if len(ds) < 2:
        return 1
    try:
        return max(1, (_date.fromisoformat(ds[-1]) - _date.fromisoformat(ds[0])).days + 1)
    except Exception:
        return 1


def identity_signals(msgs):
    """聊天里主动透露的可追溯身份线索：公司名 / 网站 / 电话 / 地址。"""
    raw = '\n'.join((m.get('content') or '') for m in (msgs or []))
    out = []
    if CO_SUFFIX.search(raw):
        out.append('公司名')
    if WEB_RE.search(raw):
        out.append('网站')
    if any(len(re.sub(r'\D', '', x)) >= 9 for x in TEL_RE.findall(raw)):
        out.append('电话')
    if ADDR_RE.search(raw):
        out.append('地址')
    return out


def quality_of(c, persona=None, strength=None):
    """给一个会话打分并给出档位 + 逐条理由（可解释，不黑箱）。

    权重：聊天记录 > 背调结论 > 客户信息 >> 内部 CRM 标签。
    返回 dict(tier, score, pillars{chat,info,bg,crm}, reasons[], risk)
    """
    k = c.get('crm') or {}
    note = (k.get('displayName') or '')
    tags = k.get('tags') or []
    stage = (k.get('stage') or '')
    lvl = (c.get('contactLevel') or '') or ((persona or {}).get('buyer_level') or '')
    ms = c.get('messages') or []
    nb = sum(1 for m in ms if m.get('senderRole') == 'buyer')
    ns = len(ms) - nb
    txt = '\n'.join((m.get('content') or '') for m in ms).lower()
    st = strength or {}

    pm = persona_metrics(persona) if persona is not None else {}
    facts = chat_facts(ms)
    sigs = identity_signals(ms)
    days = _span_days(ms)
    zero = {'chat': 0, 'info': 0, 'bg': 0, 'crm': 0}

    if any(w in txt for w in RISK_WORDS):
        return dict(tier='无效 / 风险', score=0, risk=True, pillars=dict(zero), pcap=dict(QCAP),
                    reasons=['命中风险词：涉管制成分（肽类 / 谷胱甘肽等），不能以膳食补充剂承接'])

    if nb == 0:
        return dict(tier='无效 / 风险', score=0, risk=False, pillars=dict(zero), pcap=dict(QCAP),
                    reasons=['买家全程未发言（只有系统卡片 / 我方单方消息），不构成真实询盘'])

    buckets = {'chat': [], 'info': [], 'bg': [], 'crm': []}

    def hit(b, add, why):
        buckets[b].append((why, add))

    # ---------------- A 聊天记录（权重最高） ----------------
    if nb >= 4:
        hit('chat', 3, '买家发言 %d 条（高频互动）' % nb)
    elif nb >= 2:
        hit('chat', 2, '买家发言 %d 条（有跟进）' % nb)
    else:
        hit('chat', 1, '买家仅发言 1 条')
    if nb >= 2 and ns >= 1:
        hit('chat', 2, '双向沟通（买家 %d 条 / 我方 %d 条）' % (nb, ns))
    ihits = [g[0] for g in INTENT_GROUPS if any(_kw(txt, w) for w in g[1])]
    if ihits:
        hit('chat', min(4, len(ihits)), '聊天谈到%s' % '、'.join(ihits[:5]))
    if facts.get('价格'):
        hit('chat', 2, '谈到具体单价：%s' % facts['价格'][:40])
    if facts.get('数量'):
        hit('chat', 1, '谈到具体数量：%s' % facts['数量'][:40])
    if days >= 14:
        hit('chat', 2, '沟通跨度 %d 天（长线跟进中）' % days)
    elif days >= 3:
        hit('chat', 1, '沟通跨度 %d 天' % days)

    # ---------------- C 背调结论 ----------------
    # 2026-10-16 起优先用 `company_strength` 的实力档（把主体/规模/渠道/采购/硬证据折成分数），
    # 它回答「客户实力怎么样」；没有实力档时才退回旧的 grade（只回答「能不能核实你是谁」）。
    g = ((st.get('strength') or {}).get('level') or st.get('grade') or '')
    _sb = (st.get('strength') or {}).get('score')
    _sbase = ('%s%s' % ((st.get('basis') or '')[:60],
                        ('（实力 %s 分）' % _sb) if _sb is not None else ''))
    if g == '强':
        hit('bg', 7, '实力评级=强：%s' % _sbase)
    elif g == '中-强':
        hit('bg', 6, '实力评级=中-强：%s' % _sbase)
    elif g == '中':
        hit('bg', 4, '实力评级=中：%s' % _sbase)
    elif g == '弱-中':
        hit('bg', 2, '实力评级=弱-中')
    elif g == '弱':
        hit('bg', 1, '实力评级=弱（仅线索级证据）')
    vf = (st.get('verify') or '')
    ev_auto = st.get('evidence')
    if ev_auto is None:
        # 人工研判：verify 是一段人写的结论，用负向词过滤掉「查不到」类话术
        if len(vf) > 10 and not any(w in vf for w in (
                '无公司名可查', '无公司名', '未识别', '无公开', '无可查', '无法核实', '未核验',
                '没有可核验', '无从下手', '未检索到', '查不到')):
            hit('bg', 2, '公网核实已有结论：%s' % vf[:80])
    elif any(e in ('域名已注册', '官网在营', '工商库命中', '行业匹配',
                   '域名未注册', '工商库无命中', '官网停放') for e in ev_auto):
        # 自动核验：只有真正落到公开源上的结论才加分；「待核验」的兜底说明不算结论
        hit('bg', 2, '公网核验有公开源结论：%s' % '、'.join(ev_auto))
    deal_src = '%s %s %s' % (st.get('scale') or '', st.get('rel') or '', txt)
    if any(w in deal_src for w in DEAL_WORDS):
        hit('bg', 3, '背调/聊天抓到成交硬证据（已下单 / 在途 / 大货 / 已付款）')

    # ---------------- B 客户信息 ----------------
    if lvl.endswith('4'):
        hit('info', 3, '平台买家等级 L4（最高）')
    elif lvl.endswith('3'):
        hit('info', 2, '平台买家等级 L3')
    elif lvl.endswith('2'):
        hit('info', 1, '平台买家等级 L2')
    cc = (((persona or {}).get('buyer_country_code') or c.get('contactCountry') or '') or '').upper()
    if cc:
        hit('info', 1, '国家/市场可识别：%s' % cc)
        if cc in MATURE_MARKETS:
            hit('info', 1, '成熟 / 高客单市场')
    if len(sigs) >= 2:
        hit('info', 2, '聊天透露 %s（主体可追溯）' % '、'.join(sigs[:4]))
    elif len(sigs) == 1:
        hit('info', 1, '聊天透露 %s' % sigs[0])
    sl = pm.get('sellers')
    if sl and sl >= 40:
        hit('info', 2, '90 天接触 %d 家供应商（采购极活跃）' % sl)
    elif sl and sl >= 20:
        hit('info', 1, '90 天接触 %d 家供应商' % sl)
    vw, lg = pm.get('views'), pm.get('logins')
    if (vw and vw >= 100) or (lg and lg >= 10):
        hit('info', 1, '90 天平台活跃（浏览 %s / 登录 %s 天）' % (vw or '-', lg or '-'))

    # ---------------- D 内部 CRM（辅助，封顶 3） ----------------
    hot = [t for t in tags if t in ('优质商机', '重要客户')]
    if hot:
        hit('crm', 2, '内部 CRM 标签「%s」' % '、'.join(hot))
    if stage == 'ORDER_NEGOTIATION':
        hit('crm', 2, '内部销售阶段=订单议价')
    elif stage == 'REQUIREMENT':
        hit('crm', 1, '内部销售阶段=需求确认')
    if any(w in note for w in ('已下样品', '已下单', '成交', '大单', '大货', '样品客户')):
        hit('crm', 1, '内部备注显示已成交/大单：%s' % note[:24])

    # ---------------- 汇总 ----------------
    ps = {b: min(QCAP[b], sum(x[1] for x in buckets[b])) for b in QCAP}
    score = sum(ps.values())
    reasons = ['【%s】%s +%d' % (lab, why, add)
               for b, lab in QPILLAR_LABEL for why, add in buckets[b]]
    A, B, C, D = ps['chat'], ps['info'], ps['bg'], ps['crm']

    if (A >= 7 and C >= 4 and B >= 3) or (A >= 9 and B >= 5) or (C >= 8 and (A + B) >= 8):
        tier = '优质客户'
    elif (A >= 4 and (B + C) >= 4 and score >= 9) or score >= 14:
        tier = '潜力客户'
    elif score >= 4:
        tier = '普通客户'
    else:
        tier = '无效 / 风险'

    return dict(tier=tier, score=score, risk=False, pillars=ps, pcap=dict(QCAP),
                reasons=reasons, chat=A, info=B, bg=C, crm=D,
                span_days=days, signals=sigs)
