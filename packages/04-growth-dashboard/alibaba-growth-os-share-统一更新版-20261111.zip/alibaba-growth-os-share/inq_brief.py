# -*- coding: utf-8 -*-
"""结论与行动（决策三问：评估 → 方向 → 动作）。

为什么要单独一个模块：报告原来把「复盘要点」放在最前面，但它只回答了「发生了什么」，
没有回答老板真正会问的三件事 —— **这批客户怎么样（评估）、该往哪打（方向）、这周做什么（动作）**。
这里把三件事算出来并渲染成报告的第一节（`#sr`），取代原先的「复盘要点」。

数据来源全部是 `customer_rows.build_rows()` 产出的买家级行模型 + `deal_blocker.aggregate()`
的卡点聚合，**不重新联网**。所有结论都由可复核的计数得出，规则写在代码里，不黑箱。
"""
import io
import re
from collections import Counter, defaultdict

# ISO 国家码 → 中文名（只列常用，未命中就直接显示码）
CN_NAME = {
    'GB': '英国', 'US': '美国', 'CA': '加拿大', 'AU': '澳大利亚', 'NZ': '新西兰', 'IE': '爱尔兰',
    'DE': '德国', 'FR': '法国', 'ES': '西班牙', 'IT': '意大利', 'NL': '荷兰', 'BE': '比利时',
    'PL': '波兰', 'PT': '葡萄牙', 'SE': '瑞典', 'NO': '挪威', 'DK': '丹麦', 'FI': '芬兰',
    'CH': '瑞士', 'AT': '奥地利', 'CZ': '捷克', 'RO': '罗马尼亚', 'HU': '匈牙利', 'GR': '希腊',
    'RU': '俄罗斯', 'UA': '乌克兰', 'KZ': '哈萨克斯坦', 'TR': '土耳其', 'IL': '以色列',
    'AE': '阿联酋', 'SA': '沙特', 'QA': '卡塔尔', 'KW': '科威特', 'BH': '巴林', 'OM': '阿曼',
    'JO': '约旦', 'LB': '黎巴嫩', 'IQ': '伊拉克', 'IR': '伊朗', 'EG': '埃及', 'MA': '摩洛哥',
    'DZ': '阿尔及利亚', 'TN': '突尼斯', 'NG': '尼日利亚', 'KE': '肯尼亚', 'GH': '加纳',
    'ZA': '南非', 'ET': '埃塞俄比亚', 'TZ': '坦桑尼亚', 'UG': '乌干达', 'CM': '喀麦隆',
    'IN': '印度', 'PK': '巴基斯坦', 'BD': '孟加拉', 'LK': '斯里兰卡', 'NP': '尼泊尔',
    'MY': '马来西亚', 'SG': '新加坡', 'TH': '泰国', 'VN': '越南', 'ID': '印尼', 'PH': '菲律宾',
    'KR': '韩国', 'JP': '日本', 'CN': '中国', 'HK': '中国香港', 'TW': '中国台湾',
    'BR': '巴西', 'MX': '墨西哥', 'CO': '哥伦比亚', 'PE': '秘鲁', 'CL': '智利', 'AR': '阿根廷',
    'EC': '厄瓜多尔', 'VE': '委内瑞拉', 'UY': '乌拉圭', 'PY': '巴拉圭', 'BO': '玻利维亚',
    'CR': '哥斯达黎加', 'PA': '巴拿马', 'GT': '危地马拉', 'DO': '多米尼加',
}

# 产品方向关键词（出现即计一次，用于「买家到底在问什么品类」）
PROD_KW = [
    ('collagen', '胶原蛋白'), ('creatine', '肌酸'), ('whey', '乳清蛋白'),
    ('protein', '蛋白粉'), ('pre workout', '训练前'), ('pre-workout', '训练前'),
    ('electrolyte', '电解质补水'), ('hydrat', '电解质补水'), ('gummy', '软糖'),
    ('gummies', '软糖'), ('sachet', '条袋/条包'), ('stick pack', '条袋/条包'),
    ('coffee', '咖啡'), ('vitamin', '维生素矿物质'), ('fiber', '膳食纤维'),
    ('probiotic', '益生菌'), ('glutathione', '谷胱甘肽'), ('energy', '能量类'),
    ('pouch', '能量袋'), ('liquid', '液体饮'), ('capsule', '胶囊'), ('tablet', '片剂'),
    ('private label', '私标代工'), ('oem', '私标代工'), ('turmeric', '姜黄'), ('mushroom', '菌菇'),
]

try:
    from extract_entities import is_junk_domain as _junk_dom  # noqa: E402
except Exception:
    def _junk_dom(d):
        return (d or '').lower() in ('gmail.com', 'hotmail.com', 'yahoo.com', 'outlook.com')


def _pct(a, b):
    return ('%d%%' % round(100.0 * a / b)) if b else '-'


def _cn(c):
    return CN_NAME.get((c or '').upper(), (c or '未知'))


def _esc(s):
    return (str(s or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))


def _corp_mail(r):
    return any(not _junk_dom(m.split('@')[-1]) for m in (r.get('emails') or []))


def _ctype(r):
    """客户类型：品牌方 / 企业主体 / 个人买家 / 无主体线索。用于「该往哪类客户使劲」。"""
    p = r.get('profile') or {}
    if p.get('fetched') and (p.get('ecommerce') or p.get('socials')):
        return '品牌方 / 电商'
    if _corp_mail(r):
        return '企业主体'
    if r.get('emails'):
        return '个人买家'
    return '无主体线索'


def analyse(rows, bstats):
    """算出评估 / 方向 / 动作三段所需的结构化结果（纯计算，便于单测与复用）。"""
    n = len(rows)
    tc = Counter(r['tier'] for r in rows)
    good = tc.get('优质客户', 0) + tc.get('潜力客户', 0)

    def _cnt(code):
        return sum(1 for r in rows if r.get('blocker') == code)

    n_deal = _cnt('DEAL')
    n_noreply = _cnt('NOT_REPLIED_US')
    n_noquote = _cnt('NO_QUOTE')
    n_silent = _cnt('QUOTED_SILENT')
    n_chit = _cnt('CHITCHAT')
    n_card = _cnt('CARD_ONLY')
    stale = [r for r in rows if isinstance(r.get('blocker_days'), int)
             and r['blocker_days'] >= 5 and r.get('blocker') not in ('CARD_ONLY', 'DEAL')]
    pend = [r for r in rows if r.get('pending') == '是']
    maxwait = max([r.get('wait') for r in rows
                   if isinstance(r.get('wait'), int)] or [0])

    n_mail = sum(1 for r in rows if r.get('emails'))
    n_site = sum(1 for r in rows if (r.get('profile') or {}).get('fetched'))
    n_soc = sum(1 for r in rows if ((r.get('profile') or {}).get('socials')))
    n_gv = sum(1 for r in rows if r.get('gravatar'))

    # ---- 方向：市场 ----
    mk = defaultdict(lambda: {'n': 0, 'good': 0, 'deal': 0})
    for r in rows:
        c = (r.get('country') or 'NA').upper()
        mk[c]['n'] += 1
        if r['tier'] in ('优质客户', '潜力客户'):
            mk[c]['good'] += 1
        if r.get('blocker') == 'DEAL':
            mk[c]['deal'] += 1
    markets = sorted(mk.items(), key=lambda x: (-x[1]['good'], -x[1]['n']))[:8]

    # ---- 方向：品类 ----
    pc = Counter()
    for r in rows:
        t = ' '.join([r.get('biz') or '', r.get('intent') or '', r.get('blocker_ask') or '',
                      r.get('qty') or '', (r.get('profile') or {}).get('title') or '']).lower()
        for kw, lab in PROD_KW:
            if kw in t:
                pc[lab] += 1
    products = pc.most_common(6)

    # ---- 方向：客户类型 ----
    ct = defaultdict(lambda: {'n': 0, 'good': 0})
    for r in rows:
        k = _ctype(r)
        ct[k]['n'] += 1
        if r['tier'] in ('优质客户', '潜力客户'):
            ct[k]['good'] += 1
    ctypes = sorted(ct.items(), key=lambda x: -x[1]['n'])

    # ---- 方向：渠道 ----
    ch = defaultdict(lambda: {'n': 0, 'good': 0, 'msgs': 0})
    for r in rows:
        k = r.get('channel') or '其他'
        ch[k]['n'] += 1
        ch[k]['msgs'] += (r.get('nbuy') or 0)
        if r['tier'] in ('优质客户', '潜力客户'):
            ch[k]['good'] += 1
    channels = sorted(ch.items(), key=lambda x: -x[1]['n'])

    # ---- 方向：人 ----
    ow = defaultdict(lambda: {'n': 0, 'good': 0, 'pend': 0, 'wait': 0})
    for r in rows:
        for o in (r.get('owners') or '').split('/'):
            o = o.strip()
            if not o or o == '-':
                continue
            ow[o]['n'] += 1
            if r['tier'] in ('优质客户', '潜力客户'):
                ow[o]['good'] += 1
            if r.get('pending') == '是':
                ow[o]['pend'] += 1
            if isinstance(r.get('wait'), int):
                ow[o]['wait'] = max(ow[o]['wait'], r['wait'])
    owners = sorted(ow.items(), key=lambda x: -x[1]['n'])

    # ---- 动作建议（规则生成，每条都带数字依据与承接人）----
    def who(sel):
        c = Counter()
        for r in rows:
            if sel(r):
                for o in (r.get('owners') or '').split('/'):
                    o = o.strip()
                    if o and o != '-':
                        c[o] += 1
        return '、'.join('%s(%d)' % (k, v) for k, v in c.most_common(3)) or '—'

    acts = []
    if n_noreply:
        acts.append(dict(
            act='今天回完「我方未回复」的客户', n=n_noreply,
            who=who(lambda r: r.get('blocker') == 'NOT_REPLIED_US'),
            why='买家最后一句还没人回，平均只卡 %.1f 天 —— 这类是唯一「动作即刻见效」的'
                % (sum(r.get('blocker_days') or 0 for r in rows
                       if r.get('blocker') == 'NOT_REPLIED_US') / max(1, n_noreply)),
            exp='当天可回收一批意向，转化最快'))
    if n_noquote:
        acts.append(dict(
            act='给「问了价没报价」的客户补阶梯报价', n=n_noquote,
            who=who(lambda r: r.get('blocker') == 'NO_QUOTE'),
            why='买家已明确问价、我方全文没有出现任何价格数字，属于白白漏掉的环节',
            exp='报价一给，这批直接进入比价池'))
    if stale:
        acts.append(dict(
            act='对卡 ≥5 天的老单重新破冰（发新信息，不是催单）', n=len(stale),
            who='、'.join(sorted({(r.get('owners') or '').split('/')[0].strip()
                                 for r in stale if r.get('owners')})[:3]) or '—',
            why='最长已卡 %d 天，其中 %s' % (
                max(r['blocker_days'] for r in stale),
                '、'.join(sorted({r.get('blocker_label') or '' for r in stale})[:3])),
            exp='救回一批沉单；救不回也能明确关闭，不占精力'))
    good_rows = [r for r in rows if r['tier'] == '优质客户']
    if good_rows:
        acts.append(dict(
            act='优质客户优先推进（这 %d 个是本周的产出主力）' % len(good_rows), n=len(good_rows),
            who=who(lambda r: r['tier'] == '优质客户'),
            why='聊天 + 背调 + 客户信息三支柱都达门槛，投入产出比最高',
            exp='集中资源在能成的单上'))
    brand = [r for r in rows if _ctype(r) == '品牌方 / 电商']
    if brand:
        acts.append(dict(
            act='对「品牌方 / 电商」按品牌叙事开发（私标 + 上新节奏）', n=len(brand),
            who=who(lambda r: _ctype(r) == '品牌方 / 电商'),
            why='有独立站在营/带购物车，可对公谈、可做私标，客单价高于个人买家',
            exp='把低价比价的池子换成品牌客户池'))
    if owners:
        worst = min(owners, key=lambda x: (x[1]['good'] / max(1, x[1]['n']), -x[1]['n']))
        if worst[1]['n'] >= 5 and worst[1]['good'] / max(1, worst[1]['n']) < 0.2:
            acts.append(dict(
                act='给 %s 调整流量或换话术模板' % worst[0], n=worst[1]['n'],
                who=worst[0],
                why='手上 %d 个客户，优质率仅 %s，泛询价占比偏高'
                    % (worst[1]['n'], _pct(worst[1]['good'], worst[1]['n'])),
                exp='同样的人力接更值钱的流量'))
    # ---- 实力评级 / 追击优先级 ----
    sl = [r.get('strength') or {} for r in rows]
    s_lvl = Counter(x.get('level') or '待核验' for x in sl)
    s_verdict = Counter(x.get('verdict') or '待核验' for x in sl)
    chase = sorted([r for r in rows
                    if (r.get('strength') or {}).get('verdict') in ('P0 重点追', 'P1 正常跟')],
                   key=lambda r: -r['strength']['score'])

    return dict(
        s_lvl=s_lvl, s_verdict=s_verdict, chase=chase,
        n=n, tc=tc, good=good, n_deal=n_deal, n_noreply=n_noreply, n_noquote=n_noquote,
        n_silent=n_silent, n_chit=n_chit, n_card=n_card, stale=stale, pend=pend,
        maxwait=maxwait, n_mail=n_mail, n_site=n_site, n_soc=n_soc, n_gv=n_gv,
        markets=markets, products=products, ctypes=ctypes, channels=channels,
        owners=owners, acts=acts, bstats=bstats)


# ---------------------------------------------------------------- 渲染
def build(rows, bstats, meta=None, top_good=None):
    """返回第一节「结论与行动」的 HTML。"""
    a = analyse(rows, bstats)
    n = a['n'] or 1
    H = []

    # ============ ① 评估 ============
    H.append('<h3>① 评估：这批客户什么水平 <span style="font-weight:400;color:#8a98a6;'
             'font-size:12px">全部由可复核计数得出，不是感觉</span></h3>')
    H.append('<div class="kpis">')
    H.append('<div class="kpi" style="border-left:4px solid #2e9e5b"><div class="l">优质 + 潜力</div>'
             '<div class="v">%d<small>/%d</small></div><div class="s">占比 %s</div></div>'
             % (a['good'], a['n'], _pct(a['good'], n)))
    H.append('<div class="kpi" style="border-left:4px solid #a86a11"><div class="l">已成交 / 在途</div>'
             '<div class="v">%d</div><div class="s">有订单证据的</div></div>' % a['n_deal'])
    H.append('<div class="kpi alert"><div class="l">在等我们</div><div class="v">%d</div>'
             '<div class="s">球在买家 %d ｜ 我方未回 %d ｜ 最长等 %d 天</div></div>'
             % (len(a['pend']), len(a['pend']), a['n_noreply'], a['maxwait']))
    H.append('<div class="kpi"><div class="l">背调覆盖</div>'
             '<div class="v">%d<small>/%d</small></div>'
             '<div class="s">有邮箱 %d ｜ 独立站 %d ｜ 社媒 %d</div></div>'
             % (a['n_mail'], a['n'], a['n_mail'], a['n_site'], a['n_soc']))
    H.append('<div class="kpi" style="border-left:4px solid #c0392b"><div class="l">客户实力</div>'
             '<div class="v">%d</div>'
             '<div class="s">强/中-强 %d ｜ 中 %d ｜ 其余证据不足</div></div>'
             % (a['s_lvl'].get('强', 0) + a['s_lvl'].get('中-强', 0),
                a['s_lvl'].get('强', 0) + a['s_lvl'].get('中-强', 0), a['s_lvl'].get('中', 0)))
    H.append('</div>')

    diag = []
    diag.append('结构上 <b>%s</b> 的客户够得上优质/潜力（%d 个），其中 <b>%d 个已有订单证据</b>。'
                % (_pct(a['good'], n), a['good'], a['n_deal']))
    if a['n_noreply']:
        diag.append('最大的短板是<b class="warn">响应</b>：%d 个客户在等我们回，'
                    '最长等了 %d 天 —— 这不是客户问题，是流程问题。' % (a['n_noreply'], a['maxwait']))
    if a['n_noquote']:
        diag.append('其次是<b class="warn">报价环节漏了</b>：%d 个客户明确问了价，'
                    '我方全文没有出现任何价格数字。' % a['n_noquote'])
    if a['n_card'] + a['n_chit'] > n * 0.4:
        diag.append('另有 <b>%d 个只发过卡片/招呼、%d 个聊了几轮没谈过生意</b> —— '
                    '这部分是泛流量，别投打样资源，用模板批量洗。'
                    % (a['n_card'], a['n_chit']))
    diag.append('背调只覆盖 <b>%s</b>（能拿到邮箱/独立站的），其余在公开渠道只有一个昵称；'
                '有独立站的 %d 个可以直接按公司对公谈。' % (_pct(a['n_mail'], n), a['n_site']))
    diag.append('<b>该追谁</b>：实力+意向都够的是 <b class="ok">P0/P1 共 %d 个</b>'
                '（P0 重点追 %d、P1 正常跟 %d）；%d 个实力弱但有需求，走小额快周转；'
                '其余 %d 个公开渠道查不到主体，谈单前必须先索取注册号/官网。'
                % (len(a['chase']),
                   a['s_verdict'].get('P0 重点追', 0), a['s_verdict'].get('P1 正常跟', 0),
                   a['s_verdict'].get('P2 小额快周转', 0),
                   a['s_verdict'].get('P4 先索取主体', 0)))
    H.append('<div class="reg"><b>一句话诊断：</b>%s</div>' % ' '.join(diag))

    # ============ ② 方向分析 ============
    H.append('<h3>② 方向分析：往哪打 <span style="font-weight:400;color:#8a98a6;font-size:12px">'
             '市场 / 品类 / 客户类型 / 渠道 / 人 —— 每组都有结论</span></h3>')
    H.append('<div class="dash c2">')

    # 市场
    H.append('<div class="panel"><div class="pt">市场方向（按优质+潜力排序）</div>')
    H.append('<table style="margin-top:2px"><tbody>')
    for c, v in a['markets'][:6]:
        H.append('<tr><td style="width:88px"><b>%s</b><div class="mono">%s</div></td>'
                 '<td class="mono">%d 个买家</td><td class="mc">优质+潜力 %d（%s）</td></tr>'
                 % (_esc(_cn(c)), _esc(c), v['n'], v['good'], _pct(v['good'], v['n'])))
    H.append('</tbody></table>')
    _top3 = '、'.join(_cn(c) for c, _ in a['markets'][:3])
    H.append('<div class="ps">结论：<b>主攻 %s</b>。这几个市场既有量、优质率也高，'
             '优先配产能与报价权限。</div></div>' % _esc(_top3))
    # 品类
    H.append('<div class="panel"><div class="pt">品类方向（买家在问什么）</div>')
    if a['products']:
        H.append('<table style="margin-top:2px"><tbody>')
        for lab, cnt in a['products'][:6]:
            H.append('<tr><td><b>%s</b></td><td class="mono">%d 个买家提到</td></tr>'
                     % (_esc(lab), cnt))
        H.append('</tbody></table>')
        H.append('<div class="ps">结论：<b>%s</b> 是这批询盘的主需求。'
                 '主推品与报价单按这个顺序排，别把精力花在没人问的品类上。</div>'
                 % _esc('、'.join(l for l, _ in a['products'][:3])))
    else:
        H.append('<div class="ps">聊天里没抓到明确的品类意向 —— 这批客户以泛询价为主。</div>')
    H.append('</div>')
    H.append('</div>')

    H.append('<div class="dash c2">')
    # 客户类型
    H.append('<div class="panel"><div class="pt">客户类型方向（值不值得投资源）</div>')
    H.append('<table style="margin-top:2px"><tbody>')
    for k, v in a['ctypes']:
        H.append('<tr><td><b>%s</b></td><td class="mono">%d 个</td>'
                 '<td class="mc">优质+潜力 %d（%s）</td></tr>'
                 % (_esc(k), v['n'], v['good'], _pct(v['good'], v['n'])))
    H.append('</tbody></table>')
    H.append('<div class="ps">结论：「品牌方 / 电商」和「企业主体」值得对公谈、能做私标；'
             '「个人买家」走小额快周转 + Trade Assurance；「无主体线索」先索取主体再谈。</div></div>')
    # 渠道 + 人
    H.append('<div class="panel"><div class="pt">渠道方向（哪种询盘更值钱）</div>')
    H.append('<table style="margin-top:2px"><tbody>')
    for k, v in a['channels']:
        H.append('<tr><td><b>%s</b></td><td class="mono">%d 个</td>'
                 '<td class="mc">优质+潜力 %d（%s）</td>'
                 '<td class="mono">人均买家发言 %.1f 条</td></tr>'
                 % (_esc(k), v['n'], v['good'], _pct(v['good'], v['n']),
                    v['msgs'] / max(1, v['n'])))
    H.append('</tbody></table>')
    if len(a['channels']) >= 2:
        _r = [(k, v['good'] / max(1, v['n'])) for k, v in a['channels']]
        _best = max(_r, key=lambda x: x[1])
        _worst = min(_r, key=lambda x: x[1])
        if _best[1] - _worst[1] < 0.05:
            H.append('<div class="ps">结论：两个渠道的优质率<b>基本相当</b>（%s vs %s，差 %.0f 个点，'
                     '不构成方向性差异）。差别在沟通深度：人均买家发言 %s 条 vs %s 条 —— '
                     'TM 有更多追问机会，询盘要主动把话接下去。</div></div>'
                     % (_pct(int(_best[1] * 100), 100), _pct(int(_worst[1] * 100), 100),
                        abs(_best[1] - _worst[1]) * 100,
                        '%.1f' % (a['channels'][0][1]['msgs'] / max(1, a['channels'][0][1]['n'])),
                        '%.1f' % (a['channels'][-1][1]['msgs'] / max(1, a['channels'][-1][1]['n']))))
        else:
            H.append('<div class="ps">结论：<b>%s</b> 的优质率高 %.0f 个点，值得给更高优先级。'
                     '</div></div>' % (_esc(_best[0]), (_best[1] - _worst[1]) * 100))
    else:
        H.append('</div>')
    H.append('</div>')

    # 人
    H.append('<h3>人的方向 <span style="font-weight:400;color:#8a98a6;font-size:12px">'
             '同样流量为什么产出不同，看优质率而不是看客户数</span></h3>')
    H.append('<table><thead><tr><th>接待账号</th><th>客户数</th><th>优质+潜力</th><th>优质率</th>'
             '<th>待回复</th><th>最长等待</th><th>判断</th></tr></thead><tbody>')
    for o, v in a['owners']:
        rate = v['good'] / max(1, v['n'])
        if v['n'] < 5:
            note = '样本太少，先观察'
        elif rate >= 0.75:
            note = '<span class="ok">优质流量集中，可加量</span>'
        elif rate >= 0.6:
            note = '正常'
        else:
            note = '<span class="warn">泛询价偏多，建议调流量或换话术</span>'
        H.append('<tr><td><b>%s</b></td><td class="mono">%d</td><td class="mono">%d</td>'
                 '<td class="mc"><b>%s</b></td><td class="mono">%d</td><td class="mono">%d 天</td>'
                 '<td>%s</td></tr>'
                 % (_esc(o), v['n'], v['good'], _pct(v['good'], v['n']),
                    v['pend'], v['wait'], note))
    H.append('</tbody></table>')

    # ============ 追击名单（实力 × 意向）============
    H.append('<h3>追击名单 <span style="font-weight:400;color:#8a98a6;font-size:12px">'
             'P0/P1 = 实力和意向至少占一样，按实力分排序 —— 这批就是「去追的人」</span></h3>')
    if a['chase']:
        H.append('<table><thead><tr><th>#</th><th>客户</th><th>实力</th><th>该不该追</th>'
                 '<th>凭什么</th></tr></thead><tbody>')
        for i, r in enumerate(a['chase'][:12], 1):
            _st = r.get('strength') or {}
            H.append('<tr><td class="mc"><b>%d</b></td><td><b>%s</b></td>'
                     '<td><b>%s 分</b><div class="mono">%s</div></td>'
                     '<td><b>%s</b><div class="mini">%s</div></td>'
                     '<td>%s</td></tr>'
                     % (i, _esc(r['name']), _esc(_st.get('score', 0)), _esc(_st.get('level') or ''),
                        _esc(_st.get('verdict') or ''), _esc(_st.get('verdict_desc') or ''),
                        _esc('；'.join((_st.get('why') or [])[:2]) or DASH)))
        H.append('</tbody></table>')
        if len(a['chase']) > 12:
            H.append('<div class="ps">只列前 12 个，其余 %d 个见「背调结论汇总」（按实力分同序）。</div>'
                     % (len(a['chase']) - 12))
    else:
        H.append('<div class="ps">本批没有实力+意向都达标的客户 —— '
                 '这本身就是结论：先补主体核验和报价，再谈「追谁」。</div>')

    # ============ ③ 动作建议 ============
    H.append('<h3>③ 动作建议：这周做什么 <span style="font-weight:400;color:#8a98a6;font-size:12px">'
             '按「见效速度」排序，每条都带依据与承接人</span></h3>')
    H.append('<table><thead><tr><th style="width:30px">#</th><th>动作</th>'
             '<th>对象 / 数量</th><th>建议承接</th><th>为什么先做这个</th></tr></thead><tbody>')
    for i, x in enumerate(a['acts'], 1):
        H.append('<tr><td class="mc"><b>%d</b></td><td><b>%s</b></td>'
                 '<td class="mono">%d 个</td><td>%s</td><td>%s<div class="mini">预期：%s</div></td></tr>'
                 % (i, _esc(x['act']), x['n'], _esc(x['who']), _esc(x['why']), _esc(x['exp'])))
    H.append('</tbody></table>')
    H.append('<div class="ps">以上动作全部由数据触发（谁触发、触发多少人写在「对象/数量」里）；'
             '执行明细见「一、优先行动」与「十二、成交卡点诊断」，逐条话术可直接复制。</div>')
    return ''.join(H)
