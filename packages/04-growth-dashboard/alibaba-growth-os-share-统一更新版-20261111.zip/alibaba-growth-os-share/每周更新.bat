@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONDONTWRITEBYTECODE=1
python -B make_dashboard.py --reuse --weeks 4 --months 6
if errorlevel 1 echo 生成失败，请查看logs并脱敏反馈。
pause
