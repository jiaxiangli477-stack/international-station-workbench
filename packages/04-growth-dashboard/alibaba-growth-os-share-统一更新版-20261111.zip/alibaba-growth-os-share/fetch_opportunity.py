# -*- coding: utf-8 -*-
r"""查「我的类目」的征品场景与商机品（数据参谋 · 商机发现 / 商品选品）。

  product data-advisor-opportunity-discovery  → 征品场景（细分市场）：
      needsIndex 需求指数 / supplyIndex 供给指数 / busProdRate 商机品占比
  product data-advisor-product-selection      → 热门商品（abCntIndex 逐日商机人数，
      30 天累计即「商机人数」，按它降序 = 商机品榜；本接口固定返回 10 条）

对照：与我店在售品（products 表）按词重合匹配，标出「已有 / 部分 / 未覆盖」——未覆盖 = 上新方向。

用法：
    python fetch_opportunity.py [--cate-id 202029902] [--cycle 30d] [--stat 30d]
产物：opportunity\商机品_<cateId>_<日期>.csv + opportunity_<cateId>_<日期>.json
"""
import argparse
import csv
import io
import json
import os
import re
import subprocess
import sys
from datetime import date

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'opportunity')
STOP = set('''with for and of the a an to in on by free best hot new oem odm custom private label
powder capsule capsules softgel gummies tablet tablets strips sachet sachets stick sticks pack
mg serving servings flavor unflavored men women adult kids supplier manufacturer factory price'''.split())


def env():
    e = dict(os.environ)
    e['PATH'] = os.path.join(HERE, 'bin') + os.pathsep + e.get('PATH', '')
    return e


def call(args, timeout=300):
    r = subprocess.run(args, capture_output=True, text=True, encoding='utf-8',
                       errors='replace', shell=True, timeout=timeout, env=env(), cwd=HERE)
    o = (r.stdout or '')
    i = o.find('{')
    if i < 0:
        return None
    try:
        return json.loads(o[i:])
    except Exception:
        return None


def series_sum(rec, key):
    """累计 *Index 日值数组（如 abCntIndex 30 天合计）。"""
    arr = rec.get(key)
    if not isinstance(arr, list):
        return None
    tot = 0
    for it in arr:
        try:
            tot += int(float(it.get('tagValue', it.get('value', 0))))
        except Exception:
            pass
    return tot or None


def flatten(rec):
    """标量字段保留；*Index 日值数组 → 30 天累计；*DayValue 丢弃。"""
    out = {}
    for k, v in rec.items():
        if k.endswith('DayValue'):
            continue
        if k.endswith('Index') and isinstance(v, list):
            out[k + '30'] = series_sum(rec, k)
            continue
        if k.endswith('Qoq') and isinstance(v, (str, int, float)):
            try:
                out[k] = '%+.1f%%' % (float(v) * 100)
            except Exception:
                pass
            continue
        if isinstance(v, (str, int, float)) and v != '':
            out[k] = v
    return out


def my_products(db):
    import sqlite3
    if not db or not os.path.isfile(db):
        return []
    c = sqlite3.connect(db)
    try:
        return [r[0] for r in c.execute('select title from products')]
    finally:
        c.close()


def tokens(s):
    return set(w for w in re.split(r'[^a-z0-9]+', (s or '').lower()) if len(w) > 2 and w not in STOP)


def coverage(title, mine_tok):
    t = tokens(title)
    best, bs = None, 0.0
    for m, mm in mine_tok.items():
        inter = len(t & mm)
        if inter:
            sc = inter / float(len(t | mm) or 1)
            if sc > bs:
                bs, best = sc, m
    return bs, best or ''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cate-id', type=int, default=202029902)
    ap.add_argument('--cycle', default='30d', choices=['30d', '90d'])
    ap.add_argument('--stat', default='30d', choices=['1d', '7d', '30d'])
    ap.add_argument('--top', type=int, default=20)
    ap.add_argument('--db', default=r'D:\work\boards\lifeworthcn\engine\workspace\database\alibaba_growth.db')
    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)

    # ---- 1) 征品场景 ----
    print('== 征品场景（类目 %d · %s · 按供需比降序）==' % (a.cate_id, a.cycle))
    d = call(['workctl', 'icbu', 'product', 'data-advisor-opportunity-discovery', '--format', 'json',
              '--cateId', str(a.cate_id), '--statCycle', a.cycle, '--terminalType', 'TOTAL',
              '--pageSize', '10', '--currentPage', '1', '--compact-output', 'off'])
    scenes = []
    if d and isinstance(d.get('data'), list):
        scenes = [flatten(x) for x in d['data']]

    def _ratio(x):
        try:
            return float(x.get('needsIndex') or 0) / max(float(x.get('supplyIndex') or 0), 0.001)
        except Exception:
            return 0
    # 该接口返回的是「场景 × 逐日」趋势行，同一 sceneId 多行 —— 按场景去重取需求最高的一天
    _bys = {}
    for x in scenes:
        sid = x.get('sceneId') or '-'
        if sid not in _bys or float(x.get('needsIndex') or 0) > float(_bys[sid].get('needsIndex') or 0):
            _bys[sid] = x
    scenes = list(_bys.values())
    scenes.sort(key=lambda x: -_ratio(x))
    for x in scenes[:10]:
        try:
            ni, si = float(x.get('needsIndex') or 0), float(x.get('supplyIndex') or 0)
            r = ni / max(si, 0.001)
        except Exception:
            ni = si = r = 0
        try:
            bp = float(x.get('busProdRate') or 0) * 100
        except Exception:
            bp = 0
        print('  [%s] 需求 %7.1f (环比%s)  供给 %7.1f (环比%s)  供需比 %5.2f  商机品占比 %5.2f%% (环比%s)'
              '  商家 %s  热搜词: %s' % ((x.get('sceneNameCn') or x.get('sceneName') or '-')[:16],
              ni, x.get('needsIndexQoq') or '-', si, x.get('supplyIndexQoq') or '-', r, bp,
              x.get('busProdRateQoq') or '-', x.get('shopCnt'), (x.get('top3HotKw') or '-')))

    # ---- 2) 商机品商品榜 ----
    print()
    print('== 商机品商品榜（%s · 按商机人数[30天累计]降序）==' % a.stat)
    d2 = call(['workctl', 'icbu', 'product', 'data-advisor-product-selection', '--format', 'json',
               '--cateId', str(a.cate_id), '--statisticsType', a.stat,
               '--orderBy', 'ab_cnt', '--order', 'desc'])
    rows = []
    if d2 and isinstance(d2.get('data'), list):
        rows = [flatten(x) for x in d2['data']]
        for x in rows:
            if not x.get('prodName') and x.get('detailUrl'):
                m = re.search(r'/product-detail/([^/]+?)_', x['detailUrl'])
                if m:
                    x['prodName'] = m.group(1).replace('-', ' ')
    rows.sort(key=lambda x: -(x.get('abCntIndex30') or 0))
    for x in rows[:a.top]:
        print('  商机%3s 单%3s 价格 %-12s MOQ %-6s [%s] %s' % (
            x.get('abCntIndex30') or '-', x.get('prepayOrdCntIndex30') or '-',
            (x.get('price') or '-')[:12], (x.get('minOrdQty') or '-'),
            (x.get('prodType') or '-')[:8], (x.get('prodName') or '')[:62]))

    # ---- 3) 与我在售对照 ----
    mine = my_products(a.db)
    mine_tok = {t: tokens(t) for t in mine}
    print()
    print('== 与我店在售对照（%d 个在售品）==' % len(mine))
    for x in rows[:a.top]:
        sc, hit = coverage(x.get('prodName') or '', mine_tok)
        x['_cover'] = round(sc, 2)
        x['_mine'] = hit[:52]
        x['_mark'] = '已有' if sc >= 0.30 else ('部分' if sc >= 0.12 else '未覆盖')
        print('  [%s] %.2f  %-50s ~ %s' % (x['_mark'], sc, (x.get('prodName') or '')[:50], hit[:46]))

    # ---- 4) 落盘 ----
    today = date.today().strftime('%Y%m%d')
    out_csv = os.path.join(OUT, '商机品_%d_%s.csv' % (a.cate_id, today))
    with open(out_csv, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['类目', a.cate_id, '商品口径', a.stat, '生成', today])
        w.writerow([])
        w.writerow(['【征品场景】sceneId', '热搜词', '需求指数', '供给指数', '供需比', '商机品占比', '商家数', '已选'])
        for x in scenes:
            w.writerow([x.get('sceneId') or '', x.get('top3HotKw') or '', x.get('needsIndex') or '',
                        x.get('supplyIndex') or '', x.get('supplyNeedsRate') or '', x.get('busProdRate') or '',
                        x.get('shopCnt') or '', x.get('selected') or ''])
        w.writerow([])
        w.writerow(['【商机品商品榜】商机人数(30d)', '下单意向(30d)', '价格', 'MOQ', '产品名',
                    '类型', '对照我的在售', '重合度', '最接近的我方产品', '商品链接'])
        for x in rows[:a.top]:
            w.writerow([x.get('abCntIndex30') or '', x.get('prepayOrdCntIndex30') or '',
                        x.get('price') or '', x.get('minOrdQty') or '', x.get('prodName') or '',
                        x.get('prodType') or '', x.get('_mark') or '', x.get('_cover') or '',
                        x.get('_mine') or '', x.get('detailUrl') or ''])
    with open(os.path.join(OUT, 'opportunity_%d_%s.json' % (a.cate_id, today)), 'w', encoding='utf-8') as f:
        json.dump({'scenes': scenes, 'products': rows}, f, ensure_ascii=False, indent=1)
    print()
    print('已保存: %s' % out_csv)


if __name__ == '__main__':
    main()
