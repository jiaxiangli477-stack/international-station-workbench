# -*- coding: utf-8 -*-
"""抓取最近 N 天「询盘 + TM」全部会话与聊天记录（官方 chat-analysis 管道）。

为什么要用官方管道：`tm list-active-conversation-msg` 只返回「窗口内有消息的活跃会话」且只取一页，
实测 7 天只拿到 22 个会话 / 85 条消息，而官方管道同一窗口拿到 **211 个会话 / 2137 条消息**。
官方管道会遍历全部子账号（本店 12 个）并每账号分页（默认最多 75 页）。

用法：
    python fetch_inquiries.py --days 7
    python fetch_inquiries.py --days 7 --buyer-limit 60      # 顺带抓前 60 个买家的平台画像
    python fetch_inquiries.py --days 7 --no-buyers           # 跳过画像（最快）

产物（inquiry/）：
    conversations.json   规范化后的会话 + 消息（报告生成器读这个）
    messages.txt         全部消息的纯文本（便于人工翻阅）
    fetch_stats.json     抓取统计（账号数/会话数/消息数/询盘 vs TM 拆分）
    buyers.json          买家平台画像（限制条数时只覆盖前 N 个）
    resolvedId/account_identity.json   账号身份文件（含全部子账号 aliId）
"""
import argparse
import io
import json
import os
import subprocess
import sys
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

HERE = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(HERE, 'bin')
OUT = os.path.join(HERE, 'inquiry')
WORK = os.path.join(OUT, '.work')

INQUIRY_HINTS = ('inquiry card', 'inquiry id is', '询盘卡')


def env():
    e = dict(os.environ)
    paths = [BIN]
    # 独立安装时允许借用兄弟目录的分发包桥接
    sib = os.path.join(os.path.dirname(HERE), 'alibaba-growth-os-share', 'bin')
    if os.path.isdir(sib):
        paths.append(sib)
    e['PATH'] = os.pathsep.join(paths) + os.pathsep + e.get('PATH', '')
    return e


def run(args, timeout=1800):
    r = subprocess.run(args, capture_output=True, text=True, encoding='utf-8',
                       errors='replace', shell=True, timeout=timeout, env=env(), cwd=HERE)
    return r.returncode, ((r.stdout or '') + (r.stderr or ''))


def jload(path):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def jparse(out):
    i = out.find('{')
    if i < 0:
        return None
    try:
        return json.loads(out[i:])
    except Exception:
        return None


def account_ids(force=False):
    """取全部账号 aliId（含子账号）—— 聊天数据是按账号隔离的，必须逐个抓。"""
    p = os.path.join(OUT, 'resolvedId', 'account_identity.json')
    if force or not os.path.isfile(p):
        os.makedirs(os.path.dirname(p), exist_ok=True)
        rc, out = run(['workctl', 'workflow', 'chat-analysis', 'resolve-id',
                       '--output-file', p, '--format', 'json'], timeout=600)
        if rc != 0 or not os.path.isfile(p):
            print('[!] resolve-id 失败：%s' % out.strip()[:200])
            return None, None
    d = jload(p) or {}
    ids = [str(d.get('CURRENT_SELF_ALIID'))] + [str(m.get('aliId')) for m in (d.get('otherMembers') or [])]
    ids = [x for x in ids if x and x != 'None']
    return ids, d


def main():
    ap = argparse.ArgumentParser(description='抓取最近 N 天询盘 + TM 会话与聊天记录')
    ap.add_argument('--days', type=int, default=7, help='回溯天数（官方管道窗口建议 ≤ 7 天）')
    ap.add_argument('--end-date', default=None, help='结束日期 YYYY-MM-DD，默认今天')
    ap.add_argument('--buyer-limit', type=int, default=60, help='抓平台画像的买家数量上限（按消息量排序）')
    ap.add_argument('--no-buyers', action='store_true', help='跳过买家画像抓取')
    ap.add_argument('--refresh-identity', action='store_true', help='强制重取账号身份文件')
    args = ap.parse_args()

    os.makedirs(WORK, exist_ok=True)
    os.makedirs(OUT, exist_ok=True)

    today = time.strftime('%Y-%m-%d')
    end = args.end_date or today
    start = time.strftime('%Y-%m-%d', time.localtime(time.time() - args.days * 86400))

    ids, ident = account_ids(args.refresh_identity)
    if not ids:
        print('[停止] 拿不到账号列表（先跑 setup_env.py 搭桥）')
        return 2
    print('窗口 %s ~ %s ｜ 账号 %d 个' % (start, end, len(ids)))

    # ---------- 1) 全部会话 ----------
    print('\n[1/4] 拉取全部会话（每账号分页）…')
    rc, out = run(['workctl', 'workflow', 'chat-analysis', 'fetch-conversations',
                   '--account-ids', ','.join(ids), '--start-date', start, '--end-date', end,
                   '--output-dir', WORK, '--format', 'json'], timeout=2400)
    d = jparse(out)
    conv_file = (d or {}).get('output_file') or os.path.join(WORK, 'conversations_all.json')
    if not os.path.isfile(conv_file):
        print('[停止] 会话拉取失败：%s' % out.strip()[:300])
        return 3
    print('    会话 %s 个（账号 %s 个，失败账号 %s）' % (
        (d or {}).get('totalConversations'), (d or {}).get('totalAccounts'),
        (d or {}).get('totalFailedAccounts')))

    # ---------- 2) 全部消息 ----------
    print('\n[2/4] 拉取全部消息…')
    rc, out = run(['workctl', 'workflow', 'chat-analysis', 'fetch-messages',
                   '--input-file', conv_file, '--all-pending', '--output-dir', WORK,
                   '--format', 'json'], timeout=3600)
    d2 = jparse(out)
    msg_file = (d2 or {}).get('output_file') or os.path.join(WORK, 'messages_all.json')
    if not os.path.isfile(msg_file):
        print('[停止] 消息拉取失败：%s' % out.strip()[:300])
        return 4
    print('    消息 %s 条（含消息会话 %s 个）' % ((d2 or {}).get('totalMessages'),
                                            (d2 or {}).get('totalConversationsWithMessages')))

    # ---------- 3) 规范化 ----------
    print('\n[3/4] 规范化…')
    convs = (jload(conv_file) or {}).get('conversations') or []
    msgs = {c.get('conversationId'): (c.get('messages') or [])
            for c in ((jload(msg_file) or {}).get('conversations') or [])}

    def _tags(x):
        t = x.get('tags')
        if isinstance(t, list):
            return t
        if isinstance(t, str):
            try:
                return json.loads(t) if t.strip().startswith('[') else ([t] if t else [])
            except Exception:
                return [t] if t else []
        return []

    norm = []
    n_inq = 0
    for c in convs:
        ms = msgs.get(c.get('conversationId')) or []
        txt = ' '.join((m.get('text') or '') for m in ms).lower()
        channel = '询盘' if any(h in txt for h in INQUIRY_HINTS) else 'TM'
        if channel == '询盘':
            n_inq += 1
        norm.append({
            'conversationId': c.get('conversationId'),
            'contactName': c.get('contactName'),
            'contactLoginId': c.get('contactLoginId'),
            'contactAliId': str(c.get('contactAliId') or ''),
            'contactCountry': c.get('country'),
            'contactLevel': c.get('contactLevel'),
            'channel': channel,
            'sellerName': c.get('sellerName'),
            'sellerAliId': str(c.get('sellerAliId') or ''),
            '_owners': [c.get('sellerName')] if c.get('sellerName') else [],
            'lastActiveTime': c.get('lastActiveTime'),
            'conversationCreateTime': c.get('conversationCreateTime'),
            'unreadMessageCount': c.get('unreadMessageCount'),
            'crm': {'stage': c.get('stage'), 'tags': _tags(c),
                    'displayName': (c.get('displayName') or '').strip(),
                    'contactLevel': c.get('contactLevel'),
                    'conversationCreateTime': c.get('conversationCreateTime')},
            'messages': [{'sendTime': m.get('time'),
                          'senderRole': 'buyer' if m.get('from') == 'buyer' else 'seller',
                          'content': m.get('text') or ''} for m in ms],
        })

    # 平台国家优先用画像里的 buyer_country_code，这里先保留 country
    main_id = str((ident or {}).get('CURRENT_SELF_ALIID') or '')
    store_name = (ident or {}).get('CURRENT_NAME') or ''
    with open(os.path.join(OUT, 'conversations.json'), 'w', encoding='utf-8') as f:
        json.dump({'window': {'since': '%sT00:00:00' % start, 'until': '%sT23:59:59' % end},
                   'store': {'name': store_name, 'aliId': main_id,
                             'accountCount': len(ids)},
                   'conversations': norm}, f, ensure_ascii=False, indent=1)

    # 纯文本
    total_m = 0
    with open(os.path.join(OUT, 'messages.txt'), 'w', encoding='utf-8') as f:
        f.write('=' * 78 + '\n')
        f.write('询盘+TM 聊天记录  %s ~ %s\n' % (start, end))
        f.write('会话 %d 个 / 消息 %d 条 / 账号 %d 个\n' % (len(norm), sum(len(x['messages']) for x in norm), len(ids)))
        f.write('=' * 78 + '\n')
        for c in sorted(norm, key=lambda x: (x.get('lastActiveTime') or ''), reverse=True):
            ms = c['messages']
            total_m += len(ms)
            f.write('\n' + '-' * 78 + '\n')
            f.write('【%s】 %s · %s · 渠道 %s\n' % (c.get('contactName') or '', c.get('contactLoginId') or '',
                                                  c.get('contactCountry') or '', c.get('channel')))
            f.write('conversationId: %s\n' % c.get('conversationId'))
            f.write('等级 %s ｜ 阶段 %s ｜ 标签 %s ｜ 备注 %s\n' % (
                c.get('contactLevel') or '-', (c['crm'].get('stage') or '-'),
                '、'.join(c['crm'].get('tags') or []) or '-', c['crm'].get('displayName') or '-'))
            f.write('接待账号: %s  消息 %d 条  最近活跃 %s\n' % (
                c.get('sellerName') or '-', len(ms), c.get('lastActiveTime') or '-'))
            f.write('-' * 78 + '\n')
            for m in ms:
                f.write('[%s] %s   %s\n' % (m['sendTime'], '买家' if m['senderRole'] == 'buyer' else '我方',
                                            (m['content'] or '').replace('\n', ' ')[:800]))

    # ---------- 4) 买家画像 ----------
    buyers = []
    if not args.no_buyers:
        print('\n[4/4] 抓买家画像（上限 %d 个）…' % args.buyer_limit)
        agg = {}
        for c in norm:
            k = c.get('contactName') or ''
            a = agg.setdefault(k, {'aid': c.get('contactAliId'), 'n': 0,
                                   'loginId': c.get('contactLoginId')})
            a['n'] += len(c['messages'])
        top = sorted(agg.items(), key=lambda x: -x[1]['n'])[:args.buyer_limit]
        import tempfile
        T = tempfile.gettempdir()
        for i, (name, a) in enumerate(top, 1):
            if not a['aid']:
                continue
            p = os.path.join(T, '_b.json')
            with open(p, 'w', encoding='utf-8') as f:
                json.dump({'contactAliId': a['aid']}, f)
            rc, out = run(['workctl', 'icbu', 'tm', 'get-buyer-basic', '--format', 'json',
                           '--contact-ali-id', a['aid']], timeout=180)
            d3 = jparse(out) or {}
            inner = d3.get('data')
            if isinstance(inner, str):
                try:
                    inner = json.loads(inner)
                except Exception:
                    inner = {'buyer_persona': inner}
            buyers.append({'contactName': name, 'contactLoginId': a['loginId'],
                           'contactAliId': a['aid'], 'persona': inner or {}})
            if i % 20 == 0:
                print('    %d/%d' % (i, len(top)))
        with open(os.path.join(OUT, 'buyers.json'), 'w', encoding='utf-8') as f:
            json.dump(buyers, f, ensure_ascii=False, indent=1)
        print('    画像 %d 个' % len(buyers))

    stats = {'window': {'start': start, 'end': end}, 'accounts': len(ids),
             'conversations': len(norm), 'messages': total_m,
             'inquiry_conversations': n_inq, 'tm_conversations': len(norm) - n_inq,
             'buyers_with_persona': len(buyers)}
    with open(os.path.join(OUT, 'fetch_stats.json'), 'w', encoding='utf-8') as f:
        json.dump(stats, f, ensure_ascii=False, indent=1)

    print('\n' + '=' * 60)
    print('完成：账号 %d ｜ 会话 %d（询盘 %d + TM %d）｜ 消息 %d 条' % (
        stats['accounts'], stats['conversations'], stats['inquiry_conversations'],
        stats['tm_conversations'], stats['messages']))
    print('产物目录：%s' % OUT)
    return 0


if __name__ == '__main__':
    sys.exit(main())
