# 国际站数据面板 · 从零复现指南（REPRODUCE_GUIDE.md）

> 拿到本 zip 包后，跟着这份文档一步步做，就能在**你自己的 Alibaba.com 店铺**上复现出和
> 莱华仕/YH 一样的 8 页经营驾驶舱，**所有数据板块都会自动填充你店铺自己的实时数据**（零硬编码）。
>
> 本指南只讲**实际能跑的脚本**（`pipeline/` 目录）。`scripts/` 与 `templates/dashboard/`（多页面版）
> 是早期设计，**不用管**，以本文档为准。

---

## 一、这个面板长什么样（8 个页签，数据都要有）

打开 `dashboard/index.html`（登录口令见第五节），顶部 8 个页签：

| 页签 | 核心内容 | 数据来自哪个脚本 |
|---|---|---|
| **周期看板** | 周/月大盘：曝光→点击→商机→订单漏斗、同行平均/优秀对标、环比、6 周趋势 | `fetch_new_store.py` + `v6_fetch_monthly.py` |
| **重点关注** | 6 张运营榜单：商机榜/0效果/上升趋势·零花费榜/高效低耗榜(广告商机转化)/新品榜 | `v4_judge.py` |
| **AI 搜索** | 每品 AI 五维评分（市场趋势/AI识别/Listing/B2B转化/合规）+ 主图视觉诊断 | `v4_score.py` + 视觉子代理 |
| **趋势对比** | 6 周趋势线、环比变化 | `v4_judge.py`（weeks） |
| **改造执行台** | Top20 深度方案（17 项/品）+ 人工登记状态 + 导出/导入 | `stage_f_product360.py` + `stage_f_plans20.py` |
| **竞品对比** | 竞店 Top20 产品 + 品类定位打法 | `fetch_competitors.py` + `v4_competitors.py` |
| **同行标杆** | 父类目 GMV Top 供应商对标 | `fetch_peers.py` + `v4_ingest_peer.py` |
| **管理** | 星等级、子账号客服、国家地区、广告计划层、数据健康 | 星等级/客服/地区/广告各 ingest 脚本 |

> 每个板块的完整字段级说明见 `数据字典.md`（本包 docs 外的随包文档，若没有可查 `SKILL.md` 的「数据源与已知限制」）。

---

## 二、前提条件（一次性）

1. **Accio Work 环境**：装有 `accio-mcp-cli` / `workctl` 命令行工具（拉数据用，Accio 自带，不是 pip 包）。
2. **你的 Alibaba.com 卖家账号**：能在 Accio 里登录并**授权**：
   - 数据参谋（`data_advisor_shop_summary` / `data_advisor_shop_product` / `data_advisor_supplier_selection`）
   - 星等级（`icbu-starrating`）
   - 广告（`icbu ads`，可选，用于广告计划层）
3. **Python 3.10+**
4. 解压本包到任意目录（下称**包目录**）。

---

## 三、最短路径：自己店铺从零到全量看板

### 🚀 懒人模式（最推荐）：一句话让 AI 帮你跑完
把这份包装进你自己的 Accio（技能/工作区），登录你自己的 Alibaba 账号并授权后，
**直接对 AI 说一句**：

> 「复现这个看板，同步 **8 周** 数据」（或「…从 7月1日 到现在」）

AI 会自动：部署脚本 → 检查授权 → 帮你填 `stores.json`（店铺名/ID/类目）→ 跑
`python start.py --run --full --weeks 8`（时间段则加 `--as-of 截止日期`）→ 打开看板。
**你只需要说话，不用敲命令。** 之后每周让它跑一次「周更」即可（`weekly_update.py --skip-images`）。
> 放心 AI 不会做歪：包里的 **《AI_INSTRUCTIONS.md》** 是给执行 AI 的硬约束契约（禁改前端模板/禁编造数据/失败即停
> + 产出定义 + 8 项验收清单），AI 必须先读它再动手，逐项验收通过才允许说"完成"。

「周数/时间段」怎么换算：看板按**完整自然周（周一~周日，T+2 出数）**存数据——
「最近 N 周」=`--weeks N`；「X 月 1 日至今」= 数一下中间有几个完整周 N + `--as-of` 今天。

---

### ⚡ 最简方式（推荐）：一键启动，自动装好代码脚本
解压 zip 后，**双击 `quickstart.bat`**（Windows，或 Mac/Linux 运行 `./start.sh`）。它会自动：
1. 在 `workspace/` 里铺好全部脚本 + schema + 前端模板（无需你手动复制）
2. 自检环境（Python / pycryptodome / 数据接口工具）
3. 生成 `workspace/stores.json` 模板
4. 打印下一步

然后你只需：
```bash
# 在 Accio 登录并授权自己的店铺后：
python start.py --run          # 一键拉数 + 建库 + 评分 + 建看板 + 自动打开
# 或（补齐竞品/同行/客服等全部页签，需各域已授权）：
python start.py --run --full
```
> `--run` 会逐步执行、**失败即停**并提示原因；已完成的步骤可重复执行（幂等）。
> 若不想一键、想一步步来，往下看手动版（Step0~Step10）。

---

### 手动方式（Step 0 ~ 10）

> 全程在 `workspace/` 目录操作（一键启动器会自动建好它）。脚本读相对路径 `raw/`、`database/`，
> 所以所有 `.py` 都在 `workspace/` 根目录里跑。

### Step 0 — 装环境
```bash
pip install -r requirements.txt     # 只装 pycryptodome
```

### Step 1 — 部署代码到 Workspace
> **一键启动器已自动完成这步**（`start.py` 会把 `pipeline/*.py` + `schema.sql` + `templates/v4` 铺到 `workspace/`）。
> 下面只在你想手动部署时用。目标目录 = 包内的 `workspace/`。
```bash
# Windows PowerShell 示例（把 <包目录> 换成实际路径）
Copy-Item "<包目录>\pipeline\*.py"  "<包目录>\workspace\"
Copy-Item "<包目录>\schema.sql"     "<包目录>\workspace\"
Copy-Item "<包目录>\templates\v4"   "<包目录>\workspace\templates\v4" -Recurse
```
后续所有命令都在 `<包目录>\workspace\` 里跑（一键启动器也会建好这个目录）。

### Step 2 — 登录并授权自己的店铺
在 Accio 里用**你自己**的 Alibaba 账号登录，完成上面三个接口的授权。
授权后，`data_advisor_shop_summary` 返回的就是你店铺的实时数据——**代码里没有任何写死的店铺，全来自这里**。

### Step 3 — 登记你的店铺（stores.json）
在 Workspace 根目录建 `stores.json`（多店切换与 init 都读它）：
```json
{
  "active": "mystore",
  "stores": {
    "mystore": {
      "name": "我的店铺名",
      "full_name": "公司全称 (English Co., Ltd.)",
      "store_id": "<你的 Alibaba 店铺 ID>",
      "category": "你的主类目，如 Sports Nutrition",
      "cate_id": 202029902,
      "db": "stores/mystore/database/alibaba_growth.db",
      "raw": "stores/mystore/raw",
      "img_map": "stores/mystore/img_map.json"
    }
  }
}
```
> `store_id` / `cate_id` 在你 Alibaba 后台或数据参谋能查到。**父类目 cate_id 用「保健食品」这类父类目**（同行标杆要用），不是你的叶子类目。

### Step 4 — 拉全量数据（动态窗口，自动算周/月）
```bash
python fetch_new_store.py                 # 默认 as_of=今天，自动取最近 4 个完整周 + 基础月 + MTD
# 或显式指定数据截至日（每周二 T+2 跑时填当天）：
python fetch_new_store.py --as-of 2026-09-09
```
产物：`raw/shop_summary_w1_*.json … w4_*`、`raw/shop_summary_month*`、`raw/shop_summary_mtd_*`、
`raw/shop_product_w1_p01…N.json`（最新周产品全量），以及 `raw/_window.json`（记录本次窗口，供 init 读取）。
> 每屏会打印 `[summary …] ok=True seImps=… gmv=…` 和 `[product page N] …`。**看到 ok=True 且产品有行数**即成功。

### Step 5 — 建库回填（通用 init，读 stores.json + 动态窗口）
```bash
python init_store.py          # 用 active 店铺 + raw/_window.json
```
> **绝不复制旧店的 database/**。这里按 `schema.sql` 建空库再回填，`integrity_check=ok`、`foreign_key_check=PASS` 即成功，
> 会打印 `store / products / store_weekly=4 / store_monthly=2` 等行数，**products 应等于你店铺有效产品数**。

### Step 6 — 补充数据域（可选但建议，缺哪个哪个页签就空）
```bash
python fetch_prep.py          # 国家榜/流量渠道/关键词/类目热品 → raw/
python fetch_peers.py         # 同行标杆（父类目 GMV 降序）→ raw/peer_benchmark_*.json
python fetch_competitors.py   # 竞店 Top20 产品 → competitor_data/
python fetch_staff.py         # 4 周子账号客服效果 → raw/cs_w*.json
# 星等级（注意用 --output，不要用 -o；去掉 --terminal chrome）：
workctl icbu other icbu-starrating-cgs-pc-page-data-open --yes --format json --statDate <advisory> --output raw/star_rating_<date>.json
# 广告计划层（可选）：
python v4_fetch_ads.py
# 入库：
python v4_fetch_region.py
python v4_ingest_peer.py
python v4_ingest_star.py
python v4_ingest_staff.py      # 需先有 raw/chat_quality_check.json（可为空数组 []）
```

### Step 7 — AI 评分 + 竞品 + 板块
```bash
python v4_competitors.py        # 竞品全量（过滤擦边+带图+点评）
python v4_prep_sections.py      # 数据预处理（国家/渠道/买家/关键词/热销）
python v6_market_evidence.py    # 市场趋势证据（通用品类知识，换店无需改）
python v4_score.py              # AI 五维评分
# 改造执行台 Top20 深度方案（可选但建议）：
python stage_f_product360.py
python stage_f_plans20.py
```

### Step 8 — 判定合并 + 建看板
```bash
python v4_judge.py              # 合并所有数据 → v4_data.json（含 21 板块备注）
python v4_build.py              # 单店：v4_data.json → dashboard/（加密）
# 多店则用 build_all.py（见第四节）
```

### Step 9 — 打开 / 部署
- **本地**：双击 `dashboard/index.html`，输口令（默认 `Lifeworth123456`，见第五节改法）。
- **公网**：`python deploy.py`（推 GitHub → Vercel 自动部署）。

### Step 10 — 配每周二 T+2 自动
在 Accio 里建一个定时任务（或服务器 cron），**每周二 9:00** 跑：
```bash
python weekly_update.py --skip-images        # 只刷新最新完整周 + 重建看板
python weekly_update.py --skip-images --deploy  # 加自动部署
```
> T+2 规则：每周二跑时，上周（周一~周日）数据已出，脚本自动判定最新完整周，**没有新周就 SKIP**，不会重复写。

---

## 四、多店看板（build_all.py）

一家公司多个店铺时，每店一个 `stores/<key>/`（database + raw + v4_data.json），用 `build_all.py` 打包成
`dashboard/dashboard_data.js` 的 `window.V4_STORES`，看板顶部下拉切换：
```bash
python build_all.py          # 逐店生成/复用 v4_data.json → 打包多店 → 拷模板
```
> 加第三家店：在 `stores.json` 新增条目 → 建 `stores/<key>/` → 按 Step4~8 跑一遍 → `build_all.py`。
> 切换展示店：`python switch_store.py <key>`（会先备份当前店，再与确认身份，见 SKILL.md 核心原则 #9）。

---

## 五、数据安全（重要，务必读）

1. **看板口令**：4 个构建脚本读环境变量 `GOS_DASHBOARD_PASSWORD`，未设置时用默认值。
   **建议你自己设一个强口令**：
   ```bash
   # Windows
   $env:GOS_DASHBOARD_PASSWORD='你自己想的一个强密码'
   python v4_build.py
   ```
   设了之后，看板登录就输入你这个密码。默认值 `Lifeworth123456` 只是向后兼容占位，**对外分享前请改**。
2. **不打包私有数据**：本 zip 只含代码 + schema + 模板 + 文档，**不含**任何 `database/`、`raw/`、`v4_data.json`
   （那里面是具体店铺的经营数据，属于各店私有）。同事复现的数据 100% 来自她自己账号的实时接口。
3. **不内嵌 Token**：`deploy.py` 推 GitHub 时，remote URL **不要**把 Token 写死在里面（历史曾因此泄露，需轮换）。
   用凭据管理器 / SSH key 或临时注入。
4. **换店/覆盖前先备份 + 确认身份**（store_id + 主类目）——同公司多店最容易踩的坑，见 `SKILL.md` 核心原则 #9。

---

## 六、常见坑 & 每步验证点

| 现象 | 原因 / 处理 |
|---|---|
| fetch 打印 `ok=False` | 没授权数据参谋，或店铺连接器没切到自己店 → 回 Step2 确认授权 |
| 产品榜询盘全 0 但有商机 | 该店型询盘走 TM 而非表单，脚本已用 `atmFbUv`(TM 咨询) 兜底，属正常 |
| 星等级/广告/竞品页签空 | 对应 Step6 的域没跑或没授权 → 补跑该域后重跑 `v4_judge.py` + `v4_build.py` |
| 广告没有「花费/ROI」 | **数据参谋本身不返回 spend 字段**（只有曝光/点击/询盘），这是平台接口限制，不是 bug；看板给的是曝光/点击/商机转化，非真实 ROI |
| 建看板后看板没更新 | 浏览器缓存 → `index.html` 里 `dashboard_data.js?v=…` 版本号改一下（cache-busting），或 Ctrl+F5 |
| init 报缺 raw 文件 | fetch 没跑全或窗口对不上 → 重跑 `fetch_new_store.py`（它会重写 `raw/_window.json`）再 `init_store.py` |

**验证清单**（每步做完自查）：
- [ ] Step4：`shop_summary_w1_*` 存在且 `ok=True`；产品分页有行数
- [ ] Step5：`integrity_check=ok`、`foreign_key_check=PASS`、`products`=你店有效品数
- [ ] Step8：`v4_data.json` 生成；`dashboard/dashboard_data.js` 有内容
- [ ] Step9：8 个页签都能切、数据非全空

---

## 七、目录速查

```
<包目录>/
├── REPRODUCE_GUIDE.md      ← 本文件（从这开始看）
├── quickstart.bat             ← ★ Windows 双击：自动部署代码脚本 + 自检 + 引导
├── start.sh                 ← ★ Mac/Linux 运行：同上
├── start.py                 ← 一键启动器源码（部署到 workspace/ 并可选 --run 全流程）
├── SKILL.md                 ← 技能规范 / 命令 / 核心原则
├── README.md                ← 面向使用者的快速开始
├── requirements.txt         ← pip 依赖（pycryptodome）
├── config.example.json      ← 配置模板
├── schema.sql               ← SQLite schema
├── pipeline/                ← ★ 实际能跑的全部脚本（含 gos_window 动态窗口 / init_store 通用建库）
│   ├── gos_window.py        ← 时间窗口助手（T+2/自然周，本地可自测）
│   ├── fetch_new_store.py   ← 拉全量（动态窗口）
│   ├── init_store.py        ← 建库回填（通用，读 stores.json）
│   ├── v4_judge.py          ← 判定引擎 + 合并（含高效低耗榜=广告商机转化）
│   ├── v4_build.py / build_all.py / switch_store.py
│   ├── weekly_update.py     ← 一键周更
│   └── …（其余 fetch_/v4_/v6_/v7_/stage_ 脚本）
├── templates/v4/            ← 8 页驾驶舱前端模板（index.html/app.js/styles.css/chart.umd.min.js）
├── flows/  docs/            ← 标准工作流 / 架构与数据模型文档
└── scripts/  templates/dashboard/   ←（早期多页面版，已废弃，忽略）
```
