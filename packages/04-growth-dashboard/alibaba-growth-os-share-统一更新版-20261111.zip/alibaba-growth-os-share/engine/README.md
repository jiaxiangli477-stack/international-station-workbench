# Alibaba Growth OS — Skill V1.1

可复用 Alibaba 国际站经营增长操作系统。一个 Workspace 对应一个 Alibaba 店铺：官方数据 → 本地持久化历史 → AI 经营诊断 → AI 深度产品优化（17 项方案）→ 多页面经营驾驶舱（15 个业务页面）→ 人工登记与状态持久化 → Action→Validation→Learning。

## V1.1 新增能力

- **多页面经营驾驶舱**：`dashboard/` 15 个独立业务页面（总览/重点关注/产品/AI优化/广告/搜索/客服/买家/趋势/对标/竞品/执行台/数据健康），相对路径、双击 index.html 即可用，无 localhost/远程 API。
- **AI 深度优化方案**：每个候选产品输出 17 项完整方案（为什么选/问题/证据/历史/同行差距/Buyer Intent/Listing 诊断/Root Cause/Primary Action/具体修改/不做清单/Future/验证指标/周期/置信度/证据源），标题给 3 个候选方案、主图给 Creative Brief、详情页给模块结构、MOQ 给阶梯。
- **人工登记**：状态（9 态）+ 负责人 + 计划/实际完成日期 + 实际修改 + 备注；先存浏览器 localStorage，【导出执行记录】生成 JSON，Skill 侧 `IMPORT ACTION UPDATES` 合并进 SQLite，重建 Dashboard 状态不丢。

## 两种使用方式（重要区分）

| | Skill Package | Store Runtime |
|---|---|---|
| 是什么 | 可复制、**无任何店铺数据**的通用模板 | 当前店铺的历史数据与运行产物 |
| 包含 | 本目录全部文件 + RELEASE_MANIFEST | `config.json`、`database/`、`raw/`、`reports/`、`dashboard/` |
| 能否复制给别的店 | ✅ 复制本 Skill 即可 | ❌ 禁止（含店铺私有数据） |
| 存放位置 | `releases/alibaba-growth-os-v1.0/` | Workspace 根（config.json 等） |

## 面向普通使用者：日常操作

### 新店（第一次使用）

```
1. 安装 Skill（复制 releases/alibaba-growth-os-v1.0/ 到新 Workspace）
2. 授权 Alibaba（登录并授权当前店铺账号）
3. 复制 config.example.json 为 config.json，填写店铺信息与 data_source.advisory_date
4. INITIALIZE STORE（自动新建 config / database / raw / reports / dashboard）
```

> 换另一家 Alibaba 店时：**不能复制旧店数据库**，只复制 Skill Release，然后在新 Workspace 重新授权新的 Alibaba 账号并执行 INITIALIZE STORE。

### 每周

```
SYNC WEEKLY
```

- 自动判断最新完整自然周（Monday→Sunday，仅当 `week_end <= data_advisory_date` 才同步）
- 无新周 → SKIP；有新周 → 仅抓取该周 → 诊断 → 优化候选 → 行动 → 周报 → 重建看板

### 每月

```
SYNC MONTHLY
```

- 只同步已完成且满足 T+2 的自然月；当前月只能作为 MTD（月度=策略，周度=行动）

### 产品优化

```
OPTIMIZE PRODUCT <Product ID>
OPTIMIZE TOP PRODUCTS   （数据引擎筛选 Top 5-10，不做全量 680 无差别优化）
```

### 更新看板（随时）

```
REBUILD DASHBOARD
```

- 只读取本地 SQLite，不访问 Alibaba；看板可随时重建/覆盖，历史以 SQLite 为准

### 健康检查

```
VALIDATE GROWTH OS      （Config / DB / 最新周 / Advisory / Raw / 能力 / Peer / 行动表 / 看板 → PASS/WARNING/FAILED）
```

### 某周数据不全时

```
RETRY PERIOD <period>   （只补失败的数据域，不重写已成功数据；本次同步标记 PARTIAL 并记录 failed_domain）
```

## 换电脑继续同一家店（迁移）

```
1. 旧电脑: EXPORT STORE PACKAGE
   → 打包 config + database + raw + reports + dashboard + actions（不含 Cookie/密码/Session/Alibaba 登录凭证）
2. 新电脑: IMPORT STORE PACKAGE
3. 重新登录 Alibaba
4. 继续 SYNC WEEKLY —— 历史不丢
```

## 设计约束

- 默认 **READ ONLY**：不自动修改 Listing / 价格 / MOQ / 广告 / Bid / Campaign / 发布产品；写操作必须用户明确授权。
- **SQLite 是唯一历史事实源**：dashboard.html 可覆盖；SQLite 与 Raw Snapshots 不因看板重建而改变。
- 禁止写死店铺名、Product ID、Campaign ID、日期、行业/同行数值；一切店铺值只来自 config.json 或运行时发现。
- 数据仅来自 Alibaba 官方接口；历史全部落本地 SQLite。

## 目录

- `SKILL.md` — 技能规范与命令
- `config.example.json` — 配置模板
- `schema.sql` — 本地库 schema
- `flows/` — 标准工作流
- `scripts/` — 可复用实现
- `templates/dashboard.html.j2` — 中文 Dashboard 模板
- `docs/` — 架构 / 数据模型 / 诊断规则 / 产品优化方法论

## 文档索引

- 架构：[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
- 数据模型：[docs/DATA_MODEL.md](docs/DATA_MODEL.md)
- 诊断规则：[docs/DIAGNOSIS_RULES.md](docs/DIAGNOSIS_RULES.md)
- 产品优化：[docs/AI_PRODUCT_OPTIMIZER.md](docs/AI_PRODUCT_OPTIMIZER.md)
