/* Alibaba Growth OS V4 — 渲染逻辑 */
var D = window.V4_DATA || {};
var PERIOD = 'week'; // week | month

/* ---------- 工具 ---------- */
function esc(s){ return String(s==null?'':s).replace(/[&<>"]/g, function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
function num(n){ if(n==null||n==='') return '—'; n=Number(n); return n.toLocaleString('en-US'); }
function money(n){ if(n==null||n==='') return '—'; n=Number(n); return '$'+n.toLocaleString('en-US',{maximumFractionDigits:0}); }
function pct(n){ if(n==null||n==='') return '—'; n=Number(n); return n.toFixed(2)+'%'; }
function wowHtml(w){ var unit = PERIOD==='month' ? '上月' : '上周'; if(w==null) return '<span class="muted">环比 —</span>'; var up=w>=0; var c=up?'wow-up':'wow-down'; var s=up?'+':''; return '<span class="'+c+'">'+(up?'↑':'↓')+' '+s+w+'% '+unit+'</span>'; }
function fmt(k,v){ if(k==='money') return money(v); if(k==='pct') return pct(v); return num(v); }
function tag(text,typ){ if(!text) return ''; return '<span class="tag '+typ+'">'+esc(text)+'</span>'; }
function gapHtml(cur, avg, good, lowerBetter){
  if(avg==null && good==null) return '<span class="muted">同行 —</span>';
  var parts=[];
  if(good!=null){ var d=(lowerBetter? good-cur : cur-good); var cls=(lowerBetter? (d>0?'bad':'ok') : (d<0?'bad':'ok')); parts.push('同行优秀 '+fmtg(good)+' <span class="'+cls+'">('+(d>=0?'差':'超')+' '+fmtg(Math.abs(d))+')</span>'); }
  if(avg!=null){ var d2=(lowerBetter? avg-cur : cur-avg); var cls2=(lowerBetter? (d2>0?'bad':'ok') : (d2<0?'bad':'ok')); parts.push('同行平均 '+fmtg(avg)+' <span class="'+cls2+'">('+(d2>=0?'差':'超')+' '+fmtg(Math.abs(d2))+')</span>'); }
  return parts.join(' · ');
}
function fmtg(v){ return Math.abs(v)>=1000? num(v): (Math.abs(v)<1&&v!==0? v.toFixed(3): num(v)); }
function pimg(url){ return url? '<img class="pimg" src="'+esc(url)+'" onclick="previewImg(\''+esc(url)+'\')" style="cursor:zoom-in" onerror="this.style.visibility=\'hidden\'">' : '<div class="pimg"></div>'; }
function previewImg(url){
  if(!url) return;
  var ov=document.createElement('div'); ov.className='modal-overlay'+(false?'':' img-overlay');
  ov.innerHTML='<div style="text-align:center"><img src="'+esc(url)+'" style="max-width:90vw;max-height:90vh;border-radius:8px;box-shadow:0 10px 40px rgba(0,0,0,.5)"><div class="muted" style="color:#fff;margin-top:10px">点击任意处关闭</div></div>';
  document.body.appendChild(ov);
  ov.addEventListener('click', function(){ ov.remove(); });
}

/* ---------- 产品跳转链接（我的产品 → Alibaba 商品页） ---------- */
function pUrl(p){
  if(!p || !p.product_id) return '';
  var slug=String(p.title||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,60);
  return 'https://www.alibaba.com/product-detail/'+slug+'_'+p.product_id+'.html';
}
function plink(p, maxLen){
  var full=String((p&&p.title)||'');
  var t=maxLen? full.slice(0,maxLen) : full;
  var u=pUrl(p);
  if(!u) return '<span title="'+esc(full)+'">'+esc(t)+'</span>';
  return '<a class="plink" href="'+esc(u)+'" target="_blank" rel="noopener" title="'+esc(full)+'">'+esc(t)+'</a>';
}

/* ---------- AI 评分 ---------- */
var SCORES = {};
function loadScores(){ SCORES={}; (D.v4_scores&&D.v4_scores.scores||[]).forEach(function(s){ SCORES[s.product_id]=s; }); }
function scoreOf(pid){ return SCORES[pid]||null; }
function gradeTag(s){
  if(!s) return '<span class="muted">—</span>';
  return '<span class="score-tag '+s.gcls+'" onclick="openScore(\''+s.product_id+'\')">'+s.score+'分 '+s.grade+'</span>';
}
function conciseAdvice(s){
  if(!s) return '';
  var parts=[];
  var pb=s.playbook;
  // 1. 市场定位（品类打法，按市场区分）
  if(pb && pb.positioning) parts.push('<b style="color:var(--blue)">'+esc(pb.positioning.slice(0,34))+'</b>');
  // 2. 本品具体动作（第一条打法，结合诊断）
  if(s.problems && s.problems.length){
    parts.push('<span style="color:var(--red)">'+esc(s.problems[0].slice(0,30))+'</span>');
  } else if(pb && pb.moves && pb.moves[0]){
    parts.push(esc(pb.moves[0].slice(0,30)));
  }
  // 3. 视觉诊断补充（如占位图/擦边）
  var vis=(D.vision_result&&D.vision_result[s.product_id])||null;
  if(vis && vis.advices && vis.advices.length) parts.push(esc(vis.advices[0].slice(0,24)));
  return parts.join(' → ');
}
function openScore(pid){
  var s=SCORES[pid];
  if(!s){ alert('该产品暂无评分数据'); return; }
  var adv=s.advice||{};
  var lvCls={好:'good',中:'neutral',差:'danger',风险:'danger','无流量':'muted','无数据':'muted'};
  var ov=document.createElement('div'); ov.className='modal-overlay';
  var h='<div class="plan-modal"><div class="pm-head"><span>🤖</span><b>AI 产品评分</b><span class="pm-title">'+esc(s.title)+'</span><div class="spacer"></div><span class="score-big '+s.gcls+'">'+s.score+'分 '+esc(s.grade)+'</span><button class="btn btn-close" onclick="this.closest(\'.modal-overlay\').remove()">关闭 ✕</button></div>';
  h+='<div class="pm-body"><div class="pm-left">';
  // 5 维度评分（哪里好哪里差，细颗粒度）
  h+='<div class="pm-box"><h5>📊 五维评分（哪里好 / 哪里差）</h5>';
  (s.dims||[]).forEach(function(d){
    var cls=lvCls[d.level]||'neutral';
    h+='<div class="dim-row"><div class="dim-name">'+esc(d.name)+'</div><div class="progress-bar" style="flex:1"><i style="width:'+Math.max(2,d.score||0)+'%"></i></div><span class="dim-tag '+cls+'">'+esc(d.level)+'</span></div>'+
      '<div class="dim-reason small muted">'+esc(d.reason)+'</div>';
  });
  h+='</div>';
  // 置信度 + 评分与表现关系（4.3）
  var confCls=s.confidence==='高'?'good':(s.confidence==='中'?'warn':(s.confidence==='低'?'danger':'muted'));
  h+='<div class="pm-box"><h5>🎯 评分置信度 & 与表现的关系</h5><div class="pm-note">'+
    '<div>'+tag('置信度：'+esc(s.confidence||'—'), confCls)+' <span class="small muted">（证据充分度：真实效果数据 + 视觉诊断 + 市场证据）</span></div>'+
    '<div class="mt8"><b>评分 vs 实际表现</b>：'+esc(s.score_vs_perf||'')+'</div>'+
  '</div></div>';
  // 市场趋势证据 & 建议（评分面板的市场趋势分依据）
  var me=s.market_evidence||{};
  if(me&&me.verdict){
    h+='<div class="pm-box"><h5>📈 市场趋势证据 & 建议</h5><div class="pm-note">'+
      '<div><b>趋势结论</b>：'+esc(me.verdict)+'</div>'+
      ((me.sources&&me.sources.length)?'<div class="mt8"><b>市场报告</b>：'+me.sources.map(function(x){return '<div class="small muted">· '+esc(x)+'</div>';}).join('')+'</div>':'')+
      ((me.social)?'<div class="mt8"><b>社媒热度</b>：<span class="small muted">'+esc(me.social)+'</span></div>':'')+
      ((me.amazon)?'<div class="mt8"><b>亚马逊信号</b>：<span class="small muted">'+esc(me.amazon)+'</span></div>':'')+
    '</div></div>';
  }
  // 主图视觉诊断
  var vis=(D.vision_result&&D.vision_result[pid])||null;
  if(vis){
    var b2bCls = vis.b2b==='好'?'good':(vis.b2b==='中'?'warn':'danger');
    var aiCls = vis.ai==='好'?'good':(vis.ai==='中'?'warn':'danger');
    h+='<div class="pm-box"><h5>🖼 主图视觉诊断（视觉模型识别 + 资深运营分析）</h5><div class="pm-note">'+
      '<div>'+tag('主图：'+esc(vis.type), vis.type==='实物图'?'good':(vis.type==='渲染图'?'warn':'danger'))+' '+tag('背景：'+esc(vis.bg),'neutral')+(vis.risk!=='无'?' '+tag('⚠'+esc(vis.risk)+'擦边','danger'):'')+'</div>'+
      '<div class="mt8"><b>卖点文字</b>：'+esc(vis.text||'无')+'　<b>认证</b>：'+esc(vis.cert||'无')+'</div>'+
      '<div class="mt8">'+tag('B2B转化适配：'+esc(vis.b2b), b2bCls)+' <span class="small muted">'+esc(vis.b2b_comment||'')+'</span></div>'+
      '<div class="mt8">'+tag('AI识别匹配：'+esc(vis.ai), aiCls)+' <span class="small muted">'+esc(vis.ai_comment||'')+'</span></div>'+
      '<div class="mt8" style="color:'+(vis.vision_score>=80?'var(--green)':(vis.vision_score>=55?'var(--orange)':'var(--red)'))+'"><b>视觉评分 '+vis.vision_score+'分</b>：'+esc(vis.note)+'</div>'+
      ((vis.advices&&vis.advices.length)?'<div class="mt8"><b>修改建议</b>：'+(vis.advices.map(function(a){return '<div style="color:var(--blue)">· '+esc(a)+'</div>';}).join(''))+'</div>':'')+
    '</div></div>';
  }
  // 识别画像
  h+='<div class="pm-box"><h5>🔍 AI 识别画像（标题内容能被 AI 识别到什么）</h5><div class="pm-note">'+
    '<div><b>识别为</b>：'+esc(s.recognized_as||'信息不足')+'</div>'+
    '<div class="mt8"><b>已识别到</b>：'+(s.ai_present&&s.ai_present.length?s.ai_present.map(function(x){return '<span class="tag good">'+esc(x)+'</span>';}).join(' '):'<span class="muted">无</span>')+'</div>'+
    '<div class="mt8"><b>缺失</b>：'+(s.ai_missing&&s.ai_missing.length?s.ai_missing.map(function(x){return '<span class="tag danger">'+esc(x)+'</span>';}).join(' '):'<span class="muted">无</span>')+'</div>'+
  '</div></div>';
  // 转化链路闭环
  if(s.funnel&&s.funnel.length){
    h+='<div class="pm-box"><h5>🔁 转化链路闭环（哪里断了）</h5><div class="pm-note">';
    s.funnel.forEach(function(st){ h+='<div class="funnel-step">'+(st.ok?'<span class="tag good">✓</span>':'<span class="tag danger">✗</span>')+esc(st.step)+'：'+esc(st.txt)+'</div>'; });
    h+='</div></div>';
  }
  if(s.good&&s.good.length){ h+='<div class="pm-box"><h5>✅ 好的点</h5><ul class="pm-list">'+s.good.map(function(g){return '<li>'+esc(g)+'</li>';}).join('')+'</ul></div>'; }
  if(s.bad&&s.bad.length){ h+='<div class="pm-box"><h5>❌ 不好的点</h5><ul class="pm-list">'+s.bad.map(function(b){return '<li style="color:var(--red)">'+esc(b)+'</li>';}).join('')+'</ul></div>'; }
  h+='</div><div class="pm-right">';
  // 精准建议（问题 → 行动）
  h+='<div class="pm-box"><h5>🎯 诊断 & 行动（按这个品的实际数据）</h5>';
  if(s.problems&&s.problems.length){ h+='<div class="pm-note">'+(s.problems.map(function(p){return '<div>🔴 '+esc(p)+'</div>';}).join(''))+'</div>'; }
  h+='<div class="pm-note mt8">'+(s.actions&&s.actions.length?s.actions.map(function(a){return '<div>✅ '+esc(a)+'</div>';}).join(''):'')+'</div>';
  h+='</div>';
  var pb=s.playbook||{};
  h+='<div class="pm-box"><h5>🎯 品类打法（市场定位 + 具体动作 + 对标谁）</h5><div class="pm-note">'+
    '<div><b>市场定位</b>：'+esc(pb.positioning||adv.focus||'')+'</div>'+
    '<div class="mt8"><b>打法</b>：'+((pb.moves&&pb.moves.length)?pb.moves.map(function(m){return '<div style="color:var(--blue)">· '+esc(m)+'</div>';}).join(''):esc(adv.img||''))+'</div>'+
    ((pb.benchmark)?'<div class="mt8"><b>对标</b>：'+esc(pb.benchmark)+'</div>':'')+
  '</div></div>';
  if(s.cat_type==='maca'||s.cat_type==='detox'){
    h+='<div class="pm-box"><h5>⚠️ 合规提醒</h5><div class="insight danger">该品属于壮阳/减肥擦边品类，虽出商机但平台合规风险高。建议按「主攻点」改名为植物草本/消化健康等合规表述，既保商机又避处罚。</div></div>';
  }
  h+='</div></div></div>';
  ov.innerHTML=h;
  document.body.appendChild(ov);
  ov.addEventListener('click', function(e){ if(e.target===ov) ov.remove(); });
}

/* ---------- 备注持久化（预填 AI 建议）---------- */
function note(key){
  var v = localStorage.getItem('v4note_'+key);
  if(v===null || v===''){ v = (D.section_notes && D.section_notes[key]) || ''; }
  return v;
}
function noteBox(key){
  return '<div class="note-box"><div class="note-label">本板块备注（本机保存，仅本浏览器可见）</div>'+
    '<textarea data-note="'+key+'" oninput="saveNote(this)">'+esc(note(key))+'</textarea></div>';
}
function saveNote(el){ localStorage.setItem('v4note_'+el.getAttribute('data-note'), el.value); }

var SELECTED_WEEK = -1; // -1 = 最新周
var SELECTED_MONTH = -1; // -1 = 最新完整月

function wowOf(w, key){ return (w && w.wow) ? w.wow[key] : null; }
function weekToFunnel(w){
  return [
    {key:'se_imps',label:'搜索曝光',cur:w.se_imps,prev:null,wow:wowOf(w,'se_imps'),rival_avg:w.se_imps_ra,rival_good:w.se_imps_rg,unit:''},
    {key:'se_clk',label:'搜索点击',cur:w.se_clk,prev:null,wow:wowOf(w,'se_clk'),rival_avg:w.se_clk_ra,rival_good:w.se_clk_rg,unit:''},
    {key:'se_ctr',label:'搜索点击率',cur:w.se_ctr,fmt:'pct',wow:wowOf(w,'se_ctr'),rival_avg:w.se_ctr_ra,rival_good:w.se_ctr_rg,unit:'%'},
    {key:'total_imps',label:'全店曝光',cur:w.total_imps,wow:wowOf(w,'total_imps'),rival_avg:w.total_imps_ra,rival_good:w.total_imps_rg,unit:''},
    {key:'camp_imps',label:'广告曝光',cur:w.camp_imps,wow:wowOf(w,'camp_imps'),rival_avg:w.camp_imps_ra,rival_good:w.camp_imps_rg,unit:''},
    {key:'camp_clk',label:'广告点击',cur:w.camp_clk,wow:wowOf(w,'camp_clk'),rival_avg:w.camp_clk_ra,rival_good:w.camp_clk_rg,unit:''},
    {key:'opp',label:'商机(询盘+TM)',cur:(w.fb_cnt||0)+(w.fb_tm_uv||0),wow:wowOf(w,'opp'),unit:'',note:'商机事件数·未去重（同一买家既询盘又TM会重复计入）。询盘成交意图>TM（TM为弱意向）。去重买家数/有效商机数接口未提供，无法与同行直接比较有效商机。'},
    {key:'fb_cnt',label:'询盘个数',cur:w.fb_cnt,wow:wowOf(w,'fb_cnt'),unit:''},
    {key:'fb_tm_uv',label:'TM咨询人数',cur:w.fb_tm_uv,wow:wowOf(w,'fb_tm_uv'),unit:''},
    {key:'uv_cnt',label:'访客',cur:w.uv_cnt,wow:wowOf(w,'uv_cnt'),rival_good:w.uv_cnt_rg,unit:''},
    {key:'uv_ab_rate',label:'跳失率',cur:w.uv_ab_rate,fmt:'pct',wow:wowOf(w,'uv_ab_rate'),rival_avg:w.uv_ab_rate_ra,rival_good:w.uv_ab_rate_rg,unit:'%',lower_better:true},
    {key:'suc_byr_cnt',label:'成交买家',cur:w.suc_byr_cnt,wow:wowOf(w,'suc_byr_cnt'),rival_good:w.suc_byr_cnt_rg,unit:'人'},
    {key:'uv_payord_rate',label:'访客成交率',cur:w.uv_payord_rate,fmt:'pct',wow:wowOf(w,'uv_payord_rate'),rival_avg:w.uv_payord_ra,rival_good:w.uv_payord_rg,unit:'%'},
    {key:'suc_ord_cnt',label:'下单',cur:w.suc_ord_cnt,wow:wowOf(w,'suc_ord_cnt'),rival_avg:w.suc_ord_cnt_ra,rival_good:w.suc_ord_cnt_rg,unit:'单'},
    {key:'suc_ord_amt',label:'GMV',cur:w.suc_ord_amt,wow:wowOf(w,'suc_ord_amt'),rival_avg:w.suc_ord_amt_ra,rival_good:w.suc_ord_amt_rg,unit:'$',fmt:'money'},
  ];
}
function weekToBearing(w){
  return [
    {key:'avg_reply_time',label:'平均回复时长',cur:w.avg_reply,unit:'h',lower_better:true},
    {key:'fst5min',label:'极速回复率(5min)',cur:w.fst5min,fmt:'pct',unit:'%'},
    {key:'fst_reply',label:'及时回复率',cur:w.fst_reply,fmt:'pct',unit:'%'},
    {key:'uv_payord',label:'访客成交率',cur:w.uv_payord_rate,fmt:'pct',unit:'%'},
  ];
}
function selectedWeek(){
  var arr=D.weeks||[];
  if(!arr.length) return null;
  if(SELECTED_WEEK<0 || SELECTED_WEEK===arr.length-1) return null;
  return arr[SELECTED_WEEK];
}
function selectedMonth(){
  var arr=D.months||[];
  if(!arr.length) return D.monthly;
  if(SELECTED_MONTH<0 || SELECTED_MONTH===arr.length-1) return arr[arr.length-1];
  return arr[SELECTED_MONTH];
}
function monthToFunnel(M){
  return [
    {key:'se_imps',label:'搜索曝光',cur:M.se_imps,wow:wowOf(M,'se_imps'),rival_avg:M.se_imps_ra,rival_good:M.se_imps_rg,unit:''},
    {key:'se_clk',label:'搜索点击',cur:M.se_clk,wow:wowOf(M,'se_clk'),rival_avg:M.se_clk_ra,rival_good:M.se_clk_rg,unit:''},
    {key:'se_ctr',label:'搜索点击率',cur:M.se_ctr,fmt:'pct',wow:wowOf(M,'se_ctr'),rival_avg:M.se_ctr_ra,rival_good:M.se_ctr_rg,unit:'%'},
    {key:'total_imps',label:'全店曝光',cur:M.total_imps,wow:wowOf(M,'total_imps'),rival_avg:M.total_imps_ra,rival_good:M.total_imps_rg,unit:''},
    {key:'camp_imps',label:'广告曝光',cur:M.camp_imps,wow:wowOf(M,'camp_imps'),rival_avg:M.camp_imps_ra,rival_good:M.camp_imps_rg,unit:''},
    {key:'camp_clk',label:'广告点击',cur:M.camp_clk,wow:wowOf(M,'camp_clk'),rival_avg:M.camp_clk_ra,rival_good:M.camp_clk_rg,unit:''},
    {key:'opp',label:'商机(询盘+TM)',cur:M.opp,wow:wowOf(M,'opp'),rival_avg:M.ab_cnt_ra,rival_good:M.ab_cnt_rg,unit:'',note:'商机事件数·未去重（询盘 '+num(M.fb_cnt)+' + TM '+num(M.fb_tm_uv)+'）。去重买家数/有效商机数接口未提供。'},
    {key:'fb_cnt',label:'询盘个数',cur:M.fb_cnt,wow:wowOf(M,'fb_cnt'),rival_avg:M.fb_cnt_ra,rival_good:M.fb_cnt_rg,unit:''},
    {key:'fb_tm_uv',label:'TM咨询人数',cur:M.fb_tm_uv,wow:wowOf(M,'fb_tm_uv'),rival_avg:M.fb_tm_ra,rival_good:M.fb_tm_rg,unit:''},
    {key:'uv_cnt',label:'访客',cur:M.uv_cnt,wow:wowOf(M,'uv_cnt'),rival_avg:M.uv_cnt_ra,rival_good:M.uv_cnt_rg,unit:''},
    {key:'uv_ab_rate',label:'跳失率',cur:M.uv_ab_rate,fmt:'pct',wow:wowOf(M,'uv_ab_rate'),rival_avg:M.uv_ab_ra,rival_good:M.uv_ab_rg,unit:'%',lower_better:true},
    {key:'suc_byr_cnt',label:'成交买家',cur:M.suc_byr_cnt,wow:wowOf(M,'suc_byr_cnt'),rival_avg:M.suc_byr_ra,rival_good:M.suc_byr_rg,unit:'人'},
    {key:'uv_payord_rate',label:'访客成交率',cur:M.uv_payord_rate,fmt:'pct',wow:wowOf(M,'uv_payord_rate'),rival_avg:M.uv_payord_ra,rival_good:M.uv_payord_rg,unit:'%'},
    {key:'suc_ord_cnt',label:'下单',cur:M.suc_ord_cnt,wow:wowOf(M,'suc_ord_cnt'),rival_avg:M.suc_ord_cnt_ra,rival_good:M.suc_ord_cnt_rg,unit:'单'},
    {key:'suc_ord_amt',label:'GMV',cur:M.suc_ord_amt,wow:wowOf(M,'suc_ord_amt'),rival_avg:M.suc_ord_amt_ra,rival_good:M.suc_ord_amt_rg,unit:'$',fmt:'money'},
  ];
}
function getFunnel(){
  if(PERIOD==='month') return monthToFunnel(selectedMonth()||D.monthly||{});
  var w=selectedWeek();
  return w ? weekToFunnel(w) : (D.funnel||[]);
}
function getBearing(){
  if(PERIOD==='month' && D.monthly){
    var M=selectedMonth()||D.monthly;
    return [
      {key:'avg_reply_time',label:'平均回复时长',cur:M.avg_reply_time,unit:'h',lower_better:true,rival_avg:M.avg_reply_time_ra},
      {key:'fst5min',label:'极速回复率(5min)',cur:M.fst5min,fmt:'pct',unit:'%',rival_avg:M.fst5min_ra,rival_good:M.fst5min_rg},
      {key:'fst_reply',label:'及时回复率',cur:M.fst_reply_rate,fmt:'pct',unit:'%',rival_avg:M.fst_reply_ra,rival_good:M.fst_reply_rg},
      {key:'uv_payord',label:'访客成交率',cur:M.uv_payord_rate,fmt:'pct',unit:'%',rival_avg:M.uv_payord_ra,rival_good:M.uv_payord_rg},
    ];
  }
  var w=selectedWeek();
  return w ? weekToBearing(w) : (D.bearing||[]);
}

/* 周/月统一辅助（P0-4） */
function periodWord(){ return PERIOD==='month' ? '本月' : '本周'; }
function weeklyOnlyNote(){ return PERIOD==='month' ? '<div class="insight warn">⚠ 本模块仅接入周数据（月度口径未接入），以下展示最新一周数据，仅作参考。</div>' : ''; }

/* ============ 周期看板 ============ */
function renderPeriod(){
  var el = document.getElementById('panel-period');
  var m = D.meta||{};
  var _sm = PERIOD==='month' ? selectedMonth() : null;
  var _sw = PERIOD==='week' ? selectedWeek() : null;
  var periodLabel = _sm ? _sm.month_label : (_sw ? (_sw.week_start+' ~ '+_sw.week_end) : m.week_label);
  var h = '';
  // 一、店铺漏斗
  if(PERIOD==='month' && D.monthly_mtd){
    h += '<div class="insight warn">⚠ 本月（'+esc(D.monthly_mtd.month_label)+'）为 MTD 未完成，数据不完整不可用。以下展示上一完整自然月 '+esc(periodLabel)+'。</div>';
  }
  h += '<div class="section-title">| 一、店铺漏斗 <span class="sub">'+esc(periodLabel)+'</span></div>';
  h += '<div class="card"><div class="kpi-grid">';
  var fun = getFunnel();
  fun.forEach(function(f){
    h += '<div class="kpi"><div class="k-label">'+esc(f.label)+'</div>';
    h += '<div class="k-val">'+fmt(f.fmt,f.cur)+'<small>'+(f.unit?' '+esc(f.unit):'')+'</small></div>';
    if(f.note) h += '<div class="k-meta"><span class="muted small">'+esc(f.note)+'</span></div>';
    h += '<div class="k-meta">'+wowHtml(f.wow)+'<span class="gap">'+gapHtml(f.cur,f.rival_avg,f.rival_good,f.lower_better)+'</span></div></div>';
  });
  h += '</div></div>';

  // 二、承接效率
  h += '<div class="section-title">| 二、承接效率 <span class="sub">回复三项 vs 同行优秀/平均</span></div>';
  h += '<div class="card"><div class="kpi-grid">';
  getBearing().forEach(function(b){
    var bad = b.lower_better ? (b.cur > b.rival_avg) : (b.cur < b.rival_avg);
    var dot = bad ? '<span class="dot red"></span>未达标' : '<span class="dot green"></span>达标';
    h += '<div class="kpi"><div class="k-label">'+dot+' '+esc(b.label)+'</div>';
    h += '<div class="k-val">'+fmt(b.fmt,b.cur)+'</div>';
    h += '<div class="k-meta"><span class="gap">'+gapHtml(b.cur,b.rival_avg,b.rival_good,b.lower_better)+'</span></div></div>';
  });
  h += '</div></div>';

  // 客服接待质量 by 子账号
  h += renderStaff();

  // 三、店铺健康 + 降星预警
  h += renderHealth();

  // 榜单
  // 榜单（周口径，月度时提示）
  h += weeklyOnlyNote();
  h += renderList('四、⭐ 上升趋势·零花费榜','没投广告但自然流量已出商机/高点击 → 零成本验证过，优先接广告预算','zero_cost','zero');
  h += renderList('五、💰 高效低耗榜','已投广告(有广告点击)且本周出商机 → 广告钱花得值、单商机成本低，加预算放大','high_eff_low_cost','eff');
  h += renderList('六、商机榜 Top50','询盘+TM 合并的商机榜，按商机量排序','opp','opp');
  h += renderList('七、💬 TM商机榜','纯 TM 咨询（无询盘）也是商机，主动跟进转报价成交','tm','tm');
  h += renderList('八、点击率榜 Top20','搜索点击≥4过滤噪音；高CTR+0商机=主图勾人但详情没转化','ctr','ctr');
  h += renderNewProduct();

  // 广告拆解
  h += renderAd();

  // 国家地区
  h += renderCountry();

  // 市场机会
  h += renderMarket();

  // 流量渠道
  h += renderChannel();

  // 买家 L1+
  h += renderBuyerL1();

  // 0效果产品
  h += renderZeroEffect();

  // 本期总结
  h += renderSummary();

  el.innerHTML = h;
}

function funnelVal(key){ var f=(D.funnel||[]).find(function(x){return x.key===key}); return f? f.cur : null; }

/* ---------- 客服子账号 ---------- */
function renderStaff(){
  var s=D.staff_cs||[];
  var avg5=D.store_avg_5min, avgR=D.store_avg_reply;
  var h=weeklyOnlyNote()+'<div class="insight warn">⚠ 客服跟进阶段/报价/样品/未成交原因/买家身份接口未接入，当前只有回复时效（过程指标），无法判断成交能力。</div><div class="section-title">客服接待质量 · 按子账号 <span class="sub">回复三项低于本店均值/达标线的标红，附下一步建议</span></div>';
  h+='<div class="card"><div class="tbl-scroll"><table><thead><tr>'+
    '<th>客服(子账号)</th><th class="num">TM接待</th><th class="num">询盘PV</th><th class="num">成交($)</th><th class="num">成交单</th>'+
    '<th class="num">极速回复率</th><th class="num">及时回复率</th><th class="num">平均回复时长</th><th class="num">商机→成交</th>'+
    '<th>超12h未回</th><th>预警 & 下一步建议</th></tr></thead><tbody>';
  s.forEach(function(x){
    var bad5 = x.fst5min!=null && x.fst5min < avg5;
    var badR = x.avg_reply!=null && x.avg_reply > avgR;
    var hasIssue = x.over12h>0 || x.notfollow>0 || x.onlyhi>0 || x.unsat>0 || x.l3l4>0;
    var sug=''; var parts=[];
    // 成交/商机诊断
    if(x.rcvd_amt>0 && x.bus_to_ord!=null && x.bus_to_ord < 2){ parts.push('成交 '+money(x.rcvd_amt)+' 但商机转化率仅 '+pct(x.bus_to_ord)+'，把「怎么聊到成交」沉淀成话术SOP，复制给零成交的同事'); }
    else if(x.rcvd_amt>0){ parts.push('达标（成交 '+money(x.rcvd_amt)+' '+num(x.order_cnt)+'单），团队转化标杆，带教零成交成员'); }
    else if(x.tm>=40){ parts.push('TM接待 '+num(x.tm)+' 次却 0 成交——不是没商机，是跟单没闭环，逐条复盘卡在报价/MOQ/样品哪一步'); }
    else if(x.tm>=10){ parts.push('商机 '+num(x.tm)+' 次没成交，逐单复盘卡点：报价没回→换价格方案，要样品→快速寄样'); }
    else { parts.push('商机量少('+num(x.tm)+')，先保承接速度，同时查询盘分流是否被大账号截流'); }
    // 质检预警（按具体问题）
    if(x.l3l4>0) parts.push('有 L3L4 大买家 '+x.l3l4+' 个，主管亲自跟进，别让小客服接大客户');
    if(x.over12h>0) parts.push('超12h未回 '+x.over12h+' 次=直接丢商机，设交接机制或轮值');
    if(x.notfollow>0) parts.push('未跟进 '+x.notfollow+' 次，买家问完没下文=没追单，48h 内二次触达');
    if(x.onlyhi>0) parts.push('只发 Hi '+x.onlyhi+' 次，开场白太弱，改「产品+MOQ+交期」三段式');
    if(x.unsat>0) parts.push('差评 '+x.unsat+' 次，逐单复盘不满原因（价格/交期/售后）');
    // 回复速度
    if(bad5) parts.push('极速回复 '+pct(x.fst5min)+' 远低于店均 '+pct(avg5)+'，挂 30s 欢迎语+AI首响');
    if(badR) parts.push('平均回复 '+x.avg_reply+'h 过慢，开强提醒，目标压到 '+avgR+'h 内');
    sug=parts.join('；');
    var statusCls = (bad5||badR||hasIssue)? 'red':'green';
    h+='<tr><td><div class="thumb-cell">'+pimg(x.avatar)+'<b>'+esc(x.name)+'</b></div></td>'+
      '<td class="num">'+num(x.tm)+'</td><td class="num">'+num(x.fb_pv)+'</td><td class="num">'+money(x.rcvd_amt)+'</td><td class="num">'+num(x.order_cnt)+'</td>'+
      '<td class="num '+(bad5?'red':'')+'">'+pct(x.fst5min)+'</td>'+
      '<td class="num">'+pct(x.reply_rate)+'</td>'+
      '<td class="num '+(badR?'red':'')+'">'+(x.avg_reply!=null? x.avg_reply+'h':'—')+'</td>'+
      '<td class="num">'+pct(x.bus_to_ord)+'</td>'+
      '<td class="num '+(x.over12h>0?'red':'')+'">'+num(x.over12h)+'</td>'+
      '<td class="'+statusCls+'">'+esc(sug)+'</td></tr>';
  });
  h+='</tbody></table></div>';
  h+='<div class="insight">行业基准对标：全店极速回复率 '+pct(avg5)+' vs 同行平均 '+pct(bearingVal('fst5min','rival_avg'))+' / 同行优秀 '+pct(bearingVal('fst5min','rival_good'))+'。行动：①高峰启用AI 30s欢迎语 ②给标红客服设个人回复KPI ③开启强提醒避免漏消息。</div>';
  h+=noteBox('staff');
  h+='</div>';
  return h;
}
function bearingVal(key, field){ var b=(D.bearing||[]).find(function(x){return x.key===key}); return b? b[field]: null; }

/* ---------- 店铺健康 ---------- */
function renderHealth(){
  var hh=D.health||{};
  var sr=D.star_rating||null;
  var h=weeklyOnlyNote()+'<div class="section-title">| 三、店铺健康（星等级 / 产品分层）</div>';
  h+='<div class="card"><div class="grid2">';
  // 星等级（真实数据）
  if(sr){
    var tr0 = (sr.tracks||[])[0] || {};
    var tr1 = (sr.tracks||[])[1] || {};
    var alert = tr0.alert||{};
    var stars = '';
    for(var s=0;s<(sr.level_star||0);s++) stars+='★';
    for(var s=sr.level_star||0;s<5;s++) stars+='☆';
    h+='<div><h4>本月星等级</h4><div class="k-val" style="color:#e8a200">'+stars+' <small style="font-size:14px">'+sr.level_star+'星</small></div>'+
       '<div class="mt8">'+(alert.down? '<span class="tag danger">⚠ 预测降星</span>' : '<span class="tag good">✓ 预测保星（'+esc(alert.title||'')+'）</span>')+'</div></div>';
    // 综合分进度
    h+='<div><h4>星等级综合分（'+esc(tr0.track_name||'')+'）</h4><div class="flex"><div class="progress-bar" style="max-width:100%;height:10px"><i style="width:'+(tr0.progress?tr0.progress.position:0)+'%"></i></div><b>'+esc(tr0.progress?tr0.progress.text:'')+'</b></div>';
    if(tr1.progress) h+='<div class="small muted mt8">'+esc(tr1.track_name)+'：'+esc(tr1.progress.text)+'（位置 '+tr1.progress.position+'）</div>';
    // 短板
    if((alert.indicators||[]).length){
      h+='<div class="insight danger mt8"><b>降星短板</b>：';
      alert.indicators.forEach(function(ai){ h+='<span class="tag danger">'+esc(ai.name)+' '+num(ai.value)+'（'+(ai.score_delta>0?'+':'')+Math.round(ai.score_delta)+'分）</span> '; });
      h+='</div>';
    }
    // 能力项达标
    if((tr0.indicators||[]).length){
      h+='<div class="small mt8">';
      tr0.indicators.forEach(function(i){ h+='<div>'+(i.completed?'<span class="dot green"></span>':'<span class="dot red"></span>')+esc(i.title)+' <span class="muted">（当前 '+esc(i.current)+' vs 门槛 '+esc(i.threshold)+'）</span></div>'; });
      h+='</div>';
    }
  } else {
    h+='<div><h4>本月星等级</h4><div class="k-val"><span class="muted">未接入</span></div><div class="insight danger">星等级数据未接入（icbu-starrating 接口未返回）。</div></div>';
  }
  // 产品分层
  h+='<div><h4>产品分层（'+num(hh.valid_cnt)+' 在架）</h4><div class="kpi-grid">';
  (hh.levels||[]).forEach(function(l){
    h+='<div class="kpi"><div class="k-label">'+esc(l.label)+'</div><div class="k-val">'+num(l.count)+'</div></div>';
  });
  h+='</div><div class="mt8 small muted">有询盘产品 '+num(hh.inquiry_products)+' · 零询盘产品 '+num(hh.zero_inquiry)+'（'+pct((hh.valid_cnt?hh.zero_inquiry*100/hh.valid_cnt:0))+'）</div></div>';
  h+='</div>';
  /* Health totals use the current audited period, no generated stale note. */
  h+='</div>';
  return h;
}

/* ---------- 榜单通用渲染 ---------- */
function renderList(title, sub, key, noteKey){
  var items=getLists()[key]||[];
  var h='<div class="section-title">'+title+' <span class="sub">'+sub+'</span></div>';
  // 类目筛选
  var cats={}; items.forEach(function(p){ if(p.category) cats[p.category]=1; });
  var catList=Object.keys(cats);
  var fid='filter_'+noteKey;
  h+='<div class="card">';
  if(catList.length){
    h+='<div class="flex mb8"><select id="'+fid+'" onchange="renderListBody(\''+noteKey+'\')" style="padding:4px"><option value="">类目：全部</option>'+
      catList.map(function(c){return '<option>'+esc(c)+'</option>';}).join('')+'</select><span class="muted small">共 '+items.length+' 品</span></div>';
  }
  h+='<div class="tbl-scroll"><table><thead><tr>'+
    '<th>#</th><th>产品</th><th class="num">全店曝光</th><th class="num">全店点击</th><th class="num">点击率</th><th class="num">商机</th><th class="num">广告曝光</th><th class="num">广告点击</th><th>AI评分</th><th>判定</th><th>建议（按品定制）</th></tr></thead><tbody id="body_'+noteKey+'"></tbody></table></div>';
  h+=noteBox(noteKey)+'</div>';
  window['_listItems_'+noteKey]=items;
  setTimeout(function(){ renderListBody(noteKey); }, 0);
  return h;
}
function renderListBody(noteKey){
  var body=document.getElementById('body_'+noteKey);
  if(!body) return;
  var items=window['_listItems_'+noteKey]||[];
  var fc=(document.getElementById('filter_'+noteKey)||{}).value||'';
  var list=items.filter(function(p){ return !fc || p.category===fc; });
  var h='';
  list.slice(0,50).forEach(function(p,i){
    var s=scoreOf(p.product_id);
    h+='<tr><td>'+(i+1)+'</td>'+
      '<td><div class="thumb-cell">'+pimg(p.main_image)+'<div><div class="t">'+plink(p)+'</div><div class="pid">'+esc(p.category||'')+' · '+esc(p.product_id)+'</div></div></div></td>'+
      '<td class="num">'+num(p.total_imps)+'</td><td class="num">'+num(p.total_clk)+'</td><td class="num">'+pct(p.total_ctr)+'</td>'+
      '<td class="num">'+num(p.opp)+'</td><td class="num">'+num(p.ad_imps)+'</td><td class="num">'+num(p.ad_clk)+'</td>'+
      '<td>'+gradeTag(s)+'</td>'+
      '<td>'+tag(p.label,p.label_typ)+' '+tag(p.ad_label,p.ad_typ)+'</td>'+
      '<td class="small">'+(s?conciseAdvice(s):esc(p.sug))+'</td></tr>';
  });
  body.innerHTML=h;
}

/* ---------- 新品追踪 ---------- */
function dimMini(s){
  if(!s || !s.dims) return '';
  var out=[];
  s.dims.forEach(function(d){
    if(d.level==='好') out.push('<span class="tag good">'+esc(d.name)+'好</span>');
  });
  s.dims.forEach(function(d){
    if(d.level==='差'||d.level==='风险') out.push('<span class="tag danger">'+esc(d.name)+d.level+'</span>');
  });
  return out.join(' ');
}
function getTrack(){ try{ return JSON.parse(localStorage.getItem('v4_new_track')||'{}'); }catch(e){ return {}; } }
function setTrack(obj){ try{ localStorage.setItem('v4_new_track', JSON.stringify(obj)); }catch(e){} }
function isTracked(pid){ return getTrack()[pid]==='on'; }
function toggleTrack(pid, on){ var t=getTrack(); if(on){ t[pid]='on'; } else { delete t[pid]; } setTrack(t); }
function clearAllTrack(){ setTrack({}); if(typeof renderNewProduct==='function') renderNewProduct(); }
function toggleManualTrack(pid, btn){
  var t=getTrack();
  if(t[pid]==='manual'){ delete t[pid]; if(btn){btn.textContent='☆追踪';btn.classList.remove('on');} }
  else { t[pid]='manual'; if(btn){btn.textContent='★追踪中';btn.classList.add('on');} }
  setTrack(t);
}
function isManualTracked(pid){ return getTrack()[pid]==='manual'; }
function getNewDates(){ try{ return JSON.parse(localStorage.getItem('v4_new_dates')||'{}'); }catch(e){ return {}; } }
function setNewDate(pid, d){ var m=getNewDates(); if(d){ m[pid]=d; } else { delete m[pid]; } try{ localStorage.setItem('v4_new_dates', JSON.stringify(m)); }catch(e){} }

function newProdDate(p){ return getNewDates()[p.product_id] || p.first_seen_at || ''; }
function newProdStatus(p){
  if((p.inquiries||0)>=1) return ['已出询盘·转正','good'];
  if((p.total_clk||0)>=4) return ['有热度·观察','info'];
  return ['冷启动中','muted'];
}

function renderNewProduct(){
  var cand=D.new_candidates||[];
  var ds=(document.getElementById('np_from')||{}).value||'';
  var de=(document.getElementById('np_to')||{}).value||'';
  // 追踪名单：默认有 first_seen_at 的都在（保持旧行为），取消勾选=排除，手改日期优先
  var tracked=cand.filter(function(p){
    if(!isTracked(p.product_id)) return false;              // 取消勾选 = 不是新品
    if(!p.first_seen_at && !getNewDates()[p.product_id]) return false; // 无上架日期且未手改 → 不显示
    var d=newProdDate(p);
    if(ds && d < ds) return false;
    if(de && d > de) return false;
    return true;
  }).sort(function(a,b){ return window.dashboardProductOrder.compare(a,b); });

  var h='<div class="section-title">九、🆕 新品追踪 <span class="sub">手动勾选哪些是新品（改日期≠上架）。点「管理新品清单」从全部产品挑；上架日期可点单元格直改</span></div>';
  h+='<div class="flex mb8" style="flex-wrap:wrap;gap:8px;align-items:center">'+
    '<button class="btn" onclick="openNewManager()">➕ 管理新品清单</button>'+
    '<button class="btn" onclick="clearAllTrack()">取消全选</button>'+
    '<span class="muted small">上架日期从</span>'+
    '<input type="date" id="np_from" value="'+esc(ds)+'" onchange="renderNewProduct()" style="padding:4px">'+
    '<span class="muted small">到</span>'+
    '<input type="date" id="np_to" value="'+esc(de)+'" onchange="renderNewProduct()" style="padding:4px">'+
    '<span class="muted small">共 '+tracked.length+' 个追踪新品</span>'+
  '</div>';
  h+='<div class="card"><div class="tbl-scroll"><table><thead><tr>'+
    '<th class="num">追踪</th><th>#</th><th>新品</th><th>上架日期</th><th>AI评分</th><th class="num">全店曝光</th><th class="num">全店点击</th><th class="num">CTR</th><th class="num">商机</th><th>状态</th></tr></thead><tbody>';
  tracked.forEach(function(p,i){
    var s=scoreOf(p.product_id);
    var d=newProdDate(p);
    var st=newProdStatus(p);
    h+='<tr><td class="num"><input type="checkbox"'+(isTracked(p.product_id)?' checked':'')+' onchange="toggleTrack(\''+p.product_id+'\', this.checked); renderNewProduct();"></td><td>'+(i+1)+'</td>'+
      '<td><div class="thumb-cell">'+pimg(p.main_image)+'<div><div class="t">'+plink(p)+'</div><div class="pid">'+esc(p.product_id)+' · '+esc(p.category||'')+'</div></div></div></td>'+
      '<td><input type="date" value="'+esc(d)+'" onchange="setNewDate(\''+p.product_id+'\', this.value)"></td>'+
      '<td>'+gradeTag(s)+'</td>'+
      '<td class="num">'+num(p.total_imps)+'</td><td class="num">'+num(p.total_clk)+'</td><td class="num">'+pct(p.total_ctr)+'</td>'+
      '<td class="num">'+num(p.opp)+'</td>'+
      '<td>'+tag(st[0],st[1])+'</td></tr>';
  });
  h+='</tbody></table></div>';
  h+='<div class="muted small">勾选=追踪此新品；取消=不是新品（如仅改过日期）。上架日期点单元格直改，或点「管理新品清单」批量挑。数据在本机保存（仅自己可见）。</div>';
  h+=noteBox('newprod')+'</div>';
  h='<div id="newprod_section">'+h+'</div>';
  var _ex=document.getElementById('newprod_section');
  if(_ex){ _ex.outerHTML=h; }
  return h;
}

function openNewManager(){
  var cand=D.new_candidates||[];
  var q=(document.getElementById('np_search')||{}).value||'';
  var list=cand.filter(function(p){ return !q || (p.title||'').toLowerCase().indexOf(q.toLowerCase())>=0 || p.product_id.indexOf(q)>=0; }).slice(0,300);
  var rows=list.map(function(p){
    var d=newProdDate(p);
    var chk=isTracked(p.product_id)?' checked':'';
    return '<tr><td class="num"><input type="checkbox" data-mpid="'+p.product_id+'"'+chk+' onchange="npSyncSelectAll()"></td>'+
      '<td><div class="thumb-cell">'+pimg(p.main_image)+'<div><div class="t">'+plink(p)+'</div><div class="pid">'+esc(p.product_id)+' · '+(p.first_seen_at||'无日期')+'</div></div></div></td>'+
      '<td><input type="date" data-mdate="'+p.product_id+'" value="'+esc(d)+'"></td>'+
      '<td class="num">'+num(p.total_clk)+'</td><td class="num">'+num(p.opp)+'</td></tr>';
  }).join('');
  var html='<div id="npModal" style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9000;display:flex;align-items:center;justify-content:center;font-family:-apple-system,Segoe UI,Microsoft YaHei,sans-serif;">'+
    '<div style="background:#fff;border-radius:12px;width:min(980px,94vw);max-height:86vh;display:flex;flex-direction:column;padding:20px;">'+
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;"><h4 style="margin:0">管理新品清单 <span class="muted small" style="font-weight:normal">勾选=新品，取消=不是新品；上架日期可直接改</span></h4><button class="btn" onclick="closeNewManager()">✕</button></div>'+
    '<div style="margin-bottom:8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><input id="np_search" placeholder="搜产品标题或ID..." style="padding:6px;width:300px"><button class="btn" type="button" onclick="npToggleAll(true)">全选</button><button class="btn" type="button" onclick="npToggleAll(false)">取消全选</button></div>'+
    '<div style="flex:1;overflow:auto"><table><thead><tr><th class="num"><input type="checkbox" id="npSelectAll" onchange="npToggleAll(this.checked)" title="全选/取消全选" style="cursor:pointer"></th><th>产品</th><th>上架日期</th><th class="num">全店点击</th><th class="num">商机</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+
    '<div style="margin-top:12px;text-align:right"><button class="btn btn-primary" onclick="saveNewManager()">保存并关闭</button></div>'+
    '</div></div>';
  var old=document.getElementById('npModal'); if(old) old.remove();
  var dv=document.createElement('div'); dv.innerHTML=html; document.body.appendChild(dv.firstChild);
  var si=document.getElementById('np_search');
  si.oninput=function(){ si.dataset.v=si.value; openNewManager(); var n=document.getElementById('np_search'); n.value=si.dataset.v; n.focus(); };
  npSyncSelectAll();
}
function closeNewManager(){ var m=document.getElementById('npModal'); if(m) m.remove(); }
function saveNewManager(){
  var t=getTrack();
  document.querySelectorAll('#npModal [data-mpid]').forEach(function(cb){ if(cb.checked){ t[cb.dataset.mpid]='on'; } else { delete t[cb.dataset.mpid]; } });
  setTrack(t);
  var dates=getNewDates();
  document.querySelectorAll('#npModal [data-mdate]').forEach(function(inp){ var pid=inp.dataset.mdate; if(inp.value){ dates[pid]=inp.value; } else { delete dates[pid]; } });
  try{ localStorage.setItem('v4_new_dates', JSON.stringify(dates)); }catch(e){}
  closeNewManager();
  renderNewProduct();
}
function npToggleAll(on){
  document.querySelectorAll('#npModal [data-mpid]').forEach(function(cb){ cb.checked = on; });
  var sa = document.getElementById('npSelectAll');
  if(sa){ sa.checked = on; sa.indeterminate = false; }
}
function npSyncSelectAll(){
  var cbs = document.querySelectorAll('#npModal [data-mpid]');
  var all = cbs.length > 0, any = false;
  cbs.forEach(function(cb){ if(cb.checked){ any = true; } else { all = false; } });
  var sa = document.getElementById('npSelectAll');
  if(sa){ sa.checked = all; sa.indeterminate = any && !all; }
}

/* ---------- 广告拆解（真实计划层）---------- */
function renderAd(){
  var ap=D.ad_plans||null;
  var h=weeklyOnlyNote()+'<div class="insight warn">⚠ 关键词级搜索广告（直通车）10 个计划全暂停、本周 0 花费 → 无关键词/产品搜索数据（是「没投」不是接口缺）。全站推产品级数据见下方「产品级全站推 Top」。</div><div class="section-title">| 广告花费拆解 <span class="sub">账户总览 + 计划层逐个判定</span></div>';
  if(!ap || !ap.account){ 
    h+='<div class="card"><div class="muted">广告账户花费/计划层未接入：直通车 10 个计划全暂停（0 花费），无可展示花费/ROI；全站推产品级曝光/点击已在上方榜单展示。真实花费需 P4P 账户接口开放（当前未接入）。</div>'+noteBox('ad')+'</div>'; return h;
  }
  var a=ap.account;
  h+='<div class="card">';
  h+='<div class="kpi-grid">'+
    '<div class="kpi"><div class="k-label">'+periodWord()+'广告花费</div><div class="k-val">¥'+num(a.spend)+'</div></div>'+
    '<div class="kpi"><div class="k-label">点击 / 曝光</div><div class="k-val">'+num(a.clicks)+'<small> / '+num(a.impressions)+'</small></div></div>'+
    '<div class="kpi"><div class="k-label">点击成本 CPC</div><div class="k-val">¥'+num(a.cpc)+'</div></div>'+
    '<div class="kpi"><div class="k-label">商机量</div><div class="k-val">'+num(a.opp_cnt)+'<small>（L1+ '+num(a.l1_opp)+'）</small></div></div>'+
    '<div class="kpi"><div class="k-label">单商机成本</div><div class="k-val">¥'+num(a.cpl)+'</div></div>'+
    '<div class="kpi"><div class="k-label">商机转化率</div><div class="k-val">'+num(a.opp_rate)+'%</div></div>'+
    '<div class="kpi"><div class="k-label">TM / 询盘 / 订单</div><div class="k-val">'+num(a.tm)+'<small> / '+num(a.inquiry)+' / '+num(a.orders)+'</small></div></div>'+
  '</div>';
  h+='<div class="insight info">'+(ap.search_note||'')+'。单询盘成本 = ¥'+num(a.spend)+' ÷ '+num(a.inquiry)+' 询盘 ≈ ¥'+num(Math.round(a.spend/Math.max(1,a.inquiry)))+'，单商机成本 ¥'+num(a.cpl)+'。</div>';
  // 计划层判定表
  h+='<div class="tbl-scroll"><table><thead><tr><th>计划</th><th class="num">花费</th><th class="num">点击</th><th class="num">CPC</th><th class="num">CTR</th><th class="num">商机</th><th class="num">单商机成本</th><th class="num">L1+占比</th><th class="num">TM/询盘/单</th><th>判定</th><th>建议</th></tr></thead><tbody>';
  (ap.campaigns||[]).forEach(function(c){
    h+='<tr><td><div><b>'+esc(c.name)+'</b></div><div class="pid">'+esc(c.id)+' · 预算¥'+num(c.budget)+' · '+num(c.products)+'品</div></td>'+
      '<td class="num">¥'+num(c.spend)+'</td><td class="num">'+num(c.clicks)+'</td><td class="num">¥'+num(c.cpc)+'</td><td class="num">'+num(c.ctr)+'%</td>'+
      '<td class="num">'+num(c.opp_cnt)+'</td><td class="num">¥'+num(c.cpl)+'</td><td class="num">'+num(c.l1_ratio)+'%</td>'+
      '<td class="num">'+num(c.tm)+' / '+num(c.inquiry)+' / '+num(c.orders)+'</td>'+
      '<td>'+tag(c.judgment,c.judgment_type)+'</td><td class="muted">'+esc(c.suggestion)+'</td></tr>';
  });
  h+='</tbody></table></div>'+noteBox('ad')+'</div>';
  // 产品级全站推 Top（4.5）
  var adp=D.ad_products||[];
  if(adp.length){
    h+='<div class="card"><h4>产品级全站推 Top '+Math.min(20,adp.length)+' <span class="sub">按点击降序</span></h4>';
    h+='<div class="tbl-scroll"><table><thead><tr><th>#</th><th>产品</th><th class="num">曝光</th><th class="num">点击</th><th class="num">CTR</th><th class="num">询盘</th><th class="num">TM</th><th class="num">订单</th><th class="num">商机</th><th class="num">商机转化率</th><th class="num">L1+点击占比</th></tr></thead><tbody>';
    adp.slice(0,20).forEach(function(p,i){
      h+='<tr><td>'+(i+1)+'</td><td class="small"><div class="t">'+plink(p)+'</div><div class="pid">'+esc(p.product_id)+'</div></td>'+
        '<td class="num">'+num(p.imps)+'</td><td class="num">'+num(p.clk)+'</td><td class="num">'+num(p.ctr)+'%</td>'+
        '<td class="num">'+num(p.inquiries)+'</td><td class="num">'+num(p.tm)+'</td><td class="num">'+num(p.orders)+'</td>'+
        '<td class="num">'+num(p.opp)+'</td><td class="num">'+num(p.opp_rate)+'%</td><td class="num">'+num(p.l1_rate)+'%</td></tr>';
    });
    h+='</tbody></table></div></div>';
  }
  return h;
}

/* ---------- 国家地区分析（行业 + 我的） ---------- */
function renderCountry(){
  var vs=D.v4_sections||null;
  var cm = (vs && vs.country_merged) || [];
  var h=weeklyOnlyNote()+'<div class="section-title">| 国家/地区效果 <span class="sub">行业需求/增速/供需 × 我的转化，看出该地区值不值得做、我做得怎么样</span></div>';
  if(!cm.length){ h+='<div class="card"><div class="muted">国家地区数据未接入。</div></div>'; return h; }
  var top=cm[0];
  var hot=cm.filter(function(c){return (c.ind_yoy||0)>30;});
  var behind=cm.filter(function(c){return c.vcls==='danger' && c.my_uv>=10;});
  h+='<div class="card">';
  h+='<div class="insight"><b>行业最大市场 '+esc(top.country)+'</b>（询盘 '+num(top.ind_ab)+'，供需比 '+num(top.ind_sd)+'）。'+
    (hot.length?'<span style="color:var(--green)"><b>高增长国家</b>：'+hot.slice(0,4).map(function(c){return esc(c.country)+' +'+num(c.ind_yoy)+'%';}).join('、')+'。</span>':'')+
    (behind.length?'<span style="color:var(--red)"><b>行业热但我转化落后</b>：'+behind.slice(0,4).map(function(c){return esc(c.country)+'（行业转化'+num(c.ind_dab)+'% vs 我'+num(c.my_conv)+'%）';}).join('、')+'。</span>':'')+
  '</div>';
  h+='<div class="tbl-scroll"><table><thead><tr><th>国家</th><th class="num">行业询盘</th><th class="num">增速</th><th class="num">供需比</th><th class="num">行业转化</th><th class="num">我的访客</th><th class="num">我的商机率</th><th>判定</th></tr></thead><tbody>';
  cm.slice(0,15).forEach(function(c){
    var sdCls = (c.ind_sd||0)>=70 ? 'green' : '';
    h+='<tr><td><b>'+esc(c.country)+'</b></td><td class="num">'+num(c.ind_ab)+'</td><td class="num '+(c.ind_yoy>0?'green':'red')+'">'+(c.ind_yoy>0?'+':'')+num(c.ind_yoy)+'%</td><td class="num '+sdCls+'">'+num(c.ind_sd)+'</td><td class="num">'+num(c.ind_dab)+'%</td><td class="num">'+num(c.my_uv)+'</td><td class="num">'+num(c.my_conv)+'%</td><td>'+tag(c.verdict,c.vcls)+'</td></tr>';
  });
  h+='</tbody></table></div>';
  h+='<div class="muted small">供需比仅作观察，不能仅据数值认定蓝海；行业转化是该国保健食品类目平均商机率，与「我的商机率」对比即知我是否落后于行业。</div>';
  h+=noteBox('country')+'</div>';
  return h;
}

/* ---------- 市场机会产品推荐（过滤擦边 + 带图） ---------- */
function renderMarket(){
  var vs=D.v4_sections||null;
  var hp = (vs && vs.hot_products_clean) || [];
  var banned = (vs && vs.banned_count) || 0;
  var kw = (vs && vs.keywords) || [];
  var hc=D.hot_categories||[];
  var h='<div class="section-title">| 市场机会·产品推荐 <span class="sub">已过滤玛卡/壮阳/减肥等擦边 C 端，关键词初筛候选，合规与商业适配尚待核验，带图</span></div>';
  h+='<div class="card">';
  if(banned>0){
    h+='<div class="insight warn">已过滤 '+banned+' 个擦边/减肥 C 端热销品（玛卡壮阳、私处紧致、丰臀、减肥胶囊等）。行业热销榜被这类词霸占，你避开它们本身就是差异化和合规护城河。</div>';
  }
  if(hc.length){
    h+='<div class="insight"><b>高增长类目</b>：';
    hc.forEach(function(c){ h+='<span class="tag '+(c.inquiry_yoy>20?'good':'neutral')+'">'+esc(c.name)+' +'+num(c.inquiry_yoy)+'% · 供需比 '+num(c.supply_demand)+'</span> '; });
    h+='</div>';
  }
  // 本店能力底座（4.8：能力匹配——配方/剂型/认证/试单MOQ/交期）
  var cap=D.company_capabilities||{};
  if(cap['剂型与MOQ']){
    h+='<div class="card"><h4>🏭 本店能力底座（上新能力匹配）</h4>';
    h+='<div class="insight">'+esc(cap['定位']||'')+'｜配方库 '+esc(cap['配方库']||'')+'｜交期 '+esc(cap['交期']||'')+'｜认证 '+esc(cap['认证']||'')+'｜市场 '+esc(cap['市场经验']||'')+'</div>';
    h+='<div class="tbl-scroll"><table><thead><tr><th>剂型</th><th>条件</th><th class="num">试单 MOQ</th></tr></thead><tbody>';
    cap['剂型与MOQ'].forEach(function(m){
      h+='<tr><td>'+esc(m['剂型'])+'</td><td class="small muted">'+esc(m['条件']||'')+'</td><td class="num">'+esc(m['MOQ']||'')+'</td></tr>';
    });
    h+='</tbody></table></div>';
    h+='<div class="muted small">⚠ '+esc(cap['待人工确认']||'')+'。合规红线：'+esc((cap['合规红线']||[]).join('；'))+'。</div>';
    h+='</div>';
  }
  // 热销品（带图）
  if(hp.length){
    h+='<div class="grid3">';
    hp.slice(0,18).forEach(function(p){
      var url=p.url||(p.product_id?('https://www.alibaba.com/product-detail/_'+p.product_id+'.html'):'');
      var clickAttr=url?(' class="prod-card clickable" data-url="'+esc(url)+'" onclick="window.open(this.getAttribute(\'data-url\'),\'_blank\')"'):' class="prod-card"';
      h+='<div'+clickAttr+'><div class="thumb">'+(p.image? '<img src="'+esc(p.image)+'" loading="lazy" onerror="this.style.display=\'none\'">':'<div class="noimg">无图</div>')+'</div>'+
        '<div class="t small">'+esc((p.title||'').slice(0,55))+'</div>'+
        '<div class="muted small">'+esc(p.category||'')+'</div>'+
        (p.reason?'<div class="reason small">'+esc(p.reason)+'</div>':'')+
        (url?'<div class="jump small">🔗 查看商品 ↗</div>':'')+'</div>';
    });
    h+='</div>';
  }
  h+=noteBox('market')+'</div>';
  return h;
}

/* ---------- 流量渠道结构 ---------- */
function renderChannel(){
  var vs=D.v4_sections||null;
  var ch=(vs&&vs.channels)||[];
  var h='<div class="section-title">| 流量渠道结构 <span class="sub">四类流量占比 + 各自商机率，看流量是否健康</span></div>';
  if(!ch.length){ h+='<div class="card"><div class="muted">渠道数据未接入。</div></div>'; return h; }
  var best=null; ch.forEach(function(c){ if(!best||c.ab_rate>best.ab_rate) best=c; });
  var tot=0; ch.forEach(function(c){ tot+=c.uv; });
  h+='<div class="card">';
  h+='<div class="insight">'+periodWord()+'流量 '+num(tot)+' 访客。四渠道：'+ch.map(function(c){return esc(c.channel)+' '+num(c.share)+'%';}).join(' / ')+'。<b>商机率最高的是 '+esc(best.channel)+'（'+num(best.ab_rate)+'%）</b>——这是高质量流量，值得深挖。'+
    '搜索'+num(ch.length?ch[0].share:0)+'%+自增'+num(ch.length>1?ch[1].share:0)+'% 是自然基本盘（约67%），广告依赖度尚可；场景（含全站推广告）'+num(ch.length>2?ch[2].share:0)+'% 在成长。</div>';
  h+='<div class="tbl-scroll"><table><thead><tr><th>渠道</th><th class="num">访客</th><th class="num">占比</th><th class="num">商机率</th><th>解读</th></tr></thead><tbody>';
  ch.forEach(function(c){
    var lab = c.ab_rate>=20 ? '优质流量' : (c.ab_rate>=10?'正常':'低效·排查');
    var cls = c.ab_rate>=20?'good':(c.ab_rate>=10?'neutral':'warn');
    h+='<tr><td><b>'+esc(c.channel)+'</b></td><td class="num">'+num(c.uv)+'</td><td class="num">'+num(c.share)+'%</td><td class="num">'+num(c.ab_rate)+'%</td><td>'+tag(lab,cls)+'</td></tr>';
  });
  h+='</tbody></table></div>'+noteBox('channel')+'</div>';
  return h;
}

/* ---------- 买家 L1+ 分层 ---------- */
function renderBuyerL1(){
  var vs=D.v4_sections||null;
  var bi=(vs&&vs.buyer_ident)||[];
  var cl=(vs&&vs.country_l1)||[];
  var h='<div class="section-title">| 买家 L1+ 分层 <span class="sub">L1+=近180天有下单能力的高价值买家，看流量质量</span></div>';
  h+='<div class="card">';
  var bs=vs.b2b_stats||null;
  if(bi.length && bs && bs.available){
    h+='<div class="insight">买家身份：'+bi.map(function(x){return esc(x.ident)+' '+num(x.all_rate)+'%';}).join(' / ')+'。<b>B2B 占比 '+num(bs.b2b_rate)+'%</b>（'+esc(bs.definition)+'）；线上零售商 '+num(bs.online_retail_rate)+'% 单独统计。口径：'+esc(bs.scope)+'。</div>';
  } else {
    h+='<div class="insight warn">买家身份画像数据未接入（customer_profile_snapshot 为空），B2B 占比暂无法计算。请重新拉取数据参谋「买家画像」接口。</div>';
  }
  if(bi.length){
    h+='<div class="tbl-scroll"><table><thead><tr><th>买家身份</th><th class="num">全部买家占比</th><th class="num">L1+ 占比</th></tr></thead><tbody>';
    bi.forEach(function(x){
      h+='<tr><td>'+esc(x.ident)+'</td><td class="num">'+num(x.all_rate)+'%</td><td class="num">'+(x.l1_rate!=null?num(x.l1_rate)+'%':'—')+'</td></tr>';
    });
    h+='</tbody></table></div>';
  }
  if(cl.length){
    h+='<h4>L1+ 高价值买家国家分布（vs 全部）</h4>';
    h+='<div class="tbl-scroll"><table><thead><tr><th>国家</th><th class="num">全部占比</th><th class="num">L1+占比</th><th>质量</th></tr></thead><tbody>';
    cl.forEach(function(x){
      var l1share = x.l1_rate!=null ? x.l1_rate : 0;
      var q = l1share>0 && x.all_rate>0 && (l1share >= x.all_rate*1.1) ? 'L1+富集·高质量' : (l1share>0?'正常':'样本少');
      var qc = q==='L1+富集·高质量'?'good':'neutral';
      h+='<tr><td><b>'+esc(x.name)+'</b></td><td class="num">'+num(x.all_rate)+'%</td><td class="num">'+num(l1share)+'%</td><td>'+tag(q,qc)+'</td></tr>';
    });
    h+='</tbody></table></div>';
  }
  h+=noteBox('buyerl1')+'</div>';
  return h;
}

/* ---------- 关键词机会 ---------- */
function renderKeyword(){
  var vs=D.v4_sections||null;
  var kw=(vs&&vs.keywords)||[];
  var h='<div class="section-title">| 关键词机会 <span class="sub">行业热门搜索词（已过滤擦边），合规 B 端词是蓝海</span></div>';
  h+='<div class="card">';
  if(kw.length){
    h+='<div class="insight"><b>关键发现</b>：保健食品行业搜索词榜被「玛卡壮阳/私处紧致/丰臀/减肥」霸占，这些词竞争激烈且合规风险高。过滤后剩下的合规 B 端机会词：'+kw.map(function(k){return '<span class="tag good">'+esc(k.kw)+'</span>';}).join(' ')+'。把这些词布局进标题/属性/详情，是低竞争、合规的精准流量。</div>';
    h+='<div class="tbl-scroll"><table><thead><tr><th>关键词</th><th class="num">热度指数</th><th>建议动作</th></tr></thead><tbody>';
    kw.forEach(function(k){
      var act = k.idx>=80 ? '高热度·必布局' : '布局长尾';
      h+='<tr><td><b>'+esc(k.kw)+'</b></td><td class="num">'+num(k.idx)+'</td><td>'+tag(act, k.idx>=80?'good':'neutral')+'</td></tr>';
    });
    h+='</tbody></table></div>';
  } else {
    h+='<div class="muted">关键词数据未接入。</div>';
  }
  h+=noteBox('keyword')+'</div>';
  return h;
}

/* ---------- 0效果产品板块 ---------- */
function renderZeroEffect(){
  var ze=(D.v4_scores&&D.v4_scores.zero_effect)||[];
  var waste=ze.filter(function(s){return s.ze_type==='曝光浪费';});
  var sleep=ze.filter(function(s){return s.ze_type==='彻底沉睡';});
  var h='<div class="section-title">| 🚫 0效果产品 <span class="sub">0商机0点击，分「曝光浪费」和「彻底沉睡」两类处置</span></div>';
  h+='<div class="card">';
  h+='<div class="insight">共 '+num(ze.length)+' 个 0 效果产品（0 商机 0 点击）。<b style="color:var(--orange)">曝光浪费 '+num(waste.length)+' 个</b>（有曝光没人点=主图/标题病），<b style="color:var(--muted)">彻底沉睡 '+num(sleep.length)+' 个</b>（零曝光=从未激活）。两类处置完全不同。</div>';
  // 曝光浪费
  if(waste.length){
    h+='<h4>① 曝光浪费（'+num(waste.length)+'个）：有曝光但没人点，改主图/标题</h4>';
    h+='<div class="tbl-scroll"><table><thead><tr><th>#</th><th>产品</th><th class="num">曝光</th><th>层级</th><th>AI评分</th><th>处置建议</th></tr></thead><tbody>';
    waste.slice(0,20).forEach(function(s,i){
      var act = s.cat_type==='maca'||s.cat_type==='detox' ? '合规改名后再救流量' : '首图重做(痛点钩子+认证)+标题补长尾';
      h+='<tr><td>'+(i+1)+'</td><td><div class="thumb-cell">'+pimg(s.main_image)+'<div class="t">'+plink(s,50)+'</div><div class="pid">'+esc(s.product_id)+'</div></div></td>'+
        '<td class="num">'+num(s.imps)+'</td><td>'+esc(s.prod_level||'')+'</td><td>'+gradeTag(s)+'</td>'+
        '<td class="small">'+act+'</td></tr>';
    });
    h+='</tbody></table></div>';
  }
  // 彻底沉睡
  if(sleep.length){
    h+='<h4>② 彻底沉睡（'+num(sleep.length)+'个）：零曝光，激活或下架</h4>';
    h+='<div class="tbl-scroll"><table><thead><tr><th>#</th><th>产品</th><th>层级</th><th>AI评分</th><th>处置建议</th></tr></thead><tbody>';
    sleep.slice(0,20).forEach(function(s,i){
      var act = s.prod_level==='低质品' ? '低质品+沉睡，建议下架换新' : '补结构化属性+主图6张+视频，进AI搜索池激活';
      h+='<tr><td>'+(i+1)+'</td><td><div class="thumb-cell">'+pimg(s.main_image)+'<div class="t">'+plink(s,50)+'</div><div class="pid">'+esc(s.product_id)+'</div></div></td>'+
        '<td>'+esc(s.prod_level||'')+'</td><td>'+gradeTag(s)+'</td>'+
        '<td class="small">'+act+'</td></tr>';
    });
    h+='</tbody></table></div>';
  }
  h+=noteBox('zeroeffect')+'</div>';
  return h;
}

/* ---------- 本期总结 ---------- */
function renderSummary(){
  var s=D.summary||{};
  var h='<div class="section-title">| 本期总结与下期动作 <span class="sub">本机保存（无后端共享）</span></div>';
  h+='<div class="card">';
  if(s.executive_summary){ h+='<div class="insight good"><b>核心结论</b>：'+esc(s.executive_summary)+'</div>'; }
  if(s.primary_problem){ h+='<div class="insight danger"><b>首要问题</b>：'+esc(s.primary_problem)+'<br><b>根因</b>：'+esc(s.primary_root_cause||'')+'</div>'; }
  if(s.largest_peer_gap||s.strongest_advantage){
    h+='<div class="insight">'+ (s.largest_peer_gap? '<b>最大对标缺口</b>：'+esc(s.largest_peer_gap)+'　':'') + (s.strongest_advantage? '<b>最强优势</b>：'+esc(s.strongest_advantage):'') +'</div>';
  }
  // P0-3：top_actions 可能是数组 [a,b] 或对象 {P1:[...],P2:[...],P3:[...]}，按优先级正确展开
  var tacts=[];
  if(s.top_actions){
    if(Array.isArray(s.top_actions)){
      tacts=s.top_actions.map(function(a){return {prio:a.prio||'',obj:a.obj||a.name||a.object||'',problem:a.problem||a.cur||'',action:typeof a==='string'?a:(a.action||a.chg||a.name||a.title||a.text||''),owner:a.owner||'',verify:a.verify||'',status:a.status||''};});
    }else if(typeof s.top_actions==='object'){
      Object.keys(s.top_actions).forEach(function(prio){
        (s.top_actions[prio]||[]).forEach(function(a){tacts.push({prio:prio,obj:a.obj||a.name||a.object||'',problem:a.problem||a.cur||'',action:typeof a==='string'?a:(a.action||a.chg||a.name||a.title||a.text||''),owner:a.owner||'',verify:a.verify||'',status:a.status||''});});
      });
    }
  }
  if(tacts.length){
    h+='<h4>下期动作（P1/P2/P3）</h4><div class="tbl-scroll"><table><thead><tr><th>优先</th><th>对象</th><th>当前问题</th><th>推荐动作</th><th>负责人</th><th>验证指标</th><th>状态</th></tr></thead><tbody>';
    tacts.forEach(function(a){
      h+='<tr><td>'+(a.prio?tag(a.prio,'p'+(a.prio.replace('P',''))):'—')+'</td>'+
        '<td class="small">'+esc(a.obj)+'</td><td class="small">'+esc(a.problem)+'</td><td class="small">'+esc(a.action)+'</td>'+
        '<td>'+esc(a.owner||'待分配')+'</td><td class="small">'+esc(a.verify||'—')+'</td><td>'+esc(a.status||'待办')+'</td></tr>';
    });
    h+='</tbody></table></div>';
  }
  if(s.top_opportunities && s.top_opportunities.length){
    h+='<h4>机会</h4><ul style="margin-left:18px;line-height:1.8">';
    s.top_opportunities.forEach(function(o){ h+='<li><b>'+esc(o.name||'')+'</b>：'+esc(o.why||'')+'</li>'; });
    h+='</ul>';
  }
  if(!s.executive_summary) h+='<div class="muted">本期 AI 决策摘要未生成，运行周度诊断后自动填充。</div>';
  // 下期动作 · 市场风口
  var hc=D.hot_categories||[];
  var hp=(D.v4_sections&&D.v4_sections.hot_products_clean)||[];
  if(hc.length || hp.length){
    h+='<h4>下期动作 · 市场风口（上新方向）</h4>';
    if(hc.length){
      h+='<div class="insight"><b>高增长类目（询盘同比）</b>：';
      hc.slice(0,6).forEach(function(c){
        var cls = c.inquiry_yoy>50?'wow-up':(c.inquiry_yoy>0?'':'wow-down');
        h+='<span class="tag '+(c.inquiry_yoy>50?'good':'neutral')+'">'+esc(c.name)+' +'+num(c.inquiry_yoy)+'%</span> ';
      });
      h+='<div class="small muted mt8">询盘 30 天 '+(hc[0]?num(hc[0].inquiry_30d):'—')+' 起，供需比 '+(hc[0]?num(hc[0].supply_demand):'—')+'（>100=供不应求，值得上新）。</div></div>';
    }
    if(hp.length){
      h+='<div class="tbl-scroll"><table><thead><tr><th>#</th><th>市场热销品（上新参考）</th><th>类目</th></tr></thead><tbody>';
      hp.slice(0,12).forEach(function(p,i){
        h+='<tr><td>'+(i+1)+'</td><td class="small">'+esc(p.title)+'</td><td class="small">'+esc(p.category||'')+'</td></tr>';
      });
      h+='</tbody></table></div>';
    }
  }
  h+=noteBox('summary')+'</div>';
  return h;
}

/* ============ 重点关注（机会雷达） ============ */
/* 榜单按周期取：切「月」时用 lists_month（月度产品榜，数据来自 product_monthly_stats）；
   state_grid / new_product 仍是周口径快照（月度接口不返回这两块所需字段），保留基线值 */
function getLists(){
  var base=D.lists||{};
  if(PERIOD==='month' && D.lists_month){
    return {
      inquiry:D.lists_month.inquiry||[], opp:D.lists_month.opp||[], tm:D.lists_month.tm||[],
      ctr:D.lists_month.ctr||[], zero_cost:D.lists_month.zero_cost||[],
      high_eff_low_cost:D.lists_month.high_eff_low_cost||[],
      state_grid:base.state_grid||[], new_product:base.new_product||[]
    };
  }
  return base;
}
function renderFocus(){
  var el=document.getElementById('panel-focus');
  var opp=(getLists().opp||[]).slice(0,15);
  var zc=(getLists().zero_cost||[]).slice(0,8);
  var danger=(getLists().ctr||[]).filter(function(p){return (p.opp||0)===0 && (p.total_clk||0)>=4;}).slice(0,8);
  var hc=(D.hot_categories||[]).slice(0,10);
  var h='<div class="section-title">重点关注 <span class="sub">机会雷达：按「为什么关注 + 下一步动作」分层</span></div>';
  // 顶部机会雷达
  var oppCnt=(getLists().opp||[]).length, zcCnt=(getLists().zero_cost||[]).length, dngCnt=(getLists().ctr||[]).filter(function(p){return (p.opp||0)===0;}).length;
  h+='<div class="card"><div class="kpi-grid">'+
    '<div class="kpi"><div class="k-label">有商机品</div><div class="k-val">'+num(oppCnt)+'</div><div class="k-meta muted">抓成交</div></div>'+
    '<div class="kpi"><div class="k-label">零花费有商机</div><div class="k-val">'+num(zcCnt)+'</div><div class="k-meta muted">最该接预算</div></div>'+
    '<div class="kpi"><div class="k-label">高点击0商机</div><div class="k-val">'+num(dngCnt)+'</div><div class="k-meta muted">修转化</div></div>'+
    '<div class="kpi"><div class="k-label">风口类目</div><div class="k-val">'+num(hc.length)+'</div><div class="k-meta muted">上新方向</div></div>'+
  '</div></div>';
  // 产品状态九宫格（按状态给动作，非排序）
  var grid=(getLists().state_grid||[]);
  if(grid.length){
    h+='<div class="card"><h4>产品状态诊断（九宫格） <span class="sub">按「状态 → 该状态专一动作」分层，不再统一写「优化标题/主图/详情」</span></h4>';
    h+='<div class="flex" style="flex-wrap:wrap;gap:10px">';
    grid.forEach(function(g){
      var top=(g.top||[]).map(function(t){ return '<div class="small" style="margin:2px 0">· '+esc(t.title)+' <span class="muted">('+num(t.total_clk)+'点 / '+num(t.opp)+'商机)</span></div>'; }).join('');
      var cls=(g.state==='deal_ok'||g.state==='has_opp'||g.state==='nat_opp_no_ad')?'good':(g.state==='zero_exp'||g.state==='ad_no_opp'||g.state==='clk_no_opp')?'danger':'warn';
      h+='<div class="state-cell '+cls+'" style="flex:1 1 260px;min-width:240px;border:1px solid var(--line);border-radius:8px;padding:10px">';
      h+='<div style="font-weight:600">'+esc(g.name)+' <span class="tag '+cls+'">'+num(g.count)+'个</span></div>';
      h+='<div class="small" style="margin:6px 0">'+esc(g.action)+'</div>';
      h+=top;
      h+='</div>';
    });
    h+='</div></div>';
  }
  // P1 有商机
  h+='<div class="card"><h4>P1 · 有商机，抓成交 <span class="sub">商机已来，按「问题→改法→优势」给一对一动作</span></h4>';
  h+='<div class="tbl-scroll"><table><thead><tr><th>#</th><th>产品</th><th>AI评分</th><th class="num">商机</th><th class="num">点击</th><th class="num">CTR</th><th>下一步动作（资深运营口径）</th></tr></thead><tbody>';
  opp.forEach(function(p,i){
    var s=scoreOf(p.product_id);
    h+='<tr><td>'+(i+1)+'</td><td><div class="thumb-cell">'+pimg(p.main_image)+'<div class="t">'+plink(p)+'</div></div></td>'+
      '<td>'+gradeTag(s)+'</td>'+
      '<td class="num">'+num(p.opp)+'</td><td class="num">'+num(p.total_clk)+'</td><td class="num">'+pct(p.total_ctr)+'</td>'+
      '<td class="small">'+(s?conciseAdvice(s):'')+'</td></tr>';
  });
  h+='</tbody></table></div></div>';
  // P1 零花费
  h+='<div class="card"><h4>P1 · 零花费出商机，接预算放大 <span class="sub">没花钱就有商机，是最该试投的一批</span></h4>';
  h+='<div class="tbl-scroll"><table><thead><tr><th>#</th><th>产品</th><th>AI评分</th><th class="num">商机</th><th class="num">点击</th><th class="num">CTR</th><th>动作</th></tr></thead><tbody>';
  zc.forEach(function(p,i){
    var s=scoreOf(p.product_id);
    h+='<tr><td>'+(i+1)+'</td><td><div class="thumb-cell">'+pimg(p.main_image)+'<div class="t">'+plink(p)+'</div></div></td>'+
      '<td>'+gradeTag(s)+'</td>'+
      '<td class="num">'+num(p.opp)+'</td><td class="num">'+num(p.total_clk)+'</td><td class="num">'+pct(p.total_ctr)+'</td>'+
      '<td class="small">'+(s?conciseAdvice(s):esc(p.sug))+'</td></tr>';
  });
  h+='</tbody></table></div></div>';
  // P2 高点击0商机
  h+='<div class="card"><h4>P2 · 高点击0商机，修转化 <span class="sub">按 CTR 分层：高CTR修详情页、低CTR修首图</span></h4>';
  h+='<div class="tbl-scroll"><table><thead><tr><th>#</th><th>产品</th><th>AI评分</th><th class="num">点击</th><th class="num">CTR</th><th>断点建议</th></tr></thead><tbody>';
  danger.forEach(function(p,i){
    var s=scoreOf(p.product_id);
    h+='<tr><td>'+(i+1)+'</td><td><div class="thumb-cell">'+pimg(p.main_image)+'<div class="t">'+plink(p)+'</div></div></td>'+
      '<td>'+gradeTag(s)+'</td>'+
      '<td class="num">'+num(p.total_clk)+'</td><td class="num">'+pct(p.total_ctr)+'</td>'+
      '<td class="small">'+(s?conciseAdvice(s):esc(p.sug))+'</td></tr>';
  });
  h+='</tbody></table></div></div>';
  // P2 风口类目
  if(hc.length){
    h+='<div class="card"><h4>P2 · 风口类目，上新方向 <span class="sub">询盘同比高增长的类目，优先补品</span></h4><div class="flex" style="flex-wrap:wrap">';
    hc.forEach(function(c){ h+='<span class="tag '+(c.inquiry_yoy>50?'good':'neutral')+'">'+esc(c.name)+' +'+num(c.inquiry_yoy)+'%</span> '; });
    h+='</div></div>';
  }
  h+=noteBox('focus');
  el.innerHTML=h;
}

/* ============ AI搜索 ============ */
function renderAI(){
  var el=document.getElementById('panel-ai');
  var h='<div class="section-title">AI搜索作战板</div>';
  h+='<div class="card"><div class="insight info">内部优化参考：搜索权重和TrustScore模型未经平台验证，不代表官方机制。<span class="muted">（注：以下 7 杠杆权重为内部经验阈值，非平台官方公开规则，请勿当平台事实引用）</span></div>';
  var levers=[
    ['1','补结构化属性','成分/认证等字段填满','最快'],
    ['2','自然语言文案','标题/详情覆盖采购意图',''],
    ['3','TrustScore 80+','占可见性37%，冲 TrustScore 85+',''],
    ['4','4件套视频认证','工厂/产线/质检/包装',''],
    ['5','询盘响应<30s','极速回复率对标同行优秀',''],
    ['6','行为信号(TrustRank)','停留时长/CTR/跳出率',''],
    ['7','官方Accio工具','用平台AI工具',''],
  ];
  h+='<div class="kpi-grid">';
  levers.forEach(function(L){ h+='<div class="kpi"><div class="k-label">杠杆'+L[0]+' '+L[3]+'</div><div class="k-val" style="font-size:14px">'+esc(L[1])+'</div><div class="k-meta muted">'+esc(L[2])+'</div></div>'; });
  h+='</div></div>';
  // 作战表（更多产品 + 筛选）
  var all=[];
  var seen={};
  ['opp','inquiry','tm','ctr','zero_cost'].forEach(function(k){
    (getLists()[k]||[]).forEach(function(p){ if(!seen[p.product_id]){ seen[p.product_id]=1; all.push(p); } });
  });
  all.sort(function(a,b){ return (b.opp||0)-(a.opp||0) || (b.clicks||0)-(a.clicks||0); });
  h+='<div class="section-title">AI搜索优化作战表 <span class="sub">'+all.length+' 个品，按判定标签/类目筛选，点作战方案看打法</span></div>';
  h+='<div class="card">';
  h+='<div class="flex mb8">'+
    '<select id="aiFilterLabel" onchange="renderAITable()" style="padding:4px"><option value="">判定：全部</option><option>有商机</option><option>高点击0商机</option><option>有曝光未起量</option><option>冷启动</option></select>'+
    '<select id="aiFilterCat" onchange="renderAITable()" style="padding:4px"><option value="">类目：全部</option></select>'+
    '<input id="aiSearch" placeholder="搜产品关键词..." style="padding:4px;flex:1" oninput="renderAITable()">'+
    '<span class="muted small" id="aiCount"></span></div>';
  // 类目下拉选项
  var cats={}; all.forEach(function(p){ if(p.category) cats[p.category]=1; });
  Object.keys(cats).slice(0,30).forEach(function(c){ h=h.replace('<option value="">类目：全部</option>','<option value="">类目：全部</option><option>'+esc(c)+'</option>'); });
  h+='<div class="mb8 small">图例：'+tag('有商机','good')+' '+tag('高点击0商机','danger')+' '+tag('有曝光未起量','muted')+' '+tag('冷启动','muted')+'</div>';
  h+='<div class="tbl-scroll"><table><thead><tr><th>#</th><th>产品</th><th>AI评分</th><th class="num">商机</th><th class="num">全店曝光</th><th class="num">全店点击</th><th class="num">CTR</th><th class="num">广告曝光</th><th class="num">广告点击</th><th>判定</th><th>建议（按品定制）</th><th>作战方案</th></tr></thead><tbody id="aiTableBody"></tbody></table></div>';
  h+=noteBox('ai')+'</div>';
  el.innerHTML=h;
  window._aiAll = all;
  renderAITable();
}
function renderAITable(){
  var body=document.getElementById('aiTableBody');
  if(!body) return;
  var all=window._aiAll||[];
  var fl=(document.getElementById('aiFilterLabel')||{}).value||'';
  var fc=(document.getElementById('aiFilterCat')||{}).value||'';
  var kw=((document.getElementById('aiSearch')||{}).value||'').toLowerCase();
  var list=all.filter(function(p){
    if(fl && p.label!==fl) return false;
    if(fc && p.category!==fc) return false;
    if(kw && (p.title||'').toLowerCase().indexOf(kw)<0) return false;
    return true;
  });
  (document.getElementById('aiCount')).textContent='显示 '+list.length+' / '+all.length;
  var h='';
  list.slice(0,100).forEach(function(p,i){
    var s=scoreOf(p.product_id);
    h+='<tr><td>'+(i+1)+'</td><td><div class="thumb-cell">'+pimg(p.main_image)+'<div class="t">'+plink(p)+'</div><div class="pid">'+esc(p.category||'')+' · '+esc(p.product_id)+'</div></div></td>'+
      '<td>'+gradeTag(s)+'</td>'+
      '<td class="num">'+num(p.opp)+'</td><td class="num">'+num(p.total_imps)+'</td><td class="num">'+num(p.total_clk)+'</td><td class="num">'+pct(p.total_ctr)+'</td><td class="num">'+num(p.ad_imps)+'</td><td class="num">'+num(p.ad_clk)+'</td>'+
      '<td>'+tag(p.label,p.label_typ)+'</td>'+
      '<td class="small">'+(s?conciseAdvice(s):'')+'</td>'+
      '<td><button class="btn btn-track'+(isManualTracked(p.product_id)?' on':'')+'" onclick="toggleManualTrack(\''+p.product_id+'\', this)">'+(isManualTracked(p.product_id)?'★追踪中':'☆追踪')+'</button> <button class="btn btn-plan" onclick="openPlan(\''+p.product_id+'\')">📝 作战方案</button></td></tr>';
  });
  body.innerHTML=h;
}

/* ---------- 爆品作战方案弹窗 ---------- */
function findItem(pid){
  var all=(getLists().inquiry||[]).concat(getLists().ctr||[]).concat(getLists().tm||[]).concat(getLists().zero_cost||[]);
  for(var i=0;i<all.length;i++) if(all[i].product_id===pid) return all[i];
  return null;
}
function mtForCat(pid, it){
  var cat = (it && it.category) || '';
  var mts = D.market_trends || [];
  if(!cat || !mts.length) return null;
  for(var i=0;i<mts.length;i++){
    if(mts[i].name && cat.indexOf(mts[i].name)>=0){
      var m=mts[i];
      return esc(m.name)+' 询盘同比 '+num(m.inquiry_yoy)+'%、转化 '+num(m.conv_rate)+'%、供需比 '+num(m.supply_demand)+(m.supply_demand>100?'（供不应求，可加码）':'（竞争激烈，走差异化）');
    }
  }
  return null;
}
function openPlan(pid){
  var wp=(D.war_plans&&D.war_plans[pid])||null;
  var it=findItem(pid);
  var s=scoreOf(pid);
  var title=(wp&&wp.title)||(it&&it.title)||pid;
  var dp=(wp&&wp.deep_plan)||{};
  var ov=document.createElement('div'); ov.className='modal-overlay';
  ov.innerHTML = planModalHtml(pid, title, wp, dp, it, s);
  document.body.appendChild(ov);
  ov.addEventListener('click', function(e){ if(e.target===ov) ov.remove(); });
}

function genericSeniorMoves(it){
  var imps=it?(it.impressions||0):0, clk=it?(it.clicks||0):0;
  var inq=it?(it.inquiries||0):0, tm=it?(it.tm||0):0, opp=inq+tm, adc=it?(it.ad_clk||0):0;
  if(opp>0) return [
    '秒回：第一句就问目标市场+MOQ+要定制啥，别只会甩目录',
    '详情页首屏就亮 OEM/ODM 能力+交期+认证，让买家敢下单',
    (adc>0?'广告在投(点击'+adc+')，有商机就慢慢加预算，没产出就收手':'没花钱就有商机=白赚的自然流量，可以小步试投精准词放大'),
    '报价给 3 档 MOQ 价+打样周期+交付条款，别只报一个价',
    '两周内攒 3-5 条带图评价，把信任这块补上'
  ];
  if(clk>=10) return [
    '详情页首屏就把价格/MOQ/定制/交期摆出来，别让买家翻半天',
    '主图加一句痛点钩子+核心卖点，别光秃秃放产品图',
    '认证墙+工厂规模+配方数+年限，一屏摆完',
    '把合规/起订/样品这些常问的提前写进 FAQ',
    '价格/MOQ 去跟同行对对，别贵得把买家吓跑'
  ];
  if(imps>=1000) return [
    '主图重做：白底+痛点钩子+认证，首图别只用普通产品图',
    '标题前 50 个字符就写清品类词+材质+用途',
    '必填属性+视频补全，把质量分抬进优品',
    '检查下类目放对没，放错了会丢曝光',
    '改完观察 1 周 CTR，动了再往下走'
  ];
  return [
    '小预算先投精准长尾词，买点基础曝光',
    '6 张主图+视频一次补齐，让 AI 搜索能认出来',
    '报名平台新品/品类活动，蹭点流量扶持',
    '标题覆盖核心词+用途+定制',
    '给 2 周观察期，没动静再换打法'
  ];
}

function planModalHtml(pid, title, wp, dp, it, s){
  var imps=it?(it.impressions||0):0, clk=it?(it.clicks||0):0, ctr=it?(it.ctr||0):0;
  var inq=it?(it.inquiries||0):0, tm=it?(it.tm||0):0, opp=inq+tm;
  var grade=s?(s.grade||''):'', gcls=s?(s.gcls||''):'';
  var funnel=s?(s.funnel||[]):[];
  var good=s?(s.good||[]):[], bad=s?(s.bad||[]):[], problems=s?(s.problems||[]):[];
  var actions=s?(s.actions||[]):[];
  var advice=s?(s.advice||{}):{}, playbook=s?(s.playbook||{}):{};
  var dp_problem=dp['2_current_problem']||'', dp_root=dp['9_root_cause']||'', dp_evidence=dp['3_data_evidence']||'';
  var dp_peer=dp['5_peer_gap']||'', dp_listing=dp['7_listing_diagnosis']||'';
  var dont=dp['12_do_not_change']||'';
  var intent=(wp&&wp.buyer_intent)||dp['6_buyer_intent']||'';
  var titles=(wp&&wp.candidate_titles)||[];
  var imgBrief=(wp&&wp.image_brief)||'';

  // 打法：优先 AI 给的 playbook.moves → actions → 通用兜底
  var moves=(playbook.moves&&playbook.moves.length)?playbook.moves.slice(0,5)
           :(actions&&actions.length)?actions.slice(0,5)
           :genericSeniorMoves(it);
  var mvIcons=['⚡','🎯','💰','🏭','⭐'];

  function diagTxt(){
    if(bad.length||problems.length){
      var arr=bad.concat(problems);
      return arr.slice(0,4).map(function(x){return '• '+esc(x);}).join('<br>');
    }
    if(dp_problem||dp_root||dp_evidence){
      return (dp_problem?'<b>问题</b>：'+esc(dp_problem):'')+(dp_root?'<br><b>根因</b>：'+esc(dp_root):'')+(dp_evidence?'<br><b>数据</b>：'+esc(dp_evidence):'')+(dp_peer?'<br><b>对标</b>：'+esc(dp_peer):'')+(dp_listing?'<br><b>Listing</b>：'+esc(dp_listing):'');
    }
    var s2='• 全店曝光 '+num(imps)+'、点击 '+num(clk)+'、CTR '+pct(ctr)+'、商机 '+opp+'（询盘'+inq+'/TM'+tm+'）';
    s2+= opp>0?' — 商机有了，重点是把它们谈成订单':(clk>=10?' — 有人点但没人问，八成是详情页没接住':(imps>=1000?' — 曝光不少但没人点，主图/标题得改改':' — 曝光太少，先解决「有没有人看到」'));
    return s2;
  }

  var goalTxt=playbook.positioning||advice.focus||dp['1_why_selected']||'';
  if(!goalTxt) goalTxt=opp>0?('已经有 '+opp+' 个商机，目标稳住 '+Math.max(2,Math.ceil(opp*1.2))+'/周并往成交推'):('还没商机，先出 1-2 个询盘再说');

  var imgScript=[];
  if(advice.img) imgScript.push(advice.img);
  if(imgBrief) imgScript.push(imgBrief);
  if(!imgScript.length) imgScript=[
    'Hero主图：产品+一句核心卖点（白底+痛点钩子）',
    '成分/USP图：核心成分+功效可视化',
    '认证墙：HALAL/ISO/FSSC/GMP 证书排起来',
    '工厂实力：工厂/产线/QC 实拍',
    '定制感：Your Logo · Your Formula',
    '收尾信任：演示+交期+样品政策'
  ];

  var detailTxt=advice.detail||'价格前置+定制可视化+信任数据墙+FAQ';
  var kwTxt=advice.kw||playbook.benchmark||'';

  var h='<div class="plan-modal">';
  h+='<div class="pm-head"><span>🚀</span><b>爆品作战方案</b><span class="pm-title">'+esc(title)+'</span><div class="spacer"></div>'+(grade?'<span class="tag '+gcls+'">'+esc(grade)+'</span>':'')+'<button class="btn btn-close" onclick="this.closest(\'.modal-overlay\').remove()">关闭 ✕</button></div>';
  h+='<div class="pm-body">';
  h+='<div class="pm-left">';
  h+='<div class="pm-box"><h5>🤖 AI 一眼把脉</h5><div class="pm-note">'+(funnel.length?funnel.map(function(f){return (f.ok?'✅':'⚠️')+esc(f.txt);}).join('　'):('全店曝光 '+num(imps)+' · 点击 '+num(clk)+' · CTR '+pct(ctr)+' · 商机 '+opp))+'</div></div>';
  if(good.length) h+='<div class="pm-box"><h5>💪 做得好的，保持</h5><div class="pm-note">'+good.slice(0,4).map(function(x){return '• '+esc(x);}).join('<br>')+'</div></div>';
  h+='<div class="pm-box"><h5>🎯 这一仗怎么赢</h5><div class="pm-note">'+esc(goalTxt)+'</div></div>';
  h+='<div class="pm-box"><h5>🩺 卡在哪儿了</h5><div class="pm-note">'+diagTxt()+'</div></div>';
  h+='<div class="pm-box"><h5>🚀 照着这样打</h5>';
  moves.forEach(function(m,i){ h+='<div class="lever"><span class="lv-icon">'+mvIcons[i%5]+'</span><div><b>'+esc(m)+'</b></div></div>'; });
  h+='</div>';
  if(dont) h+='<div class="pm-box"><h5>🚫 别碰这些</h5><div class="pm-note">'+esc(dont)+'</div></div>';
  if(intent) h+='<div class="pm-box"><h5>💬 买家在纠结啥</h5><div class="pm-note">'+esc(intent)+'</div></div>';
  h+='</div>';
  h+='<div class="pm-right">';
  h+='<div class="pm-box"><h5>📷 主图这么改</h5><ol class="img-script">';
  imgScript.forEach(function(x){ h+='<li>'+esc(x)+'</li>'; });
  h+='</ol></div>';
  if(kwTxt) h+='<div class="pm-box"><h5>🔑 关键词 / 看齐谁</h5><div class="pm-note">'+esc(kwTxt)+'</div></div>';
  if(titles&&titles.length){
    h+='<div class="pm-box"><h5>✍️ 标题可以这么写</h5><ul class="pm-list">';
    titles.forEach(function(t){ h+='<li><b>'+(t.code?esc(t.code)+' ':'')+'</b>'+esc(t.title||t)+'</li>'; });
    h+='</ul></div>';
  }
  h+='<div class="pm-box"><h5>🎯 详情页怎么接住询盘</h5><ul class="pm-list"><li>'+esc(detailTxt)+'</li><li>价格前置：Price from $X + MOQ + 交期</li><li>定制可视化：logo/配方/口味/包装</li><li>信任数据墙：认证+工厂规模+配方数+年限</li></ul></div>';
  h+='<div class="pm-box"><h5>📄 详情正文（英文）</h5><div class="pm-note">CTA：Start your OEM project — send us your target market, MOQ and customization needs, we quote within 24 hours.</div></div>';
  h+='</div>';
  h+='</div></div>';
  return h;
}

/* ============ 趋势对比 ============ */
/* 趋势序列按周期取：月模式用 D.months（完整自然月），并把 month_start 映射成展示标签。
   原来是写死 D.trend（周），切月后趋势表纹丝不动。 */
function trendSeries(){
  if(PERIOD==='month' && (D.months||[]).length){
    return (D.months||[]).map(function(m){
      var o={}; for(var k in m){ o[k]=m[k]; }
      o.week_end = (m.month_start||'').slice(0,7);
      return o;
    });
  }
  return D.trend||[];
}
function renderTrend(){
  var el=document.getElementById('panel-trend');
  var t=trendSeries();
  var h='<div class="section-title">店级指标趋势 <span class="sub">同账户同周期类型下自动对比</span></div>';
  h+='<div class="card"><div class="tbl-scroll"><table><thead><tr><th>指标</th>';
  t.forEach(function(w){ h+='<th class="num">'+esc(w.week_end)+'</th>'; });
  h+='<th class="num">最新环比</th></tr></thead><tbody>';
  var rows=[['搜索曝光','se_imps',''],['搜索点击','se_clk',''],['搜索点击率','se_ctr','pct'],['询盘','fb_cnt',''],['TM咨询','fb_tm_uv',''],['下单','suc_ord_cnt',''],['GMV($)','suc_ord_amt','money'],['访客','uv_cnt','']];
  rows.forEach(function(r){
    h+='<tr><td>'+r[0]+'</td>';
    t.forEach(function(w){ h+='<td class="num">'+(r[2]==='pct'?pct(w[r[1]]):(r[2]==='money'?money(w[r[1]]):num(w[r[1]])))+'</td>'; });
    var cur=t.length? t[t.length-1][r[1]]:null, pr=t.length>1? t[t.length-2][r[1]]:null;
    h+='<td class="num">'+(cur!=null&&pr? wowHtml(Math.round((cur-pr)/Math.abs(pr)*1000)/10):'<span class="muted">—</span>')+'</td></tr>';
  });
  h+='</tbody></table></div>';
  h+='<div class="chart-wrap"><canvas id="trendChart"></canvas></div>';
  h+=noteBox('trend')+'</div>';

  // 单品逐期
  h+='<div class="section-title">单品逐期对比 <span class="sub">选一个品，看它每期的点击/询盘/TM/花费</span></div>';
  h+='<div class="card"><div class="flex mb8">产品：<select id="prodSel" style="padding:4px;max-width:400px"></select></div><div id="prodTrend"></div>'+noteBox('prodtrend')+'</div>';
  el.innerHTML=h;
  // 单品选择器
  var items=(getLists().inquiry||[]).concat(getLists().ctr||[]).concat(getLists().tm||[]);
  var seen={}; var uniq=[]; items.forEach(function(p){ if(!seen[p.product_id]){seen[p.product_id]=1;uniq.push(p);} });
  var sel=document.getElementById('prodSel');
  uniq.forEach(function(p){ var o=document.createElement('option'); o.value=p.product_id; o.textContent=(p.title||'').slice(0,50); sel.appendChild(o); });
  sel.onchange=function(){ renderProdTrend(this.value); };
  if(uniq.length) renderProdTrend(uniq[0].product_id);
  trendChartDrawn=false;
}

var trendChartDrawn=false;
function drawTrendChart(){
  if(trendChartDrawn) return;
  var cv=document.getElementById('trendChart');
  if(!cv || !window.Chart) return;
  trendChartDrawn=true;
  var t=trendSeries();
  if(!t.length) return;
  var labels=t.map(function(w){return w.week_end;});
  var raw=[
    {label:'搜索曝光',key:'se_imps',color:'#2b6cb0'},
    {label:'搜索点击',key:'se_clk',color:'#e8832a'},
    {label:'询盘',key:'fb_cnt',color:'#1fa363'},
    {label:'TM咨询',key:'fb_tm_uv',color:'#9c6ade'},
  ];
  var datasets=raw.map(function(ds){
    var arr=t.map(function(w){return w[ds.key]||0;});
    var max=Math.max.apply(null,arr)||1;
    return {label:ds.label,data:arr.map(function(v){return v/max;}),borderColor:ds.color,backgroundColor:ds.color,fill:false,tension:0.3,spanGaps:true};
  });
  new Chart(cv,{type:'line',data:{labels:labels,datasets:datasets},options:{maintainAspectRatio:false,plugins:{title:{display:true,text:'各自归一化（同账户同周期）'}},scales:{y:{beginAtZero:true}}}});
}
function renderProdTrend(pid){
  var box=document.getElementById('prodTrend');
  // 从 lists 里找该产品的最新周数据
  var p=null;
  ['opp','inquiry','tm','ctr','zero_cost','high_eff_low_cost'].forEach(function(k){
    if(p) return; (getLists()[k]||[]).forEach(function(x){ if(x.product_id===pid && !p) p=x; });
  });
  var h='<div class="insight warn">历史周数据不可回填：数据参谋商品接口（week 模式）只返回最新一周。以下为本周（'+esc((D.meta||{}).week_label||'')+'）实际值；从下周起每周快照落库，自动累积逐期趋势。<b>当前无「改标题/主图/详情/价格/广告/活动」事件关联，趋势只能观察、不能下因果结论。</b></div>';
  if(p){
    h+='<table><thead><tr><th>指标</th><th class="num">本周值</th><th>解读</th></tr></thead><tbody>'+
      '<tr><td>全店曝光</td><td class="num">'+num(p.total_imps)+'</td><td>'+(p.total_imps&&p.total_imps>=1000?'曝光充足，看点击承接':'曝光偏低，补标题关键词')+'</td></tr>'+
      '<tr><td>全店点击</td><td class="num">'+num(p.total_clk)+'</td><td>'+(p.total_clk>=4?'点击正常':'点击少，主图/标题待优化')+'</td></tr>'+
      '<tr><td>点击率</td><td class="num">'+pct(p.total_ctr)+'</td><td>'+(p.total_ctr>=3?'CTR 优秀':'CTR 低于3%，首图卖点弱')+'</td></tr>'+
      '<tr><td>商机（询盘+TM）</td><td class="num">'+num(p.opp)+'</td><td>'+(p.opp>0?'已出商机，抓成交':'0商机，修详情页/MOQ/价格')+'</td></tr>'+
      '<tr><td>询盘</td><td class="num">'+num(p.inquiries)+'</td><td rowspan="2">'+(p.opp>0?'商机已来，重点转报价成交':'无商机，先解决转化断点')+'</td></tr>'+
      '<tr><td>TM咨询</td><td class="num">'+num(p.tm)+'</td></tr>'+
      '<tr><td>广告点击</td><td class="num">'+num(p.ad_clk)+'</td><td>'+(p.ad_clk>0?(p.opp>0?'广告有商机':'广告烧钱无商机，收或换定向'):'零花费（自然流量）')+'</td></tr>'+
    '</tbody></table>';
  } else {
    h+='<div class="muted">未找到该产品本周数据。</div>';
  }
  box.innerHTML=h;
}

/* ============ 改造执行台 ============ */
function taskStatus(id, field){ var v=localStorage.getItem('v4status_'+id+'_'+field); return v||'待办'; }
function saveTaskStatus(el, id, field){ localStorage.setItem('v4status_'+id+'_'+field, el.value); el.style.color=(el.value==='待办'||el.value==='不做')?'#8a94a0':'#1fa363'; }
function statusSel(id, field, cur){
  var st=taskStatus(id, field)||cur||'待办';
  var opts=['待办','进行中','已完成','不做'];
  return '<select style="padding:2px;color:'+(st==='待办'||st==='不做'?'#8a94a0':'#1fa363')+'" onchange="saveTaskStatus(this,\''+id+'\',\''+field+'\')">'+
    opts.map(function(o){return '<option'+(o===st?' selected':'')+'>'+o+'</option>';}).join('')+'</select>';
}
function renderExec(){
  var el=document.getElementById('panel-exec');
  var plan=D.exec_plan||[];
  var acts=D.actions||[];
  var opts=D.optimizations||[];
  var FIELDMAP={title_rewrite:'标题改写', moq_ladder:'MOQ试单档', main_image:'主图', detail_conversion:'详情页转化模块', detail_b2b_section:'详情页B2B模块', price_optimize:'定价/MOQ阶梯'};
  function cleanField(f){ if(!f) return '优化'; var fl=(f||'').toLowerCase(); var k=Object.keys(FIELDMAP); for(var i=0;i<k.length;i++){ if(fl.indexOf(k[i])>=0) return FIELDMAP[k[i]]; } return (f||'').split('(')[0].trim().slice(0,14); }
  function cleanTxt(t){ if(!t) return ''; t=String(t)
      .replace(/\(?NEEDS_HUMAN_CONFIRMATION=true\)?/gi,'')
      .replace(/（One Variable[^）]*）/g,'').replace(/\(One Variable[^)]*\)/gi,'')
      .replace(/\bMAIN_IMAGE\b/gi,'').replace(/\bTITLE_REWRITE\b/gi,'').replace(/\bDETAIL_CONVERSION\b/gi,'')
      .replace(/\bDETAIL_B2B_SECTION\b/gi,'').replace(/\bREVIEW_MOQ_LADDER\b/gi,'').replace(/\bREVIEW MOQ LADDER\b/gi,'')
      .replace(/\bPRICE_OPTIMIZE\b/gi,'').replace(/\bMOQ_LADDER\b/gi,'')
      .replace(/\btitle_rewrite\b/gi,'').replace(/\bdetail_conversion\b/gi,'').replace(/\bdetail_b2b_section\b/gi,'')
      .replace(/\bmoq_ladder\b/gi,'').replace(/\bprice_optimize\b/gi,'').replace(/\bmain_image\b/gi,'')
      .replace(/（本轮唯一变量）/g,'').replace(/\(PRIMARY\)/gi,'').replace(/\(PRI\)/gi,'')
      .replace(/\(\)/g,'').replace(/（\s*）/g,'')
      .replace(/[→\->]+\s*$/g,'').replace(/[→\->]+\s*(?=[。；，])/g,'')
      .replace(/\s+/g,' ').trim();
    return t.length>70? t.slice(0,70)+'…' : (t||'待诊断');
  }
  function adviceFor(pid){
    var s=scoreOf(pid); if(!s) return '';
    var adv=s.advice||{};
    return adv.img || adv.focus || adv.detail || '';
  }
  var ACTION_CN={title_rewrite:'标题改为覆盖核心品类词+规格',main_image:'重做主图首图(痛点钩子+认证墙)',detail_b2b_section:'详情加B2B模块(OEM/定制/交期)',detail_conversion:'详情加转化模块(价格前置+CTA)',moq_ladder:'MOQ试单档(降低小B门槛)',price_optimize:'按诊断做定价/MOQ阶梯'};
  function actionCn(a){ if(!a) return ''; var al=String(a).toLowerCase(); var k=Object.keys(ACTION_CN); for(var i=0;i<k.length;i++){ if(al.indexOf(k[i])>=0) return ACTION_CN[k[i]]; } return cleanField(a); }
  // 产品级动作合并
  var prodTasks=[];
  acts.forEach(function(a){
    var chg = cleanTxt(a.recommended_change) || adviceFor(a.product_id);
    prodTasks.push({prio: a.confidence==='high'?'P1':'P2', field:cleanField(a.primary_variable||a.action_type), cat: a.action_type||'', cur: cleanTxt(a.description)||'待诊断', chg: chg||'待定', pid:a.product_id, status: a.status||'待办', owner: a.owner||'', due: a.due_date||''});
  });
  opts.forEach(function(o){
    var chg = actionCn(o.primary_action) || adviceFor(o.product_id) || '优化方案';
    prodTasks.push({prio:'P2', field:'AI优化方案', cat:o.primary_action||'', cur:cleanTxt(o.priority_reason)||'待诊断', chg:chg, pid:o.product_id, status:o.status||'待办', owner:o.owner||'', due:o.due_date||''});
  });
  var storeTotal=0, storeDone=0;
  plan.forEach(function(b){ storeTotal+=b.tasks.length; storeDone+=b.tasks.filter(function(t){return taskStatus(b.id,t.field)==='已完成';}).length; });
  var h='<div class="section-title">Listing 改造执行台 <span class="sub">状态/负责人/备注均为本机保存（非团队共享）</span></div>';
  h+='<div class="flex mb8">'+
    '<select style="padding:4px"><option>全部优先级</option><option>P0</option><option>P1</option><option>P2</option></select>'+
    '<select style="padding:4px"><option>全部状态</option><option>待办</option><option>进行中</option><option>已完成</option><option>不做</option></select>'+
    '<input placeholder="搜产品/字段..." style="padding:4px;flex:1">'+
    '<span class="muted">店级 '+num(storeTotal)+' 项 · 已完成 '+num(storeDone)+' · 单品 '+num(prodTasks.length)+' 项</span></div>';
  // 店级 4 块（哪里缺了补哪里）
  plan.forEach(function(b){
    var done=b.tasks.filter(function(t){return taskStatus(b.id,t.field)==='已完成';}).length;
    h+='<div class="task-block"><div class="task-head"><span class="t-id">'+b.id+'</span><span>'+b.icon+'</span><span class="t-name">'+esc(b.name)+'</span><div class="progress-bar"><i style="width:'+Math.round(done/Math.max(1,b.tasks.length)*100)+'%"></i></div><span class="progress">'+done+'/'+b.tasks.length+'</span></div>';
    h+='<div class="tbl-scroll"><table><thead><tr><th>优先</th><th>字段/位置</th><th>现状 → 改成什么</th><th>状态</th><th>负责人</th><th>截止日</th><th>备注</th></tr></thead><tbody>';
    b.tasks.forEach(function(x){
      h+='<tr><td>'+tag(x.prio,'p'+x.prio.slice(1))+'</td>'+
        '<td class="small">'+esc(x.field)+'<div class="muted tiny">'+esc(x.cat||'')+'</div></td>'+
        '<td class="small">'+esc(x.cur)+'<br><span style="color:var(--green)">→</span> '+esc(x.chg)+'</td>'+
        '<td>'+statusSel(b.id,x.field,x.status)+'</td>'+
        '<td>'+(x.owner?esc(x.owner):'<span class="muted">待分配</span>')+'</td>'+
        '<td>'+esc(x.due||'')+'</td>'+
        '<td class="small muted">AI预填</td></tr>';
    });
    h+='</tbody></table></div></div>';
  });
  // 单品优化（产品级）
  if(prodTasks.length){
    var pdone=prodTasks.filter(function(t){return taskStatus('PROD',t.field+t.pid)==='已完成';}).length;
    h+='<div class="task-block"><div class="task-head"><span class="t-id">LW-PROD</span><span>🎯</span><span class="t-name">单品优化 (产品级)</span><div class="progress-bar"><i style="width:'+Math.round(pdone/Math.max(1,prodTasks.length)*100)+'%"></i></div><span class="progress">'+pdone+'/'+prodTasks.length+'</span></div>';
    h+='<div class="tbl-scroll"><table><thead><tr><th>优先</th><th>字段/位置</th><th>现状 → 改成什么</th><th>状态</th><th>负责人</th><th>截止日</th><th>备注</th></tr></thead><tbody>';
    prodTasks.forEach(function(x){
      var s=scoreOf(x.pid);
      h+='<tr><td>'+tag(x.prio,'p'+x.prio.slice(1))+'</td>'+
        '<td class="small">'+esc(x.field)+'<div class="muted tiny">'+esc(x.pid)+'</div></td>'+
        '<td class="small">'+esc(x.cur)+'<br><span style="color:var(--green)">→</span> '+esc(x.chg)+'</td>'+
        '<td>'+statusSel('PROD',x.field+x.pid,x.status)+'</td>'+
        '<td>'+(x.owner?esc(x.owner):'<span class="muted">待分配</span>')+'</td>'+
        '<td>'+esc(x.due||'')+'</td>'+
        '<td class="small">'+(s?gradeTag(s):'<span class="muted">AI预填</span>')+'</td></tr>';
    });
    h+='</tbody></table></div></div>';
  }
  h+=noteBox('exec');
  el.innerHTML=h;
}

/* ============ 竞品对比（产品级） ============ */
function renderCompete(){
  var el=document.getElementById('panel-compete');
  var comps=(D.competitor_full&&D.competitor_full.competitors)||(D.v4_scores&&D.v4_scores.competitors)||[];
  var total=(D.competitor_full&&D.competitor_full.total)||comps.length;
  var sup=(D.competitor_full&&D.competitor_full.supplier_count)||5;
  var h='<div class="section-title">竞品对比 <span class="sub">'+num(total)+' 个真实竞品（'+num(sup)+' 家供应商），带真实图可跳转+好在哪点评</span></div>';
  h+='<div class="card">';
  h+='<div class="insight info">对标口径：'+num(sup)+' 家标杆供应商的 Top 商品（按月订单排序），只保留运动营养/维生素/草本补充剂/胶原蛋白品类，已过滤壮阳/减肥/美白/助孕/关节/骨骼/心脏/脑等擦边与非目标品类。每张卡：①竞品好在哪（月订单/询盘/MOQ）②价格/MOQ 差在哪 ③点「跳转」看它的主图/详情打法。</div>';
  if(!comps.length){ h+='<div class="muted">竞品数据未接入。</div>'; }
  else {
    // 类目筛选
    var cats={}; comps.forEach(function(c){ if(c.category) cats[c.category]=1; });
    var catList=Object.keys(cats);
    h+='<div class="flex mb8"><select id="compCat" onchange="renderCompCards()" style="padding:4px"><option value="">全部类目</option>'+catList.map(function(c){return '<option>'+esc(c)+'</option>';}).join('')+'</select><span class="muted small" id="compCount"></span></div>';
    h+='<div class="grid3" id="compCards"></div>';
    h+='<div class="muted small mt8">注：图片为竞品真实主图（数据参谋商品报告），点「跳转竞品」查看 alibaba.com 详情页。</div>';
  }
  h+=noteBox('compete')+'</div>';
  el.innerHTML=h;
  window._comps=comps;
  renderCompCards();
}
function renderCompCards(){
  var box=document.getElementById('compCards');
  if(!box) return;
  var comps=window._comps||[];
  var fc=(document.getElementById('compCat')||{}).value||'';
  var list=comps.filter(function(c){ return !fc || c.category===fc; });
  (document.getElementById('compCount')).textContent='显示 '+list.length+' / '+comps.length;
  var h='';
  list.slice(0,48).forEach(function(c){
    h+='<div class="comp-card">'+
      '<div class="thumb">'+(c.img?'<img src="'+esc(c.img)+'" loading="lazy" onclick="previewImg(\''+esc(c.img)+'\')" style="cursor:zoom-in" onerror="this.style.visibility=\'hidden\'">':'<div class="noimg">无图</div>')+'</div>'+
      '<div class="t small" title="'+esc(c.title)+'"><b>'+esc(c.title)+'</b></div>'+
      '<div class="meta small">'+
        '<div>💰 '+esc(c.price||'—')+' · MOQ '+esc(c.moq||'—')+'</div>'+
        '<div>📦 月订单 '+num(c.orders)+' · 询盘 '+num(c.inquiry)+'</div>'+
        '<div>🏷 '+esc(c.category||'')+'</div>'+
      '</div>'+
      '<div class="good small"><b>好在哪</b>：'+esc(c.good_point||'')+'</div>'+
      '<div class="mt8"><a class="btn btn-save" href="'+esc(c.url||'#')+'" target="_blank">跳转竞品 ↗</a></div>'+
    '</div>';
  });
  box.innerHTML=h;
}

/* ============ 店铺深度详情弹窗 ============ */
function storeDetail(name){
  var cd=D.competitor_detail||null;
  if(!cd) return null;
  var arr=cd.stores||[];
  for(var i=0;i<arr.length;i++) if(arr[i].name===name) return arr[i];
  return null;
}
function basicPeer(name){
  var pb=D.peer_benchmark||null;
  if(!pb) return null;
  var arr=pb.peers||[];
  for(var i=0;i<arr.length;i++) if(arr[i].store_name===name) return arr[i];
  return null;
}
function shareBar(pct, color){
  return '<div class="share-row"><span class="share-label">'+esc(pct.label||pct)+'</span><div class="progress-bar" style="flex:1"><i style="width:'+Math.min(100,pct.share||0)+'%;background:'+(color||'#2b6cb0')+'"></i></div><span class="small muted">'+num(pct.share)+'%</span></div>';
}
function openStoreDetail(name){
  var s=storeDetail(name);
  if(!s){
    var b=basicPeer(name);
    if(b){ openBasicPeer(b); return; }
    alert('该店暂无数据'); return;
  }
  var stars=''; var sl=Math.round(parseFloat(s.star)||0); for(var i=0;i<sl;i++) stars+='★';
  var m=s.metrics||{}; var pr=s.products||{}; var pf=s.profile||{};
  // 自动总结：哪里做得好
  var goods=[];
  var topC=(pf.country||[])[0]; if(topC) goods.push('主攻「'+topC.label+'」市场（占 '+topC.share+'%），'+((pf.country||[])[1]?'其次是'+pf.country[1].label+' '+pf.country[1].share+'%':''));
  var topI=(pf.identity||[])[0]; if(topI) goods.push('买家以「'+topI.label+'」为主（'+topI.share+'%）');
  if(m.gmv_trend==='up') goods.push('GMV 指数处于上升期（↑）'); else if(m.gmv_trend==='down') goods.push('GMV 指数近两周回落（↓），或进入存量竞争');
  if(s.main_products&&s.main_products.length) goods.push('核心盘：'+s.main_products.slice(0,3).join(' / '));
  var goodTxt = goods.length? goods.join('；')+'。' : '本次未取得足够数据。';

  var ov=document.createElement('div'); ov.className='modal-overlay';
  var h='<div class="plan-modal">';
  h+='<div class="pm-head"><span>🏪</span><b>店铺深度分析</b><span class="pm-title">'+esc(s.name)+'</span><div class="spacer"></div><span class="muted small">'+stars+' '+esc(s.star||'')+' · 评分 '+esc(s.score||'—')+'</span><a class="btn btn-save" style="margin-left:10px" href="'+esc(s.url||'#')+'" target="_blank">跳转店铺 ↗</a><button class="btn btn-close" onclick="this.closest(\'.modal-overlay\').remove()">关闭 ✕</button></div>';
  h+='<div class="pm-body">';
  h+='<div class="pm-left">';
  // 经营指标
  h+='<div class="pm-box"><h5>📊 经营指标（指数，非真实成交）</h5><div class="kpi-grid">'+
    '<div class="kpi"><div class="k-label">GMV 强度指数</div><div class="k-val">'+num(m.gmv_index)+'</div><div class="k-meta">'+(m.gmv_trend==='up'?'<span class="wow-up">↑ 上升</span>':(m.gmv_trend==='down'?'<span class="wow-down">↓ 回落</span>':'<span class="muted">→ 平稳</span>'))+'</div></div>'+
    '<div class="kpi"><div class="k-label">询盘效率</div><div class="k-val">'+num(m.inquiry_eff)+'</div></div>'+
    '<div class="kpi"><div class="k-label">订单效率</div><div class="k-val">'+num(m.order_eff)+'</div></div>'+
  '</div></div>';
  // 主营
  h+='<div class="pm-box"><h5>🧭 主营产品</h5><div class="mb8">'+(s.main_products||[]).map(function(x){return '<span class="tag info">'+esc(x)+'</span> ';}).join('')+'</div></div>';
  // 价格带
  if(pr.price_units&&pr.price_units.length){
    h+='<div class="pm-box"><h5>💰 主力价格带</h5>';
    pr.price_units.forEach(function(u){ h+='<div class="small mt8"><b>'+esc(u.unit)+'</b>：'+u.buckets.map(function(b){return '<span class="tag neutral">'+esc(b)+'</span> ';}).join('')+'</div>'; });
    h+='</div>';
  }
  // 进店词
  if(pf.search&&pf.search.length){
    h+='<div class="pm-box"><h5>🔍 店内搜索词 Top</h5><div>'+(pf.search||[]).map(function(x){return shareBar(x,'#1fa363');}).join('')+'</div></div>';
  }
  h+='</div>';
  h+='<div class="pm-right">';
  // 国家
  h+='<div class="pm-box"><h5>🌍 买家国家分布 Top6（近30天）</h5>'+(pf.country||[]).map(function(x){return shareBar(x);}).join('')+'</div>';
  // 身份
  h+='<div class="pm-box"><h5>👥 买家身份</h5>'+(pf.identity||[]).map(function(x){return shareBar(x,'#e8832a');}).join('')+'</div>';
  // 来源
  if(pf.source&&pf.source.length){ h+='<div class="pm-box"><h5>🚪 流量来源</h5>'+(pf.source||[]).map(function(x){return shareBar(x,'#9c6ade');}).join('')+'</div>'; }
  // 总结
  h+='<div class="pm-box"><h5>💡 哪里做得好（总结）</h5><div class="pm-note">'+esc(goodTxt)+'</div></div>';
  h+='</div>';
  h+='</div></div>';
  ov.innerHTML=h;
  document.body.appendChild(ov);
  ov.addEventListener('click', function(e){ if(e.target===ov) ov.remove(); });
}
function openBasicPeer(b){
  var stars=''; var sl=Math.round(parseFloat(b.star_level)||0); for(var i=0;i<sl;i++) stars+='★';
  var ov=document.createElement('div'); ov.className='modal-overlay';
  var h='<div class="plan-modal">';
  h+='<div class="pm-head"><span>🏪</span><b>店铺基础档案</b><span class="pm-title">'+esc(b.store_name)+'</span><div class="spacer"></div><span class="muted small">'+stars+' '+esc(b.star_level||'')+' · 评分 '+esc(b.score||'—')+'</span><a class="btn btn-save" style="margin-left:10px" href="'+esc(b.url||'#')+'" target="_blank">跳转店铺 ↗</a><button class="btn btn-close" onclick="this.closest(\'.modal-overlay\').remove()">关闭 ✕</button></div>';
  h+='<div class="pm-body"><div class="pm-left">';
  h+='<div class="pm-box"><h5>📊 经营信号（近7日指数）</h5><div class="kpi-grid">'+
    '<div class="kpi"><div class="k-label">询盘指数</div><div class="k-val">'+num(b.inquiry_7d)+'</div></div>'+
    '<div class="kpi"><div class="k-label">UV指数</div><div class="k-val">'+num(b.uv_7d)+'</div></div>'+
    '<div class="kpi"><div class="k-label">订单指数</div><div class="k-val">'+num(b.order_7d)+'</div></div>'+
    '<div class="kpi"><div class="k-label">评论数</div><div class="k-val">'+num(b.review_cnt)+'</div></div>'+
  '</div></div>';
  h+='<div class="pm-box"><h5>🧭 主营产品</h5><div class="mb8">'+esc(b.main_products||'')+'</div></div>';
  h+='<div class="pm-box"><h5>💡 参考</h5><div class="pm-note">该店尚未跑深度分析（经营指标/买家国家/价格带），下轮补充。可先点「跳转店铺」看其首页与 listing 结构。</div></div>';
  h+='</div><div class="pm-right"><div class="pm-box"><h5>🆔 店铺信息</h5><div class="small">store_id: '+esc(b.store_id||'—')+'</div><div class="small muted mt8">数据来源：数据参谋供应商筛选（30d，按 GMV 降序）。</div></div></div>';
  h+='</div></div>';
  ov.innerHTML=h;
  document.body.appendChild(ov);
  ov.addEventListener('click', function(e){ if(e.target===ov) ov.remove(); });
}

/* ============ 同行标杆 ============ */
function renderPeer(){
  var el=document.getElementById('panel-peer');
  var pb=D.peer_benchmark||null;
  var h='<div class="section-title">🏆 同行标杆总览</div>';
  h+='<div class="card"><div class="insight">【行业格局】标杆同行由数据参谋「供应商筛选」（30d，按 GMV 降序）采集时返回，含星等级、评分、评论、询盘/UV/订单指数与主营类目——对标时重点看营收领先者的主营品类与定位，找可复制的赛道与差异化空隙。点公司名可看该店指数档案并跳转店铺。</div>';
  if(!pb || !(pb.peers||[]).length){
    h+='<div class="card"><div class="muted">标杆同行数据未接入。</div>'+noteBox('peer')+'</div>'; el.innerHTML=h; return h;
  }
  var name2domain={};
  var cd=(D.competitor_detail&&D.competitor_detail.stores)||[];
  cd.forEach(function(s){ name2domain[s.name]=s.domain; });
  h+='<div class="tbl-scroll"><table><thead><tr><th>#</th><th>公司</th><th>星</th><th class="num">评分</th><th class="num">评论</th><th class="num">询盘指数7d</th><th class="num">UV指数7d</th><th class="num">订单指数</th><th>主营</th></tr></thead><tbody>';
  (pb.peers||[]).forEach(function(x,i){
    var stars=''; for(var s=0;s<Math.round(parseFloat(x.star_level)||0);s++) stars+='★';
    var nameCell = '<span class="store-link" onclick="openStoreDetail(\''+esc(x.store_name)+'\')">'+esc(x.store_name)+'</span>';
    h+='<tr><td>'+(i+1)+'</td><td>'+nameCell+'<div class="pid">'+esc(x.store_id||'')+'</div></td>'+
      '<td>'+stars+'<span class="small muted">'+esc(x.star_level||'')+'</span></td>'+
      '<td class="num">'+esc(x.score||'—')+'</td><td class="num">'+num(x.review_cnt)+'</td>'+
      '<td class="num">'+num(x.inquiry_7d)+'</td><td class="num">'+num(x.uv_7d)+'</td><td class="num">'+num(x.order_7d!=null?x.order_7d:x.order_30d)+'</td>'+
      '<td class="small">'+esc((x.main_products||'').slice(0,60))+'</td></tr>';
  });
  h+='</tbody></table></div>';
  h+='<div class="muted small">注：共 '+pb.peers.length+' 家标杆店，按 30 天实收 GMV 降序排列；询盘/UV/订单均为平台指数（近7日合计），非真实成交额，仅用于同行相对位置参考。</div>';
  h+=noteBox('peer')+'</div>';
  el.innerHTML=h;
}

/* ============ 管理 ============ */
function renderAdmin(){
  var el=document.getElementById('panel-admin');
  var m=D.meta||{};
  var h='<div class="section-title">管理</div>';
  h+='<div class="card"><div class="grid2">'+
    '<div><h4>店铺</h4><div class="small">'+esc(m.store_name)+'</div><div class="small muted">store_id: '+esc(m.store_id)+'</div></div>'+
    '<div><h4>数据</h4><div class="small">最新周：'+esc(m.week_label)+'</div><div class="small muted">advisory_date: '+esc(m.advisory_date)+'</div><div class="small muted">生成时间：'+esc(m.generated_at)+'</div></div>'+
  '</div>'+
  '<div class="insight info">数据源：Alibaba 数据参谋 MCP + CGS 星等级接口 + 广告 HATEOAS 接口（全站推/直通车计划+报告）。已接入：星等级/降星预警、广告计划层（花费/CPC/CPL/商机）。数据缺口（显式标注）：订单明细/复购率、RFQ、ACP站外明细 — 需接入对应接口后补齐。</div>'+
  noteBox('admin')+'</div>';
  el.innerHTML=h;
}

/* ============ 启动 ============ */
function updateDateLabel(){
  if(PERIOD==='month'){ var mm=selectedMonth(); if(mm){ document.getElementById('dateLabel').textContent = mm.month_label; return; } }
  var w=selectedWeek();
  document.getElementById('dateLabel').textContent = w ? (w.week_start+' ~ '+w.week_end) : (D.meta? D.meta.week_label:'');
}
function weekNum(w){ // 由周起始日算"第N周"
  var d=new Date(w.week_start+'T00:00:00');
  var jan1=new Date(d.getFullYear(),0,1);
  var days=Math.floor((d-jan1)/86400000);
  return Math.ceil((days + jan1.getDay()+1)/7);
}
function populatePeriodSel(){
  var ws=document.getElementById('weekSel'); ws.innerHTML='';
  if(PERIOD==='month'){
    (D.months||[]).forEach(function(m,i){ var o=document.createElement('option'); o.value=i; o.textContent=m.month_start.slice(0,7)+'月 ('+m.month_start+'~'+m.month_end+')'; ws.appendChild(o); });
    if(D.months&&D.months.length) ws.value = D.months.length-1;
    ws.onchange=function(){ SELECTED_MONTH=parseInt(this.value,10); updateDateLabel(); refreshAllPanels(); };
  } else {
    (D.weeks||[]).forEach(function(w,i){ var o=document.createElement('option'); o.value=i; o.textContent='2026 第'+weekNum(w)+'周 ('+w.week_start+'~'+w.week_end+')'; ws.appendChild(o); });
    if(D.weeks&&D.weeks.length) ws.value = D.weeks.length-1;
    ws.onchange=function(){ SELECTED_WEEK=parseInt(this.value,10); updateDateLabel(); refreshAllPanels(); };
  }
}
/* ===================== 老板看板 ===================== */
function bossKey(){ return 'gos_boss_manual_' + (window.V4_STORE || 'store'); }
/* [本机补丁 2026-11-03] 新品点选是跨期清单，不能跟着「带周期」的 key 走。
   原来 new_selection 和其它手填字段一起存在 bossKey()（周期 key）里，
   换一周 key 就变，上周点好的产品全部读不到（「已点选产品 0」）。
   现在：固定 key 优先，其次用数据源里的清单；当期 key 里的 new_selection 不再覆盖。 */
function newSelKey(){
  var store=(D.meta&&D.meta.store_id)||window.V4_STORE||'store';
  return 'gos_new_selection_'+store;
}
function getNewSelection(){
  try{ var v=JSON.parse(localStorage.getItem(newSelKey())||'null'); if(Array.isArray(v)) return v; }catch(e){}
  /* 旧版把点选存在「带周期」的 bossKey 里，换期读不到。这里扫一遍历史 key，取最新一份迁过来。 */
  try{
    var store=(D.meta&&D.meta.store_id)||window.V4_STORE||'store',best=null,bestKey='';
    for(var i=0;i<localStorage.length;i++){
      var k=localStorage.key(i)||'';
      if(k.indexOf('gos_boss_manual_v2_'+store)===0){
        var o=null; try{ o=JSON.parse(localStorage.getItem(k)||'null'); }catch(e2){}
        if(o&&Array.isArray(o.new_selection)&&o.new_selection.length&&k>bestKey){ bestKey=k; best=o.new_selection; }
      }
    }
    if(best){ try{ localStorage.setItem(newSelKey(),JSON.stringify(best)); }catch(e3){} return best; }
  }catch(e){}
  var b=((D.boss||{}).manual||{}).new_selection;
  return Array.isArray(b)?b:[];
}
/* [本机补丁 2026-11-03] 年费/问鼎/顶展/品牌广告是「月度固定投入」，不该每周重填。
   当期这几项为空时，自动沿用最近一次填过的值；用户真填了 0 就尊重 0（品牌广告可能确实是 0）。 */
var COST_FIELDS = ['annual_fee','wendin','topshow','brand_ad'];
function _lastCostFilled(){
  var store=(D.meta&&D.meta.store_id)||window.V4_STORE||'store',best=null,bestKey='';
  try{
    for(var i=0;i<localStorage.length;i++){
      var k=localStorage.key(i)||'';
      if(k.indexOf('gos_boss_manual_v2_'+store)===0 || k.indexOf('dashboard_manual_html_v1_'+store)===0){
        var o=null; try{ o=JSON.parse(localStorage.getItem(k)||'null'); }catch(e){}
        if(!o) continue;
        var f=o.fields||o;
        var hit=COST_FIELDS.some(function(x){ return f[x]!=null && f[x]!==''; });
        if(hit&&k>bestKey){ bestKey=k; best=f; }
      }
    }
  }catch(e){}
  return best||{};
}
function getBossManual(){
  var b = (D.boss && D.boss.manual) || {};
  var m = { acquisition: b.acquisition||0, quality_customers: b.quality_customers||0, cac: (b.cac!=null?b.cac:null),
            sample_orders: b.sample_orders||0, sample_products: b.sample_products||'',
            order_products: b.order_products||'',
            annual_fee: b.annual_fee||0, wendin: b.wendin||0, topshow: b.topshow||0, brand_ad: b.brand_ad||0,
            ad_spend_override: (b.ad_spend_override!=null?b.ad_spend_override:null),
            new_count: b.new_count||0, new_selection: b.new_selection||[] };
  var cur=null;
  try{ var s=localStorage.getItem(bossKey()); if(s){ cur=JSON.parse(s); for(var k in cur){ if(k in m && k!=='new_selection') m[k]=cur[k]; } } }catch(e){}
  var carry=_lastCostFilled();
  COST_FIELDS.forEach(function(f){
    var curV = cur ? cur[f] : undefined;
    var blank = (curV===undefined || curV===null || curV==='');
    if(blank && carry[f]!=null && carry[f]!=='') m[f]=carry[f];
  });
  m.new_selection=getNewSelection();
  return m;
}
function saveBossManual(m){
  try{ localStorage.setItem(bossKey(), JSON.stringify(m)); }catch(e){}
  try{ if(Array.isArray(m.new_selection)) localStorage.setItem(newSelKey(), JSON.stringify(m.new_selection)); }catch(e){}
}
function _n(x){ return (x==null)?'-':Number(x).toLocaleString(); }
function _m(x){ return (x==null)?'-':'¥'+Number(x).toLocaleString(undefined,{maximumFractionDigits:2}); }
function _pct(x){ return (x==null)?'-':(Math.round(x*100)+'%'); }
function _kpi(lab,val,tag,cls,sub){ return '<div class="kpi '+(cls||'')+'"><span class="tag '+(cls||'')+'">'+(tag||'')+'</span><div class="lab">'+lab+'</div><div class="val">'+val+'</div><div class="sub">'+(sub||'')+'</div></div>'; }
function renderNewSelected(m){
  var pool={}; (D.boss.product_pool||[]).forEach(function(p){ pool[p.product_id]=p; });
  var rows=m.new_selection.map(function(id){ return pool[id]; }).filter(Boolean);
  if(!rows.length) return '<div class="insight" style="margin-bottom:8px">尚未点选具体新品。在下方产品池里点一下产品即可（带图，再点=取消）。</div>';
  var h='<table class="boss-table"><thead><tr><th>产品(点击看链接)</th><th>ID</th><th>分级</th><th>曝光</th><th>点击</th><th>商机</th><th>订单</th><th>GMV($)</th></tr></thead><tbody>';
  rows.forEach(function(p){ h+='<tr><td class="prod-cell"><a href="'+(p.detail_url||'#')+'" target="_blank">'+(p.main_image?'<img class="prod-thumb" src="'+esc(p.main_image)+'" alt=""> ':'')+esc(p.title)+'</a></td><td class="small np-id">'+p.product_id+'</td><td><span class="lvl lvl-'+(p.level||'')+'">'+(p.level||'-')+'</span></td><td>'+_n(p.imps)+'</td><td>'+_n(p.clicks)+'</td><td title="询盘 '+_n(p.inquiries)+' + TM '+_n(p.tm)+'">'+_n(p.opp!=null?p.opp:((p.inquiries||0)+(p.tm||0)))+'</td><td>'+_n(p.orders)+'</td><td>'+_n(p.gmv)+'</td></tr>'; });
  return h+'</tbody></table>';
}
/* 老板面板复用运营看板的漏斗/承接效率卡片(每项含 同行优秀/平均 + 较比上周) */
function funnelCardsHtml(){
  var fun=getFunnel();
  var h='<div class="card"><div class="kpi-grid">';
  fun.forEach(function(f){
    h+='<div class="kpi"><div class="k-label">'+esc(f.label)+'</div>';
    h+='<div class="k-val">'+fmt(f.fmt,f.cur)+'<small>'+(f.unit?' '+esc(f.unit):'')+'</small></div>';
    if(f.note) h+='<div class="k-meta"><span class="muted small">'+esc(f.note)+'</span></div>';
    h+='<div class="k-meta">'+wowHtml(f.wow)+'<span class="gap">'+gapHtml(f.cur,f.rival_avg,f.rival_good,f.lower_better)+'</span></div></div>';
  });
  h+='</div></div>';
  return h;
}
function bearingCardsHtml(){
  var h='<div class="card"><div class="kpi-grid">';
  getBearing().forEach(function(b){
    var has = (b.rival_avg!=null);
    var bad = has ? (b.lower_better ? (b.cur > b.rival_avg) : (b.cur < b.rival_avg)) : false;
    var dot = has ? (bad ? '<span class="dot red"></span>未达标 ' : '<span class="dot green"></span>达标 ') : '';
    h+='<div class="kpi"><div class="k-label">'+dot+esc(b.label)+'</div>';
    h+='<div class="k-val">'+fmt(b.fmt,b.cur)+'</div>';
    h+='<div class="k-meta"><span class="gap">'+gapHtml(b.cur,b.rival_avg,b.rival_good,b.lower_better)+'</span></div></div>';
  });
  h+='</div></div>';
  return h;
}
function bossPeriodLabel(){
  var _sw = (PERIOD==='week') ? selectedWeek() : null;
  var _sm = (PERIOD==='month') ? selectedMonth() : null;
  return _sm ? _sm.month_label : (_sw ? (_sw.week_start+' ~ '+_sw.week_end) : ((D.meta||{}).week_label||''));
}
function renderBossIfActive(){ if(document.body && document.body.classList.contains('view-boss')) renderBoss(); }
/* 平台分级产品区（爆品/优品/潜力优品 通用）：各自可折叠表格 + 供首栏卡跳转的 id */
function productLevelSection(emoji, title, count, products, secId, key){
  var n=(products||[]).length;
  var h='<div class="boss-sec" id="'+secId+'"><h3>'+emoji+' '+title+' <span class="flabel">'+n+' 个 · 平台分级 · 展开看真实产品链接</span></h3>';
  h+='<button id="bossLvlToggle_'+key+'" class="boss-collapse-btn" type="button" data-label="'+title+'" data-open="0">▸ 展开看'+title+'链接（'+n+' 个）</button>';
  h+='<div id="bossLvlBody_'+key+'" style="display:none;margin-top:10px">';
  if(n){
    h+='<table class="boss-table"><thead><tr><th>#</th><th>产品(链接)</th><th>分级</th><th>曝光</th><th>点击</th><th>询盘</th><th>TM</th><th>订单</th><th>GMV($)</th></tr></thead><tbody>';
    (products||[]).forEach(function(p,i){
      h+='<tr><td>'+(i+1)+'</td><td class="prod-cell"><a href="'+(p.detail_url||'#')+'" target="_blank">'+(p.main_image?'<img class="prod-thumb" src="'+esc(p.main_image)+'" alt=""> ':'')+esc(p.title)+'</a></td><td><span class="lvl lvl-'+(p.level||'')+'">'+(p.level||'-')+'</span></td><td>'+_n(p.imps)+'</td><td>'+_n(p.clicks)+'</td><td>'+_n(p.inquiries)+'</td><td>'+_n(p.tm)+'</td><td>'+_n(p.orders)+'</td><td>'+_n(p.gmv)+'</td></tr>';
    });
    h+='</tbody></table>';
  } else {
    h+='<div class="insight" style="margin-top:10px">本周无 '+title+' 产品。</div>';
  }
  h+='</div></div>';
  return h;
}
function renderBoss(){
  var el=document.getElementById('panel-boss'); if(!el) return;
  var B=D.boss;
  if(!B){ el.innerHTML='<div class="insight warn">该店暂无老板看板数据。请在数据管线上重跑 <code>v4_judge.py</code> 生成 boss 板块。</div>'; return; }
  // 周期口径：切到「月」时改用月度 KPI（B.kpi_month），否则顶部卡片一直是周数据、
  // 而下方漏斗已切成月数据，同屏混口径（回复三项平台只有 30d 口径，周/月共用同一值）
  var k=(PERIOD==='month' && B.kpi_month) ? B.kpi_month : B.kpi;
  var _perLabel=(PERIOD==='month' && B.month_label) ? ('月 '+B.month_label) : ('周 '+B.week_label);
  var sp=(PERIOD==='month' && B.spend_month) ? B.spend_month : (B.spend||{});
  var m=getBossManual();
  var adSpend = (m.ad_spend_override!=null && m.ad_spend_override!=='') ? Number(m.ad_spend_override) : (sp.ad_spend||0);
  var otherSpend = Number(m.annual_fee||0) + Number(m.wendin||0) + Number(m.topshow||0) + Number(m.brand_ad||0);
  var totalSpend = (adSpend||0) + otherSpend;
  var acq = Number(m.acquisition||0);
  var qc  = Number(m.quality_customers||0);
  var cac = (m.cac!=null && m.cac!=='') ? Number(m.cac) : (acq>0 ? totalSpend/acq : null);
  var sample = Number(m.sample_orders||0);
  var adConv = sp.ad_cpl||null;

  var h='';
  h+='<div class="boss-head"><h2>👔 老板看板 · 经营总览</h2><div class="sub">'+_perLabel+'　｜　<span style="color:#4ade80">绿=自动</span> · <span style="color:#fbbf24">黄=运营手动</span> · <span style="color:#60a5fa">蓝=自动推算</span></div></div>';

  h+='<div class="boss-sec"><h3>💰 花费与获客</h3><div class="kpi-grid">';
  h+=_kpi('广告花费', _m(adSpend), sp.ad_spend_auto?'自动·全站推':'手动', sp.ad_spend_auto?'auto':'manual', 'CPC '+_n(sp.ad_cpc)+' · 点击 '+_n(sp.ad_clicks));
  h+=_kpi('品牌/其他花费', _m(otherSpend), '手动','manual','年费'+_m(m.annual_fee||0)+' 问鼎'+_m(m.wendin||0)+' 顶展'+_m(m.topshow||0)+' 品牌广告'+_m(m.brand_ad||0));
  h+=_kpi('店铺总花费', _m(totalSpend), '推算','derived','广告花费 + 其他花费');
  h+=_kpi('获客数量', _n(acq), '手动','manual','运营填写（获客成本分母）');
  h+=_kpi('优质获客数量', _n(qc), '手动','manual','运营填写（其中优质客户）');
  h+=_kpi('获客成本', _m(cac), (m.cac!=null&&m.cac!=='')?'手动':'推算', (m.cac!=null&&m.cac!=='')?'manual':'derived', acq>0?'总花费 ÷ 获客数量':'填获客数量后自动算');
  h+=_kpi('广告平均转化成本', _m(adConv), (adConv!=null&&adConv>0)?'自动':'-','auto','单商机成本(全站推CPL)');
  var sampProd=m.sample_products||'', ordProd=m.order_products||'';
  h+='<div class="kpi manual"><span class="tag manual">手动</span><div class="lab">样品单</div><div class="val">'+_n(sample)+'</div><div class="sub">'+(sampProd?'<a class="boss-exp" data-boss-exp="sample">样品产品 '+esc(sampProd.length>14?sampProd.slice(0,14)+'…':sampProd)+'</a>':'运营填写（可填具体产品）')+'</div></div>';
  /* [本机补丁 2026-10-27] 订单(成交)与成交金额改手动填写：接口口径与实际成交对不上时以运营手填为准，平台自动值保留在卡内小字做对照。 */
  var ordManual=(m.order_manual!=null&&m.order_manual!=='')?Number(m.order_manual):null;
  var gmvManual=(m.gmv_manual!=null&&m.gmv_manual!=='')?Number(m.gmv_manual):null;
  h+='<div class="kpi manual"><span class="tag manual">手动</span><div class="lab">订单(成交)</div><div class="val">'+_n(ordManual)+'</div><div class="sub">运营填写 · 平台自动值 '+_n(k.orders)+'（GMV '+_m(k.gmv)+'）'+(ordProd?' · <a class="boss-exp" data-boss-exp="order">订单产品 '+esc(ordProd.length>14?ordProd.slice(0,14)+'…':ordProd)+'</a>':'')+'</div></div>';
  h+='<div class="kpi manual"><span class="tag manual">手动</span><div class="lab">成交金额</div><div class="val">'+(gmvManual==null?'未提供 / 未填写':'$'+gmvManual.toLocaleString(undefined,{maximumFractionDigits:2}))+'</div><div class="sub">运营填写（USD，同平台GMV口径）· 平台自动值 '+_m(k.gmv)+'</div></div>';
  h+='<div class="kpi auto boss-jump" data-jump="bossSec_hot" title="点击查看爆品"><span class="tag auto">自动</span><div class="lab">爆品数量</div><div class="val">'+_n(B.hot_count)+'</div><div class="sub">▾ 点击查看爆品</div></div>';
  h+='<div class="kpi auto boss-jump" data-jump="bossSec_premium" title="点击查看优品"><span class="tag auto">自动</span><div class="lab">优品数量</div><div class="val">'+_n(B.premium_count)+'</div><div class="sub">▾ 点击查看优品</div></div>';
  h+='<div class="kpi auto boss-jump" data-jump="bossSec_potential" title="点击查看潜力优品"><span class="tag auto">自动</span><div class="lab">潜力优品数量</div><div class="val">'+_n(B.potential_count)+'</div><div class="sub">▾ 点击查看潜力优品</div></div>';
  h+='<div class="kpi manual boss-jump" data-jump="bossNewSec" title="点击查看具体新品"><span class="tag manual">手动</span><div class="lab">新品数量</div><div class="val">'+_n(m.new_count)+'</div><div class="sub">▾ 点击查看具体新品</div></div>';
  h+='</div>';
  h+='<div class="boss-exp-detail" id="bossExp_order" style="display:none"><b>订单产品：</b>'+(ordProd?esc(ordProd):'<span class="muted">（未填写）</span>')+'</div>';
  h+='<div class="boss-exp-detail" id="bossExp_sample" style="display:none"><b>样品单产品：</b>'+(sampProd?esc(sampProd):'<span class="muted">（未填写）</span>')+'</div>';
  h+='</div>';

  h+='<div class="boss-sec"><h3>📈 店铺漏斗 <span class="flabel">'+esc(bossPeriodLabel())+' · 每项含 同行优秀/平均 + 较比上周</span></h3>';
  h+=funnelCardsHtml();
  h+='</div>';

  h+='<div class="boss-sec"><h3>📈 承接效率 <span class="flabel">回复三项 + 访客成交率 vs 同行优秀/平均</span></h3>';
  h+=bearingCardsHtml();
  h+='</div>';

  h+=productLevelSection('🔥','爆品', B.hot_count, B.hot_products, 'bossSec_hot','hot');
  h+=productLevelSection('⭐','优品', B.premium_count, B.premium_products, 'bossSec_premium','premium');
  h+=productLevelSection('🌱','潜力优品', B.potential_count, B.potential_products, 'bossSec_potential','potential');

  h+='<div class="boss-sec" id="bossNewSec"><h3>🆕 新品 <span class="flabel">下方从带图产品池点选 · 新品数量自己填写</span></h3><div class="kpi-grid" style="margin-bottom:12px">';
  h+=_kpi('新品数量', _n(m.new_count),'手动','manual','运营填写（本周/本月上新款数）');
  h+='<div class="kpi manual"><span class="tag manual">手动</span><div class="lab">已点选产品</div><div class="val"><span id="bossNewSel">'+m.new_selection.length+'</span></div><div class="sub">下方点选具体产品</div></div>';
  h+='</div>';
  h+='<div id="bossNewSelBox">'+renderNewSelected(m)+'</div>';
  var poolN=(D.boss.product_pool||[]).length;
  h+='<button id="bossNewPoolToggle" class="boss-collapse-btn" type="button" style="margin-top:12px">▸ 展开产品池点选新品（'+poolN+' 个，带图）</button>';
  h+='<div id="bossNewPool" style="display:none;margin-top:10px"><div class="np-browse-head"><span>🛒 产品池点选新品（带图，点击=选中 / 再点=取消）</span><input id="bossNewSearch" class="manual-input np-filter" placeholder="可选：输入关键词过滤…"></div><div id="bossNewPick" class="newpick newpick-open"></div></div>';
  h+='</div>';

  h+='<div class="boss-sec"><h3>运营录入区（填写后导出）</h3><div class="boss-manual">';
  h+='<div class="bm-row"><label>获客数量</label><input data-bm="acq" type="number" value="'+esc(String(m.acquisition))+'"><span class="bm-ph">本周/本月总新增客户数（获客成本分母）</span></div>';
  h+='<div class="bm-row"><label>优质获客数量</label><input data-bm="qc" type="number" value="'+esc(String(m.quality_customers))+'"><span class="bm-ph">其中优质客户数</span></div>';
  h+='<div class="bm-row"><label>获客成本 (¥)</label><input data-bm="cac" type="text" value="'+esc(String(m.cac==null?'':m.cac))+'"><span class="bm-ph">留空=自动用 总花费÷获客数量</span></div>';
  h+='<div class="bm-row"><label>新品数量</label><input data-bm="newcount" type="number" value="'+esc(String(m.new_count))+'"><span class="bm-ph">本周/本月上新款数</span></div>';
  h+='<div class="bm-row"><label>订单(成交)</label><input data-bm="ordercnt" type="number" value="'+esc(String(m.order_manual==null?'':m.order_manual))+'"><span class="bm-ph">本周/本月成交订单数（手动填写，平台自动值仅作对照）</span></div>';
  h+='<div class="bm-row"><label>成交金额 ($)</label><input data-bm="gmvman" type="number" step="0.01" value="'+esc(String(m.gmv_manual==null?'':m.gmv_manual))+'"><span class="bm-ph">成交金额，美元（手动填写，与平台GMV同口径）</span></div>';
  h+='<div class="bm-row"><label>样品单数量</label><input data-bm="sample" type="number" value="'+esc(String(m.sample_orders))+'"><span class="bm-ph">运营填写</span></div>';
  h+='<div class="bm-row bm-row-block"><label>样品单产品</label><textarea data-bm="sampleprod" rows="2" class="bm-textarea" placeholder="手动录入样品单对应产品名称（可多个，用、隔开）">'+esc(m.sample_products||'')+'</textarea></div>';
  h+='<div class="bm-row"><label>年费 (¥)</label><input data-bm="annual" type="number" value="'+esc(String(m.annual_fee))+'"><span class="bm-ph">店铺年费/平台费</span></div>';
  h+='<div class="bm-row bm-row-block"><label>订单产品</label><textarea data-bm="orderprod" rows="2" class="bm-textarea" placeholder="手动录入成交订单对应产品名称（可多个，用、隔开）">'+esc(m.order_products||'')+'</textarea></div>';
  h+='<div class="bm-row"><label>问鼎 (¥)</label><input data-bm="wendin" type="number" value="'+esc(String(m.wendin))+'"><span class="bm-ph">问鼎推广花费</span></div>';
  h+='<div class="bm-row"><label>顶展 (¥)</label><input data-bm="topshow" type="number" value="'+esc(String(m.topshow))+'"><span class="bm-ph">顶展花费</span></div>';
  h+='<div class="bm-row"><label>品牌广告 (¥)</label><input data-bm="brand" type="number" value="'+esc(String(m.brand_ad))+'"><span class="bm-ph">品牌广告花费</span></div>';
  h+='<div class="bm-row"><label>广告花费覆盖 (¥)</label><input data-bm="adov" type="text" value="'+esc(String(m.ad_spend_override==null?'':m.ad_spend_override))+'"><span class="bm-ph">留空=用全站推自动值 '+_m(sp.ad_spend)+'</span></div>';
  h+='<div class="bm-tip">填写本次数据后，使用顶部导出生成报告。</div>';
  h+='</div></div>';

  el.innerHTML=h;
  initBossInteractions();
}
function initBossInteractions(){
  document.querySelectorAll('#panel-boss [data-bm]').forEach(function(inp){
    inp.addEventListener('change', function(){
      var m=getBossManual(), id=this.getAttribute('data-bm'), raw=this.value;
      if(id==='acq') m.acquisition = (raw==='')?0:Number(raw);
      else if(id==='qc') m.quality_customers = (raw==='')?0:Number(raw);
      else if(id==='sample') m.sample_orders = (raw==='')?0:Number(raw);
      else if(id==='annual') m.annual_fee = (raw==='')?0:Number(raw);
      else if(id==='wendin') m.wendin = (raw==='')?0:Number(raw);
      else if(id==='topshow') m.topshow = (raw==='')?0:Number(raw);
      else if(id==='brand') m.brand_ad = (raw==='')?0:Number(raw);
      else if(id==='cac') m.cac = (raw==='')?null:Number(raw);
      else if(id==='adov') m.ad_spend_override = (raw==='')?null:Number(raw);
      else if(id==='newcount') m.new_count = (raw==='')?0:Number(raw);
      else if(id==='ordercnt') m.order_manual = (raw==='')?null:Number(raw);
      else if(id==='gmvman') m.gmv_manual = (raw==='')?null:Number(raw);
      else if(id==='ordercnt') m.order_manual = (raw==='')?null:Number(raw);
      else if(id==='gmvman') m.gmv_manual = (raw==='')?null:Number(raw);
      else if(id==='sampleprod') m.sample_products = raw;
      else if(id==='orderprod') m.order_products = raw;
      saveBossManual(m); renderBoss();
    });
  });
  // 首栏 KPI 卡点击跳转（新品数量→新品区，优爆品→爆品区）
  document.querySelectorAll('#panel-boss [data-jump]').forEach(function(el){
    el.addEventListener('click', function(){
      var t=document.getElementById(this.getAttribute('data-jump'));
      if(t){ t.scrollIntoView({behavior:'smooth', block:'start'}); }
    });
  });
  // 爆品/优品/潜力优品 展开收起
  ['hot','premium','potential'].forEach(function(kk){
    var tg=document.getElementById('bossLvlToggle_'+kk); if(!tg) return;
    tg.addEventListener('click', function(){
      var body=document.getElementById('bossLvlBody_'+kk); if(!body) return;
      var open = body.style.display!=='none';
      body.style.display = open?'none':'block';
      tg.setAttribute('data-open', open?'0':'1');
      var label=tg.getAttribute('data-label');
      tg.textContent = open ? ('▸ 展开看'+label+'链接') : '▾ 收起'+label+'链接';
    });
  });
  // 订单/样品单 产品名 展开/收起
  document.querySelectorAll('#panel-boss .boss-exp').forEach(function(a){
    a.addEventListener('click', function(e){ e.preventDefault();
      var d=document.getElementById('bossExp_'+a.getAttribute('data-boss-exp')); if(!d) return;
      var open=d.style.display!=='none'; d.style.display=open?'none':'block';
      a.setAttribute('data-open', open?'0':'1');
    });
  });
  // 新品产品池展开/收起
  var newToggle=document.getElementById('bossNewPoolToggle');
  if(newToggle){ newToggle.addEventListener('click', function(){
    var body=document.getElementById('bossNewPool'); if(!body) return;
    var open = body.style.display!=='none';
    body.style.display = open?'none':'block';
    var n=(D.boss.product_pool||[]).length;
    newToggle.textContent = open ? ('▸ 展开产品池点选新品（'+n+' 个，带图）') : '▾ 收起产品池';
  }); }
  // 新品点选：默认显示带图产品池（无需先输入），可过滤，点击选中/取消；点选时局部刷新不整页重渲染
  var sInp=document.getElementById('bossNewSearch'), pick=document.getElementById('bossNewPick');
  if(sInp && pick){
    var pool=D.boss.product_pool||[];
    function renderPick(){
      var q=(sInp.value||'').trim().toLowerCase(), m=getBossManual();
      var list=pool.filter(function(p){ return !q || (p.title||'').toLowerCase().indexOf(q)>=0 || String(p.product_id).indexOf(q)>=0; });
      pick.innerHTML = list.length ? list.map(function(p){ var sel=m.new_selection.indexOf(p.product_id)>=0;
        return '<div class="newpick-item'+(sel?' sel':'')+'" data-pid="'+p.product_id+'">'+(p.main_image?'<img class="np-thumb" loading="lazy" src="'+esc(p.main_image)+'" alt="">':'')+'<span class="np-title">'+esc(p.title)+'</span><span class="np-meta">'+(p.level||'')+' · 点击'+_n(p.clicks)+' · <b>'+p.product_id+'</b></span></div>'; }).join('') : '<div class="np-empty">无匹配产品</div>';
    }
    renderPick();
    sInp.addEventListener('input', renderPick);
    pick.addEventListener('click', function(e){
      var it=e.target.closest('.newpick-item'); if(!it) return;
      var pid=it.getAttribute('data-pid'), m=getBossManual(), i=m.new_selection.indexOf(pid);
      if(i>=0) m.new_selection.splice(i,1); else m.new_selection.push(pid);
      saveBossManual(m);
      it.classList.toggle('sel');
      var selBox=document.getElementById('bossNewSelBox'); if(selBox) selBox.innerHTML=renderNewSelected(m);
      var cnt=document.getElementById('bossNewSel'); if(cnt) cnt.textContent=m.new_selection.length;
    });
  }
}
function setView(v){
  try{ localStorage.setItem('gos_view', v); }catch(e){}
  if(v==='boss') document.body.classList.add('view-boss'); else document.body.classList.remove('view-boss');
  document.querySelectorAll('#viewSwitch .vs-btn').forEach(function(b){ b.classList.toggle('on', b.getAttribute('data-view')===v); });
  if(v==='boss') renderBoss();
}
/* ===== 导出 CSV（老板/运营自选，当前周期）===== */
function _csvCell(v){ v=(v==null?'':String(v)); return '"'+v.replace(/"/g,'""')+'"'; }
function _csvLine(a){ return a.map(_csvCell).join(','); }
function _downloadCSV(name, text){
  try{
    var blob=new Blob(['\uFEFF'+text], {type:'text/csv;charset=utf-8;'});
    var url=URL.createObjectURL(blob); var a=document.createElement('a');
    a.href=url; a.download=name; document.body.appendChild(a); a.click();
    setTimeout(function(){ document.body.removeChild(a); URL.revokeObjectURL(url); }, 1500);
  }catch(e){ alert('导出失败: '+(e&&e.message?e.message:e)); }
}
function _downloadHTML(name, html){
  try{
    var blob=new Blob([html], {type:'text/html;charset=utf-8;'});
    var url=URL.createObjectURL(blob); var a=document.createElement('a');
    a.href=url; a.download=name; document.body.appendChild(a); a.click();
    setTimeout(function(){ document.body.removeChild(a); URL.revokeObjectURL(url); }, 1500);
  }catch(e){ alert('导出失败: '+(e&&e.message?e.message:e)); }
}
function exportView(view, fmt){
  if(typeof D==='undefined' || !D){ return; }
  if(fmt==='csv'){ exportCSV(view); return; }
  if(fmt==='xlsx'){ exportXLSX(view); return; }
  var store=window.V4_STORE||((D.meta&&D.meta.store_id)||'store');
  _downloadHTML(store+'_'+(view==='boss'?'老板看板':'运营看板')+'_数据留存_'+(bossPeriodLabel()||'').replace(/[~\-\/\s:]/g,'')+'.html', buildReportHTML(view));
}
function exportCSV(view){
  if(typeof D==='undefined' || !D){ return; }
  var meta=D.meta||{}, store=(window.V4_STORE||meta.store_id||'store'), B=D.boss||{}, k=B.kpi||{}, sp=B.spend||{};
  var plabel=bossPeriodLabel(), ptype=(PERIOD==='month'?'月':'周');
  var R=[];
  R.push(_csvLine(['店铺', meta.store_name||store, '店铺代码', store, '周期', ptype+_periodWeekTag(), '区间', plabel, '导出时间', new Date().toLocaleString()]));
  R.push(_csvLine([]));
  var fun=getFunnel();
  var m=getBossManual();
  var adSpend=(m.ad_spend_override!=null&&m.ad_spend_override!=='')?Number(m.ad_spend_override):(sp.ad_spend||0);
  var otherSpend=Number(m.annual_fee||0)+Number(m.wendin||0)+Number(m.topshow||0)+Number(m.brand_ad||0);
  var totalSpend=(adSpend||0)+otherSpend;
  var acq=Number(m.acquisition||0), qc=Number(m.quality_customers||0);
  var cac=(m.cac!=null&&m.cac!=='')?Number(m.cac):(acq>0?totalSpend/acq:null);
  /* 扁平单表：板块|指标|本期值|同行优秀|同行平均（值=原始数字，行顺序每周固定，便于整块复制到对比表 / AI 分析） */
  R.push(_csvLine(['板块','指标','本期值','同行优秀','同行平均']));
  R.push(_csvLine(['花费与获客','广告花费', adSpend]));
  R.push(_csvLine(['花费与获客','品牌/其他花费', otherSpend]));
  R.push(_csvLine(['花费与获客','店铺总花费', totalSpend]));
  R.push(_csvLine(['花费与获客','获客数量', acq]));
  R.push(_csvLine(['花费与获客','优质获客数量', qc]));
  R.push(_csvLine(['花费与获客','获客成本', cac==null?'':cac]));
  R.push(_csvLine(['花费与获客','广告平均转化成本(CPL)', sp.ad_cpl==null?'':sp.ad_cpl]));
  R.push(_csvLine(['花费与获客','样品单', m.sample_orders||0]));
  R.push(_csvLine(['花费与获客','订单(成交)', k.orders||0]));
  R.push(_csvLine(['花费与获客','订单(成交)手填', m.order_manual==null?'':m.order_manual]));
  R.push(_csvLine(['花费与获客','成交金额手填($)', m.gmv_manual==null?'':m.gmv_manual]));
  R.push(_csvLine(['花费与获客','爆品数量', B.hot_count||0]));
  R.push(_csvLine(['花费与获客','优品数量', B.premium_count||0]));
  R.push(_csvLine(['花费与获客','潜力优品数量', B.potential_count||0]));
  R.push(_csvLine(['花费与获客','新品数量', m.new_count||0]));
  R.push(_csvLine(['花费与获客','订单产品', m.order_products||'-']));
  R.push(_csvLine(['花费与获客','样品单产品', m.sample_products||'-']));
  fun.forEach(function(f){ R.push(_csvLine(['店铺漏斗', f.label, f.cur==null?'':f.cur, f.rival_good==null?'':f.rival_good, f.rival_avg==null?'':f.rival_avg])); });
  _downloadCSV((store||'store')+'_'+(view==='boss'?'老板看板':'运营看板')+'_数据留存_'+(plabel||'').replace(/[~\-\/\s:]/g,'')+'.csv', R.join('\r\n'));
}
/* ===== Excel 格式化表格导出（ExcelJS：真实 xlsx，带配色/边框/列宽/冻结表头，WPS/Excel 打开即美观）===== */
var XLS_C={ navy:'FF16324F', head:'FF2C4A6E', gold:'FFF5C518', sub:'FF5B6B7B', zebra:'FFF7FAFC', border:'FFD9E2EC',
  g:'FF1A7F4B', gFill:'FFE6F4EC', r:'FFC0392B', rFill:'FFFDECEA', r2:'FFD64545',
  o:'FFB8741A', oFill:'FFFBF0DF', b:'FF2B6CB0', bFill:'FFEBF1FB', link:'FF2563EB', txt:'FF1F2733' };
function _xlsBorder(){ return {top:{style:'thin',color:{argb:XLS_C.border}},left:{style:'thin',color:{argb:XLS_C.border}},bottom:{style:'thin',color:{argb:XLS_C.border}},right:{style:'thin',color:{argb:XLS_C.border}}}; }
function _xNumFmt(f){ if(f==='pct') return '0.00"%"'; if(f==='money') return '"$"#,##0'; return '#,##0'; }
function _isoWeek(dstr){
  try{
    var d=new Date(dstr+'T00:00:00Z'), day=(d.getUTCDay()+6)%7;
    d.setUTCDate(d.getUTCDate()-day+3);
    var ft=new Date(Date.UTC(d.getUTCFullYear(),0,4)), fd=(ft.getUTCDay()+6)%7;
    ft.setUTCDate(ft.getUTCDate()-fd+3);
    return 1+Math.round((d-ft)/(7*86400000));
  }catch(e){ return null; }
}
function _periodWeekTag(){
  if(PERIOD!=='week') return '';
  var ds='';
  try{ var w=selectedWeek(); if(w&&w.week_start) ds=w.week_start; }catch(e){}
  if(!ds){ var pm=(bossPeriodLabel()||'').match(/\d{4}-\d{2}-\d{2}/); ds=pm?pm[0]:''; }
  if(!ds) return '';
  var wn=_isoWeek(ds);
  return wn?('（第'+wn+'自然周 · W'+wn+'）'):'';
}

function _xcell(cell, v, o){
  o=o||{};
  var empty=(v==null||v==='');
  if(empty){ if(o.dash!==false) v='-'; }
  else if(o.link) cell.value={text:v,hyperlink:o.link};
  else cell.value=v;
  if(o.numFmt && typeof v==='number') cell.numFmt=o.numFmt;
  var font={size:11,color:{argb:o.color||XLS_C.txt}};
  if(o.bold) font.bold=true;
  if(o.link){ font.underline=true; font.color={argb:XLS_C.link}; }
  cell.font=font;
  if(o.fill) cell.fill={type:'pattern',pattern:'solid',fgColor:{argb:o.fill}};
  cell.border=_xlsBorder();
  cell.alignment={horizontal:o.align||'left',vertical:'middle',wrapText:!!o.wrap,indent:1};
  return cell;
}
function _xlsHeadRow(ws, row, heads){
  ws.getRow(row).height=22;
  heads.forEach(function(h,j){ var c=ws.getCell(row,j+1); c.value=h||'—'; c.font={bold:true,size:11,color:{argb:'FFFFFFFF'}}; c.fill={type:'pattern',pattern:'solid',fgColor:{argb:XLS_C.head}}; c.alignment={horizontal:'center',vertical:'middle'}; c.border=_xlsBorder(); });
  return row+1;
}
/* 数据留存：两个板块分表（工作表1=花费与获客「指标|本期值」，工作表2=店铺漏斗「指标|本期值|同行优秀|同行平均|备注」）
   每张表顶部 店铺(金底)+周期/区间(navy底) 分区色块 —— 与用户主对比表同构：
   每周把对应列复制进主表新列即可；行顺序每周固定、值为原始数字 */
function _xlsSheetHead(ws, nC, store, blockName, sKey, ptype, plabel){
  var i;
  ws.mergeCells(1,1,1,nC);
  for(i=1;i<=nC;i++){ ws.getCell(1,i).fill={type:'pattern',pattern:'solid',fgColor:{argb:XLS_C.navy}}; }
  ws.getCell(1,1).value='📁 '+store+' · '+blockName+' · 数据留存 ｜ 🕒 '+new Date().toLocaleString();
  ws.getCell(1,1).font={bold:true,size:14,color:{argb:'FFFFFFFF'}}; ws.getCell(1,1).alignment={horizontal:'left',vertical:'middle',indent:1};
  ws.getRow(1).height=30;
  ws.getRow(2).height=22;
  ws.getCell(2,1).value='🏪 店铺: '+sKey;
  ws.getCell(2,1).fill={type:'pattern',pattern:'solid',fgColor:{argb:'FFF5C518'}};
  ws.getCell(2,1).font={size:11,bold:true,color:{argb:XLS_C.navy}};
  ws.getCell(2,1).alignment={horizontal:'center',vertical:'middle'};
  ws.getCell(2,1).border=_xlsBorder();
  ws.mergeCells(2,2,2,nC);
  for(i=2;i<=nC;i++){ ws.getCell(2,i).fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF2C4A6E'}}; ws.getCell(2,i).border=_xlsBorder(); }
  ws.getCell(2,2).value='📅 周期: '+ptype+_periodWeekTag()+' ｜ 📆 区间: '+plabel;
  ws.getCell(2,2).font={size:11,bold:true,color:{argb:'FFFFFFFF'}};
  ws.getCell(2,2).alignment={horizontal:'center',vertical:'middle'};
}
function exportXLSX(view){
  if(typeof D==='undefined' || !D){ return; }
  if(typeof ExcelJS==='undefined'){ alert('ExcelJS 组件未加载（网络拦截了 CDN），请刷新重试，或先选 CSV / HTML报告 导出'); return; }
  var meta=D.meta||{}, store=meta.store_name||meta.store_id||'store', B=D.boss||{}, k=B.kpi||{}, sp=B.spend||{};
  var sKey=window.V4_STORE||meta.store_id||'-';
  var plabel=bossPeriodLabel(), ptype=(PERIOD==='month'?'月':'周'), baseName=(view==='boss'?'老板看板':'运营看板');
  var wb=new ExcelJS.Workbook();
  wb.creator='Alibaba Growth OS'; wb.modified=new Date();
  var fun=getFunnel(), m=getBossManual();
  var adSpend=(m.ad_spend_override!=null&&m.ad_spend_override!=='')?Number(m.ad_spend_override):(sp.ad_spend||0);
  var otherSpend=Number(m.annual_fee||0)+Number(m.wendin||0)+Number(m.topshow||0)+Number(m.brand_ad||0);
  var totalSpend=(adSpend||0)+otherSpend;
  var acq=Number(m.acquisition||0), qc=Number(m.quality_customers||0);
  var cac=(m.cac!=null&&m.cac!=='')?Number(m.cac):(acq>0?totalSpend/acq:null);
  /* ── 表1：花费与获客（指标|本期值）── */
  var ws1=wb.addWorksheet('花费与获客',{views:[{state:'frozen',ySplit:3}]});
  ws1.columns=[{width:22},{width:30}];
  _xlsSheetHead(ws1,2, store, '花费与获客', sKey, ptype, plabel);
  _xlsHeadRow(ws1,3,['指标','本期值']);
  var kpiRows=[
    ['广告花费', adSpend, '"¥"#,##0'],
    ['品牌/其他花费', otherSpend, '"¥"#,##0'],
    ['店铺总花费', totalSpend, '"¥"#,##0'],
    ['获客数量', acq, '#,##0'],
    ['优质获客数量', qc, '#,##0'],
    ['获客成本', cac, '"¥"#,##0.00'],
    ['广告平均转化成本(CPL)', sp.ad_cpl, '"¥"#,##0.00'],
    ['样品单', m.sample_orders, '#,##0'],
    ['订单(成交)', k.orders, '#,##0'],
    ['订单(成交)手填', m.order_manual, '#,##0'],
    ['成交金额手填($)', m.gmv_manual, '"$"#,##0.00'],
    ['爆品数量', B.hot_count, '#,##0'],
    ['优品数量', B.premium_count, '#,##0'],
    ['潜力优品数量', B.potential_count, '#,##0'],
    ['新品数量', m.new_count, '#,##0'],
    ['订单产品', m.order_products||'-', null],
    ['样品单产品', m.sample_products||'-', null]
  ];
  var r=4;
  kpiRows.forEach(function(row,idx){
    var zf=(idx%2===1)?XLS_C.zebra:null;
    var g=ws1.getRow(r);
    _xcell(g.getCell(1), row[0], {bold:true, fill:zf});
    var isStr=(typeof row[1]==='string');
    _xcell(g.getCell(2), row[1], {numFmt:row[2], bold:true, align:isStr?'center':'right', fill:zf});
    r++;
  });
  ws1.autoFilter={from:{row:3,column:1},to:{row:r-1,column:2}};
  /* ── 表2：店铺漏斗（指标|本期值|同行优秀|同行平均）── */
  var ws2=wb.addWorksheet('店铺漏斗',{views:[{state:'frozen',ySplit:3}]});
  ws2.columns=[{width:22},{width:14},{width:12},{width:14}];
  _xlsSheetHead(ws2,4, store, '店铺漏斗', sKey, ptype, plabel);
  _xlsHeadRow(ws2,3,['指标','本期值','同行优秀','同行平均']);
  var r2=4;
  (fun||[]).forEach(function(f,idx){
    var zf=(idx%2===1)?XLS_C.zebra:null;
    var g=ws2.getRow(r2);
    _xcell(g.getCell(1), f.label, {bold:true, fill:zf});
    _xcell(g.getCell(2), f.cur, {numFmt:_xNumFmt(f.fmt), bold:true, align:'right', fill:zf});
    _xcell(g.getCell(3), f.rival_good, {numFmt:_xNumFmt(f.fmt), align:'right', fill:zf});
    _xcell(g.getCell(4), f.rival_avg, {numFmt:_xNumFmt(f.fmt), align:'right', fill:zf});
    r2++;
  });
  ws2.autoFilter={from:{row:3,column:1},to:{row:r2-1,column:4}};
  wb.xlsx.writeBuffer().then(function(buf){
    _downloadXLSX(store+'_'+baseName+'_数据留存_'+(plabel||'').replace(/[~\-\/\s:]/g,'')+'.xlsx', buf);
  }).catch(function(e){ alert('Excel 导出失败: '+(e&&e.message?e.message:e)); });
}
function _downloadXLSX(name, buf){
  try{
    var blob=new Blob([buf], {type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
    var url=URL.createObjectURL(blob); var a=document.createElement('a');
    a.href=url; a.download=name; document.body.appendChild(a); a.click();
    setTimeout(function(){ document.body.removeChild(a); URL.revokeObjectURL(url); }, 1500);
  }catch(e){ alert('导出失败: '+(e&&e.message?e.message:e)); }
}
var RPT_CSS='*{box-sizing:border-box}body{margin:0;font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;background:#eef1f4;color:#1f2733;font-size:13px}.wrap{max-width:1180px;margin:0 auto;padding:20px}.rhead{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;background:#16324f;color:#fff;border-radius:12px;padding:18px 22px;margin-bottom:16px}.rt{font-size:20px;font-weight:800}.rs{margin-top:6px;font-size:12px;opacity:.92}.rs b{padding:1px 7px;border-radius:10px;font-size:11px;font-weight:700}.rs .c-g{background:#1a7f4b}.rs .c-o{background:#d98a1f}.rs .c-b{background:#2b6cb0}.rprint{background:#f5c518;color:#1f2733;border:0;border-radius:8px;padding:9px 16px;font-size:13px;font-weight:700;cursor:pointer;white-space:nowrap}.rprint:hover{filter:brightness(.96)}section{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:16px 18px;margin-bottom:14px}h2{font-size:16px;font-weight:800;color:#16324f;margin:0 0 14px;padding-left:10px;border-left:4px solid #f5c518}h2 .hsub{font-size:12px;font-weight:500;color:#7a8794;margin-left:8px}h2 .cnt{font-size:12px;font-weight:700;color:#2b6cb0;background:#eaf1fb;border-radius:10px;padding:1px 9px;margin-left:6px}.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(178px,1fr));gap:11px}.kpi{position:relative;border:1px solid #e2e8f0;border-left:4px solid #ccc;border-radius:9px;padding:12px 14px}.kpi.auto{border-left-color:#1a7f4b}.kpi.manual{border-left-color:#d98a1f}.kpi.derived{border-left-color:#2b6cb0}.ktag{position:absolute;top:10px;right:10px;font-size:10px;font-weight:700;padding:1px 8px;border-radius:10px}.kpi.auto .ktag{background:#e6f4ec;color:#1a7f4b}.kpi.manual .ktag{background:#fbf0df;color:#b8741a}.kpi.derived .ktag{background:#eaf1fb;color:#2b6cb0}.klab{color:#5b6b7b;font-size:12px;margin-bottom:6px;padding-right:36px}.kval{font-size:22px;font-weight:800;line-height:1.15}.ksub{margin-top:6px;font-size:11px;color:#8593a1;line-height:1.45;word-break:break-all}.tbl{width:100%;border-collapse:collapse;font-size:12px}.tbl th{background:#f5f7fa;text-align:left;padding:8px 10px;font-weight:700;color:#3a4a5a;border-bottom:2px solid #e2e8f0;white-space:nowrap}.tbl td{padding:8px 10px;border-bottom:1px solid #eef1f4;vertical-align:middle}.tbl tbody tr:nth-child(even){background:#fafbfc}.tbl .tl{color:#1f2733}.tbl .tv{font-weight:800}.tbl .rg,.tbl .ra{color:#5b6b7b}.wow.up{color:#1a7f4b;font-weight:700}.wow.down{color:#c0392b;font-weight:700}.dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:5px}.dot.ok{background:#1a7f4b}.dot.bad{background:#c0392b}.lvl{display:inline-block;padding:1px 8px;border-radius:10px;font-size:11px;font-weight:700;white-space:nowrap}.lvl.l-hot{background:#fdecea;color:#c0392b}.lvl.l-prem{background:#e6f4ec;color:#1a7f4b}.lvl.l-pot{background:#eaf1fb;color:#2b6cb0}.ptbl .pth{width:34px;height:34px;object-fit:cover;border-radius:5px;border:1px solid #e2e8f0;vertical-align:middle;margin-right:6px}.ptbl a{color:#2b6cb0;font-weight:600;text-decoration:none}.ptbl a:hover{text-decoration:underline}.mut{color:#9aa7b4}.banner{background:#eef4fb;border-left:4px solid #2b6cb0;border-radius:8px;padding:10px 14px;margin-top:10px;font-size:13px;color:#16324f}.banner b{font-weight:800}.bmut{color:#8593a1;font-size:12px;margin-left:6px}.rfoot{text-align:center;color:#9aa7b4;font-size:11px;padding:8px 0 20px}@media print{body{background:#fff}.rprint{display:none}.wrap{padding:0;max-width:none}section{break-inside:avoid;border-color:#ddd}.rhead{-webkit-print-color-adjust:exact;print-color-adjust:exact}}';
function _rptKpi(label, value, type, sub){ var cls=(type==='auto')?'auto':((type==='manual')?'manual':'derived'); var tag=(type==='auto')?'自动':((type==='manual')?'手动':'推算'); return '<div class="kpi '+cls+'"><div class="ktag">'+tag+'</div><div class="klab">'+esc(label)+'</div><div class="kval">'+value+'</div><div class="ksub">'+(sub?esc(sub):'')+'</div></div>'; }
function _rptWow(wow){ if(wow==null) return '<span class="mut">环比 -</span>'; var up=(wow>=0); return '<span class="wow '+(up?'up':'down')+'">'+(up?'▲ +':'▼ ')+Math.round(wow)+'%</span>'; }
function buildReportHTML(view){
  var meta=D.meta||{}, B=D.boss||{}, k=B.kpi||{}, sp=B.spend||{};
  var plabel=bossPeriodLabel(), ptype=(PERIOD==='month'?'月':'周');
  var fun=getFunnel(), bea=getBearing(), m=getBossManual();
  var adSpend=(m.ad_spend_override!=null&&m.ad_spend_override!=='')?Number(m.ad_spend_override):(sp.ad_spend||0);
  var otherSpend=Number(m.annual_fee||0)+Number(m.wendin||0)+Number(m.topshow||0)+Number(m.brand_ad||0);
  var totalSpend=(adSpend||0)+otherSpend;
  var acq=Number(m.acquisition||0), qc=Number(m.quality_customers||0);
  var cac=(m.cac!=null&&m.cac!=='')?Number(m.cac):(acq>0?totalSpend/acq:null);
  var H=[];
  var baseName=(view==='boss'?'老板看板':'运营看板');
  H.push('<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(meta.store_name||'')+' '+baseName+' 数据留存</title><style>'+RPT_CSS+'</style></head><body><div class="wrap">');
  H.push('<div class="rhead"><div><div class="rt">📁 '+esc(meta.store_name||'')+' · '+baseName+' · 数据留存</div><div class="rs">店铺 '+esc(window.V4_STORE||meta.store_id||'-')+' ｜ '+ptype+esc(_periodWeekTag())+' · '+esc(plabel)+' · 导出 '+new Date().toLocaleString()+' ｜ <b class="c-g">绿</b>=自动 <b class="c-o">黄</b>=手动 <b class="c-b">蓝</b>=推算</div></div><button class="rprint" onclick="window.print()">🖨 打印 / 存为PDF</button></div>');
  H.push('<section><h2>💰 花费与获客</h2><div class="cards">');
  H.push(_rptKpi('广告花费', _m(adSpend), sp.ad_spend_auto?'auto':'manual', 'CPC '+(sp.ad_cpc==null?'-':sp.ad_cpc)+' · 点击 '+(sp.ad_clicks==null?'-':sp.ad_clicks)));
  H.push(_rptKpi('品牌/其他花费', _m(otherSpend), 'manual', '年费'+(m.annual_fee||0)+' 问鼎'+(m.wendin||0)+' 顶展'+(m.topshow||0)+' 品牌广告'+(m.brand_ad||0)));
  H.push(_rptKpi('店铺总花费', _m(totalSpend), 'derived', '广告 '+_m(adSpend)+' + 其他 '+_m(otherSpend)));
  H.push(_rptKpi('获客数量', _n(acq), 'manual', '获客成本分母'));
  H.push(_rptKpi('优质获客数量', _n(qc), 'manual', '其中优质客户'));
  H.push(_rptKpi('获客成本', _m(cac), (m.cac!=null&&m.cac!=='')?'manual':'derived', acq>0?'总花费÷获客数量('+acq+')':'填获客数量后自动算'));
  H.push(_rptKpi('广告平均转化成本', _m(sp.ad_cpl), (sp.ad_cpl!=null&&sp.ad_cpl>0)?'auto':'manual', 'CPL 单商机成本'));
  H.push(_rptKpi('样品单', _n(m.sample_orders), 'manual', '数量'));
  H.push(_rptKpi('订单(成交)', _n(k.orders), 'auto', 'GMV $'+(k.gmv==null?'-':k.gmv)));
  H.push(_rptKpi('订单(成交)手填', _n(m.order_manual), 'manual', '单'));
  H.push(_rptKpi('成交金额手填', (m.gmv_manual==null||m.gmv_manual==='')?'未提供 / 未填写':'$'+Number(m.gmv_manual).toLocaleString(undefined,{maximumFractionDigits:2}), 'manual', 'USD'));
  H.push(_rptKpi('爆品数量', _n(B.hot_count), 'auto', 'prod_level=爆品'));
  H.push(_rptKpi('优品数量', _n(B.premium_count), 'auto', 'prod_level=优品'));
  H.push(_rptKpi('潜力优品数量', _n(B.potential_count), 'auto', 'prod_level=潜力优品'));
  H.push(_rptKpi('新品数量', _n(m.new_count), 'manual', '已点选 '+(m.new_selection||[]).length+' 个产品'));
  H.push('</div>');
  H.push('<div class="banner">🧾 订单产品：<b>'+esc(m.order_products||'-')+'</b><span class="bmut">（本周期成交订单对应产品）</span></div>');
  H.push('<div class="banner">🧪 样品单产品：<b>'+esc(m.sample_products||'-')+'</b><span class="bmut">（本周期样品单对应产品）</span></div>');
  H.push('</section>');
  H.push('<section><h2>📈 店铺漏斗 <span class="hsub">'+esc(plabel)+' · 每项含 同行优秀/平均 + 较比上周</span></h2><table class="tbl"><thead><tr><th>指标</th><th>本期</th><th>较比上周</th><th>同行优秀</th><th>同行平均</th></tr></thead><tbody>');
  fun.forEach(function(f){ H.push('<tr><td class="tl">'+esc(f.label)+'</td><td class="tv">'+fmt(f.fmt,f.cur)+'</td><td>'+_rptWow(f.wow)+'</td><td class="rg">'+(f.rival_good==null?'-':fmt(f.fmt,f.rival_good))+'</td><td class="ra">'+(f.rival_avg==null?'-':fmt(f.fmt,f.rival_avg))+'</td></tr>'); });
  H.push('</tbody></table></section>');
  H.push('<div class="rfoot">Alibaba Growth OS · '+baseName+' 数据留存报告 · 生成于 '+new Date().toLocaleString()+'</div>');
  H.push('</div></body></html>');
  return H.join('');
}
function initBossView(){
  var sw=document.getElementById('viewSwitch'); if(!sw) return;
  var exBtn=document.getElementById('bossExportBtn');
  if(exBtn){ exBtn.addEventListener('click', function(){ var s=document.getElementById('bossExportView'), f=document.getElementById('bossExportFmt'); exportView((s&&s.value)||'boss', (f&&f.value)||'html'); }); }
  sw.addEventListener('click', function(e){ var b=e.target.closest('.vs-btn'); if(!b) return; setView(b.getAttribute('data-view')); });
  var saved='boss'; try{ saved=localStorage.getItem('gos_view')||'boss'; }catch(e){}
  setView(saved);
}
/* ===================== /老板看板 ===================== */

/* 周期切换要重渲染「所有」面板：原来只刷新周期看板+老板看板，
   导致重点关注/AI搜索/趋势对比等页切月后内容纹丝不动（看着像切换没生效） */
function refreshAllPanels(){
  renderPeriod(); renderFocus(); renderAI(); renderTrend(); renderExec();
  renderCompete(); renderPeer(); renderAdmin();
  renderBossIfActive();
  if (typeof drawTrendChart === 'function') setTimeout(drawTrendChart, 50);
}
function boot(){
  loadScores();
  updateDateLabel();
  // 单店看板：店名与运营者名都由构建时注入（v4_build.py 替换 __STORE_NAME__ / __USER_LABEL__），
  // 前端不再做店铺切换，也不再覆盖顶部文案（否则会把注入值冲掉）。
  // 周/月选择器
  populatePeriodSel();
  renderPeriod(); renderFocus(); renderAI(); renderTrend(); renderExec(); renderCompete(); renderPeer(); renderAdmin();
  // tab 切换
  var tabs=document.querySelectorAll('#navbar .tab');
  tabs.forEach(function(t){
    t.onclick=function(){
      tabs.forEach(function(x){x.classList.remove('on');});
      t.classList.add('on');
      var k=t.getAttribute('data-tab');
      document.querySelectorAll('.tabpanel').forEach(function(p){p.classList.remove('on');});
      document.getElementById('panel-'+k).classList.add('on');
      if(k==='trend'){ setTimeout(drawTrendChart, 50); }
    };
  });
  // 周/月切换
  document.getElementById('segWeek').onclick=function(){ PERIOD='week'; this.classList.add('on'); document.getElementById('segMonth').classList.remove('on'); updateDateLabel(); populatePeriodSel(); refreshAllPanels(); };
  document.getElementById('segMonth').onclick=function(){ PERIOD='month'; this.classList.add('on'); document.getElementById('segWeek').classList.remove('on'); updateDateLabel(); populatePeriodSel(); refreshAllPanels(); };
  // 全局搜索
  initGlobalSearch();
  // 老板/运营视角切换
  initBossView();
}
function initGlobalSearch(){
  var inp=document.getElementById('globalSearch');
  var drop=document.getElementById('searchDrop');
  if(!inp||!drop) return;
  // 索引：tab + 板块 + 产品
  var idx=[];
  var tabs=['周期看板','重点关注','AI搜索','趋势对比','改造执行台','竞品对比','同行标杆','管理'];
  var tabIds=['period','focus','ai','trend','exec','compete','peer','admin'];
  tabs.forEach(function(t,i){ idx.push({type:'板块', name:t, tab:tabIds[i], section:''}); });
  var sections=[['店铺漏斗','funnel'],['承接效率','bearing'],['客服子账号','staff'],['店铺健康','health'],['广告花费拆解','ad'],['国家地区','country'],['市场机会','market'],['流量渠道','channel'],['买家L1+','buyerl1'],['关键词机会','keyword'],['0效果产品','zeroeffect'],['本期总结','summary'],['商机榜','opp'],['TM商机榜','tm'],['点击率榜','ctr'],['零花费榜','zero'],['高效低耗榜','eff'],['新品追踪','newprod']];
  window._sectionsIdx=sections;
  sections.forEach(function(s){ idx.push({type:'板块', name:s[0], tab:'period', section:s[1]}); });
  var seen={};
  var catSet={};
  ['opp','inquiry','tm','ctr','zero_cost','high_eff_low_cost'].forEach(function(k){(getLists()[k]||[]).forEach(function(p){ if(!seen[p.product_id]){seen[p.product_id]=1; idx.push({type:'产品', name:(p.title||'')+' '+(p.category||''), tab:'ai', pid:p.product_id});} if(p.category && !catSet[p.category]){catSet[p.category]=1; idx.push({type:'类目', name:p.category, tab:'ai', section:'ai'});} });});
  // 中文品类词映射（蛋白/咖啡/维生素 等 → 匹配英文标题）
  var CN2EN={'蛋白':'protein','咖啡':'coffee','维生素':'vitamin','胶原':'collagen','能量':'energy','软糖':'gummies','玛卡':'maca','肌酸':'creatine','草本':'herbal','氨基酸':'amino'};
  Object.keys(CN2EN).forEach(function(cn){ idx.push({type:'关键词', name:cn+'（'+CN2EN[cn]+'）', tab:'ai', section:'ai', kw:CN2EN[cn]}); });
  inp.addEventListener('input', function(){
    var q=(inp.value||'').trim().toLowerCase();
    if(!q){ drop.style.display='none'; return; }
    var res=idx.filter(function(x){ return (x.name||'').toLowerCase().indexOf(q)>=0; }).slice(0,12);
    if(!res.length){ drop.innerHTML='<div class="sd-item muted">无匹配</div>'; drop.style.display='block'; return; }
    drop.innerHTML=res.map(function(r){
      return '<div class="sd-item" data-type="'+r.type+'" data-tab="'+r.tab+'" data-section="'+(r.section||'')+'" data-pid="'+(r.pid||'')+'" data-kw="'+(r.kw||'')+'"><span class="sd-type">'+r.type+'</span> '+esc(r.name)+'</div>';
    }).join('');
    drop.style.display='block';
  });
  drop.addEventListener('click', function(e){
    var it=e.target.closest('.sd-item'); if(!it) return;
    var tab=it.getAttribute('data-tab');
    var sec=it.getAttribute('data-section');
    var pid=it.getAttribute('data-pid');
    var kw=it.getAttribute('data-kw');
    // 切 tab
    document.querySelectorAll('#navbar .tab').forEach(function(t){ t.classList.remove('on'); });
    document.querySelector('#navbar .tab[data-tab="'+tab+'"]').classList.add('on');
    document.querySelectorAll('.tabpanel').forEach(function(p){ p.classList.remove('on'); });
    document.getElementById('panel-'+tab).classList.add('on');
    if(tab==='trend') setTimeout(drawTrendChart,50);
    drop.style.display='none'; inp.value='';
    // 板块：滚动到对应板块标题
    if(sec){
      var secName=null;
      var it2=null;
      for(var si=0; si<window._sectionsIdx && window._sectionsIdx[si]; si++){ if(window._sectionsIdx[si][1]===sec){ it2=window._sectionsIdx[si]; break; } }
      if(it2) secName=it2[0];
      if(secName){
        setTimeout(function(){
          var tts=document.querySelectorAll('#panel-'+tab+' .section-title');
          for(var i=0;i<tts.length;i++){
            var tx=tts[i].textContent||'';
            if(tx.indexOf(secName)>=0){ tts[i].scrollIntoView({behavior:'smooth', block:'start'}); break; }
          }
        }, 80);
      }
    }
    // 产品：打开评分详情
    if(pid && pid!=='') openScore(pid);
    // 关键词：设置 AI 搜索过滤
    if(kw){ var aiS=document.getElementById('aiSearch'); if(aiS){ aiS.value=kw; renderAITable(); } }
  });
  document.addEventListener('click', function(e){ if(!e.target.closest('#globalSearch') && !e.target.closest('#searchDrop')) drop.style.display='none'; });
}
document.addEventListener('DOMContentLoaded', boot);
