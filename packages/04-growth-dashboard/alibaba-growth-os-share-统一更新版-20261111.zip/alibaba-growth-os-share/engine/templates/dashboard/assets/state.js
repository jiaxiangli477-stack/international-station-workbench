/* Alibaba Growth OS — state.js：人工登记状态管理（V1.1）
 *
 * 机制（PART R/S/T）:
 *   1. 页面中的人工操作状态先保存在 browser localStorage（key: growth_os_state_v11）
 *   2. 页面加载时与 SQLite 已导入状态（dashboard_data.js 的 actions/opts）合并展示
 *   3. 【导出执行记录】生成 growth_os_action_updates.json（下载）
 *   4. 【导入执行记录】读取之前导出的 JSON 合并回 localStorage
 *   5. Skill 侧 IMPORT ACTION UPDATES 把 JSON 合并进 SQLite → 下次重建 Dashboard 保留
 */
"use strict";
var STATE_KEY = "growth_os_state_v11";

var UIState = {
  load: function () {
    try { return JSON.parse(localStorage.getItem(STATE_KEY) || "{}"); }
    catch (e) { return {}; }
  },
  save: function (s) { localStorage.setItem(STATE_KEY, JSON.stringify(s)); },
  getAction: function (kind, id) {
    var s = this.load();
    var key = kind + ":" + id;
    return s[key] || null;
  },
  setAction: function (kind, id, fields) {
    var s = this.load();
    var key = kind + ":" + id;
    s[key] = Object.assign({}, s[key] || {}, fields, { updated_at: new Date().toISOString().slice(0, 19) });
    this.save(s);
  },
  all: function () {
    var s = this.load(), out = [];
    Object.keys(s).forEach(function (k) {
      var m = k.split(":");
      out.push(Object.assign({ kind: m[0], id: m[1] }, s[k]));
    });
    return out;
  },
  /* 导出 growth_os_action_updates.json */
  exportUpdates: function (filename) {
    var rows = this.all().map(function (r) {
      return { action_id: r.id, product_id: r.product_id || "", status: r.status || "",
        owner: r.owner || "", due_date: r.due_date || "", completed_at: r.completed_at || "",
        actual_change: r.actual_change || "", notes: r.notes || "", updated_at: r.updated_at || "" };
    });
    var blob = new Blob([JSON.stringify(rows, null, 2)], { type: "application/json" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename || "growth_os_action_updates.json";
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 100);
    return rows.length;
  },
  /* 导入 JSON（文件或字符串）合并回 localStorage */
  importUpdates: function (jsonText) {
    var rows = JSON.parse(jsonText);
    var n = 0;
    rows.forEach(function (r) {
      if (!r.action_id) return;
      var kind = r.kind || "action";
      this.setAction(kind, String(r.action_id), {
        status: r.status, owner: r.owner, due_date: r.due_date,
        completed_at: r.completed_at, actual_change: r.actual_change,
        notes: r.notes, product_id: r.product_id
      });
      n++;
    }.bind(this));
    return n;
  },
  /* 合并展示: SQLite 状态优先（已导入），localStorage 增量覆盖 */
  mergedStatus: function (kind, row) {
    var local = this.getAction(kind, String(row.id || row.action_id || ""));
    if (local && local.status) return local;
    var s = row.status;
    if (kind === "opt" && !s) s = "未处理";
    return { status: s || "未处理", owner: row.owner || "", due_date: row.due_date || "",
      completed_at: row.completed_at || "", actual_change: row.actual_change || "", notes: row.notes || "" };
  }
};

function downloadText(name, text, mime) {
  var blob = new Blob([text], { type: mime || "application/json" });
  var a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 100);
}
function readFileInput(input, cb) {
  var f = input.files && input.files[0];
  if (!f) return;
  var r = new FileReader();
  r.onload = function () { try { cb(r.result); } catch (e) { alert("导入失败: " + e.message); } };
  r.readAsText(f, "utf-8");
}
