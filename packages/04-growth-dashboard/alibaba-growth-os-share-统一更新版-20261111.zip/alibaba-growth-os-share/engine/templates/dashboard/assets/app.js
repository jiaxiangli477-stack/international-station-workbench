/* Alibaba Growth OS — app.js：数据访问 / 格式化 / 导航 / 通用渲染（V1.1） */
"use strict";
var D = window.GROWTH_OS_DATA || { store: {}, weeks: [], months: [], products: [], tiers: {},
  cs: null, profiles: {}, industry: [], diagnostics: [], actions: [], opts: [],
  capabilities: {}, funnel: {}, meta: {} };

var NAV = [
  ["经营总览", "overview.html"], ["重点关注", "focus.html"], ["产品经营", "products.html"],
  ["AI产品优化", "ai_optimizer.html"], ["广告分析", "advertising.html"], ["搜索情报", "search.html"],
  ["客户接待", "customer_service.html"], ["买家质量", "buyer_quality.html"], ["趋势分析", "trends.html"],
  ["同行对标", "peer_benchmark.html"], ["竞品情报", "competitor.html"], ["行动执行台", "action_center.html"],
  ["数据健康", "data_health.html"]
];

function renderNav(active) {
  var s = '<div class="logo">Alibaba Growth OS<small>经营驾驶舱 V1.1</small></div><nav>';
  NAV.forEach(function (n) {
    s += '<a href="' + n[1] + '"' + (n[0] === active ? ' class="active"' : '') + '>' + n[0] + '</a>';
  });
  s += "</nav>";
  return s;
}

function fmt(n, d) { if (n === null || n === undefined || n === "") return "-"; var v = Number(n); if (isNaN(v)) return "-"; return v.toLocaleString("zh-CN", { maximumFractionDigits: d === undefined ? 0 : d }); }
function fmtp(p, d) { if (p === null || p === undefined || isNaN(p)) return "-"; var x = p * 100; return (x >= 0 ? "+" : "") + x.toFixed(d === undefined ? 1 : d) + "%"; }
function dcls(p) { if (p === null || p === undefined || isNaN(p)) return "flat"; return p > 0 ? "up" : (p < 0 ? "down" : "flat"); }
function deltacell(cur, prev) { var p = prev ? (cur - prev) / prev : null; return '<span class="' + dcls(p) + '">' + fmtp(p) + "</span>"; }
function tierBadge(t) {
  var m = { "爆品": "b-1", "优品": "b-2", "潜力优品": "b-3", "普通品": "b-4", "低质品": "b-5" };
  return t ? '<span class="badge ' + (m[t] || "b-na") + '">' + t + "</span>" : '<span class="badge b-na">-</span>';
}
function statusBadge(s) {
  if (!s) return '<span class="badge b-4">未处理</span>';
  var m = { "未处理": "b-4", "已确认": "b-6", "优化中": "b-3", "已完成": "b-5", "忽略": "b-na",
    "验证中": "b-3", "验证有效": "b-5", "验证无效": "b-1", "结果不明确": "b-2", "suggested": "b-6" };
  return '<span class="badge ' + (m[s] || "b-4") + '">' + s + "</span>";
}
function na() { return '<span class="na">当前数据不可用</span>'; }
function esc(s) { return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function w1() { return D.weeks.length ? D.weeks[D.weeks.length - 1] : {}; }
function w2() { return D.weeks.length > 1 ? D.weeks[D.weeks.length - 2] : {}; }
function mo7() { return D.months["2026-07"] || {}; }
function mtd() { return D.months["2026-08-mtd"] || {}; }
function productMap() { var m = {}; (D.products || []).forEach(function (p) { m[p.product_id] = p; }); return m; }
function optByProduct() { var m = {}; (D.opts || []).forEach(function (o) { m[o.product_id] = o; }); return m; }
function deepPlan(o) { try { return o && o.deep_plan_json ? JSON.parse(o.deep_plan_json) : null; } catch (e) { return null; } }
function init() {
  document.getElementById("sidebar").innerHTML = renderNav(window.PAGE_ACTIVE || "");
  var hm = document.getElementById("head-meta");
  if (hm) hm.textContent = D.store && D.store.name ? D.store.name + " · advisory " + (D.meta.advisory_date || "-") + " · 数据源: Alibaba 官方数据参谋 (T+2)" : "";
  if (document.getElementById("period-bar")) renderPeriodBar();
}

/* ===== V2.1 全局周期选择器（Period Bar）===== */
var PERIOD = { mode: "week", week_end: null, month_start: null };
(function () {
  if (D.weeks && D.weeks.length) PERIOD.week_end = D.weeks[D.weeks.length - 1].stat_week_end;
  if (D.months && D.months["2026-07"]) PERIOD.month_start = "2026-07";
})();
function curWeek() {
  var e = PERIOD.week_end;
  for (var i = 0; i < D.weeks.length; i++) if (D.weeks[i].stat_week_end === e) return D.weeks[i];
  return D.weeks.length ? D.weeks[D.weeks.length - 1] : {};
}
function prevWeekOf(w) { for (var i = 0; i < D.weeks.length; i++) if (D.weeks[i].stat_week_end === w.stat_week_end) return D.weeks[i - 1] || {}; return {}; }
function curMonth() { return (PERIOD.month_start && D.months[PERIOD.month_start]) ? D.months[PERIOD.month_start] : {}; }
function setPeriod(mode, value) {
  if (mode === "week") { PERIOD.mode = "week"; PERIOD.week_end = value; }
  else { PERIOD.mode = "month"; PERIOD.month_start = value; }
  renderPeriodBar();
  if (typeof window.PAGE_RENDER === "function") window.PAGE_RENDER();
}
function renderPeriodBar() {
  var box = document.getElementById("period-bar");
  if (!box) return;
  var wkOpts = D.weeks.map(function (w) {
    var label = "W" + (w.stat_week_end || "").slice(0, 7) === "" ? w.stat_week_end : w.stat_week_end;
    return "<option value='" + w.stat_week_end + "'" + (PERIOD.week_end === w.stat_week_end ? " selected" : "") + ">" + w.stat_week_end + "</option>";
  }).join("");
  var moOpts = Object.keys(D.months).map(function (k) {
    var lbl = k.indexOf("mtd") >= 0 ? D.months[k].month_start + "（月内累计 MTD）" : D.months[k].month_start;
    return "<option value='" + k + "'" + (PERIOD.month_start === k ? " selected" : "") + ">" + lbl + "</option>";
  }).join("");
  var w = curWeek(), mo = PERIOD.mode === "month" ? D.months[PERIOD.month_start] : null;
  var range = PERIOD.mode === "week" ? (w.stat_week_start || "?") + " ~ " + (w.stat_week_end || "?") : (mo ? mo.month_start + " ~ " + mo.month_end : "?");
  box.innerHTML = '<div class="period-bar">' +
    '<span class="pb-mode"><button class="btn' + (PERIOD.mode === "week" ? " primary" : "") + '" onclick="setPeriod(\'week\', PERIOD.week_end)">周</button>' +
    '<button class="btn' + (PERIOD.mode === "month" ? " primary" : "") + '" onclick="setPeriod(\'month\', PERIOD.month_start)">月</button></span>' +
    '<select onchange="setPeriod(PERIOD.mode, this.value)">' + (PERIOD.mode === "week" ? wkOpts : moOpts) + "</select>" +
    '<span class="pb-meta">周期 ' + range + " · Data As Of " + (D.meta.advisory_date || "-") + ' · <span class="badge b-5">完整数据 · T+2</span></span></div>';
}
/* 本页结论（≤3）+ 本周建议（≤3）—— 运营不用看完整表再总结（PART 26/27） */
function renderConcl(conclusions, actions) {
  var box = document.getElementById("concl");
  if (!box) return;
  var h = "";
  if (conclusions && conclusions.length) {
    h += '<div class="panel" style="border-left:4px solid var(--brand);background:#f7fbff"><h2>本页结论</h2><ol style="margin-left:18px;line-height:1.8">' +
      conclusions.map(function (c) { return "<li>" + c + "</li>"; }).join("") + "</ol></div>";
  }
  if (actions && actions.length) {
    h += '<div class="panel" style="border-left:4px solid var(--green);background:#fafff6"><h2>本周建议</h2><ol style="margin-left:18px;line-height:1.8">' +
      actions.map(function (a) { return "<li>" + a + "</li>"; }).join("") + "</ol></div>";
  }
  box.innerHTML = h;
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
