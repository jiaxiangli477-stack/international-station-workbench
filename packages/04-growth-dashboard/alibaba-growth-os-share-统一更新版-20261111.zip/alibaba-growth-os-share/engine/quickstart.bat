@echo off
chcp 65001 >nul
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [错误] 未找到 python。请先安装 Python 3.10+ 并勾选 "Add to PATH"。
  echo 装完再双击本文件即可。
  pause
  exit /b 1
)
echo 正在部署代码与脚本 ...
python start.py %*
echo.
echo 完成。窗口可关闭，后续在 workspace\ 目录继续操作（见《REPRODUCE_GUIDE.md》）。
pause
