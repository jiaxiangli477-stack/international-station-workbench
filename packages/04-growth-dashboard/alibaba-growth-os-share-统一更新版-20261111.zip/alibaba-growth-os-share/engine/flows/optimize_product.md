# Flow: 产品优化（OPTIMIZE PRODUCT）

> 目标：从本地历史数据中识别高潜力/问题产品，生成优化动作，并进入验证闭环。
> 约束：不写死任何 Product ID；候选由数据驱动筛选；优化建议基于店铺自身数据。
> 命令形式：
>   - `OPTIMIZE PRODUCT <Product ID>` — 指定单品深度分析
>   - `OPTIMIZE TOP PRODUCTS` — 由数据引擎筛选 Top 5-10（禁止无差别优化全部产品）

## 步骤

### 1. 候选筛选

```bash
python scripts/optimizer.py --config config.json --stage screen
```

- 从 `product_weekly_stats` / `product_daily_stats` 筛选：
  - 流量充足但转化低的潜力品（impressions ≥ `optimizer.min_impressions`）。
  - 转化不错但流量不足的潜力品（clicks ≥ `optimizer.min_clicks`）。
  - 下滑异常品（趋势 Z-score 超阈值）。
- 候选池大小 ≤ `optimizer.candidate_pool_size`。

### 2. 评分排序

```bash
python scripts/optimizer.py --config config.json --stage score
```

- 按 `optimizer.score_weights` 计算综合分（转化潜力 / 流量潜力 / 盈利性），全部来自店铺自身数据。
- 输出 Top-N 候选及每项的评分构成与优化方向建议。

### 3. 生成优化动作

- 动作类型（模板驱动，参数占位）：
  - `title_rewrite`：标题优化建议（基于关键词数据）。
  - `price_adjust`：价格调整区间建议（基于转化/询盘弹性，标注置信度）。
  - `keyword_add`：可补充关键词（来自店铺自身关键词表现）。
  - `bid_change`：广告出价调整建议（基于 ROI 与花费效率）。
  - `image/description`：素材与详情优化提示。
- 每条动作写入 `actions` 表（subject_type=product，status=planned），并注明预期影响与验证指标。

### 4. 与用户确认

- 向用户展示候选与动作清单（影响 × 置信度排序），确认执行范围。
- 用户确认后标记执行状态（executed）。

### 5. 进入验证

- 执行后按 `flows/validation.md` 设置验证窗口（≥ `guardrails.min_validation_days` 天）。

## 输出

- 优化候选清单（含评分与证据）。
- 已登记的行动记录。
- 验证计划。
