# Flow: 月度复盘（SYNC MONTHLY）

> 目标：对最近一个已完成且满足 T+2 的自然月进行经营复盘，评估趋势与动作效果，更新学习沉淀。
> 约束：月窗口由 `scripts/window.py` 计算；同比基线为店铺自身历史（若不足一年，则用环比+趋势基线）。
> 定位：**Weekly = Action，Monthly = Strategy**。

## 月同步规则（硬性）

- 只同步**已完成且满足 T+2 的自然月**（如 8 月数据需 9 月初且当月最后一天数据 T+2 就绪才允许作为完整月入库）。
- **当前月只能作为 MTD**（月度趋势展示），不得作为完整月。
- 月度复盘重点：GMV / Orders / Buyer / Product Portfolio / Advertising / Search / Peer Benchmark / Market / Customer Service / Root Cause / Strategy。

## 步骤

### 1. 确定月窗口

- `scripts/window.py --config config.json --monthly` 获取最近完整月与对比期（上一月，若历史足够则上年同月）。

### 2. 同步与聚合

```bash
python scripts/sync.py --config config.json --sync
python scripts/db.py --config config.json --aggregate monthly
```

- 校验数据完整性：当月每日数据齐全，缺日须标注。

### 3. 运行月度诊断

```bash
python scripts/diagnose.py --config config.json --scope monthly --period <month_start> <month_end>
```

- 月度维度：
  1. 店铺整体月度表现与趋势（连续 N 月方向）。
  2. 产品组合结构：集中度、明星/问题产品迁移。
  3. 广告效率与花费结构变化。
  4. 上周期行动的验证结果汇总（从 `validations` 表读取）。
- findings 写入 `diagnostics` 表（scope=monthly）。

### 4. 学习沉淀

- 将本月已验证的行动结论写入 `learnings`（category 分类，含 confidence 与 evidence_ref）。
- 更新诊断规则的可复用经验（`docs/DIAGNOSIS_RULES.md` 允许在用户确认后补充规则）。

### 5. 生成月度 Dashboard

```bash
python scripts/dashboard_build.py --config config.json --scope monthly
```

### 6. 输出月报

**状态**: 本月表现（On track / At risk / Ahead of plan，相对店铺自身目标，目标由用户提供）
**当前**: 核心指标值 vs 目标值（差异%）
**驱动**: 主要驱动因素（已验证/很可能）
**行动回顾**: 上月动作验证结果（positive/neutral/negative + 数量）
**学习沉淀**: 本月可复用结论
**下月建议**: 行动优先级（影响×置信度排序）
**置信度**: 整体置信度与主要不确定来源

## 输出

- 中文月报文本 + 重新生成的 HTML Dashboard 文件路径。
