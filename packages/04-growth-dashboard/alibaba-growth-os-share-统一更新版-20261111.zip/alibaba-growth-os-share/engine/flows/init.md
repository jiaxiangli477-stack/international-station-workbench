# Flow: 初始化（init）

> 目标：将当前 Workspace 初始化为一个 Alibaba 店铺的 Growth OS 实例。
> 约束：一个 Workspace = 一个店铺；禁止写死店铺名/Product ID/Campaign ID/日期/行业/同行数值。

## 前置条件

- 已确认当前 Workspace 对应的 Alibaba 店铺（店铺身份来自用户提供，写入 config.json，不写进代码）。
- 官方数据接入可用（凭据由用户在外部安全存放，仅以引用形式写入配置）。

## 步骤

### 1. 生成配置

1. 复制 `config.example.json` 为 `config.json`（如不存在）。
2. **向用户确认店铺身份（硬门槛，未确认不得建库/拉数）**：把要绑定的店铺的「店铺名 + store_id + 主类目」明确列出，让用户确认无误后再填写：
   - `store.name` / `store.store_id` / `store.currency` / `store.timezone`
   - `data_source` 接入方式与凭据引用
   - 诊断阈值与优化参数（可用默认值）
   - ⚠️ 同一家公司可能有多个店铺，禁止凭公司名或产品名猜测店铺；以 `store_id + 主类目` 为准，并让用户逐项确认。
3. 校验：所有 `<...>` 占位符必须被替换；`db`、`dashboard_output`、`log` 路径可写。

### 2. 建库

```bash
python scripts/db.py --config config.json --init
```

- 按 `schema.sql` 创建全部表与索引。
- `store` 表写入一行运行时配置快照。
- 成功后写入同步日志（status=failed 时停止并报告错误）。

### 3. 首次同步

```bash
python scripts/sync.py --config config.json --init-sync
```

- 按 `data_source.history_months` 拉取官方历史数据（店铺概览、产品、关键词、广告活动）。
- 原始指标按天落 `*_daily_stats` 表，周/月聚合由同步层生成。
- 同步必须全量对账：记录数、时间范围与官方口径一致，否则标记数据缺口。

### 4. 基线建立

- 用首个完整窗口（`diagnosis.trend_baseline_days` 天）建立基线分布（均值/标准差），存入诊断依赖表（当前为聚合表派生）。
- 基线仅来自本店官方数据，不引入任何外部行业/同行数值。

### 5. 验证初始化

1. `sync_log` 最新一条状态为 success。
2. 产品日度表存在且时间范围与官方一致。
3. 生成首份 Dashboard（`flows/dashboard.md`）。
4. 输出初始化摘要：店铺（配置值）、数据覆盖范围、表行数、下一步建议。

## 输出

- 初始化摘要（中文，含数据覆盖时间范围与记录数）。
- 提示用户可开始周度/月度诊断。
