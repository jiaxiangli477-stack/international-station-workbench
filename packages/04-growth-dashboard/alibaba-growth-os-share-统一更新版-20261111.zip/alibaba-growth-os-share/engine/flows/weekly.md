# Flow: 周度经营诊断（weekly）

> 目标：对最近一个完整自然周进行经营复盘，定位驱动因素，输出可执行建议。
> 约束：周窗口由 `scripts/window.py` 计算（不写死日期）；完整周判定必须基于 **Alibaba data_advisory_date**（禁止用电脑当前日期判断）；对比基线为店铺自身历史。

## Advisory Date Gate（硬性规则）

```
Natural Week = Monday → Sunday
仅当 week_end <= data_advisory_date 时该自然周 is_complete = true，才允许正式同步。
data_advisory_date 来源: config.json 的 data_source.advisory_date（或 --advisory-date 显式传入）。
```

- 例 (EXAMPLE ONLY): `data_advisory_date=2026-08-22`（周六）→ W34(8/17~8/23) 的 week_end=8/23 > 8/22 → **NOT_READY**，不得写入 W34 完整周。
- 仅当 `data_advisory_date >= 2026-08-23` 才允许同步 W34（EXAMPLE ONLY）。

## 步骤

### 0. 导入人工登记（V1.1）

- 若 Workspace 中存在 `growth_os_action_updates.json`（驾驶舱【导出执行记录】产物）：
  `python scripts/import_action_updates.py --config config.json`
  合并人工状态（status/owner/截止/实际修改/备注）进入 SQLite，确保 Dashboard 重建不丢操作历史。

### 1. 确定周窗口（Advisory Date Gate）

- 调用 `scripts/window.py --config config.json --weekly`（内部按 config 的 advisory_date 计算最新完整周）。
- 输出含 `is_complete`；为 false 时输出"数据未就绪（T+2）"并停止，不执行同步。
- 若数据不足一个完整周，按 `diagnosis.min_sample_days` 判断是否可诊断；不足则输出"数据不足"并停止。

### 2. 增量决策

- 调用 `scripts/window.py --config config.json --decision --db-latest-week <数据库最新周结束日>`：
  - `SKIP`：数据库最新周 >= 最新完整周 → 无新周可同步，直接进入诊断与看板更新。
  - `FETCH`：存在新完整周 → 仅抓取该周（绝不多抓、不回溯）。

### 3. 同步本周数据

```bash
python scripts/sync.py --config config.json --sync
```

- 同步后校验新鲜度：最新数据日期 ≥ 本周最后一天，否则标记缺口。

### 4. 运行诊断引擎

```bash
python scripts/diagnose.py --config config.json --scope weekly --period <week_start> <week_end>
```

- 诊断维度（规则见 `docs/DIAGNOSIS_RULES.md`）：
  1. 店铺整体：曝光/点击/CTR/询盘/订单/GMV 周环比（对比上一周）与趋势（对比 `trend_baseline_days` 基线）。
  2. 产品层：Top 贡献产品与跌幅/涨幅异常产品（Z-score 超阈值）。
  3. 广告层：花费、ROI、异常活动。
  4. 关键词层：词级波动与预算效率。
- 输出结构化 findings，写入 `diagnostics` 表（scope=weekly），每个 finding 标注置信度。

### 5. 生成周报 Dashboard

```bash
python scripts/dashboard_build.py --config config.json --scope weekly
```

- 每次全量重新生成中文 HTML（见 `flows/dashboard.md`）。

### 6. 输出周报

按模板：

**核心洞察**: 本周最重要的变化 + 量化影响
**关键证据**: 2-3 个支撑数据点（带环比/占比较）
**驱动因素**: 已验证 / 很可能 的驱动
**置信度**: High/Medium/Low + 理由
**推荐行动**: 最多 `guardrails.max_actions_per_cycle` 条，每条含：做什么、预期影响、验证窗口
**开放问题**: 什么数据能提高置信度

- 所有结论必须来自诊断结果，不凭空推断。
- 行动项写入 `actions` 表（status=planned），进入 Validation 闭环（`flows/validation.md`）。

## 输出

- 中文周报文本 + 重新生成的 HTML Dashboard 文件路径。
