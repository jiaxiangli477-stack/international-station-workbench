# Flow: Dashboard 生成（REBUILD DASHBOARD）

> 目标：基于本地库最新数据，全量重新生成中文 HTML Dashboard。
> 原则：Dashboard 是一次性生成物，禁止手工编辑；每次运行都重建。
> **历史源声明（硬性）**：`dashboard.html` 可以随时覆盖重建；**SQLite 不允许因为 Dashboard 重建而被修改业务历史；Raw Snapshots 不允许被 Dashboard Build 修改**。SQLite 是唯一历史事实源。

## 步骤

### 1. 确认数据就绪

- 检查本地库存在且最近同步成功（`sync_log` 最新状态）。
- 无数据时明确提示"请先执行同步"，不生成空壳页面。

### 2. 生成

```bash
python scripts/dashboard_build.py --config config.json [--scope weekly|monthly|store]
```

- 读取本地库聚合数据，渲染 `templates/dashboard.html.j2`。
- 输出到 `config.paths.dashboard_output`。
- 页面语言为中文（`dashboard.language`），品牌色来自配置。

### 3. 内容结构（模板内置）

- 概览区：核心指标卡片（当前值 + 环比 + 方向）。
- 趋势区：关键指标时间序列。
- 产品区：Top 产品排行与异常产品列表。
- 广告区：活动效率与花费。
- 诊断区：最新 findings（含置信度标签）。
- 行动区：进行中的行动与验证状态。

### 4. 自检

- 页面可独立打开（无外部 CDN 依赖或已内联资源）。
- 数值与本地库对账（抽查 2-3 个指标）。
- 无占位符残留（如 `<店铺名>` 未替换，则报配置错误）。

### 5. 交付

- 输出 Dashboard 文件路径，供用户浏览器打开。

## 输出

- 中文 HTML Dashboard 文件（每次全量重建）。
