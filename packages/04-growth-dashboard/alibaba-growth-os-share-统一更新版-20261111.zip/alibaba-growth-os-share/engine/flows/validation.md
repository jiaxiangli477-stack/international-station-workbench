# Flow: Action → Validation → Learning（validation）

> 目标：让每个经营动作有验证、有结论、可复用。这是 Growth OS 的闭环环节。

## 闭环模型

```
Diagnosis ──> Action（登记） ──> Execution（执行） ──> Validation（验证）
                                                            │
                                                            ▼
Learning（沉淀结论） <── 可复用规则 ── Reuse（下次诊断引用）
```

## 步骤

### 1. 登记 Action（诊断阶段完成）

- 每条行动写入 `actions`：subject_type/subject_id、action_type、description、expected_impact、status=planned。

### 2. 执行（用户/运营执行）

- 用户确认执行后，更新 `actions.status=executed`，记录执行时间。

### 3. 设置验证（Validation）

```bash
python scripts/diagnose.py --config config.json --scope validate --action-id <id>
```

- 验证窗口：`guardrails.min_validation_days` 天起，至达到统计所需天数（数据不足则判 inconclusive）。
- 验证设计：同一指标，基线期（动作前，取 `trend_baseline_days` 天均值）vs 验证期均值；计算 delta 与 delta_pct。
- 排除混淆因素：期间若发生其他重大动作/活动，标注并存证，不强行归因。

### 4. 判定（Verdict）

| 判定 | 条件（默认，可配置） |
|------|---------------------|
| positive | 指标显著改善（delta_pct ≥ 正向阈值，且置信度达标） |
| neutral | 无显著变化 |
| negative | 指标显著恶化 |
| inconclusive | 数据不足 / 混淆因素未排除 |

- 结果写入 `validations` 表，更新 `actions.status=validated|reverted`。

### 5. 沉淀 Learning

- 将结论写入 `learnings`：category、conclusion、evidence_ref（关联 validation id）、confidence、reusable。
- 高置信度、可复用的结论在后续诊断中作为"已知模式"引用（docs/DIAGNOSIS_RULES.md 维护规则库）。

### 6. 复盘反馈

- 月度复盘时汇总验证结果分布，评估动作质量与规则有效性。
- 若某类动作系统性无效，调整规则或停止该动作类型。

## 输出

- 验证报告（指标、基线 vs 验证期、判定、置信度）。
- 更新后的行动状态。
- 沉淀的学习条目。
