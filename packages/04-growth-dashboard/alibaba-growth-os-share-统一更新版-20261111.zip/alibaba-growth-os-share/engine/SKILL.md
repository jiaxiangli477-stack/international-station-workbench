---
name: alibaba-growth-os
description: 可复用 Alibaba 国际站经营增长操作系统（V6）。8 页经营驾驶舱（周期看板/重点关注/AI搜索/趋势对比/改造执行台/竞品对比/同行标杆/管理），含 AI 五维产品评分（市场趋势/AI识别/B2B转化/合规）、主图视觉诊断（视觉模型识别）、88 个真实竞品对标、广告计划层、星等级、子账号客服、国家地区分析、市场机会推荐、0效果产品。一键周更 + 每周二 T+2 自动化。 适用于国际站店铺的经营分析、周/月复盘、产品优化与决策支持，可换店铺复用。V7 新增：动态时间窗口（gos_window，T+2/自然周自动算周/月）+ 通用建库（init_store，读 stores.json 零写死店铺身份）+ 同事可从空白店铺在自身账号一键复现全量看板（见《REPRODUCE_GUIDE.md》）。V7.1 新增：老板看板（📊运营/👔老板可切换视角；店铺漏斗+承接效率每项含同行优秀/平均+较比上周；爆品/新品带产品图片；花费·优质客户·获客成本·样品单·其他花费支持运营录入）。V7.2 老板看板体验：爆品表可折叠（默认收起、展开看链接）；新品改为**浏览带图产品池、点击即选中**（无需输 ID）；新增**获客数量**、**新品数量**两个运营自填项。V7.3：新品产品池也**可折叠（默认收起）**；**获客数量** 与 **优质获客数量** 分列（获客成本=店铺总花费÷获客数量）；品牌花费拆成 **年费/问鼎/顶展/品牌广告** 四项分填；录入区改双列网格。V7.4：老板看板**置前且为默认视图**；首栏加 **优爆品数量/新品数量** 卡（点新品卡跳转新品区）；新品勾选显示 **产品ID**；**订单/样品单** 可手填具体产品名；产品池扩为**全店所有产品**（无差别勾选）；新增 **导出CSV**（老板/运营自选、当前周期）。V7.5：爆品/优品/潜力优品 拆成**三个各自可折叠的产品区**（`productLevelSection`，点首栏对应数量卡平滑跳转）；**订单/样品单**手填的产品名做成**可展开**（`.boss-exp` 切换详情）；数据层 `boss` 增 `premium_products`/`potential_products`（各平台分级**全量**，`boss_hot` 亦改为爆品全量）。V7.6：导出升级为**美观 HTML 报告**（自包含、KPI卡+着色表格+产品表、可打印存PDF），导出控件可选 HTML报告/CSV。V7.7：导出收敛为**数据留存**扁平单表（板块/指标/本期值/较比上周/同行优秀/同行平均/备注，行序固定、值为原始数字，便于每周复制对比+AI 分析；含 店铺/周期/区间/导出时间 meta + 订单/样品单产品 显式行），支持 **Excel格式化表格(xlsx，默认)/CSV/HTML**，并修复导出环比 ×100 bug。
version: 7.0.0
---

# Alibaba Growth OS V7

可复用 Skill：Alibaba 官方数据 → 本地 SQLite → 判定引擎 + AI 五维评分 + 主图视觉识别 → 8 页中文 HTML 驾驶舱 → 一键周更。

## V6 一键周更（核心命令）

```bash
# 拉图 → 竞品 → 评分 → 板块 → 合并 → 建看板（全流程）
python weekly_update.py

# 跳过图片拉取（图片已缓存时，更快）
python weekly_update.py --skip-images
```

数据管线（按顺序）：
1. `v6_fetch_monthly.py` — 拉取全量月度数据（data_advisor 30d，含全量同行对标 + 环比）
2. `v6_fetch_imgs.py` — 拉取产品主图真实 URL（data_advisor_shop_product，分页全量）
3. `v4_competitors.py` — 提取多家供应商 Top20 竞品（过滤擦边+带图+点评）
4. `v4_prep_sections.py` — 数据预处理（国家行业+渠道+买家L1++关键词+热销品过滤）
5. `v6_market_evidence.py` — 生成多源市场趋势证据（全球市场报告 + 社媒热度 + 亚马逊信号 → raw/market_evidence.json）
6. `v4_score.py` — AI 五维产品评分（市场趋势[含多源证据]/AI识别匹配/Listing/B2B转化/合规，每品带 market_evidence 块）
7. `v4_judge.py` — 判定引擎 + 合并所有数据 → v4_data.json（含 21 个板块备注整体建议）
8. `v4_build.py` — 重建 dashboard/

视觉识别（一次性/新增品时）：`v6_export_split.py` 导出图片清单 → 派 4 个 general 子代理读图 → `v6_merge_vision.py` 合并 + B2B/AI适配分析。

## 实战初始化清单（真实脚本，非 scripts/ 抽象层）

> 本 Skill 的 `scripts/` 目录是早期抽象设计（已废弃），**实际能跑的是 `pipeline/` 目录这些脚本**。换店铺/新建看板按下面顺序执行（脚本已随包打包在 `pipeline/`，拷贝到 Workspace 根目录后直接运行）：

**A. 拉数据（数据参谋 MCP，经 accio-mcp-cli 或 workctl）：**
1. `python fetch_new_store.py` — 动态窗口（`gos_window` 自动算最近 4 完整周 7d + 基础月 + MTD 30d，写 `raw/_window.json`）+ 产品全量分页 → `raw/shop_summary_*.json`、`raw/shop_product_w1_p*.json`
2. `python fetch_prep.py` — 国家榜/流量渠道/关键词洞察/类目热品榜 → `raw/industry_country_rank.json`、`raw/shop_flow_channel.json`、`raw/industry_keyword.json`、`raw/industry_cate_rank_*.json`
3. `python fetch_peers.py` — 同行标杆（**用父类目「保健食品」cateId，非店铺子类目**，30d GMV 降序）→ `raw/peer_benchmark_*.json`
4. `python fetch_competitors.py` — 竞店 Top20 产品（month 口径按起草订单降序）→ `competitor_data/shop-product-*.json`
5. `python fetch_staff.py` — 4 周子账号经营效果 → `raw/cs_w1..w4.json`
6. 星等级：`workctl icbu other icbu-starrating-cgs-pc-page-data-open --yes --format json --statDate <advisory> --terminal chrome -o raw/star_rating_<date>.json`

**B. 建库（SQLite，绝不复制旧店 database/）：**
7. `python init_store.py` — 通用建库（读 `stores.json` 店铺身份 + `raw/_window.json` 窗口，执行 schema + 扩展 DDL + 回填 store/meta/周/月/产品，占位符按参数量自动生成）。`stage_b_load.py` 为历史一次性脚本，**新店请用 `init_store.py`**
8. `python create_missing_tables.py` — 补 competitor_stores/operator_decisions/cs_staff_weekly 等 5 张缺表
9. `python fix_columns.py` — 补 diagnosis_actions/product_optimizations 的 owner/due_date/deep_plan_json 等缺列

**C. 补充数据域：**
10. `python v4_fetch_region.py` — 国家地区 → `raw/country_region.json`
11. `python v2_competitors.py` — 类目热品榜 → market_products 表
12. `python v4_ingest_peer.py` — 同行标杆入库解析
13. `python v4_ingest_star.py` — 星等级入库 + `raw/star_rating_parsed.json`
14. `python v4_ingest_staff.py` — 子账号入库（需先 `raw/chat_quality_check.json`，可为空数组）

**D. 改造方案（Top20 深度方案，17 项结构）：**
15. `python stage_f_product360.py` — 生成 top20_candidates + product_360_profile
16. `python stage_f_plans20.py` — 生成 Top20 的 17 项深度方案 → product_optimizations 表

**E. 建看板（V6 管线，见上「一键周更」）：**
17. `python weekly_update.py --skip-images`（主图已回填时）或 `python weekly_update.py`

## 数据源与已知限制

- **星等级**：`workctl icbu other icbu-starrating-cgs-pc-page-data-open`（需 `--yes` 确认 + `--statDate`），返回 finalStar（展示星/页面星/直通星）+ 赛道 trackList + 降星预警。
- **同行标杆**：`data_advisor_supplier_selection`，**cateId 用父类目「保健食品」（如 202029701）**，不是店铺自身子类目；orderBy=rec_ord_amt(GMV) 降序。
- **竞品**：`data_advisor_shop_product` 传竞店 domain，orderBy=crtOrd 降序。⚠️ 竞店月订单 Top 产品会随时间变化，可能从成品变成原料，需配合品类白名单 + 原料黑名单过滤；必要时复用上一期已过滤的 `competitor_full.json`。
- **广告 ROI（花费/投产比）**：⚠️ 当前数据源**拿不到花费字段**——数据参谋只有曝光/点击/询盘，无 spend；workctl ads 当前仅品牌广告（问鼎/顶展）实体，无直通车/全站推 campaign/report。缺花费则无法算真实 ROI，只能给曝光/点击/询盘。
- **产品级询盘归因**：shop_product 周口径 `sumProdFbNum`（询盘）可能为 0 而店铺大盘 fbCnt>0（TM 接待为主店型，询盘走 TM 而非表单），商机榜需用 `atmFbUv`（TM 咨询）兜底。

## 产品分类体系（24 赛道）

`v4_score.py` 的 `classify_cat` 按「合规优先 → 独立剂型 → 功能赛道 → 剂型 → 功能」顺序匹配：maca(壮阳)/detox(减肥) 合规优先；spray/pouch/strip 独立剂型；sleep/mushroom/fertility/keto/electrolyte/nootropic 功能赛道；tablet/liquid/tea/coffee 剂型；pro/beauty/energy/gummies/vitamin/superfood/longevity/men 功能；兜底 generic。每个赛道在 `CAT_PLAYBOOK` 有定位 + 3 条打法 + 对标。

## 换店铺复用

> ⚠️ **同一家公司多店铺切换（如 莱华仕·运动营养 vs YH·草本补充剂）必须先走「核心原则 #9」**：备份当前店铺数据 → 与用户确认目标店铺身份（店铺名 + store_id + 主类目）→ 确认后才覆盖。未确认前禁止用另一家店的数据覆盖当前店。

### A. 同一 Workspace 加店（多店隔离，推荐）

数据按店铺物理隔离在 `stores/<key>/`，绝不互相覆盖：

- **店铺注册表** `stores.json`：记录每个店的 key / name / store_id / 主类目 / cate_id / db / raw 路径，以及 `active` 指针。
- **切换店铺**：`python switch_store.py <key>`（先备份当前店 → 恢复目标店 → 同步 `load_new_store.py` 的店铺常量 → 重建）。
- **构建多店看板**：`python build_all.py`（优先复用 `stores/<key>/v4_data.json`，缺才重建；打包成 `dashboard_data.js` 的 `window.V4_STORES`，index.html 顶部下拉切换）。

**加第三个店铺的标准流程**：
1. `stores.json` 里新增该店条目（key/name/store_id/类目/cate_id/db/raw），`active` 指向新店。
2. 建 `stores/<key>/` 目录。
3. `python switch_store.py <key>` 切到新店。
4. 跑拉数管线：`fetch_new_store.py` → `init_store.py` → `fetch_staff.py` → `v4_ingest_staff.py` → workctl 星等级（**用 `--output` 不用 `-o`**）→ `v6_fetch_monthly.py` → `v6_fetch_imgs.py`。
5. 跑 AI 评分：`v4_score.py`。
6. `v4_judge.py` 生成 v4_data.json，落到 `stores/<key>/v4_data.json`。
7. `build_all.py` 打包多店看板并部署。
8. 全程不动 `stores/lifeworth/`、`stores/yh/`，覆盖前备份、覆盖前与用户确认店铺身份。

### B. 新 Workspace（给同事/换电脑）

1. 新 Workspace 复制本 Skill + 所有 v4_*.py / v6_*.py / weekly_update.py / templates/v4/。
2. 重新登录 Alibaba（授权数据参谋 + 星等级 + 广告接口）。
3. `INITIALIZE STORE` 建新库（不复制旧店 SQLite）。
4. `python weekly_update.py` 一键重建新店驾驶舱。

## 🚀 懒人模式：一句话复现（Agent 执行协议）

> **同事对 Agent 说**：「复现/搭一个和老板一样的国际站看板，**同步 8 周数据**」或「…从 7月1日 到现在」
> → Agent 按下述 5 步执行，全程无需同事手动敲命令。产出与莱华仕/YH **完全同构**的 8 页驾驶舱 + 老板看板/运营看板 + 数据留存导出，数据 100% 来自**他自己登录账号**的实时接口。

**Agent 执行步骤**（在解压后的包目录跑；**第 0 步：先完整读包根目录《AI_INSTRUCTIONS.md》——它是硬约束执行契约：三条铁律（禁改前端/禁编造数据/失败即停）+ 产出定义 + 时间段换算 + 失败对照表 + 8 项验收清单，全部通过才允许说"完成"**）：
0. **读契约**：`AI_INSTRUCTIONS.md`（+ 人类视角《REPRODUCE_GUIDE.md》）。
1. **部署+自检**：`python start.py`（或双击 `quickstart.bat` / `./start.sh`）→ 自动铺脚本+模板到 `workspace/`、生成 `stores.json` 模板、检查 Python/pycryptodome/accio-mcp-cli。
2. **确认授权**：确认用户已在 Accio 登录**自己的** Alibaba 账号并授权 数据参谋/星等级/广告（缺哪个，对应页签就是空的，先引导授权再继续）。
3. **填 stores.json**：Agent 代填 `workspace/stores.json`——店铺名/公司全称/`store_id`（用户后台可查，或问用户）/主类目/父类目 `cate_id`（同行标杆用父类目，如保健食品）。
4. **一键全量（核心命令）**：
   ```bash
   python start.py --run --full --weeks N              # "同步 N 周"
   python start.py --run --full --weeks N --as-of YYYY-MM-DD   # "某时间段"：截至 as_of 往前 N 个完整自然周
   ```
   失败即停、可重复跑（幂等）；周数变多补历史周时 A2 会自动回填。
5. **交付**：完成后自动打开 `dashboard/index.html`（口令默认 `Lifeworth123456`，建议自设 `GOS_DASHBOARD_PASSWORD`）；要公网则 `python deploy.py`（用户自己的 GitHub/Vercel）；要每周一键更新则配定时任务跑 `python weekly_update.py --skip-images`。

**"时间段"换算规则**（告诉 Agent 自然语言即可）：「最近8周」→`--weeks 8`；「7/1 到现在」→ 算出完整自然周数 N（T+2，周一~周日为一周）+ `--as-of` 今天或数据可用日；「某月」→ 周粒度覆盖该月即可（月度数据自动含 基础月+MTD）。

## 从空白店铺复现（给同事的完整步骤）

> **V7 起，同事从零复现以《REPRODUCE_GUIDE.md》为唯一权威操作手册**（含每步验证点、常见坑、多店、安全）。
> 这里只给骨架。核心变化：**时间窗口动态计算（`gos_window.py`）+ 建库通用化（`init_store.py` 读 `stores.json`）**，
> 不再写死店铺身份与日期——换人换店换日期都能自动适配。

同事拿到的是一个**数据空白**的全新 Workspace（只有代码，没有你的店铺数据）。在她自己登录的店铺上复现：

1. **部署代码**：把 `pipeline/*.py` + `schema.sql` 拷到 Workspace 根目录，`templates/v4/` 拷到根 `templates/v4/`；`pip install -r requirements.txt`。
2. **登录自己的 Alibaba 账号**：授权数据参谋（data_advisor）、星等级（icbu-starrating）、广告（icbu ads）接口。
3. **登记店铺**：建 `stores.json`（active 指向她的店，填 name/store_id/主类目/cate_id）。
4. **首次全量拉数（动态窗口）**：`python fetch_new_store.py --weeks N`（默认 as_of=今天，自动算最近 N 完整周 + 基础月 + MTD，写 `raw/_window.json`；**懒人模式直接用 `start.py --run --full --weeks N` 代替 Step1/4~8**）。
5. **建空白库**：`python init_store.py`（按 schema.sql 建库 + 回填，读 stores.json 身份 + `_window.json` 窗口；**绝不复制旧店 database/**）。
6. **补数据域 + 评分 + 建看板**：`fetch_prep/fetch_peers/fetch_competitors/fetch_staff` + 星等级 → 各 `v4_ingest_*` → `v4_competitors` → `v4_prep_sections` → `v6_market_evidence` → `v4_score` → `v4_judge` → `v4_build`（多店用 `build_all`）。
7. **视觉识别（可选，一次性）**：`v6_export_split.py` → 派 general 子代理读图 → `v6_merge_vision.py`。
8. **打开看板**：双击 `dashboard/index.html`；配每周二 T+2 跑 `python weekly_update.py --skip-images`。

注意事项：
- 所有店铺名/ID/数值都来自她登录账号的实时接口，代码里**零硬编码**，换人就自动换成她的数据。
- 每周二 T+2 自动化：在她自己的环境里配置 cron（或 ACCIO WORK 定时任务）跑 `python weekly_update.py --skip-images` 即可。
- 市场趋势证据（`v6_market_evidence.py` 的 EVIDENCE 字典）是**通用品类知识**（蛋白/胶原/能量/玛卡/减肥/软糖/维生素/口溶膜/通用），与具体店铺无关，换店铺无需改动；只有行业询盘同比来自她的数据参谋接口。

## 每周自动化（T+2）

- 每周二（自然周完整 + T+2）运行一次 `python weekly_update.py --skip-images`，自动更新最新自然周到看板。
- 云服务器部署：把整个 workspace 目录 + Python 环境 + accio-mcp-cli 部署上去，用 cron 每周二定时跑。

## 老板看板（可切换视角 · V7.1）

顶部导航下方有「📊 运营看板 ↔ 👔 老板看板」视角切换条（`index.html` 的 `.viewswitch`；选中记 `localStorage.gos_view`；`body.view-boss` 时隐藏运营导航/面板、只留 `#panel-boss`）。老板看板面向老板，混合「自动取数 + 运营手动录入」。

- **数据层** `pipeline/v4_judge.py` 的 `boss` 板块（`data["boss"]`），随 `v4_judge` 自动产出，无需额外步骤：
  - `kpi`（曝光/点击/访客/询盘/TM/订单/GMV/回复三项，自动）
  - `spend`（**广告花费=全站推真实值** `ad_plans.account.spend` + CPC/CPL/点击/曝光，自动；无投放则 0 → 前端标「手动」）
  - `manual`（优质客户/获客成本/样品单/其他花费/广告花费覆盖，前端 localStorage 覆盖默认值）
  - `hot_products`(Top12，含 `detail_url` **真实产品链接** + `main_image`) + `hot_count/premium_count/potential_count`（爆品/优品/潜力优品 平台分级）
  - `product_pool`(**全店所有产品** 供新品无差别勾选，含 `main_image`，按总点击降序) + `new_products`(自动 first_seen 近4周)
- **前端** `templates/v4/app.js`：`renderBoss/initBossView/setView/initBossInteractions`（`boot()` 末尾调 `initBossView`）。
  - **店铺漏斗 + 承接效率**直接复用运营看板的 `getFunnel()/getBearing()`（`funnelCardsHtml()/bearingCardsHtml()`）——每项含 **同行优秀/同行平均 + 较比上周**，卡片格式与运营周期看板一致；周/月/周选择器切换时 `renderBossIfActive()` 同步刷新老板面板。
  - 爆品表 / 新品显示产品缩略图（`main_image`，`.prod-thumb/.np-thumb`）；**V7.2/7.3**：爆品表可折叠（`#bossHotToggle` 默认收起、展开看链接）；新品为**浏览带图产品池、点击即选中**（`renderPick`，无需输 ID；点选局部刷新不整页重渲染），**产品池也可折叠**（`#bossNewPoolToggle` 默认收起，展开才显示长列表）。
  - **V7.4**：老板看板**置前且为默认视图**（`initBossView` 默认 `boss`）；首栏「花费与获客」加 **优爆品数量** + **新品数量**（`[data-jump]` 点击平滑滚动到 `#bossNewSec`/`#bossHotSec`）；新品勾选列表/已选表显示 **产品ID**（`.np-id`）；**订单/样品单** 可手填具体产品名（`order_products/sample_products`，多行 `.bm-textarea`，显示在对应 KPI 卡 sub）；**导出CSV**（`exportView`，viewswitch 栏 `#bossExportView` 选 老板/运营 + `#bossExportBtn`，当前周期，UTF-8-BOM 下载）。
- **V7.5**：首栏「花费与获客」的 **优爆品数量** 拆成 **爆品数量 / 优品数量 / 潜力优品数量** 三张卡（`[data-jump]` 平滑滚动到对应区）；下方用 `productLevelSection()` 渲染**三个各自可折叠产品区** `#bossSec_hot / #bossSec_premium / #bossSec_potential`（`#bossLvlToggle_<key>` 展开/收起，`#bossLvlBody_<key>`）；数据层 `boss` 新增 `premium_products`/`potential_products`（各平台分级**全量**，列表长度=对应数量卡），`boss_hot` 改为爆品全量（按 GMV+商机+订单+点击 综合降序）。**订单/样品单**卡的产品名（`order_products/sample_products`）做成**可展开**：卡片 sub 显示 `.boss-exp` 链接（带预览），点击切换 `#bossExp_order`/`#bossExp_sample` 详情条。`exportView` 同步导出 优品/潜力优品 段。
  - **V7.6**：导出重做为**美观 HTML 报告**（`buildReportHTML`，自包含）：navy 头部（店铺/周期/导出时间/绿黄蓝图例）+ 花费与获客 KPI 卡（自动绿/手动黄/推算蓝边）+ 店铺漏斗·承接效率着色表（↑绿/↓红、达标点）+ 爆品/优品/潜力优品/已选新品 产品表（缩略图+分级徽标+真实链接）+ 客服子账号表（运营视图），顶部「🖨 打印 / 存为PDF」按钮 + `@media print`。导出控件 `#bossExportFmt` 可选 **HTML报告（默认）/ CSV**（CSV 走 `exportCSV`，UTF-8-BOM）。
  - **V7.7**：导出收敛为**数据留存**（用户要求只留「花费与获客 + 店铺漏斗」用于跨周期对比 + 每周复制进对比表喂 AI）：顶部 navy 标题条 + meta 行 **店铺ID/周期(周·月)/区间/导出时间**，**XLSX=两个板块分工作表**（与用户主对比表同构，每周把对应列复制进主表新列）：表1「花费与获客」`指标|本期值` 15 行（13 KPI + **订单产品/样品单产品** 显式两行）、表2「店铺漏斗」`指标|本期值|同行优秀|同行平均` 16 行；**每表顶部** navy 标题条（店名·板块·数据留存·🕒导出时间）+ 分区色块 🏪店铺金底 / 📅周期（**含 第N自然周·W##，`_periodWeekTag` ISO 算法**）+📆区间 navy 底白字（`_xlsSheetHead`）——哪个店哪一周一目了然；无板块列（表名即板块）、用户明确**不要较比上周**列（宽表对比里相邻周相减即是环比）；**行顺序每周固定、本期值存原始数字**（XLSX 用 numFmt 显示 ¥/$/%，复制出来是裸数字）→ 直接整列粘进对比表/喂 AI。ExcelJS（CDN `exceljs@4.4.0`，`exportXLSX`+`_xcell/_xlsHeadRow`：冻结前3行、autoFilter、边框斑马纹）；CSV 单文件 2 块（带板块列，UTF-8-BOM，裸数字）/ HTML报告（KPI卡+banner+漏斗表，供打印PDF）。文件名 `<店铺>_<老板|运营看板>_数据留存_<周期>.<ext>`。**修复**：导出环比原先误 ×100（`v4_judge.wow` 本身即百分比），CSV/HTML/XLSX 三处已修正与看板一致。
  - KPI 卡带「自动(绿)/手动(黄)/推算(蓝)」角标；派生 **店铺总花费=广告+（年费+问鼎+顶展+品牌广告）**、**获客成本=手填优先否则 总花费÷获客数量** 实时算。
  - 运营录入区（双列网格）：**获客数量 / 优质获客数量 / 获客成本 / 新品数量 / 样品单 / 年费 / 问鼎 / 顶展 / 品牌广告 / 广告花费覆盖**，存 `localStorage.gos_boss_manual_<store>`（仅本浏览器；跨设备需把值提交→写进数据→重跑部署）。
- **多店**：每店各自 `v4_judge` 出各自 boss，`build_all.py` 打包；缺 boss 的店在老板视角显示占位提示。
- **改 boss 数据层后**须对该店重跑 `v4_judge` 再 `build_all`（build_all 复用已存在 `v4_data.json`，强制重建前先移走该店文件并备份）。

## 核心原则（不可违反）

1. **不写死业务数据**：本 Skill 内禁止写死店铺名、Product ID、Campaign ID、具体日期、行业数值、同行/竞对数值。所有此类信息必须来自 `config`（店铺配置）与同步后的本地数据库（历史数据）。
2. **一个 Workspace 对应一个 Alibaba 店铺**：本 Skill 只服务当前 Workspace 绑定的单一店铺。店铺身份通过 `config/store` 注入，不在代码与文档中硬编码。
3. **数据来自 Alibaba 官方接口**：所有经营数据通过官方数据同步层获取（见 `flows/init.md` 与 `scripts/sync.py` 的数据源契约），不手工录入、不写死样例。
4. **每次重新生成 Dashboard**：Dashboard 为一次性生成物，每次运行 `dashboard_build.py` 都会基于最新数据库全量重建，禁止手工维护 HTML。
5. **闭环**：任何经营动作必须走 Action → Validation → Learning 流程，结论沉淀到本地库，供后续诊断复用。
6. **SQLite 是唯一历史事实源**：`dashboard.html` 可以随时覆盖重建；SQLite 不允许因 Dashboard 重建而被修改；Raw Snapshots 不允许被 Dashboard Build 修改（见 `flows/dashboard.md`）。
7. **默认 READ ONLY**：Skill V1.0 不自动修改 Listing / 价格 / MOQ / 广告 / Bid / Campaign / 发布产品。所有 Alibaba 写操作必须由用户未来明确授权。
8. **Advisory Date Gate**：完整自然周（Monday→Sunday）仅当 `week_end <= data_advisory_date` 才算完成并可同步；禁止用电脑当前日期判断完整周。
9. **改店铺数据前必须「备份 + 与用户确认店铺身份」**（本次 YH↔莱华仕 混店事故的教训，最高优先级）：
   - 任何会覆盖或切换店铺数据的操作（换店、恢复备份、加载新店数据、改 `store`/`meta` 表、覆盖 `database/`、重建看板数据源），执行前**必须**：
     ① 先把当前数据完整备份到带「店铺名 + 日期时间戳」的独立目录（如 `_backup_<店铺>_<YYYYMMDD>/`）；备份成功才继续，备份失败立即停止并告知用户，绝不覆盖。
     ② 覆盖前，把**目标店铺的「店铺名 + store_id + 主类目」明确列给用户**，让用户确认「这是哪个店铺、数据对不对」；只有用户确认后才执行覆盖。
   - 禁止凭记忆、凭旧会话或凭猜测判定店铺身份。同一家公司可能有多个店铺（如 莱华仕·运动营养 vs YH·草本补充剂），店铺身份以「store_id + 主类目」为准，不以公司名或产品名猜测。
   - **换店/恢复数据时 `database/` 与 `raw/` 必须成对备份、成对恢复**：`v4_judge.py` 有 12 处直接读 `raw/`（star_rating_parsed / peer_benchmark_parsed / competitor_full / competitor_detail / country_region / v4_sections / v4_scores / vision_full / ads_report_* / ads_kw_* / monthly_full / company_capabilities）。只恢复 DB、不恢复 raw/ 会产出「A 店 DB + B 店 raw」的混合看板（星等级错、AI 评分对不上显示「—」、广告/竞品/同行全错）。

## V7 复现核心文件（实际运行，优先于 scripts/）

```
alibaba-growth-os/
├── REPRODUCE_GUIDE.md     # ★ 同事从零复现的权威操作手册
├── requirements.txt        # pip 依赖（pycryptodome）
├── pipeline/               # ★ 实际能跑的全部脚本
│   ├── gos_window.py       # 时间窗口助手（T+2/自然周，动态算 4 周 + 基础月 + MTD，可本地自测）
│   ├── fetch_new_store.py  # 拉全量（动态窗口，写 raw/_window.json）
│   ├── init_store.py       # 通用建库（读 stores.json 身份 + _window.json 窗口，零写死）
│   ├── build_all.py        # 多店打包 → dashboard_data.js (V4_STORES)
│   ├── switch_store.py     # 换 active 店（先备份 + 确认店铺身份）
│   ├── weekly_update.py    # 一键周更（最新完整周 + 重建）
│   └── v4_*/v6_*/v7_*/stage_*   # 各数据域 fetch / ingest / score / judge / build
├── templates/v4/           # ★ 8 页驾驶舱前端模板（index.html/app.js/styles.css/chart.umd.min.js）
└── schema.sql / config.example.json
```

> `scripts/`（window/db/sync/diagnose/…）与 `templates/dashboard/`（15 页多页面版）是早期抽象设计，**已废弃**；
> 复现与日常更新一律用 `pipeline/` + `templates/v4/`。

## 目录结构

```
alibaba-growth-os/
├── SKILL.md                  # 本文件：技能入口与规范
├── README.md                 # 面向普通使用者的快速开始
├── config.example.json       # 配置模板（复制为 config.json 后填写）
├── schema.sql                # SQLite 本地库 schema
├── flows/                    # 标准工作流（Markdown 流程指令）
│   ├── init.md               # 初始化
│   ├── weekly.md             # 周度经营诊断（SYNC WEEKLY）
│   ├── monthly.md            # 月度复盘（SYNC MONTHLY）
│   ├── dashboard.md          # Dashboard 生成（REBUILD DASHBOARD）
│   ├── optimize_product.md   # 产品优化（OPTIMIZE PRODUCT）
│   └── validation.md         # Action→Validation→Learning
├── scripts/                  # 可复用实现
│   ├── window.py             # 时间窗口工具 + Advisory Date Gate + 增量决策
│   ├── db.py                 # 本地持久化层
│   ├── sync.py               # 官方数据同步入口
│   ├── diagnose.py           # 诊断引擎
│   ├── optimizer.py          # AI Product Optimizer
│   └── dashboard_build.py    # 中文 HTML Dashboard 生成
├── templates/
│   ├── dashboard.html.j2     # Dashboard 单页模板（V1.0 兼容）
│   └── dashboard/            # 多页面驾驶舱模板（V1.1）: 15 个业务页面 + assets/
│       ├── index.html        # 首页（核心健康）
│       ├── overview.html     # 经营总览
│       ├── focus.html        # 重点关注（运营榜单）
│       ├── products.html     # 产品经营
│       ├── product_detail.html  # 产品详情（?id=）
│       ├── ai_optimizer.html # AI 产品优化工作台（深度方案 + 人工登记）
│       ├── advertising.html  # 广告分析
│       ├── search.html       # 搜索情报
│       ├── customer_service.html  # 客户接待
│       ├── buyer_quality.html     # 买家质量
│       ├── trends.html       # 趋势分析
│       ├── peer_benchmark.html   # 同行对标
│       ├── competitor.html   # 竞品情报
│       ├── action_center.html    # 行动执行台（人工登记 + 导出/导入）
│       ├── data_health.html  # 数据健康
│       └── assets/           # styles.css / app.js / state.js（数据由生成器写入 dashboard_data.js）
└── docs/
    ├── ARCHITECTURE.md       # 架构说明
    ├── DATA_MODEL.md         # 数据模型
    ├── DIAGNOSIS_RULES.md    # 诊断规则体系
    └── AI_PRODUCT_OPTIMIZER.md # 产品优化方法论
```

## 快速开始

1. 复制 `config.example.json` 为 `config.json`，填写当前店铺配置（店铺身份、同步参数、诊断阈值、`data_source.advisory_date`）。
2. 按 `flows/init.md` 初始化：建库 → 校验配置 → 首次同步。
3. 按需执行 `flows/weekly.md` / `flows/monthly.md` 经营诊断。
4. 每次诊断后运行 `flows/dashboard.md` 重新生成中文 HTML Dashboard。
5. 对产品优化需求执行 `flows/optimize_product.md`；对已执行动作执行 `flows/validation.md` 沉淀学习。

## 命令规范（正式命令）

### `SYNC WEEKLY` — 周度同步（执行顺序锁定）

1. 读取 config
2. 检查 Alibaba `data_advisory_date`
3. 计算 latest complete natural week（`week_end <= advisory_date`）
4. 检查 SQLite latest stored week
5. 若无新完整周 → **SKIP**（不重复写入）
6. 有新周 → 仅抓取该周（绝不多抓、不回溯）
7. 保存 Raw Snapshot（版本化：历史修正生成 v2/v3…，不产生重复普通记录）
8. Validate（数据完整性与口径对账）
9. Upsert SQLite（主键覆盖 = historical revision）
10. Peer Benchmark（同行平均/优秀）
11. Run Diagnosis
12. Select AI Product Optimizer Candidates（Top 5-10，禁止全量 680）
13. Run Optimizer
14. Create Actions
15. Validate previous actions
16. Write Learnings
17. Generate Weekly Report
18. Rebuild Dashboard
19. Commit sync_log

### `SYNC MONTHLY` — 月度同步

- 只同步**已完成且满足 T+2** 的自然月；当前月只能作为 **MTD**。
- 月度复盘重点：GMV / Orders / Buyer / Product Portfolio / Advertising / Search / Peer Benchmark / Market / Customer Service / Root Cause / Strategy。
- 定位：**Weekly = Action，Monthly = Strategy**。

### `OPTIMIZE PRODUCT <Product ID>` / `OPTIMIZE TOP PRODUCTS`

- `OPTIMIZE TOP PRODUCTS` 必须先由数据引擎筛选（P1/P2、OPTIMIZE_CTR、OPTIMIZE_CONVERSION、TRAFFIC_LIMITED、DECLINING_RISK、Buyer Intent Gap），默认 Top 5-10；禁止无差别优化全部产品。
- Optimizer 必须实际读取 Listing + 数据 + 自身历史 + Peer Avg + Peer Excellent + Buyer/Search + 广告 + 市场/竞品（可用时），禁止"Status → 固定话术"。
- 输出规范见 `docs/AI_PRODUCT_OPTIMIZER.md` 与 `flows/optimize_product.md`。

### `REBUILD DASHBOARD`

- 仅读取本地 SQLite，不调用 Alibaba、不重新抓取数据；每次全量重建 HTML（见 `flows/dashboard.md`）。

### `VALIDATE GROWTH OS`

- 检查：Config / DB Integrity / Latest Week / Advisory Date / Raw Snapshot / Capability / Peer Data / Action Tables / Dashboard Build；输出 PASS / WARNING / FAILED（见 `flows/validation.md` 补充说明与脚本实现）。

### `RETRY PERIOD <period>`

- 仅补上次失败的 `failed_domain` 数据域；不得重复破坏已成功的数据（见「恢复与部分成功」）。

### `EXPORT STORE PACKAGE` / `IMPORT STORE PACKAGE`

- 迁移同一家店到另一台电脑：导出 config + database + raw + reports + dashboard + actions（不含 Cookie / Password / Session / Alibaba 登录凭证）；导入后重新登录 Alibaba 即可继续 SYNC WEEKLY，历史不丢。
- 新店初始化：**不复制旧店数据库**，只复制本 Skill Release，在新 Workspace 重新授权后执行 `INITIALIZE STORE`（自动新建 config/database/raw/reports/dashboard）。

### `IMPORT ACTION UPDATES`（V1.1 人工登记持久化）

- 读取 Workspace 中 `growth_os_action_updates.json`（驾驶舱【导出执行记录】产物），合并人工登记（状态/负责人/截止/实际修改/备注）进入 SQLite 的 diagnosis_actions / product_optimizations。
- 在每次 SYNC WEEKLY / REBUILD DASHBOARD 前执行，确保人工状态不因重建丢失（见 `flows/weekly.md` 步骤 0）。

## 多页面驾驶舱与人工登记（V1.1）

- 驾驶舱由 `scripts/dashboard_build.py`（V1.1 多页面版，或运行时 `stage_d_build.py` 等价物）从 SQLite 生成 `dashboard/assets/dashboard_data.js`，并将 `templates/dashboard/` 静态页面复制到 `dashboard/`。
- 全部页面使用**相对路径**，无 localhost / 远程 API 依赖；整个 `dashboard/` 文件夹复制到另一台电脑后双击 `index.html` 即可使用。
- 页面中的人工登记状态（未处理/已确认/优化中/已完成/忽略/验证中/验证有效/验证无效/结果不明确 + 负责人/计划完成/实际完成/实际修改/备注）先保存在浏览器 localStorage，通过【导出执行记录】生成 JSON，再经 `IMPORT ACTION UPDATES` 合并进 SQLite。
- 每次 Dashboard 重建 = SQLite action state + 最新 engine state 合并生成 HTML；不允许把"已完成"重新变成"未处理"。

## Advisory Date Gate

```
Natural Week = Monday → Sunday
仅当 week_end <= data_advisory_date 时该自然周 is_complete = true，才允许正式同步。
data_advisory_date 来源: config.json 的 data_source.advisory_date（或 --advisory-date 显式传入）。
禁止用电脑当前日期判断完整周。
```

- 例 (EXAMPLE ONLY): `data_advisory_date=2026-08-22`（周六）→ W34(8/17~8/23) 的 week_end=8/23 > 8/22 → **NOT_READY**，不得写入 W34 完整周；仅当 `data_advisory_date >= 2026-08-23` 才允许同步 W34。
- 实现: `scripts/window.py`（`latest_complete_week` / `sync_decision` / `--decision --db-latest-week`）。

## 恢复与部分成功（Recovery）

- 若某周 Alibaba 某模块取数失败：**不破坏已有数据库**；本次 sync 记为 `PARTIAL`，在 `sync_log.message` 记录 `failed_domain`；其它成功模块继续保存。
- 后续可用 `RETRY PERIOD <period>` 只补失败数据域，不重写已成功数据。

## 触发方式

- 用户要求"初始化 Alibaba Growth OS" → 执行 `flows/init.md`
- 用户要求"周报 / 本周诊断 / 周度经营分析 / SYNC WEEKLY" → 执行 `flows/weekly.md`
- 用户要求"月报 / 月度复盘 / SYNC MONTHLY" → 执行 `flows/monthly.md`
- 用户要求"生成 / 刷新 Dashboard / REBUILD DASHBOARD" → 执行 `flows/dashboard.md`
- 用户要求"优化产品 / 产品诊断 / OPTIMIZE PRODUCT" → 执行 `flows/optimize_product.md`
- 用户要求"验证动作效果 / 沉淀学习 / VALIDATE GROWTH OS" → 执行 `flows/validation.md`
- 用户要求"迁移店铺 / 换电脑 / EXPORT|IMPORT STORE PACKAGE" → 见 README「迁移」
- 用户/同事要求"复现看板 / 搭一个一样的面板 / 接入我自己的店铺 / 同步 N 周数据 / 某时间段的数据" → **🚀 懒人模式**（`start.py --run --full --weeks N [--as-of …]`，见上节协议）

## 配置契约

所有可变参数必须通过 `config.json` 注入，本 Skill 代码与文档一律使用占位符。配置字段以 `config.example.json` 为权威定义，运行时由 `scripts/db.py` 加载并校验。店铺相关值（店铺名/ID/产品/Campaign/日期/Peer 数值）只允许来自 `config.json` 或运行时 Alibaba Discovery，不得来自 SKILL.md / Python 常量 / HTML 模板 / SQL 默认值。

## 数据源契约

- 数据仅来自 Alibaba 官方数据接口（经 `scripts/sync.py` 适配），包括但不限于：店铺概览、产品表现、关键词表现、广告活动表现。
- 同步任务将原始数据写入本地 SQLite（`schema.sql` 定义），历史由此累积。
- 禁止手工导入外部整理表替代官方数据；如数据源不可用，诊断必须显式标注数据缺口，不得虚构。

## 输出规范

- 所有面向用户的诊断输出使用中文。
- 数字给出上下文：对比基线（周环比/月环比/同比）、占总数百分比、历史区间。
- 每个结论标注置信度：已验证 / 很可能 / 假设。
- 每次交付以推荐行动结尾（做什么、预期影响、剩余不确定性）。
