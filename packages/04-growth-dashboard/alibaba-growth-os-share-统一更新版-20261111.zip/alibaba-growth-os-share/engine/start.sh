#!/usr/bin/env bash
# 国际站数据面板 · 一键部署与引导（Mac / Linux 双击或运行）
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then PY=python3
elif command -v python >/dev/null 2>&1; then PY=python
else echo "[错误] 未找到 Python，请先安装 Python 3.10+"; exit 1; fi
echo "正在部署代码与脚本 ..."
"$PY" start.py "$@"
echo
echo "完成。后续在 workspace/ 目录继续操作（见《REPRODUCE_GUIDE.md》）。"
