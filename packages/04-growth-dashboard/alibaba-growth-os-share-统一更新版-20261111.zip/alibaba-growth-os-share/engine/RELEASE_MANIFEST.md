# Alibaba Growth OS — Release Manifest

- **版本**: 7.0.0 (shareable)
- **打包日期**: 2026-09-08
- **定位**: 可分享给同事、在各自 Alibaba 店铺上从零复现全量 8 页经营驾驶舱的代码包。**不含任何店铺私有数据**（无 database/、raw/、v4_data.json）。

## 快速开始
打开 **《REPRODUCE_GUIDE.md》**（从这开始），按 Step0~Step10 走即可。

## V7 相比 V6 的改动
1. **时间窗口动态化**：新增 `pipeline/gos_window.py`，按 T+2/自然周(Mon-Sun)从 as_of 自动算最近 4 完整周 + 基础月 + MTD；`fetch_new_store.py` 不再写死日期（写 `raw/_window.json`）。
2. **建库通用化**：新增 `pipeline/init_store.py`（取代一次性硬编码的 `load_new_store.py`），读 `stores.json` 店铺身份 + 动态窗口，零写死店铺/日期；占位符按参数量自动生成，杜绝「N values for M columns」。
3. **补全管线脚本**：`pipeline/` 补齐 `build_all.py`（多店打包）、`switch_store.py`（换店）、`v7_fetch_buyer.py`（买家画像）、`v2_competitors.py`（类目热品）。
4. **看板口令可配置**：`build_all.py / v4_build.py / weekly_full.py / build_dual_data.py` 改读环境变量 `GOS_DASHBOARD_PASSWORD`（未设用默认值向后兼容），消除硬编码口令。
5. **同步最新逻辑**：`v4_judge.py`（高效低耗榜 = 广告商机转化，非 0 花费）、`templates/v4/`（index.html/app.js）更新到最新。
6. **修复**：`v4_build_competitor_detail.py` 一处历史缩进语法错误。
7. **一键启动器（打开即装）**：新增 `start.py` + `quickstart.bat`(Windows 双击) + `start.sh`(Mac/Linux)。
   解压后双击/运行即自动在 `workspace/` 铺好全部脚本+schema+模板、生成 `stores.json` 模板、自检环境；
   `python start.py --run` 可一键拉数→建库→评分→建看板→自动打开（失败即停、幂等）。**无需手动复制任何文件。**

## 内容清单
```
SKILL.md / README.md / REPRODUCE_GUIDE.md / RELEASE_MANIFEST.md
config.example.json / schema.sql / requirements.txt
pipeline/     实际能跑的 68 个脚本（gos_window / init_store / fetch_*/v4_*/v6_*/v7_*/stage_*/build_all/switch_store/weekly_update）
templates/v4/ 8 页驾驶舱前端（index.html / app.js / styles.css / chart.umd.min.js）
flows/        标准工作流文档
docs/         架构 / 数据模型 / 诊断规则 / 产品优化方法论
scripts/ + templates/dashboard/   早期多页面版（已废弃，保留备查）
```

## 打包前校验（2026-09-08）
- [x] 80 个 .py 全部通过内存 `compile()`（语法 0 错误）
- [x] `weekly_update.py` + `SKILL.md` 引用的 30 个脚本全部存在（缺失 0）
- [x] 私有数据泄漏检查：包内无 database / raw 数据 / v4_data.json / img_map.json（0）
- [x] 敏感串检查：无 GitHub token、无裸硬编码口令（仅存于 env 兜底）
- [x] `gos_window.py` 日期数学本地验证：as_of=2026-08-23 精确复现 lifeworth 初始化窗口；as_of=2026-09-09 → W36
- [x] `init_store.py` 隔离环境实测：用 lifeworth 真实 raw 建库 → store_weekly=4 / store_monthly=2 / products=693，integrity=ok，foreign_key_check=PASS

## 运行期需验证（同事侧，本环境无法代跑）
- 数据参谋 / 星等级 / 广告接口授权是否生效（fetch 各步打印 `ok=True`）
- 各店 `products` 行数 = 该店有效产品数
- 8 页签切换、数据非全空

## 安全须知
1. 对外分享前请**改看板口令**：`$env:GOS_DASHBOARD_PASSWORD='<强密码>'` 后重建。
2. `deploy.py` 的 GitHub remote **不要内嵌 token**（用 SSH key / 凭据管理器 / 临时注入）。
3. 换店/覆盖前**先备份 + 确认店铺身份**（store_id + 主类目），见 SKILL.md 核心原则 #9。
