"""stage_e_learning_demo.py — PART 19 Result Learning 预演（Test Fixture，不污染生产数据）。

验证: 主图 A/B 测试后 CTR 上升，不能简单判定"主图有效"。
必须对照环境变化（Store CTR Change / Peer CTR Change / Traffic Change）。

场景 A: 产品 CTR 大涨且环境平稳 → positive（主图有效）
场景 B: 产品 CTR 大涨但环境同步大涨（流量结构变化）→ neutral（不能归因主图）
场景 C: 产品 CTR 微升但环境小涨 → neutral
"""
from __future__ import annotations

import json


def judge(product_ctr_before, product_ctr_after, store_ctr_before, store_ctr_after,
          peer_ctr_before, peer_ctr_after, traffic_change_pct):
    """基于相对环境的增量判定（Test Fixture 演示逻辑）。"""
    p_delta = (product_ctr_after - product_ctr_before) / product_ctr_before if product_ctr_before else None
    s_delta = (store_ctr_after - store_ctr_before) / store_ctr_before if store_ctr_before else None
    e_delta = (peer_ctr_after - peer_ctr_before) / peer_ctr_before if peer_ctr_before else None
    # 环境基准 = Store 与 Peer 的相对变化的保守平均（取较差者 = 环境改善幅度更大者）
    env = max([x for x in (s_delta, e_delta) if x is not None] or [0.0])
    excess = (p_delta or 0) - env  # 产品超额表现
    # Traffic 变化修正: 流量结构变化大时降低置信
    if abs(traffic_change_pct) > 0.25:
        excess *= 0.6  # 流量大幅变化时，超额表现置信折减
    if p_delta is None:
        return "inconclusive", "无基线 CTR，无法判定"
    if excess > 0.10:
        verdict = "positive"
        reason = f"产品 CTR {p_delta*100:+.1f}% 远超环境基准 {env*100:+.1f}%（超额 {excess*100:+.1f}%）"
    elif excess < -0.10:
        verdict = "negative"
        reason = f"产品 CTR 落后环境基准 {excess*100:+.1f}%，主图可能造成反效果"
    else:
        verdict = "neutral"
        reason = f"产品变化（{p_delta*100:+.1f}%）未显著超过环境（{env*100:+.1f}%），不能归因主图"
    return verdict, reason


def main() -> int:
    fixtures = [
        {"name": "场景A: 主图有效（环境平稳）", "args": (0.012, 0.018, 0.017, 0.018, 0.018, 0.018, 0.05)},
        {"name": "场景B: 环境同步大涨（不能归因）", "args": (0.012, 0.018, 0.017, 0.019, 0.018, 0.020, 0.40)},
        {"name": "场景C: 微升且环境小涨（中性）", "args": (0.012, 0.013, 0.017, 0.0175, 0.018, 0.0182, 0.08)},
        {"name": "场景D: 上升但流量结构剧变（置信折减）", "args": (0.012, 0.016, 0.017, 0.017, 0.018, 0.018, 0.80)},
    ]
    out = []
    for f in fixtures:
        v, reason = judge(*f["args"])
        out.append({"fixture": f["name"], "verdict": v, "reason": reason,
                    "data": {"product_ctr": f"{f['args'][0]}→{f['args'][1]}",
                             "store_ctr": f"{f['args'][2]}→{f['args'][3]}",
                             "peer_ctr": f"{f['args'][4]}→{f['args'][5]}",
                             "traffic_change": f"{f['args'][6]*100:+.0f}%"}})
    print(json.dumps(out, ensure_ascii=False, indent=1))
    print("LEARNING_LOGIC: 仅当产品 CTR 超额变化显著超过环境基准时才判定 positive（防止把环境红利误判为主图效果）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
