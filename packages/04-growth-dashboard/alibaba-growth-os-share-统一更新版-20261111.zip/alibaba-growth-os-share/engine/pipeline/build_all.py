# -*- coding: utf-8 -*-
"""
多店看板构建：为 stores.json 里每个店铺生成 v4_data.json，打包成 dashboard_data.js（含多店数据）
用法: python build_all.py
"""
import json, os, shutil, subprocess, sys, io, hashlib, base64
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
from Crypto.Cipher import AES

ROOT = os.path.dirname(os.path.abspath(__file__))
CONF = os.path.join(ROOT, 'stores.json')
DST = os.path.join(ROOT, 'dashboard')
# 看板访问口令：优先取环境变量 GOS_DASHBOARD_PASSWORD，未设置用默认值（向后兼容）
PASSWORD = os.environ.get('GOS_DASHBOARD_PASSWORD', 'Lifeworth123456')

def encrypt_str(data):
    raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    key = hashlib.sha256(PASSWORD.encode('utf-8')).digest()
    nonce = os.urandom(12)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ct, tag = cipher.encrypt_and_digest(raw)
    return base64.b64encode(nonce + ct + tag).decode('ascii')

def main():
    conf = json.load(open(CONF, encoding='utf-8'))
    active = conf.get('active')
    stores = conf['stores']
    os.makedirs(DST, exist_ok=True)

    encrypted = {}

    for key, st in stores.items():
        print(f'=== 构建 {key} ({st["name"]}) ===')
        v4_saved = os.path.join(ROOT, 'stores', key, 'v4_data.json')
        # 优先用已有的 v4_data.json（避免用旧快照重建导致数据丢失）
        if os.path.exists(v4_saved) and os.path.getsize(v4_saved) > 1000:
            data = json.load(open(v4_saved, encoding='utf-8'))
            encrypted[key] = encrypt_str(data)
            print(f'  复用已有 v4_data.json ({os.path.getsize(v4_saved)} bytes)')
            continue
        # 否则从 DB + raw 重建
        for name in ['database', 'raw']:
            s = os.path.join(ROOT, 'stores', key, name)
            d = os.path.join(ROOT, name)
            if os.path.isdir(d):
                shutil.rmtree(d)
            shutil.copytree(s, d)
        print(f'  运行 v4_judge.py ...')
        subprocess.run([sys.executable, 'v4_judge.py'], cwd=ROOT, capture_output=True, text=True, encoding='utf-8')
        v4 = os.path.join(ROOT, 'v4_data.json')
        if not os.path.exists(v4):
            print(f'  ⚠ {key} 构建失败，跳过（v4_data.json 未生成）')
            continue
        shutil.copy2(v4, v4_saved)
        data = json.load(open(v4, encoding='utf-8'))
        encrypted[key] = encrypt_str(data)
        print(f'  完成 {key}，v4_data.json 大小 {os.path.getsize(v4)}')

    # 4) 恢复 active 店铺到工作区
    if active and active in stores:
        print(f'=== 恢复 active 店铺 {active} 到工作区 ===')
        for name in ['database', 'raw']:
            s = os.path.join(ROOT, 'stores', active, name)
            d = os.path.join(ROOT, name)
            if os.path.isdir(d):
                shutil.rmtree(d)
            shutil.copytree(s, d)
        # 恢复 v4_data.json
        v4a = os.path.join(ROOT, 'stores', active, 'v4_data.json')
        if os.path.exists(v4a):
            shutil.copy2(v4a, os.path.join(ROOT, 'v4_data.json'))

    # 5) 生成 dashboard_data.js（多店）
    js = 'window.V4_STORES = ' + json.dumps(encrypted, ensure_ascii=False) + ';\n'
    out = os.path.join(DST, 'dashboard_data.js')
    with open(out, 'w', encoding='utf-8') as f:
        f.write(js)
    print(f'\n生成 {out} ({len(js.encode("utf-8"))} bytes)，包含店铺: {list(encrypted.keys())}')

    # 6) 复制模板到 dashboard/
    tpl = os.path.join(ROOT, 'templates', 'v4')
    for f in ['index.html', 'app.js', 'styles.css', 'chart.umd.min.js']:
        s = os.path.join(tpl, f)
        if os.path.exists(s):
            shutil.copy2(s, os.path.join(DST, f))
    print('模板已复制到 dashboard/')

if __name__ == '__main__':
    main()
