# -*- coding: utf-8 -*-
"""扩展 YH 成品竞品：5 家供应商多页多排序拉取 + 原料过滤"""
import subprocess, json, io, sys, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

ROOT = os.path.dirname(os.path.abspath(__file__))
SUPPLIERS = ["ecobiotech", "globalnutrition", "heinersupplement", "inter-health", "interlhealthcare"]

def is_raw(title):
    t = (title or "").lower()
    if re.search(r"\b\d{2,4}-\d{1,2}-\d{1,2}\b", t):
        return True
    for s in ["raw material","food additive","cosmetic grade","food grade","bulk "," hcl",
              "stearic acid","glucoside","ambroxane","tocopherol","stearate",
              "extract 5%","extract 10%","extract 20%","extract 25%","extract 30%",
              "extract 40%","extract 50%","extract 98%","extract 99%","500g","1000g"]:
        if s in t:
            return True
    if re.search(r"\b(9[5-9]|100)%\b", t):
        return True
    return False

def fetch(domain, page, order_by):
    p = {"shopProductQueryParam": {"domain": domain, "statisticsType": "month",
         "statDate": "2026-08-01", "orderBy": order_by, "order": "desc",
         "pageNo": page, "pageSize": 20}}
    pf = os.path.join(ROOT, "_tmp_comp.json")
    json.dump(p, open(pf, "w", encoding="utf-8"))
    r = subprocess.run(["accio-mcp-cli", "call", "data_advisor_shop_product",
                        "--json-file", pf], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=120, shell=True)
    try:
        d = json.loads(r.stdout)
    except Exception as e:
        print("parse err:", r.stdout[:100])
        return []
    return (d.get("data") or {}).get("data") or []

seen = {}
for dom in SUPPLIERS:
    for ob in ["crtOrd", "inquiries", "views"]:
        for pg in [1, 2, 3]:
            rows = fetch(dom, pg, ob)
            for it in rows:
                pid = str(it.get("id"))
                if pid in seen:
                    continue
                seen[pid] = it
    print(f"{dom}: 去重 {len([v for v in seen.values() if v.get('subject','').find(dom)>=0 or True])}", end=" ")

# 去重统计
all_items = list(seen.values())
fin = [it for it in all_items if not is_raw(it.get("subject") or "")]
print(f"\n5 家供应商共去重 {len(all_items)} 个, 成品 {len(fin)} 个")
print("成品竞品清单:")
for it in fin:
    print("  -", (it.get("subject") or "")[:60], "|", it.get("cateName"))

# 保存成品竞品原始数据
json.dump(fin, open(os.path.join(ROOT, "_backup_yh_store_20260825", "competitors_finished_raw.json"), "w", encoding="utf-8"), ensure_ascii=False)
print("已保存成品竞品原始数据")
