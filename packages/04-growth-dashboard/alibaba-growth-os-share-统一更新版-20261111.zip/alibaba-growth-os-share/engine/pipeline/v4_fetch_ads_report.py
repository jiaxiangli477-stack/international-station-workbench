# -*- coding: utf-8 -*-
"""V4: 拉取广告效果报告（全站推 + 直通车）→ raw/ads_report_<tag>.json

修复要点：原包 v4_fetch_ads.py / v4_fetch_ads_sql.py 用
    env.get('result', {}).get('structuredContent')
解析 workctl 输出，但 workctl icbu ads list 返回的是**扁平结构**
    {"data":[...], "links":[...], "meta":{...}, "success":true}
没有 result/structuredContent 包装，所以永远解析出空 → 花费取不到。
本脚本按真实结构解析。

链路（HATEOAS）：
    1) entityType=report  datasource=campaign_whole_site|campaign_search
       + beginDateTime/endDateTime  → 建报告表，返回 tableName + sessionId
    2) entityType=report_sql  sessionId + tableName + sql1..sql5 → 返回 tsvData

输出结构对齐 v4_judge.py 的读取契约：
    {"account": {"company_whole_site":[{...}], "company_search":[{...}]},   ← 最新完整周 W1
     "campaigns": [{"campaign_id","name","line","budget","product_count","onlineStatus","report_data":[{...}]}],
     "finance": {...},
     "month": {"begin","end","account",{...}} }                             ← 最新完整自然月（切「月」时用）
"""
import subprocess, json, io, sys, os
from datetime import date, timedelta
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import _gos_ctx

RAW = _gos_ctx.RAW
os.makedirs(RAW, exist_ok=True)
PARAMS = os.path.join(os.getcwd(), '_ads_tmp_params.json')

# ── 时间窗口 ─────────────────────────────────────────────────────────
try:
    W = _gos_ctx.window()
except (KeyError, FileNotFoundError):
    raise ValueError('缺少已确认自然周/月窗口，停止广告采集')
latest_week=max(W['weeks'],key=lambda w:w['week_end'])
latest_month=max(W['months'],key=lambda m:m['month_end'])
WB, WE = latest_week['week_start'],latest_week['week_end']
MB, ME = latest_month['month_start'],latest_month['month_end']
TAG = WB.replace('-', '')
print("广告报告窗口：周 %s ~ %s ｜ 月 %s ~ %s" % (WB, WE, MB, ME))


def wc(params_obj):
    """调 workctl icbu ads list，返回扁平 JSON（不做 envelope 猜测）"""
    with open(PARAMS, 'w', encoding='utf-8') as f:
        json.dump(params_obj, f, ensure_ascii=False)
    r = subprocess.run(['workctl', 'icbu', 'ads', 'list', '--params-file', PARAMS, '--format', 'json'],
                       capture_output=True, text=True, encoding='utf-8', errors='replace',
                       timeout=180, shell=True)
    try:
        return json.loads(r.stdout or '{}')
    except Exception as e:
        print("  [解析失败] %s | 原始输出前 200 字: %s" % (e, (r.stdout or '')[:200]))
        return {}


def parse_tsv(tsv):
    lines = [l for l in (tsv or '').strip('\n').split('\n') if l.strip() != '']
    if not lines:
        return []
    header = [h.strip() for h in lines[0].split('\t')]
    out = []
    for ln in lines[1:]:
        vals = ln.split('\t')
        out.append({header[i]: (vals[i] if i < len(vals) else '') for i in range(len(header))})
    return out


def build_table(datasource, begin, end):
    env = wc({"entityType": "report",
              "filters": {"datasource": datasource, "beginDateTime": begin, "endDateTime": end},
              "include": "data"})
    for it in (env.get('data') or []):
        if it.get('tableName'):
            tm = it.get('tableMeta') or {}
            return it['tableName'], it.get('sessionId'), tm.get('total_rows')
    return None, None, 0


def sql_rows(tname, sid, *sqls):
    flt = {"sessionId": sid, "tableName": tname}
    for i, s in enumerate(sqls):
        flt["sql%d" % (i + 1)] = s
    env = wc({"entityType": "report_sql", "filters": flt, "include": "data"})
    res = []
    for it in (env.get('data') or []):
        res.append(parse_tsv(it.get('tsvData') or ''))
    while len(res) < len(sqls):
        res.append([])
    return res


def fnum(d, k, dft=0.0):
    try:
        v = d.get(k)
        if v in (None, ''):
            return dft
        return float(v)
    except Exception:
        return dft


def shape_row(r):
    imp = fnum(r, '曝光量'); clk = fnum(r, '点击量'); spend = fnum(r, '花费')
    opp = fnum(r, '全站商机量') or fnum(r, '直通车总转化数')
    return {
        "花费": round(spend, 2), "曝光量": int(imp), "点击量": int(clk),
        "点击率": round(clk / imp * 100, 2) if imp else 0.0,
        "点击成本": round(spend / clk, 2) if clk else 0.0,
        "全站商机量": int(opp),
        "全站商机成本": round(spend / opp, 2) if opp else 0.0,
        "全站商机转化率": round(opp / clk * 100, 2) if clk else 0.0,
        "TM咨询量": int(fnum(r, 'TM咨询量') or fnum(r, 'searchAtmSessionCnt')),
        "询盘量": int(fnum(r, '询盘量') or fnum(r, 'searchMcCnt')),
        "订单量": int(fnum(r, '订单量') or fnum(r, 'searchOrderCnt')),
        "L1+全站商机量": int(fnum(r, 'L1+全站商机量')),
        "L1+买家点击占比": fnum(r, 'L1+买家点击占比'),
    }


WS_FIELDS = ['花费', '曝光量', '点击量', 'TM咨询量', '询盘量', '订单量', '全站商机量', 'L1+全站商机量']
SR_FIELDS = ['花费', '曝光量', '点击量', 'searchAtmSessionCnt', 'searchMcCnt', 'searchOrderCnt']
ALIAS = {'searchAtmSessionCnt': 'TM咨询量', 'searchMcCnt': '询盘量', 'searchOrderCnt': '订单量'}
SOURCES = [('campaign_whole_site', WS_FIELDS), ('campaign_search', SR_FIELDS)]


def field_sql(fields):
    return ", ".join('SUM("%s") AS "%s"' % (f, ALIAS.get(f, f)) for f in fields)


def fetch_window(begin, end, label):
    """返回 (account_dict, plan_rows_dict)"""
    account, plan_rows = {}, {}
    for datasource, fields in SOURCES:
        tname, sid, total = build_table(datasource, begin, end)
        key = datasource.replace('campaign_', 'company_')
        if not tname or not sid or not total:
            print("   [%s] %s: 无数据" % (label, datasource))
            account[key] = []
            continue
        agg, byplan = sql_rows(
            tname, sid,
            'SELECT %s FROM %s' % (field_sql(fields), tname),
            'SELECT "计划ID", "计划名称", %s FROM %s GROUP BY "计划ID", "计划名称"' % (field_sql(fields), tname))
        account[key] = [shape_row(r) for r in agg] if agg else []
        for r in byplan:
            plan_rows[(datasource, str(r.get('计划ID')))] = shape_row(r)
        if agg:
            a = account[key][0]
            print("   [%s] %s: 花费 ¥%s | 曝光 %s | 点击 %s | CPC ¥%s | 商机 %s | 商机成本 ¥%s" % (
                label, datasource, a['花费'], a['曝光量'], a['点击量'], a['点击成本'], a['全站商机量'], a['全站商机成本']))
    return account, plan_rows


print("\n== 最新完整周 %s ~ %s ==" % (WB, WE))
account, plan_rows = fetch_window(WB + " 00:00:00", WE + " 23:59:59", "周")

print("\n== 最新完整月 %s ~ %s ==" % (MB, ME))
m_account, _ = fetch_window(MB + " 00:00:00", ME + " 23:59:59", "月")

# ── 计划列表（预算/状态/在投商品数），与周数据 join ──────────────────
campaigns = []
for line, filters in [('search', {"summaryTypes": "search", "productLineId": "110101"}),
                      ('wholeSite', {"campaignType": "47", "productLineId": "110106",
                                     "summaryTypes": "wholeSite"})]:
    env = wc({"entityType": "campaign", "filters": filters, "include": "data"})
    datasource = 'campaign_search' if line == 'search' else 'campaign_whole_site'
    for c in (env.get('data') or []):
        cid = str(c.get('campaignId') or '')
        rep = plan_rows.get((datasource, cid))
        campaigns.append({
            "campaign_id": cid,
            "name": c.get('campaignName') or '',
            "line": line,
            "budget": float(c.get('budget') or 0),
            "product_count": int(float(c.get('onlineProductCount') or 0)),
            "onlineStatus": str(c.get('onlineStatus') if c.get('onlineStatus') is not None else ''),
            "report_data": [rep] if rep else [],
            "spend_week": (rep or {}).get('花费', 0),
        })
print("\n计划列表: %d 个（本周有花费 %d 个）" % (len(campaigns), sum(1 for c in campaigns if c['spend_week'] > 0)))

# ── 账户财务 ─────────────────────────────────────────────────────────
fin = wc({"entityType": "account_finance",
          "filters": {"accountTypes": ["search", "recommend", "all_domain"], "historyTypes": []},
          "include": "data"})
finance = {}
for it in (fin.get('data') or []):
    bal = it.get('balance') or {}
    if bal:
        finance[it.get('accountType')] = {
            "balance": bal.get('totalBalance'), "cash": bal.get('cashBalance'),
            "day_cost": bal.get('realDayCost'), "unsettled": bal.get('realUnSettleCost'),
        }

out = {"window": {"begin": WB, "end": WE}, "account": account, "campaigns": campaigns,
       "finance": finance,
       "month": {"begin": MB, "end": ME, "account": m_account}}
p = os.path.join(RAW, 'ads_report_%s.json' % TAG)
with open(p, 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("\nsaved %s" % p)

from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from dashboard_week_history import collect_ad_weeks
collect_ad_weeks(Path.cwd(),wc)  # MULTI_WEEK_ADS_V1
