# -*- coding: utf-8 -*-
"""V4: 拉取国家地区流量效果（访客/商机/询盘/TM/点击）并合并，算商机转化率"""
import subprocess, json, io, sys, os
from datetime import date, timedelta
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 最新完整自然周（动态计算）
_t = date.today(); _dow = (_t.weekday() + 1) % 7
_sun = _t - timedelta(days=_dow)
if _sun >= _t: _sun -= timedelta(days=7)
WEEK_START = (_sun - timedelta(days=6)).isoformat(); WEEK_END = _sun.isoformat()

DIMS = [
    ("shop_uv", "uv"),           # 访客
    ("total_bus_cnt", "bus"),    # 全站商机
    ("comp_fb_cnt", "fb"),       # 询盘个数
    ("comp_atm_uv", "atm"),      # TM咨询
    ("total_clk_cnt", "clk"),    # 全站点击
]

def call(dim):
    pfile = os.path.join(os.getcwd(), 'reg_tmp.json')
    with open(pfile, 'w', encoding='utf-8') as f:
        json.dump({"regionQueryParam": {"dimensionType": dim, "statisticsType": "week",
                  "startDate": WEEK_START, "endDate": WEEK_END, "terminalType": "TOTAL"}}, f)
    r = subprocess.run(['accio-mcp-cli', 'call', 'data_advisor_shop_region', '--json-file', pfile],
                       capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120, shell=True)
    env = json.loads(r.stdout)
    data = env.get('data') or []
    if not data: return {}
    # data[0] = {date: [items]}
    d0 = data[0] if isinstance(data, list) else data
    out = {}
    for date, items in d0.items():
        for it in items:
            name = it.get('countryName') or it.get('regionName') or ''
            if not name: continue
            # 找数值字段和占比字段
            val = None; rate = None
            for k, v in it.items():
                if k in ('countryName', 'regionName', 'date', 'ds'): continue
                if k.lower().endswith('rate') and rate is None: rate = float(v) if v else 0
                elif val is None and v is not None: 
                    try: val = float(v)
                    except: val = None
            out[name] = {"value": val, "rate": rate}
    return out

merged = {}
for dim, key in DIMS:
    print("拉取", dim, "...")
    r = call(dim)
    for name, d in r.items():
        merged.setdefault(name, {})[key] = d.get('value')
        merged.setdefault(name, {})['name'] = name

# 计算商机转化率
countries = []
for name, m in merged.items():
    uv = m.get('uv') or 0
    bus = m.get('bus') or 0
    fb = m.get('fb') or 0
    atm = m.get('atm') or 0
    clk = m.get('clk') or 0
    countries.append({
        "country": name, "uv": uv, "bus": bus, "fb": fb, "tm": atm, "clk": clk,
        "conv_rate": round(bus/uv*100, 1) if uv else 0,
    })
countries.sort(key=lambda x: -(x['uv'] or 0))

out = {"week": WEEK_START + " ~ " + WEEK_END, "countries": countries}
with open('raw/country_region.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

print("\n== 国家/地区 Top20（按访客）==")
for c in countries[:20]:
    print("  %-18s 访客%-5s 商机%-4s 询盘%-3s TM%-4s 点击%-5s 商机率%.1f%%" % (
        c['country'], int(c['uv']), int(c['bus']), int(c['fb']), int(c['tm']), int(c['clk']), c['conv_rate']))
