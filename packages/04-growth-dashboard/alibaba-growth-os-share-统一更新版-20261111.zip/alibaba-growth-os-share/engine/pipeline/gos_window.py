# -*- coding: utf-8 -*-
"""
gos_window.py — Alibaba Growth OS 时间窗口助手（可复现核心）

作用：给定一个 as_of 日期（默认=今天，可用 --as-of 或环境变量 GOS_AS_OF 覆盖），
按「自然周 = 周一~周日 + Advisory Date Gate(week_end <= as_of) + T+2」规则，
动态算出最近 N 个完整自然周 与 月度窗口（基础完整月 + 当月 MTD），
tag 命名与现有 raw 快照文件名保持一致，fetch / init 脚本共用，避免写死日期。

规则说明：
- 最近一个完整周 W1：其 Sunday(week_end) <= as_of，且是最接近 as_of 的这样一个 Sunday。
  每周二 T+2 跑时，as_of=周二 → 最近 Sunday 是 2 天前 → 该周数据已出，安全。
- 往回数 4 个完整周：W1..W4。
- 月度：base = W1 所在月的「上一自然月」(完整)；mtd = W1 所在月 1 号 ~ W1 的 week_end。

自测：
    python gos_window.py --as-of 2026-08-23   # 应复现 lifeworth 初始化窗口
    python gos_window.py --as-of 2026-09-09
"""
import sys, io, os, json, argparse
from datetime import date, timedelta

WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']


def _last_sunday_on_or_before(d: date) -> date:
    # d.weekday(): Mon=0 .. Sun=6
    return d - timedelta(days=(d.weekday() + 1) % 7)


def detect_platform_week_end(timeout=90):
    """问一次接口拿「平台当前可用的自然周」的 statDate（周六）。

    产品参谋的周数据比直通车落后，日历推出的「上周」可能平台还没出，
    所以默认用接口自报的周标记做锚点；拿不到才退回日历推算。
    """
    import json as _json, os as _os, subprocess as _sp
    from pathlib import Path as _P
    env = dict(_os.environ)
    bin_dir = _os.environ.get('GOS_MCP_BIN') or r'D://work//alibaba-growth-os//bin'
    env['PATH'] = bin_dir + _os.pathsep + env.get('PATH', '')
    cache = _P(_os.getcwd()) / 'raw' / 'platform_week_anchor.json'
    try:
        import tempfile
        args = _P(tempfile.gettempdir()) / ('_gos_anchor_args_%d.json' % _os.getpid())
        args.write_text(_json.dumps({'shopProductQueryParam': {
            'statisticsType': 'week', 'pageNo': 1, 'pageSize': 1}}, ensure_ascii=False),
            encoding='utf-8')
        r = _sp.run(['accio-mcp-cli', 'call', 'data_advisor_shop_product',
                     '--json-file', str(args)], capture_output=True, text=True,
                    encoding='utf-8', errors='replace', shell=True, env=env,
                    timeout=timeout)
        out = r.stdout or ''
        i = out.find('{')
        if i < 0:
            raise ValueError('no json')
        d = _json.loads(out[i:])
        from urllib.parse import urlsplit, parse_qs
        q = parse_qs(urlsplit(((d.get('data') or {}).get('downloadUrl') or '')).query)
        token = (q.get('statDate') or [''])[0]
        date.fromisoformat(token)
        if cache.parent.is_dir():
            cache.write_text(_json.dumps({'statDate': token, 'source': 'api'}), encoding='utf-8')
        return token
    except Exception:
        try:
            if cache.exists():
                return _json.loads(cache.read_text('utf-8')).get('statDate')
        except Exception:
            pass
    return None


def compute(as_of, n_weeks=4, anchor_end=None, auto_anchor=True):
    """anchor_end = 平台自然周的 statDate（周六）。有就按它锚定，避免日历推算与
    平台实际可得的周错位（产品参谋比直通车落后一周）。"""
    import sys
    from pathlib import Path
    sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
    from calendar_periods import dashboard_windows
    anchor = anchor_end or os.environ.get('GOS_NATIVE_WEEK_END') or None
    if not anchor and auto_anchor:
        anchor = detect_platform_week_end()
    return dashboard_windows(as_of,n_weeks,anchor_end=anchor)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--as-of', default=os.environ.get('GOS_AS_OF') or date.today().isoformat())
    ap.add_argument('--weeks', type=int, default=4)
    ap.add_argument('--anchor', default=None, help='平台周 statDate（周六，如 2026-10-17）')
    a = ap.parse_args()
    as_of = date.fromisoformat(a.as_of)
    res = compute(as_of, a.weeks, a.anchor)
    print('as_of = %s (%s)' % (res['as_of'], WEEKDAYS[as_of.weekday()]))
    for w in res['weeks']:
        print('  %s  %s ~ %s   tag=%s' % ('W%d' % w['idx'], w['week_start'], w['week_end'], w['tag']))
    for mo in res['months']:
        print('  %s  %s ~ %s   tag=%s' % (mo['key'], mo['month_start'], mo['month_end'], mo['tag']))
    if '--json' in sys.argv:
        print('\nJSON:\n' + json.dumps(res, ensure_ascii=False))


if __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    main()
