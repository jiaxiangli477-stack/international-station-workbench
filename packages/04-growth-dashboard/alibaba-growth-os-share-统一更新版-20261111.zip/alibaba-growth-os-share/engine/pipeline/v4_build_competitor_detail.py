# -*- coding: utf-8 -*-
"""V4: 合并竞品深度数据 → competitor_detail.json（每店：经营指标+Top20商品+买家画像）"""
import json, io, sys, os
from datetime import date
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
D = 'competitor_data'

metrics = json.load(open(os.path.join(D, 'supplier_selection_results.json'), encoding='utf-8'))
behavior = json.load(open(os.path.join(D, 'buyer_behavior_summary.json'), encoding='utf-8'))
profile = json.load(open(os.path.join(D, 'customer_profile_summary.json'), encoding='utf-8'))
peer = json.load(open('raw/peer_benchmark_parsed.json', encoding='utf-8'))

# 建立索引
behavior_by_domain = {s['domain']: s for s in behavior.get('stores', [])}
profile_by_domain = {s['domain']: s for s in profile.get('stores', [])}
peer_by_name = {p['store_name']: p for p in peer.get('peers', [])}

def top_n(items, n=5):
    return items[:n] if items else []

out = {"as_of": date.today().isoformat(), "stores": []}
for s in metrics.get('suppliers', []):
    dom = s.get('domain')
    dm = s.get('data_advisor_metrics', {}).get('derived_metrics', {})
    trend = dm.get('trend', {})
    b = behavior_by_domain.get(dom, {})
    p = profile_by_domain.get(dom, {})
    pdims = p.get('dimensions', {})
    pn = peer_by_name.get(s.get('supplier_name'), {})
    # 商品类目：从主图 URL / 商品标题推断不了类目，用主营产品 + 价格带替代
    price_units = []
    for pu in b.get('price_by_unit', [])[:4]:
        buckets = [x['bucket'] for x in pu.get('buckets', [])]
        price_units.append({"unit": pu.get('customer_label', ''), "buckets": buckets})
    country = top_n((pdims.get('country') or {}).get('items', []), 6)
    identity = top_n((pdims.get('byr_identity') or {}).get('items', []), 3)
    source = top_n((pdims.get('source') or {}).get('items', []), 3)
    search = top_n((pdims.get('shop_keyword') or {}).get('items', []), 5)
    out['stores'].append({
        "name": s.get('supplier_name'), "url": s.get('store_url'), "domain": dom,
        "main_products": s.get('main_products', []),
        "star": pn.get('star_level'), "score": pn.get('score'), "review_cnt": pn.get('review_cnt'),
        "metrics": {
            "gmv_index": round(dm.get('gmv_intensity_index') or 0, 1),
            "inquiry_eff": round(dm.get('inquiry_efficiency_index') or 0, 4),
            "order_eff": round(dm.get('order_efficiency_index') or 0, 4),
            "gmv_trend": (trend.get('rec_ord_amt_index') or {}).get('direction'),
            "inquiry_trend": (trend.get('ab_cnt_index') or {}).get('direction'),
            "uv_trend": (trend.get('uv_detail_index') or {}).get('direction'),
        },
        "products": {
            "sample_size": b.get('sample_size', 20),
            "avg_click": (b.get('metrics', {}).get('click_index') or {}).get('average'),
            "avg_exposure": (b.get('metrics', {}).get('exposure_index') or {}).get('average'),
            "avg_inquiry": (b.get('metrics', {}).get('inquiry_index') or {}).get('average'),
            "price_units": price_units,
        },
        "profile": {
            "country": [{"label": x.get('display_label'), "share": round(x.get('share', 0)*100, 1)} for x in country],
            "identity": [{"label": x.get('display_label'), "share": round(x.get('share', 0)*100, 1)} for x in identity],
            "source": [{"label": x.get('display_label'), "share": round(x.get('share', 0)*100, 1)} for x in source],
            "search": [{"label": x.get('display_label'), "share": round(x.get('share', 0)*100, 1)} for x in search],
        },
    })

with open('raw/competitor_detail.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

print("生成 %d 家店深度数据" % len(out['stores']))
for s in out['stores']:
    c = s['profile']['country']
    topc = c[0] if c else {}
    print("  %s | GMV指数%s(%s) | 询盘效率%s | Top国家:%s %s%% | Top商品%s个" % (
        s['name'][:18], s['metrics']['gmv_index'], s['metrics']['gmv_trend'],
        s['metrics']['inquiry_eff'], topc.get('label','—'), topc.get('share','—'), s['products']['sample_size']))
