# -*- coding: utf-8 -*-
"""
V4 T1 入库脚本：读取 raw/cs_w1..w4.json（员工经营效果）+ raw/chat_quality_check_20260818.json（聊天质检）
写入 SQLite: cs_staff_weekly, cs_chat_quality
"""
import sqlite3, json, os, io, sys, glob
from datetime import datetime, timedelta
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

DB = 'database/alibaba_growth.db'

def load_json(path):
    with open(path, 'rb') as f:
        raw = f.read()
    if raw[:2] == b'\xff\xfe':
        return json.loads(raw.decode('utf-16'))
    if raw[:3] == b'\xef\xbb\xbf':
        return json.loads(raw.decode('utf-8-sig'))
    return json.loads(raw.decode('utf-8'))

def week_of(date_str):
    d = datetime.strptime(date_str, "%Y-%m-%d")
    wd = d.weekday()
    ws = (d - timedelta(days=wd)).strftime("%Y-%m-%d")
    we = (d + timedelta(days=6 - wd)).strftime("%Y-%m-%d")
    return ws, we

# ---- 1. 员工经营效果（周度）----
staff_rows = []
for wk in ['w1', 'w2', 'w3', 'w4']:
    p = 'raw/cs_%s.json' % wk
    if not os.path.exists(p):
        continue
    d = load_json(p)
    data = d.get('data') or []
    if not data:
        continue
    d0 = data[0] if isinstance(data, list) else data
    # [本机补丁 2026-10-27] 平台自然周是周六~周五，week_of 的周一~周日换算会错位一周。
    # cs_w{i}.json 对应 _window.json 的第 i 个周窗口，直接用它，不再从日期反推。
    _win = {}
    try:
        _w = json.load(open('raw/_window.json', encoding='utf-8'))
        for _i, _x in enumerate(_w.get('weeks', [])[:4], 1):
            _win['w%d' % _i] = (_x['week_start'], _x['week_end'])
    except Exception:
        pass
    if isinstance(d0, dict):
        # {date: [staff...]}
        for date, arr in d0.items():
            ws, we = _win.get(wk) or week_of(date)
            for s in arr:
                staff_rows.append({
                    'week_start': ws, 'week_end': we, 'snap_date': date,
                    'full_name': s.get('fullName', ''),
                    'reply_rate': s.get('replyRate'),
                    'fst5min_reply_rate': s.get('fst5minReplyRate30d'),
                    'avg_reply_time': s.get('replyAvgTime') if s.get('replyAvgTime') is not None else s.get('avgReplyTime'),
                    'fb_pv': s.get('fbPv'), 'fb_uv': s.get('fbUv'),
                    'uv_fb_atm': s.get('uvFbAtm'),
                    'rcvd_amt': s.get('rcvdAmt'),
                    'prepay_ord': s.get('prepayMordCnt'),
                    'drawup_ord': s.get('drawupMordCnt'),
                    'bus_to_ord_rate': s.get('busToOrdRate'),
                    'avatar': (s.get('avatarUrl') or s.get('avtarUrl') or ''),
                    'raw_json': json.dumps(s, ensure_ascii=False),
                })
print("staff_rows=%d" % len(staff_rows))

# ---- 2. 聊天质检（按员工聚合）----
# 聊天质检是「可选数据域」：本包没有任何脚本会生成 raw/chat_quality_check_*.json，
# 原版在这里直接 open() 会 FileNotFoundError 并把整条管线打断。
# 缺文件时按空处理 —— 质检是增项，不该影响客服周表入库。
_cq = sorted(glob.glob('raw/chat_quality_check_*.json'))
if not _cq and os.path.exists('raw/chat_quality_check.json'):
    _cq = ['raw/chat_quality_check.json']
if _cq:
    cq = load_json(_cq[-1])
    cq_data = cq.get('data') or []
else:
    print('WARN: 未找到聊天质检文件（raw/chat_quality_check*.json），cs_chat_quality 按空处理')
    cq_data = []
cq_rows = []
for c in cq_data:
    cq_rows.append({
        'stats_date': c.get('statsDate'),
        'full_name': (c.get('firstName') or '') + (' ' + (c.get('lastName') or '') if c.get('lastName') else ''),
        'login_id': c.get('loginId'),
        'buyer_level': c.get('buyerLevel'),
        'l3l4_buyer': c.get('l3l4Buyer'),
        'reply_over12h': c.get('replyOver12h'),
        'not_follow': c.get('notFollow'),
        'buyer_rnr': c.get('buyerRnR'),
        'only_hi': c.get('onlyHi'),
        'evaluate_unsatisfied': c.get('evaluateUnsatisfied'),
        'msg_content': c.get('replyOver12hMsgContent'),
        'raw_json': json.dumps(c, ensure_ascii=False),
    })
print("chat_quality_rows=%d" % len(cq_rows))

# ---- 3. 写库 ----
c = sqlite3.connect(DB)
cur = c.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS cs_staff_weekly (
    week_end TEXT NOT NULL, week_start TEXT, snap_date TEXT, full_name TEXT,
    reply_rate REAL, fst5min_reply_rate REAL, avg_reply_time REAL,
    fb_pv INTEGER, fb_uv INTEGER, uv_fb_atm INTEGER, rcvd_amt REAL,
    prepay_ord INTEGER, drawup_ord INTEGER, bus_to_ord_rate REAL,
    avatar TEXT, raw_json TEXT,
    PRIMARY KEY (week_end, full_name))""")
cur.execute("""CREATE TABLE IF NOT EXISTS cs_chat_quality (
    id INTEGER PRIMARY KEY AUTOINCREMENT, stats_date TEXT, full_name TEXT,
    login_id TEXT, buyer_level TEXT, l3l4_buyer INTEGER, reply_over12h INTEGER,
    not_follow INTEGER, buyer_rnr INTEGER, only_hi INTEGER, evaluate_unsatisfied INTEGER,
    msg_content TEXT, raw_json TEXT)""")

# 只保留「全部账号」之外的员工行做子账号表；全部账号单独存
def is_all(s): return s.get('full_name') == '全部账号'

for s in staff_rows:
    cur.execute("""INSERT OR REPLACE INTO cs_staff_weekly
        (week_end, week_start, snap_date, full_name, reply_rate, fst5min_reply_rate, avg_reply_time,
         fb_pv, fb_uv, uv_fb_atm, rcvd_amt, prepay_ord, drawup_ord, bus_to_ord_rate, avatar, raw_json)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (s['week_end'], s['week_start'], s['snap_date'], s['full_name'], s['reply_rate'],
         s['fst5min_reply_rate'], s['avg_reply_time'], s['fb_pv'], s['fb_uv'], s['uv_fb_atm'],
         s['rcvd_amt'], s['prepay_ord'], s['drawup_ord'], s['bus_to_ord_rate'], s['avatar'], s['raw_json']))

# chat_quality 全量重写（当日快照）
cur.execute("DELETE FROM cs_chat_quality")
for x in cq_rows:
    cur.execute("""INSERT INTO cs_chat_quality
        (stats_date, full_name, login_id, buyer_level, l3l4_buyer, reply_over12h, not_follow,
         buyer_rnr, only_hi, evaluate_unsatisfied, msg_content, raw_json)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (x['stats_date'], x['full_name'], x['login_id'], x['buyer_level'], x['l3l4_buyer'],
         x['reply_over12h'], x['not_follow'], x['buyer_rnr'], x['only_hi'], x['evaluate_unsatisfied'],
         x['msg_content'], x['raw_json']))

c.commit()

# 校验
cur.execute("SELECT week_end, COUNT(*) FROM cs_staff_weekly GROUP BY week_end ORDER BY week_end")
print("cs_staff_weekly by week:", cur.fetchall())
cur.execute("SELECT full_name, COUNT(*) FROM cs_staff_weekly WHERE full_name != '全部账号' GROUP BY full_name ORDER BY full_name")
print("cs_staff_weekly staffs:", cur.fetchall())
cur.execute("SELECT full_name, COUNT(*), SUM(reply_over12h), SUM(not_follow) FROM cs_chat_quality GROUP BY full_name ORDER BY full_name")
print("cs_chat_quality by staff:", cur.fetchall())
c.close()
print("DONE")
