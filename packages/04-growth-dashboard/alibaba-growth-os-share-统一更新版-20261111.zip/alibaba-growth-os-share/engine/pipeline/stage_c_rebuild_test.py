"""stage_c_rebuild_test.py — PART 7/8/10 持久化与 Dashboard 重建验证（硬性验收）。

PART 7: 复制 database/alibaba_growth.db 到临时目录 → 关闭并重新打开 → 历史存在
PART 8: 不访问 Alibaba、仅依赖 SQLite 重建 dashboard_rebuild_test.html → 与现有 Dashboard 对比
        （KPI / Product / Peer / Actions / Optimizer / History 一致）
PART 10: Action / Optimizer / Validation / Learning 历史在重建后保留
"""
from __future__ import annotations

import json
import re
import shutil
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC_DB = ROOT / "database" / "alibaba_growth.db"
TMP_DIR = ROOT / "database" / "tmp_persistence"
TMP_DB = TMP_DIR / "alibaba_growth_copy.db"
REBUILT = ROOT / "dashboard" / "dashboard_rebuild_test.html"
CUR_DASH = ROOT / "dashboard" / "dashboard.html"


def extract_data_json(path: Path) -> dict:
    html = path.read_text(encoding="utf-8")
    i = html.find("var D = ")
    if i < 0:
        raise ValueError(f"cannot find 'var D = ' in {path}")
    j = html.find("{", i)
    obj, _ = json.JSONDecoder().raw_decode(html[j:])
    return obj


def main() -> int:
    results = {}

    # ---------- PART 7: 复制 → 关闭重开 → 历史存在 ----------
    TMP_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SRC_DB, TMP_DB)
    conn = sqlite3.connect(str(TMP_DB))
    conn.row_factory = sqlite3.Row
    counts = {
        "store_weekly": conn.execute("SELECT COUNT(*) FROM store_weekly_stats").fetchone()[0],
        "products": conn.execute("SELECT COUNT(*) FROM products").fetchone()[0],
        "product_weekly": conn.execute("SELECT COUNT(*) FROM product_weekly_stats").fetchone()[0],
        "diagnosis_actions": conn.execute("SELECT COUNT(*) FROM diagnosis_actions").fetchone()[0],
        "product_optimizations": conn.execute("SELECT COUNT(*) FROM product_optimizations").fetchone()[0],
        "diagnostics": conn.execute("SELECT COUNT(*) FROM diagnostics").fetchone()[0],
        "learnings": conn.execute("SELECT COUNT(*) FROM learnings").fetchone()[0],
        "validations": conn.execute("SELECT COUNT(*) FROM validations").fetchone()[0],
        "industry_trend": conn.execute("SELECT COUNT(*) FROM industry_trend").fetchone()[0],
    }
    w1 = dict(conn.execute("SELECT * FROM store_weekly_stats WHERE stat_week_end='2026-08-16'").fetchone())
    conn.close()  # 关闭
    conn = sqlite3.connect(str(TMP_DB))  # 重新打开
    reopened = conn.execute("SELECT COUNT(*) FROM store_weekly_stats").fetchone()[0]
    conn.close()
    # learnings/validations 为 0 属正常（尚未执行动作验证），历史表要求 > 0
    history_core = {k: v for k, v in counts.items() if k not in ("learnings", "validations")}
    p7_ok = all(v > 0 for v in history_core.values()) and reopened == counts["store_weekly"]
    results["PART7_DB_REOPEN_HISTORY"] = {
        "ok": p7_ok, **counts, "reopened_weeks": reopened,
        "learnings_validations_empty_ok": "空表属正常（未执行动作验证）"}

    # ---------- PART 8: 仅依赖 SQLite 重建 Dashboard ----------
    import subprocess
    proc = subprocess.run(
        ["python", "stage_b_dashboard.py", "--db", str(TMP_DB), "--output", str(REBUILT)],
        capture_output=True, text=True, encoding="utf-8")
    if proc.returncode != 0:
        results["PART8_REBUILD"] = {"ok": False, "stderr": proc.stderr[:500]}
    else:
        old = extract_data_json(CUR_DASH)
        new = extract_data_json(REBUILT)
        # 对比核心数据块（忽略 generated_at / 顺序差异）
        def norm(d: dict) -> dict:
            keys = ["w1", "w2", "w4", "mo7", "mtd", "top_products", "tiers",
                    "opts", "actions", "cs", "ident_all", "ident_l1", "trend"]
            return {k: d.get(k) for k in keys}

        a, b = norm(old), norm(new)
        equal = a == b
        results["PART8_REBUILD_NO_ALIBABA"] = {
            "ok": equal and REBUILT.exists(),
            "rebuilt_size_kb": round(REBUILT.stat().st_size / 1024, 1),
            "kpi_equal": a["w1"] == b["w1"],
            "product_equal": a["top_products"] == b["top_products"],
            "peer_equal": (a["w1"].get("total_imps_rival_avg") == b["w1"].get("total_imps_rival_avg")),
            "actions_equal": a["actions"] == b["actions"],
            "optimizer_equal": a["opts"] == b["opts"],
            "history_equal": a["trend"] == b["trend"],
            "full_data_equal": equal,
        }

    # ---------- PART 10: Action/Optimizer 历史保留 ----------
    conn = sqlite3.connect(str(TMP_DB))
    conn.row_factory = sqlite3.Row
    a_after = conn.execute("SELECT COUNT(*) FROM diagnosis_actions").fetchone()[0]
    o_after = conn.execute("SELECT COUNT(*) FROM product_optimizations").fetchone()[0]
    v_after = conn.execute("SELECT COUNT(*) FROM validations").fetchone()[0]
    l_after = conn.execute("SELECT COUNT(*) FROM learnings").fetchone()[0]
    conn.close()
    results["PART10_ACTION_PERSIST"] = {
        "ok": a_after == counts["diagnosis_actions"] == 8 and o_after == counts["product_optimizations"] == 8,
        "diagnosis_actions": a_after, "product_optimizations": o_after,
        "validations": v_after, "learnings": l_after,
        "note": "Dashboard 重建不触碰业务表，优化建议/执行状态/验证计划持续存在",
    }

    # ---------- 清理临时目录 ----------
    shutil.rmtree(TMP_DIR, ignore_errors=True)
    print(json.dumps(results, ensure_ascii=False, indent=1))
    all_ok = all(v.get("ok") for v in results.values())
    print("PERSISTENCE_REBUILD_PASS" if all_ok else "PERSISTENCE_REBUILD_FAIL")
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
