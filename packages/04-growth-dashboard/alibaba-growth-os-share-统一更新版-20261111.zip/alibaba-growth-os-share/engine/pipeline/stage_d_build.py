"""stage_d_build.py — Stage D 多页面驾驶舱生成器（Store Runtime 工具）。

从 database/alibaba_growth.db 提取全量数据 → dashboard/assets/dashboard_data.js，
并把 alibaba-growth-os/templates/dashboard/ 的静态页面模板复制到 dashboard/。
仅读 SQLite，不访问 Alibaba；全部相对路径，双击 index.html 可用。

用法: python stage_d_build.py
"""
from __future__ import annotations

import json
import shutil
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / "database" / "alibaba_growth.db"
TEMPLATES = ROOT / "alibaba-growth-os" / "templates" / "dashboard"
DASH = ROOT / "dashboard"


def main() -> int:
    conn = sqlite3.connect(str(DB))
    conn.row_factory = sqlite3.Row
    try:
        meta = {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM meta")}
        weeks = [dict(r) for r in conn.execute("SELECT * FROM store_weekly_stats ORDER BY stat_week_end")]
        months = {r["month_start"]: dict(r) for r in conn.execute("SELECT * FROM store_monthly_stats")}
        tiers = {}
        for r in conn.execute("SELECT prod_level AS p, COUNT(*) AS c FROM products WHERE prod_level IS NOT NULL GROUP BY prod_level"):
            tiers[r["p"]] = r["c"]
        products = [dict(r) for r in conn.execute(
            """SELECT p.product_id, p.title, p.prod_level AS tier, p.price_range, p.moq, p.detail_url,
                      p.main_image,
                      w.impressions, w.clicks, w.ctr, w.inquiries, w.orders, w.gmv,
                      e.atm_fb_uv, e.ad_imps, e.ad_clk, e.p4p_imps, e.p4p_clk,
                      e.sum_show_coc AS coc_show, e.sum_click_coc AS coc_click
               FROM products p
               JOIN product_weekly_stats w ON p.product_id = w.product_id AND w.week_start='2026-08-10'
               LEFT JOIN product_weekly_stats_ext e ON p.product_id = e.product_id AND e.week_start='2026-08-10'
               ORDER BY w.gmv DESC, w.inquiries DESC""")]
        cs_row = conn.execute("SELECT * FROM service_diag_snapshot ORDER BY stats_date DESC LIMIT 1").fetchone()
        cs = dict(cs_row) if cs_row else None
        profiles = {"byr_identity": [], "byr_identity_l1": [], "country": [], "country_l1": []}
        for r in conn.execute("SELECT * FROM customer_profile_snapshot"):
            key = r["dimension"] + ("_l1" if r["byr_growth_level"] else "")
            payload = json.loads(r["payload_json"])
            profiles[key] = payload[0].get("byr_identity" if "identity" in key else "country", []) if payload else []
        industry = [dict(r) for r in conn.execute("SELECT * FROM industry_trend ORDER BY period_index")]
        actions = [dict(r) for r in conn.execute("SELECT * FROM diagnosis_actions ORDER BY id")]
        opts = [dict(r) for r in conn.execute("SELECT * FROM product_optimizations ORDER BY id")]
        funnel = dict(conn.execute(
            """SELECT (SELECT SUM(inquiries) FROM product_weekly_stats WHERE week_start='2026-08-10') AS inquiries,
                      (SELECT SUM(atm_fb_uv) FROM product_weekly_stats_ext WHERE week_start='2026-08-10') AS tm_uv,
                      (SELECT SUM(mc_fb_uv) FROM product_weekly_stats_ext WHERE week_start='2026-08-10') AS mc_uv,
                      (SELECT SUM(crt_ord) FROM product_weekly_stats_ext WHERE week_start='2026-08-10') AS crt_ord,
                      (SELECT SUM(rts_online_amt) FROM product_weekly_stats_ext WHERE week_start='2026-08-10') AS gmv""").fetchone())
        deep_plans = conn.execute("SELECT COUNT(*) FROM product_optimizations WHERE deep_plan_json IS NOT NULL").fetchone()[0]

        # 官方诊断近 7 天商机量（raw 快照）
        official_opportunity = None
        brief = ROOT / "raw" / "store_diagnose_brief_full.json"
        if brief.exists():
            try:
                bd = json.loads(brief.read_text(encoding="utf-8"))
                for item in (bd.get("data", {}).get("aiSalesWeekDiagnoseList") or []):
                    v = item.get("businessChanceNum") or item.get("opporNum") or item.get("recentSevenDays") or {}
                    break
            except Exception:
                pass

        capabilities = {}
        cap_file = ROOT / "data_capabilities.json"
        if cap_file.exists():
            cj = json.loads(cap_file.read_text(encoding="utf-8"))
            capabilities = cj.get("domains", {})

        # Product 360 索引 + 真实同行（V1.2）
        product360 = {}
        for r in conn.execute("SELECT product_id, profile_json FROM product_360_profile"):
            try:
                product360[r["product_id"]] = json.loads(r["profile_json"])
            except Exception:
                pass
        competitors = [dict(r) for r in conn.execute("SELECT * FROM competitor_stores ORDER BY id")]
        comp_products = [dict(r) for r in conn.execute("SELECT * FROM competitor_products ORDER BY id")]
        market_products = [dict(r) for r in conn.execute(
            "SELECT product_id, title, image, category, rank, source, price_range, moq, certifications, product_url FROM market_products ORDER BY rank")]
        # 竞品/热品图片本地路径
        img_by_id = {r["product_id"]: r["image"] for r in conn.execute("SELECT product_id, image FROM market_products WHERE image IS NOT NULL")}
        for cp in comp_products:
            if cp["product_id"] in img_by_id:
                cp["local_image"] = "assets/competitors/" + cp["product_id"] + ".jpg"
            else:
                cp["local_image"] = None
        for mp in market_products:
            mp["local_image"] = "assets/competitors/" + mp["product_id"] + ".jpg" if mp["image"] else None
        buyer_snap = [dict(r) for r in conn.execute("SELECT * FROM buyer_snapshot ORDER BY snapshot_date")]
        cs_snap = [dict(r) for r in conn.execute("SELECT * FROM customer_service_snapshot ORDER BY stats_date")]
        # 决策层（V3）
        decisions = None
        dr = conn.execute("SELECT decision_json FROM operator_decisions ORDER BY period DESC LIMIT 1").fetchone()
        if dr:
            try:
                decisions = json.loads(dr["decision_json"])
            except Exception:
                decisions = None
        products_map = {p["product_id"]: p for p in products}

        data = {
            "store": {"name": meta.get("store_name", ""), "store_id": meta.get("store_binding", "")},
            "meta": {"advisory_date": meta.get("advisory_date", ""), "deep_plans": deep_plans,
                     "official_opportunity": official_opportunity},
            "weeks": weeks, "months": months, "tiers": tiers, "products": products,
            "products_map": products_map, "product360": product360, "competitors": competitors,
            "comp_products": comp_products, "market_products": market_products,
            "buyer_snap": buyer_snap, "cs_snap": cs_snap, "decisions": decisions,
            "cs": cs, "profiles": profiles, "industry": industry,
            "diagnostics": [], "actions": actions, "opts": opts,
            "capabilities": capabilities, "funnel": funnel,
        }
        js = "/* Alibaba Growth OS — 数据快照（由 stage_d_build.py 从 SQLite 生成，重建时覆盖） */\n"
        js += "window.GROWTH_OS_DATA = " + json.dumps(data, ensure_ascii=False, default=str) + ";\n"
        (DASH / "assets").mkdir(parents=True, exist_ok=True)
        (DASH / "assets" / "dashboard_data.js").write_text(js, encoding="utf-8")

        # 复制静态模板（HTML + assets 中的 app/state/styles；dashboard_data.js 不复制，用生成的）
        n_copy = 0
        for p in sorted(TEMPLATES.rglob("*")):
            if p.is_file():
                rel = p.relative_to(TEMPLATES)
                if rel.as_posix() == "assets/dashboard_data.js":
                    continue
                dest = DASH / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, dest)
                n_copy += 1

        html_pages = sorted(p.name for p in DASH.glob("*.html"))
        print(json.dumps({
            "dashboard_dir": str(DASH),
            "html_pages": len(html_pages), "pages": html_pages,
            "assets_copied": n_copy,
            "data": {"weeks": len(weeks), "products": len(products), "actions": len(actions),
                     "opts": len(opts), "deep_plans": deep_plans, "profiles_keys": list(profiles.keys())},
            "data_js_kb": round((DASH / "assets" / "dashboard_data.js").stat().st_size / 1024, 1),
        }, ensure_ascii=False, indent=1))
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
