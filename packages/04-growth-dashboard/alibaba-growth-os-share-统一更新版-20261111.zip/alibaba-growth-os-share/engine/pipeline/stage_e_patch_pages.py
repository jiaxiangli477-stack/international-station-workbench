"""stage_e_patch_pages.py — Stage E 页面修复（PART 26-30）：
1) 每个业务页面插入 <div id="concl"></div> + renderConcl(本页结论≤3, 本周建议≤3)
2) overview 增加漏斗卡点结论（PART 4/5）
3) action_center 业务化文案映射（PART 16）
4) search 三类区分（PART 23）、advertising AVAILABLE/PARTIAL/UNAVAILABLE（PART 22）
"""
from __future__ import annotations

from pathlib import Path

T = Path(__file__).resolve().parent / "alibaba-growth-os" / "templates" / "dashboard"

# 页面 → (结论列表, 建议列表)（内容与各页数据对应）
CONCL = {
    "overview.html": (
        ["① 流量规模优势明显（总曝光 88,107 vs 同行平均 26,845，+228%），但 GMV $2,542 落后同行优秀 $10,677（-76%）—— 流量规模优势 ≠ 经营效率优势，问题卡在 UV→订单转化（0.28% vs 优秀 0.42%）与客单价（$508 vs 同行平均 $1,501，仅 1/3）",
         "② 客服 5 分钟首响率 22.1% vs 同行平均 55.7%（已验证落后），压制 Click→Inquiry 转化",
         "③ 订单结构以小单为主（5 单/$2,542），缺大客户订单，客单价是最大结构性差距"],
        ["① 客服排班与话术优化（首响率→50%+，验证 2 周）",
         "② 官方定价优化 5 品（客单价提升）",
         "③ 标题重构（1600472561736）与主图重制（1601427218194）先执行高可落地项"]),
    "focus.html": (
        ["① 最大经营问题：GMV 连续回落（W3 $16,133 → W1 $2,542）+ 客单价仅同行 1/3",
         "② 客服响应显著落后（首响率 22.1% vs 55.7%）",
         "③ 高流量低转化：能量胶曝光 +194% 询盘仅 1"],
        ["① P0 客服改善（本周启动）",
         "② 定价优化（官方清单 5 品）",
         "③ 能量胶 MOQ 阶梯 REVIEW（需工厂确认）"]),
    "products.html": (
        ["① 680 产品中爆品 11 / 优品 202，但多数长尾产品零询盘，拖累整体 UV→订单率",
         "② 优品 1601635898551 CTR 仅 0.43%（曝光 +215% 但点不进去）；优品 1601387052135 曝光 +184%/询盘 2 值得观察",
         "③ 产品级历史仅 W1 单周，趋势判断需增量累积"],
        ["① 聚焦 8 个 AI 优化候选（见 AI产品优化页）",
         "② 观察优品 1601387052135（转化好流量涨）是否进入下轮候选",
         "③ 长尾零商机产品暂不动（避免无效动作）"]),
    "ai_optimizer.html": (
        ["① 8 个候选全部具备 17 项深度方案（标题×3 / 主图×2 / 详情×2 / MOQ·定价 REVIEW×2 覆盖）",
         "② 全部为单变量（PRIMARY）+ Future 拆分，可做 One Variable 验证",
         "③ MOQ/定价类均 NEEDS_HUMAN_CONFIRMATION=true，AI 不越权定商业政策"],
        ["① 先执行高可落地项：标题重构 ×2（1600472561736 / 1600546912886）",
         "② 主图重制 ×2（1601427218194 / 1601720577533）按 Creative Brief 交设计",
         "③ 详情转化 ×2（1601719605709 / 1601476000834）本周排期"]),
    "advertising.html": (
        ["① 店铺以营销推广（全站推）为主（W1 营销曝光 31,490），P4P 标准推广未投放",
         "② Campaign 级 Spend/CPC/CPL 不可得 → 无法判断计划级问题（PARTIAL/UNAVAILABLE 如实标注）",
         "③ 产品级 Paid 信号可得：能量胶等品广告曝光较高"],
        ["① 先修复转化漏斗（客服首响率/详情询盘转化）再评估 P4P 投放",
         "② 曝光高增长产品（能量胶）窗口评估广告承接",
         "③ 广告动作统一经行动执行台登记后执行"]),
    "search.html": (
        ["① Buyer Search Terms 当前不可得；本页严格区分 Buyer Search Terms / Buyer Profile / Traffic Intent 三类数据（不混用）",
         "② 买家进店以零售商为主（线上 38.8% + 线下 32.7%），批发 21.1%",
         "③ AI Query 承接分析（AI_INFERENCE）：6 组高相关 Query 均为部分/弱承接，标题/属性/MOQ/详情各有缺口"],
        ["① 按 Query 承接缺口修复标题（creatine bulk 主词前置）",
         "② 详情补 B2B 定制参数表（caffeine pouch custom）",
         "③ 能量胶 MOQ 阶梯确认后承接 'energy gels' 询盘"]),
    "customer_service.html": (
        ["① 5 分钟首响率 22.1% vs 同行平均 55.7%、优秀 71.4% —— 显著落后（已验证）",
         "② 平均回复时长 5.75 分钟 vs 同行 2.59 分钟",
         "③ 当前仅 Store-level 指标（Sub-account 明细不可得，不冒充）"],
        ["① 排班覆盖高峰时段 + 快捷回复模板（价格/交期/MOQ）",
         "② TM 咨询 24h 内引导转询盘",
         "③ 2 周后复测首响率验证效果"]),
    "buyer_quality.html": (
        ["① 买家结构：线上零售商 38.8% + 线下 32.7% + 批发 21.1% —— 零售渠道占主导",
         "② L1+ 买家画像已取（byrGrowthLevel 官方筛选）；精确 L0-L4 不可用，与 Buyer Type 严格区分不混用",
         "③ 美国买家 30.7% 居首，其次塞内加尔 8.3%/英国 7.9%"],
        ["① 针对零售商/批发分层制定报价与定制策略",
         "② 欧美重点市场（US/UK/FR）强化合规展示",
         "③ L1+ 高价值买家优先跟进（客服联动）"]),
    "trends.html": (
        ["① 4 周 GMV 波动大：W3 高点 $16,133 → W1 $2,542（-84%），订单 14→5",
         "② 曝光稳定（8.4万-9.2万），波动集中在订单/GMV 而非流量",
         "③ 产品/广告/客服/Buyer 历史仍为单点快照，趋势随增量同步累积"],
        ["① 连续追踪 4 周以上再做趋势判断（当前仅 4 周）",
         "② 关注 GMV 是否企稳（本周 W2 8/17-8/23 数据 8/25 后同步）",
         "③ 客单价指标纳入每周追踪"]),
    "peer_benchmark.html": (
        ["① 流量规模全面领先（曝光 +228% vs 平均 / +36% vs 优秀），经营效率全面落后（GMV -15% vs 平均 / -76% vs 优秀）",
         "② 客单价 $508 vs 平均 $1,501（-66%）为最大结构性差距",
         "③ 客服 5 分钟首响率显著落后（22.1% vs 55.7%）"],
        ["① 客单价提升（定价优化 + 大客户订单）作为本月主线",
         "② 客服指标对标修复（2 周）",
         "③ 每周围绕 9 业务域差距排名跟进 Top 差距项"]),
    "action_center.html": (
        ["① 9 条行动（8 产品 + 1 客服）均为 P0-P1，全部可执行",
         "② 行动状态需人工登记：localStorage → 导出 JSON → IMPORT ACTION UPDATES 合并 SQLite",
         "③ 验证遵循 One Variable Test（每品 1 个 Primary）"],
        ["① 本周登记 2-3 条状态（已确认/优化中）并导出执行记录",
         "② 指定负责人与截止日期（建议周五前完成登记）",
         "③ 验证窗口 ≥ 1 完整自然周"]),
    "data_health.html": (
        ["① 核心数据域 READY：店铺大盘/同行对标/产品 680/分层/客服/买家画像/行业趋势",
         "② UNAVAILABLE：订单明细 / Buyer Search Terms / Campaign 明细 / L0-L4 精确 / 竞品明细（如实标注，不填 0）",
         "③ SQLite 为唯一历史事实源，看板可随时重建"],
        ["① 规划数据接入优先级（订单明细 → 搜索词 → Campaign）",
         "② 每周 SYNC WEEKLY 自动累积历史",
         "③ 按 data_capabilities.json 逐域核对数据新鲜度"]),
}

# action_type 业务化文案（PART 16）
ACTION_LABEL = {
    "title_rewrite": "重构标题", "main_image": "测试新主图", "moq_ladder": "检查 MOQ / 试单门槛",
    "detail_b2b_section": "强化 B2B 转化模块", "price_optimize": "复查定价", "cert_bind": "绑定行业品证",
    "keyword_add": "扩充关键词", "bid_change": "调整出价", "detail_conversion": "强化详情询盘转化",
    "service_schedule": "客服排班与话术", "REVIEW_MOQ_LADDER": "复查 MOQ 阶梯", "PRICE_OPTIMIZE_REVIEW": "复查定价",
}


def patch() -> None:
    for fname in CONCL:
        p = T / fname
        html = p.read_text(encoding="utf-8")
        if 'id="concl"' not in html:
            html = html.replace(
                '<div class="meta" id="head-meta"></div></header>',
                '<div class="meta" id="head-meta"></div></header>\n<div id="concl"></div>', 1)
        concl, acts = CONCL[fname]
        js = "renderConcl({}, {});".format(
            json_str(concl), json_str(acts))
        marker = "</script>\n</body>"
        if "renderConcl(" not in html:
            html = html.replace(marker, js + "\n" + marker, 1)
        p.write_text(html, encoding="utf-8")
        print(f"patched {fname}")

    # action_center: 业务化文案
    p = T / "action_center.html"
    html = p.read_text(encoding="utf-8")
    if "ACTION_LABEL" not in html:
        html = html.replace("var PRIO = {",
            "var ACTION_LABEL = " + json_str(ACTION_LABEL) + ";\nvar PRIO = {", 1)
        html = html.replace(
            'esc((it.row.description || it.row.current_problem || "").slice(0, 60))',
            "esc((it.row.action_type && ACTION_LABEL[it.row.action_type] ? ACTION_LABEL[it.row.action_type] : it.row.action_type) + ' — ' + (it.row.description || it.row.current_problem || '').slice(0, 60))")
        p.write_text(html, encoding="utf-8")
        print("patched action_center.html (business labels)")

    # search: 三类区分
    p = T / "search.html"
    html = p.read_text(encoding="utf-8")
    if "Traffic Intent" not in html:
        html = html.replace(
            '<div class="section-title">替代情报 · 买家进店身份结构（30d 访客）</div>',
            '<div class="section-title">数据区分（三类不同数据，不混用）</div>\n'
            '<div class="cards cols3" id="cat"></div>\n\n'
            '<div class="section-title">Buyer Profile · 买家进店身份结构（30d 访客，非搜索词）</div>')
        js3 = """document.getElementById("cat").innerHTML = [
  ["Buyer Search Terms", "UNAVAILABLE（无官方工具；P4P 未投无 Ad Keyword）"],
  ["Buyer Profile", "可用（30d 访客身份/国家，见下方卡片）"],
  ["Traffic Intent", "部分（买家身份推断采购意图，AI_INFERENCE；无真实 Query）"]
].map(function (c) {
  return '<div class="card"><div class="label">' + c[0] + '</div><div class="value" style="font-size:14px">' + c[1] + "</div></div>";
}).join("");"""
        html = html.replace("  var id = document.getElementById(\"identity\");",
                            js3 + "\n  var id = document.getElementById(\"identity\");")
        p.write_text(html, encoding="utf-8")
        print("patched search.html (3-category)")

    # advertising: AVAILABLE/PARTIAL/UNAVAILABLE
    p = T / "advertising.html"
    html = p.read_text(encoding="utf-8")
    if "AVAILABLE" not in html:
        html = html.replace(
            '<div class="section-title">广告整体（W1, 8/10-8/16）</div>',
            '<div class="section-title">数据能力分段 · AVAILABLE / PARTIAL / UNAVAILABLE</div>\n<div class="cards cols3" id="seg"></div>\n\n<div class="section-title">广告整体（W1, 8/10-8/16 · AVAILABLE）</div>')
        js4 = """document.getElementById("seg").innerHTML = [
  ["AVAILABLE", "店铺级营销曝光/点击（campImps/campClk/qzt）+ 产品级 Paid Impr/Clk + 搜索/询盘信号"],
  ["PARTIAL", "P4P 未投放（曝光 0）；无 Campaign 级花费结构；广告归因 GMV 不可得 → 不计算 ROAS"],
  ["UNAVAILABLE", "Spend / CPC / CPL / Campaign 列表 / 广告归因收入（禁止估算为真实值）"]
].map(function (c) {
  return '<div class="card"><div class="label">' + c[0] + '</div><div class="value" style="font-size:12.5px;font-weight:400;line-height:1.6">' + c[1] + "</div></div>";
}).join("");"""
        html = html.replace("  var w = w1(), p = w2();",
                            js4 + "\n  var w = w1(), p = w2();", 1)
        p.write_text(html, encoding="utf-8")
        print("patched advertising.html (segments)")

    # ai_optimizer: 证据类型标记（官方/计算/AI推断）
    p = T / "ai_optimizer.html"
    html = p.read_text(encoding="utf-8")
    if "evidence-tag" not in html:
        html = html.replace(
            '<div class="alert info">',
            '<style>.evidence-tag{font-size:10.5px;padding:1px 6px;border-radius:8px;margin-left:6px}.ev-o{background:#f6ffed;color:#389e0d}.ev-c{background:#f0f5ff;color:#2f54eb}.ev-ai{background:#fff7e6;color:#d46b08}</style>\n<div class="alert info">')
        # 在 deep plan 渲染的 k 标签后加证据类型
        html = html.replace(
            "s += '<div class=\"plan-block\" style=\"border:none;padding:8px 0;border-bottom:1px solid #f0f0f0;margin:0\"><div class=\"k\">' + k.replace(/^\\d+_/, \"\") + \"</div>\";",
            "s += '<div class=\"plan-block\" style=\"border:none;padding:8px 0;border-bottom:1px solid #f0f0f0;margin:0\"><div class=\"k\">' + k.replace(/^\\d+_/, \"\") + evTag(k) + \"</div>\";")
        html = html.replace(
            "function renderTitlePlan(v) {",
            """function evTag(k) {
  var o = { "1_why_selected": "ev-c", "2_current_problem": "ev-c", "3_data_evidence": "ev-o", "4_self_history": "ev-o",
    "5_peer_gap": "ev-c", "6_buyer_intent": "ev-ai", "7_listing_diagnosis": "ev-o", "8_competitor_gap": "ev-o",
    "9_root_cause": "ev-c", "10_primary_action": "ev-c", "11_concrete_plan": "ev-ai", "12_do_not_change": "ev-c",
    "13_future_actions": "ev-c", "14_validation_metric": "ev-c", "15_validation_period": "ev-c",
    "16_confidence": "ev-c", "17_evidence_source": "ev-o" };
  var t = { "ev-o": "官方数据", "ev-c": "系统计算", "ev-ai": "AI推断" }[o[k]];
  return t ? '<span class="evidence-tag ' + o[k] + '">' + t + "</span>" : "";
}
function renderTitlePlan(v) {""")
        p.write_text(html, encoding="utf-8")
        print("patched ai_optimizer.html (evidence tags)")


def json_str(arr) -> str:
    import json
    return json.dumps(arr, ensure_ascii=False)


if __name__ == "__main__":
    patch()
