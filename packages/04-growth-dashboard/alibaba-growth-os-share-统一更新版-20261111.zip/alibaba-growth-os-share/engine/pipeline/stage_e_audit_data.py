"""stage_e_audit_data.py — Stage E 运营级数据审计：漏斗诊断 + 20 产品抽检数据。"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent / "database" / "alibaba_growth.db"


def main():
    conn = sqlite3.connect(str(DB))
    conn.row_factory = sqlite3.Row
    out = {}

    # ---- 漏斗（W1 8/10-8/16 店级 + 产品级汇总）----
    w = dict(conn.execute("SELECT * FROM store_weekly_stats WHERE stat_week_end='2026-08-16'").fetchone())
    funnel_prod = dict(conn.execute(
        """SELECT (SELECT SUM(inquiries) FROM product_weekly_stats WHERE week_start='2026-08-10') AS inquiries,
                  (SELECT SUM(atm_fb_uv) FROM product_weekly_stats_ext WHERE week_start='2026-08-10') AS tm_uv,
                  (SELECT SUM(mc_fb_uv) FROM product_weekly_stats_ext WHERE week_start='2026-08-10') AS mc_uv,
                  (SELECT SUM(crt_ord) FROM product_weekly_stats_ext WHERE week_start='2026-08-10') AS crt_ord,
                  (SELECT SUM(rts_online_amt) FROM product_weekly_stats_ext WHERE week_start='2026-08-10') AS gmv""").fetchone())
    funnel = {
        "traffic_total_imps": w["total_imps"], "traffic_se_imps": w["se_imps"],
        "traffic_avg": w["total_imps_rival_avg"], "traffic_good": w["total_imps_rival_good"],
        "click": w["se_clk"], "click_avg": w["se_clk_rival_avg"], "click_good": w["se_clk_rival_good"],
        "ctr": w["se_ctr"], "ctr_avg": w["se_ctr_rival_avg"], "ctr_good": w["se_ctr_rival_good"],
        "visitor_uv": w["uv_cnt"], "visitor_uv_good": w["uv_cnt_rival_good"],
        "bounce": w["uv_ab_rate"], "bounce_avg": w["uv_ab_rate_rival_avg"], "bounce_good": w["uv_ab_rate_rival_good"],
        "inquiry": funnel_prod["inquiries"], "tm": funnel_prod["tm_uv"], "inquiry_buyer": funnel_prod["mc_uv"],
        "order": w["suc_ord_cnt"], "order_avg": w["suc_ord_cnt_rival_avg"], "order_good": w["suc_ord_cnt_rival_good"],
        "gmv": w["suc_ord_amt"], "gmv_avg": w["suc_ord_amt_rival_avg"], "gmv_good": w["suc_ord_amt_rival_good"],
        "uv_payord": w["uv_payord_rate"], "uv_payord_avg": w["uv_payord_rate_rival_avg"], "uv_payord_good": w["uv_payord_rate_rival_good"],
        "avg_order_value": (w["suc_ord_amt"] / w["suc_ord_cnt"]) if w["suc_ord_cnt"] else None,
        "avg_order_value_avg": (w["suc_ord_amt_rival_avg"] / w["suc_ord_cnt_rival_avg"]) if w["suc_ord_cnt_rival_avg"] else None,
        "avg_order_value_good": (w["suc_ord_amt_rival_good"] / w["suc_ord_cnt_rival_good"]) if w["suc_ord_cnt_rival_good"] else None,
        "cs_5min": None, "cs_5min_avg": None,
    }
    cs = conn.execute("SELECT five_min_reply_rate, five_min_reply_rate_avg FROM service_diag_snapshot ORDER BY stats_date DESC LIMIT 1").fetchone()
    if cs:
        funnel["cs_5min"] = cs["five_min_reply_rate"]
        funnel["cs_5min_avg"] = cs["five_min_reply_rate_avg"]
    out["funnel"] = funnel

    # ---- 20 产品抽检（5 爆 + 5 优 + 5 潜 + 5 普，按 W1 曝光排序抽样）----
    sample = {}
    for tier, n in [("爆品", 5), ("优品", 5), ("潜力优品", 5), ("普通品", 5)]:
        rows = conn.execute(
            """SELECT p.product_id, p.prod_level AS tier,
                      w.impressions, w.clicks, w.ctr, w.inquiries, w.orders, w.gmv,
                      e.sum_show_coc AS coc_show,
                      CASE WHEN o.id IS NULL THEN 0 ELSE 1 END AS has_opt
               FROM products p
               JOIN product_weekly_stats w ON p.product_id=w.product_id AND w.week_start='2026-08-10'
               LEFT JOIN product_weekly_stats_ext e ON p.product_id=e.product_id AND e.week_start='2026-08-10'
               LEFT JOIN product_optimizations o ON o.product_id=p.product_id
               WHERE p.prod_level=? AND (e.total_imps > 0)
               ORDER BY w.gmv DESC, w.inquiries DESC LIMIT ?""",
            (tier, n)).fetchall()
        sample[tier] = [dict(r) for r in rows]
    out["sample_20"] = sample

    # ---- 8 候选的业务化画像 ----
    cands = conn.execute(
        """SELECT o.product_id, o.title, p.prod_level AS tier, o.primary_action, o.confidence, o.data_evidence,
                  o.why_selected, o.deep_plan_json IS NOT NULL AS has_deep,
                  w.impressions, w.clicks, w.ctr, w.inquiries, w.orders, w.gmv,
                  e.sum_show_coc AS coc_show, e.ad_imps, e.ad_clk
           FROM product_optimizations o
           JOIN products p ON p.product_id=o.product_id
           LEFT JOIN product_weekly_stats w ON w.product_id=o.product_id AND w.week_start='2026-08-10'
           LEFT JOIN product_weekly_stats_ext e ON e.product_id=o.product_id AND e.week_start='2026-08-10'
           ORDER BY o.id""").fetchall()
    out["candidates"] = [dict(r) for r in cands]

    print(json.dumps(out, ensure_ascii=False, indent=1, default=str))
    conn.close()


if __name__ == "__main__":
    main()
