"""stage_b_optimizer.py — STEP 17-21 AI Product Optimizer 首跑。

基于真实数据（W1 官方表现 + 公开 Listing 详情 + 店铺/行业/买家画像 + 官方诊断）为 Top 8 候选
生成具体优化方案（One Variable Test），写入 diagnosis_actions / product_optimizations 表。
只建议，不修改任何 Alibaba Listing。
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / "database" / "alibaba_growth.db"

# 每个候选: 真实数据 + 真实 Listing 分析（AI 推理部分显式标注 AI_INFERENCE=1）
PLANS = [
    {
        "product_id": "1600472561736",
        "title": "LIFEWORTH Pre Workout Bodybuilding Supplement Creatine Monohydrate Bulk Energy Drink Powder Caffeine Preworkout Powder 300g",
        "tier": "爆品",
        "why_selected": "官方爆品 + 店铺 W1 询盘最高（5）+ TM 4；搜索 CTR 5.15% 远超店均 1.7%，转化基础好但搜索流量受限（曝光 1710），广告曝光占比 66%（2044/3074）",
        "current_problem": "自然搜索流量不足，过度依赖广告曝光；点击同比 +37.8% 但询盘转化（5/88=5.7%）未同步放大",
        "data_evidence": "W1: 搜索曝光 1710, 点击 88, CTR 5.15%, 询盘 5, TM 4, 订单 1, GMV $68; 总曝光 3074(广告 2044); coc_show +4.8%, coc_click +37.8%",
        "self_history": "4 周店内该品曝光/点击处于上升通道（coc 均正）",
        "peer_gap": "店级搜索 CTR 1.69% vs 同行平均 1.77%（接近）；但本品 5.15% 的 CTR 说明主图/标题点击力强，缺的是自然曝光入口",
        "buyer_intent": "买家结构: 线上零售商 38.8% / 线下 32.7% / 批发 21.1%；标题含 Bulk/300g 已覆盖批发意图，OEM 关键词不足",
        "listing_gap": "Listing 属性 'Primary Ingredient' 与 'Main Ingredients' 不一致（Blended,Caffeine... vs Green Tea Extract,BCAA）；MOQ 100 boxes 试单友好；'Flavor: OEM' 属性值为 OEM 占位，搜索匹配弱",
        "root_cause": "关键词/标题对自然搜索词覆盖不足（Energy Drinks 排名 #4 但搜索曝光仅 1710），广告掩盖了自然流量瓶颈",
        "primary_action": "title_rewrite（One Variable: 标题）",
        "candidate_titles": [
            "LIFEWORTH Creatine Monohydrate Pre Workout Powder 300g - Sugar Free Energy Drink Mix Bulk OEM Private Label",
            "Pre Workout Creatine Monohydrate Powder Bulk 300g Energy Drink Caffeine Supplement - OEM ODM Private Label Manufacturer",
            "Creatine Monohydrate Pre-Workout 300g Can - Explosive Energy Endurance Powder Bulk OEM Private Label GMP Factory"
        ],
        "secondary_actions": ["关键词: 补充 'creatine monohydrate powder bulk'/'pre workout energy drink mix' 长尾词", "属性: 统一 Primary Ingredient 与 Main Ingredients 口径，补齐 Flavor 具体口味"],
        "do_not_do": "不降 MOQ（100 boxes 已友好）；不动价格（$2.80-3.40 阶梯合理，官方未列入定价优化）",
        "validation_metric": "搜索曝光 / 搜索点击 / 询盘数（周环比，对照 coc 基线）",
        "validation_period": "1 个完整自然周（下一周 8/24-8/30）",
        "confidence": "medium",
        "listing_read": 1,
    },
    {
        "product_id": "1601492686064",
        "title": "LIFEWORTH Caffeine Isotonic Sports Energy Gels Packet Electrolyte Mix for Running Cycling Recovery Faster Energy Management",
        "tier": "爆品",
        "why_selected": "官方爆品；W1 搜索曝光同比 +194%（coc_show 2.94）流量暴涨，但询盘仅 1 → 高流量低转化的典型，优化杠杆最大",
        "current_problem": "曝光 3 倍增长未转化为询盘：W1 点击 20、询盘 1、TM 4；MOQ 10000 pcs 门槛过高，试单买家流失",
        "data_evidence": "W1: 搜索曝光 784(coc +194%), 点击 20, CTR 2.55%, 询盘 1, TM 4, 订单 1; MOQ 10000 pcs; 价格 $0.19-0.25",
        "self_history": "曝光处于爆发期（+194%），转化未跟上",
        "peer_gap": "店级 UV→订单率 0.47% vs 同行优秀 0.56%（接近）；问题是询盘层转化而非流量",
        "buyer_intent": "能量胶买家以跑团/经销渠道为主，习惯小批量试单（500-2000 pcs）验证口味",
        "listing_gap": "MOQ 10000 pcs 为店最高档之一；未提供小批量试单 SKU/选项",
        "root_cause": "MOQ 阶梯设计压制试单转化；流量暴涨窗口未被询盘承接",
        "primary_action": "moq_ladder（One Variable: MOQ 试单档）",
        "recommended_change": "新增 1000 pcs 试单档（价格上浮 10-15% 覆盖小批量成本），保留 10000 pcs 批发档；同步在属性/详情标注 'Sample order available'",
        "secondary_actions": ["详情页补充能量胶应用场景（跑步/骑行）与口味矩阵图", "评估投放广告承接新增流量"],
        "do_not_do": "不全面降价（行业能量胶批发价带 $0.19-0.25 已具竞争力）",
        "validation_metric": "询盘数 / TM 数 / 订单数（MOQ 调整后完整自然周）",
        "validation_period": "1 个完整自然周",
        "confidence": "medium",
        "listing_read": 1,
    },
    {
        "product_id": "1601720577533",
        "title": "LIFEWORTH Fast Dissolving Oral Film Energy Strips ODM Caffeine L-Theanine Vitamin B12 Electrolytes",
        "tier": "爆品",
        "why_selected": "官方爆品；询盘 3 + TM 3 说明需求真实，但 W1 搜索曝光 -1.1%、点击 -30.8% 双双下滑 → 流量衰减风险",
        "current_problem": "点击同比暴跌 31%（coc_click 0.692→-30.8%），CTR 1.72% 低于店均；曝光微降",
        "data_evidence": "W1: 搜索曝光 523, 点击 9, CTR 1.72%, 询盘 3, TM 3, 订单 1, GMV $68; coc_show -1.1%, coc_click -30.8%; 价格 $2.60-2.90, MOQ 3000 boxes",
        "self_history": "4 周内点击持续下滑",
        "peer_gap": "CTR 1.72% vs 店均 1.69%（持平），点击下滑更可能是关键词/排名问题而非主图问题",
        "buyer_intent": "口腔膜（oral film）为差异化创新剂型，买家需要看到形态与使用方式（图片/视频演示）",
        "listing_gap": "Oral Film 剂型认知度低，主图未直观展示膜片形态与速溶效果；视频缺失",
        "root_cause": "创新剂型缺乏视觉传达 → 点击率走低 → 排名衰减循环",
        "primary_action": "main_image（One Variable: 主图）",
        "image_brief": "主图 Creative Brief: ① 45° 俯拍口腔膜单片置于舌尖的速溶瞬间（浅色背景）② 左上角标注 'Fast Dissolving Oral Film' ③ 右侧小图展示 3 口味条装 ④ 底部绿条 'ODM Caffeine + L-Theanine + B12' ⑤ 尺寸 800x800+，首屏 3 秒传达'速溶能量膜'",
        "secondary_actions": ["补充 15-30s 速溶演示视频", "关键词补 'energy strips'/'oral dissolving strips'"],
        "do_not_do": "不降 MOQ 3000（该剂型产线成本决定）",
        "validation_metric": "CTR / 点击 / 询盘（主图更换后完整自然周）",
        "validation_period": "1 个完整自然周",
        "confidence": "medium",
        "listing_read": 1,
    },
    {
        "product_id": "1600546912886",
        "title": "LIFEWORTH Private Label Pre Workout Creatine Monohydrate Powder Muscle Building Energy Supplement Helps Support Explosive Energy",
        "tier": "爆品",
        "why_selected": "官方爆品；点击同比暴跌 -81.8%（coc_click 0.18），CTR 1.52% 低于店均，且与 #1600472561736 同配方不同价位形成内部竞争",
        "current_problem": "同店同配方产品（$4.00-4.60 vs $2.80-3.40）内部流量分流；点击暴跌至 13",
        "data_evidence": "W1: 搜索曝光 857, 点击 13, CTR 1.52%, 询盘 0, 订单 1, GMV $68; coc_show -11.2%, coc_click -81.8%; 价格 $4.00-4.60, MOQ 100 bottles; 认证 HALAL MSDS FSSC HACCP",
        "self_history": "曝光/点击双下滑",
        "peer_gap": "CTR 1.52% < 店均 1.69%，点击力弱",
        "buyer_intent": "Private Label 买家（品牌商）找 OEM 供应商，关注定制能力与认证；标题已含 Private Label 但首屏价格高于同配方品",
        "listing_gap": "与 1600472561736 同质化严重（同 creatine pre-workout，价格高 30%+），差异化定位缺失",
        "root_cause": "同质产品内部竞争 + 定位模糊（无明确 Private Label/OEM 卖点首屏化）",
        "primary_action": "title_rewrite（One Variable: 标题差异化定位）",
        "candidate_titles": [
            "LIFEWORTH Private Label Creatine Pre Workout Powder - OEM Custom Formula Bulk Manufacturer HALAL Certified 500g",
            "Private Label Pre Workout Creatine Monohydrate - Custom Branding OEM ODM Bulk Factory Direct GMP Certified",
            "Creatine Pre Workout Private Label OEM - Custom Flavor & Packaging, 500g Bulk, HALAL & HACCP Certified"
        ],
        "secondary_actions": ["价格带差异化: 明确 500g 大包装定位，与 300g 罐装品拉开规格差异", "详情页强化 Private Label 定制流程（logo/配方/包装 3 步）"],
        "do_not_do": "不与 1600472561736 直接竞价降 $2.8（会自伤利润）",
        "validation_metric": "CTR / 点击 / 询盘（标题更换后完整自然周）",
        "validation_period": "1 个完整自然周",
        "confidence": "medium",
        "listing_read": 1,
    },
    {
        "product_id": "1601719605709",
        "title": "LIFEWORTH Customizable Caffeine Pouch Powder - With Nootropic Ingredients and Natural Flavors - OEM Bulk FOB China",
        "tier": "爆品",
        "why_selected": "官方爆品；W1 GMV $158 为 8 候选最高（订单 2），但询盘 0 → 有直接成交却无询盘转化路径，成长天花板明显",
        "current_problem": "GMV 最高但询盘 0、TM 仅 1；流量平稳（coc_show +16.2%）但商机链路断裂",
        "data_evidence": "W1: 搜索曝光 416, 点击 9, CTR 2.16%, 询盘 0, TM 1, 订单 2, GMV $158; coc_show +16.2%; 价格 $1.85-1.99, MOQ 2000 pcs; 认证 HALAL/HACCP/FSC",
        "self_history": "曝光温和增长",
        "peer_gap": "订单/曝光转化 0.48% 尚可，但询盘为 0 说明 B2B 询盘路径未被引导",
        "buyer_intent": "Caffeine Pouch 新兴品类，买家（品牌商/分销商）需定制参数（口味/咖啡因 mg/包装形式）",
        "listing_gap": "详情页未提供定制参数表（可选口味/规格/logo 位置）；B2B 询盘引导弱",
        "root_cause": "详情页缺少 B2B 定制参数与询盘转化模块，直接把买家推向直接下单而非建立商机关系",
        "primary_action": "detail_b2b_section（One Variable: 详情页 B2B 询盘转化模块）",
        "detail_modules": "① 'Customization Menu' 表格: 咖啡因含量(0/50/100/200mg)、口味(天然/无味/果味)、包装(袋/罐/盒)、logo 工艺 ② OEM 流程 4 步图 ③ 认证栏 HALAL/HACCP/FSC ④ 底部 'Request Quote' CTA",
        "secondary_actions": ["属性补 'Customized Support: OEM/ODM' 与 'Main Ingredient: Caffeine + Nootropics'"],
        "do_not_do": "不动 MOQ 2000（定制产线经济性）",
        "validation_metric": "询盘数 / TM 数（详情模块上线后完整自然周）",
        "validation_period": "1 个完整自然周",
        "confidence": "medium",
        "listing_read": 1,
    },
    {
        "product_id": "1601476000834",
        "title": "LIFEWORTH Rehydration Electrolytes Recovery Powder High Strength Vitamin C, B1, B3, B5, B12 Supplement Sachet Drink Potassium",
        "tier": "爆品",
        "why_selected": "官方爆品；CTR 3.72% 为候选最高（点击力强）、累计售出 1130、EU&UK 人气榜 #7，但 W1 零询盘零订单 + 曝光同比 -22.7% → 强点击弱转化",
        "current_problem": "高 CTR 未转化为询盘（0）；曝光/点击同比双降（-22.7%/-35.7%）",
        "data_evidence": "W1: 搜索曝光 242, 点击 9, CTR 3.72%, 询盘 0, 订单 0, TM 6; coc_show -22.7%, coc_click -35.7%; 价格 €2.42-2.77, MOQ 500 boxes; 认证 ISO22000/HACCP/GMP/HALAL/MSDS/COA",
        "self_history": "曝光/点击 4 周下行",
        "peer_gap": "点击力强（CTR 3.72% >> 店均 1.69%）但询盘 0 → 卡在详情转化层",
        "buyer_intent": "EU/UK 市场（#7 人气榜）对电解质品类的合规/认证敏感；TM 6 说明咨询活跃但未沉淀询盘",
        "listing_gap": "详情页缺欧盟合规展示（欧盟市场认证说明）、OEM 案例与询盘 CTA；TM 咨询 6 次未引导转询盘",
        "root_cause": "详情页转化要素缺失 + TM 咨询未承接为询盘（客服响应短板放大）",
        "primary_action": "detail_conversion（One Variable: 详情页询盘转化模块）",
        "detail_modules": "① 欧盟合规/认证区（ISO22000/HACCP/GMP/HALAL + EU 适用说明）② 'Private Label 案例' 模块（品牌定制流程）③ 询盘 CTA 强化（'Get EU Market Quote'）④ FAQ: MOQ/样品/交期",
        "secondary_actions": ["客服话术: TM 咨询 24h 内引导发起询盘（与客服优化联动）"],
        "do_not_do": "不动价格 €2.42-2.77（EU 市场已具竞争力）",
        "validation_metric": "询盘数 / TM→询盘转化 / 曝光环比（详情改版后完整自然周）",
        "validation_period": "1 个完整自然周",
        "confidence": "medium",
        "listing_read": 1,
    },
    {
        "product_id": "1601829634947",
        "title": "LIFEWORTH Collagen Peptides Ashwagandha Powder Zero Sugar Custom OEM ODM Private Label Manufacturer Sleep Aid",
        "tier": "优品",
        "why_selected": "官方诊断定价优化清单（三周前任务）指定产品；优品但 W1 询盘 0、订单 0，流量低",
        "current_problem": "流量与点击双低（曝光 189/点击 3）；官方判定定价待优化",
        "data_evidence": "W1: 搜索曝光 189(coc +27.7%), 点击 3, CTR 1.59%, 询盘 0, 订单 0; 价格 €3.29-3.63, MOQ 10000 sachets/670 bags; 属性: 毛发生长/睡眠/免疫; 累计售出 308",
        "self_history": "曝光小幅回升但点击未跟上",
        "peer_gap": "店级询盘转化正常，本品为低流量低转化尾部优品",
        "buyer_intent": "胶原蛋白+Ashwagandha 复合粉买家（品牌商）关注配方差异化与 MOQ 灵活性",
        "listing_gap": "MOQ 670 bags 偏高（同类品 500 常见）；草莓口味单一；'Form: Powder Capsule Gummies Liquid' 属性表述含混",
        "root_cause": "官方定价判定 + MOQ 与属性表述削弱试单意愿",
        "primary_action": "price_optimize（One Variable: 定价/MOQ 阶梯，官方任务）",
        "recommended_change": "按官方诊断执行定价优化（自动定价工具建议档位）；将 MOQ 表述拆分为 '10000 sachets / 670 bags' 双档并增加试单说明；修正 Form 属性为 'Powder'",
        "secondary_actions": ["补 'Sleep Aid'/'Collagen Ashwagandha' 关键词", "详情页突出睡眠/毛发双功效证据（成分表）"],
        "do_not_do": "不虚构临床功效文案（仅用官方属性词: 睡眠支持/毛发生长/免疫支持）",
        "validation_metric": "询盘 / 订单 / CVR（定价调整后完整自然周）",
        "validation_period": "1 个完整自然周",
        "confidence": "high（官方任务背书）",
        "listing_read": 1,
    },
    {
        "product_id": "1601427218194",
        "title": "LIFEWORTH Mental Performance System: 200mg Plant-Derived Caffeine & Nootropic Matrix for Optimal Cognitive Function",
        "tier": "优品",
        "why_selected": "官方诊断定价优化清单#1（近 7 天任务）；搜索曝光同比 +98.3% 大涨但点击仅 2 → 曝光增长完全未转化为点击",
        "current_problem": "CTR 1.12% 为候选最低；曝光翻倍点击停滞 → 首屏信息（主图/标题）无法承接新流量",
        "data_evidence": "W1: 搜索曝光 179(coc +98.3%), 点击 2, CTR 1.12%, 询盘 0, 订单 0, GMV $0; 价格 $1.85-1.99, MOQ 2000 pcs",
        "self_history": "曝光暴涨期（+98%），点击转化率极低",
        "peer_gap": "CTR 1.12% << 店均 1.69%，点击力明显不足",
        "buyer_intent": "Nootropic/认知功能品类买家为专业经销商与品牌商，需快速识别成分矩阵",
        "listing_gap": "标题过长（30+ 词）且主词 'Mental Performance System' 非搜索热词；'200mg Plant-Derived Caffeine' 卖点未在首屏强调",
        "root_cause": "曝光暴涨（官方流量分配）与 CTR 极低并存 → 主图/标题与买家预期错配",
        "primary_action": "main_image（One Variable: 主图）+ 标题简化",
        "image_brief": "主图 Creative Brief: ① 深色科技感背景 + 产品罐体特写 ② 左上角 '200mg Caffeine' 黄色徽章 ③ 右侧成分矩阵图标（Caffeine/L-Theanine/B12）④ 底部 'Nootropic Focus Matrix' 字样 ⑤ 保持 800x800+",
        "candidate_titles": [
            "LIFEWORTH 200mg Caffeine Nootropic Focus Powder - L-Theanine B12 Mental Performance OEM Private Label",
            "Nootropic Pre Workout Focus Powder 200mg Plant Caffeine L-Theanine - Bulk OEM ODM Custom Formula",
            "Caffeine Nootropic Matrix Powder - 200mg Focus & Energy, Private Label Bulk Manufacturer GMP"
        ],
        "secondary_actions": ["官方定价优化清单联动执行"],
        "do_not_do": "不删除 'Mental Performance' 品牌词（保留品牌资产）",
        "validation_metric": "CTR / 点击 / 询盘（主图+标题后完整自然周）",
        "validation_period": "1 个完整自然周",
        "confidence": "medium",
        "listing_read": 1,
    },
]


def main() -> int:
    conn = sqlite3.connect(str(DB))
    try:
        for p in PLANS:
            listing_read = p.pop("listing_read")
            # product_optimizations
            cur = conn.execute(
                """INSERT INTO product_optimizations
                   (product_id, title, why_selected, current_problem, data_evidence,
                    self_history, peer_gap, buyer_intent, listing_gap, root_cause,
                    primary_action, secondary_actions, do_not_do, validation_metric,
                    validation_period, candidate_titles, image_brief, attributes_gap,
                    detail_modules, ai_inference, confidence, listing_read)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)""",
                (p["product_id"], p["title"], p["why_selected"], p["current_problem"],
                 p["data_evidence"], p["self_history"], p["peer_gap"], p["buyer_intent"],
                 p["listing_gap"], p["root_cause"], p["primary_action"],
                 json.dumps(p.get("secondary_actions", []), ensure_ascii=False),
                 p["do_not_do"], p["validation_metric"], p["validation_period"],
                 json.dumps(p.get("candidate_titles", []), ensure_ascii=False),
                 p.get("image_brief", ""),
                 json.dumps(p.get("attributes_gap", []), ensure_ascii=False),
                 json.dumps(p.get("detail_modules", []), ensure_ascii=False),
                 p["confidence"], listing_read),
            )
            opt_id = cur.lastrowid
            # diagnosis_actions（One Variable Test: 每个产品仅一个 Primary Variable）
            conn.execute(
                """INSERT INTO diagnosis_actions
                   (product_id, action_type, primary_variable, description, data_evidence,
                    before_snapshot, recommended_change, validation_metric,
                    validation_period_days, ai_inference, confidence, status, source)
                   VALUES (?,?,?,?,?,?,?,?,?,1,?, 'suggested', 'stage_b_optimizer_v1')""",
                (p["product_id"], p["primary_action"].split("(")[0].strip(),
                 p["primary_action"], p["current_problem"],
                 p["data_evidence"], p["title"],
                 p.get("recommended_change", p.get("candidate_titles", [""])[0] if p.get("candidate_titles") else ""),
                 p["validation_metric"], 7, p["confidence"]),
            )
        conn.commit()
        n_opt = conn.execute("SELECT COUNT(*) FROM product_optimizations").fetchone()[0]
        n_act = conn.execute("SELECT COUNT(*) FROM diagnosis_actions").fetchone()[0]
        print(f"product_optimizations: {n_opt} | diagnosis_actions: {n_act}")
        for p in PLANS:
            print(f"  - {p['product_id']}: {p['primary_action']} | conf={p['confidence']}")
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
