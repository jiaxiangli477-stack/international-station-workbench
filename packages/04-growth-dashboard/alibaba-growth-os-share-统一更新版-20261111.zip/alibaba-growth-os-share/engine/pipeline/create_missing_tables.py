# -*- coding: utf-8 -*-
"""创建 pipeline 依赖但尚未由 stage_b 创建的 5 张表（空表）"""
import sqlite3
DB = 'database/alibaba_growth.db'
DDL = """
CREATE TABLE IF NOT EXISTS competitor_stores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_name TEXT NOT NULL UNIQUE, store_url TEXT, main_category TEXT,
    years_on_alibaba INTEGER, rating REAL, rating_count INTEGER,
    response_time TEXT, on_time_rate TEXT, reorder_rate TEXT,
    verified_by TEXT, online_revenue TEXT, year_founded INTEGER,
    floorspace TEXT, main_markets TEXT, positioning TEXT,
    source TEXT, snapshot_date TEXT, snapshot_type TEXT DEFAULT 'BASELINE'
);
CREATE TABLE IF NOT EXISTS competitor_products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    store_id INTEGER REFERENCES competitor_stores(id),
    product_id TEXT, title TEXT, product_url TEXT,
    price_range TEXT, moq TEXT, sold INTEGER, rank TEXT,
    certifications TEXT, oem_odm INTEGER, private_label INTEGER,
    lead_time TEXT, customization TEXT,
    match_our_product TEXT, match_reason TEXT, relevance REAL, observed_gap TEXT,
    source TEXT, snapshot_date TEXT, snapshot_type TEXT DEFAULT 'BASELINE'
);
CREATE TABLE IF NOT EXISTS operator_decisions (
    period TEXT PRIMARY KEY,
    decision_json TEXT,
    generated_at TEXT
);
CREATE TABLE IF NOT EXISTS cs_staff_weekly (
    week_end TEXT NOT NULL, week_start TEXT, snap_date TEXT, full_name TEXT,
    reply_rate REAL, fst5min_reply_rate REAL, avg_reply_time REAL,
    fb_pv INTEGER, fb_uv INTEGER, uv_fb_atm INTEGER, rcvd_amt REAL,
    prepay_ord INTEGER, drawup_ord INTEGER, bus_to_ord_rate REAL,
    avatar TEXT, raw_json TEXT,
    PRIMARY KEY (week_end, full_name)
);
CREATE TABLE IF NOT EXISTS cs_chat_quality (
    id INTEGER PRIMARY KEY AUTOINCREMENT, stats_date TEXT, full_name TEXT,
    login_id TEXT, buyer_level TEXT, l3l4_buyer INTEGER, reply_over12h INTEGER,
    not_follow INTEGER, buyer_rnr INTEGER, only_hi INTEGER, evaluate_unsatisfied INTEGER,
    msg_content TEXT, raw_json TEXT
);
"""
c = sqlite3.connect(DB)
c.executescript(DDL)
c.commit()
tabs = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")]
for t in ["competitor_stores","competitor_products","operator_decisions","cs_staff_weekly","cs_chat_quality"]:
    print(t, "OK" if t in tabs else "MISSING")
c.close()
