# -*- coding: utf-8 -*-
"""导出全部 680 品图片清单，按 4 批拆分，URL 升级到 640"""
import sqlite3, json, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
c = sqlite3.connect('database/alibaba_growth.db')
c.row_factory = sqlite3.Row
cur = c.cursor()
cur.execute("SELECT product_id, main_image, title FROM products WHERE main_image LIKE 'http%' ORDER BY product_id")
rows = [dict(r) for r in cur.fetchall()]

def up640(u):
    for old in ('_100x100','_300x300','_500x500'):
        if old in u:
            return u.replace(old, '_640x640')
    if u.endswith('.jpg'): return u[:-4] + '_640x640.jpg'
    if u.endswith('.png'): return u[:-4] + '_640x640.png'
    if u.endswith('.JPG'): return u[:-4] + '_640x640.jpg'
    return u + '.jpg_640x640.jpg'

items = []
for r in rows:
    items.append({"pid": str(r['product_id']), "img": up640(r['main_image']), "title": (r['title'] or '')[:60]})

BATCH = 170
batches = [items[i:i+BATCH] for i in range(0, len(items), BATCH)]
for i, b in enumerate(batches):
    with open('raw/vision_batch_%d.json' % i, 'w', encoding='utf-8') as f:
        json.dump(b, f, ensure_ascii=False)
    print("批 %d: %d 个产品" % (i, len(b)))
print("总计 %d 个产品，分 %d 批" % (len(items), len(batches)))
