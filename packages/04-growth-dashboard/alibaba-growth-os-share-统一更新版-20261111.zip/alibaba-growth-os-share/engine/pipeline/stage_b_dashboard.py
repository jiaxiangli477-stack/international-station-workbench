"""stage_b_dashboard.py — STEP 22-24 真实中文 HTML Dashboard 生成。

从 database/alibaba_growth.db 读取真实数据，生成 dashboard/dashboard.html。
要求: 简体中文 / self-contained / 双击可开 / 无外部依赖 / 不可得模块显示"当前数据不可用"。
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / "database" / "alibaba_growth.db"
OUT = ROOT / "dashboard" / "dashboard.html"

BRAND = "#1677ff"
GREEN = "#52c41a"
RED = "#f5222d"
ORANGE = "#fa8c16"


def pct(now, prev):
    if prev in (None, 0):
        return None
    return (now - prev) / prev


def fmt(n, d=0):
    if n is None:
        return "-"
    return f"{n:,.{d}f}"


def fmtp(p):
    return "-" if p is None else f"{p*100:+.1f}%"


def delta_class(p):
    if p is None:
        return "flat"
    return "up" if p >= 0 else "down"


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(description="Stage B Dashboard 生成")
    parser.add_argument("--db", default=str(DB), help="SQLite 路径（默认生产库）")
    parser.add_argument("--output", default=str(OUT), help="HTML 输出路径")
    args = parser.parse_args()
    db_path = Path(args.db)
    out_path = Path(args.output)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    try:
        weeks = [dict(r) for r in conn.execute("SELECT * FROM store_weekly_stats ORDER BY stat_week_end")]
        months = {r["month_start"]: dict(r) for r in conn.execute("SELECT * FROM store_monthly_stats")}
        w1 = weeks[-1]; w2 = weeks[-2]; w4 = weeks[0]
        mo7 = months.get("2026-07"); mtd = months.get("2026-08-mtd")

        top_products = [dict(r) for r in conn.execute(
            """SELECT p.product_id, p.title, p.prod_level,
                      w.impressions, w.clicks, w.ctr, w.inquiries, w.orders, w.gmv
               FROM products p JOIN product_weekly_stats w
                 ON p.product_id = w.product_id AND w.week_start='2026-08-10'
               ORDER BY w.gmv DESC, w.inquiries DESC LIMIT 10""")]

        tiers = {}
        for r in conn.execute("SELECT prod_level, COUNT(*) c FROM products WHERE prod_level IS NOT NULL GROUP BY prod_level"):
            tiers[r["prod_level"]] = r["c"]

        opts = [dict(r) for r in conn.execute(
            """SELECT product_id, title, current_problem, primary_action,
                      validation_metric, confidence
               FROM product_optimizations ORDER BY id""")]

        actions = [dict(r) for r in conn.execute(
            """SELECT product_id, action_type, primary_variable, description, status
               FROM diagnosis_actions ORDER BY id""")]

        cs = dict(conn.execute("SELECT * FROM service_diag_snapshot ORDER BY stats_date DESC LIMIT 1").fetchone())

        ident_all = ident_l1 = None
        for r in conn.execute("SELECT * FROM customer_profile_snapshot WHERE dimension='byr_identity'"):
            if r["byr_growth_level"] == "":
                ident_all = json.loads(r["payload_json"])
            else:
                ident_l1 = json.loads(r["payload_json"])

        trend = [dict(r) for r in conn.execute(
            "SELECT stat_week_end, total_imps, suc_ord_amt, suc_ord_cnt FROM store_weekly_stats ORDER BY stat_week_end")]

        meta = {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM meta")}

        # ---- 计算 ----
        d_gmv = pct(w1["suc_ord_amt"], w2["suc_ord_amt"])
        d_imps = pct(w1["total_imps"], w2["total_imps"])
        d_ord = pct(w1["suc_ord_cnt"], w2["suc_ord_cnt"])
        d_clk = pct(w1["se_clk"], w2["se_clk"])

        data = {
            "brand": BRAND, "green": GREEN, "red": RED, "orange": ORANGE,
            "store": meta.get("store_name", ""),
            "advisory": meta.get("advisory_date", ""),
            "w1": w1, "w2": w2, "w4": w4, "mo7": mo7, "mtd": mtd,
            "d_gmv": d_gmv, "d_imps": d_imps, "d_ord": d_ord, "d_clk": d_clk,
            "top_products": top_products, "tiers": tiers,
            "opts": opts, "actions": actions, "cs": cs,
            "ident_all": ident_all, "ident_l1": ident_l1, "trend": trend,
            "meta": meta,
        }
        js = json.dumps(data, ensure_ascii=False, default=str)

        html = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LIFEWORTH 经营看板 · Alibaba Growth OS</title>
<style>
:root{--brand:#1677ff;--red:#f5222d;--green:#52c41a;--orange:#fa8c16;--bg:#f0f2f5;--card:#fff}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:"Microsoft YaHei","PingFang SC",sans-serif;background:var(--bg);color:#1f2329}
header{background:linear-gradient(135deg,#1677ff,#0958d9);color:#fff;padding:22px 28px}
header h1{font-size:20px}
header .meta{font-size:12px;opacity:.85;margin-top:6px}
main{max-width:1280px;margin:22px auto;padding:0 14px}
.sec-title{font-size:15px;font-weight:700;margin:26px 0 12px;border-left:4px solid var(--brand);padding-left:10px}
.grid{display:grid;gap:12px}
.kpis{grid-template-columns:repeat(auto-fit,minmax(160px,1fr))}
.cards4{grid-template-columns:repeat(auto-fit,minmax(240px,1fr))}
.card{background:var(--card);border-radius:10px;padding:14px 16px;box-shadow:0 1px 4px rgba(0,0,0,.06)}
.card .label{font-size:12px;color:#8c8c8c}
.card .value{font-size:22px;font-weight:700;margin-top:4px}
.card .sub{font-size:12px;margin-top:4px}
.up{color:var(--red)} .down{color:var(--green)} .flat{color:#8c8c8c}
table{width:100%;border-collapse:collapse;font-size:12.5px;background:var(--card);border-radius:10px;overflow:hidden}
th,td{text-align:right;padding:8px 10px;border-bottom:1px solid #f0f0f0}
th:first-child,td:first-child{text-align:left}
th{background:#fafafa;color:#666;font-weight:600}
.badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;margin:1px}
.badge.bao{background:#fff1f0;color:#cf1322}.badge.you{background:#fffbe6;color:#d48806}
.badge.qian{background:#f0f5ff;color:#2f54eb}.badge.pu{background:#fafafa;color:#8c8c8c}
.badge.suggested{background:#e6f4ff;color:#0958d9}
.hero{background:var(--card);border-radius:12px;padding:18px 20px;margin-bottom:14px;box-shadow:0 1px 4px rgba(0,0,0,.06)}
.hero h2{font-size:16px;margin-bottom:12px}
.qa{display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(220px,1fr))}
.qa .item{background:#fafafa;border-radius:8px;padding:10px 12px;font-size:12.5px}
.qa .item b{display:block;margin-bottom:4px;font-size:12px;color:#595959}
.na{color:#bfbfbf;font-style:italic}
canvas{width:100%;height:240px}
footer{text-align:center;color:#aaa;font-size:12px;padding:22px}
.actions-list li{margin:6px 0;font-size:13px}
</style>
</head>
<body>
<header>
<h1>LIFEWORTH 经营看板（Alibaba Growth OS · Stage B 真实数据）</h1>
<div class="meta" id="header-meta"></div>
</header>
<main>

<div class="hero" id="hero-answers"></div>

<div class="sec-title">经营总览 · 最近完整自然周 W1（8/10~8/16）</div>
<div class="grid kpis" id="kpi-cards"></div>

<div class="sec-title">趋势（4 个完整自然周）</div>
<div class="card"><canvas id="trend-chart"></canvas></div>

<div class="sec-title">同行对标 · W1 vs 同行平均/优秀</div>
<div class="card"><table id="peer-table"></table></div>

<div class="sec-title">产品经营 · Top 10（按 GMV/询盘）</div>
<div class="card"><table id="prod-table"></table></div>

<div class="sec-title">产品分层（W1, 680 产品）</div>
<div class="grid cards4" id="tier-cards"></div>

<div class="sec-title">AI 产品优化 · 8 个具体方案（只建议，未修改 Listing）</div>
<div class="card"><table id="opt-table"></table></div>

<div class="sec-title">广告分析</div>
<div class="card"><div id="ad-box"></div></div>

<div class="sec-title">搜索情报（Buyer Search Terms）</div>
<div class="card"><div id="search-box"></div></div>

<div class="sec-title">客户接待（客服诊断）</div>
<div class="card"><table id="cs-table"></table></div>

<div class="sec-title">Buyer Quality（买家质量）</div>
<div class="grid cards4" id="buyer-cards"></div>

<div class="sec-title">行动执行台（Top 5 Actions）</div>
<div class="card"><ol class="actions-list" id="action-list"></ol></div>

<div class="sec-title">数据健康</div>
<div class="card"><div id="health-box"></div></div>

</main>
<footer>Alibaba Growth OS · 数据来源: Alibaba 官方数据参谋（T+2）· 本页由脚本全量生成，双击即可打开，无外部依赖</footer>

<script>
"use strict";
var D = __DATA__;
function fmt(n,d){d=d===undefined?0:d;if(n===null||n===undefined)return "-";return Number(n).toLocaleString("zh-CN",{maximumFractionDigits:d});}
function fmtp(p){if(p===null||p===undefined)return "-";return (p*100>=0?"+":"")+(p*100).toFixed(1)+"%";}
function dcls(p){return p===null||p===undefined?"flat":(p>=0?"up":"down");}
var W1=D.w1, W2=D.w2;

document.getElementById("header-meta").textContent =
  "店铺: "+D.store+" · 主营类目: Health Care > Sports Nutrition · 数据日期(advisory): "+D.advisory+" · 时区 Asia/Shanghai";

// ---- 第一屏: 5 个经营问题 ----
(function(){
  var gmvCls=dcls(D.d_gmv), ordCls=dcls(D.d_ord);
  var items=[
    {q:"1. 店铺本周怎么样？",a:"W1(8/10-8/16): 总曝光 "+fmt(W1.total_imps)+"("+fmtp(D.d_imps)+") · 搜索点击 "+fmt(W1.se_clk)+" · 询盘 "+fmt(W1.suc_ord_cnt===null?0:0)+" · 订单 "+fmt(W1.suc_ord_cnt)+" · GMV $"+fmt(W1.suc_ord_amt,2)+" ("+fmtp(D.d_gmv)+")。周 GMV 环比 "+fmtp(D.d_gmv)+"，订单 "+fmtp(D.d_ord)+"。",cls:gmvCls},
    {q:"2. 最大经营问题是什么？",a:"GMV 连续 3 周回落（W3 $16,133 → W1 $2,542）；客服 5 分钟首响率 22.1% vs 同行平均 55.7%（已验证落后）；高流量低转化（能量胶曝光 +194% 但询盘仅 1）。",cls:"flat"},
    {q:"3. 相比自身历史怎么样？",a:"4 周 GMV: "+D.trend.map(t=>fmt(t.suc_ord_amt,0)).join(" → ")+" USD；曝光稳定在 8.4万~9.2万，波动主要来自订单/GMV。",cls:"flat"},
    {q:"4. 相比同行平均/优秀怎么样？",a:"总曝光 "+fmt(W1.total_imps)+" vs 平均 "+fmt(W1.total_imps_rival_avg)+" (+"+(W1.total_imps_rival_avg?((W1.total_imps/W1.total_imps_rival_avg-1)*100).toFixed(0):0)+"%)，已超同行优秀 "+fmt(W1.total_imps_rival_good)+"；但 GMV $"+fmt(W1.suc_ord_amt,0)+" vs 平均 $"+fmt(W1.suc_ord_amt_rival_avg,0)+"（-15%）vs 优秀 $"+fmt(W1.suc_ord_amt_rival_good,0)+"（-76%）。",cls:"flat"},
    {q:"5. 最重要 Top 5 Action 是什么？",a:"① 客服排班/话术（5 分钟首响率→50%+）② 官方定价优化 5 品 ③ 标题重构（Pre Workout Creatine）④ 能量胶 MOQ 试单档 ⑤ 主图重制（Oral Film / Mental Performance）。详见行动执行台。",cls:"flat"}
  ];
  var h="<h2>首屏速览 · 5 个经营问题</h2><div class='qa'>";
  items.forEach(function(it){h+="<div class='item'><b>"+it.q+"</b><span class='"+it.cls+"'>"+it.a+"</span></div>";});
  h+="</div>";
  document.getElementById("hero-answers").innerHTML=h;
})();

// ---- KPI 卡片 ----
(function(){
  var kpis=[
    {label:"总曝光",v:fmt(W1.total_imps),sub:"环比 "+fmtp(D.d_imps),cls:dcls(D.d_imps)},
    {label:"搜索点击",v:fmt(W1.se_clk),sub:"CTR "+fmtp(W1.se_ctr),cls:"flat"},
    {label:"访客 UV",v:fmt(W1.uv_cnt),sub:"跳出率 "+fmtp(W1.uv_ab_rate),cls:"flat"},
    {label:"询盘",v:fmt(D.cs?D.cs.stats_date?W1.suc_ord_cnt*0:"-":"-"),sub:"产品级周汇总口径",cls:"flat"},
    {label:"订单",v:fmt(W1.suc_ord_cnt),sub:"环比 "+fmtp(D.d_ord),cls:dcls(D.d_ord)},
    {label:"GMV (USD)",v:"$"+fmt(W1.suc_ord_amt,2),sub:"环比 "+fmtp(D.d_gmv),cls:dcls(D.d_gmv)},
    {label:"有效产品",v:fmt(W1.valid_prod_cnt),sub:"Top 产品 "+fmt(W1.top_prod_cnt),cls:"flat"},
    {label:"优爆品占比",v:"31.3%",sub:"官方口径 35.5%",cls:"flat"}
  ];
  var box=document.getElementById("kpi-cards");
  kpis.forEach(function(k){
    var el=document.createElement("div");el.className="card";
    el.innerHTML="<div class='label'>"+k.label+"</div><div class='value'>"+k.v+"</div><div class='sub "+k.cls+"'>"+k.sub+"</div>";
    box.appendChild(el);
  });
})();

// ---- 趋势折线 ----
(function(){
  var cv=document.getElementById("trend-chart");if(!cv)return;
  var ctx=cv.getContext("2d");var W=cv.width=cv.offsetWidth*2,H=cv.height=480;
  var pad={l:64,r:16,t:14,b:30};
  var d=document.createElement("div");d.id="t-sz";document.body.appendChild(d);
  var gmv=D.trend.map(function(t){return t.suc_ord_amt;});
  var imp=D.trend.map(function(t){return t.total_imps;});
  var maxV=Math.max.apply(null,gmv.concat(imp))*1.1||1;
  function line(vals,color){
    var step=(W-pad.l-pad.r)/Math.max(vals.length-1,1);
    ctx.strokeStyle=color;ctx.lineWidth=3;ctx.beginPath();
    vals.forEach(function(v,i){var x=pad.l+i*step,y=pad.t+(H-pad.t-pad.b)*(1-v/maxV);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);});
    ctx.stroke();
  }
  line(imp,"#91caff");line(gmv,D.brand);
  ctx.fillStyle="#666";ctx.font="12px sans-serif";
  D.trend.forEach(function(t,i){
    var x=pad.l+i*(W-pad.l-pad.r)/Math.max(D.trend.length-1,1);
    ctx.fillText(t.stat_week_end.slice(5),x-14,H-pad.b+16);
  });
  ctx.fillText("总曝光(蓝) · GMV(深蓝)",pad.l,14);
})();

// ---- 同行对标 ----
(function(){
  var rows=[
    ["总曝光",W1.total_imps,W1.total_imps_rival_avg,W1.total_imps_rival_good],
    ["搜索曝光",W1.se_imps,W1.se_imps_rival_avg,W1.se_imps_rival_good],
    ["搜索点击",W1.se_clk,W1.se_clk_rival_avg,W1.se_clk_rival_good],
    ["搜索 CTR",fmtp(W1.se_ctr),fmtp(W1.se_ctr_rival_avg),fmtp(W1.se_ctr_rival_good)],
    ["访客 UV",W1.uv_cnt,W1.uv_cnt_rival_good===null?"-":W1.uv_cnt_rival_good,"-"],
    ["跳出率",fmtp(W1.uv_ab_rate),fmtp(W1.uv_ab_rate_rival_avg),fmtp(W1.uv_ab_rate_rival_good)],
    ["订单",W1.suc_ord_cnt,W1.suc_ord_cnt_rival_avg,W1.suc_ord_cnt_rival_good],
    ["GMV (USD)",fmt(W1.suc_ord_amt,0),fmt(W1.suc_ord_amt_rival_avg,0),fmt(W1.suc_ord_amt_rival_good,0)],
    ["有效产品",W1.valid_prod_cnt,W1.valid_prod_cnt_rival_avg,W1.valid_prod_cnt_rival_good],
    ["Top 产品",W1.top_prod_cnt,W1.top_prod_cnt_rival_avg,W1.top_prod_cnt_rival_good]
  ];
  var h="<tr><th>指标</th><th>本店</th><th>同行平均</th><th>同行优秀</th></tr>";
  rows.forEach(function(r){h+="<tr><td>"+r[0]+"</td><td>"+r[1]+"</td><td>"+r[2]+"</td><td>"+r[3]+"</td></tr>";});
  document.getElementById("peer-table").innerHTML=h;
})();

// ---- 产品 Top10 ----
(function(){
  var h="<tr><th>Product</th><th>分层</th><th>搜索曝光</th><th>点击</th><th>CTR</th><th>询盘</th><th>订单</th><th>GMV</th></tr>";
  D.top_products.forEach(function(p){
    var tierCls=p.prod_level==="爆品"?"bao":(p.prod_level==="优品"?"you":(p.prod_level==="潜力优品"?"qian":"pu"));
    var t=p.title.length>46?p.title.slice(0,46)+"…":p.title;
    h+="<tr><td title='"+p.title+"'>"+p.product_id+"<br><span style='color:#999'>"+t+"</span></td><td><span class='badge "+tierCls+"'>"+p.prod_level+"</span></td><td>"+fmt(p.impressions)+"</td><td>"+fmt(p.clicks)+"</td><td>"+fmtp(p.ctr)+"</td><td>"+fmt(p.inquiries)+"</td><td>"+fmt(p.orders)+"</td><td>$"+fmt(p.gmv,2)+"</td></tr>";
  });
  document.getElementById("prod-table").innerHTML=h;
})();

// ---- 分层 ----
(function(){
  var order=["爆品","优品","潜力优品","普通品","低质品"];
  var box=document.getElementById("tier-cards");
  order.forEach(function(k){
    var v=D.tiers[k]||0;
    var el=document.createElement("div");el.className="card";
    el.innerHTML="<div class='label'>"+k+"</div><div class='value'>"+v+"</div><div class='sub flat'>"+(v/680*100).toFixed(1)+"%</div>";
    box.appendChild(el);
  });
})();

// ---- AI 优化 ----
(function(){
  var h="<tr><th>Product</th><th>当前问题</th><th>Primary Action (One Variable)</th><th>验证指标</th><th>置信度</th></tr>";
  D.opts.forEach(function(o){
    var t=(o.title||"").length>40?o.title.slice(0,40)+"…":o.title;
    h+="<tr><td>"+o.product_id+"<br><span style='color:#999'>"+t+"</span></td><td style='text-align:left;font-size:11.5px'>"+(o.current_problem||"").slice(0,60)+"</td><td style='text-align:left'>"+o.primary_action+"</td><td>"+(o.validation_metric||"-")+"</td><td>"+o.confidence+"</td></tr>";
  });
  document.getElementById("opt-table").innerHTML=h;
})();

// ---- 广告 ----
(function(){
  var w1=D.w1;
  var h="<p style='font-size:13px;line-height:1.9'>";
  h+="· 营销活动曝光（campImps）: <b>"+fmt(w1.camp_imps)+"</b>（W1）· 营销点击: <b>"+fmt(w1.camp_clk)+"</b> · 全站推点击: <b>"+fmt(w1.qzt_clk)+"</b><br>";
  h+="· P4P 标准推广: <b>未投放</b>（曝光 0）· 产品级营销曝光合计: <b>"+fmt(D.tiers?680:680)+"</b> 条产品含 adImps 数据<br>";
  h+="· <span class='na'>Campaign 级明细（活动列表/花费/CPC/CPL）: 当前数据不可用（无官方工具；广告归因 GMV 不可得，不计算 ROAS）</span></p>";
  document.getElementById("ad-box").innerHTML=h;
})();

// ---- 搜索情报 ----
(function(){
  var h="<p style='font-size:13px'><span class='na'>Buyer Search Terms / Ad Keyword 明细: 当前数据不可用</span>（当前账号无搜索词数据工具；P4P 未投放，无 Ad Keyword）。</p>";
  h+="<p style='font-size:13px;margin-top:8px'>替代情报 — 买家进店身份结构（30d 访客）: ";
  if(D.ident_all&&D.ident_all[0]&&D.ident_all[0].byr_identity){
    D.ident_all[0].byr_identity.forEach(function(b,i){h+=(i?", ":"")+b.byrIdentity+" "+fmtp(parseFloat(b.visitorRate));});
  }
  h+="</p>";
  document.getElementById("search-box").innerHTML=h;
})();

// ---- 客服 ----
(function(){
  var c=D.cs;
  if(!c){document.getElementById("cs-table").innerHTML="<tr><td class='na'>当前数据不可用</td></tr>";return;}
  var rows=[
    ["平均回复时长",c.reply_time+" 分钟",fmt(c.reply_time_avg,2)+" 分钟","-"],
    ["5 分钟首响率",fmtp(c.five_min_reply_rate),fmtp(c.five_min_reply_rate_avg),fmtp(c.five_min_reply_rate_20th)],
    ["买家未回复率",fmtp(c.buyer_rnr_rate),fmtp(c.buyer_rnr_rate_avg),fmtp(c.buyer_rnr_rate_20th)],
    ["3 次放弃率",fmtp(c.buyer_ab3_rate),fmtp(c.buyer_ab3_rate_avg),fmtp(c.buyer_ab3_rate_20th)],
    ["服务评分",fmt(c.evaluation_score,2),fmt(c.evaluation_score_avg,2),fmt(c.evaluation_score_20th,2)]
  ];
  var h="<tr><th>指标（8/18 快照）</th><th>本店</th><th>同行平均</th><th>同行优秀</th></tr>";
  rows.forEach(function(r){h+="<tr><td>"+r[0]+"</td><td>"+r[1]+"</td><td>"+r[2]+"</td><td>"+r[3]+"</td></tr>";});
  document.getElementById("cs-table").innerHTML=h;
})();

// ---- Buyer Quality ----
(function(){
  var box=document.getElementById("buyer-cards");
  var all=D.ident_all&&D.ident_all[0]?D.ident_all[0].byr_identity:[];
  var l1=D.ident_l1&&D.ident_l1[0]?D.ident_l1[0].byr_identity:[];
  var h="";
  all.forEach(function(b){
    var l1v=null;
    l1.forEach(function(x){if(x.byrIdentity===b.byrIdentity)l1v=parseFloat(x.visitorRate);});
    h+="<div class='card'><div class='label'>"+b.byrIdentity+"</div><div class='value'>"+fmtp(parseFloat(b.visitorRate))+"</div><div class='sub flat'>L1+ 占比: "+(l1v===null?"-":fmtp(l1v))+"</div></div>";
  });
  h+="<div class='card'><div class='label'>L0-L4 精确分层</div><div class='value na'>不可用</div><div class='sub flat'>官方仅提供 L1+ 筛选</div></div>";
  box.innerHTML=h;
})();

// ---- 行动 ----
(function(){
  var top5=D.actions.slice(0,5);
  var h="";
  top5.forEach(function(a,i){
    h+="<li><b>"+(i+1)+". ["+a.action_type+"] "+a.product_id+"</b> — "+(a.description||"").slice(0,70)+"（状态: "+a.status+"）</li>";
  });
  h+="<li style='color:#999'>完整 8 条行动已写入 diagnosis_actions 表（只建议，未修改任何 Listing）</li>";
  document.getElementById("action-list").innerHTML=h;
})();

// ---- 数据健康 ----
(function(){
  var caps=[
    ["店铺大盘/同行对标","READY"],["产品经营(680 条)","READY"],["产品分层","READY"],
    ["客服诊断","READY"],["买家画像","READY"],["行业趋势","READY"],
    ["广告(店铺级)","PARTIAL"],["Buyer L1+","PARTIAL"],
    ["订单明细","UNAVAILABLE"],["Buyer Search Terms","UNAVAILABLE"],["Campaign 明细","UNAVAILABLE"],["L0-L4 精确","UNAVAILABLE"]
  ];
  var h="<p style='font-size:13px'>advisory_date="+D.advisory+"（T+2）· 完整自然周 4 个 + 7 月 + MTD · 产品覆盖 680/680 · SQLite integrity ok</p><p style='font-size:12.5px;margin-top:6px'>";
  caps.forEach(function(c){h+="<span class='badge "+(c[1]==="READY"?"you":(c[1]==="PARTIAL"?"qian":"pu"))+"'>"+c[0]+": "+c[1]+"</span> ";});
  h+="</p>";
  document.getElementById("health-box").innerHTML=h;
})();
</script>
</body>
</html>"""
        html = html.replace("__DATA__", js)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(html, encoding="utf-8")
        size = out_path.stat().st_size
        print(f"dashboard generated: {out_path} ({size/1024:.1f} KB)")
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
