"""stage_d_migrate.py — Stage D V1.1 表扩展（仅 ADD COLUMN，不重构 Stage B 数据模型）。

diagnosis_actions / product_optimizations 增加人工登记字段；
product_optimizations 增加 deep_plan_json（17 项深度方案）。
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent / "database" / "alibaba_growth.db"

COLUMNS = {
    "diagnosis_actions": [
        ("owner", "TEXT"),
        ("due_date", "TEXT"),
        ("completed_at", "TEXT"),
        ("actual_change", "TEXT"),
        ("notes", "TEXT"),
        ("updated_at", "TEXT"),
    ],
    "product_optimizations": [
        ("status", "TEXT DEFAULT '未处理'"),
        ("owner", "TEXT"),
        ("due_date", "TEXT"),
        ("completed_at", "TEXT"),
        ("actual_change", "TEXT"),
        ("notes", "TEXT"),
        ("updated_at", "TEXT"),
        ("deep_plan_json", "TEXT"),
        ("plan_version", "TEXT DEFAULT 'v1.1'"),
    ],
}


def main() -> int:
    conn = sqlite3.connect(str(DB))
    try:
        for table, cols in COLUMNS.items():
            existing = {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
            for name, ddl in cols:
                if name not in existing:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")
        conn.commit()
        # 验证
        checks = {}
        for table in COLUMNS:
            cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
            checks[table] = sorted(cols)
        print(json.dumps(checks, ensure_ascii=False, indent=1))
        print("MIGRATE_OK")
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
