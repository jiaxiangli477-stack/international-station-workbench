# -*- coding: utf-8 -*-
"""
安全切换店铺：python switch_store.py <目标店铺key> [--no-rebuild]
- 先把当前店铺数据归档到 stores/<current>/（覆盖前先备份）
- 再把目标店铺数据从 stores/<target>/ 恢复到工作区（database/ + raw/ + img_map）
- 同步 load_new_store.py 的店铺常量（STORE_NAME/STORE_ALIID/MAIN_CATEGORY/CATE_ID）
- 更新 stores.json 的 active
- 默认重建看板（v4_judge + v4_build）
用法示例：python switch_store.py yh
"""
import json, shutil, os, re, sys, io, subprocess
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

ROOT = os.path.dirname(os.path.abspath(__file__))
CONF = os.path.join(ROOT, 'stores.json')

def load_conf():
    return json.load(open(CONF, encoding='utf-8'))

def copy_into(src_dir, dst_dir):
    """把 src_dir 下的 database/ raw/ img_map 复制到工作区 dst"""
    for name in ['database', 'raw']:
        s = os.path.join(src_dir, name)
        d = os.path.join(dst_dir, name)
        if os.path.isdir(s):
            if os.path.isdir(d):
                shutil.rmtree(d)
            shutil.copytree(s, d)
    for f in ['img_map.json', 'img_map_fresh.json', 'competitors_finished_raw.json']:
        s = os.path.join(src_dir, f)
        if os.path.exists(s):
            shutil.copy2(s, os.path.join(dst_dir, f))

def sync_constants(store):
    """把 load_new_store.py 里的店铺常量改成目标店铺"""
    p = os.path.join(ROOT, 'load_new_store.py')
    s = open(p, encoding='utf-8').read()
    s = re.sub(r'STORE_NAME = "[^"]*"', f'STORE_NAME = "{store["full_name"]}"', s)
    s = re.sub(r'STORE_ALIID = "[^"]*"', f'STORE_ALIID = "{store["store_id"]}"', s)
    s = re.sub(r'MAIN_CATEGORY = "[^"]*"', f'MAIN_CATEGORY = "Health Care > Healthcare Supplements > {store["category"]}"', s)
    s = re.sub(r'CATE_ID = \d+', f'CATE_ID = {store["cate_id"]}', s)
    open(p, 'w', encoding='utf-8').write(s)
    print(f'  已同步 load_new_store.py 常量: {store["name"]} / {store["store_id"]} / {store["category"]}')

def main():
    if len(sys.argv) < 2:
        print('用法: python switch_store.py <目标店铺key> [--no-rebuild]')
        print('可选店铺:', list(load_conf()['stores'].keys()))
        return
    target = sys.argv[1]
    rebuild = '--no-rebuild' not in sys.argv
    conf = load_conf()
    if target not in conf['stores']:
        print(f'错误：店铺 "{target}" 不在 stores.json 中。可选: {list(conf["stores"].keys())}')
        return
    cur = conf.get('active')
    tgt = conf['stores'][target]

    print(f'=== 切换店铺: {cur} -> {target} ({tgt["name"]}) ===')

    # 1) 备份当前店铺
    if cur and cur in conf['stores']:
        print(f'[1] 备份当前店铺 {cur} → stores/{cur}/')
        copy_into(os.path.join(ROOT), os.path.join(ROOT, 'stores', cur))

    # 2) 恢复目标店铺
    print(f'[2] 恢复目标店铺 {target} → 工作区 (database/ + raw/)')
    copy_into(os.path.join(ROOT, 'stores', target), ROOT)

    # 3) 同步常量
    print('[3] 同步店铺常量')
    sync_constants(tgt)

    # 4) 更新 active
    conf['active'] = target
    json.dump(conf, open(CONF, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print(f'[4] stores.json active -> {target}')

    # 5) 重建（多店看板用 build_all.py，避免覆盖成单店）
    if rebuild:
        print('[5] 重建多店看板数据 (build_all.py)...')
        subprocess.run([sys.executable, 'build_all.py'], cwd=ROOT)
    else:
        print('[5] 跳过重建 (--no-rebuild)')

    print(f'\n✅ 切换完成，当前店铺 = {target} ({tgt["name"]})')

if __name__ == '__main__':
    main()
