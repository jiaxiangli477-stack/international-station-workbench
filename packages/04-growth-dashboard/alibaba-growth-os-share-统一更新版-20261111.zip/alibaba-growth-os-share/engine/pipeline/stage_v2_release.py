"""stage_v2_release.py — 冻结 Alibaba Growth OS V2.0 Beta Release。"""
from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL = ROOT / "alibaba-growth-os"
REL = ROOT / "releases" / "alibaba-growth-os-v2.0-beta"
ZIP_PATH = ROOT / "releases" / "alibaba-growth-os-v2.0-beta.zip"

PRIVATE = ["LIFEWORTH", "莱华仕", "Shenzhen Lifeworth", "1653192276", "1600472561736",
           "1601427218194", "1600546912886", "1601720577533", "1601719605709",
           "1601476000834", "1601829634947", "1601492686064", "1601387052135",
           "1601728673188", "1601618995199", "1601700931444", "1601724696246",
           "60337273387", "1601847167545", "1601361255457", "1601763326911",
           "60852053624", "1600718096240", "1600530523398", "1601386954792", "1600341073560",
           "26845", "64677", "10677.05", "12909.5", "16132.8"]


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    h.update(p.read_bytes())
    return h.hexdigest()


def main() -> int:
    if REL.exists():
        shutil.rmtree(REL)
    REL.mkdir(parents=True)
    files = []
    for p in sorted(SKILL.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc":
            rel = p.relative_to(SKILL)
            dest = REL / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dest)
            files.append(rel.as_posix())
    manifest = {
        "skill_name": "alibaba-growth-os",
        "skill_version": "2.0.0-beta",
        "schema_version": "1.0-stageA+stageB+d1+e+f+v2",
        "release_date": date.today().isoformat(),
        "supersedes": "1.2.0（V1.0/V1.1/V1.1.1/V1.2 均保留）",
        "supported_commands": [
            "SYNC WEEKLY", "SYNC MONTHLY", "OPTIMIZE PRODUCT <id>", "OPTIMIZE TOP PRODUCTS",
            "REBUILD DASHBOARD", "VALIDATE GROWTH OS", "RETRY PERIOD <period>",
            "EXPORT STORE PACKAGE", "IMPORT STORE PACKAGE", "INITIALIZE STORE",
            "IMPORT ACTION UPDATES", "DISCOVER COMPETITORS", "REFRESH MARKET INTELLIGENCE"
        ],
        "v2_features": {
            "product_image": "680/680 产品主图本地缓存(dashboard/assets/products/), file:// 离线显示, 无图 placeholder",
            "product_list_cards": "80×80 主图卡片网格(等级/趋势/商机/GMV/操作), 分页 680 全可达",
            "product_360_tabs": "8 TAB(经营表现/自身历史/同行竞品/买家搜索/广告/Listing体检/AI优化/行动历史), 业务卡片非 JSON",
            "ai_optimizer_brief": "产品卡片 + Product Optimization Brief(标题可复制/主图任务书/详情审计/MOQ 需确认), 无 Action Code 文案",
            "competitor_rebuild": "核心竞品 5 家 + 竞品产品卡 + 差距表(gap 标签) + 值得学习/不应该照搬/本周情报",
            "cockpit_index": "经营驾驶舱(健康 KPI/漏斗/Gap/最大问题/Top Actions), 去六宫格问答",
            "visual_spec": "深蓝主色/绿橙红灰状态色/卡片统一/每页有图片或图表"
        },
        "required_runtime_capabilities": [
            "python3", "Alibaba 官方数据访问(data-advisor MCP)", "config.json(advisory_date)",
            "SQLite", "浏览器(file:// 驾驶舱)", "公开 Alibaba 产品页/官方热品榜(同行与图片)"
        ],
        "optional_runtime_capabilities": ["官方 Excel Export", "supplier_verification_recall"],
        "default_locale": "zh-CN",
        "data_delay_days": 2,
        "week_start": "Monday", "week_end": "Sunday",
        "read_only_default": True,
        "files": {f: sha256(REL / f) for f in files},
        "checksums_algorithm": "SHA-256",
    }
    (REL / "RELEASE_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    leaks = []
    for p in REL.rglob("*"):
        if not p.is_file() or p.name == "RELEASE_MANIFEST.json":
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except Exception:
            continue
        for m in PRIVATE:
            idx = text.find(m)
            if idx >= 0 and "EXAMPLE ONLY" not in text[max(0, idx - 150): idx + 150]:
                leaks.append(f"{p.relative_to(REL)}: {m}")
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(REL.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(REL).as_posix())
    print(json.dumps({
        "release_dir": str(REL), "file_count_incl_manifest": len(files) + 1,
        "zip": str(ZIP_PATH), "zip_size_kb": round(ZIP_PATH.stat().st_size / 1024, 1),
        "private_data_leaks": leaks if leaks else "NONE (PASS)",
    }, ensure_ascii=False, indent=1))
    return 0 if not leaks else 1


if __name__ == "__main__":
    raise SystemExit(main())
