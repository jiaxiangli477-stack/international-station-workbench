"""stage_v3_release.py — 冻结 Alibaba Growth OS V3 Beta Release。"""
from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL = ROOT / "alibaba-growth-os"
REL = ROOT / "releases" / "alibaba-growth-os-v3-beta"
ZIP_PATH = ROOT / "releases" / "alibaba-growth-os-v3-beta.zip"

PRIVATE = ["LIFEWORTH", "莱华仕", "1653192276", "1600472561736", "1601427218194",
           "1601387052135", "1601728673188", "1601618995199", "1601700931444",
           "1601724696246", "60337273387", "1601847167545", "1601361255457",
           "1601763326911", "60852053624", "1600718096240", "1600530523398",
           "1601386954792", "1600341073560", "26845", "64677", "10677.05", "12909.5", "16132.8"]


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main() -> int:
    if REL.exists():
        shutil.rmtree(REL)
    REL.mkdir(parents=True)
    files = []
    for p in sorted(SKILL.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc":
            rel = p.relative_to(SKILL)
            dest = REL / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dest)
            files.append(rel.as_posix())
    manifest = {
        "skill_name": "alibaba-growth-os",
        "skill_version": "3.0.0-beta",
        "schema_version": "1.0-stageA+stageB+d1+e+f+v2+v2.1+v3",
        "release_date": date.today().isoformat(),
        "supersedes": "2.1.0-beta（V1.0-V2.1 均保留）",
        "supported_commands": [
            "SYNC WEEKLY", "SYNC MONTHLY", "OPTIMIZE PRODUCT <id>", "OPTIMIZE TOP PRODUCTS",
            "REBUILD DASHBOARD", "VALIDATE GROWTH OS", "RETRY PERIOD <period>",
            "EXPORT STORE PACKAGE", "IMPORT STORE PACKAGE", "INITIALIZE STORE",
            "IMPORT ACTION UPDATES", "DISCOVER COMPETITORS", "REFRESH MARKET INTELLIGENCE"
        ],
        "v3_features": {
            "decision_layer": "operator_decisions 表：executive_summary/primary_problem+root_cause/secondary_problem/largest_peer_gap/strongest_advantage/top_opportunities/top_risks/top_actions(P1≤5/P2≤10/P3)/why_now/expected_impact/validation，数据驱动计算，页面只展示决策层结果",
            "boss_cockpit": "经营总览 30 秒：本周结论 4 条（结论→为什么→影响→建议）+ 漏斗（每层当前/WoW/平均/优秀/状态）+ Gap Bar + Top5 Actions（对象/问题/为什么/动作/负责人/验证）+ 增长机会/风险",
            "executive_action_queue": "P1≤5/P2≤10/P3 观察池，每 Action 给 Why/Impact/Effort/Confidence/Owner/Validation，只需确认 做/不做/延后",
            "focus_screened": "P1 本周必须看（板块说明）+ P2/P3 折叠 + 产品机会雷达 8 类（每类 Top5 + 一句为什么）",
            "operator_review_pack": "operator_review_pack.html：每页附'这个页面替运营做了什么判断'"
        },
        "required_runtime_capabilities": ["python3", "Alibaba 官方数据访问", "config.json", "SQLite", "浏览器(file://)"],
        "default_locale": "zh-CN", "data_delay_days": 2, "week_start": "Monday", "week_end": "Sunday",
        "read_only_default": True,
        "files": {f: sha256(REL / f) for f in files},
        "checksums_algorithm": "SHA-256",
    }
    (REL / "RELEASE_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    leaks = []
    for p in REL.rglob("*"):
        if not p.is_file() or p.name == "RELEASE_MANIFEST.json":
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except Exception:
            continue
        for m in PRIVATE:
            idx = text.find(m)
            if idx >= 0 and "EXAMPLE ONLY" not in text[max(0, idx - 150): idx + 150]:
                leaks.append(f"{p.relative_to(REL)}: {m}")
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(REL.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(REL).as_posix())
    print(json.dumps({
        "release_dir": str(REL), "file_count_incl_manifest": len(files) + 1,
        "zip": str(ZIP_PATH), "zip_size_kb": round(ZIP_PATH.stat().st_size / 1024, 1),
        "private_data_leaks": leaks if leaks else "NONE (PASS)",
    }, ensure_ascii=False, indent=1))
    return 0 if not leaks else 1


if __name__ == "__main__":
    raise SystemExit(main())
