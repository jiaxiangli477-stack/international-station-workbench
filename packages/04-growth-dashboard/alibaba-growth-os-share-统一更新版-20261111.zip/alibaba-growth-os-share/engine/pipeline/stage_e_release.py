"""stage_e_release.py — 冻结 Alibaba Growth OS Skill V1.1.1 Release（Stage E 审计修复版）。"""
from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL = ROOT / "alibaba-growth-os"
REL = ROOT / "releases" / "alibaba-growth-os-v1.1.1"
ZIP_PATH = ROOT / "releases" / "alibaba-growth-os-v1.1.1.zip"

PRIVATE_MARKERS = ["LIFEWORTH", "莱华仕", "Shenzhen Lifeworth", "1653192276", "215246481",
                   "3164238008", "2216342370938", "3177503098", "2216438476011",
                   "1600472561736", "1601492686064", "1601720577533", "1600546912886",
                   "1601719605709", "1601476000834", "1601829634947", "1601427218194",
                   "26845", "64677", "3001.99", "10677.05", "12909.5", "16132.8", "508.4", "1501"]


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    h.update(p.read_bytes())
    return h.hexdigest()


def main() -> int:
    if REL.exists():
        shutil.rmtree(REL)
    REL.mkdir(parents=True)
    files = []
    for p in sorted(SKILL.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc":
            rel = p.relative_to(SKILL)
            dest = REL / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dest)
            files.append(rel.as_posix())

    manifest = {
        "skill_name": "alibaba-growth-os",
        "skill_version": "1.1.1",
        "schema_version": "1.0-stageA+stageB+d1_manual_tracking+e_audit_fixes",
        "release_date": date.today().isoformat(),
        "supersedes": "1.1.0（V1.0 / V1.1 均保留，不覆盖）",
        "supported_commands": [
            "SYNC WEEKLY", "SYNC MONTHLY", "OPTIMIZE PRODUCT <id>", "OPTIMIZE TOP PRODUCTS",
            "REBUILD DASHBOARD", "VALIDATE GROWTH OS", "RETRY PERIOD <period>",
            "EXPORT STORE PACKAGE", "IMPORT STORE PACKAGE", "INITIALIZE STORE",
            "IMPORT ACTION UPDATES"
        ],
        "v111_changes": {
            "operator_audit": "资深运营验收（业务/数据/可执行/可用性/AI 深度五维）",
            "ai_quality_fixes": [
                "8/8 候选 17 项深度方案（证据类型标记: 官方数据/系统计算/AI推断）",
                "双变量拆分: 主图候选 PRIMARY=MAIN_IMAGE, FUTURE=TITLE_SIMPLIFICATION（候选 ID 见运行时库）",
                "MOQ 越权修复: REVIEW_MOQ_LADDER + NEEDS_HUMAN_CONFIRMATION=true（AI 不决定商业政策）",
                "标题合规: Sugar Free → 真实属性 Low-Carb；候选标题按 Product/OEM/Wholesale 意图区分",
                "priority_reason/impact/actionability 字段（业务化候选选择）"
            ],
            "page_fixes": [
                "每页顶部'本页结论'(≤3) + '本周建议'(≤3)",
                "overview 漏斗卡点结论（PRIMARY_LEAKAGE: UV→Order / SECONDARY: Click→Inquiry）",
                "Action Center 业务化文案（重构标题/测试新主图/检查 MOQ 试单门槛…）+ 按产品去重",
                "Search 三类区分（Buyer Search Terms / Buyer Profile / Traffic Intent）",
                "Advertising AVAILABLE / PARTIAL / UNAVAILABLE 分段",
                "Result Learning 逻辑: 仅当产品 CTR 超额变化显著超过环境基准才判 positive"
            ]
        },
        "required_runtime_capabilities": [
            "python3 (sqlite3, json, argparse, datetime, hashlib, zipfile)",
            "Alibaba 官方数据访问（data-advisor MCP 或等价官方通路）",
            "config.json（含 data_source.advisory_date）", "SQLite 本地库",
            "现代浏览器（file:// 打开驾驶舱；localStorage 人工登记）"
        ],
        "optional_runtime_capabilities": ["官方 Excel Export（downloadUrl）", "公开产品详情页抓取"],
        "default_locale": "zh-CN",
        "data_delay_days": 2,
        "week_start": "Monday",
        "week_end": "Sunday",
        "read_only_default": True,
        "files": {f: sha256(REL / f) for f in files},
        "checksums_algorithm": "SHA-256",
    }
    (REL / "RELEASE_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")

    leaks = []
    for p in REL.rglob("*"):
        if not p.is_file() or p.name == "RELEASE_MANIFEST.json":
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except Exception:
            continue
        for marker in PRIVATE_MARKERS:
            idx = text.find(marker)
            if idx >= 0 and "EXAMPLE ONLY" not in text[max(0, idx - 150): idx + 150]:
                leaks.append(f"{p.relative_to(REL)}: {marker}")

    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(REL.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(REL).as_posix())

    print(json.dumps({
        "release_dir": str(REL),
        "file_count_incl_manifest": len(files) + 1,
        "manifest_listed_files": len(files),
        "zip": str(ZIP_PATH), "zip_size_kb": round(ZIP_PATH.stat().st_size / 1024, 1),
        "private_data_leaks": leaks if leaks else "NONE (PASS)",
    }, ensure_ascii=False, indent=1))
    return 0 if not leaks else 1


if __name__ == "__main__":
    raise SystemExit(main())
