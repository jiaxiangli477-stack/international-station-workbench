"""v2_competitors.py — Stage V2: 从官方热品榜提取真实竞品/热品 Product（≥30 目标）。

来源: raw/industry_cate_rank_*.json 的 prodInfoList（ALIBABA_OFFICIAL 官方热品榜，含 id/名称/图片）。
与已有 6 个直接竞品合并。首次标记 BASELINE，无图/无价格的标 UNAVAILABLE。
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / "database" / "alibaba_growth.db"


def main() -> int:
    conn = sqlite3.connect(str(DB))
    conn.row_factory = sqlite3.Row
    try:
        # 解析官方热品榜
        hot = []
        for f in ["industry_cate_rank_popular.json", "industry_cate_rank_blueocean.json"]:
            p = ROOT / "raw" / f
            if not p.exists():
                continue
            d = json.loads(p.read_text(encoding="utf-8"))
            for item in d.get("data", []):
                cate = item.get("cateCnName") or item.get("cateEnName") or ""
                for pi in (item.get("prodInfoList") or []):
                    pid = str(pi.get("id") or pi.get("productId") or "")
                    if not pid:
                        continue
                    hot.append({
                        "product_id": pid,
                        "title": pi.get("prodName") or pi.get("name") or "",
                        "image": pi.get("prodImage") or pi.get("image") or "",
                        "category": cate,
                        "rank": item.get("rankType") or "",
                        "source": "ALIBABA_OFFICIAL 官方热品榜(industry_cate_rank)",
                    })
        # 去重
        seen = {}
        for h in hot:
            if h["product_id"] not in seen:
                seen[h["product_id"]] = h
        hot_list = list(seen.values())
        print(f"官方热品榜提取: {len(hot_list)} 个真实热品")

        # 入库（category_products 表：竞品/热品 Product，含图片）
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS market_products (
            product_id TEXT PRIMARY KEY,
            title TEXT, image TEXT, category TEXT, rank TEXT, source TEXT,
            price_range TEXT, moq TEXT, certifications TEXT, product_url TEXT,
            snapshot_date TEXT DEFAULT '2026-08-20', snapshot_type TEXT DEFAULT 'BASELINE'
        );
        """)
        for h in hot_list:
            conn.execute(
                """INSERT OR IGNORE INTO market_products
                   (product_id, title, image, category, rank, source, snapshot_date, snapshot_type)
                   VALUES (?,?,?,?,?,?,'2026-08-20','BASELINE')""",
                (h["product_id"], h["title"], h["image"], h["category"], h["rank"], h["source"]))
        conn.commit()
        # 统计
        n_direct = conn.execute("SELECT COUNT(*) FROM competitor_products").fetchone()[0]
        n_market = conn.execute("SELECT COUNT(*) FROM market_products").fetchone()[0]
        print(json.dumps({
            "direct_competitor_products": n_direct,
            "market_hot_products": n_market,
            "total_real_products": n_direct + n_market,
            "target_30": n_direct + n_market >= 30,
        }, ensure_ascii=False, indent=1))
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
