# -*- coding: utf-8 -*-
"""把 raw/shop_product_m1_p*.json（月度产品全量）回填到本地库：
  - product_monthly_stats      （核心 7 指标）
  - product_monthly_stats_ext  （扩展指标，结构对齐 product_weekly_stats_ext）
  - products                    （月度有、周口径没有的产品，INSERT OR IGNORE 补上）

用法: python v6_ingest_products_monthly.py
"""
import json, glob, io, sys, os, sqlite3
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import _gos_ctx

ROOT = _gos_ctx.ROOT
RAW = _gos_ctx.RAW
DB = os.path.join(ROOT, 'database', 'alibaba_growth.db')


def num(v, d=0):
    try:
        if v in (None, ''):
            return d
        return float(v)
    except Exception:
        return d


def inum(v, d=0):
    try:
        return int(float(v))
    except Exception:
        return d


def main():
    win = {}
    wp = os.path.join(RAW, '_month_product_window.json')
    if os.path.exists(wp):
        win = json.load(open(wp, encoding='utf-8'))
    m_start = win.get('statDate') or ''
    m_end = win.get('month_end') or ''
    if not m_start:
        print("!! 缺少 raw/_month_product_window.json，先跑 v6_fetch_products_monthly.py")
        return 1
    if not m_end:
        # 由 statDate 推月末
        y, m = int(m_start[:4]), int(m_start[5:7])
        nxt = (y + (m // 12), (m % 12) + 1, 1)
        from datetime import date, timedelta
        m_end = (date(*nxt) - timedelta(days=1)).isoformat()
    print("月度产品窗口: %s ~ %s" % (m_start, m_end))

    rows = {}
    for p in sorted(glob.glob(os.path.join(RAW, 'shop_product_m1_p*.json'))):
        try:
            d = json.load(open(p, encoding='utf-8'))
        except Exception:
            continue
        for r in ((d.get('data') or {}).get('data') or []):
            rows[str(r.get('id'))] = r
    print("读到月度产品 %d 个" % len(rows))
    if not rows:
        return 1

    c = sqlite3.connect(DB)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS product_monthly_stats (
        product_id TEXT NOT NULL, month_start TEXT NOT NULL, month_end TEXT NOT NULL,
        impressions INTEGER NOT NULL DEFAULT 0, clicks INTEGER NOT NULL DEFAULT 0,
        ctr REAL NOT NULL DEFAULT 0, inquiries INTEGER NOT NULL DEFAULT 0,
        orders INTEGER NOT NULL DEFAULT 0, gmv REAL NOT NULL DEFAULT 0,
        PRIMARY KEY (product_id, month_start));
    CREATE TABLE IF NOT EXISTS product_monthly_stats_ext (
        product_id TEXT NOT NULL, month_start TEXT NOT NULL,
        total_imps INTEGER, total_clk INTEGER,
        ad_imps INTEGER, ad_clk INTEGER, p4p_imps INTEGER, p4p_clk INTEGER,
        atm_fb_uv INTEGER, mc_fb_uv INTEGER, fav INTEGER, cmp INTEGER, share INTEGER,
        crt_ord INTEGER, rts_online_amt REAL, byr_cnt_online_rts INTEGER,
        sum_show_coc REAL, sum_click_coc REAL, sum_visitor_coc REAL,
        PRIMARY KEY (product_id, month_start));
    """)

    st, ex, newp = [], [], []
    for pid, r in rows.items():
        st.append((pid, m_start, m_end,
                   inum(r.get('sumProdShowNum')), inum(r.get('sumProdClickNum')),
                   num(r.get('sumProdClickRate')), inum(r.get('sumProdFbNum')),
                   inum(r.get('crtOrd')), num(r.get('rtsOnlineAmt'))))
        ex.append((pid, m_start,
                   inum(r.get('totalImpsCnt')), inum(r.get('totalClkCnt')),
                   inum(r.get('adImpsCnt')), inum(r.get('adClkCnt')),
                   inum(r.get('p4pImpsCnt')), inum(r.get('p4pClkCnt')),
                   inum(r.get('atmFbUv')), inum(r.get('mcFbUv')),
                   inum(r.get('fav')), inum(r.get('cmp')), inum(r.get('share')),
                   inum(r.get('crtOrd')), num(r.get('rtsOnlineAmt')), inum(r.get('byrCntOnlineRts')),
                   num(r.get('sumProdShowNumCoc')), num(r.get('sumProdClickNumCoc')),
                   num(r.get('sumProdVisitorCntCoc'))))
        # 月度出现、库里还没有的产品补一条基础记录（不覆盖已有）
        cur = c.execute("SELECT 1 FROM products WHERE product_id=?", (pid,))
        if not cur.fetchone():
            newp.append((pid, r.get('prodName') or r.get('subject') or '',
                         r.get('cateName'), num(r.get('price')),
                         (r.get('crtTime') or '')[:10] or None))

    c.executemany("INSERT OR REPLACE INTO product_monthly_stats"
                  " (product_id, month_start, month_end, impressions, clicks, ctr, inquiries, orders, gmv)"
                  " VALUES (?,?,?,?,?,?,?,?,?)", st)
    c.executemany("INSERT OR REPLACE INTO product_monthly_stats_ext"
                  " (product_id, month_start, total_imps, total_clk, ad_imps, ad_clk, p4p_imps, p4p_clk,"
                  "  atm_fb_uv, mc_fb_uv, fav, cmp, share, crt_ord, rts_online_amt, byr_cnt_online_rts,"
                  "  sum_show_coc, sum_click_coc, sum_visitor_coc)"
                  " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ex)
    if newp:
        c.executemany("INSERT OR IGNORE INTO products"
                      " (product_id, title, category, price, status, crt_time) VALUES (?,?,?,?,?,?)",
                      [(p[0], p[1], p[2], p[3], 'active', p[4]) for p in newp])
    c.commit()

    n1 = c.execute("SELECT COUNT(*) FROM product_monthly_stats").fetchone()[0]
    n2 = c.execute("SELECT COUNT(*) FROM product_monthly_stats_ext").fetchone()[0]
    print("product_monthly_stats     = %d 行" % n1)
    print("product_monthly_stats_ext = %d 行" % n2)
    print("products 新增 %d 个（月度有、周口径没有的）" % len(newp))
    c.close()
    print("DONE")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
