# -*- coding: utf-8 -*-
"""V6: 市场趋势证据（多源：阿里询盘同比 + 全球市场报告 + 社媒/亚马逊信号 + 资深运营判断）"""
import json, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 每个品类：市场证据 + 趋势判断 + 建议。数据来源标注（market report=市场报告，judgment=资深运营判断）
EVIDENCE = {
    "pro": {
        "label": "蛋白/肌酸",
        "sources": [
            "全球蛋白补剂市场 $43.98B(2031)，CAGR 7.74%(Mordor Intelligence)",
            "植物蛋白粉占市场 44.2% 份额(2024, Grand View Research)",
        ],
        "social": "健身/撸铁内容常年高热，肌酸是 TikTok 健身圈标配，需求稳定",
        "amazon": "亚马逊蛋白粉是运动营养第一大品类，白牌/贴牌空间大",
        "verdict": "成熟大盘稳定增长，靠认证+含量透明赢，不是风口但需求永不枯竭",
    },
    "collagen": {
        "label": "胶原蛋白",
        "sources": [
            "胶原肽 2026 占 nutricosmetics 成分 32% 份额(Future Market Insights)",
            "水解胶原在粉剂+胶囊+软糖+饮品多剂型渗透",
        ],
        "social": "美容内服是小红书/TikTok 高热度赛道，'口服美容'持续种草",
        "amazon": "亚马逊 collagen peptides 是稳定畅销词，头部集中",
        "verdict": "美容线增长明确，拼来源(鱼/牛)+分子量+吸收率，复合配方是溢价点",
    },
    "energy": {
        "label": "能量/咖啡",
        "sources": [
            "运动健身增长驱动蛋白/能量大盘(CAGR 3.3%, Technavio)",
        ],
        "social": "能量饮品/咖啡是高频消费品，'咖啡因+提神'内容热度稳定",
        "amazon": "亚马逊 energy/pre-workout 是运动营养第二大品类",
        "verdict": "高频快消，B端要 OEM贴牌+稳定供货，场景图+含量透明+合法是赢家公式",
    },
    "maca": {
        "label": "玛卡/壮阳",
        "sources": [
            "Maca 真实定位是安第斯草本食品，主流应用是 daily vitality/energy(HerbaZest)",
            "'壮阳'是市场误用，站内壮阳词属合规雷区",
        ],
        "social": "壮阳类目在站内被严打，TikTok/亚马逊都不允许性功效宣称",
        "amazon": "亚马逊 male enhancement 类目下架率高，合规风险最大",
        "verdict": "别做壮阳。改赛道到 sports energy+stamina，把复合配方周期表当差异化",
    },
    "detox": {
        "label": "减肥/草本茶",
        "sources": [
            "减肥胶囊/茶是站内+亚马逊最高合规风险的类目之一",
        ],
        "social": "草本消化茶(bloating/gut health)在 TikTok 是蓝海，Yogi Tea 式打法",
        "amazon": "亚马逊 detox 词被限制，digestive herbal tea 是合规替代",
        "verdict": "减肥是红海+雷区。换赛道 digestive herbal tea，主打消化舒缓，客单价可翻倍",
    },
    "gummies": {
        "label": "软糖",
        "sources": [
            "软糖是补充剂增长最快的剂型(好入口+便携+儿童向)",
        ],
        "social": "软糖剂型在社媒种草率高(好吃+颜值+便携)，儿童/女性向尤其火",
        "amazon": "亚马逊 gummies vitamins 增速远超胶囊，OEM 口味定制需求大",
        "verdict": "剂型红利期，B端要 OEM口味定制+低糖天然色素，对标软糖行业头部卖家",
    },
    "vitamin": {
        "label": "维生素",
        "sources": [
            "2026 美国补充剂趋势：GLP-1 相关营养、肌酸、胶原是热点(The Vitamin Shoppe)",
        ],
        "social": "维生素是基础盘，'免疫/能量/睡眠'功能词持续有需求",
        "amazon": "亚马逊 multivitamin 是最大补充剂品类，价格战激烈",
        "verdict": "基础盘走量，靠剂量透明+认证+组合装，避免价格战(做差异化组合)",
    },
    "strip": {
        "label": "口溶膜",
        "sources": [
            "口溶膜是新兴剂型，'3秒速溶+便携+快吸收'是差异化卖点",
        ],
        "social": "口溶膜在社媒有'新奇特'传播点，便携场景(出差/健身/车上)",
        "amazon": "亚马逊 oral film 尚处早期，竞争少，是蓝海剂型",
        "verdict": "新兴剂型蓝海，靠溶解演示视频+便携场景打开，快吸收是护城河",
    },
    "generic": {
        "label": "通用补充剂",
        "sources": [
            "全球补充剂大盘稳定增长，clean-label/植物来源是趋势",
        ],
        "social": "健康/养生内容热度稳定，'天然/无添加/clean label'是主流心智",
        "amazon": "亚马逊补充剂头部集中，白牌 OEM 是中小卖家的主要打法",
        "verdict": "通用品靠 OEM定制+认证+价格，没认证只能卷价格战",
    },
}

with open('raw/market_evidence.json', 'w', encoding='utf-8') as f:
    json.dump(EVIDENCE, f, ensure_ascii=False, indent=1)
print("市场证据 %d 个品类" % len(EVIDENCE))
for k, v in EVIDENCE.items():
    print("  [%s] %s" % (v['label'], v['verdict'][:50]))
