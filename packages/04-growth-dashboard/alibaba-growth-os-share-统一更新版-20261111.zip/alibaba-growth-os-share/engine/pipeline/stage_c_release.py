"""stage_c_release.py — PART 1/2/24 冻结 Alibaba Growth OS Skill V1.0 Release。

1. 复制 alibaba-growth-os/ → releases/alibaba-growth-os-v1.0/（仅通用 Skill 文件）
2. 生成 RELEASE_MANIFEST.json（版本/能力/文件/SHA256 checksums）
3. 审计 Release 不含当前店铺私有数据
4. 打包 alibaba-growth-os-v1.0.zip
"""
from __future__ import annotations

import hashlib
import json
import shutil
import sys
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL = ROOT / "alibaba-growth-os"
REL = ROOT / "releases" / "alibaba-growth-os-v1.0"
ZIP_PATH = ROOT / "releases" / "alibaba-growth-os-v1.0.zip"

# 店铺私有数据标记（Release 中禁止出现，除非为文档示例且标注 EXAMPLE ONLY）
PRIVATE_MARKERS = ["LIFEWORTH", "莱华仕", "Shenzhen Lifeworth", "1653192276", "215246481",
                   "3164238008", "2216342370938", "3177503098", "2216438476011", "2217596342049",
                   "1600472561736", "1601492686064", "1601720577533", "1600546912886",
                   "1601719605709", "1601476000834", "1601829634947", "1601427218194",
                   "26845", "64677", "3001.99", "10677.05"]


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    h.update(p.read_bytes())
    return h.hexdigest()


def main() -> int:
    # 1. 复制
    if REL.exists():
        shutil.rmtree(REL)
    REL.mkdir(parents=True)
    files = []
    for p in sorted(SKILL.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc":
            rel = p.relative_to(SKILL)
            dest = REL / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dest)
            files.append(rel.as_posix())

    # 2. Manifest
    manifest = {
        "skill_name": "alibaba-growth-os",
        "skill_version": "1.0.0",
        "schema_version": "1.0-stageA+stageB",
        "release_date": date.today().isoformat(),
        "supported_commands": [
            "SYNC WEEKLY", "SYNC MONTHLY", "OPTIMIZE PRODUCT <id>", "OPTIMIZE TOP PRODUCTS",
            "REBUILD DASHBOARD", "VALIDATE GROWTH OS", "RETRY PERIOD <period>",
            "EXPORT STORE PACKAGE", "IMPORT STORE PACKAGE", "INITIALIZE STORE"
        ],
        "required_runtime_capabilities": [
            "python3 (sqlite3, json, argparse, datetime)", "Alibaba 官方数据访问（data-advisor MCP 或等价官方通路）",
            "config.json（含 data_source.advisory_date）", "SQLite 本地库"
        ],
        "optional_runtime_capabilities": [
            "Accio Work / 通用 Shell", "官方 Excel Export（downloadUrl）", "公开产品详情页抓取"
        ],
        "default_locale": "zh-CN",
        "data_delay_days": 2,
        "week_start": "Monday",
        "week_end": "Sunday",
        "read_only_default": True,
        "files": {f: sha256(REL / f) for f in files},
        "checksums_algorithm": "SHA-256",
    }
    (REL / "RELEASE_MANIFEST.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")

    # 3. 私有数据审计（文档示例 EXAMPLE ONLY 允许）
    leaks = []
    for p in REL.rglob("*"):
        if not p.is_file() or p.name == "RELEASE_MANIFEST.json":
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except Exception:
            continue
        for marker in PRIVATE_MARKERS:
            idx = text.find(marker)
            if idx >= 0:
                seg = text[max(0, idx - 150): idx + 150]
                if "EXAMPLE ONLY" not in seg:
                    leaks.append(f"{p.relative_to(REL)}: {marker}")
    # 4. ZIP
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(REL.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(REL).as_posix())

    print(json.dumps({
        "release_dir": str(REL),
        "file_count": len(files),
        "manifest": "RELEASE_MANIFEST.json 生成",
        "zip": str(ZIP_PATH),
        "zip_size_kb": round(ZIP_PATH.stat().st_size / 1024, 1),
        "private_data_leaks": leaks if leaks else "NONE (PASS)",
    }, ensure_ascii=False, indent=1))
    return 0 if not leaks else 1


if __name__ == "__main__":
    raise SystemExit(main())
