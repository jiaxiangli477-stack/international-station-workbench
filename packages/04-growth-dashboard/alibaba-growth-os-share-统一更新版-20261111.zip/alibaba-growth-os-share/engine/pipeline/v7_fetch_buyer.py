# -*- coding: utf-8 -*-
"""V7: 重新拉取买家画像（data_advisor_shop_customer_profile）→ raw/customer_profile_*.json → customer_profile_snapshot"""
import subprocess, json, io, sys, os, sqlite3
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def call_advisor(params):
    tmp = os.path.join(os.getcwd(), '_tmp_cp.json')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(params, f, ensure_ascii=False)
    r = subprocess.run('accio-mcp-cli call data_advisor_shop_customer_profile --json-file "' + tmp + '"',
                       shell=True, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120)
    out = r.stdout or ''
    # 找到第一个 JSON 边界并解析
    i = out.find('{')
    if i < 0:
        i = out.find('[')
    if i < 0:
        raise RuntimeError('无 JSON 输出: ' + out[:300] + ((' | err: ' + r.stderr[:200]) if r.stderr else ''))
    dec = json.JSONDecoder()
    obj, _ = dec.raw_decode(out[i:])
    return obj

FETCHES = [
    ("byr_identity", "", "customer_profile_byr_identity_30d.json"),
    ("country", "", "customer_profile_country_30d.json"),
    ("byr_identity", "L1+", "customer_profile_byr_identity_L1_30d.json"),
    ("country", "L1+", "customer_profile_country_L1_30d.json"),
]

rows = []
for dim, growth, fname in FETCHES:
    params = {"dimensionType": dim, "nd": "30d", "terminalType": "TOTAL"}
    if growth:
        params["byrGrowthLevel"] = growth
    try:
        resp = call_advisor(params)
        path = os.path.join('raw', fname)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(resp, f, ensure_ascii=False)
        data = resp.get('data') if isinstance(resp, dict) else resp
        rows.append((dim, growth, json.dumps(data, ensure_ascii=False)))
        print('OK  ', fname, '->', str(data)[:140])
    except Exception as e:
        print('FAIL', fname, '->', repr(e))

if rows:
    db = sqlite3.connect('database/alibaba_growth.db')
    db.execute("DELETE FROM customer_profile_snapshot")
    today = '2026-08-25'
    for dim, growth, payload in rows:
        db.execute("INSERT INTO customer_profile_snapshot (snapshot_date, nd, dimension, byr_growth_level, payload_json) VALUES (?,?,?,?,?)",
                   (today, '30d', dim, growth, payload))
    db.commit()
    print('已重载', len(rows), '条到 customer_profile_snapshot')
