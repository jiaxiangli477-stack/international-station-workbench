# -*- coding: utf-8 -*-
"""聊天质检明细入库：raw/chat_quality_check_*.json → cs_chat_quality 表"""
import sqlite3, json, glob, os, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ROOT, 'database', 'alibaba_growth.db')

def load(path):
    raw = open(path, 'rb').read()
    for enc in ('utf-8-sig', 'utf-8', 'utf-16'):
        try:
            return json.loads(raw.decode(enc))
        except Exception:
            pass
    return None

files = sorted(glob.glob(os.path.join(ROOT, 'raw', 'chat_quality_check_*.json')))
if not files:
    print("无质检文件"); sys.exit(1)

conn = sqlite3.connect(DB)
cur = conn.cursor()
total = 0
for f in files:
    d = load(f)
    rows = (d or {}).get('data') or []
    for r in rows:
        full_name = ' '.join(('%s %s' % (r.get('firstName') or '', r.get('lastName') or '')).split())
        stats_date = r.get('statsDate') or ''
        cur.execute(
            """INSERT OR REPLACE INTO cs_chat_quality
               (id, stats_date, full_name, login_id, buyer_level, l3l4_buyer,
                reply_over12h, not_follow, buyer_rnr, only_hi, evaluate_unsatisfied,
                msg_content, raw_json)
               VALUES ((SELECT id FROM cs_chat_quality WHERE stats_date=? AND full_name=? AND login_id=?),
                       ?,?,?,?,?,?,?,?,?,?,?,?)""",
            (stats_date, full_name, r.get('loginId'),
             stats_date, full_name, r.get('loginId'), r.get('buyerLevel'),
             r.get('l3l4Buyer'), r.get('replyOver12h'), r.get('notFollow'),
             r.get('buyerRnR'), r.get('onlyHi'), r.get('evaluateUnsatisfied'),
             (r.get('replyOver12hMsgContent') or r.get('rcTooShortMsgContent') or r.get('repeatReplyMsgContent') or ''),
             json.dumps(r, ensure_ascii=False)))
        total += 1
conn.commit()
# 统计
stats = cur.execute("""SELECT full_name, COUNT(*) cnt, SUM(reply_over12h) over12h,
                       SUM(not_follow) nf, SUM(l3l4_buyer) l3l4, SUM(buyer_rnr) rnr,
                       SUM(evaluate_unsatisfied) unsat
                       FROM cs_chat_quality GROUP BY full_name""").fetchall()
print(f"入库 {total} 条质检记录")
print("按客服聚合:")
for s in stats:
    print(f"  {s[0]}: 记录{s[1]} 超12h={s[2]} 未跟进={s[3]} L3L4={s[4]} 回复率={s[5]} 不满意={s[6]}")
conn.close()
