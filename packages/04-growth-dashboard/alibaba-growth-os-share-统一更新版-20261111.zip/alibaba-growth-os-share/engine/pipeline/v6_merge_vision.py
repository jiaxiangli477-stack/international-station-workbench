# -*- coding: utf-8 -*-
"""V6: 合并 4 批视觉结果 + 资深运营分析（B2B转化/AI识别适配 + 修改建议）"""
import json, io, sys, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

merged = {}
total_lines = 0
for i in range(4):
    fp = 'raw/vision_result_%d.jsonl' % i
    if not os.path.exists(fp):
        print("缺失 %s" % fp); continue
    with open(fp, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            try:
                obj = json.loads(line)
                merged[str(obj['pid'])] = obj
                total_lines += 1
            except Exception as e:
                print("解析失败:", line[:60], e)

# 资深运营分析：给每个产品算 b2b_fit / ai_match / 视觉分 / 修改建议
def analyze(v):
    t = v.get('type', '')
    bg = v.get('bg', '')
    sp = v.get('sellpoint', '')
    cert = v.get('cert', '')
    risk = v.get('risk', '')
    note = v.get('note', '')
    # 视觉基础分
    base = 0
    if t == '实物图': base += 45
    elif t == '渲染图': base += 25
    elif t == '占位图': base += 10
    if bg == '白底': base += 15
    elif bg == '场景': base += 12
    if sp == '有': base += 15
    if cert == '有': base += 10
    if risk == '无': base += 15
    elif risk == '其他': base += 5
    else: base += 0  # 减肥/壮阳 不加分
    vision_score = min(100, base)
    # B2B 转化适配
    if t == '占位图': b2b, b2bc = '差', '白牌模板图，B端买家要真实成品'
    elif t == '渲染图': b2b, b2bc = '中', '渲染图非实拍，B端信任感弱'
    elif t == '实物图' and cert == '有': b2b, b2bc = '好', '实拍+认证，B端信任要素齐全'
    elif t == '实物图': b2b, b2bc = '好' if sp == '有' else '中', ('卖点清晰，B端可看懂' if sp == '有' else '缺卖点文字，B端看不明')
    else: b2b, b2bc = '中', '待确认'
    # AI 识别匹配
    if sp == '有' and t in ('实物图', '渲染图'): ai, aic = '好', '卖点文字清晰，AI可识别品类/卖点'
    elif sp == '有': ai, aic = '中', '有文字但图片类型待优化'
    elif t == '渲染图': ai, aic = '中', '渲染图无实拍质感，AI识别卖点有限'
    else: ai, aic = '差', '无卖点文字，AI难识别具体卖点'
    # 修改建议（资深运营口径）
    advices = []
    if risk == '减肥': advices.append('改掉减肥擦边词(改 metabolism support/digestive health)')
    if risk == '壮阳': advices.append('改掉壮阳擦边词(改 herbal/botanical supplement)')
    if risk == '其他': advices.append('删除疾病疗效宣称(涉癌/艾滋等，最高合规风险)')
    if t == '占位图': advices.append('换真实品牌成品图，去掉 YOUR LOGO')
    if t == '渲染图': advices.append('换成实拍图')
    if sp == '无': advices.append('主图加卖点大字报(核心卖点+规格)')
    if cert == '无': advices.append('补认证墙(HALAL/ISO/GMP)')
    if '拼写' in note or '错' in note: advices.append('修正主图拼写错误')
    v['vision_score'] = vision_score
    v['b2b'] = b2b; v['b2b_comment'] = b2bc
    v['ai'] = ai; v['ai_comment'] = aic
    v['advices'] = advices[:3]
    return v

for pid, v in merged.items():
    merged[pid] = analyze(v)

with open('raw/vision_full.json', 'w', encoding='utf-8') as f:
    json.dump(merged, f, ensure_ascii=False)

# 统计
n_occ = sum(1 for v in merged.values() if v.get('type') == '占位图')
n_render = sum(1 for v in merged.values() if v.get('type') == '渲染图')
n_risk = sum(1 for v in merged.values() if v.get('risk') in ('减肥','壮阳','其他'))
n_b2b_good = sum(1 for v in merged.values() if v.get('b2b') == '好')
n_ai_good = sum(1 for v in merged.values() if v.get('ai') == '好')
print("合并完成: %d 个产品（原始 %d 行）" % (len(merged), total_lines))
print("占位图 %d | 渲染图 %d | 擦边/违规 %d" % (n_occ, n_render, n_risk))
print("B2B转化适配 好 %d | AI识别 好 %d" % (n_b2b_good, n_ai_good))
