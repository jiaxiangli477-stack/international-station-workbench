# -*- coding: utf-8 -*-
"""
V4 判定引擎 + 数据聚合：从 SQLite 计算所有页面需要的判定标签、对标 gap、榜单，输出 v4_data.json。
单一事实源：dashboard 模板只读 v4_data.json，不再各自算。
"""
import sqlite3, json, io, sys, os
from datetime import datetime
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

DB = 'database/alibaba_growth.db'
OUT = 'v4_data.json'

c = sqlite3.connect(DB)
c.row_factory = sqlite3.Row
cur = c.cursor()

def r1(sql, args=()):
    cur.execute(sql, args)
    row = cur.fetchone()
    return dict(row) if row else {}

def rall(sql, args=()):
    cur.execute(sql, args)
    return [dict(r) for r in cur.fetchall()]

# ---------- 最新完整周 + 上一周 ----------
wk = rall("SELECT * FROM store_weekly_stats ORDER BY stat_week_end")
latest = wk[-1]; prev = wk[-2]
WEEK_END = latest['stat_week_end']; WEEK_START = latest['stat_week_start']
PREV_END = prev['stat_week_end']
print("最新周:", WEEK_START, "~", WEEK_END, "| 上周:", prev['stat_week_start'], "~", PREV_END)

store_meta = r1("SELECT * FROM store WHERE id=1")
cur.execute("SELECT value FROM meta WHERE key='advisory_date'")
_adv = cur.fetchone()
advisory = _adv[0] if _adv else ''

# ---------- 店铺级 KPI（最新周 + 环比 + 对标）----------
S = latest
def wow(cur_v, prev_v):
    if prev_v in (None, 0): return None
    try: return round((cur_v - prev_v) / abs(prev_v) * 100, 1)
    except: return None

def pct(v):
    return round(v*100, 2) if isinstance(v, (int, float)) else None

def num(v):
    if v is None: return '—'
    try: return format(int(round(v)), ',')
    except: return str(v)

# 全店点击 = 产品级 total_clk 之和
tot_clk = r1("SELECT SUM(total_clk) s FROM product_weekly_stats_ext WHERE week_start=?", (WEEK_START,))['s'] or 0

funnel = [
  {"key":"se_imps","label":"搜索曝光","cur":S['se_imps'],"prev":prev['se_imps'],
   "rival_avg":S['se_imps_rival_avg'],"rival_good":S['se_imps_rival_good'],"unit":""},
  {"key":"se_clk","label":"搜索点击","cur":S['se_clk'],"prev":prev['se_clk'],
   "rival_avg":S['se_clk_rival_avg'],"rival_good":S['se_clk_rival_good'],"unit":""},
  {"key":"se_ctr","label":"搜索点击率","cur":pct(S['se_ctr']),"prev":pct(prev['se_ctr']),
   "rival_avg":pct(S['se_ctr_rival_avg']),"rival_good":pct(S['se_ctr_rival_good']),"unit":"%","fmt":"pct"},
  {"key":"total_imps","label":"全店曝光","cur":S['total_imps'],"prev":prev['total_imps'],
   "rival_avg":S['total_imps_rival_avg'],"rival_good":S['total_imps_rival_good'],"unit":""},
  {"key":"total_clk","label":"全店点击/浏览量","cur":S['pv_cnt'],"prev":prev['pv_cnt'],
   "rival_avg":None,"rival_good":S['pv_cnt_rival_good'],"unit":""},
  {"key":"camp_imps","label":"广告曝光","cur":S['camp_imps'],"prev":prev['camp_imps'],
   "rival_avg":S['camp_imps_rival_avg'],"rival_good":S['camp_imps_rival_good'],"unit":""},
  {"key":"camp_clk","label":"广告点击","cur":S['camp_clk'],"prev":prev['camp_clk'],
   "rival_avg":S['camp_clk_rival_avg'],"rival_good":S['camp_clk_rival_good'],"unit":""},
  {"key":"opp","label":"商机(询盘+TM)","cur":(S['fb_cnt'] or 0)+(S['fb_tm_uv'] or 0),"prev":(prev['fb_cnt'] or 0)+(prev['fb_tm_uv'] or 0),
   "rival_avg":None,"rival_good":None,"unit":"","note":"询盘 %s + TM %s" % (S['fb_cnt'], S['fb_tm_uv'])},
  {"key":"fb_cnt","label":"询盘个数","cur":S['fb_cnt'],"prev":prev['fb_cnt'],"rival_avg":None,"rival_good":None,"unit":""},
  {"key":"fb_tm_uv","label":"TM咨询人数","cur":S['fb_tm_uv'],"prev":prev['fb_tm_uv'],"rival_avg":None,"rival_good":None,"unit":""},
  {"key":"uv_cnt","label":"访客","cur":S['uv_cnt'],"prev":prev['uv_cnt'],"rival_avg":None,"rival_good":S['uv_cnt_rival_good'],"unit":""},
  {"key":"uv_ab_rate","label":"跳失率","cur":pct(S['uv_ab_rate']),"prev":pct(prev['uv_ab_rate']),
   "rival_avg":pct(S['uv_ab_rate_rival_avg']),"rival_good":pct(S['uv_ab_rate_rival_good']),"unit":"%","fmt":"pct","lower_better":True},
  {"key":"suc_byr_cnt","label":"成交买家","cur":S['suc_byr_cnt'],"prev":prev['suc_byr_cnt'],
   "rival_avg":None,"rival_good":S['suc_byr_cnt_rival_good'],"unit":"人"},
  {"key":"uv_payord_rate","label":"访客成交率","cur":pct(S['uv_payord_rate']),"prev":pct(prev['uv_payord_rate']),
   "rival_avg":pct(S['uv_payord_rate_rival_avg']),"rival_good":pct(S['uv_payord_rate_rival_good']),"unit":"%","fmt":"pct"},
  {"key":"suc_ord_cnt","label":"下单","cur":S['suc_ord_cnt'],"prev":prev['suc_ord_cnt'],
   "rival_avg":S['suc_ord_cnt_rival_avg'],"rival_good":S['suc_ord_cnt_rival_good'],"unit":"单"},
  {"key":"suc_ord_amt","label":"GMV","cur":round(S['suc_ord_amt'],1),"prev":prev['suc_ord_amt'],
   "rival_avg":round(S['suc_ord_amt_rival_avg'],1),"rival_good":round(S['suc_ord_amt_rival_good'],1),"unit":"$","fmt":"money"},
]
for f in funnel:
    f['wow'] = wow(f['cur'], f['prev'])
    f['gap_avg'] = round(f['cur'] - f['rival_avg'], 2) if f['rival_avg'] is not None else None
    f['gap_good'] = round(f['cur'] - f['rival_good'], 2) if f['rival_good'] is not None else None

# ---------- 承接效率 ----------
bearing = [
  {"key":"avg_reply_time","label":"平均回复时长","cur":S['avg_reply_time30d'],
   "rival_avg":S['avg_reply_time30d_rival_avg'],"rival_good":None,"unit":"h","lower_better":True},
  {"key":"fst5min","label":"极速回复率(5min)","cur":pct(S['fst5min_reply_rate30d']),
   "rival_avg":pct(S['fst5min_reply_rate30d_rival_avg']),"rival_good":pct(S['fst5min_reply_rate30d_rival_good']),"unit":"%","fmt":"pct"},
  {"key":"fst_reply","label":"及时回复率","cur":pct(S['fst_reply_rate30d']),
   "rival_avg":pct(S['fst_reply_rate30d_rival_avg']),"rival_good":pct(S['fst_reply_rate30d_rival_good']),"unit":"%","fmt":"pct"},
  {"key":"uv_payord","label":"访客成交率","cur":pct(S['uv_payord_rate']),
   "rival_avg":pct(S['uv_payord_rate_rival_avg']),"rival_good":pct(S['uv_payord_rate_rival_good']),"unit":"%","fmt":"pct"},
]

# ---------- 客服子账号 ----------
staff = rall("SELECT * FROM cs_staff_weekly WHERE week_end=? AND full_name!='全部账号' ORDER BY uv_fb_atm DESC", (WEEK_END,))
# 聊天质检聚合
cq = rall("SELECT full_name, COUNT(*) cnt, SUM(reply_over12h) over12h, SUM(not_follow) notfollow, SUM(l3l4_buyer) l3l4, SUM(only_hi) onlyhi, SUM(evaluate_unsatisfied) unsat, SUM(buyer_rnr) rnr FROM cs_chat_quality GROUP BY full_name")
cq_map = {x['full_name']: x for x in cq}
# 店级均值（用于标红）
store_avg_5min = pct(S['fst5min_reply_rate30d'])
store_avg_reply = S['avg_reply_time30d']
staff_out = []
for s in staff:
    nm = s['full_name']
    q = cq_map.get(nm, {})
    staff_out.append({
        "name": nm, "avatar": s['avatar'],
        "fb_pv": s['fb_pv'], "fb_uv": s['fb_uv'], "tm": s['uv_fb_atm'],
        "rcvd_amt": s['rcvd_amt'], "order_cnt": (s['prepay_ord'] or 0) + (s['drawup_ord'] or 0),
        "fst5min": pct(s['fst5min_reply_rate']), "reply_rate": pct(s['reply_rate']),
        "avg_reply": s['avg_reply_time'],
        "bus_to_ord": pct(s['bus_to_ord_rate']),
        "over12h": q.get('over12h') or 0, "notfollow": q.get('notfollow') or 0,
        "l3l4": q.get('l3l4') or 0, "onlyhi": q.get('onlyhi') or 0,
        "unsat": q.get('unsat') or 0, "rnr": q.get('rnr') or 0,
        "qc_cnt": q.get('cnt') or 0,
    })

# ---------- 店铺健康（产品分层）----------
lvl = rall("SELECT prod_level, COUNT(*) c FROM products GROUP BY prod_level")
lvl_map = {x['prod_level']: x['c'] for x in lvl}
inquiry_products = r1("SELECT COUNT(DISTINCT product_id) c FROM product_weekly_stats WHERE week_end=? AND inquiries>0", (WEEK_END,))['c']
valid_cnt = S['valid_prod_cnt']
health = {
    "star": None,  # 数据缺口
    "star_note": "星等级综合分/降星预测：当前数据源（数据参谋 MCP）无此字段，需接入 My Alibaba 星等级接口",
    "levels": [
        {"label":"爆品","count":lvl_map.get('爆品',0)},
        {"label":"优品","count":lvl_map.get('优品',0)},
        {"label":"潜力优品","count":lvl_map.get('潜力优品',0)},
        {"label":"普通品","count":lvl_map.get('普通品',0)},
        {"label":"低质品","count":lvl_map.get('低质品',0)},
    ],
    "valid_cnt": valid_cnt,
    "inquiry_products": inquiry_products,
    "zero_inquiry": valid_cnt - inquiry_products,
}

# ---------- 产品判定 + 榜单 ----------
prods = rall("""SELECT p.product_id, p.title, p.prod_level, p.moq, p.price_range, p.main_image, p.detail_url, p.category_name, p.first_seen_at, p.crt_time,
  ps.impressions, ps.clicks, ps.ctr, ps.inquiries, ps.orders, ps.gmv,
  e.total_imps, e.total_clk, e.ad_imps, e.ad_clk, e.p4p_imps, e.p4p_clk, e.mc_fb_uv, e.atm_fb_uv, e.crt_ord, e.rts_online_amt,
  e.sum_show_coc, e.sum_click_coc
  FROM products p
  LEFT JOIN product_weekly_stats ps ON ps.product_id=p.product_id AND ps.week_end=?
  LEFT JOIN product_weekly_stats_ext e ON e.product_id=p.product_id AND e.week_start=?
  """, (WEEK_END, WEEK_START))

def judge(p):
    """商机 = 询盘 + TM（平行商机，非上下游）。判定标签 + 专业建议"""
    inq = p['inquiries'] or 0
    clk = p['clicks'] or 0
    tm = p['atm_fb_uv'] or 0   # ATM = Alibaba TradeManager 咨询UV
    adc = p['ad_clk'] or 0
    tot_clk = p['total_clk'] or 0
    opp = inq + tm  # 商机
    if opp >= 1:
        label = "有商机"
        typ = "good"
        src = "询盘%d" % inq if inq else ""
        if tm: src += ("+TM%d" % tm) if src else "TM%d" % tm
        sug = "商机(%s)，抓成交：30秒响应→问目标市场/MOQ/定制→发报价，别让商机凉在接待" % src
    elif tot_clk >= 4:
        label = "高点击0商机"
        typ = "danger"
        sug = "全店点击%02d次但0商机=主图勾住人了、详情页没转化。查价格/MOQ是否劝退，首屏放「价格+认证+OEM能力+免费样品」四要素" % tot_clk
    elif tot_clk >= 1:
        label = "有曝光未起量"
        typ = "muted"
        sug = "曝光有、全店点击%02d次偏少=主图首图卖点没勾住，重做首图（痛点钩子+认证墙），标题补长尾" % tot_clk
    else:
        label = "冷启动"
        typ = "muted"
        sug = "无流量，进AI搜索池：补结构化属性(成分/剂型/适用场景)+主图6张+视频+TrustScore冲80"
    # 广告判定（商机口径）
    if adc >= 1 and opp == 0:
        ad_label = "烧钱无商机"; ad_typ = "danger"
    elif adc >= 1:
        ad_label = "广告有商机"; ad_typ = "good"
    else:
        ad_label = "零花费"; ad_typ = "neutral"
    p['label'] = label; p['label_typ'] = typ; p['sug'] = sug
    p['opp'] = opp
    p['ad_label'] = ad_label; p['ad_typ'] = ad_typ
    return p

prods = [judge(p) for p in prods]

# ---------- 产品状态分类（4.4 九宫格，落地 8 态；报价类需报价数据暂缺） ----------
STATE_NAMES = {
    "zero_exp": "零曝光沉睡", "imp_no_clk": "有曝光无点击",
    "ad_no_opp": "广告点击无商机", "clk_no_opp": "有点击无商机",
    "nat_opp_no_ad": "自然商机无广告", "has_opp": "有商机",
    "deal_low_aov": "成交·客单价低", "deal_ok": "成交·健康",
}
STATE_ACTIONS = {
    "zero_exp": "零曝光=类目/关键词没匹配或可能降权。查是否下架受限，重发+补长尾词+换主类目",
    "imp_no_clk": "有曝光无点击=首图没勾住。只重做主图首图（痛点钩子+认证墙），标题核心词前移",
    "ad_no_opp": "广告点击无商机=广告词与详情页不匹配。查进店词，换词或改 Landing 首屏",
    "clk_no_opp": "有点击无商机=详情页没转化。首屏放「价格+认证+OEM能力+免费样品」四要素",
    "nat_opp_no_ad": "有自然商机无广告=已验证的自然词。开小额广告放大，先投已出商机的词",
    "has_opp": "有商机=承接转成交关键。客服 48h 跟进+报价+样品方案闭环",
    "deal_low_aov": "有成交但客单价低=推组合装/高客单 SKU，或提高 MOQ 拉客单价",
    "deal_ok": "有成交=标杆品。复制打法到同类零成交品，继续投广告放大",
}
STATE_ORDER = ["deal_ok", "deal_low_aov", "has_opp", "nat_opp_no_ad", "ad_no_opp", "clk_no_opp", "imp_no_clk", "zero_exp"]

def classify_state(p):
    total_imps = p.get('total_imps') or 0
    total_clk = p.get('total_clk') or 0
    ad_clk = p.get('ad_clk') or 0
    opp = p.get('opp') or 0
    orders = p.get('orders') or 0
    gmv = p.get('gmv') or 0
    if orders > 0:
        aov = gmv / orders
        return "deal_low_aov" if aov < 500 else "deal_ok"
    if opp > 0 and ad_clk == 0:
        return "nat_opp_no_ad"
    if opp > 0:
        return "has_opp"
    if ad_clk > 0:
        return "ad_no_opp"
    if total_clk >= 4:
        return "clk_no_opp"
    if total_imps > 0:
        return "imp_no_clk"
    return "zero_exp"

def mklist(items):
    out = []
    for p in items:
        out.append({
            "product_id": p['product_id'], "title": (p['title'] or '')[:70],
            "prod_level": p['prod_level'], "moq": p['moq'], "price_range": p['price_range'],
            "main_image": p['main_image'], "detail_url": p['detail_url'], "category": p['category_name'],
            "impressions": p['impressions'], "clicks": p['clicks'], "ctr": pct(p['ctr']),
            "total_imps": p['total_imps'], "total_clk": p['total_clk'],
            "total_ctr": pct((p['total_clk'] or 0) / (p['total_imps'] or 0) if p['total_imps'] else 0),
            "inquiries": p['inquiries'], "tm": p['atm_fb_uv'], "opp": p.get('opp', (p['inquiries'] or 0) + (p['atm_fb_uv'] or 0)),
            "orders": p['orders'], "gmv": p['gmv'],
            "ad_imps": p['ad_imps'], "ad_clk": p['ad_clk'],
            "label": p['label'], "label_typ": p['label_typ'], "sug": p['sug'],
            "ad_label": p['ad_label'], "ad_typ": p['ad_typ'],
            "state": classify_state(p), "state_txt": STATE_NAMES[classify_state(p)],
            "coc_show": p['sum_show_coc'], "coc_click": p['sum_click_coc'],
        })
    return out

def build_lists(plist):
    """榜单构造抽成函数，周/月两套口径共用（月口径传 prods_m）。
    注意：入参元素必须已过 judge()，即带 opp/label/ad_label 等派生字段。"""
    has_inq = [p for p in plist if (p['inquiries'] or 0) > 0]
    has_opp = [p for p in plist if (p['opp'] or 0) > 0]   # 商机榜（询盘+TM）
    has_tm = [p for p in plist if (p['atm_fb_uv'] or 0) > 0 and (p['inquiries'] or 0) == 0]  # TM商机榜（纯TM）
    has_ctr = [p for p in plist if (p['total_clk'] or 0) >= 4]
    zero_cost = [p for p in plist if (p['ad_clk'] or 0) == 0 and ((p['opp'] or 0) > 0 or (p['total_clk'] or 0) >= 4)]
    # 高效低耗榜 = 广告商机转化好：有广告点击（真投了广告）且有商机产出（广告钱花得值）
    high_eff = [p for p in plist if (p['ad_clk'] or 0) > 0 and (p['opp'] or 0) > 0]

    # 排序
    has_inq.sort(key=lambda x: -(x['inquiries'] or 0) or -(x['clicks'] or 0))
    has_opp.sort(key=lambda x: -(x['opp'] or 0))
    has_tm.sort(key=lambda x: -(x['atm_fb_uv'] or 0))
    has_ctr.sort(key=lambda x: -(x['ctr'] or 0))
    zero_cost.sort(key=lambda x: -(x['opp'] or 0) or -(x['clicks'] or 0))
    # 高效低耗榜：商机量优先（广告带出的商机越多越好），同商机量按每次广告点击商机效率
    high_eff.sort(key=lambda x: (-(x['opp'] or 0), -((x['opp'] or 0) * 1.0 / max(x['ad_clk'] or 1, 1))))

    return {
        "inquiry": mklist(has_inq[:20]),
        "opp": mklist(has_opp[:50]),
        "tm": mklist(has_tm[:50]),
        "ctr": mklist(has_ctr[:20]),
        "zero_cost": mklist(zero_cost[:20]),
        "high_eff_low_cost": mklist(high_eff[:20]),
    }


lists = build_lists(prods)
# 兼容下游 section_notes 等仍在引用的模块级变量（榜单构造已抽进 build_lists）
zero_cost = [p for p in prods if (p['ad_clk'] or 0) == 0 and ((p['opp'] or 0) > 0 or (p['total_clk'] or 0) >= 4)]

# ---------- 月度口径产品榜（切「月」时前端改读 lists_month） ----------
# 数据来自 product_monthly_stats / _ext，由 v6_fetch_products_monthly.py +
# v6_ingest_products_monthly.py 回填（数据参谋商品接口支持 month 口径）。
prods_m = []
lists_month = None
prods_m = []   # 月口径产品（下面 try 里赋值；失败时保持空，别让后面 NameError）
try:
    _ms_row = r1("SELECT MAX(month_start) AS m FROM product_monthly_stats")
    _ms_month = (_ms_row or {}).get('m')   # 注意 r1 返回 dict，不是元组
    if _ms_month:
        prods_m = rall("""SELECT p.product_id, p.title, p.prod_level, p.moq, p.price_range, p.main_image,
          p.detail_url, p.category_name, p.first_seen_at, p.crt_time,
          ms.impressions, ms.clicks, ms.ctr, ms.inquiries, ms.orders, ms.gmv,
          me.total_imps, me.total_clk, me.ad_imps, me.ad_clk, me.p4p_imps, me.p4p_clk,
          me.mc_fb_uv, me.atm_fb_uv, me.crt_ord, me.rts_online_amt,
          me.sum_show_coc, me.sum_click_coc
          FROM products p
          JOIN product_monthly_stats ms ON ms.product_id=p.product_id AND ms.month_start=?
          LEFT JOIN product_monthly_stats_ext me ON me.product_id=p.product_id AND me.month_start=ms.month_start
          """, (_ms_month,))
        prods_m = [judge(p) for p in prods_m]
        lists_month = build_lists(prods_m)
        lists_month["_month"] = _ms_month
except Exception as _e:
    print("月度产品榜跳过:", _e)

# 产品状态九宫格（4.4：按状态给动作，非单纯排序）
_state_map = {}
for p in prods:
    st = classify_state(p)
    _state_map.setdefault(st, []).append(p)
state_grid = []
for st in STATE_ORDER:
    items = _state_map.get(st, [])
    if not items:
        continue
    # 每状态取 Top3（按商机/点击排序）
    items.sort(key=lambda x: -((x['opp'] or 0) * 10 + (x['total_clk'] or 0)))
    top = [{"product_id": p['product_id'], "title": (p['title'] or '')[:46],
            "total_clk": p['total_clk'], "total_imps": p['total_imps'],
            "opp": p['opp'], "orders": p['orders'], "gmv": p['gmv'],
            "main_image": p['main_image']} for p in items[:3]]
    state_grid.append({"state": st, "name": STATE_NAMES[st], "count": len(items),
                       "action": STATE_ACTIONS[st], "top": top})
lists["state_grid"] = state_grid

# 新品追踪：用 first_seen_at 近 30 天 或 status
newp = rall("""SELECT product_id, title, prod_level, first_seen_at, last_seen_at, main_image, detail_url, moq, price_range
  FROM products WHERE first_seen_at IS NOT NULL ORDER BY first_seen_at DESC LIMIT 50""")
newp_out = []
for p in newp:
    st = rall("SELECT impressions, clicks, ctr, inquiries, gmv FROM product_weekly_stats WHERE product_id=? AND week_end=?", (p['product_id'], WEEK_END))
    ex = rall("SELECT total_imps, total_clk FROM product_weekly_stats_ext WHERE product_id=? AND week_start=?", (p['product_id'], WEEK_START))
    s = st[0] if st else {}
    e = ex[0] if ex else {}
    inq = s.get('inquiries') or 0; tot_clk = e.get('total_clk') or 0
    tot_imps = e.get('total_imps') or 0
    tot_ctr = (tot_clk / tot_imps) if tot_imps else 0
    if inq >= 1: status = "已出询盘·转正"; sty = "good"
    elif tot_clk >= 4: status = "有热度·继续观察"; sty = "info"
    else: status = "冷启动中"; sty = "muted"
    newp_out.append({
        "product_id": p['product_id'], "title": (p['title'] or '')[:60],
        "first_seen_at": p['first_seen_at'], "main_image": p['main_image'],
        "detail_url": p['detail_url'], "moq": p['moq'], "price_range": p['price_range'],
        "total_clk": tot_clk, "total_ctr": pct(tot_ctr), "inquiries": inq,
        "status": status, "sty": sty,
    })
lists["new_product"] = newp_out

# 新品候选池：全部产品（供前端手动勾选「哪些是新品」+ 手改上架日期 + 时间选区）
_cand = rall("""SELECT p.product_id, p.title, p.prod_level, p.first_seen_at, p.main_image, p.category_name, p.moq, p.price_range,
  ps.inquiries, e.total_imps, e.total_clk, e.ad_imps, e.ad_clk, e.atm_fb_uv
  FROM products p
  LEFT JOIN product_weekly_stats ps ON ps.product_id=p.product_id AND ps.week_end=?
  LEFT JOIN product_weekly_stats_ext e ON e.product_id=p.product_id AND e.week_start=?
  ORDER BY (p.first_seen_at IS NULL), p.first_seen_at DESC, (e.total_clk IS NULL), e.total_clk DESC""", (WEEK_END, WEEK_START))
new_candidates = []
for p in _cand:
    inq = p['inquiries'] or 0; tm = p['atm_fb_uv'] or 0
    ti = p['total_imps'] or 0; tc = p['total_clk'] or 0
    new_candidates.append({
        "product_id": p['product_id'], "title": (p['title'] or '')[:60],
        "prod_level": p['prod_level'], "first_seen_at": p['first_seen_at'],
        "main_image": p['main_image'], "category": p['category_name'],
        "moq": p['moq'], "price_range": p['price_range'],
        "total_imps": ti, "total_clk": tc,
        "total_ctr": round((tc / ti * 100) if ti else 0, 2),
        "ad_imps": p['ad_imps'] or 0, "ad_clk": p['ad_clk'] or 0,
        "inquiries": inq, "tm": tm, "opp": inq + tm,
    })

# ---------- 广告拆解 ----------
ad_store = {
    "camp_imps": S['camp_imps'], "camp_clk": S['camp_clk'], "qzt_clk": S['qzt_clk'],
    "p4p_imps": S['p4p_imps'], "p4p_clk": S['p4p_clk'],
    "camp_imps_rival_avg": S['camp_imps_rival_avg'], "camp_clk_rival_avg": S['camp_clk_rival_avg'],
    "camp_imps_rival_good": S['camp_imps_rival_good'], "camp_clk_rival_good": S['camp_clk_rival_good'],
    "note": "计划层（活动/花费/CPC）数据源 UNAVAILABLE，仅店铺级+产品级广告曝光/点击",
}
ad_prod = mklist(sorted([p for p in prods if (p['ad_clk'] or 0) > 0], key=lambda x: -(x['ad_clk'] or 0))[:20])

# ---------- 月度口径（用 data_advisor 30d 全量数据，含全量同行对标 + 环比）----------
from datetime import datetime as _dt, timedelta as _td
def is_complete_month(mend):
    d = _dt.strptime(mend, "%Y-%m-%d")
    nxt = (d.replace(day=28) + _td(days=4)).replace(day=1) - _td(days=1)
    return d == nxt
# 优先用全量月度数据（raw/monthly_full.json），回退到 store_monthly_stats
monthly_full = None
if os.path.exists('raw/monthly_full.json'):
    with open('raw/monthly_full.json', encoding='utf-8') as f:
        monthly_full = json.load(f)

def _mth_to_funnel(M, prev_M=None):
    def _wow(cur, prev):
        if prev in (None, 0) or cur is None: return None
        return round((cur - prev) / abs(prev) * 100, 1)
    def _pct(v): return round(v*100, 2) if v is not None else None
    f = {
        "se_imps": M.get('se_imps'), "se_clk": M.get('se_clk'), "se_ctr": _pct(M.get('se_ctr')),
        "total_imps": M.get('total_imps'), "camp_imps": M.get('camp_imps'), "camp_clk": M.get('camp_clk'),
        "fb_cnt": M.get('fb_cnt'), "fb_uv": M.get('fb_uv'), "fb_tm_uv": M.get('fb_tm_uv'),
        "opp": M.get('ab_cnt'),
        "suc_ord_cnt": M.get('suc_ord_cnt'), "suc_ord_amt": M.get('suc_ord_amt'),
        "uv_cnt": M.get('uv_cnt'), "pv_cnt": M.get('pv_cnt'),
        "uv_ab_rate": _pct(M.get('uv_ab_rate')), "suc_byr_cnt": M.get('suc_byr_cnt'),
        "uv_payord_rate": _pct(M.get('uv_payord_rate')),
        # 全量同行对标
        "se_imps_ra": M.get('se_imps_ra'), "se_imps_rg": M.get('se_imps_rg'),
        "se_clk_ra": M.get('se_clk_ra'), "se_clk_rg": M.get('se_clk_rg'),
        "se_ctr_ra": _pct(M.get('se_ctr_ra')), "se_ctr_rg": _pct(M.get('se_ctr_rg')),
        "total_imps_ra": M.get('total_imps_ra'), "total_imps_rg": M.get('total_imps_rg'),
        "camp_imps_ra": M.get('camp_imps_ra'), "camp_imps_rg": M.get('camp_imps_rg'),
        "camp_clk_ra": M.get('camp_clk_ra'), "camp_clk_rg": M.get('camp_clk_rg'),
        "fb_cnt_ra": M.get('fb_cnt_ra'), "fb_cnt_rg": M.get('fb_cnt_rg'),
        "fb_tm_ra": M.get('fb_tm_ra'), "fb_tm_rg": M.get('fb_tm_rg'),
        "ab_cnt_ra": M.get('ab_cnt_ra'), "ab_cnt_rg": M.get('ab_cnt_rg'),
        "uv_cnt_ra": M.get('uv_cnt_ra'), "uv_cnt_rg": M.get('uv_cnt_rg'),
        "uv_ab_ra": _pct(M.get('uv_ab_ra')), "uv_ab_rg": _pct(M.get('uv_ab_rg')),
        "suc_byr_ra": M.get('suc_byr_ra'), "suc_byr_rg": M.get('suc_byr_rg'),
        "suc_ord_cnt_ra": M.get('suc_ord_cnt_ra'), "suc_ord_cnt_rg": M.get('suc_ord_cnt_rg'),
        "suc_ord_amt_ra": M.get('suc_ord_amt_ra'), "suc_ord_amt_rg": M.get('suc_ord_amt_rg'),
        "uv_payord_ra": _pct(M.get('uv_payord_ra')), "uv_payord_rg": _pct(M.get('uv_payord_rg')),
        "month_label": M['month_start'] + " ~ " + M['month_end'],
        "month_start": M['month_start'], "month_end": M['month_end'],
        # 回复三项：平台只提供「近30天」滚动口径（fstReplyRate30d 等），与周/月窗口无关，
        # 月度视图沿用同一个 30d 值。前端 getBearing() 在月模式下就读这三个键
        # （原包此处没输出，导致月模式下「承接效率」三张卡全空）。
        "avg_reply_time": S.get('avg_reply_time30d'),
        "fst5min": pct(S.get('fst5min_reply_rate30d')),
        "fst_reply_rate": pct(S.get('fst_reply_rate30d')),
        # 承接效率的同行对标（同样是 30d 口径）
        "avg_reply_time_ra": S.get('avg_reply_time30d_rival_avg'),
        "fst5min_ra": pct(S.get('fst5min_reply_rate30d_rival_avg')),
        "fst5min_rg": pct(S.get('fst5min_reply_rate30d_rival_good')),
        "fst_reply_ra": pct(S.get('fst_reply_rate30d_rival_avg')),
        "fst_reply_rg": pct(S.get('fst_reply_rate30d_rival_good')),
        "uv_payord_ra": pct(S.get('uv_payord_rate_rival_avg')),
        "uv_payord_rg": pct(S.get('uv_payord_rate_rival_good')),
    }
    f["wow"] = {
        "se_imps": _wow(M.get('se_imps'), prev_M.get('se_imps') if prev_M else None),
        "se_clk": _wow(M.get('se_clk'), prev_M.get('se_clk') if prev_M else None),
        "se_ctr": _wow(_pct(M.get('se_ctr')), _pct(prev_M.get('se_ctr')) if prev_M else None),
        "total_imps": _wow(M.get('total_imps'), prev_M.get('total_imps') if prev_M else None),
        "camp_imps": _wow(M.get('camp_imps'), prev_M.get('camp_imps') if prev_M else None),
        "camp_clk": _wow(M.get('camp_clk'), prev_M.get('camp_clk') if prev_M else None),
        "fb_cnt": _wow(M.get('fb_cnt'), prev_M.get('fb_cnt') if prev_M else None),
        "fb_tm_uv": _wow(M.get('fb_tm_uv'), prev_M.get('fb_tm_uv') if prev_M else None),
        "opp": _wow((M.get('fb_cnt') or 0) + (M.get('fb_tm_uv') or 0), ((prev_M.get('fb_cnt') or 0) + (prev_M.get('fb_tm_uv') or 0)) if prev_M else None),
        "suc_ord_cnt": _wow(M.get('suc_ord_cnt'), prev_M.get('suc_ord_cnt') if prev_M else None),
        "suc_ord_amt": _wow(M.get('suc_ord_amt'), prev_M.get('suc_ord_amt') if prev_M else None),
        "uv_cnt": _wow(M.get('uv_cnt'), prev_M.get('uv_cnt') if prev_M else None),
        "uv_ab_rate": _wow(_pct(M.get('uv_ab_rate')), _pct(prev_M.get('uv_ab_rate')) if prev_M else None),
        "suc_byr_cnt": _wow(M.get('suc_byr_cnt'), prev_M.get('suc_byr_cnt') if prev_M else None),
        "uv_payord_rate": _wow(_pct(M.get('uv_payord_rate')), _pct(prev_M.get('uv_payord_rate')) if prev_M else None),
    }
    return f
# 月份列表（完整自然月 + MTD）
months_list = []
mth_mtd_funnel = None
if monthly_full:
    keys_sorted = sorted(monthly_full.keys())
    for i, key in enumerate(keys_sorted):
        M = monthly_full[key]
        prev_M = monthly_full[keys_sorted[i-1]] if i > 0 else None
        f = _mth_to_funnel(M, prev_M)
        if is_complete_month(M['month_end']):
            months_list.append(f)
        else:
            mth_mtd_funnel = f
    mth_funnel = months_list[-1] if months_list else None
else:
    mth_funnel = None

# ---------- 趋势对比 ----------
trend_rows = []
for w in wk:
    trend_rows.append({
        "week_end": w['stat_week_end'], "week_start": w['stat_week_start'],
        "se_imps": w['se_imps'], "se_clk": w['se_clk'], "se_ctr": pct(w['se_ctr']),
        "fb_cnt": w['fb_cnt'], "fb_tm_uv": w['fb_tm_uv'], "suc_ord_cnt": w['suc_ord_cnt'],
        "suc_ord_amt": round(w['suc_ord_amt'], 1), "uv_cnt": w['uv_cnt'],
    })

# ---------- 同行标杆 ----------
peers = rall("SELECT * FROM competitor_stores ORDER BY online_revenue DESC LIMIT 10")
peer_out = []
for p in peers:
    peer_out.append({
        "store_name": p['store_name'], "rating": p['rating'], "main_category": p['main_category'],
        "years": p['years_on_alibaba'], "online_revenue": p['online_revenue'],
        "positioning": p['positioning'], "country": p['country'],
    })

# ---------- 行动执行台 ----------
actions = rall("""SELECT id, product_id, action_type, primary_variable, description, recommended_change,
  confidence, status, owner, due_date, source FROM diagnosis_actions ORDER BY id""")
opt = rall("""SELECT product_id, title, primary_action, status, owner, due_date, priority_reason, impact, actionability
  FROM product_optimizations ORDER BY id""")

# ---------- 作战方案（爆品作战方案弹窗数据）----------
def parse_json_field(v):
    if not v: return None
    try: return json.loads(v)
    except: return v

opt_full = rall("SELECT product_id, title, primary_action, buyer_intent, image_brief, detail_modules, candidate_titles, deep_plan_json, status FROM product_optimizations")
war_plans = {}
for o in opt_full:
    pid = o['product_id']
    dp = parse_json_field(o.get('deep_plan_json'))
    ct = parse_json_field(o.get('candidate_titles'))
    war_plans[pid] = {
        "title": o.get('title'),
        "primary_action": o.get('primary_action'),
        "buyer_intent": o.get('buyer_intent'),
        "image_brief": o.get('image_brief'),
        "detail_modules": parse_json_field(o.get('detail_modules')),
        "candidate_titles": ct if isinstance(ct, list) else [],
        "deep_plan": dp if isinstance(dp, dict) else {},
    }

# ---------- 全部周（周选择器，含全量同行对标 + 环比）----------
def _rv(w, k, is_pct=False):
    v = w.get(k)
    if v is None: return None
    return pct(v) if is_pct else (round(v, 1) if isinstance(v, float) else v)
weeks_all = []
for i, w in enumerate(wk):
    prev_w = wk[i-1] if i > 0 else None
    def _wow(cur, prev):
        if prev in (None, 0) or cur is None: return None
        return round((cur - prev) / abs(prev) * 100, 1)
    weeks_all.append({
        "week_end": w['stat_week_end'], "week_start": w['stat_week_start'],
        "se_imps": w['se_imps'], "se_clk": w['se_clk'], "se_ctr": pct(w['se_ctr']),
        "total_imps": w['total_imps'], "camp_imps": w['camp_imps'], "camp_clk": w['camp_clk'],
        "fb_cnt": w['fb_cnt'], "fb_uv": w['fb_uv'], "fb_tm_uv": w['fb_tm_uv'],
        "suc_ord_cnt": w['suc_ord_cnt'], "suc_ord_amt": round(w['suc_ord_amt'], 1),
        "uv_cnt": w['uv_cnt'], "uv_ab_rate": pct(w['uv_ab_rate']),
        "suc_byr_cnt": w['suc_byr_cnt'], "uv_payord_rate": pct(w['uv_payord_rate']),
        "fst5min": pct(w['fst5min_reply_rate30d']),
        "fst_reply": pct(w['fst_reply_rate30d']), "avg_reply": w['avg_reply_time30d'],
        # 全量同行对标
        "se_imps_ra": w['se_imps_rival_avg'], "se_imps_rg": w['se_imps_rival_good'],
        "se_clk_ra": w['se_clk_rival_avg'], "se_clk_rg": w['se_clk_rival_good'],
        "se_ctr_ra": pct(w['se_ctr_rival_avg']), "se_ctr_rg": pct(w['se_ctr_rival_good']),
        "total_imps_ra": w['total_imps_rival_avg'], "total_imps_rg": w['total_imps_rival_good'],
        "camp_imps_ra": w['camp_imps_rival_avg'], "camp_imps_rg": w['camp_imps_rival_good'],
        "camp_clk_ra": w['camp_clk_rival_avg'], "camp_clk_rg": w['camp_clk_rival_good'],
        "uv_cnt_rg": w['uv_cnt_rival_good'], "uv_ab_rate_ra": pct(w['uv_ab_rate_rival_avg']), "uv_ab_rate_rg": pct(w['uv_ab_rate_rival_good']),
        "suc_byr_cnt_rg": w['suc_byr_cnt_rival_good'],
        "suc_ord_cnt_ra": w['suc_ord_cnt_rival_avg'], "suc_ord_cnt_rg": w['suc_ord_cnt_rival_good'],
        "suc_ord_amt_ra": round(w['suc_ord_amt_rival_avg'], 1), "suc_ord_amt_rg": round(w['suc_ord_amt_rival_good'], 1),
        "uv_payord_ra": pct(w['uv_payord_rate_rival_avg']), "uv_payord_rg": pct(w['uv_payord_rate_rival_good']),
        # 环比（上周）
        "wow": {
            "se_imps": _wow(w['se_imps'], prev_w['se_imps'] if prev_w else None),
            "se_clk": _wow(w['se_clk'], prev_w['se_clk'] if prev_w else None),
            "se_ctr": _wow(pct(w['se_ctr']), pct(prev_w['se_ctr']) if prev_w else None),
            "total_imps": _wow(w['total_imps'], prev_w['total_imps'] if prev_w else None),
            "camp_imps": _wow(w['camp_imps'], prev_w['camp_imps'] if prev_w else None),
            "camp_clk": _wow(w['camp_clk'], prev_w['camp_clk'] if prev_w else None),
            "fb_cnt": _wow(w['fb_cnt'], prev_w['fb_cnt'] if prev_w else None),
            "fb_tm_uv": _wow(w['fb_tm_uv'], prev_w['fb_tm_uv'] if prev_w else None),
            "opp": _wow((w['fb_cnt'] or 0) + (w['fb_tm_uv'] or 0), ((prev_w['fb_cnt'] or 0) + (prev_w['fb_tm_uv'] or 0)) if prev_w else None),
            "suc_ord_cnt": _wow(w['suc_ord_cnt'], prev_w['suc_ord_cnt'] if prev_w else None),
            "suc_ord_amt": _wow(w['suc_ord_amt'], prev_w['suc_ord_amt'] if prev_w else None),
            "uv_cnt": _wow(w['uv_cnt'], prev_w['uv_cnt'] if prev_w else None),
            "uv_ab_rate": _wow(pct(w['uv_ab_rate']), pct(prev_w['uv_ab_rate']) if prev_w else None),
            "suc_byr_cnt": _wow(w['suc_byr_cnt'], prev_w['suc_byr_cnt'] if prev_w else None),
            "uv_payord_rate": _wow(pct(w['uv_payord_rate']), pct(prev_w['uv_payord_rate']) if prev_w else None),
        },
    })

# ---------- 板块备注建议（AI 预填，团队可覆盖）----------
def wstr(cur, prev_v):
    if prev_v in (None, 0): return '—'
    v = round((cur - prev_v) / abs(prev_v) * 100, 1)
    return ('+' if v >= 0 else '') + str(v) + '%'

section_notes = {
    "funnel": "本周搜索曝光 %s（同行优秀 %s）、搜索点击 %s、CTR %s%%，询盘 %s 环比 %s。流量规模领先同行，询盘承接是短板——先救转化再谈放量。" % (
        num(S['se_imps']), num(S['se_imps_rival_good']), num(S['se_clk']), pct(S['se_ctr']), num(S['fb_cnt']), wstr(S['fb_cnt'], prev['fb_cnt'])),
    "bearing": "全店极速回复率 %s%% vs 同行优秀 %s%%（落后 %s pp），平均回复 %sh。承接是降星之外第二大隐患，优先给标红客服设个人 KPI。" % (
        pct(S['fst5min_reply_rate30d']), pct(S['fst5min_reply_rate30d_rival_good']), round((S['fst5min_reply_rate30d_rival_good'] or 0)*100 - (S['fst5min_reply_rate30d'] or 0)*100, 1), S['avg_reply_time30d']),
    "staff": "共 %d 名子账号在接待。标红重点：极速回复率低于店均 %s%%、平均回复慢于店均、有超12h未回复的。成交好的人沉淀方法复制给全组。" % (len(staff_out), pct(S['fst5min_reply_rate30d'])),
    "health": "优品 %d / 爆品 %d / 潜力优品 %d，在架 %d。零询盘品 %d（%s%%）。星等级与降星预警详见「星等级」板块。" % (
        lvl_map.get('优品', 0), lvl_map.get('爆品', 0), lvl_map.get('潜力优品', 0), health['valid_cnt'], health['zero_inquiry'], round(health['zero_inquiry']/max(1, health['valid_cnt'])*100, 1)),
    "ad": "",
    "summary": "核心：访客成交率 %s%% vs 同行优秀 %s%%，客单价 $%s（同行优秀 $%s）。本周聚焦：承接提速 + 潜力品冲级 + 保星。" % (
        pct(S['uv_payord_rate']), pct(S['uv_payord_rate_rival_good']),
        num(round((S['suc_ord_amt'] or 0)/max(1, S['suc_ord_cnt'] or 0))),
        num(round((S['suc_ord_amt_rival_good'] or 0)/max(1, S['suc_ord_cnt_rival_good'] or 0)))),
}

# ---------- 星等级（CGS 接口）----------
star_rating = None
if os.path.exists('raw/star_rating_parsed.json'):
    with open('raw/star_rating_parsed.json', encoding='utf-8') as f:
        star_rating = json.load(f)

# ---------- 标杆同行（data_advisor_supplier_selection）----------
peer_benchmark = None
if os.path.exists('raw/peer_benchmark_parsed.json'):
    with open('raw/peer_benchmark_parsed.json', encoding='utf-8') as f:
        peer_benchmark = json.load(f)

# ---------- 竞品深度数据（经营指标+Top20商品+买家画像）----------
competitor_detail = None
if os.path.exists('raw/competitor_detail.json'):
    with open('raw/competitor_detail.json', encoding='utf-8') as f:
        competitor_detail = json.load(f)

# ---------- 国家地区流量效果 ----------
country_region = None
if os.path.exists('raw/country_region.json'):
    with open('raw/country_region.json', encoding='utf-8') as f:
        country_region = json.load(f)

# ---------- 新板块数据（国家行业+渠道+买家L1++关键词+热销品过滤）----------
v4_sections = None
if os.path.exists('raw/v4_sections.json'):
    with open('raw/v4_sections.json', encoding='utf-8') as f:
        v4_sections = json.load(f)

# ---------- 市场原因（verdict）：给市场机会推荐品补「为什么推荐」 ----------
_me = {}
if os.path.exists('raw/market_evidence.json'):
    try:
        with open('raw/market_evidence.json', encoding='utf-8') as f:
            _me = json.load(f)
    except Exception:
        _me = {}

def _reason_for(title, category):
    t = (title or '').lower()
    c = (category or '')
    if '维生素' in c:
        key = 'vitamin'
    elif '胶原' in c:
        key = 'collagen'
    elif '草本' in c:
        if any(w in t for w in ['maca', '玛卡', 'male vitality', 'libido', 'testosterone']):
            key = 'maca'
        elif any(w in t for w in ['detox', 'weight loss', 'slim', '减肥', '瘦']):
            key = 'detox'
        else:
            key = 'generic'
    elif '运动营养' in c or '能量' in c:
        if any(w in t for w in ['coffee', 'caffeine', 'energy', 'isotonic', '咖啡', '能量']):
            key = 'energy'
        else:
            key = 'pro'
    else:
        key = 'generic'
    return _me.get(key, {}).get('verdict', '')

if v4_sections and isinstance(v4_sections.get('hot_products_clean'), list):
    for p in v4_sections['hot_products_clean']:
        if isinstance(p, dict) and not p.get('reason'):
            p['reason'] = _reason_for(p.get('title'), p.get('category'))

# ---------- AI 产品评分 + 竞品 ----------
v4_scores = None
if os.path.exists('raw/v4_scores.json'):
    with open('raw/v4_scores.json', encoding='utf-8') as f:
        v4_scores = json.load(f)

# ---------- 竞品全量（5家供应商 Top20）----------
competitor_full = None
if os.path.exists('raw/competitor_full.json'):
    with open('raw/competitor_full.json', encoding='utf-8') as f:
        competitor_full = json.load(f)

# ---------- 主图视觉诊断（全量 680 品 + B2B/AI适配分析）----------
vision_result = None
if os.path.exists('raw/vision_full.json'):
    with open('raw/vision_full.json', encoding='utf-8') as f:
        vision_result = json.load(f)
elif os.path.exists('raw/vision_result.json'):
    with open('raw/vision_result.json', encoding='utf-8') as f:
        vision_result = json.load(f)

# ---------- 广告计划层（全站推/直通车 report_sql）----------
ad_plans = None
_ads_files = sorted([f for f in os.listdir('raw') if f.startswith('ads_report_') and f.endswith('.json')]) if os.path.isdir('raw') else []
_ads_path = ('raw/' + _ads_files[-1]) if _ads_files else 'raw/ads_report_20260810.json'
if os.path.exists(_ads_path):
    with open(_ads_path, encoding='utf-8') as f:
        ads = json.load(f)
    acc_ws = (ads.get('account') or {}).get('company_whole_site') or []
    acc_sr = (ads.get('account') or {}).get('company_search') or []
    def _frow(r, k, d=0):
        try: return float(r.get(k, d) or d)
        except: return d
    arow = acc_ws[0] if acc_ws else {}
    # 月度账户（老板看板切「月」时用，来自 ads_report 的 month 段）
    _ads_m = ads.get('month') or {}
    _acc_ws_m = (_ads_m.get('account') or {}).get('company_whole_site') or []
    arow_m = _acc_ws_m[0] if _acc_ws_m else {}
    account_month = {
        "spend": _frow(arow_m, '花费'), "clicks": _frow(arow_m, '点击量'),
        "impressions": _frow(arow_m, '曝光量'), "ctr": _frow(arow_m, '点击率'),
        "cpc": _frow(arow_m, '点击成本'), "opp_cnt": _frow(arow_m, '全站商机量'),
        "cpl": _frow(arow_m, '全站商机成本'), "opp_rate": _frow(arow_m, '全站商机转化率'),
        "tm": _frow(arow_m, 'TM咨询量'), "inquiry": _frow(arow_m, '询盘量'),
        "orders": _frow(arow_m, '订单量'), "l1_opp": _frow(arow_m, 'L1+全站商机量'),
        "month_label": ((_ads_m.get('begin') or '') + ' ~ ' + (_ads_m.get('end') or '')) if _ads_m else None,
    }
    account = {
        "spend": _frow(arow, '花费'), "clicks": _frow(arow, '点击量'),
        "impressions": _frow(arow, '曝光量'), "ctr": _frow(arow, '点击率'),
        "cpc": _frow(arow, '点击成本'), "opp_cnt": _frow(arow, '全站商机量'),
        "cpl": _frow(arow, '全站商机成本'), "opp_rate": _frow(arow, '全站商机转化率'),
        "tm": _frow(arow, 'TM咨询量'), "inquiry": _frow(arow, '询盘量'),
        "orders": _frow(arow, '订单量'), "l1_opp": _frow(arow, 'L1+全站商机量'),
    }
    base_cpl = account['cpl'] or 1
    camps = []
    for c in ads.get('campaigns') or []:
        r = (c.get('report_data') or [{}])[0]
        spend = _frow(r, '花费')
        opp = _frow(r, '全站商机量')
        cpl = _frow(r, '全站商机成本')
        if spend <= 0:
            continue
        if opp <= 0:
            j, jt, sug = '烧钱无商机', 'danger', '有花费但0商机，先查落地页承接，再决定是否降预算'
        elif cpl < base_cpl * 0.9:
            j, jt, sug = '相对最优', 'good', '单商机成本 ¥%.0f 低于账户均值 ¥%.0f，可小幅加预算放大' % (cpl, base_cpl)
        elif cpl <= base_cpl * 1.1:
            j, jt, sug = '达标', 'info', '单商机成本 ¥%.0f 与账户均值相当，保持观察' % cpl
        else:
            j, jt, sug = '观察', 'warn', '单商机成本 ¥%.0f 高于账户均值 ¥%.0f，控制预算或优化定向' % (cpl, base_cpl)
        camps.append({
            "id": c['campaign_id'], "name": c['name'], "line": c['line'],
            "budget": _frow(r, '预算', c.get('budget')), "products": c.get('product_count'),
            "spend": spend, "clicks": _frow(r, '点击量'), "cpc": _frow(r, '点击成本'),
            "ctr": _frow(r, '点击率'), "opp_cnt": opp, "cpl": cpl, "opp_rate": _frow(r, '全站商机转化率'),
            "tm": _frow(r, 'TM咨询量'), "inquiry": _frow(r, '询盘量'), "orders": _frow(r, '订单量'),
            "l1_ratio": _frow(r, 'L1+买家点击占比'),
            "judgment": j, "judgment_type": jt, "suggestion": sug,
        })
    camps.sort(key=lambda x: -x['spend'])
    search_on = [c for c in (ads.get('campaigns') or []) if c.get('line') == 'search' and c.get('onlineStatus') != '-2']
    ad_plans = {
        "account": account,
        "account_month": account_month,
        "campaigns": camps,
        "search_note": "直通车 %d 个计划全部暂停（状态-2），本周 0 花费。全站推是当前唯一投放。" % sum(1 for c in (ads.get('campaigns') or []) if c.get('line') == 'search'),
        "total_campaigns": len(ads.get('campaigns') or []),
        "active_campaigns": len(camps),
    }
    # ad 板块备注（数据驱动，不写死金额）
    if ad_plans:
        ac = ad_plans['account']
        _ad = "本周广告花费 ¥%s（全站推），CPC ¥%s，单商机成本 ¥%s，商机转化率 %s%%。" % (
            num(ac.get('spend')), num(ac.get('cpc')), num(ac.get('cpl')), round(ac.get('opp_rate') or 0, 2))
        with_cpl = [c for c in camps if (c.get('cpl') or 0) > 0]
        if len(with_cpl) >= 2:
            best = min(with_cpl, key=lambda x: x['cpl']); worst = max(with_cpl, key=lambda x: x['cpl'])
            _ad += "最优计划 %s（CPL ¥%s），最高 %s（CPL ¥%s）。" % (best['name'], num(best['cpl']), worst['name'], num(worst['cpl']))
        _ad += ad_plans.get('search_note', '')
        section_notes['ad'] = _ad

# 产品级全站推广告（PRODUCT_WHOLE_SITE：直通车暂停=0，全站推有产品级数据）
ad_products = []
_akw_files = sorted([f for f in os.listdir('raw') if f.startswith('ads_kw_') and f.endswith('.json')]) if os.path.isdir('raw') else []
if _akw_files:
    with open('raw/' + _akw_files[-1], encoding='utf-8') as f:
        _akw = json.load(f)
    for r in (_akw.get('product_whole_site') or []):
        try:
            def _iv(v): return int(float(v or 0))
            def _fv(v): return float(v or 0)
            ad_products.append({
                "product_id": r.get('产品ID', ''), "title": (r.get('商品信息') or '')[:60],
                "imps": _iv(r.get('曝光量')), "clk": _iv(r.get('点击量')), "ctr": _fv(r.get('点击率')),
                "inquiries": _iv(r.get('询盘量')), "tm": _iv(r.get('TM咨询量')), "orders": _iv(r.get('订单量')),
                "l1_clk": _iv(r.get('L1+点击量')), "l1_rate": _fv(r.get('L1+买家点击占比')),
                "opp": _iv(r.get('全站商机量')), "opp_rate": _fv(r.get('全站商机转化率')), "l1_opp": _iv(r.get('L1+全站商机量')),
            })
        except Exception:
            pass
    ad_products.sort(key=lambda x: -(x['clk'] or 0))

# ---------- 市场趋势/风口类目（下期动作上新建议）----------
# 优先用「蓝海类目排行」的细分类目（叶子类目级：胶原蛋白/鱼油/辅酶Q10/能量饮料…），
# 比本店主类目「运动营养补给」更细，直接给出可落地的上新方向。
def _fnum(x):
    try: return float(x or 0)
    except Exception: return 0.0

market_trends = []
_blue_path = 'raw/industry_cate_rank_blueocean.json'
if os.path.exists(_blue_path):
    try:
        with open(_blue_path, encoding='utf-8') as f:
            _blue = json.load(f)
        for r in (_blue.get('data') or []):
            _name = (r.get('cateCnName') or '').strip()
            if not _name:
                continue
            market_trends.append({
                "cate_id": r.get('cateId'),
                "name": _name,
                "inquiry_yoy": round(_fnum(r.get('abCntYoy')) * 100, 1),
                "inquiry_30d": int(_fnum(r.get('abCnt'))),
                "supply_demand": round(_fnum(r.get('supplyDemandRate')), 1),
                "conv_rate": round(_fnum(r.get('dAbRate')) * 100, 1),
            })
        market_trends.sort(key=lambda x: -(x['inquiry_yoy'] or 0))
    except Exception:
        market_trends = []

# 回退：无蓝海类目榜时，用 industry_trend 表（本店类目）
if not market_trends:
    cur.execute("SELECT DISTINCT cate_id, category_name FROM products WHERE cate_id IS NOT NULL")
    cate_name = {r['cate_id']: r['category_name'] for r in cur.fetchall() if r['cate_id']}
    industry_rows = rall("SELECT cate_id, period_index, ab_cnt, ab_cnt_yoy, d_ab_rate, supply_demand_rate FROM industry_trend ORDER BY cate_id, period_index")
    trend_by_cate = {}
    for t in industry_rows:
        trend_by_cate.setdefault(t['cate_id'], []).append(t)
    for cid, rows in trend_by_cate.items():
        latest = rows[-1]
        name = cate_name.get(cid) or ('类目' + str(cid))
        market_trends.append({
            "cate_id": cid, "name": name,
            "inquiry_yoy": round(latest['ab_cnt_yoy']*100, 1),
            "inquiry_30d": latest['ab_cnt'],
            "supply_demand": round(latest['supply_demand_rate'], 1),
            "conv_rate": round(latest['d_ab_rate']*100, 1),
        })
    market_trends.sort(key=lambda x: -(x['inquiry_yoy'] or 0))

# 风口类目 = 询盘同比正增长的细分类目（按增速降序，取 Top 10）
hot_categories = [m for m in market_trends if (m['inquiry_yoy'] or 0) > 10][:10]
# 热销品（市场机会）——全部 35 个均为官方热品榜；附原因（见上文 _reason_for）
hot_products = []
for mp in rall("SELECT title, category, price_range, moq, certifications, source, product_url FROM market_products ORDER BY rank LIMIT 12"):
    hot_products.append({
        "title": (mp['title'] or '')[:80], "category": mp['category'],
        "price": mp['price_range'], "moq": mp['moq'],
        "certs": mp['certifications'], "url": mp['product_url'],
        "reason": _reason_for(mp['title'], mp['category']),
    })

# ---------- 补充板块备注（其余板块 AI 预填整体建议）----------
vs = v4_sections or {}
def _set(k, t):
    if t: section_notes[k] = t

cm = vs.get('country_merged') or []
if cm:
    top = sorted(cm, key=lambda x: -(x.get('my_uv') or 0))[:3]
    warn = [x for x in cm if x.get('vcls') == 'warn']
    hy = sorted(cm, key=lambda x: -(x.get('ind_yoy') or 0))[:2]
    _set('country', "主力市场 %s（UV %s，行业询盘 %s、同比 +%s%%）承接达标；%s 行业询盘同比 +%s%% 是增长洼地，值得加预算试探%s" % (
        top[0]['country'], num(top[0].get('my_uv')), num(top[0].get('ind_ab')), round(top[0].get('ind_yoy') or 0, 1),
        hy[0]['country'], round(hy[0].get('ind_yoy') or 0, 1),
        ("。警告：%s 转化略低于行业，优先优化承接" % warn[0]['country']) if warn else ""))

ch = vs.get('channels') or []
if ch:
    biggest = max(ch, key=lambda x: x.get('uv') or 0)
    best_conv = max(ch, key=lambda x: x.get('ab_rate') or 0)
    if biggest['channel'] == best_conv['channel']:
        _set('channel', "流量结构：%s %s UV 占 %s%%、商机率 %s%% 双领先，是绝对主航道，继续放大并优化承接。" % (
            biggest['channel'], num(biggest.get('uv')), round(biggest.get('share') or 0, 1), round(biggest.get('ab_rate') or 0, 1)))
    else:
        _set('channel', "流量结构：%s %s UV 占 %s%% 是最大盘，但商机率仅 %s%% 偏低；%s 商机率 %s%% 最高却只占 %s%% 流量——被低估的高转化渠道，值得加大引导/投放。" % (
            biggest['channel'], num(biggest.get('uv')), round(biggest.get('share') or 0, 1), round(biggest.get('ab_rate') or 0, 1),
            best_conv['channel'], round(best_conv.get('ab_rate') or 0, 1), round(best_conv.get('share') or 0, 1)))

bi = vs.get('buyer_ident') or []
if bi:
    bi = sorted(bi, key=lambda x: -(x.get('l1_rate') or 0))
    _set('buyerl1', "买家结构：%s 占 L1+ 高价值买家 %s%%（全量 %s%%）是绝对主力，%s 次之 %s%%。用 L1+ 画像反推主图/详情卖点，优先打 %s 的采购诉求。" % (
        bi[0]['ident'], round(bi[0].get('l1_rate') or 0, 1), round(bi[0].get('all_rate') or 0, 1),
        bi[1]['ident'], round(bi[1].get('l1_rate') or 0, 1), bi[0]['ident']))

kw = vs.get('keywords') or []
if kw:
    _set('keyword', "关键词机会：%s（指数 %s、增速 +%s%%）是当前最热词，%s 次之。把热词写进标题+详情首屏，喂 AI 搜索匹配。" % (
        kw[0]['kw'], num(kw[0].get('idx')), round(kw[0].get('rate') or 0, 1), kw[1]['kw']))

ze = (v4_scores or {}).get('zero_effect') or []
if ze:
    waste = [x for x in ze if x.get('ze_type') == '曝光浪费']
    sleep = [x for x in ze if x.get('ze_type') == '彻底沉睡']
    _set('zeroeffect', "0效果产品 %d 个：曝光浪费 %d（有曝光无商机，救详情页）+ 彻底沉睡 %d（零曝光，补属性进 AI 池）。优先处理曝光浪费，回报最快。" % (
        len(ze), len(waste), len(sleep)))

_set('opp', "商机榜（询盘+TM 双口径）：%d 个有商机品是成交主力，重点保障承接与库存。榜单支持品类/层级筛选。" % len(lists['opp']))
_set('tm', "TM 商机榜：%d 个纯 TM 咨询品，买家弱意向但没发询盘，安排客服 30 秒内跟报价转询盘。" % len(lists['tm']))
_set('ctr', "点击率榜：%d 个高 CTR 品，主图/标题勾人，重点核对详情页能否接住点击。" % len(lists['ctr']))
_set('zero', "零花费榜：%d 个 0 广告花费但已有商机/点击的品，是自然流量红利，可优先选入全站推放大。" % len(lists['zero_cost']))
_set('eff', "高效低耗榜：%d 个投了广告(有广告点击)且本周出商机的品，广告钱花得值、单商机成本低，是加预算放大优先标的。" % len(lists['high_eff_low_cost']))
_set('newprod', "新品追踪 %d 个（近30天上线）：%d 个已出询盘转正，其余观察/冷启动。新品的核心是『卡在哪个维度』，点评分看五维雷达。" % (
    len(lists['new_product']), sum(1 for x in lists['new_product'] if x.get('status') == '已出询盘·转正')))

if market_trends:
    hc = hot_categories[:3]
    hc_txt = "、".join(["%s(+%s%%)" % (h['name'], h['inquiry_yoy']) for h in hc])
    _set('market', "风口类目（行业询盘同比 >10%%）：%s。%d 个合规热销品可对标上新（已过滤 %d 个擦边品）。上新优先对齐风口类目 + 合规，别碰玛卡/减肥。" % (
        hc_txt, len(vs.get('hot_products_clean') or []), vs.get('banned_count') or 0))

if actions or opt:
    _set('exec', "改造执行台：%d 条诊断动作 + %d 条产品优化，%d 条未处理。每动作含 Why/影响/工作量/负责人/截止日，按 P0/P1/P2 排期，落地后走 Action→Validation→Learning 闭环。" % (
        len(actions), len(opt), sum(1 for o in opt if o.get('status') == '未处理')))

if competitor_full:
    _set('compete', "竞品对比：%d 个真实竞品（已过滤擦边，带图+跳转链接+『好在哪』点评）。对标同类目竞品的价格/MOQ/卖点，找差异化空隙。" % len(competitor_full.get('competitors') or []))

if peer_out:
    _set('peer', "同行标杆：%d 家 Top 同行店铺，可点进跳转看其类目/国家/GMV 表现。重点看营收领先者的主营品类与定位，找到可复制的赛道。" % len(peer_out))

# ---------- 改造执行台：店级任务（哪里缺了补哪里，数据驱动）----------
from datetime import timedelta as _tdm
_due_base = datetime.strptime(advisory, '%Y-%m-%d') if advisory else datetime.now()
_due1 = (_due_base + _tdm(days=7)).strftime('%Y-%m-%d')
_due2 = (_due_base + _tdm(days=14)).strftime('%Y-%m-%d')

_tm = S['fb_tm_uv'] or 0
_fb = S['fb_cnt'] or 0
exec_plan = []

# 1. 流量·试投（店级）
if lists.get('zero_cost'):
    exec_plan.append({"id": "LW-AD", "name": "流量·试投 (店级)", "icon": "💰", "tasks": [{
        "prio": "P1", "field": "零花费上升品小额试投", "cat": "广告",
        "cur": "全店 %d 个零花费品已出商机/高点击（纯自然流量），广告 0 花费——潜力品没给曝光" % len(zero_cost),
        "chg": "给零花费有商机的 Top 品小额试投（全站推），单商机成本可控后再放大",
        "verify": "7天单商机成本 ≤ ¥60 且商机量不降", "status": "待办", "owner": "", "due": _due1}]})

# 2. 上新·提质（店级）
_np = lists.get('new_product') or []
_np_ok = sum(1 for x in _np if x.get('status') == '已出询盘·转正')
if _np:
    exec_plan.append({"id": "LW-NEW", "name": "上新·提质 (店级)", "icon": "NEW", "tasks": [{
        "prio": "P2", "field": "上新从量转质", "cat": "上新",
        "cur": "近30天上新 %d 个，仅 %d 个出询盘转正（%d 个冷启动/观察）" % (len(_np), _np_ok, len(_np) - _np_ok),
        "chg": "直接套 AI搜索作战方案：一次性补齐结构化属性/6主图/视频，聚焦高复购类目",
        "verify": "7天转正新品数增加", "status": "待办", "owner": "", "due": _due2}]})

# 3. 承接·转化（店级）
if _tm > _fb:
    exec_plan.append({"id": "LW-CONV", "name": "承接·转化 (店级)", "icon": "💬", "tasks": [{
        "prio": "P1", "field": "TM池转询盘/成交", "cat": "客服",
        "cur": "TM咨询 %d 次 vs 询盘仅 %d 个——大量 TM 漏在接待，没转成询盘/订单" % (_tm, _fb),
        "chg": "把 TM 池往询盘/成交推：主动报价 + 定制 + 样品，30秒响应",
        "verify": "7天 TM→询盘转化率提升", "status": "待办", "owner": "", "due": _due1}]})

# 4. 保星·放大交易（店级）
if star_rating:
    _tracks = {}
    for _t in (star_rating.get('tracks') or []):
        _tracks[_t.get('track_name')] = _t.get('score')
    _cs = _tracks.get('商机赛道'); _rs = _tracks.get('交易赛道')
    _lvl = star_rating.get('level_star') or 3
    _down = False
    _acp = 0
    for _t in (star_rating.get('tracks') or []):
        if (_t.get('alert') or {}).get('down'):
            _down = True
        for _ind in ((_t.get('alert') or {}).get('indicators') or []):
            if 'ACP' in (_ind.get('name') or ''):
                _acp = _ind.get('value') or 0
    _pred = '预测降星' if _down else '预测保星'
    _grow_tasks = [{
        "prio": "P0", "field": "保星·放大站内交易", "cat": "经营",
        "cur": "当前 %d 星（%s），商机分 %s / 交易分 %s——站内交易量不够撑 4 星" % (_lvl, _pred, (_cs if _cs is not None else '—'), (_rs if _rs is not None else '—')),
        "chg": "靠高复购 + 活跃上新拉站内交易量，把平台商机转信保订单，保星冲 4 星",
        "verify": "7天站内交易额环比增长", "status": "待办", "owner": "", "due": _due2}]
    if _acp == 0:
        _grow_tasks.append({"prio": "P1", "field": "ACP站外第一单", "cat": "经营",
            "cur": "ACP站外交易额 $0，是降星最大短板（拉低 17 分）",
            "chg": "至少完成一单 ACP 站外交易，把 $0 变成非零",
            "verify": "ACP 站外交易额 > $0", "status": "待办", "owner": "", "due": _due1})
    exec_plan.append({"id": "LW-GROW", "name": "保星·放大交易 (店级)", "icon": "⭐", "tasks": _grow_tasks})

# ---------- 本期总结 ----------
dec = r1("SELECT decision_json FROM operator_decisions ORDER BY generated_at DESC LIMIT 1")
summary_dec = json.loads(dec['decision_json']) if dec and dec.get('decision_json') else {}
# P0-3：operator_decisions 为空时，用 exec_plan 的 P0/P1/P2 任务生成 top_actions（数组，含优先级/对象/问题/动作/负责人/验证指标/状态）
if not summary_dec:
    _ta = []
    for _blk in exec_plan:
        for _t in _blk.get('tasks', []):
            _ta.append({
                "prio": _t.get('prio'), "obj": _t.get('field'),
                "problem": _t.get('cur'), "action": _t.get('chg'),
                "owner": _t.get('owner') or '待分配', "verify": _t.get('verify') or '见验证周期',
                "status": _t.get('status') or '待办',
            })
    summary_dec = {"top_actions": _ta}

# ---------- 老板看板 (boss)：老板要看的花费/接待/爆品/新品/成交，混合自动+手动 ----------
from datetime import timedelta as _boss_td
_boss_ac = (ad_plans or {}).get('account') or {}
_boss_ac_m = (ad_plans or {}).get('account_month') or {}   # 月口径广告账户
def _bf(x, d=0):
    try:
        v = float(x or 0)
        return v if v else d
    except (TypeError, ValueError):
        return d
_boss_ad_spend = _bf(_boss_ac.get('spend'))
_boss_cpl = _bf(_boss_ac.get('cpl'))
_boss_total_clk = (S.get('se_clk') or 0) + (S.get('camp_clk') or 0)
# 爆品/优品/潜力优品 数量（平台分级）
_boss_lvl = {}
for p in prods:
    _boss_lvl[p['prod_level']] = _boss_lvl.get(p['prod_level'], 0) + 1
# 平台分级产品榜（爆品/优品/潜力优品 各自全量，按 成交GMV+商机+订单+点击 综合降序）
def _boss_score(p):
    g = p['gmv'] or 0
    o = (p['inquiries'] or 0) + (p['atm_fb_uv'] or 0)
    od = p['orders'] or 0
    c = p['total_clk'] or 0
    return g + o * 200 + od * 400 + c * 2
def _boss_level_list(level):
    cands = [p for p in prods if p['prod_level'] == level]
    cands.sort(key=_boss_score, reverse=True)
    return [{
        "product_id": p['product_id'], "title": (p['title'] or '')[:64],
        "detail_url": p['detail_url'], "main_image": p['main_image'],
        "level": p['prod_level'], "category": p['category_name'],
        "imps": p['total_imps'] or 0, "clicks": p['total_clk'] or 0,
        "inquiries": p['inquiries'] or 0, "tm": p['atm_fb_uv'] or 0,
        "orders": p['orders'] or 0, "gmv": round(p['gmv'] or 0, 2),
    } for p in cands]
boss_hot = _boss_level_list('爆品')
boss_premium = _boss_level_list('优品')
boss_potential = _boss_level_list('潜力优品')
# 新品：判定口径二选一
#   优先用平台创建日 crt_time 近 28 天（真实「新上架」）；
#   没有 crt_time 时才回退 first_seen_at —— 注意：全新库首次建档时所有产品的 first_seen
#   都等于建档当天，会把全店产品误判成新品（实测算出 198 个），所以 crt_time 优先。
_boss_cutoff = (datetime.strptime(WEEK_END, "%Y-%m-%d") - _boss_td(days=28)).strftime("%Y-%m-%d")
if any((p['crt_time'] or '') for p in prods):
    _boss_new = [p for p in prods if p['crt_time'] and p['crt_time'] >= _boss_cutoff]
else:
    _boss_new = [p for p in prods if p['first_seen_at'] and p['first_seen_at'] >= _boss_cutoff]
_boss_new.sort(key=lambda p: (p['total_clk'] or 0), reverse=True)
boss_new = []
for p in _boss_new[:15]:
    boss_new.append({
        "product_id": p['product_id'], "title": (p['title'] or '')[:64],
        "detail_url": p['detail_url'], "main_image": p['main_image'],
        "level": p['prod_level'], "first_seen_at": p['first_seen_at'],
        "crt_time": p['crt_time'],
        "imps": p['total_imps'] or 0, "clicks": p['total_clk'] or 0,
        "inquiries": (p['inquiries'] or 0) + (p['atm_fb_uv'] or 0),
    })
# 产品池：全店所有产品(不再限 Top200)，按总点击降序，供老板看板「新品手动选择器」无差别勾选
_boss_pool = sorted(prods, key=lambda p: (p['total_clk'] or 0), reverse=True)
boss_pool = [{
    "product_id": p['product_id'], "title": (p['title'] or '')[:64],
    "detail_url": p['detail_url'], "main_image": p['main_image'], "level": p['prod_level'],
    "first_seen_at": p['first_seen_at'],
    "imps": p['total_imps'] or 0, "clicks": p['total_clk'] or 0,
    "inquiries": (p['inquiries'] or 0) + (p['atm_fb_uv'] or 0),
    "orders": p['orders'] or 0, "gmv": round(p['gmv'] or 0, 2),
} for p in _boss_pool]
# 月口径产品池：老板看板切「月」时，「新品」区与新品导出改读这份。
# 原来只有周口径（boss_pool），切月后新品表和导出永远是周数据 —— 用户已反馈过。
boss_pool_month = []
try:
    if prods_m:
        _pm = sorted(prods_m, key=lambda p: (p['total_clk'] or 0), reverse=True)
        boss_pool_month = [{
            "product_id": p['product_id'], "title": (p['title'] or '')[:64],
            "detail_url": p['detail_url'], "main_image": p['main_image'], "level": p['prod_level'],
            "first_seen_at": p['first_seen_at'],
            "imps": p['total_imps'] or 0, "clicks": p['total_clk'] or 0,
            "inquiries": (p['inquiries'] or 0) + (p['atm_fb_uv'] or 0),
            "orders": p['orders'] or 0, "gmv": round(p['gmv'] or 0, 2),
        } for p in _pm]
except Exception as _e:
    print("月度产品池跳过:", _e)
_bm = months_list[-1] if months_list else {}   # 最新完整月（老板看板切「月」时改读这份）
boss = {
    "week_label": WEEK_START + " ~ " + WEEK_END,
    "month_label": _bm.get('month_label'),
    "kpi": {  # 自动：流量/成交/接待
        "total_imps": S.get('total_imps'), "total_clk": _boss_total_clk,
        "se_clk": S.get('se_clk'), "camp_clk": S.get('camp_clk'), "uv_cnt": S.get('uv_cnt'),
        "inquiries": S.get('fb_cnt'), "tm_inquiries": S.get('fb_tm_uv'),
        "orders": S.get('suc_ord_cnt'), "gmv": S.get('suc_ord_amt'),
        "reply_rate": S.get('fst_reply_rate30d'), "reply_5min": S.get('fst5min_reply_rate30d'),
        "avg_reply_time": S.get('avg_reply_time30d'), "valid_prod": S.get('valid_prod_cnt'),
    },
    # 月口径 KPI：前端 renderBoss 在 PERIOD==='month' 时改读这份，
    # 否则会出现「顶部卡片是周数据、下面漏斗是月数据」的同屏混口径。
    "kpi_month": {
        "total_imps": _bm.get('total_imps'),
        "total_clk": (_bm.get('se_clk') or 0) + (_bm.get('camp_clk') or 0),
        "se_clk": _bm.get('se_clk'), "camp_clk": _bm.get('camp_clk'), "uv_cnt": _bm.get('uv_cnt'),
        "inquiries": _bm.get('fb_cnt'), "tm_inquiries": _bm.get('fb_tm_uv'),
        "orders": _bm.get('suc_ord_cnt'), "gmv": _bm.get('suc_ord_amt'),
        # 回复三项平台只有 30d 口径，周/月共用
        "reply_rate": S.get('fst_reply_rate30d'), "reply_5min": S.get('fst5min_reply_rate30d'),
        "avg_reply_time": S.get('avg_reply_time30d'), "valid_prod": S.get('valid_prod_cnt'),
    },
    "spend": {  # 广告花费/成本（自动，全站推；拿不到计划层 spend 时回退到店铺级广告曝光/点击）
        "ad_spend": _boss_ad_spend, "ad_spend_auto": _boss_ad_spend > 0,
        "ad_cpc": (_bf(_boss_ac.get('cpc')) or None), "ad_cpl": (_boss_cpl or None),
        "ad_clicks": (_bf(_boss_ac.get('clicks')) or _bf(S.get('camp_clk'))),
        "ad_imps": (_bf(_boss_ac.get('impressions')) or _bf(S.get('camp_imps'))),
        "ad_opp": _bf(_boss_ac.get('opp_cnt')),
    },
    # 月口径广告花费（切「月」时前端改读这份，否则顶部卡片仍是周花费）
    "spend_month": {
        "ad_spend": _bf(_boss_ac_m.get('spend')), "ad_spend_auto": _bf(_boss_ac_m.get('spend')) > 0,
        "ad_cpc": (_bf(_boss_ac_m.get('cpc')) or None), "ad_cpl": (_bf(_boss_ac_m.get('cpl')) or None),
        "ad_clicks": _bf(_boss_ac_m.get('clicks')), "ad_imps": _bf(_boss_ac_m.get('impressions')),
        "ad_opp": _bf(_boss_ac_m.get('opp_cnt')),
    },
    "manual": {  # 运营手动填写（前端 localStorage 覆盖；此为其默认/上次提交值）
        "quality_customers": 0, "cac": None, "sample_orders": 0,
        "other_spend": 0, "ad_spend_override": None, "new_selection": [],
        # 以下键对齐 templates/v4/app.js（V7.3/V7.4 前端读这些键；
        # 原包数据层未输出，前端取到 undefined → Number(undefined||0)=0，导致卡片显示 0）
        "acquisition": 0,               # 获客数量（获客成本分母，运营填）
        "annual_fee": 0, "wendin": 0, "topshow": 0, "brand_ad": 0,   # 年费/问鼎/顶展/品牌广告
        "new_count": len(_boss_new),    # 新品数量：默认填系统自动候选数，运营可在录入区改写
        "sample_products": "", "order_products": "",
    },
    "hot_products": boss_hot,
    "premium_products": boss_premium,
    "potential_products": boss_potential,
    "hot_count": _boss_lvl.get('爆品', 0),
    "premium_count": _boss_lvl.get('优品', 0),
    "potential_count": _boss_lvl.get('潜力优品', 0),
    "new_products": boss_new,
    "new_count": len(_boss_new),
    "product_pool": boss_pool,
    "product_pool_month": boss_pool_month,
}

data = {
    "meta": {
        "store_name": store_meta.get('name',''), "store_id": store_meta.get('store_id',''),
        "week_label": WEEK_START + " ~ " + WEEK_END, "week_start": WEEK_START, "week_end": WEEK_END,
        "prev_week_end": PREV_END, "advisory_date": advisory,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    },
    "funnel": funnel,
    "bearing": bearing,
    "monthly": mth_funnel,
    "monthly_mtd": mth_mtd_funnel,
    "months": months_list,
    "staff_cs": staff_out,
    "store_avg_5min": store_avg_5min, "store_avg_reply": store_avg_reply,
    "health": health,
    "lists": lists,
    "lists_month": lists_month,
    "new_candidates": new_candidates,
    "ad": {"store": ad_store, "products": ad_prod},
    "trend": trend_rows,
    "weeks": weeks_all,
    "peers": peer_out,
    "actions": actions,
    "optimizations": opt,
    "exec_plan": exec_plan,
    "company_capabilities": json.load(open('raw/company_capabilities.json', encoding='utf-8')) if os.path.exists('raw/company_capabilities.json') else {},
    "ad_products": ad_products[:50],
    "war_plans": war_plans,
    "section_notes": section_notes,
    "stores": [{"name": store_meta.get('name',''), "store_id": store_meta.get('store_id','')}],
    "star_rating": star_rating,
    "ad_plans": ad_plans,
    "peer_benchmark": peer_benchmark,
    "competitor_detail": competitor_detail,
    "country_region": country_region,
    "v4_sections": v4_sections,
    "v4_scores": v4_scores,
    "competitor_full": competitor_full,
    "vision_result": vision_result,
    "market_trends": market_trends,
    "hot_categories": hot_categories,
    "hot_products": hot_products,
    "boss": boss,
    "summary": summary_dec,
}

with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=1)

print("\n=== v4_data.json 生成完成 ===")
print("funnel KPI 数:", len(funnel))
print("staff 子账号数:", len(staff_out))
print("榜单: 询盘=%d TM=%d CTR=%d 零花费=%d 高效低耗=%d 新品=%d" % (
    len(lists['inquiry']), len(lists['tm']), len(lists['ctr']),
    len(lists['zero_cost']), len(lists['high_eff_low_cost']), len(lists['new_product'])))
print("广告产品数:", len(ad_prod), "| 同行:", len(peer_out), "| actions:", len(actions))
# 打印几个样本校验
print("\n--- 漏斗样本 ---")
for f in funnel[:4]:
    print(f"{f['label']}: cur={f['cur']} wow={f['wow']}% rival_avg={f['rival_avg']} rival_good={f['rival_good']} gap_good={f['gap_good']}")
print("\n--- 客服子账号样本 ---")
for s in staff_out[:5]:
    print(f"{s['name']}: TM={s['tm']} 询盘PV={s['fb_pv']} 成交={s['rcvd_amt']} 极速={s['fst5min']}% 及时={s['reply_rate']}% 回复={s['avg_reply']}h 超12h={s['over12h']}")
