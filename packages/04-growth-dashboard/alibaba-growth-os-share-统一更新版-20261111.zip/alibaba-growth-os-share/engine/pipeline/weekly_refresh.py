# -*- coding: utf-8 -*-
"""每周二 T+2 周更：拉最新完整周大盘 + 月度MTD → 回填 DB → 跑 V6 管线
用法: python weekly_refresh.py
"""
import subprocess, json, io, sys, os, sqlite3
from datetime import date, timedelta
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

ROOT = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(ROOT, 'raw')
DB = os.path.join(ROOT, 'database', 'alibaba_growth.db')
os.makedirs(RAW, exist_ok=True)

def mcp_call(tool, payload_obj):
    pfile = os.path.join(RAW, '_tmp_w.json')
    with open(pfile, 'w', encoding='utf-8') as f:
        json.dump(payload_obj, f, ensure_ascii=False)
    r = subprocess.run(['accio-mcp-cli', 'call', tool, '--json-file', pfile],
                       capture_output=True, text=True, encoding='utf-8', errors='replace',
                       timeout=180, shell=True)
    out = r.stdout or ''
    i = out.find('{')
    if i >= 0:
        try:
            return json.loads(out[i:])
        except Exception:
            pass
    return {}

def num(v):
    if v is None or v == "" or v == "null":
        return None
    try:
        f = float(v)
        return int(f) if f == int(f) else f
    except (TypeError, ValueError):
        return None

def latest_complete_week(advisory_date):
    # 最新完整自然周：周一~周日，week_end <= advisory_date
    d = date.fromisoformat(advisory_date)
    sunday = d - timedelta(days=d.weekday() + 1)  # 本周日
    if sunday > d:
        sunday = sunday - timedelta(days=7)
    monday = sunday - timedelta(days=6)
    return monday.isoformat(), sunday.isoformat()

def main():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    try:
        cur = c.cursor()
        cur.execute("SELECT value FROM meta WHERE key='advisory_date'")
        row = cur.fetchone()
        advisory = row['value'] if row else '2026-08-21'
        ws, we = latest_complete_week(advisory)
        print(f"advisory={advisory} 最新完整周 {ws} ~ {we}")

        # 1. 拉最新完整周大盘（7d）
        resp = mcp_call('data_advisor_shop_summary',
                        {"advisorQueryParam": {"statisticsType": "7d", "startDate": ws, "endDate": we}})
        if resp.get('data'):
            r = resp['data'][0]
            exists = cur.execute("SELECT 1 FROM store_weekly_stats WHERE stat_week_end=?", (we,)).fetchone()
            if exists:
                print(f"周 {we} 已存在，跳过")
            else:
                cur.execute(
                    """INSERT OR REPLACE INTO store_weekly_stats
                       (stat_week_end, stat_week_start, total_imps, se_imps, se_clk, se_ctr,
                        camp_imps, camp_clk, pv_cnt, uv_cnt, uv_ab_rate, suc_ord_cnt, suc_ord_amt, suc_byr_cnt,
                        valid_prod_cnt, top_prod_cnt, fb_cnt, fb_uv, fb_tm_uv,
                        fst_reply_rate30d, fst5min_reply_rate30d, avg_reply_time30d, uv_payord_rate,
                        se_imps_rival_avg, se_imps_rival_good, suc_ord_amt_rival_avg, suc_ord_amt_rival_good, raw_json)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (we, ws,
                     num(r.get("totalImpsCnt")), num(r.get("seImpsCnt")), num(r.get("seClkCnt")), num(r.get("seCtr")),
                     num(r.get("campImpsCnt")), num(r.get("campClkCnt")),
                     num(r.get("pvCnt")), num(r.get("uvCnt")), num(r.get("uvAbRate")),
                     num(r.get("sucOrdCnt")), num(r.get("sucOrdAmt")), num(r.get("sucByrCnt")),
                     num(r.get("validProdCnt")), num(r.get("topProdCnt")),
                     num(r.get("fbCnt")), num(r.get("fbUv")), num(r.get("fbTmUv")),
                     num(r.get("fstReplyRate30d")), num(r.get("fst5minReplyRate30d")),
                     num(r.get("avgReplyTime30d")), num(r.get("uvPayordRate")),
                     num(r.get("seImpsCntRivalAvg")), num(r.get("seImpsCntRivalGood")),
                     num(r.get("sucOrdAmtRivalAvg")), num(r.get("sucOrdAmtRivalGood")),
                     json.dumps(r, ensure_ascii=False)))
                c.commit()
                print(f"已写入周 {we}: 曝光 {r.get('seImpsCnt')} 询盘 {r.get('fbCnt')} GMV {r.get('sucOrdAmt')}")
        else:
            print("最新周大盘拉取失败（可能 T+2 未到）")

        # 2. 跑 V6 管线（月度+竞品+评分+建看板，跳过图片）
        print("=== 跑 V6 管线 ===")
        r = subprocess.run(['python', 'weekly_update.py', '--skip-images'],
                           capture_output=True, text=True, encoding='utf-8', errors='replace',
                           timeout=1800, shell=True, cwd=ROOT)
        print((r.stdout or '')[-600:])
        if r.returncode != 0:
            print("管线非零退出码:", r.returncode)
            return 1
        print("=== 周更完成 ===")
        return 0
    finally:
        c.close()

if __name__ == '__main__':
    raise SystemExit(main())
