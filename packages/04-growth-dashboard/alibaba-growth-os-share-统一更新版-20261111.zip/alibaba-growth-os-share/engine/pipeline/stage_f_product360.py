"""stage_f_product360.py — Stage F Product 360° Intelligence（680 全量 profile + Top20 多因素选择）。

A-J 十块数据驱动聚合；Top20 按 Business Impact/Tier/GMV/曝光/询盘/订单/Peer Gap/Buyer Intent/Market/Actionability
多因素评分（不只 CTR）。Root Cause 输出 causal_confidence。
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent / "database" / "alibaba_growth.db"


def main() -> int:
    conn = sqlite3.connect(str(DB))
    conn.row_factory = sqlite3.Row
    try:
        # 竞品匹配索引
        comp_map = {}
        for r in conn.execute("SELECT * FROM competitor_products WHERE match_our_product IS NOT NULL"):
            comp_map.setdefault(r["match_our_product"], []).append(dict(r))
        # 店级买家画像
        buyer = []
        for r in conn.execute("SELECT * FROM customer_profile_snapshot WHERE dimension='byr_identity' AND byr_growth_level=''"):
            p = json.loads(r["payload_json"])
            buyer = p[0].get("byr_identity", []) if p else []
        # 行业最新信号
        ind = conn.execute("SELECT * FROM industry_trend ORDER BY period_index DESC LIMIT 1").fetchone()
        market = dict(ind) if ind else {}
        # 热词（机会发现）
        hot_kw = "creatine|creatine monohydrate|creatine gummies"  # ALIBABA_OFFICIAL opportunity_discovery
        # 深度方案
        opts = {r["product_id"]: dict(r) for r in conn.execute("SELECT * FROM product_optimizations")}

        conn.executescript("""
        CREATE TABLE IF NOT EXISTS product_360_profile (
            product_id TEXT PRIMARY KEY,
            profile_json TEXT,
            generated_at TEXT DEFAULT (datetime('now')),
            profile_version TEXT DEFAULT 'v1.2'
        );
        CREATE TABLE IF NOT EXISTS top20_candidates (
            rank INTEGER, product_id TEXT, score REAL,
            factors_json TEXT, PRIMARY KEY (rank, product_id)
        );
        """)
        rows = conn.execute(
            """SELECT p.product_id, p.title, p.prod_level, p.price_range, p.moq, p.detail_url, p.category_name,
                      w.impressions, w.clicks, w.ctr, w.inquiries, w.orders, w.gmv,
                      e.atm_fb_uv, e.mc_fb_uv, e.ad_imps, e.ad_clk, e.p4p_imps, e.p4p_clk,
                      e.sum_show_coc AS coc_show, e.sum_click_coc AS coc_click
               FROM products p
               JOIN product_weekly_stats w ON w.product_id=p.product_id AND w.week_start=(SELECT MAX(week_start) FROM product_weekly_stats)
               LEFT JOIN product_weekly_stats_ext e ON e.product_id=p.product_id AND e.week_start=(SELECT MAX(week_start) FROM product_weekly_stats)
               ORDER BY p.product_id""").fetchall()

        profiles = []
        scored = []
        for r in rows:
            pid = r["product_id"]
            o = opts.get(pid)
            comps = comp_map.get(pid, [])
            # E. Buyer（店级画像 + AI 推断 Query）
            buyer_types = [{"type": b["byrIdentity"], "rate": float(b.get("visitorRate", 0))} for b in buyer[:3]]
            # G. Market 关联（按品类关键词映射，AI_INFERENCE 标注）
            title = (r["title"] or "").lower()
            cluster = "creatine" if "creatine" in title else ("collagen" if "collagen" in title
                     else ("caffeine" if "caffeine" in title or "energy" in title
                     else ("electrolyte" if "electrolyte" in title or "rehydration" in title
                     else ("pre workout" if "pre workout" in title else "other"))))
            # 多因素评分（Business Impact / Tier / GMV / 曝光 / 询盘 / 订单 / Peer Gap / Buyer Intent / Market / Actionability）
            tier_w = {"爆品": 5, "优品": 4, "潜力优品": 3, "普通品": 1, "低质品": 0}.get(r["prod_level"], 1)
            gmv_w = min((r["gmv"] or 0) / 50, 5)
            inq_w = min((r["inquiries"] or 0) * 1.5, 5)
            ord_w = min((r["orders"] or 0) * 2, 5)
            imp_w = min((r["impressions"] or 0) / 800, 5)
            dec_w = 3 if (r["coc_show"] is not None and r["coc_show"] < 0.8) else 0
            buyer_w = 2 if buyer_types else 0
            market_w = 3 if cluster in ("creatine", "collagen") else 1.5  # ALIBABA_OFFICIAL 热词/高增长类目
            comp_w = min(len(comps) * 1.5, 3)
            has_opt_w = 2 if o else 0
            score = (tier_w * 1.2 + gmv_w + inq_w + ord_w + imp_w * 0.5 + dec_w + buyer_w + market_w + comp_w + has_opt_w)
            if (r["impressions"] or 0) < 50:
                score *= 0.3  # 无流量产品降低优化优先级
            scored.append((pid, score, {
                "tier": r["prod_level"], "gmv": r["gmv"], "inquiries": r["inquiries"],
                "orders": r["orders"], "impressions": r["impressions"], "declining": bool(dec_w),
                "cluster": cluster, "competitors": len(comps), "has_plan": bool(o),
            }))

            profile = {
                "A_alibaba_official": {
                    "product_id": pid, "official_tier": r["prod_level"], "category": r["category_name"],
                    "publish_date": "UNAVAILABLE", "status": "active(官方在架)",
                },
                "B_performance": {
                    "impressions": r["impressions"], "clicks": r["clicks"], "ctr": r["ctr"],
                    "visitor": "UNAVAILABLE(产品级访客)", "inquiries": r["inquiries"], "tm": r["atm_fb_uv"],
                    "opportunity": (r["inquiries"] or 0) + (r["atm_fb_uv"] or 0),
                    "orders": r["orders"], "gmv": r["gmv"], "paid_imps": r["ad_imps"], "paid_clks": r["ad_clk"],
                },
                "C_historical": {
                    "note": "产品级 4/8/12W 随增量同步累积",
                    "exposure_coc": r["coc_show"], "click_coc": r["coc_click"],
                },
                "D_peer": {
                    "peer_average_store_level": "见 store_weekly_stats(店级, 不冒充产品级)",
                    "peer_excellent_store_level": "见 store_weekly_stats",
                    "product_peer": [{"product_id": c["product_id"], "store": None, "relevance": c["relevance"]}
                                     for c in comps],
                    "product_peer_note": "真实产品级同行: 见 competitor_products",
                },
                "E_buyer": {
                    "buyer_types": buyer_types,
                    "buyer_queries_ai": [{"query": hot_kw.split("|")[0], "source": "ALIBABA_OFFICIAL 热词, AI_INFERENCE 匹配"}],
                    "b2b_intent": "AI_INFERENCE: 基于买家身份结构推断",
                },
                "F_listing": {
                    "title": r["title"], "price_range": r["price_range"], "moq": r["moq"],
                    "detail_url": r["detail_url"], "images/video/attributes": "详见 Listing 实读(深度方案)",
                },
                "G_market": {
                    "cluster": cluster,
                    "market_signal": {"ab_cnt": market.get("ab_cnt"), "ab_cnt_yoy": market.get("ab_cnt_yoy"),
                                      "supply_demand_rate": market.get("supply_demand_rate"),
                                      "source": "ALIBABA_OFFICIAL industry_trend"},
                    "hot_keywords": hot_kw.split("|")[:3], "hot_kw_source": "ALIBABA_OFFICIAL opportunity_discovery",
                },
                "H_competitor": {
                    "matched": [{"product_id": c["product_id"], "title": (c["title"] or "")[:60],
                                 "moq": c["moq"], "price": c["price_range"], "relevance": c["relevance"],
                                 "observed_gap": c["observed_gap"]} for c in comps],
                },
                "I_diagnosis": {
                    "root_cause": (o or {}).get("root_cause"),
                    "causal_confidence": "high" if (o or {}).get("confidence") == "high" else "medium",
                    "priority": "P1" if o else None,
                },
                "J_optimization": {
                    "has_deep_plan": bool(o and o.get("deep_plan_json")),
                    "primary_action": (o or {}).get("primary_action"),
                    "status": (o or {}).get("status", "未处理"),
                    "validation": (o or {}).get("validation_metric"),
                },
            }
            profiles.append((pid, json.dumps(profile, ensure_ascii=False)))
        conn.executemany("INSERT OR REPLACE INTO product_360_profile (product_id, profile_json) VALUES (?,?)", profiles)
        # Top20
        top20 = sorted(scored, key=lambda x: -x[1])[:20]
        conn.execute("DELETE FROM top20_candidates")
        conn.executemany("INSERT INTO top20_candidates (rank, product_id, score, factors_json) VALUES (?,?,?,?)",
                         [(i + 1, pid, round(s, 1), json.dumps(f, ensure_ascii=False))
                          for i, (pid, s, f) in enumerate(top20)])
        conn.commit()
        print(json.dumps({
            "profiles_generated": len(profiles),
            "top20": [{"rank": i + 1, "product_id": pid, "score": round(s, 1)} for i, (pid, s, f) in enumerate(top20)],
            "top20_with_deep_plan": sum(1 for pid, s, f in top20 if opts.get(pid, {}).get("deep_plan_json")),
        }, ensure_ascii=False, indent=1))
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
