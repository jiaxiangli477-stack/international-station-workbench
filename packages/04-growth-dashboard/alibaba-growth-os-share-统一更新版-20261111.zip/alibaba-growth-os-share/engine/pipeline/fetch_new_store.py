# -*- coding: utf-8 -*-
"""新店初始化拉数：周/月大盘 + 产品全量分页 → raw/ (完整 MCP 响应)
用法: python fetch_new_store.py [--as-of YYYY-MM-DD] [--no-products] [--weeks N]

时间窗口动态计算（gos_window）：默认 as_of=今天，按 T+2/自然周规则取最近 N 个完整周 + 基础月 + MTD。
算出的窗口写入 raw/_window.json，供 init_store.py 读取同一窗口，保证 fetch 与 init 对齐。
产品全量始终取「最新完整周(W1)」，文件名前缀固定 w1_（表示最新周）。
"""
import subprocess, json, io, sys, os, argparse
from datetime import date
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import gos_window

ROOT = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(ROOT, 'raw')
os.makedirs(RAW, exist_ok=True)


def build_window(as_of: date, n_weeks: int):
    """返回 (WEEKS, MONTHS) 列表 [(start,end,tag),...]，WEEKS 旧→新，MONTHS=[base, mtd]。"""
    w = gos_window.compute(as_of, n_weeks)
    weeks = [(x['week_start'], x['week_end'], x['tag']) for x in reversed(w['weeks'])]  # 旧→新
    months = [(m['month_start'], m['month_end'], m['tag']) for m in w['months']]
    return weeks, months, w

def mcp_call(tool, payload_obj):
    pfile = os.path.join(RAW, '_tmp_args.json')
    with open(pfile, 'w', encoding='utf-8') as f:
        json.dump(payload_obj, f, ensure_ascii=False)
    r = subprocess.run(['accio-mcp-cli', 'call', tool, '--json-file', pfile],
                       capture_output=True, text=True, encoding='utf-8', errors='replace',
                       timeout=180, shell=True)
    out = r.stdout or ''
    parsed = None
    try:
        parsed = json.loads(out)
    except Exception as e:
        i = out.find('{')
        if i >= 0:
            try:
                parsed = json.loads(out[i:])
            except Exception:
                pass
        if parsed is None:
            return {"_raw": out[:500], "_stderr": (r.stderr or '')[:500], "_err": str(e)}

    # [本机补丁 2026-10-27] 网关偶发 success!=true / 401 抖动，退避重试最多 3 次
    attempt = 0
    while isinstance(parsed, dict) and parsed.get('success') is not True and attempt < 3:
        attempt += 1
        import time
        time.sleep(2 * attempt)
        try:
            r = subprocess.run(['accio-mcp-cli', 'call', tool, '--json-file', pfile],
                               capture_output=True, text=True, encoding='utf-8', errors='replace',
                               timeout=180, shell=True)
        except Exception:
            continue
        out = r.stdout or ''
        try:
            parsed = json.loads(out)
        except Exception:
            i = out.find('{')
            if i >= 0:
                try:
                    parsed = json.loads(out[i:])
                except Exception:
                    pass
    return parsed

def save(name, obj):
    p = os.path.join(RAW, name + '.json')
    with open(p, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False)
    return p

def fetch_summary(stat_type, start, end, tag):
    resp = mcp_call('data_advisor_shop_summary',
                    {"advisorQueryParam": {"statisticsType": stat_type, "startDate": start, "endDate": end}})
    save(f'shop_summary_{tag}', resp)
    d = (resp.get('data') or [{}])
    r0 = d[0] if isinstance(d, list) and d else (d if isinstance(d, dict) else {})
    ok = resp.get('success')
    print(f"[summary {tag}] ok={ok} seImps={r0.get('seImpsCnt')} fb={r0.get('fbCnt')} tm={r0.get('fbTmUv')} gmv={r0.get('sucOrdAmt')}")

def fetch_products(start, end):
    # W1（最新完整周）产品效果，按询盘降序分页，每页 20，最多 50 页
    all_rows = {}
    total = 0
    for page in range(1, 51):
        payload = {"shopProductQueryParam": {
            "statisticsType": "week", "startDate": start, "endDate": end,
            "orderBy": "inquiries", "order": "desc",
            "pageNo": page, "pageSize": 20, "terminalType": "TOTAL"}}
        resp = mcp_call('data_advisor_shop_product', payload)
        d = (resp.get('data') or {}) if isinstance(resp, dict) else {}
        cnt = d.get('recordCount') or 0
        rows = d.get('data') or []
        total = cnt if cnt else total
        # 保存原始响应（分页）
        save(f'shop_product_w1_p{page:02d}', resp)
        for r in rows:
            all_rows[str(r.get('id'))] = r
        print(f"[product page {page}] {len(rows)} rows (累计 {len(all_rows)})")
        if len(rows) < 20:
            break
    print(f"[product] total={total} fetched={len(all_rows)}")
    return all_rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--as-of', default=os.environ.get('GOS_AS_OF') or date.today().isoformat(),
                    help='数据截至日(YYYY-MM-DD)，默认今天。每周二 T+2 跑时填当天即可。')
    ap.add_argument('--weeks', type=int, default=4, help='拉几个完整自然周，默认 4')
    ap.add_argument('--no-products', action='store_true')
    args = ap.parse_args()

    as_of = date.fromisoformat(args.as_of)
    WEEKS, MONTHS, win = build_window(as_of, args.weeks)
    print("=== 动态时间窗口 (as_of=%s) ===" % as_of)
    for s, e, t in WEEKS:
        print("  %s ~ %s  [%s]" % (s, e, t))
    for s, e, t in MONTHS:
        print("  %s ~ %s  [%s]" % (s, e, t))

    # 写入窗口供 init_store.py 读取（保证 fetch 与 init 用同一窗口）
    with open(os.path.join(RAW, '_window.json'), 'w', encoding='utf-8') as f:
        json.dump(win, f, ensure_ascii=False, indent=1)

    print("\n=== 拉取周度大盘 (7d) ===")
    for start, end, tag in WEEKS:
        fetch_summary("7d", start, end, tag)

    print("\n=== 拉取月度大盘 (30d) ===")
    for start, end, tag in MONTHS:
        fetch_summary("30d", start, end, tag)

    if not args.no_products:
        print("\n=== 拉取产品全量分页 (最新完整周) ===")
        from pathlib import Path
        sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
        from dashboard_native_week import collect_all
        cfg=json.load(open(os.path.join(ROOT,'stores.json'),encoding='utf-8'))
        store=cfg['stores'][cfg['active']]['store_id']
        collect_all(Path(ROOT),store,mcp_call)  # MULTI_WEEK_PRODUCTS_V1

    print("DONE")

if __name__ == '__main__':
    main()
