# -*- coding: utf-8 -*-
"""每周二 YH 店周更（双店架构）：
在 YH 环境跑拉数→入库→评分→合并，生成 dashboard_data_yh.js（YH），
全程不动 dashboard_data.js（莱华仕）。结束后恢复莱华仕环境并推送部署。
用法: python weekly_full.py
"""
import subprocess, json, os, sys, io, shutil, datetime
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ROOT, 'database', 'alibaba_growth.db')
RAW = os.path.join(ROOT, 'raw')
YH_BACKUP = os.path.join(ROOT, '_backup_yh_store_20260825')
DB_LW = os.path.join(ROOT, 'database', 'alibaba_growth_lifeworth.db')
RAW_LW = os.path.join(ROOT, 'raw_lifeworth_backup2')

def run(cmd, timeout=900):
    print(">>> " + cmd)
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                       encoding='utf-8', errors='replace', timeout=timeout, cwd=ROOT)
    out = (r.stdout or '') + (r.stderr or '')
    for line in out.strip().splitlines()[-3:]:
        print("   ", line)
    return r.returncode

def encrypt_yh():
    """把 v4_data.json（YH）加密为 dashboard_data_yh.js"""
    import base64, hashlib
    from Crypto.Cipher import AES
    data = json.load(open(os.path.join(ROOT, 'v4_data.json'), encoding='utf-8'))
    raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    key = hashlib.sha256(os.environ.get('GOS_DASHBOARD_PASSWORD', 'Lifeworth123456').encode()).digest()
    nonce = os.urandom(12)
    c = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ct, tag = c.encrypt_and_digest(raw)
    enc = base64.b64encode(nonce + ct + tag).decode('ascii')
    with open(os.path.join(ROOT, 'dashboard', 'dashboard_data_yh.js'), 'w', encoding='utf-8') as f:
        f.write('window.V4_DATA_ENCRYPTED_YH = ' + json.dumps(enc) + ';\n')
    print(">>> dashboard_data_yh.js 已生成", os.path.getsize(os.path.join(ROOT, 'dashboard', 'dashboard_data_yh.js')))

def setup_yh_env():
    """切换为 YH 环境（备份莱华仕，装入 YH 库+raw）"""
    if os.path.exists(DB):
        shutil.copy2(DB, DB_LW)
    if os.path.exists(RAW):
        if os.path.exists(RAW_LW):
            shutil.rmtree(RAW_LW)
        os.rename(RAW, RAW_LW)
    shutil.copy2(os.path.join(YH_BACKUP, 'alibaba_growth_yh.db'), DB)
    shutil.copytree(os.path.join(YH_BACKUP, 'raw'), RAW)

def restore_lw_env():
    """恢复莱华仕环境"""
    if os.path.exists(DB_LW):
        shutil.copy2(DB_LW, DB)
    if os.path.exists(RAW_LW):
        if os.path.exists(RAW):
            shutil.rmtree(RAW)
        os.rename(RAW_LW, RAW)

def deploy():
    """git push 部署"""
    run('git add -A && git commit -m "YH周更 %s" --allow-empty && git push' %
        datetime.date.today().isoformat(), timeout=180)
    return 0

def main():
    try:
        print("== [1/7] 切换 YH 环境 ==")
        setup_yh_env()
        print("== [2/7] 拉最新周数据 ==")
        run('python fetch_new_store.py', timeout=500)
        print("== [3/7] 入库 ==")
        run('python stage_b_load.py', timeout=180)
        print("== [4/7] 客服/同行/星等级 ==")
        run('python fetch_staff.py && python v4_ingest_staff.py', timeout=200)
        run('python fetch_peers.py && python v4_ingest_peer.py', timeout=120)
        print("== [5/7] 评分 + 合并 ==")
        run('python v4_score.py', timeout=300)
        run('python v4_judge.py', timeout=180)
        print("== [6/7] 生成 YH 数据文件 ==")
        encrypt_yh()
    finally:
        print("== 恢复莱华仕环境 ==")
        restore_lw_env()
    print("== [7/7] 部署 ==")
    deploy()
    print("完成：YH 已更新到最新周，莱华仕未动")

if __name__ == '__main__':
    main()
