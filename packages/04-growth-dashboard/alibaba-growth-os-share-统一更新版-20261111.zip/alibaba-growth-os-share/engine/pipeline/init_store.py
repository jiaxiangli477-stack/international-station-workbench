# -*- coding: utf-8 -*-
"""
init_store.py — 新店建库回填（通用版，取代一次性硬编码的 load_new_store.py）

作用：
  按 schema.sql + 扩展 DDL 建空 SQLite，回填 store 身份 + 周/月大盘 + 产品全量。
  全部日期/文件名取自 raw/_window.json（由 fetch_new_store.py 动态写入）或 --as-of 现算，
  店铺身份（名称/ali_id/类目/cate_id）取自 stores.json。零写死，换人换店即自动适配。
  占位符由参数量自动生成（_ph），杜绝「N values for M columns」错位。

用法:
  python init_store.py                     # active 店铺 + raw/_window.json 窗口
  python init_store.py --store yh          # 指定 stores.json 里的某店
  python init_store.py --as-of 2026-09-09  # 无 _window.json 时现算窗口
"""
import json, sqlite3, sys, io, os, argparse
from datetime import date, datetime
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import gos_window

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ROOT, 'database', 'alibaba_growth.db')
RAW = os.path.join(ROOT, 'raw')


def _ph(params):
    """按参数量生成 SQL 占位符串，保证与列数一致。"""
    return ','.join(['?'] * len(params))


def find_schema():
    cands = [
        os.path.join(ROOT, 'schema.sql'),
        os.path.join(ROOT, 'alibaba-growth-os', 'schema.sql'),
        os.path.normpath(os.path.join(ROOT, 'pipeline', '..', 'schema.sql')),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), 'schema.sql'),
    ]
    for c in cands:
        if os.path.exists(c):
            return c
    raise SystemExit("找不到 schema.sql（应随包提供 alibaba-growth-os/schema.sql）")


def load_store_conf(store_key):
    conf_p = os.path.join(ROOT, 'stores.json')
    if os.path.exists(conf_p):
        conf = json.load(open(conf_p, encoding='utf-8'))
        stores = conf.get('stores', {})
        key = store_key or conf.get('active')
        if key in stores:
            return stores[key]
    return {'key': store_key or 'store', 'name': store_key or '未命名店铺',
            'full_name': store_key or '未命名店铺', 'store_id': '',
            'category': '', 'cate_id': None}


def load_raw(name):
    p = os.path.join(RAW, name)
    if not os.path.exists(p):
        return None
    raw = open(p, 'rb').read()
    if raw[:2] == b'\xff\xfe':
        return json.loads(raw.decode('utf-16'))
    if raw[:3] == b'\xef\xbb\xbf':
        return json.loads(raw.decode('utf-8-sig'))
    return json.loads(raw.decode('utf-8'))


def num(v, default=None):
    if v is None or v == "" or v == "null":
        return default
    try:
        f = float(v)
        return int(f) if f == int(f) else f
    except (TypeError, ValueError):
        return default


def get_window(args):
    wp = os.path.join(RAW, '_window.json')
    if os.path.exists(wp):
        return json.load(open(wp, encoding='utf-8'))
    return gos_window.compute(date.fromisoformat(args.as_of), args.weeks)


EXT_DDL = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS store_weekly_stats (
    stat_week_end TEXT PRIMARY KEY, stat_week_start TEXT,
    total_imps INTEGER, se_imps INTEGER, se_clk INTEGER, se_ctr REAL,
    camp_imps INTEGER, camp_clk INTEGER, qzt_clk INTEGER, p4p_imps INTEGER, p4p_clk INTEGER,
    pv_cnt INTEGER, uv_cnt INTEGER, uv_ab_rate REAL,
    suc_ord_cnt INTEGER, suc_ord_amt REAL, suc_byr_cnt INTEGER, crt_ord_cnt INTEGER,
    add_cart_cnt INTEGER, valid_prod_cnt INTEGER, top_prod_cnt INTEGER,
    fb_cnt INTEGER, fb_uv INTEGER, fb_tm_uv INTEGER,
    fst_reply_rate30d REAL, fst5min_reply_rate30d REAL, avg_reply_time30d REAL,
    uv_payord_rate REAL,
    total_imps_rival_avg INTEGER, total_imps_rival_good INTEGER,
    se_imps_rival_avg INTEGER, se_imps_rival_good INTEGER,
    se_clk_rival_avg INTEGER, se_clk_rival_good INTEGER,
    se_ctr_rival_avg REAL, se_ctr_rival_good REAL,
    camp_imps_rival_avg INTEGER, camp_imps_rival_good INTEGER,
    camp_clk_rival_avg INTEGER, camp_clk_rival_good INTEGER,
    uv_cnt_rival_good INTEGER, pv_cnt_rival_good INTEGER,
    uv_ab_rate_rival_avg REAL, uv_ab_rate_rival_good REAL,
    suc_ord_cnt_rival_avg INTEGER, suc_ord_cnt_rival_good INTEGER,
    suc_ord_amt_rival_avg REAL, suc_ord_amt_rival_good REAL,
    suc_byr_cnt_rival_good INTEGER, crt_ord_cnt_rival_avg INTEGER, crt_ord_cnt_rival_good INTEGER,
    top_prod_cnt_rival_avg INTEGER, top_prod_cnt_rival_good INTEGER,
    valid_prod_cnt_rival_avg INTEGER, valid_prod_cnt_rival_good INTEGER,
    fst_reply_rate30d_rival_avg REAL, fst_reply_rate30d_rival_good REAL,
    fst5min_reply_rate30d_rival_avg REAL, fst5min_reply_rate30d_rival_good REAL,
    avg_reply_time30d_rival_avg REAL,
    uv_payord_rate_rival_avg REAL, uv_payord_rate_rival_good REAL,
    raw_json TEXT);
CREATE TABLE IF NOT EXISTS store_monthly_stats (
    month_start TEXT PRIMARY KEY, month_end TEXT,
    total_imps INTEGER, se_imps INTEGER, se_clk INTEGER, se_ctr REAL,
    camp_imps INTEGER, camp_clk INTEGER,
    pv_cnt INTEGER, uv_cnt INTEGER, uv_ab_rate REAL,
    suc_ord_cnt INTEGER, suc_ord_amt REAL, suc_byr_cnt INTEGER,
    valid_prod_cnt INTEGER, top_prod_cnt INTEGER,
    fst_reply_rate30d REAL, fst5min_reply_rate30d REAL, avg_reply_time30d REAL,
    total_imps_rival_avg INTEGER, total_imps_rival_good INTEGER,
    suc_ord_amt_rival_avg REAL, suc_ord_amt_rival_good REAL,
    raw_json TEXT);
CREATE TABLE IF NOT EXISTS product_weekly_stats_ext (
    product_id TEXT NOT NULL, week_start TEXT NOT NULL,
    total_imps INTEGER, total_clk INTEGER,
    ad_imps INTEGER, ad_clk INTEGER, p4p_imps INTEGER, p4p_clk INTEGER,
    atm_fb_uv INTEGER, mc_fb_uv INTEGER, fav INTEGER, cmp INTEGER, share INTEGER,
    crt_ord INTEGER, rts_online_amt REAL, byr_cnt_online_rts INTEGER,
    sum_show_coc REAL, sum_click_coc REAL, sum_visitor_coc REAL,
    PRIMARY KEY (product_id, week_start));
CREATE TABLE IF NOT EXISTS customer_profile_snapshot (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_date TEXT, nd TEXT, byr_growth_level TEXT, dimension TEXT, payload_json TEXT);
CREATE TABLE IF NOT EXISTS service_diag_snapshot (
    stats_date TEXT PRIMARY KEY, buyer_type INTEGER,
    reply_time REAL, five_min_reply_rate REAL, buyer_rnr_rate REAL,
    buyer_ab3_rate REAL, evaluation_score REAL,
    reply_time_avg REAL, five_min_reply_rate_avg REAL, buyer_rnr_rate_avg REAL,
    buyer_ab3_rate_avg REAL, evaluation_score_avg REAL,
    five_min_reply_rate_20th REAL, buyer_rnr_rate_20th REAL,
    buyer_ab3_rate_20th REAL, evaluation_score_20th REAL,
    buyer_has_trans_rate REAL, buyer_nrl_num INTEGER, remind_open_acct_num INTEGER,
    raw_json TEXT);
CREATE TABLE IF NOT EXISTS industry_trend (
    cate_id INTEGER NOT NULL, period_index INTEGER NOT NULL,
    ab_cnt INTEGER, ab_cnt_yoy REAL, supply_demand_rate REAL, d_ab_rate REAL,
    raw_json TEXT, PRIMARY KEY (cate_id, period_index));
CREATE TABLE IF NOT EXISTS diagnosis_actions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    product_id TEXT, action_type TEXT NOT NULL, primary_variable TEXT,
    description TEXT NOT NULL, data_evidence TEXT, before_snapshot TEXT,
    recommended_change TEXT, validation_metric TEXT, validation_period_days INTEGER,
    ai_inference INTEGER NOT NULL DEFAULT 1, confidence TEXT,
    status TEXT NOT NULL DEFAULT 'suggested', source TEXT);
CREATE TABLE IF NOT EXISTS product_optimizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    product_id TEXT NOT NULL, title TEXT, why_selected TEXT, current_problem TEXT,
    data_evidence TEXT, self_history TEXT, peer_gap TEXT, buyer_intent TEXT,
    listing_gap TEXT, root_cause TEXT, primary_action TEXT, secondary_actions TEXT,
    do_not_do TEXT, validation_metric TEXT, validation_period TEXT,
    candidate_titles TEXT, image_brief TEXT, attributes_gap TEXT, detail_modules TEXT,
    ai_inference INTEGER NOT NULL DEFAULT 1, confidence TEXT,
    listing_read INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS idx_po_prod ON product_optimizations(product_id);
CREATE INDEX IF NOT EXISTS idx_da_prod ON diagnosis_actions(product_id);
"""

# 周度大盘：列 → 原始字段映射（保持与看板口径一致）
WEEKLY_COLS = [
    "stat_week_end", "stat_week_start",
    "total_imps", "se_imps", "se_clk", "se_ctr",
    "camp_imps", "camp_clk", "qzt_clk", "p4p_imps", "p4p_clk",
    "pv_cnt", "uv_cnt", "uv_ab_rate",
    "suc_ord_cnt", "suc_ord_amt", "suc_byr_cnt", "crt_ord_cnt",
    "add_cart_cnt", "valid_prod_cnt", "top_prod_cnt",
    "fb_cnt", "fb_uv", "fb_tm_uv",
    "fst_reply_rate30d", "fst5min_reply_rate30d", "avg_reply_time30d", "uv_payord_rate",
    "total_imps_rival_avg", "total_imps_rival_good",
    "se_imps_rival_avg", "se_imps_rival_good",
    "se_clk_rival_avg", "se_clk_rival_good",
    "se_ctr_rival_avg", "se_ctr_rival_good",
    "camp_imps_rival_avg", "camp_imps_rival_good",
    "camp_clk_rival_avg", "camp_clk_rival_good",
    "uv_cnt_rival_good", "pv_cnt_rival_good",
    "uv_ab_rate_rival_avg", "uv_ab_rate_rival_good",
    "suc_ord_cnt_rival_avg", "suc_ord_cnt_rival_good",
    "suc_ord_amt_rival_avg", "suc_ord_amt_rival_good",
    "suc_byr_cnt_rival_good", "crt_ord_cnt_rival_avg", "crt_ord_cnt_rival_good",
    "top_prod_cnt_rival_avg", "top_prod_cnt_rival_good",
    "valid_prod_cnt_rival_avg", "valid_prod_cnt_rival_good",
    "fst_reply_rate30d_rival_avg", "fst_reply_rate30d_rival_good",
    "fst5min_reply_rate30d_rival_avg", "fst5min_reply_rate30d_rival_good",
    "avg_reply_time30d_rival_avg",
    "uv_payord_rate_rival_avg", "uv_payord_rate_rival_good", "raw_json",
]
WEEKLY_SRC = [
    None, None,
    "totalImpsCnt", "seImpsCnt", "seClkCnt", "seCtr",
    "campImpsCnt", "campClkCnt", "qztClkCnt", "p4pImpsCnt", "p4pClkCnt",
    "pvCnt", "uvCnt", "uvAbRate",
    "sucOrdCnt", "sucOrdAmt", "sucByrCnt", "crtOrdCnt",
    "addCartCnt", "validProdCnt", "topProdCnt",
    "fbCnt", "fbUv", "fbTmUv",
    "fstReplyRate30d", "fst5minReplyRate30d", "avgReplyTime30d", "uvPayordRate",
    "totalImpsCntRivalAvg", "totalImpsCntRivalGood",
    "seImpsCntRivalAvg", "seImpsCntRivalGood",
    "seClkCntRivalAvg", "seClkCntRivalGood",
    "seCtrRivalAvg", "seCtrRivalGood",
    "campImpsCntRivalAvg", "campImpsCntRivalGood",
    "campClkCntRivalAvg", "campClkCntRivalGood",
    "uvCntRivalGood", "pvCntRivalGood",
    "uvAbRateRivalAvg", "uvAbRateRivalGood",
    "sucOrdCntRivalAvg", "sucOrdCntRivalGood",
    "sucOrdAmtRivalAvg", "sucOrdAmtRivalGood",
    "sucByrCntRivalGood", "crtOrdCntRivalAvg", "crtOrdCntRivalGood",
    "topProdCntRivalAvg", "topProdCntRivalGood",
    "validProdCntRivalAvg", "validProdCntRivalGood",
    "fstReplyRate30dRivalAvg", "fstReplyRate30dRivalGood",
    "fst5minReplyRate30dRivalAvg", "fst5minReplyRate30dRivalGood",
    "avgReplyTime30dRivalAvg",
    "uvPayordRateRivalAvg", "uvPayordRateRivalGood", None,
]

MONTHLY_COLS = [
    "month_start", "month_end",
    "total_imps", "se_imps", "se_clk", "se_ctr",
    "camp_imps", "camp_clk",
    "pv_cnt", "uv_cnt", "uv_ab_rate",
    "suc_ord_cnt", "suc_ord_amt", "suc_byr_cnt",
    "valid_prod_cnt", "top_prod_cnt",
    "fst_reply_rate30d", "fst5min_reply_rate30d", "avg_reply_time30d",
    "total_imps_rival_avg", "total_imps_rival_good",
    "suc_ord_amt_rival_avg", "suc_ord_amt_rival_good", "raw_json",
]
MONTHLY_SRC = [
    None, None,
    "totalImpsCnt", "seImpsCnt", "seClkCnt", "seCtr",
    "campImpsCnt", "campClkCnt",
    "pvCnt", "uvCnt", "uvAbRate",
    "sucOrdCnt", "sucOrdAmt", "sucByrCnt",
    "validProdCnt", "topProdCnt",
    "fstReplyRate30d", "fst5minReplyRate30d", "avgReplyTime30d",
    "totalImpsCntRivalAvg", "totalImpsCntRivalGood",
    "sucOrdAmtRivalAvg", "sucOrdAmtRivalGood", None,
]


def _row(r, cols, srcs, overrides):
    vals = []
    for col, src in zip(cols, srcs):
        if col in overrides:
            vals.append(overrides[col])
        elif src is None:
            vals.append(None)
        else:
            vals.append(num(r.get(src)))
    return vals


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--store', default=None, help='stores.json 里的店铺 key；默认用 active')
    ap.add_argument('--as-of', default=os.environ.get('GOS_AS_OF') or date.today().isoformat())
    ap.add_argument('--weeks', type=int, default=4)
    args = ap.parse_args()

    st = load_store_conf(args.store)
    store_name = st.get('full_name') or st.get('name')
    store_aliid = st.get('store_id') or ''
    main_category = st.get('category') or ''
    cate_id = st.get('cate_id')
    win = get_window(args)
    weeks = win['weeks']
    months = win['months']
    as_of = win.get('as_of') or args.as_of
    w1 = weeks[0]
    w1_start, w1_end = w1['week_start'], w1['week_end']

    print("=== init_store ===")
    print("店铺: %s | ali_id=%s | cate_id=%s" % (store_name, store_aliid, cate_id))
    print("窗口: as_of=%s, W1=%s~%s" % (as_of, w1_start, w1_end))

    os.makedirs(os.path.dirname(DB), exist_ok=True)
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    try:
        conn.executescript(open(find_schema(), encoding='utf-8').read())
        conn.executescript(EXT_DDL)

        existing = {r[1] for r in conn.execute("PRAGMA table_info(products)").fetchall()}
        for col, ddl in [
            ("prod_level", "ALTER TABLE products ADD COLUMN prod_level TEXT"),
            ("detail_url", "ALTER TABLE products ADD COLUMN detail_url TEXT"),
            ("category_name", "ALTER TABLE products ADD COLUMN category_name TEXT"),
            ("cate_id", "ALTER TABLE products ADD COLUMN cate_id INTEGER"),
            ("moq", "ALTER TABLE products ADD COLUMN moq INTEGER"),
            ("price_range", "ALTER TABLE products ADD COLUMN price_range TEXT"),
            ("crt_time", "ALTER TABLE products ADD COLUMN crt_time TEXT"),      # 产品在平台的创建日
            ("main_image", "ALTER TABLE products ADD COLUMN main_image TEXT"),  # 主图 URL（v6_fetch_imgs 回填）
        ]:
            if col not in existing:
                conn.execute(ddl)

        conn.execute(
            """INSERT INTO store (id, name, store_id, currency, timezone)
               VALUES (1, ?, ?, 'USD', 'Asia/Shanghai')
               ON CONFLICT(id) DO UPDATE SET name=excluded.name,
                   store_id=excluded.store_id, updated_at=datetime('now')""",
            (store_name, store_aliid))
        meta = {
            "schema_version": "1.0-stageA+stageB", "store_binding": store_aliid,
            "store_name": store_name, "main_category": main_category,
            "cate_id": str(cate_id) if cate_id is not None else "",
            "advisory_date": as_of,
            "initialized_at": datetime.now().isoformat(timespec="seconds"),
            "data_source": "alibaba-data-advisor-official-mcp", "timezone": "Asia/Shanghai",
        }
        conn.executemany("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                         [(k, str(v)) for k, v in meta.items()])

        # 周度大盘
        wcols = ','.join(WEEKLY_COLS)
        wsql = "INSERT OR REPLACE INTO store_weekly_stats (%s) VALUES (%s)" % (wcols, _ph(WEEKLY_COLS))
        for w in weeks:
            d = load_raw("shop_summary_%s.json" % w['tag'])
            if not d or not d.get("data"):
                print("[warn] missing %s" % w['tag']); continue
            r = d["data"][0]
            vals = _row(r, WEEKLY_COLS, WEEKLY_SRC, {
                "stat_week_end": w['week_end'], "stat_week_start": w['week_start'],
                "raw_json": json.dumps(r, ensure_ascii=False)})
            conn.execute(wsql, vals)

        # 月度大盘
        mcols = ','.join(MONTHLY_COLS)
        msql = "INSERT OR REPLACE INTO store_monthly_stats (%s) VALUES (%s)" % (mcols, _ph(MONTHLY_COLS))
        for m in months:
            d = load_raw("shop_summary_%s.json" % m['tag'])
            if not d or not d.get("data"):
                print("[warn] missing %s" % m['tag']); continue
            r = d["data"][0]
            vals = _row(r, MONTHLY_COLS, MONTHLY_SRC, {
                "month_start": m['month_start'], "month_end": m['month_end'],
                "raw_json": json.dumps(r, ensure_ascii=False)})
            conn.execute(msql, vals)

        # 产品主档 + 周表现（最新完整周 W1 全量分页）
        prod_rows, wk_rows = [], []
        for pg in range(1, 300):
            fname = "shop_product_w1_p%02d.json" % pg
            d = load_raw(fname)
            if not d or not d.get("data"):
                continue
            items = d["data"].get("data") or []
            if not items:
                continue
            for it in items:
                pid = str(it.get("id"))
                prod_rows.append((pid, it.get("prodName") or it.get("subject") or "",
                                  it.get("cateName"), num(it.get("categoryId")),
                                  it.get("priceRange") or it.get("price"),
                                  num(it.get("minOrderQuantity")), it.get("prodLevel3"),
                                  it.get("detailUrl") or it.get("productDetailUrl"),
                                  (it.get("crtTime") or "")[:10] or None))
                wk_rows.append((
                    pid,                                 # 0
                    num(it.get("sumProdShowNum")),        # 1 impressions
                    num(it.get("sumProdClickNum")),       # 2 clicks
                    num(it.get("sumProdClickRate")),      # 3 ctr
                    num(it.get("sumProdFbNum")),          # 4 inquiries
                    num(it.get("mcFbUv")),                # 5 mc 商机 uv
                    num(it.get("crtOrd")),                # 6 orders
                    num(it.get("rtsOnlineAmt")),          # 7 gmv
                    num(it.get("totalImpsCnt")),          # 8
                    num(it.get("totalClkCnt")),           # 9
                    num(it.get("adImpsCnt")),             # 10
                    num(it.get("adClkCnt")),              # 11
                    num(it.get("p4pImpsCnt")),            # 12
                    num(it.get("p4pClkCnt")),             # 13
                    num(it.get("atmFbUv")),               # 14
                    num(it.get("fav")),                   # 15
                    num(it.get("cmp")),                   # 16
                    num(it.get("sumProdShowNumCoc")),     # 17
                    num(it.get("sumProdClickNumCoc")),    # 18
                    num(it.get("sumProdVisitorCntCoc")),  # 19
                    num(it.get("byrCntOnlineRts")),       # 20
                ))
        conn.executemany(
            "INSERT OR REPLACE INTO products (product_id, title, category, price, status,"
            " first_seen_at, last_seen_at, crt_time) VALUES (?,?,?,?,?,?,?,?)",
            [(p[0], p[1], p[2], p[4], p[6], w1_start, w1_end, p[8]) for p in prod_rows])
        conn.executemany(
            "UPDATE products SET category_name=?, cate_id=?, price_range=?, moq=?, prod_level=?, detail_url=?, crt_time=? WHERE product_id=?",
            [(p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[0]) for p in prod_rows])

        conn.executemany(
            "INSERT OR REPLACE INTO product_weekly_stats"
            " (product_id, week_start, week_end, impressions, clicks, ctr, inquiries, orders, gmv)"
            " VALUES (?,?,?,?,?,?,?,?,?)",
            [(w[0], w1_start, w1_end, w[1], w[2], w[3], w[4], w[6], w[7]) for w in wk_rows])
        conn.executemany(
            "INSERT OR REPLACE INTO product_weekly_stats_ext"
            " (product_id, week_start, total_imps, total_clk, ad_imps, ad_clk, p4p_imps, p4p_clk,"
            "  atm_fb_uv, mc_fb_uv, fav, cmp, crt_ord, rts_online_amt, byr_cnt_online_rts,"
            "  sum_show_coc, sum_click_coc, sum_visitor_coc)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            [(w[0], w1_start, w[8], w[9], w[10], w[11], w[12], w[13], w[14], w[5], w[15], w[16],
              w[6], w[7], w[20], w[17], w[18], w[19]) for w in wk_rows])

        conn.execute(
            "INSERT INTO sync_log (source, records, status, message, finished_at)"
            " VALUES ('alibaba-data-advisor-official-mcp', ?, 'success', ?, datetime('now'))",
            (len(prod_rows), "新店初始化: %d周+%d月, 产品 %d 条, as_of %s" % (len(weeks), len(months), len(prod_rows), as_of)))

        conn.commit()
        checks = {
            "integrity_check": conn.execute("PRAGMA integrity_check").fetchone()[0],
            "store": tuple(conn.execute("SELECT name, store_id FROM store WHERE id=1").fetchone()),
            "products": conn.execute("SELECT COUNT(*) FROM products").fetchone()[0],
            "product_weekly": conn.execute("SELECT COUNT(*) FROM product_weekly_stats").fetchone()[0],
            "product_weekly_ext": conn.execute("SELECT COUNT(*) FROM product_weekly_stats_ext").fetchone()[0],
            "store_weekly": conn.execute("SELECT COUNT(*) FROM store_weekly_stats").fetchone()[0],
            "store_monthly": conn.execute("SELECT COUNT(*) FROM store_monthly_stats").fetchone()[0],
        }
        print(json.dumps(checks, ensure_ascii=False, indent=1, default=str))
        fk = conn.execute("PRAGMA foreign_key_check").fetchall()
        print("foreign_key_check:", "PASS" if not fk else fk)
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
