# -*- coding: utf-8 -*-
"""
V4 T1: 拉取子账号客服周度数据（data_advisor_account_summary）并聚合聊天质检，入库。
"""
import subprocess, json, os, sys, io
from datetime import date, timedelta
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 最近 4 个完整自然周（动态计算，不写死日期）
def _last_weeks(n=4):
    t = date.today()
    dow = (t.weekday() + 1) % 7  # Sunday=0
    sun = t - timedelta(days=dow)
    if sun >= t: sun -= timedelta(days=7)
    out = []
    for i in range(n):
        e = sun - timedelta(days=7 * i)
        s = e - timedelta(days=6)
        out.append((s.isoformat(), e.isoformat(), e.isoformat()))
    return list(reversed(out))

WEEKS = _last_weeks(4)

def call_account_summary(start, end):
    tmp = os.path.join(os.environ.get('TEMP', '/tmp'), 'acc_staff_%d.json' % os.getpid())
    payload = json.dumps({"accountQueryParam": {"statisticsType": "week", "startDate": start, "endDate": end}})
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write(payload)
    try:
        r = subprocess.run(['accio-mcp-cli', 'call', 'data_advisor_account_summary', '--json-file', tmp],
                           capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120, shell=True)
        out = r.stdout or ''
        i = out.find('{')
        j = out.rfind('}')
        if i < 0 or j < 0:
            print("  NO JSON for %s~%s: %s" % (start, end, out[:200]))
            return None
        return json.loads(out[i:j+1])
    finally:
        try: os.remove(tmp)
        except: pass

all_raw = {}
for start, end, week_end in WEEKS:
    print("Fetch %s ~ %s ..." % (start, end))
    resp = call_account_summary(start, end)
    if not resp or not resp.get('data'):
        print("  empty")
        continue
    # data[0] = { date: [staff,...] }
    d0 = resp['data'][0] if resp['data'] else {}
    for date, staffs in d0.items():
        all_raw[date] = staffs
        print("  date=%s staffs=%d" % (date, len(staffs)))

# 保存原始
os.makedirs('raw', exist_ok=True)
with open('raw/cs_account_summary_weeks.json', 'w', encoding='utf-8') as f:
    json.dump(all_raw, f, ensure_ascii=False, indent=1)
print("saved raw/cs_account_summary_weeks.json  dates=%d" % len(all_raw))

# 展平到 (week 归属) 结构 —— 按日期归到周
def week_of(date_str):
    # date like 2026-08-15
    from datetime import datetime, timedelta
    d = datetime.strptime(date_str, "%Y-%m-%d")
    wd = d.weekday()  # 0=Mon
    ws = (d - timedelta(days=wd)).strftime("%Y-%m-%d")
    we = (d + timedelta(days=6-wd)).strftime("%Y-%m-%d")
    return ws, we

flatten = []
for date, staffs in all_raw.items():
    ws, we = week_of(date)
    for s in staffs:
        flatten.append({
            "week_start": ws, "week_end": we, "snap_date": date,
            "full_name": s.get("fullName", ""),
            "reply_rate": s.get("replyRate"),
            "fst5min_reply_rate": s.get("fst5minReplyRate30d"),
            "avg_reply_time": s.get("replyAvgTime") or s.get("avgReplyTime"),
            "fb_pv": s.get("fbPv"),
            "fb_uv": s.get("fbUv"),
            "uv_fb_atm": s.get("uvFbAtm"),
            "rcvd_amt": s.get("rcvdAmt"),
            "order_cnt": (s.get("prepayMordCnt") or 0) + (s.get("drawupMordCnt") or 0),
            "bus_to_ord_rate": s.get("busToOrdRate"),
            "avatar": s.get("avatarUrl") or s.get("avtarUrl") or "",
        })

with open('raw/cs_account_summary_flatten.json', 'w', encoding='utf-8') as f:
    json.dump(flatten, f, ensure_ascii=False, indent=1)
print("flatten rows=%d" % len(flatten))
