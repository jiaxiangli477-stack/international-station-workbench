"""stage_f_release.py — 冻结 Alibaba Growth OS Skill V1.2 Release（Stage F 原生深度情报）。"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL = ROOT / "alibaba-growth-os"
REL = ROOT / "releases" / "alibaba-growth-os-v1.2"
ZIP_PATH = ROOT / "releases" / "alibaba-growth-os-v1.2.zip"

# 店铺私有标记（EXAMPLE ONLY 除外）
PRIVATE = ["LIFEWORTH", "莱华仕", "Shenzhen Lifeworth", "1653192276", "1600472561736",
           "1601427218194", "1600546912886", "1601720577533", "1601719605709",
           "1601476000834", "1601829634947", "1601492686064", "1601387052135",
           "1601728673188", "1601618995199", "1601700931444", "1601724696246",
           "60337273387", "1601847167545", "1601361255457", "1601763326911",
           "60852053624", "1600718096240", "1600530523398", "1601386954792", "1600341073560",
           "26845", "64677", "10677.05", "12909.5", "16132.8"]
ID_PAT = re.compile(r"1[6-9]\d{10}")


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    h.update(p.read_bytes())
    return h.hexdigest()


def main() -> int:
    if REL.exists():
        shutil.rmtree(REL)
    REL.mkdir(parents=True)
    files = []
    for p in sorted(SKILL.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc":
            rel = p.relative_to(SKILL)
            dest = REL / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dest)
            files.append(rel.as_posix())

    manifest = {
        "skill_name": "alibaba-growth-os",
        "skill_version": "1.2.0",
        "schema_version": "1.0-stageA+stageB+d1+e_audit+f_native_intel",
        "release_date": date.today().isoformat(),
        "supersedes": "1.1.1（V1.0/V1.1/V1.1.1 均保留，不覆盖）",
        "supported_commands": [
            "SYNC WEEKLY", "SYNC MONTHLY", "OPTIMIZE PRODUCT <id>", "OPTIMIZE TOP PRODUCTS",
            "REBUILD DASHBOARD", "VALIDATE GROWTH OS", "RETRY PERIOD <period>",
            "EXPORT STORE PACKAGE", "IMPORT STORE PACKAGE", "INITIALIZE STORE",
            "IMPORT ACTION UPDATES", "DISCOVER COMPETITORS", "REFRESH MARKET INTELLIGENCE"
        ],
        "v12_features": {
            "native_intelligence": [
                "Alibaba Industry Intelligence: 官方行业排行(人气/蓝海榜)/细分市场机会/热词(top3HotKw)/供需/增速",
                "真实同行发现: 5 家真实同行店铺(公开产品详情页实抓, Intertek/SGS 验证, 评分/响应/收入)",
                "真实相似 Listing: 6 个热品(官方热品榜) + 与本店 3 个重点产品匹配(相关度/差距)",
                "Competitor Snapshot: BASELINE 快照(首次不声明本周新增)"
            ],
            "product_360": "680 产品 A-J 十块 profile(官方/表现/历史/同行/买家/Listing/市场/竞品/诊断/优化)",
            "ai_optimizer": [
                "Top20 多因素选择(商业影响/等级/GMV/曝光/询盘/订单/Peer Gap/市场/可落地, 非 CTR)",
                "22 个 17 项深度方案(Funnel Position/Market Opportunity/Competitor Benchmark/Exact Execution Plan)",
                "Root Cause causal_confidence(相关≠因果; 客服指标限定为'影响客服环节承接')",
                "optimization_cache + refresh_reason(不每周全量重分析)"
            ],
            "pages": ["products 每行 360°/AI优化/登记入口", "product_detail Product 360 区块", "peer_benchmark 真实同行店铺", "ai_optimizer Tier/Priority/状态筛选"]
        },
        "required_runtime_capabilities": [
            "python3", "Alibaba 官方数据访问(data-advisor MCP)", "config.json(advisory_date)",
            "SQLite", "浏览器(file:// 驾驶舱)", "公开 Alibaba 产品详情页抓取(同行发现)"
        ],
        "optional_runtime_capabilities": ["官方 Excel Export", "supplier_verification_recall"],
        "default_locale": "zh-CN",
        "data_delay_days": 2,
        "week_start": "Monday",
        "week_end": "Sunday",
        "read_only_default": True,
        "files": {f: sha256(REL / f) for f in files},
        "checksums_algorithm": "SHA-256",
    }
    (REL / "RELEASE_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")

    leaks = []
    for p in REL.rglob("*"):
        if not p.is_file():
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except Exception:
            continue
        if p.name == "RELEASE_MANIFEST.json":
            continue
        for marker in PRIVATE:
            idx = text.find(marker)
            if idx >= 0 and "EXAMPLE ONLY" not in text[max(0, idx - 150): idx + 150]:
                leaks.append(f"{p.relative_to(REL)}: {marker}")

    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(REL.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(REL).as_posix())

    print(json.dumps({
        "release_dir": str(REL),
        "file_count_incl_manifest": len(files) + 1,
        "zip": str(ZIP_PATH), "zip_size_kb": round(ZIP_PATH.stat().st_size / 1024, 1),
        "private_data_leaks": leaks if leaks else "NONE (PASS)",
    }, ensure_ascii=False, indent=1))
    return 0 if not leaks else 1


if __name__ == "__main__":
    raise SystemExit(main())
