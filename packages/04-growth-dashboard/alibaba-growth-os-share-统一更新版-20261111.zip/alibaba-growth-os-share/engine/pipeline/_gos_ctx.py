# -*- coding: utf-8 -*-
"""GOS 运行上下文：店铺身份与时间窗口的统一读取入口（本地工作区补丁）。

背景：原包部分 fetch 脚本把类目 id / 日期写死成了上一次打包时的值，
与 V7「动态窗口 + 零写死」的目标不符。此模块让这些脚本改为读
stores.json（店铺身份）与 raw/_window.json（本次运行窗口）。
"""
import json, os

ROOT = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(ROOT, 'raw')


def active_store():
    with open(os.path.join(ROOT, 'stores.json'), encoding='utf-8') as f:
        c = json.load(f)
    return c['stores'][c['active']]


def window():
    with open(os.path.join(RAW, '_window.json'), encoding='utf-8') as f:
        return json.load(f)
