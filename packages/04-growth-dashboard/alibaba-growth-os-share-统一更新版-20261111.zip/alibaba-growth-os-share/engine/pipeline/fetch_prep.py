# -*- coding: utf-8 -*-
"""新店 prep 数据拉取：行业国家榜/流量渠道/关键词洞察/类目热品榜 → raw/
用法: python fetch_prep.py

类目 id 取自 stores.json（当前店主类目），流量渠道时间窗取自 raw/_window.json，
不再写死类目与日期。
"""
import subprocess, json, io, sys, os
from datetime import date, timedelta
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import _gos_ctx

ROOT = _gos_ctx.ROOT
RAW = _gos_ctx.RAW
os.makedirs(RAW, exist_ok=True)

CATE_ID = int(_gos_ctx.active_store().get('cate_id') or 0)
W = _gos_ctx.window()
_W1_END = date.fromisoformat(W['weeks'][0]['week_end'])
FLOW_START = (_W1_END - timedelta(days=29)).isoformat()
FLOW_END = _W1_END.isoformat()
print("店铺主类目 cateId = %s | 流量渠道窗口 = %s ~ %s" % (CATE_ID, FLOW_START, FLOW_END))


def mcp_call(tool, payload_obj):
    pfile = os.path.join(RAW, '_tmp_prep.json')
    with open(pfile, 'w', encoding='utf-8') as f:
        json.dump(payload_obj, f, ensure_ascii=False)
    r = subprocess.run(['accio-mcp-cli', 'call', tool, '--json-file', pfile],
                       capture_output=True, text=True, encoding='utf-8', errors='replace',
                       timeout=180, shell=True)
    out = r.stdout or ''
    i = out.find('{')
    if i >= 0:
        try:
            return json.loads(out[i:])
        except Exception:
            pass
    return {"_raw": out[:400], "_stderr": (r.stderr or '')[:400]}


def save(name, obj):
    p = os.path.join(RAW, name)
    with open(p, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False)
    print(f"saved {name}  (data len: {len(obj.get('data') or []) if isinstance(obj, dict) else '?'})")
    return p


def main():
    # 1. 行业国家榜（人气榜 rankType=1）
    print("== 行业国家榜 ==")
    for rt, tag in [("1", "popular"), ("3", "blueocean")]:
        r = mcp_call('data_advisor_industry_country_rank',
                     {"industryRankQueryParam": {"cateId": CATE_ID, "rankType": rt}})
        save(f'industry_country_rank_{tag}.json', r)
    # 同时保存一份不带后缀的（兼容 v4_prep_sections 读 industry_country_rank.json）
    r = mcp_call('data_advisor_industry_country_rank',
                 {"industryRankQueryParam": {"cateId": CATE_ID, "rankType": "1"}})
    save('industry_country_rank.json', r)

    # 2. 店铺流量渠道（最近 30 天）
    print("== 店铺流量渠道 ==")
    r = mcp_call('data_advisor_shop_flow',
                 {"channelQueryParam": {"startDate": FLOW_START, "endDate": FLOW_END,
                                         "terminalType": "TOTAL"}})
    save('shop_flow_channel.json', r)

    # 3. 行业关键词洞察（30d）
    print("== 行业关键词洞察 ==")
    r = mcp_call('data_advisor_industry_crowd_insight',
                 {"crowdInsightQueryParam": {"industryId": str(CATE_ID), "nd": "30d",
                                              "terminalType": "TOTAL"}})
    save('industry_keyword.json', r)

    # 4. 类目热品榜（人气榜 + 蓝海榜）→ market_products 来源
    print("== 类目热品榜 ==")
    for rt, tag in [("1", "popular"), ("3", "blueocean")]:
        r = mcp_call('data_advisor_industry_cate_rank',
                     {"industryRankQueryParam": {"cateId": CATE_ID, "rankType": rt}})
        save(f'industry_cate_rank_{tag}.json', r)

    print("DONE")


if __name__ == '__main__':
    main()
