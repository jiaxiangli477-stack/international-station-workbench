# -*- coding: utf-8 -*-
"""V4: 解析标杆同行数据 → raw/peer_benchmark_parsed.json（供 v4_judge 读取）"""
import json, io, sys, glob
from datetime import date
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def load(p):
    with open(p, 'rb') as f: raw = f.read()
    if raw[:2] == b'\xff\xfe': return json.loads(raw.decode('utf-16'))
    if raw[:3] == b'\xef\xbb\xbf': return json.loads(raw.decode('utf-8-sig'))
    return json.loads(raw.decode('utf-8'))

_pb = sorted([f for f in glob.glob('raw/peer_benchmark_*.json') if 'parsed' not in f])
d = load(_pb[-1] if _pb else 'raw/peer_benchmark.json')
data = d.get('data') or []

def sum_idx(arr, days=7):
    if not arr: return None
    recent = arr[:days]
    return sum(int(x.get('tagValue') or 0) for x in recent)

def latest(arr):
    if not arr: return None
    return arr[0].get('tagValue')

peers = []
for s in data:
    peers.append({
        "store_name": s.get('compCnName') or s.get('adminMbrId'),
        "store_id": s.get('adminMbrId'),
        "star_level": s.get('starLevel'),
        "score": s.get('compScore'),
        "review_cnt": s.get('compReviewCnt'),
        "url": s.get('minisiteUrl'),
        "main_products": s.get('mainProdSlr'),
        "inquiry_7d": sum_idx(s.get('abCntIndex')),
        "uv_7d": sum_idx(s.get('uvDetailIndex')),
        "order_7d": sum_idx(s.get('prepayOrdCntIndex')),
    })

_cfg = {}
try:
    _cfg = json.load(open('config.json', encoding='utf-8'))
except Exception:
    pass
_st = _cfg.get('store', {}) or {}
out = {"category": _st.get('main_category') or '', "cate_id": _st.get('cate_id') or 0, "as_of": date.today().isoformat(), "peers": peers}
with open('raw/peer_benchmark_parsed.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

print("标杆店 %d 家：" % len(peers))
for p in peers:
    print("  %s | %s星 评分%s | 询盘7d=%s UV7d=%s 订单7d=%s | %s" % (
        p['store_name'], p['star_level'], p['score'], p['inquiry_7d'], p['uv_7d'], p['order_7d'], (p['main_products'] or '')[:40]))
