"""stage_c_sync_test.py — PART 5/6 增量同步验证（独立测试库，不触碰生产数据库）。

测试:
  PART 5  W34 Future Simulation: advisory=2026-08-23 且库最新为 W33 → 决策 FETCH W34(8/17~8/23)，
          且仅计划抓取 2026-08-17 ~ 2026-08-23。不伪造 Alibaba 指标写入生产库。
  PART 6  CASE A: 库 W30-W33, advisory=W33 完成 → SKIP
          CASE B: 库 W30-W33, advisory=W34 完成 → 仅 FETCH W34
          CASE C: 库 W30-W34, 再次执行 W34(数据未变) → SKIP；重插行数不变
          CASE D: W34 v1 已存在, 后台历史修正 → Snapshot v2, 业务表覆盖（无重复普通记录）
"""
from __future__ import annotations

import json
import shutil
import sqlite3
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TEST_DB = ROOT / "database" / "test_incr.db"
sys.path.insert(0, str(ROOT / "alibaba-growth-os" / "scripts"))
from window import latest_complete_week, sync_decision  # noqa: E402

W30_E, W31_E, W32_E, W33_E, W34_E = "2026-07-26", "2026-08-02", "2026-08-09", "2026-08-16", "2026-08-23"
W34_S = "2026-08-17"
W30_S, W31_S, W32_S, W33_S = "2026-07-20", "2026-07-27", "2026-08-03", "2026-08-10"

DDL = """
CREATE TABLE IF NOT EXISTS store_weekly_stats (
    stat_week_end TEXT PRIMARY KEY, stat_week_start TEXT,
    total_imps INTEGER, suc_ord_amt REAL, suc_ord_cnt INTEGER, raw_json TEXT);
CREATE TABLE IF NOT EXISTS sync_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT, records INTEGER, status TEXT, message TEXT,
    finished_at TEXT DEFAULT (datetime('now')));
"""


def fresh_db() -> sqlite3.Connection:
    if TEST_DB.exists():
        TEST_DB.unlink()
    conn = sqlite3.connect(str(TEST_DB))
    conn.row_factory = sqlite3.Row
    conn.executescript(DDL)
    return conn


def seed(conn: sqlite3.Connection, week_ends: list[str]) -> None:
    for we, ws in zip(week_ends, [W30_S, W31_S, W32_S, W33_S, W34_S]):
        conn.execute(
            "INSERT OR REPLACE INTO store_weekly_stats VALUES (?,?,1000,100.0,1,'{}')",
            (we, ws))


def main() -> int:
    results = {}
    # ---------- PART 5: W34 Future Simulation ----------
    conn = fresh_db()
    seed(conn, [W30_E, W31_E, W32_E, W33_E])   # 库最新 = W33
    conn.commit()
    advisory_823 = date.fromisoformat("2026-08-23")
    decision, w = sync_decision(date.fromisoformat(W33_E), advisory_823, 28)
    p5_ok = (decision == "FETCH" and w.start.isoformat() == W34_S
             and w.end.isoformat() == W34_E and w.is_complete)
    results["PART5_W34_SIMULATION"] = {
        "ok": p5_ok, "decision": decision,
        "planned_fetch": f"{w.start.isoformat()} → {w.end.isoformat()}",
        "expect": "FETCH 2026-08-17 → 2026-08-23 only",
    }
    # 生产库行数不受影响
    prod = sqlite3.connect(str(ROOT / "database" / "alibaba_growth.db"))
    prod_cnt = prod.execute("SELECT COUNT(*) FROM store_weekly_stats").fetchone()[0]
    prod.close()
    results["PART5_PRODUCTION_UNTOUCHED"] = {"ok": prod_cnt == 4, "prod_weeks": prod_cnt}
    conn.close()

    # ---------- PART 6: CASE A ----------
    conn = fresh_db()
    seed(conn, [W30_E, W31_E, W32_E, W33_E])
    conn.commit()
    decision, w = sync_decision(date.fromisoformat(W33_E), date.fromisoformat("2026-08-20"), 28)
    results["CASE_A_SKIP"] = {
        "ok": decision == "SKIP", "decision": decision,
        "db": "W30-W33", "advisory": "2026-08-20(→W33 完成)",
    }
    conn.close()

    # ---------- PART 6: CASE B ----------
    conn = fresh_db()
    seed(conn, [W30_E, W31_E, W32_E, W33_E])
    conn.commit()
    decision, w = sync_decision(date.fromisoformat(W33_E), advisory_823, 28)
    results["CASE_B_FETCH_W34"] = {
        "ok": decision == "FETCH" and w.end.isoformat() == W34_E,
        "decision": decision, "fetch_range": f"{w.start}~{w.end}",
        "db": "W30-W33", "advisory": "2026-08-23(→W34 完成)",
    }
    conn.close()

    # ---------- PART 6: CASE C ----------
    conn = fresh_db()
    seed(conn, [W30_E, W31_E, W32_E, W33_E, W34_E])  # 库已含 W34
    conn.commit()
    before = conn.execute("SELECT COUNT(*) FROM store_weekly_stats").fetchone()[0]
    decision, w = sync_decision(date.fromisoformat(W34_E), advisory_823, 28)
    # 模拟数据未变化的重跑（同周相同数据 → 覆盖，行数不变）
    conn.execute(
        "INSERT OR REPLACE INTO store_weekly_stats VALUES (?,?,1000,100.0,1,'{}')",
        (W34_E, W34_S))
    conn.commit()
    after = conn.execute("SELECT COUNT(*) FROM store_weekly_stats").fetchone()[0]
    results["CASE_C_RESYNC_SKIP"] = {
        "ok": decision == "SKIP" and before == after == 5,
        "decision": decision, "rows_before": before, "rows_after": after,
    }
    conn.close()

    # ---------- PART 6: CASE D ----------
    conn = fresh_db()
    seed(conn, [W30_E, W31_E, W32_E, W33_E, W34_E])  # W34 v1
    conn.commit()
    before = conn.execute("SELECT COUNT(*) FROM store_weekly_stats").fetchone()[0]
    # 后台历史修正: 写入 v2 快照（raw 层版本化）+ 业务表覆盖更新（revision 语义）
    revision = 2
    v2_raw = {"week": "2026-08-17~2026-08-23", "revision": revision,
              "note": "Alibaba 后台历史修正", "total_imps": 1005, "suc_ord_amt": 999.5}
    conn.execute(
        """INSERT OR REPLACE INTO store_weekly_stats VALUES (?,?,?,?,?,?)""",
        (W34_E, W34_S, v2_raw["total_imps"], v2_raw["suc_ord_amt"], 2,
         json.dumps(v2_raw, ensure_ascii=False)))
    conn.execute(
        """INSERT INTO sync_log (source, records, status, message)
           VALUES ('alibaba-data-advisor', 1, 'success', ?)""",
        (f"W34 historical revision: v1→v2 ({W34_S}~{W34_E})",))
    conn.commit()
    after = conn.execute("SELECT COUNT(*) FROM store_weekly_stats").fetchone()[0]
    row = conn.execute("SELECT * FROM store_weekly_stats WHERE stat_week_end=?", (W34_E,)).fetchone()
    logs = conn.execute("SELECT message FROM sync_log").fetchall()
    results["CASE_D_REVISION_V2"] = {
        "ok": after == before == 5 and row["total_imps"] == 1005 and row["raw_json"] == json.dumps(v2_raw, ensure_ascii=False),
        "rows_before": before, "rows_after": after,
        "w34_revised_imps": row["total_imps"], "v2_snapshot_saved": "revision" in (row["raw_json"] or ""),
        "sync_log_revision_note": logs[0]["message"],
        "no_duplicate_records": after == 5,
    }
    conn.close()

    # ---------- 输出 ----------
    all_ok = all(v["ok"] for v in results.values())
    print(json.dumps(results, ensure_ascii=False, indent=1))
    print("ALL_CASES_PASS" if all_ok else "SOME_CASE_FAIL")
    if TEST_DB.exists():
        TEST_DB.unlink()
        print("test db cleaned")
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
