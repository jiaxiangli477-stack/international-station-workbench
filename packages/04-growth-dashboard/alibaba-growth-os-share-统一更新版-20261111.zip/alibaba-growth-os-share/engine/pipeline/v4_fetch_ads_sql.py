# -*- coding: utf-8 -*-
"""V4: 通过 report_sql 拉取广告报告 TSV 数据（账户 + 全计划），解析花费/点击/CPC/商机"""
import subprocess, json, io, sys, os
from datetime import date, timedelta
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 最新完整自然周（动态计算）
_t = date.today(); _dow = (_t.weekday() + 1) % 7
_sun = _t - timedelta(days=_dow)
if _sun >= _t: _sun -= timedelta(days=7)
_wb = _sun - timedelta(days=6)
WEEK_BEGIN = _wb.isoformat() + " 00:00:00"
WEEK_END = _sun.isoformat() + " 23:59:59"
WEEK_TAG = _wb.isoformat().replace('-', '')

def workctl(params_obj):
    pfile = os.path.join(os.getcwd(), 'ads_tmp_params.json')
    with open(pfile, 'w', encoding='utf-8') as f:
        json.dump(params_obj, f, ensure_ascii=False)
    r = subprocess.run(['workctl','icbu','ads','list','--params-file',pfile,'--format','json'],
                       capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120, shell=True)
    env = json.loads(r.stdout)
    return env.get('result', {}).get('structuredContent') or {}

def q(entityType, filters=None, include='data'):
    p = {"entityType": entityType, "include": include}
    if filters: p["filters"] = filters
    return workctl(p)

def get_report_data(entityType, filters):
    """query report → 拿 tableName/sessionId → report_sql → 解析 TSV"""
    r = q(entityType, filters)
    d = r.get('data') or {}
    rows = d.get('data') or []
    if not rows: return None
    tm = rows[0].get('tableMeta') or {}
    tname = rows[0].get('tableName') or tm.get('table_name')
    sid = rows[0].get('sessionId')
    if not tname: return None
    sql_r = q("report_sql", {"sessionId": sid, "tableName": tname, "sql1": "SELECT * FROM %s" % tname})
    dd = (sql_r.get('data') or {}).get('data') or []
    if not dd: return None
    tsv = dd[0].get('tsvData') or ''
    return parse_tsv(tsv)

def parse_tsv(tsv):
    lines = tsv.strip('\n').split('\n')
    if not lines or not lines[0]: return []
    header = lines[0].split('\t')
    out = []
    for ln in lines[1:]:
        if not ln.strip(): continue
        vals = ln.split('\t')
        row = {}
        for i, h in enumerate(header):
            row[h] = vals[i] if i < len(vals) else ''
        out.append(row)
    return out

# 1. 账户报告
print("== 账户报告 ==")
acc = {}
for ds, tname in [('company_search','COMPANY_SEARCH'), ('company_whole_site','COMPANY_WHOLE_SITE')]:
    rows = get_report_data("report", {"datasource": ds, "beginDateTime": WEEK_BEGIN, "endDateTime": WEEK_END})
    acc[ds] = rows
    print("  %s: %d 行" % (ds, len(rows or [])))
    if rows: print("    ", json.dumps(rows[0], ensure_ascii=False))

# 2. 计划报告
plans = json.load(open('raw/ads_plan_%s.json' % WEEK_TAG, encoding='utf-8'))
campaigns = plans['campaigns']
print("\n== 计划报告 ==")
for c in campaigns:
    cid = c['campaign_id']
    ds = 'campaign_search' if c['line'] == 'search' else 'campaign_whole_site'
    rows = get_report_data("report", {"datasource": ds, "campaignId": cid, "beginDateTime": WEEK_BEGIN, "endDateTime": WEEK_END})
    c['report_data'] = rows or []
    n = len(c['report_data'])
    spend = 0.0
    if rows:
        for r in rows:
            try: spend += float(r.get('花费', 0) or 0)
            except: pass
    c['spend_week'] = round(spend, 2)
    if n or spend > 0:
        print("  [%s] %s: %d 行, 花费=%.2f" % (cid, c['name'][:22], n, spend))

with open('raw/ads_report_%s.json' % WEEK_TAG, 'w', encoding='utf-8') as f:
    json.dump({"account": acc, "campaigns": campaigns}, f, ensure_ascii=False, indent=1)
print("\nsaved raw/ads_report_%s.json" % WEEK_TAG)
