# -*- coding: utf-8 -*-
import sqlite3, json, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
c = sqlite3.connect('database/alibaba_growth.db')
c.row_factory = sqlite3.Row
cur = c.cursor()
_wk = cur.execute("SELECT stat_week_end, stat_week_start FROM store_weekly_stats ORDER BY stat_week_end DESC LIMIT 1").fetchone()
WE = _wk['stat_week_end'] if _wk else '2026-08-16'
WS = _wk['stat_week_start'] if _wk else '2026-08-10'
cur.execute("""SELECT p.product_id, p.main_image, p.title, ps.inquiries, ps.clicks, e.atm_fb_uv
  FROM products p
  JOIN product_weekly_stats ps ON ps.product_id=p.product_id AND ps.week_end=?
  LEFT JOIN product_weekly_stats_ext e ON e.product_id=p.product_id AND e.week_start=?
  WHERE (ps.inquiries>0 OR e.atm_fb_uv>0 OR ps.clicks>=4) AND p.main_image IS NOT NULL AND p.main_image!=''
  ORDER BY (ps.inquiries + COALESCE(e.atm_fb_uv,0)) DESC, ps.clicks DESC LIMIT 40""", (WE, WS))
rows = [dict(r) for r in cur.fetchall()]
out = []
for r in rows:
    out.append({"product_id": r['product_id'], "img": r['main_image'], "title": (r['title'] or '')[:60],
                "inq": r['inquiries'], "clk": r['clicks'], "tm": r['atm_fb_uv'] or 0})
with open('raw/top_imgs.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("提取 %d 个产品主图" % len(out))
for o in out[:15]:
    print("  %s | 询盘%d 点击%d | %s" % (o['product_id'], o['inq'], o['clk'], o['img'][:70]))
