# -*- coding: utf-8 -*-
"""拉取 5 家竞店的 Top20 产品（month 口径，按起草订单降序）→ competitor_data/shop-product-*.json

statDate 取 raw/_window.json 里当前月（MTD）的月初，不再写死。
"""
import subprocess, json, io, sys, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import _gos_ctx

ROOT = _gos_ctx.ROOT
CD = os.path.join(ROOT, 'competitor_data')
os.makedirs(CD, exist_ok=True)

STAT_DATE = _gos_ctx.window()['months'][-1]['month_start']
print("month 口径 statDate = %s" % STAT_DATE)

COMPETITORS = [
    "inter-health",
    "heinersupplement",
    "interlhealthcare",
    "ecobiotech",
    "globalnutrition",
]


def call_product(domain):
    pfile = os.path.join(CD, '_tmp.json')
    payload = {"shopProductQueryParam": {
        "domain": domain, "statisticsType": "month", "statDate": STAT_DATE,
        "orderBy": "crtOrd", "order": "desc", "pageNo": 1, "pageSize": 20,
        "terminalType": "TOTAL"}}
    with open(pfile, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False)
    r = subprocess.run(['accio-mcp-cli', 'call', 'data_advisor_shop_product', '--json-file', pfile],
                       capture_output=True, text=True, encoding='utf-8', errors='replace',
                       timeout=180, shell=True)
    out = r.stdout or ''
    i = out.find('{')
    if i >= 0:
        try:
            return json.loads(out[i:])
        except Exception:
            pass
    return {"_raw": out[:300]}


for d in COMPETITORS:
    resp = call_product(d)
    p = os.path.join(CD, f'shop-product-{d}-ranked20.json')
    with open(p, 'w', encoding='utf-8') as f:
        json.dump(resp, f, ensure_ascii=False)
    dd = (resp.get('data') or {}) if isinstance(resp, dict) else {}
    rows = dd.get('data') or []
    print(f"{d}: {len(rows)} products (recordCount={dd.get('recordCount')})")

print("DONE")
