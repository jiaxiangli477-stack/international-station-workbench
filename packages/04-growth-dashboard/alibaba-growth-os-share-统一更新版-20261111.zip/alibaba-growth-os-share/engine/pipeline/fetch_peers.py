# -*- coding: utf-8 -*-
"""拉取标杆同行（供应商筛选：父类目保健食品 30d GMV降序）→ raw/peer_benchmark_*.json"""
import subprocess, json, io, sys, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
RAW = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'raw')
os.makedirs(RAW, exist_ok=True)

PARENT_CATE = 202029701  # Healthcare Supplements 父类目

pfile = os.path.join(RAW, '_tmp_peer.json')
with open(pfile, 'w', encoding='utf-8') as f:
    json.dump({"cateId": PARENT_CATE, "statisticsType": "30d", "orderBy": "rec_ord_amt", "order": "desc"}, f)
r = subprocess.run(['accio-mcp-cli', 'call', 'data_advisor_supplier_selection', '--json-file', pfile],
                   capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120, shell=True)
out = r.stdout or ''
i = out.find('{')
resp = json.loads(out[i:]) if i >= 0 else {}
data = resp.get('data') or []
out_path = os.path.join(RAW, 'peer_benchmark_20260823.json')
with open(out_path, 'w', encoding='utf-8') as f:
    json.dump(resp, f, ensure_ascii=False)
print(f"标杆同行 {len(data)} 家，已保存 {out_path}")
for s in data[:5]:
    print("  %s | %s星 | %s" % (s.get('compCnName') or s.get('adminMbrId'), s.get('starLevel'), (s.get('mainProdSlr') or '')[:50]))
