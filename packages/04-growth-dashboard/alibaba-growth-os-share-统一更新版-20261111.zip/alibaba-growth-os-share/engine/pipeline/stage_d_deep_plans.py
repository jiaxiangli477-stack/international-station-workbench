"""stage_d_deep_plans.py — D2: 3 个 AI 深度优化方案（PART H 17 项结构）。

方案覆盖（PART AD 验收）:
  1. TITLE_REWRITE  — 1600472561736 Pre Workout Creatine（真实标题 + 3 候选方案）
  2. MAIN_IMAGE     — 1601427218194 Mental Performance（真实 Creative Brief 全要素）
  3. DETAIL/MOQ     — 1601719605709 Caffeine Pouch（九模块详情 + MOQ 阶梯）

写入 product_optimizations.deep_plan_json（AI_INFERENCE 显式标注，不虚构工厂能力）。
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent / "database" / "alibaba_growth.db"

CURRENT_TITLE_PW = "LIFEWORTH Pre Workout Bodybuilding Supplement Creatine Monohydrate Bulk Energy Drink Powder Caffeine Preworkout Powder 300g"
CURRENT_TITLE_MP = "LIFEWORTH Mental Performance System: 200mg Plant-Derived Caffeine & Nootropic Matrix for Optimal Cognitive Function"
CURRENT_TITLE_POUCH = "LIFEWORTH Customizable Caffeine Pouch Powder - With Nootropic Ingredients and Natural Flavors - OEM Bulk FOB China"

PLANS = [
    {
        "product_id": "1600472561736",
        "primary_action": "TITLE_REWRITE",
        "title": CURRENT_TITLE_PW,
        "plan": {
            "1_why_selected": "官方爆品；W1 搜索曝光 1710、CTR 5.15%（远超店均 1.69%）点击力强，但自然搜索曝光受限（广告占 66%），询盘 5/TM 4 说明转化基础好 —— 标题是放大自然流量的最高杠杆点",
            "2_current_problem": "搜索曝光不足（1710/周），自然流量过度依赖广告（广告曝光 2044/总 3074）；标题对 'creatine monohydrate powder bulk' 类核心采购词覆盖弱",
            "3_data_evidence": "W1: 搜索曝光 1710 | 点击 88 | CTR 5.15% | 询盘 5 | TM 4 | 订单 1 | GMV $68；coc_show +4.8%、coc_click +37.8%；价格 $2.80-3.40、MOQ 100 boxes、1686 sold",
            "4_self_history": "4 周内曝光/点击处于上升通道（coc 双正），处于'有流量就有转化'的验证期",
            "5_peer_gap": "店级搜索 CTR 1.69% vs 同行平均 1.77%（基本持平）；本品 CTR 5.15% 说明点击力显著领先，缺口在曝光入口而非点击力",
            "6_buyer_intent": "买家结构: online retailer 38.8% / offline 32.7% / wholesale 21.1%；能量粉买家高频 Query 模式: 'creatine monohydrate powder bulk'、'pre workout powder private label'、'energy drink powder 300g'（AI_INFERENCE: 基于买家身份结构与品类惯例推断）",
            "7_listing_diagnosis": "当前标题 22 词过长；'Pre Workout' 与 'Preworkout' 重复表达；核心词 'Creatine Monohydrate' 位于第 5 位；'Bulk' 有但 'Private Label/OEM' 采购信号弱；'300g' 规格词被淹没",
            "8_competitor_gap": "UNAVAILABLE（当前无竞品店铺明细数据；仅官方同行聚合值）",
            "9_root_cause": "标题关键词结构与搜索采购意图匹配度低 → 自然搜索排名与曝光受限 → 高 CTR 无法规模化",
            "10_primary_action": "TITLE_REWRITE（本轮唯一变量）",
            "11_concrete_plan": {
                "type": "TITLE_REWRITE",
                "current_title": CURRENT_TITLE_PW,
                "analysis": {
                    "core_product_word_position": "'Creatine Monohydrate' 位于第 5 位，前有 4 个修饰词，B2B 搜索引擎对首部主词权重更高",
                    "b2b_intent": "'Bulk' 有但 'Private Label / OEM / Custom' 缺失，丢失品牌商/采购商流量",
                    "dosage_form": "'Powder' 有；'300g' 规格有但位置靠后",
                    "key_attributes": "'Caffeine' 有；'Sugar Free' 缺失（官方属性含 Low-Carb）",
                    "redundancy": "'Pre Workout' 与 'Preworkout' 重复出现，浪费字符",
                    "buyer_query_match": "对 'creatine monohydrate bulk' 匹配中；对 'private label pre workout' 匹配弱（AI_INFERENCE）"
                },
                "title_options": [
                    {
                        "code": "A",
                        "title": "LIFEWORTH Creatine Monohydrate Pre Workout Powder 300g - Sugar Free Energy Drink Mix Bulk OEM Private Label",
                        "target_intent": "批发/品牌商（Private Label + Bulk 双信号）",
                        "why": "核心词 Creatine Monohydrate 前置第 1 位；300g 规格提前；补 Sugar Free 属性词；OEM Private Label 强化 B2B",
                        "solves": "自然搜索主词排名 + 品牌商采购流量"
                    },
                    {
                        "code": "B",
                        "title": "Creatine Monohydrate Pre-Workout 300g Can - Explosive Energy Endurance Powder Bulk OEM ODM Private Label GMP Factory",
                        "target_intent": "OEM/ODM 定制买家",
                        "why": "去品牌前缀、纯产品词开头；GMP Factory 强化工厂信任；ODM 覆盖定制需求",
                        "solves": "工厂直供/定制买家搜索匹配"
                    },
                    {
                        "code": "C",
                        "title": "Pre Workout Creatine Monohydrate Powder Bulk 300g - Caffeine Energy Drink Mix Sugar Free, OEM Private Label Manufacturer",
                        "target_intent": "泛流量 + 批发混合",
                        "why": "'Pre Workout' 主流量词前置保排名，Creatine 紧随；Manufacturer 收尾强化 B2B",
                        "solves": "在保留现有排名基础上前置主词，风险最低"
                    }
                ]
            },
            "12_do_not_change": "不修改价格（$2.80-3.40 阶梯合理）；不动 MOQ 100 boxes（试单友好）；不删除品牌词 LIFEWORTH（品牌资产）；不改主图（CTR 5.15% 证明主图有效）",
            "13_future_actions": ["补充 'creatine monohydrate powder bulk' / 'pre workout energy drink mix' 长尾关键词", "统一 Primary Ingredient 与 Main Ingredients 属性口径", "评估广告预算向自然词回投"],
            "14_validation_metric": "搜索曝光 / 搜索点击 / 询盘数（周环比，对照 coc 基线）",
            "15_validation_period": "1 个完整自然周（标题更换后，下一周数据对比）",
            "16_confidence": "medium（标题-排名影响有品类惯例依据，需实测验证）",
            "17_evidence_source": "data_advisor_shop_product W1 官方数据 + 公开 Listing 实读 + 官方商品分层 + 买家身份画像（AI_INFERENCE 已标注）"
        }
    },
    {
        "product_id": "1601427218194",
        "primary_action": "MAIN_IMAGE",
        "title": CURRENT_TITLE_MP,
        "plan": {
            "1_why_selected": "官方诊断定价优化清单#1；W1 搜索曝光同比 +98.3% 暴涨但点击仅 2（CTR 1.12% 全场最低）→ 流量进来了但首屏无法承接，主图是最大瓶颈",
            "2_current_problem": "CTR 1.12% << 店均 1.69%；曝光翻倍点击停滞；'Mental Performance System' 品牌式标题 + 首屏信息无法让买家 3 秒内识别成分与价值",
            "3_data_evidence": "W1: 搜索曝光 179(coc +98.3%) | 点击 2 | CTR 1.12% | 询盘 0 | 订单 0；价格 $1.85-1.99、MOQ 2000 pcs；页面被反爬时以官方 API 组件数据补充（listing_read=API）",
            "4_self_history": "曝光处于暴涨期（+98%），点击转化率极低 → 曝光增长完全未兑现为点击",
            "5_peer_gap": "CTR 1.12% vs 店均 1.69% vs 同行平均搜索 CTR 1.77%（W1 口径）→ 点击力显著落后",
            "6_buyer_intent": "Nootropic/认知类买家为专业经销商与品牌商，首屏需 3 秒确认: 成分矩阵（Caffeine/L-Theanine/B12）+ 剂量（200mg）+ 剂型",
            "7_listing_diagnosis": "当前主图未获取到完整像素（页面反爬）；标题 30+ 词过长、'Mental Performance System' 非品类搜索词，主词 'Caffeine' 被品牌化表达淹没 —— 主图需承接被标题浪费的点击机会",
            "8_competitor_gap": "UNAVAILABLE（无竞品明细数据；店级同行 CTR 对比可作参考）",
            "9_root_cause": "曝光暴涨（官方流量分配）与 CTR 极低并存 → 主图/首屏与买家预期错配",
            "10_primary_action": "MAIN_IMAGE（本轮唯一变量；标题简化列入 Future）",
            "11_concrete_plan": {
                "type": "MAIN_IMAGE",
                "current_image_problem": "无法确认像素细节（反爬）；基于数据判断: 首屏缺少成分矩阵/剂量等 B2B 关键决策信息，导致高曝光低点击",
                "creative_brief": {
                    "subject": "产品罐体特写（800x800+，主体居中偏左）",
                    "product_ratio": "产品占画面 55-65%",
                    "background": "深色科技感渐变（深蓝→黑），与品牌色形成对比，突出粉末剂型",
                    "packaging_display": "罐体正面展示 + 右上角 45° 罐盖微开露出粉末颗粒细节",
                    "b2b_signals": "是 — 左上角 '200mg Caffeine' 黄色徽章 + 右侧成分矩阵图标（Caffeine/L-Theanine/B12）+ 底部 'Nootropic Focus Matrix'",
                    "text_allowed": "仅 3 处文字: 左上 '200mg Caffeine'、右下 'L-Theanine + B12'、底部 'OEM/Private Label'（≤4 词）",
                    "do_not_include": "不放认证 logo 堆砌、不放长句卖点、不放价格数字（价格带见详情页）、不放大段成分表",
                    "mobile_thumbnail": "缩略图 80x80 可读性: '200mg' 徽章放大至可读，文字字号 ≥ 36px 等效",
                    "ab_test": "适合 — A/B: 深色成分矩阵版 vs 浅色极简罐体版，1 完整自然周对比 CTR"
                }
            },
            "12_do_not_change": "不删除 'Mental Performance' 品牌词（保留品牌资产于标题尾部）；不动价格与 MOQ（官方定价优化任务单独执行）",
            "13_future_actions": ["标题简化: 主词 Caffeine 前置（候选标题已生成，见 Stage B）", "官方定价优化清单联动执行", "补 15-30s 成分讲解视频"],
            "14_validation_metric": "CTR / 点击 / 询盘（主图更换后完整自然周，A/B 对照）",
            "15_validation_period": "1 个完整自然周",
            "16_confidence": "medium（主图未获像素级实读，方案基于数据与品类惯例，AI_INFERENCE 已标注）",
            "17_evidence_source": "data_advisor_shop_product W1 官方数据 + 官方 API 组件数据 + 官方诊断任务清单（AI_INFERENCE 已标注）"
        }
    },
    {
        "product_id": "1601719605709",
        "primary_action": "DETAIL_B2B_SECTION",
        "title": CURRENT_TITLE_POUCH,
        "plan": {
            "1_why_selected": "官方爆品；W1 GMV $158 为 8 候选最高（订单 2）但询盘 0、TM 仅 1 → 直接成交存在但 B2B 商机链路断裂，成长天花板明显",
            "2_current_problem": "询盘 0 / TM 1：买家直接下单而非建立商机关系；详情页缺少定制参数引导与询盘转化路径",
            "3_data_evidence": "W1: 搜索曝光 416(coc +16.2%) | 点击 9 | CTR 2.16% | 询盘 0 | TM 1 | 订单 2 | GMV $158；价格 $1.85-1.99、MOQ 2000 pcs；认证 HALAL/HACCP/FSC（Listing 实读）",
            "4_self_history": "曝光温和增长（+16.2%），订单 2 说明购买意图存在",
            "5_peer_gap": "订单/曝光 0.48% 尚可；询盘为 0 显著弱于同类 B2B 品（店均询盘转化存在）",
            "6_buyer_intent": "Caffeine Pouch 新兴品类买家（品牌商/分销商）核心诉求: 定制参数（咖啡因 mg/口味/包装形式/logo 工艺）—— AI_INFERENCE: 基于品类定制属性与买家身份结构推断",
            "7_listing_diagnosis": "详情页无 'Customization Menu' 参数表；无 OEM 流程说明；询盘 CTA 弱；'FOB China' 在标题但详情未承接",
            "8_competitor_gap": "UNAVAILABLE（无竞品明细数据）",
            "9_root_cause": "详情页缺少 B2B 定制参数与询盘转化模块，把买家直接导向下单而非建立商机关系",
            "10_primary_action": "DETAIL_B2B_SECTION（本轮唯一变量）",
            "11_concrete_plan": {
                "type": "DETAIL_B2B_SECTION",
                "detail_modules": [
                    {"module": "模块1 产品核心价值", "content": "速溶咖啡因袋装粉：能量/专注/天然香料；首屏价值主张（3 行内）"},
                    {"module": "模块2 规格/配方/剂型", "content": "咖啡因含量梯度表（0/50/100/200mg）+ 剂型粉末袋装 + 口味列表"},
                    {"module": "模块3 OEM/ODM", "content": "配方定制 4 步流程（需求→打样→量产→交付）+ 现有 Nootropic 配方库"},
                    {"module": "模块4 包装定制", "content": "包装形式（袋/罐/盒）+ logo 工艺选项（印刷/贴标）"},
                    {"module": "模块5 认证", "content": "HALAL / HACCP / FSC 图标行（真实持有的认证，不虚构）"},
                    {"module": "模块6 工厂能力", "content": "工贸一体、出口 12 年、GMP 产线（来自店铺档案真实信息）"},
                    {"module": "模块7 MOQ/Sample", "content": "标准 MOQ 2000 pcs；样品获取路径（需与工厂确认样品政策，禁止虚构样品价）"},
                    {"module": "模块8 交期", "content": "量产交期（以工厂实际为准，需确认后填写）"},
                    {"module": "模块9 询价 CTA", "content": "页面顶部+底部双 'Request Quote' CTA + 定制需求预填表单"}
                ],
                "moq_ladder": {
                    "current": {"moq": "2000 pcs", "price": "$1.85-1.99", "source": "Listing 实读"},
                    "problem": "无试单档与样品信息，小品牌商望而却步",
                    "buyer_risk": "品牌商需先验证口味/包装再批量下单；2000 pcs 直接起步风险高",
                    "suggested_structure": [
                        {"tier": "Sample", "suggest": "样品政策（Listing 未展示样品价 → 需与工厂确认后填写，禁止 AI 虚构）", "status": "需人工确认"},
                        {"tier": "Trial Order", "suggest": "500 pcs 试单档（价格上浮 10-15% 覆盖小批量成本）—— 需工厂确认产能后实施", "status": "需人工确认"},
                        {"tier": "Standard MOQ", "suggest": "2000 pcs（现状保留）", "status": "现状"},
                        {"tier": "Bulk Order", "suggest": "10000+ pcs 阶梯价（需与工厂确认阶梯折扣）", "status": "需人工确认"}
                    ],
                    "ai_note": "所有试单/样品档位为建议结构，实际可提供性必须经工厂确认；AI 未虚构任何 MOQ/价格。"
                }
            },
            "12_do_not_change": "不动 MOQ 2000 pcs 主档（定制产线经济性）；不动价格 $1.85-1.99（B2B 阶梯另行评估）；不修改认证列表（仅展示真实持有的 HALAL/HACCP/FSC）",
            "13_future_actions": ["客服话术: TM 咨询 24h 内引导发起询盘", "属性补 'Customized Support: OEM/ODM' 与 'Main Ingredient: Caffeine + Nootropics'", "若 MOQ 阶梯确认后评估广告承接"],
            "14_validation_metric": "询盘数 / TM 数 / 询盘→订单转化（详情模块上线后完整自然周）",
            "15_validation_period": "1 个完整自然周",
            "16_confidence": "medium（详情模块结构基于品类惯例；MOQ 档位需人工确认）",
            "17_evidence_source": "data_advisor_shop_product W1 官方数据 + 公开 Listing 实读（价格/MOQ/认证）+ 店铺档案 + 买家身份画像（AI_INFERENCE 已标注）"
        }
    },
]


def main() -> int:
    conn = sqlite3.connect(str(DB))
    try:
        for p in PLANS:
            cur = conn.execute(
                """UPDATE product_optimizations
                   SET deep_plan_json=?, plan_version='v1.1',
                       status=COALESCE(status,'未处理'),
                       updated_at=datetime('now')
                   WHERE product_id=?""",
                (json.dumps(p["plan"], ensure_ascii=False), p["product_id"]),
            )
            print(f"  {p['product_id']}: {p['primary_action']} rows={cur.rowcount}")
        conn.commit()
        n = conn.execute("SELECT COUNT(*) FROM product_optimizations WHERE deep_plan_json IS NOT NULL").fetchone()[0]
        print(f"deep plans: {n}/8")
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
