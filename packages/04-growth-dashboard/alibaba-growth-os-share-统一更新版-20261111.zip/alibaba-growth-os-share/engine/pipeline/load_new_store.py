# -*- coding: utf-8 -*-
"""新店建库回填：schema + 扩展 DDL + store/meta + 周/月大盘 + 产品全量
用法: python load_new_store.py
"""
import json, sqlite3, sys, io, os
from datetime import datetime
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

ROOT = os.path.dirname(os.path.abspath(__file__))
SCHEMA = os.path.join(ROOT, 'alibaba-growth-os', 'schema.sql')
DB = os.path.join(ROOT, 'database', 'alibaba_growth.db')
RAW = os.path.join(ROOT, 'raw')

# ---- 新店常量 ----
STORE_NAME = "深圳市莱华仕生物科技有限公司 (Shenzhen Lifeworth Biotechnology Co., Ltd.)"
STORE_ALIID = "1653192276"                       # 店铺 store_id（莱华仕·运动营养）
MAIN_CATEGORY = "Health Care > Healthcare Supplements > Sports Nutrition"
CATE_ID = 202029902
ADVISORY_DATE = "2026-08-23"

EXT_DDL = """
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT
);
CREATE TABLE IF NOT EXISTS store_weekly_stats (
    stat_week_end TEXT PRIMARY KEY,
    stat_week_start TEXT,
    total_imps INTEGER, se_imps INTEGER, se_clk INTEGER, se_ctr REAL,
    camp_imps INTEGER, camp_clk INTEGER, qzt_clk INTEGER, p4p_imps INTEGER, p4p_clk INTEGER,
    pv_cnt INTEGER, uv_cnt INTEGER, uv_ab_rate REAL,
    suc_ord_cnt INTEGER, suc_ord_amt REAL, suc_byr_cnt INTEGER, crt_ord_cnt INTEGER,
    add_cart_cnt INTEGER, valid_prod_cnt INTEGER, top_prod_cnt INTEGER,
    fb_cnt INTEGER, fb_uv INTEGER, fb_tm_uv INTEGER,
    fst_reply_rate30d REAL, fst5min_reply_rate30d REAL, avg_reply_time30d REAL,
    uv_payord_rate REAL,
    total_imps_rival_avg INTEGER, total_imps_rival_good INTEGER,
    se_imps_rival_avg INTEGER, se_imps_rival_good INTEGER,
    se_clk_rival_avg INTEGER, se_clk_rival_good INTEGER,
    se_ctr_rival_avg REAL, se_ctr_rival_good REAL,
    camp_imps_rival_avg INTEGER, camp_imps_rival_good INTEGER,
    camp_clk_rival_avg INTEGER, camp_clk_rival_good INTEGER,
    uv_cnt_rival_good INTEGER, pv_cnt_rival_good INTEGER,
    uv_ab_rate_rival_avg REAL, uv_ab_rate_rival_good REAL,
    suc_ord_cnt_rival_avg INTEGER, suc_ord_cnt_rival_good INTEGER,
    suc_ord_amt_rival_avg REAL, suc_ord_amt_rival_good REAL,
    suc_byr_cnt_rival_good INTEGER, crt_ord_cnt_rival_avg INTEGER, crt_ord_cnt_rival_good INTEGER,
    top_prod_cnt_rival_avg INTEGER, top_prod_cnt_rival_good INTEGER,
    valid_prod_cnt_rival_avg INTEGER, valid_prod_cnt_rival_good INTEGER,
    fst_reply_rate30d_rival_avg REAL, fst_reply_rate30d_rival_good REAL,
    fst5min_reply_rate30d_rival_avg REAL, fst5min_reply_rate30d_rival_good REAL,
    avg_reply_time30d_rival_avg REAL,
    uv_payord_rate_rival_avg REAL, uv_payord_rate_rival_good REAL,
    raw_json TEXT
);
CREATE TABLE IF NOT EXISTS store_monthly_stats (
    month_start TEXT PRIMARY KEY,
    month_end TEXT,
    total_imps INTEGER, se_imps INTEGER, se_clk INTEGER, se_ctr REAL,
    camp_imps INTEGER, camp_clk INTEGER,
    pv_cnt INTEGER, uv_cnt INTEGER, uv_ab_rate REAL,
    suc_ord_cnt INTEGER, suc_ord_amt REAL, suc_byr_cnt INTEGER,
    valid_prod_cnt INTEGER, top_prod_cnt INTEGER,
    fst_reply_rate30d REAL, fst5min_reply_rate30d REAL, avg_reply_time30d REAL,
    total_imps_rival_avg INTEGER, total_imps_rival_good INTEGER,
    suc_ord_amt_rival_avg REAL, suc_ord_amt_rival_good REAL,
    raw_json TEXT
);
CREATE TABLE IF NOT EXISTS product_weekly_stats_ext (
    product_id TEXT NOT NULL,
    week_start TEXT NOT NULL,
    total_imps INTEGER, total_clk INTEGER,
    ad_imps INTEGER, ad_clk INTEGER,
    p4p_imps INTEGER, p4p_clk INTEGER,
    atm_fb_uv INTEGER, mc_fb_uv INTEGER,
    fav INTEGER, cmp INTEGER, share INTEGER,
    crt_ord INTEGER, rts_online_amt REAL, byr_cnt_online_rts INTEGER,
    sum_show_coc REAL, sum_click_coc REAL, sum_visitor_coc REAL,
    PRIMARY KEY (product_id, week_start)
);
CREATE TABLE IF NOT EXISTS customer_profile_snapshot (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_date TEXT, nd TEXT, byr_growth_level TEXT, dimension TEXT, payload_json TEXT
);
CREATE TABLE IF NOT EXISTS service_diag_snapshot (
    stats_date TEXT PRIMARY KEY, buyer_type INTEGER,
    reply_time REAL, five_min_reply_rate REAL, buyer_rnr_rate REAL,
    buyer_ab3_rate REAL, evaluation_score REAL,
    reply_time_avg REAL, five_min_reply_rate_avg REAL, buyer_rnr_rate_avg REAL,
    buyer_ab3_rate_avg REAL, evaluation_score_avg REAL,
    five_min_reply_rate_20th REAL, buyer_rnr_rate_20th REAL,
    buyer_ab3_rate_20th REAL, evaluation_score_20th REAL,
    buyer_has_trans_rate REAL, buyer_nrl_num INTEGER, remind_open_acct_num INTEGER,
    raw_json TEXT
);
CREATE TABLE IF NOT EXISTS industry_trend (
    cate_id INTEGER NOT NULL, period_index INTEGER NOT NULL,
    ab_cnt INTEGER, ab_cnt_yoy REAL, supply_demand_rate REAL, d_ab_rate REAL,
    raw_json TEXT,
    PRIMARY KEY (cate_id, period_index)
);
CREATE TABLE IF NOT EXISTS diagnosis_actions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    product_id TEXT, action_type TEXT NOT NULL, primary_variable TEXT,
    description TEXT NOT NULL, data_evidence TEXT, before_snapshot TEXT,
    recommended_change TEXT, validation_metric TEXT, validation_period_days INTEGER,
    ai_inference INTEGER NOT NULL DEFAULT 1, confidence TEXT,
    status TEXT NOT NULL DEFAULT 'suggested', source TEXT
);
CREATE TABLE IF NOT EXISTS product_optimizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    product_id TEXT NOT NULL, title TEXT, why_selected TEXT, current_problem TEXT,
    data_evidence TEXT, self_history TEXT, peer_gap TEXT, buyer_intent TEXT,
    listing_gap TEXT, root_cause TEXT, primary_action TEXT, secondary_actions TEXT,
    do_not_do TEXT, validation_metric TEXT, validation_period TEXT,
    candidate_titles TEXT, image_brief TEXT, attributes_gap TEXT, detail_modules TEXT,
    ai_inference INTEGER NOT NULL DEFAULT 1, confidence TEXT,
    listing_read INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_po_prod ON product_optimizations(product_id);
CREATE INDEX IF NOT EXISTS idx_da_prod ON diagnosis_actions(product_id);
"""

def load_raw(name):
    p = os.path.join(RAW, name)
    if not os.path.exists(p):
        return None
    with open(p, 'rb') as f:
        raw = f.read()
    if raw[:2] == b'\xff\xfe':
        return json.loads(raw.decode('utf-16'))
    if raw[:3] == b'\xef\xbb\xbf':
        return json.loads(raw.decode('utf-8-sig'))
    return json.loads(raw.decode('utf-8'))

def num(v, default=None):
    if v is None or v == "" or v == "null":
        return default
    try:
        f = float(v)
        return int(f) if f == int(f) else f
    except (TypeError, ValueError):
        return default

def main():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    try:
        with open(SCHEMA, encoding='utf-8') as f:
            conn.executescript(f.read())
        conn.executescript(EXT_DDL)

        # products 扩展列
        existing = {r[1] for r in conn.execute("PRAGMA table_info(products)").fetchall()}
        for col, ddl in [
            ("prod_level", "ALTER TABLE products ADD COLUMN prod_level TEXT"),
            ("detail_url", "ALTER TABLE products ADD COLUMN detail_url TEXT"),
            ("category_name", "ALTER TABLE products ADD COLUMN category_name TEXT"),
            ("cate_id", "ALTER TABLE products ADD COLUMN cate_id INTEGER"),
            ("moq", "ALTER TABLE products ADD COLUMN moq INTEGER"),
            ("price_range", "ALTER TABLE products ADD COLUMN price_range TEXT"),
        ]:
            if col not in existing:
                conn.execute(ddl)

        # store + meta
        conn.execute(
            """INSERT INTO store (id, name, store_id, currency, timezone)
               VALUES (1, ?, ?, 'USD', 'Asia/Shanghai')
               ON CONFLICT(id) DO UPDATE SET name=excluded.name,
                   store_id=excluded.store_id, currency=excluded.currency,
                   timezone=excluded.timezone, updated_at=datetime('now')""",
            (STORE_NAME, STORE_ALIID))
        meta = {
            "schema_version": "1.0-stageA+stageB",
            "store_binding": STORE_ALIID,
            "store_name": STORE_NAME,
            "main_category": MAIN_CATEGORY,
            "cate_id": str(CATE_ID),
            "advisory_date": ADVISORY_DATE,
            "initialized_at": datetime.now().isoformat(timespec="seconds"),
            "data_source": "alibaba-data-advisor-official-mcp",
            "timezone": "Asia/Shanghai",
        }
        conn.executemany("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                         [(k, str(v)) for k, v in meta.items()])

        # 周度汇总
        week_files = {
            "2026-08-02": ("2026-07-27", "shop_summary_w4_20260727-0802.json"),
            "2026-08-09": ("2026-08-03", "shop_summary_w3_20260803-0809.json"),
            "2026-08-16": ("2026-08-10", "shop_summary_w2_20260810-0816.json"),
            "2026-08-23": ("2026-08-17", "shop_summary_w1_20260817-0823.json"),
        }
        for week_end, (week_start, fname) in week_files.items():
            d = load_raw(fname)
            if not d or not d.get("data"):
                print(f"[warn] missing {fname}"); continue
            r = d["data"][0]
            conn.execute(
                """INSERT OR REPLACE INTO store_weekly_stats
                   (stat_week_end, stat_week_start, total_imps, se_imps, se_clk, se_ctr,
                    camp_imps, camp_clk, qzt_clk, p4p_imps, p4p_clk,
                    pv_cnt, uv_cnt, uv_ab_rate, suc_ord_cnt, suc_ord_amt, suc_byr_cnt,
                    crt_ord_cnt, add_cart_cnt, valid_prod_cnt, top_prod_cnt,
                    fb_cnt, fb_uv, fb_tm_uv,
                    fst_reply_rate30d, fst5min_reply_rate30d, avg_reply_time30d, uv_payord_rate,
                    total_imps_rival_avg, total_imps_rival_good,
                    se_imps_rival_avg, se_imps_rival_good,
                    se_clk_rival_avg, se_clk_rival_good,
                    se_ctr_rival_avg, se_ctr_rival_good,
                    camp_imps_rival_avg, camp_imps_rival_good,
                    camp_clk_rival_avg, camp_clk_rival_good,
                    uv_cnt_rival_good, pv_cnt_rival_good,
                    uv_ab_rate_rival_avg, uv_ab_rate_rival_good,
                    suc_ord_cnt_rival_avg, suc_ord_cnt_rival_good,
                    suc_ord_amt_rival_avg, suc_ord_amt_rival_good,
                    suc_byr_cnt_rival_good, crt_ord_cnt_rival_avg, crt_ord_cnt_rival_good,
                    top_prod_cnt_rival_avg, top_prod_cnt_rival_good,
                    valid_prod_cnt_rival_avg, valid_prod_cnt_rival_good,
                    fst_reply_rate30d_rival_avg, fst_reply_rate30d_rival_good,
                    fst5min_reply_rate30d_rival_avg, fst5min_reply_rate30d_rival_good,
                    avg_reply_time30d_rival_avg,
                    uv_payord_rate_rival_avg, uv_payord_rate_rival_good,
                    raw_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (week_end, week_start,
                 num(r.get("totalImpsCnt")), num(r.get("seImpsCnt")), num(r.get("seClkCnt")), num(r.get("seCtr")),
                 num(r.get("campImpsCnt")), num(r.get("campClkCnt")), num(r.get("qztClkCnt")),
                 num(r.get("p4pImpsCnt")), num(r.get("p4pClkCnt")),
                 num(r.get("pvCnt")), num(r.get("uvCnt")), num(r.get("uvAbRate")),
                 num(r.get("sucOrdCnt")), num(r.get("sucOrdAmt")), num(r.get("sucByrCnt")),
                 num(r.get("crtOrdCnt")), num(r.get("addCartCnt")),
                 num(r.get("validProdCnt")), num(r.get("topProdCnt")),
                 num(r.get("fbCnt")), num(r.get("fbUv")), num(r.get("fbTmUv")),
                 num(r.get("fstReplyRate30d")), num(r.get("fst5minReplyRate30d")),
                 num(r.get("avgReplyTime30d")), num(r.get("uvPayordRate")),
                 num(r.get("totalImpsCntRivalAvg")), num(r.get("totalImpsCntRivalGood")),
                 num(r.get("seImpsCntRivalAvg")), num(r.get("seImpsCntRivalGood")),
                 num(r.get("seClkCntRivalAvg")), num(r.get("seClkCntRivalGood")),
                 num(r.get("seCtrRivalAvg")), num(r.get("seCtrRivalGood")),
                 num(r.get("campImpsCntRivalAvg")), num(r.get("campImpsCntRivalGood")),
                 num(r.get("campClkCntRivalAvg")), num(r.get("campClkCntRivalGood")),
                 num(r.get("uvCntRivalGood")), num(r.get("pvCntRivalGood")),
                 num(r.get("uvAbRateRivalAvg")), num(r.get("uvAbRateRivalGood")),
                 num(r.get("sucOrdCntRivalAvg")), num(r.get("sucOrdCntRivalGood")),
                 num(r.get("sucOrdAmtRivalAvg")), num(r.get("sucOrdAmtRivalGood")),
                 num(r.get("sucByrCntRivalGood")), num(r.get("crtOrdCntRivalAvg")), num(r.get("crtOrdCntRivalGood")),
                 num(r.get("topProdCntRivalAvg")), num(r.get("topProdCntRivalGood")),
                 num(r.get("validProdCntRivalAvg")), num(r.get("validProdCntRivalGood")),
                 num(r.get("fstReplyRate30dRivalAvg")), num(r.get("fstReplyRate30dRivalGood")),
                 num(r.get("fst5minReplyRate30dRivalAvg")), num(r.get("fst5minReplyRate30dRivalGood")),
                 num(r.get("avgReplyTime30dRivalAvg")),
                 num(r.get("uvPayordRateRivalAvg")), num(r.get("uvPayordRateRivalGood")),
                 json.dumps(r, ensure_ascii=False)))

        # 月度汇总
        month_files = {
            "2026-07": ("2026-07-01", "2026-07-31", "shop_summary_month7_20260701-0731.json"),
            "2026-08-mtd": ("2026-08-01", "2026-08-23", "shop_summary_mtd_20260801-0823.json"),
        }
        for key, (ms, me, fname) in month_files.items():
            d = load_raw(fname)
            if not d or not d.get("data"):
                print(f"[warn] missing {fname}"); continue
            r = d["data"][0]
            conn.execute(
                """INSERT OR REPLACE INTO store_monthly_stats
                   (month_start, month_end, total_imps, se_imps, se_clk, se_ctr,
                    camp_imps, camp_clk, pv_cnt, uv_cnt, uv_ab_rate,
                    suc_ord_cnt, suc_ord_amt, suc_byr_cnt, valid_prod_cnt, top_prod_cnt,
                    fst_reply_rate30d, fst5min_reply_rate30d, avg_reply_time30d,
                    total_imps_rival_avg, total_imps_rival_good,
                    suc_ord_amt_rival_avg, suc_ord_amt_rival_good, raw_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (ms, me,
                 num(r.get("totalImpsCnt")), num(r.get("seImpsCnt")), num(r.get("seClkCnt")), num(r.get("seCtr")),
                 num(r.get("campImpsCnt")), num(r.get("campClkCnt")),
                 num(r.get("pvCnt")), num(r.get("uvCnt")), num(r.get("uvAbRate")),
                 num(r.get("sucOrdCnt")), num(r.get("sucOrdAmt")), num(r.get("sucByrCnt")),
                 num(r.get("validProdCnt")), num(r.get("topProdCnt")),
                 num(r.get("fstReplyRate30d")), num(r.get("fst5minReplyRate30d")),
                 num(r.get("avgReplyTime30d")),
                 num(r.get("totalImpsCntRivalAvg")), num(r.get("totalImpsCntRivalGood")),
                 num(r.get("sucOrdAmtRivalAvg")), num(r.get("sucOrdAmtRivalGood")),
                 json.dumps(r, ensure_ascii=False)))

        # 产品主档 + 周表现
        def prod_file(pg):
            two = f"shop_product_w1_p{pg:02d}.json"
            return two if os.path.exists(os.path.join(RAW, two)) else None

        prod_rows = []
        for pg in range(1, 50):
            fname = prod_file(pg)
            if not fname:
                continue
            d = load_raw(fname)
            if not d or not d.get("data"):
                continue
            dd = d["data"]
            items = dd.get("data") or []
            for it in items:
                pid = str(it.get("id"))
                prod_rows.append((pid, it.get("prodName") or it.get("subject") or "",
                                  it.get("cateName"), it.get("categoryId"),
                                  it.get("priceRange") or it.get("price"),
                                  it.get("minOrderQuantity"), it.get("prodLevel3"),
                                  it.get("detailUrl") or it.get("productDetailUrl"),
                                  json.dumps(it, ensure_ascii=False)))
        conn.executemany(
            """INSERT OR REPLACE INTO products
               (product_id, title, category, price, status, first_seen_at, last_seen_at, raw)
               VALUES (?, ?, ?, ?, ?, '2026-08-16', '2026-08-16', ?)""",
            [(p[0], p[1], p[2], p[3], p[6], p[7]) for p in prod_rows])
        conn.executemany(
            """UPDATE products SET category_name=?, cate_id=?, price_range=?,
               moq=?, prod_level=?, detail_url=? WHERE product_id=?""",
            [(p[2], num(p[3]), p[4], num(p[5]), p[6], p[7], p[0]) for p in prod_rows])

        wk_rows = []
        for pg in range(1, 50):
            fname = prod_file(pg)
            if not fname:
                continue
            d = load_raw(fname)
            if not d or not d.get("data"):
                continue
            for it in (d["data"].get("data") or []):
                pid = str(it.get("id"))
                wk_rows.append((
                    pid, "2026-08-17",
                    num(it.get("sumProdShowNum")), num(it.get("sumProdClickNum")),
                    num(it.get("sumProdClickRate")),
                    num(it.get("sumProdFbNum")), num(it.get("mcFbUv")),
                    num(it.get("crtOrd")), num(it.get("rtsOnlineAmt")),
                    num(it.get("totalImpsCnt")), num(it.get("totalClkCnt")),
                    num(it.get("adImpsCnt")), num(it.get("adClkCnt")),
                    num(it.get("p4pImpsCnt")), num(it.get("p4pClkCnt")),
                    num(it.get("atmFbUv")), num(it.get("fav")), num(it.get("cmp")),
                    num(it.get("sumProdShowNumCoc")), num(it.get("sumProdClickNumCoc")),
                    num(it.get("sumProdVisitorCntCoc")), num(it.get("byrCntOnlineRts")),
                ))
        conn.executemany(
            """INSERT OR REPLACE INTO product_weekly_stats
               (product_id, week_start, week_end, impressions, clicks, ctr, inquiries, orders, gmv)
               VALUES (?, ?, '2026-08-23', ?, ?, ?, ?, ?, ?)""",
            [(w[0], w[1], w[2], w[3], w[4], w[5], w[7], w[8]) for w in wk_rows])
        conn.executemany(
            """INSERT OR REPLACE INTO product_weekly_stats_ext
               (product_id, week_start, total_imps, total_clk, ad_imps, ad_clk,
                p4p_imps, p4p_clk, atm_fb_uv, mc_fb_uv, fav, cmp,
                crt_ord, rts_online_amt, byr_cnt_online_rts,
                sum_show_coc, sum_click_coc, sum_visitor_coc)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            [(w[0], w[1], w[9], w[10], w[11], w[12], w[13], w[14], w[15], w[6], w[16], w[17],
              w[7], w[8], w[21], w[18], w[19], w[20]) for w in wk_rows])

        conn.execute(
            """INSERT INTO sync_log (source, records, status, message, finished_at)
               VALUES ('alibaba-data-advisor-official-mcp', ?, 'success', ?, datetime('now'))""",
            (len(prod_rows), f"莱华仕周更回填: 4周+1月+MTD, 产品 {len(prod_rows)} 条, advisory {ADVISORY_DATE}"))

        conn.commit()

        checks = {
            "integrity_check": conn.execute("PRAGMA integrity_check").fetchone()[0],
            "store": conn.execute("SELECT name, store_id FROM store WHERE id=1").fetchone(),
            "products": conn.execute("SELECT COUNT(*) FROM products").fetchone()[0],
            "product_weekly": conn.execute("SELECT COUNT(*) FROM product_weekly_stats").fetchone()[0],
            "store_weekly": conn.execute("SELECT COUNT(*) FROM store_weekly_stats").fetchone()[0],
            "store_monthly": conn.execute("SELECT COUNT(*) FROM store_monthly_stats").fetchone()[0],
        }
        print(json.dumps(checks, ensure_ascii=False, indent=1, default=str))
        fk = conn.execute("PRAGMA foreign_key_check").fetchall()
        print("foreign_key_check:", "PASS" if not fk else fk)
        return 0
    finally:
        conn.close()

if __name__ == "__main__":
    raise SystemExit(main())
