# -*- coding: utf-8 -*-
"""
V5: AI 产品评分引擎 —— 每个产品 0-100 分 + 好的点/不好的点 + 产品化建议
"""
import sqlite3, json, io, sys, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
DB = 'database/alibaba_growth.db'

c = sqlite3.connect(DB)
c.row_factory = sqlite3.Row
cur = c.cursor()

# 最新完整周（从 DB 取，不写死日期；换店铺/换周期自动适配）
_wk = cur.execute("SELECT stat_week_end, stat_week_start FROM store_weekly_stats ORDER BY stat_week_end DESC LIMIT 1").fetchone()
if _wk:
    WEEK_END = _wk['stat_week_end']; WEEK_START = _wk['stat_week_start']
else:
    WEEK_END = '2026-08-16'; WEEK_START = '2026-08-10'  # 兜底：DB 尚无周数据

cur.execute("""SELECT p.product_id, p.title, p.prod_level, p.category_name, p.moq, p.price_range, p.main_image, p.detail_url, p.cate_id,
  ps.impressions, ps.clicks, ps.ctr, ps.inquiries, ps.orders, ps.gmv,
  e.atm_fb_uv, e.ad_clk, e.ad_imps
  FROM products p
  LEFT JOIN product_weekly_stats ps ON ps.product_id=p.product_id AND ps.week_end=?
  LEFT JOIN product_weekly_stats_ext e ON e.product_id=p.product_id AND e.week_start=?
  """, (WEEK_END, WEEK_START))
rows = [dict(r) for r in cur.fetchall()]

# 市场趋势：cate_id → 最新询盘同比增速
mt_map = {}
for r in cur.execute("SELECT cate_id, period_index, ab_cnt_yoy FROM industry_trend ORDER BY cate_id, period_index"):
    mt_map[r['cate_id']] = float(r['ab_cnt_yoy'] or 0)  # 最后一条 = 最新
def market_growth(cate_id):
    return mt_map.get(cate_id, 0)

# 市场趋势证据（多源：全球市场报告 + 社媒/亚马逊 + 资深运营判断）
EVIDENCE = {}
if os.path.exists('raw/market_evidence.json'):
    with open('raw/market_evidence.json', encoding='utf-8') as f:
        EVIDENCE = json.load(f)

# 主图视觉诊断（type/bg/sellpoint/cert/risk → b2b/ai/vision_score/advices）
VISION = {}
if os.path.exists('raw/vision_full.json'):
    with open('raw/vision_full.json', encoding='utf-8') as f:
        VISION = json.load(f)

def classify_cat(title, cat):
    t = ((title or '') + ' ' + (cat or '')).lower()
    # 擦边优先（壮阳/减肥/私处），即使混在咖啡/蛋白里也要标风险
    if 'maca' in t or 'tongkat' in t or 'male' in t or 'penis' in t or 'testosterone' in t or 'sexual' in t or 'erectile' in t or 'vitality' in t or 'enlargement' in t:
        return 'maca'
    if 'detox' in t or 'weight loss' in t or 'slim' in t or 'diet' in t or 'fat burn' in t or 'skinny' in t or 'lose weight' in t:
        return 'detox'
    # 剂型优先（独立剂型赛道，先于功能词，避免 Oral Spray 被 oral→strip 误伤）
    if 'spray' in t or ' mist' in t or 'nasal' in t or ' throat' in t:
        return 'spray'
    if 'pouch' in t or 'sachet' in t or 'stick pack' in t or 'stickpack' in t or ' sublingual' in t or ' oral pouch' in t:
        return 'pouch'
    if 'strip' in t or 'film' in t or 'oral film' in t or 'fast dissolve' in t or 'dissolving' in t:
        return 'strip'
    # 功能赛道（睡眠/菌菇/备孕/生酮/电解质/益智，先于剂型，避免 Mushroom Coffee 被 coffee 抢走）
    if 'sleep' in t or 'melatonin' in t or '5-htp' in t or '5htp' in t or 'insomnia' in t or 'dream' in t or 'night' in t:
        return 'sleep'
    if 'mushroom' in t or 'reishi' in t or "lion's mane" in t or 'lions mane' in t or 'ganoderma' in t or 'cordyceps' in t or 'turkey tail' in t or 'chaga' in t:
        return 'mushroom'
    if 'fertility' in t or 'womb' in t or 'prenatal' in t or 'conception' in t or 'reproductive' in t:
        return 'fertility'
    if 'keto' in t or 'ketogenic' in t or ' mct' in t or ' mct ' in t:
        return 'keto'
    if 'electrolyte' in t or 'hydration' in t or 'rehydration' in t:
        return 'electrolyte'
    if 'nootropic' in t or 'alpha gpc' in t or 'l-theanine' in t or 'cognition' in t or 'focus' in t or 'brain' in t:
        return 'nootropic'
    # 剂型（片剂/液体/茶/咖啡）
    if 'tablet' in t or 'tablets' in t or 'pills' in t or 'effervescent' in t or 'lozenge' in t:
        return 'tablet'
    if 'liquid' in t or 'drop' in t or 'drops' in t or 'tincture' in t or 'syrup' in t or ' shot' in t:
        return 'liquid'
    if 'tea' in t or 'matcha' in t or 'chai' in t:
        return 'tea'
    if 'coffee' in t or 'espresso' in t or 'mocha' in t or 'latte' in t or 'cappuccino' in t:
        return 'coffee'
    # 功能（蛋白/美容/能量/软糖/维生素）
    if 'creatine' in t or 'pre workout' in t or 'pre-workout' in t or 'protein' in t or 'whey' in t or 'bcaa' in t or 'amino' in t or 'eaa' in t:
        return 'pro'
    if 'collagen' in t or 'glutathione' in t or 'hyaluronic' in t or 'hair' in t or 'nail' in t or 'skin' in t or 'beauty' in t:
        return 'beauty'
    if 'energy drink' in t or 'caffeine' in t or ' energy' in t or 'energy ' in t:
        return 'energy'
    if 'gummies' in t or 'gummy' in t or 'softgel' in t or 'soft gel' in t or 'jelly' in t:
        return 'gummies'
    if 'vitamin' in t or 'mineral' in t or 'multivitamin' in t or 'biotin' in t or 'zinc' in t or 'magnesium' in t or 'omega' in t or 'fish oil' in t or 'probiotic' in t:
        return 'vitamin'
    if 'seamoss' in t or 'sea moss' in t or 'greens' in t or 'beet' in t or 'superfood' in t or 'spirulina' in t or 'chlorella' in t or 'bladderwrack' in t:
        return 'superfood'
    if 'nad' in t or 'resveratrol' in t or 'anti-aging' in t or 'antiaging' in t or 'nmn' in t or 'longevity' in t:
        return 'longevity'
    if 'prostate' in t or "men's" in t or ' mens ' in t or 'testosterone support' in t:
        return 'men'
    return 'generic'

# 产品化建议（资深运营打法：市场定位 + 3条打法 + 对标谁）
CAT_PLAYBOOK = {
    'pro': {
        "positioning": "蛋白/肌酸是认证门槛品类，B端买家只认 NSF/GMP/第三方检测+含量透明，赢家=认证墙+每勺含量表",
        "moves": [
            "主图像 ON Gold Standard 结构：每勺含量表大字 + 认证墙(GMP/NSF) + 训练场景",
            "详情放第三方检测报告+溶解测试视频，B端最看重『可验证』",
            "换掉 YOUR LOGO 白牌桶图，做成品牌感成品，中小品牌商认这个才下单",
        ],
        "benchmark": "对标 ON / MyProtein",
    },
    'collagen': {
        "positioning": "胶原蛋白拼『来源+分子量+吸收率』，美容+关节双卖点是溢价点，赢家=复合配方+吸收率数据",
        "moves": [
            "主图突出复合配方表 + 鱼/牛胶原来源，美容+关节双卖点并行",
            "详情放吸收率/分子量数据（B端最认数据），加前后对比图",
            "补 HALAL 认证，中东/东南亚买家卡这个才敢下大单",
        ],
        "benchmark": "对标 Youhealth / 胶原蛋白头部卖家",
    },
    'energy': {
        "positioning": "能量/咖啡是高频快消，B端要 OEM贴牌+稳定供货+口味多，赢家=冲泡场景图+咖啡因含量透明+合法不夸大",
        "moves": [
            "主图放冲泡场景（健身/加班/户外），别放白底产品图，参考 GU Energy 赛道图",
            "咖啡因 mg 含量写清楚 + 合法声明（不涉疾病治疗），这是信任底线",
            "详情突出口味多+可 OEM 贴牌+交期，快消买家重供货稳定性",
        ],
        "benchmark": "对标 GU Energy / 三顿半",
    },
    'maca': {
        "positioning": "壮阳是站内最卷的合规雷区，别硬碰。改赛道到『运动能量+耐力』，把复合配方周期表当差异化卖点",
        "moves": [
            "卖点从 male enhancement 改到 sports energy + stamina，瞄准运动营养而非性保健",
            "主图保留复合配方周期表（这是记忆点），但删掉壮阳暗示图和词",
            "对标 sports nutrition 类目，避开 sex category 的价格战和封杀",
        ],
        "benchmark": "对标运动营养，不做性保健",
    },
    'detox': {
        "positioning": "减肥茶是红海+合规雷区，别纠结改词。直接换赛道做『消化草本茶』，主打 bloating relief + gut health",
        "moves": [
            "整条 listing 从 weight loss 改到 digestive health / herbal tea，参考 Yogi Tea 蓝海打法",
            "主图放草本原料 + 冲泡场景，卖『消化舒缓』而非『瘦』",
            "客单价可翻倍：草本消化茶比减肥茶溢价高，且避开封杀",
        ],
        "benchmark": "对标 Yogi Tea / 草本茶蓝海",
    },
    'gummies': {
        "positioning": "软糖是增长最快的补充剂形态（好入口+便携+儿童向），B端要 OEM口味定制+低糖天然色素",
        "moves": [
            "主图放软糖实拍 + 口味颜色 + 便携场景，突出『好吃』这个剂型核心卖点",
            "详情强调低糖/天然色素/无明胶，这是软糖买家的三大卡点",
            "对标软糖行业头部卖家，补 OEM 口味+包装定制示意",
        ],
        "benchmark": "对标软糖行业头部卖家",
    },
    'vitamin': {
        "positioning": "维生素是基础盘，靠『剂量透明+认证+组合装』走量，赢家=多规格组合+第三方检测",
        "moves": [
            "主图放成分剂量表 + 认证，B端买家第一眼看剂量和认证",
            "详情放每日剂量建议 + 适用人群 + 第三方检测报告",
            "上组合装（多维生素+矿物质），拉高客单价和复购",
        ],
        "benchmark": "对标维生素头部 OEM 卖家",
    },
    'strip': {
        "positioning": "口溶膜是新兴剂型，卖『3秒速溶+便携+快吸收』，赢家=溶解演示视频+场景化",
        "moves": [
            "主图放薄膜实拍 + 3秒速溶演示（动态感），这是剂型最大卖点",
            "详情放溶解对比视频 + 便携场景（出差/健身/车上）",
            "强调快吸收（比胶囊快），这是口溶膜的差异化护城河",
        ],
        "benchmark": "对标口溶膜新兴品牌",
    },
    'spray': {
        "positioning": "口服喷雾卖『秒吸收+便携+精准剂量』，B端要 OEM 口味定制+便携细长瓶，赢家=喷吸动作图+剂量标清",
        "moves": [
            "主图放喷吸动作 + 便携场景（出差/助眠床头），突出『喷一下』的动作感",
            "详情放每次喷多少 mg + 每日喷几次，剂量精准是喷雾的核心卖点",
            "补 OEM 口味定制（薄荷/浆果/无味）+ 细长瓶身，便携是溢价点",
        ],
        "benchmark": "对标口服喷雾新锐品牌",
    },
    'pouch': {
        "positioning": "口含袋卖『免冲水+便携+快吸收』，B端要口味矩阵+多包装规格，赢家=口味颜色矩阵图",
        "moves": [
            "主图放袋装实拍 + 口味颜色矩阵，突出『撕开即含』的便利",
            "详情强调快吸收（口腔黏膜吸收）+ 便携（口袋/通勤），这是剂型护城河",
            "补多口味 SKU + 多包装规格（10/20/30袋装），快消买家重口味覆盖",
        ],
        "benchmark": "对标口含袋/能量袋头部品牌",
    },
    'tablet': {
        "positioning": "片剂是标准剂型，靠『剂量精准+易吞服+便携泡罩』走量，赢家=剂量表+泡罩包装",
        "moves": [
            "主图放片剂实拍 + 每片剂量表，B端买家第一眼看剂量",
            "详情放每日剂量建议 + 适用人群 + 第三方检测报告",
            "补泡罩包装 + 多规格组合，拉高客单价和便携体验",
        ],
        "benchmark": "对标片剂头部 OEM 卖家",
    },
    'liquid': {
        "positioning": "液体/滴剂卖『吸收快+剂量灵活』，B端要滴管瓶+OEM 定制，赢家=滴取动作图",
        "moves": [
            "主图放滴管瓶 + 滴取动作，突出『精准控量』",
            "详情强调吸收率（液体比胶囊快）+ 每滴剂量",
            "补滴管瓶 OEM + 防漏包装，液体运输是买家顾虑点",
        ],
        "benchmark": "对标滴剂/口服液头部卖家",
    },
    'nootropic': {
        "positioning": "益智补充剂卖『专注+记忆+情绪』，B端要科学背书+剂量透明，赢家=成分机理图+临床数据",
        "moves": [
            "主图放成分 + 剂量表，Alpha-GPC/L-茶氨酸等明星成分写清楚",
            "详情放临床数据/作用机理 + 适用人群（学生/上班族/电竞），科学背书是溢价点",
            "补认证 + 第三方检测，益智品最怕成分掺假",
        ],
        "benchmark": "对标益智补充剂头部品牌",
    },
    'tea': {
        "positioning": "茶饮卖『天然+配方+即冲』，B端要 OEM 配方+三角包/条装，赢家=冲泡场景图+成分茶包实拍",
        "moves": [
            "主图放冲泡场景 + 茶包/茶粉实拍，突出『天然草本』",
            "详情放成分表 + 每日冲泡建议 + 无糖/无咖啡因等差异点",
            "补三角包/条装多规格 + OEM 配方定制，茶饮重口味矩阵",
        ],
        "benchmark": "对标草本茶/即冲茶头部卖家",
    },
    'coffee': {
        "positioning": "咖啡卖『功能+风味』，B端要 OEM 配方+冻干/条装，赢家=杯测风味图+功能宣称（能量/益智）",
        "moves": [
            "主图放冲泡咖啡液 + 风味描述，功能咖啡突出成分（如灵芝咖啡）",
            "详情放风味矩阵 + 功能成分剂量 + 冻干/条装便携性",
            "补风味 SKU + OEM 配方，咖啡买家重风味覆盖",
        ],
        "benchmark": "对标功能咖啡/即冲咖啡头部品牌",
    },
    'sleep': {
        "positioning": "助眠品卖『安全+起效+不成瘾』，B端要成分剂量透明+临床背书，赢家=褪黑素/5-HTP 剂量表",
        "moves": [
            "主图放成分剂量表（褪黑素 mg / 5-HTP mg），剂量透明是助眠品信任基础",
            "详情放作用机理 + 无依赖说明 + 适用人群（倒时差/轮班）",
            "补第三方检测 + 无药物相互作用声明，助眠品合规风险高",
        ],
        "benchmark": "对标褪黑素/助眠补充剂头部品牌",
    },
    'mushroom': {
        "positioning": "菌菇补充剂卖『免疫+适应原』，B端要科学背书+子实体提取物，赢家=菌菇种类图+β-葡聚糖含量",
        "moves": [
            "主图放菌菇实拍 + 菌菇种类矩阵（灵芝/猴头菇/虫草），突出子实体提取",
            "详情放 β-葡聚糖含量 + 免疫/认知作用机理 + 双提取工艺",
            "补第三方检测（重金属/农残）+ 有机认证，菌菇品重原料纯净",
        ],
        "benchmark": "对标菌菇适应原头部品牌",
    },
    'fertility': {
        "positioning": "备孕品卖『科学配方+温和调理』，B端要成分安全+临床数据，赢家=成分机理图+男女分方",
        "moves": [
            "主图放男女分方 + 成分剂量表（叶酸/肌醇/辅酶Q10），分性别配方是卖点",
            "详情放临床数据 + 备孕周期建议 + 无激素声明",
            "补第三方检测 + 温和无副作用声明，备孕品信任门槛高",
        ],
        "benchmark": "对标备孕补充剂头部品牌",
    },
    'keto': {
        "positioning": "生酮品卖『快速入酮+能量』，B端要 MCT 含量+0碳水，赢家=入酮机制图+MCT 剂量",
        "moves": [
            "主图放 MCT 剂量 + 0碳水/0糖标识，生酮买家第一眼看碳水和MCT",
            "详情放入酮机制 + 与断食/运动搭配建议 + 防酮流感说明",
            "补 MCT 纯度第三方检测 + 生酮适用人群提示",
        ],
        "benchmark": "对标生酮/MCT 头部品牌",
    },
    'electrolyte': {
        "positioning": "电解质卖『快速补水+运动恢复』，B端要电解质配比+0糖，赢家=电解质配比表+运动场景",
        "moves": [
            "主图放钠/钾/镁配比表 + 运动出汗场景，配比科学是电解质核心卖点",
            "详情放补液时机 + 与运动/中暑/宿醉场景结合 + 0糖0卡",
            "补条装/泡腾多规格 + 口味矩阵，电解质是快消属性",
        ],
        "benchmark": "对标电解质补水头部品牌",
    },
    'beauty': {
        "positioning": "美容补充剂卖『内调+由内而外』，B端要成分剂量+临床，赢家=成分机理图+前后对比示意",
        "moves": [
            "主图放成分剂量（胶原蛋白肽/谷胱甘肽/玻尿酸）+ 美容功效场景",
            "详情放吸收率 + 服用周期 + 无添加激素声明",
            "补第三方检测 + 功效成分含量背书，美容品重剂量足",
        ],
        "benchmark": "对标口服美容头部品牌",
    },
    'superfood': {
        "positioning": "超级食物卖『天然+营养密度』，B端要原料纯净+有机认证，赢家=原料产地图+营养成分表",
        "moves": [
            "主图放原料实拍（海苔/甜菜根/绿粉）+ 营养密度标识，突出天然",
            "详情放营养成分表 + 产地 + 重金属/农残第三方检测",
            "补有机认证 + 纯素/非转基因标识，超级食物买家重纯净",
        ],
        "benchmark": "对标超级食物/绿粉头部品牌",
    },
    'longevity': {
        "positioning": "抗衰品卖『NAD/NMN科学背书』，B端要纯度+临床数据，赢家=成分纯度+作用机理图",
        "moves": [
            "主图放 NAD/NMN/白藜芦醇纯度 + 剂量，抗衰买家第一眼看纯度和剂量",
            "详情放作用机理（NAD+提升）+ 临床/文献背书 + 适用人群",
            "补第三方纯度检测 + 生产批次报告，抗衰品重可信度",
        ],
        "benchmark": "对标 NAD/NMN 抗衰头部品牌",
    },
    'men': {
        "positioning": "男性健康卖『前列腺+活力』，B端要成分剂量+安全，赢家=成分机理图+无副作用声明",
        "moves": [
            "主图放成分剂量表（锯棕榈/番茄红素）+ 男性健康场景",
            "详情放作用机理 + 适用人群 + 无激素/无副作用声明",
            "补第三方检测 + 认证，男性健康品信任门槛高",
        ],
        "benchmark": "对标男性健康补充剂头部品牌",
    },
    'generic': {
        "positioning": "通用品靠 OEM定制+认证+价格赢，B端买家要 logo/配方/包装全定制+交期",
        "moves": [
            "主图放产品实拍 + OEM 定制示意（Your Logo Your Formula）",
            "详情放定制流程(logo/配方/包装) + 认证 + MOQ/交期",
            "补认证墙，通用品没认证就只能在价格战里卷",
        ],
        "benchmark": "对标 OEM 大卖家",
    },
}
CAT_ADVICE = {k: {"focus": v["positioning"], "img": v["moves"][0], "detail": v["moves"][1] if len(v["moves"])>1 else "", "kw": v["benchmark"]} for k, v in CAT_PLAYBOOK.items()}

# 关键词类别检测（AI 搜索靠这些内容匹配买家意图）
KW_CATS = [
    ('品类词', ['creatine','collagen','coffee','caffeine','protein','whey','vitamin','maca','tongkat','gummies','glutathione','mushroom','herbal','electrolyte','reishi','ginseng','melatonin','keto','prenatal','mct','nootropic']),
    ('剂型词', ['capsule','powder','gummies','gummy','strips','film','softgel','tablet','jelly','liquid','pills','stick','spray','pouch','sachet','drops','tincture','effervescent','tea','coffee','lozenge']),
    ('规格词', ['mg','g ','gram','ml','oz','serving','2000mg','5g','100mg','10g']),
    ('场景词', ['pre workout','pre-workout','energy','recovery','sleep','immune','digest','joint','skin','hair','focus','muscle','hydrat','relax']),
    ('认证词', ['halal','iso','gmp','fssc','haccp','kosher','fda','organic','vegan','non-gmo','sgs']),
    ('功能词', ['muscle','anti-aging','whitening','booster','recovery','metabolism','beauty','memory']),
]
def detect_ai_attrs(title):
    t = (title or '').lower()
    present, missing = [], []
    for cat, kws in KW_CATS:
        if any(k in t for k in kws): present.append(cat)
        else: missing.append(cat)
    return present, missing

def judge_score(p):
    inq = p['inquiries'] or 0
    tm = p['atm_fb_uv'] or 0
    opp = inq + tm
    clk = p['clicks'] or 0
    ctr = (p['ctr'] or 0) * 100
    imps = p['impressions'] or 0
    adc = p['ad_clk'] or 0
    lvl = p['prod_level'] or ''
    cat = classify_cat(p['title'], p['category_name'])
    # 合规风险
    compliance_risk = cat in ('maca', 'detox')
    # ===== 维度化评分（看市场+listing+AI匹配+B2B转化，不看流量数据）=====
    dims = []
    title_len = len(p['title'] or '')
    has_img = bool(p['main_image'])
    has_detail = bool(p['detail_url'])
    # 1. 市场趋势（行业询盘增速 × 多源市场证据：报告/社媒/亚马逊）
    mg = market_growth(p.get('cate_id'))
    if mg >= 0.30: ms, ml = 90, '好'
    elif mg >= 0: ms, ml = 65, '中'
    elif mg < 0: ms, ml = 35, '差'
    else: ms, ml = 50, '中'
    ev = EVIDENCE.get(cat, EVIDENCE.get('generic', {}))
    if mg >= 0.30: mr = "品类询盘同比 +%d%%，风口赛道" % int(mg*100)
    elif mg >= 0: mr = "品类询盘同比 +%d%%，平稳" % int(mg*100)
    elif mg < 0: mr = "品类询盘同比 %d%%，需求下滑" % int(mg*100)
    else: mr = "无该品类趋势数据"
    if ev.get('verdict'):
        mr += "｜市场结论：" + ev['verdict']
    dims.append({"name":"市场趋势","score":ms,"level":ml,"reason":mr,"weight":20})
    # 2. AI识别匹配度（标题内容能被AI识别到什么：品类/剂型/规格/场景/认证/功能）
    ai_present, ai_missing = detect_ai_attrs(p['title'])
    ai_cov = len(ai_present) / 6.0
    if ai_cov >= 0.83: as_, al = 90, '好'
    elif ai_cov >= 0.5: as_, al = 65, '中'
    elif ai_cov >= 0.33: as_, al = 40, '差'
    else: as_, al = 20, '差'
    ar = "识别到：%s" % ('、'.join(ai_present) if ai_present else '几乎无')
    ar += ("；缺：%s" % ('、'.join(ai_missing))) if ai_missing else ""
    dims.append({"name":"AI识别匹配度","score":as_,"level":al,"reason":ar,"present":ai_present,"missing":ai_missing,"weight":25})
    # 3. Listing完整度（主图+详情页+层级）
    if has_img and has_detail and lvl in ('爆品','优品'): ls, ll, lr = 90, '好', "主图+详情页齐全，层级%s" % lvl
    elif has_img and has_detail: ls, ll, lr = 70, '中', "主图+详情页有，层级%s待提升" % (lvl or '普通')
    elif has_img: ls, ll, lr = 40, '差', "缺详情页/缺主图，listing不完整"
    else: ls, ll, lr = 20, '差', "主图缺失，listing严重不完整"
    dims.append({"name":"Listing完整度","score":ls,"level":ll,"reason":lr,"weight":20})
    # 4. B2B转化力（主图×详情页质量为主，数据为辅——B2B买家先看主图/详情再发询盘）
    vis = VISION.get(str(p['product_id']))
    v_b2b = vis.get('b2b') if vis else None
    v_sc = vis.get('vision_score') if vis else None
    v_adv = vis.get('advices') if vis else []
    # ① 主图质量（50%：主图是 B2B 转化第一关——是不是实物图、有没有卖点/认证）
    if v_b2b == '好': img_s, img_txt = 90, "主图B2B承接好(实物图+卖点+认证)"
    elif v_b2b == '中': img_s, img_txt = 65, "主图B2B承接中(建议补卖点/认证)"
    elif v_b2b == '差': img_s, img_txt = 35, "主图B2B承接差(占位图/无卖点，需重做)"
    else: img_s, img_txt = 50, "主图未做视觉诊断，按中值评估"
    # ② 详情页质量（30%：详情页决定询盘转化——规格/认证/定制/包装信息齐不齐）
    if has_detail and ctr >= 3: det_s, det_txt = 85, "详情页完整+CTR%.1f%%佐证" % ctr
    elif has_detail: det_s, det_txt = 65, "详情页存在，建议补规格/认证/OEM定制信息"
    else: det_s, det_txt = 30, "缺详情页=询盘必丢，先补详情"
    # ③ 数据佐证（20%：数据是验证，不是唯一依据——零数据按主图/详情评估，不否决）
    if inq >= 1: opp_s, opp_txt = 100, "询盘%d个=已获B端验证" % inq
    elif tm >= 1: opp_s, opp_txt = 85, "TM咨询%d次=有B端兴趣" % tm
    elif clk >= 4: opp_s, opp_txt = 70, "点击%d=主图有效但详情待转化" % clk
    elif clk >= 1: opp_s, opp_txt = 60, "有点击%d=需优化承接" % clk
    else: opp_s, opp_txt = 45, "暂无点击数据，按主图/详情页评估"
    # 综合（主图50% + 详情页30% + 数据20%）
    bs = max(0, min(100, round(img_s*0.50 + det_s*0.30 + opp_s*0.20)))
    if bs >= 70: bl = '好'
    elif bs >= 45: bl = '中'
    else: bl = '差'
    br = "%s｜%s｜%s" % (img_txt, det_txt, opp_txt)
    if v_sc is not None: br += "｜视觉%d分" % v_sc
    dims.append({"name":"B2B转化力","score":bs,"level":bl,"reason":br,"weight":25})
    # 5. 合规性
    if compliance_risk: cs, cl, cr = 20, '风险', "壮阳/减肥擦边品类，有处罚/下架风险"
    else: cs, cl, cr = 100, '好', "合规品类"
    dims.append({"name":"合规性","score":cs,"level":cl,"reason":cr,"weight":10})
    # 总分 = 维度加权（市场趋势20% + AI匹配25% + Listing完整20% + B2B转化25% + 合规10%）
    base = ms*0.20 + as_*0.25 + ls*0.20 + bs*0.25 + cs*0.10
    score = max(0, min(100, round(base)))
    if score >= 70: grade, gcls = 'A·优质', 'good'
    elif score >= 50: grade, gcls = 'B·待优化', 'warn'
    elif score >= 30: grade, gcls = 'C·问题', 'danger'
    else: grade, gcls = 'D·沉睡', 'muted'
    # ===== 好的点 / 不好的点（按维度）=====
    good = [d["name"]+d["level"]+": "+d["reason"] for d in dims if d["level"] in ('好',)]
    bad = [d["name"]+d["level"]+": "+d["reason"] for d in dims if d["level"] in ('差','风险')]
    # ===== 产品化建议（市场定位 + CTR分层诊断 + 品类打法）=====
    adv = CAT_ADVICE.get(cat, CAT_ADVICE['generic'])
    pb = CAT_PLAYBOOK.get(cat, CAT_PLAYBOOK['generic'])
    problems, actions = [], []
    # 合规最高优先：给『换赛道』而非『改词』
    if compliance_risk:
        problems.append("合规风险：%s" % ('壮阳擦边' if cat=='maca' else '减肥擦边'))
        actions.append("换赛道：" + pb['positioning'])
    # CTR 分层：判断病根在主图还是详情页
    if opp == 0 and clk >= 4:
        if ctr >= 3:
            problems.append("CTR %.1f%% 高但0商机=主图勾人、详情页没接住" % ctr)
            actions.append("详情页首屏放价格/MOQ/认证/OEM四要素")
        elif ctr < 1.5:
            problems.append("CTR %.1f%% 极低=首图/标题没勾住买家" % ctr)
            actions.append("先重做主图首图，再谈详情")
        else:
            problems.append("CTR %.1f%% 一般，主图+详情都需修" % ctr)
            actions.append("主图加卖点大字+详情加CTA")
    elif opp == 0 and imps == 0:
        problems.append("零曝光零点击=彻底沉睡")
        actions.append("补结构化属性+主图6张+视频，进AI搜索池")
    elif opp >= 1 and inq >= 1:
        actions.append("有主动询盘=B端强意向，30秒响应转报价")
    elif opp >= 1 and tm >= 1:
        actions.append("TM咨询跟进转报价，别让商机凉在接待")
    # 视觉诊断建议（主图承接，最多补 2 条）
    for a in v_adv[:2]:
        actions.append("主图·" + a)
    # 品类打法（市场导向的 2 条具体动作）
    actions.append(pb['moves'][0])
    if len(pb['moves']) > 1:
        actions.append(pb['moves'][1])
    # 转化链路闭环：曝光→点击→商机→成交 各环节
    funnel_steps = []
    if imps >= 1: funnel_steps.append({"step":"曝光","ok":True,"txt":"曝光 %d" % imps})
    else: funnel_steps.append({"step":"曝光","ok":False,"txt":"零曝光"})
    if clk >= 1: funnel_steps.append({"step":"点击","ok":True,"txt":"点击 %d" % clk})
    else: funnel_steps.append({"step":"点击","ok":False,"txt":"零点击（曝光→点击断裂）"})
    if opp >= 1: funnel_steps.append({"step":"商机","ok":True,"txt":"商机 %d（询盘%d+TM%d）" % (opp, inq, tm)})
    else: funnel_steps.append({"step":"商机","ok":False,"txt":"零商机（点击→商机断裂）"})
    # 识别画像：AI 会把它识别成什么
    recognized_as = " · ".join(ai_present) if ai_present else "信息不足，AI 难以归类"
    # 置信度（证据充分度：真实效果数据 + 视觉诊断 + 市场证据）
    _ev = 0
    if imps > 0 or clk > 0: _ev += 1
    if v_sc is not None: _ev += 1
    if EVIDENCE: _ev += 1
    confidence = ("高" if _ev >= 3 else "中" if _ev == 2 else "低" if _ev == 1 else "极低")
    # 评分与表现关系（4.3）：评分与实际效果是否背离
    if score >= 70 and opp == 0 and clk < 4:
        score_vs_perf = "评分高但实际商机=0、点击<4 → 潜力未释放，优先看承接/详情页，而非改Listing"
    elif score < 50 and opp > 0:
        score_vs_perf = "评分低但已有商机 %d → 有自然转化力，优先保转化链路，别盲目改" % opp
    elif score >= 70 and opp > 0:
        score_vs_perf = "评分高且已有商机 → 评分与表现一致，可加广告放大"
    else:
        score_vs_perf = "评分与实际表现基本一致"
    return {
        "product_id": p['product_id'], "title": (p['title'] or '')[:70],
        "prod_level": lvl, "cat_type": cat, "main_image": p['main_image'],
        "opp": opp, "inq": inq, "tm": tm, "clk": clk, "ctr": round(ctr, 2), "imps": imps, "adc": adc,
        "score": score, "grade": grade, "gcls": gcls, "confidence": confidence,
        "score_vs_perf": score_vs_perf,
        "dims": dims, "good": good, "bad": bad,
        "problems": problems, "actions": actions,
        "advice": adv,
         "funnel": funnel_steps, "recognized_as": recognized_as,
         "ai_present": ai_present, "ai_missing": ai_missing,
         "playbook": {"positioning": pb['positioning'], "moves": pb['moves'], "benchmark": pb['benchmark']},
         "market_evidence": ev,  # label/sources/social/amazon/verdict（多源市场证据）
         "zero_effect": (opp == 0 and clk == 0),  # 0商机且0点击 = 0效果
    }

scores = [judge_score(p) for p in rows]
scores.sort(key=lambda x: -x['score'])

# 竞品（真实，非擦边，带链接+点评）
BANNED_COMP = ["maca","penis","male","slimming","weight loss","enlargement","vitality","testosterone","sexual"]
def comp_banned(t): return any(b in (t or '').lower() for b in BANNED_COMP)
comp = [dict(r) for r in cur.execute("SELECT * FROM competitor_products ORDER BY sold DESC")]
# 我的产品图片 map（用于对标图）
my_img = {r['product_id']: r['main_image'] for r in cur.execute("SELECT product_id, main_image FROM products")}
comp_out = []
for x in comp:
    if comp_banned(x['title']): continue
    comp_out.append({
        "title": (x['title'] or '')[:80], "url": x['product_url'],
        "price": x['price_range'], "moq": x['moq'], "sold": x['sold'],
        "rank": x['rank'], "certs": x['certifications'],
        "good_point": x['observed_gap'], "match_our": x['match_our_product'],
        "match_reason": x['match_reason'],
        "img": my_img.get(x['match_our_product']) or '',
    })

# 0效果产品（0商机0点击，分"曝光浪费"和"彻底沉睡"两类）
zero_effect = [s for s in scores if s['zero_effect']]
zero_effect.sort(key=lambda x: -(x['imps'] or 0))
for s in zero_effect:
    if (s['imps'] or 0) >= 1:
        s['ze_type'] = '曝光浪费'
    else:
        s['ze_type'] = '彻底沉睡'

out = {"scores": scores, "competitors": comp_out, "zero_effect": zero_effect,
       "stat": {"total": len(scores), "A": sum(1 for s in scores if s['grade'].startswith('A')),
                "B": sum(1 for s in scores if s['grade'].startswith('B')),
                "C": sum(1 for s in scores if s['grade'].startswith('C')),
                "D": sum(1 for s in scores if s['grade'].startswith('D'))}}
with open('raw/v4_scores.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

print("评分完成: 共 %d 品 | A优质 %d | B待优化 %d | C问题 %d | D沉睡 %d | 0效果 %d" % (
    out['stat']['total'], out['stat']['A'], out['stat']['B'], out['stat']['C'], out['stat']['D'], len(zero_effect)))
print("\nTop5 优质品（含维度）:")
for s in scores[:5]:
    print("  [%d分 %s] %s" % (s['score'], s['grade'], s['title'][:40]))
    print("    好:", '; '.join(s['good']))
    print("    差:", '; '.join(s['bad']))

