"""ago_mcp.py — Stage B 数据获取辅助工具（仅用于本 Workspace 的 Stage B 初始化）。

调用 accio-mcp-cli 执行只读官方数据工具，保存 Raw Snapshot 并打印摘要。
不属于 alibaba-growth-os 可复用 Skill 包。

用法:
    python ago_mcp.py call <tool_name> <args_json_path> <raw_target_json_path>
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

MCP = "accio-mcp-cli"


def summarize(obj, depth: int = 2) -> str:
    """生成紧凑摘要，便于在对话中快速查看。"""
    if isinstance(obj, dict):
        parts = []
        for k, v in list(obj.items())[:24]:
            if isinstance(v, (dict, list)):
                parts.append(f"{k}:<{type(v).__name__} n={len(v)}>")
            else:
                s = str(v)
                parts.append(f"{k}={s[:60]}")
        return "{" + ", ".join(parts) + "}"
    if isinstance(obj, list):
        if not obj:
            return "[]"
        return f"[{len(obj)} items] first: " + summarize(obj[0], depth - 1)
    return str(obj)[:200]


def main() -> int:
    if len(sys.argv) != 5 or sys.argv[1] != "call":
        print(__doc__)
        return 2

    tool, args_path, raw_target = sys.argv[2], sys.argv[3], sys.argv[4]
    args_file = Path(args_path)
    cmd = [MCP, "call", tool]
    if args_file.exists() and args_file.stat().st_size > 0:
        cmd += ["--json-file", str(args_file)]

    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", shell=True, timeout=180)
    stdout = proc.stdout or ""
    # 清理 accio-mcp-cli 可能的非 JSON 包装
    try:
        payload = json.loads(stdout)
        summary = summarize(payload)
    except json.JSONDecodeError:
        payload = {"raw_stdout": stdout[:2000], "stderr": (proc.stderr or "")[:2000]}
        summary = f"[non-json] {payload['raw_stdout'][:300]}"

    out = Path(raw_target)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"=== {tool} -> {raw_target}")
    print(f"exit={proc.returncode} | {summary}")
    if proc.returncode != 0 and proc.stderr:
        print("stderr:", proc.stderr[:500])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
