# -*- coding: utf-8 -*-
"""V4: 完整解析星等级数据 → star_rating 表 + star_rating_parsed.json"""
import sqlite3, json, io, sys, glob
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
DB = 'database/alibaba_growth.db'

def load_json(path):
    with open(path, 'rb') as f: raw = f.read()
    if raw[:2] == b'\xff\xfe': return json.loads(raw.decode('utf-16'))
    if raw[:3] == b'\xef\xbb\xbf': return json.loads(raw.decode('utf-8-sig'))
    return json.loads(raw.decode('utf-8'))

_sr = sorted([f for f in glob.glob('raw/star_rating_*.json') if 'parsed' not in f])
d = load_json(_sr[-1] if _sr else 'raw/star_rating.json')
data = d.get('data') or {}
final = data.get('finalStar') or {}
tracks = data.get('trackList') or []

def val(v): return (v or {}).get('displayText') if isinstance(v, dict) else v

parsed = {
    "stat_date": data.get('statDate'),
    "level_star": final.get('pageLevelStar'),
    "display_star": final.get('displayLevelStar'),
    "predict_track_type": data.get('predictScoreHighestTrackType'),
    "star_rating_enabled": data.get('starRatingEnabled'),
    "tracks": [],
}
for t in tracks:
    alert = t.get('alert') or {}
    prog = t.get('progress') or {}
    inds = []
    for th in (t.get('thresholdList') or []):
        actions = [a.get('text') for a in (th.get('actionList') or []) if a.get('text')]
        inds.append({
            "title": th.get('title'), "completed": th.get('completed'),
            "current": val(th.get('currentValue')), "threshold": val(th.get('thresholdValue')),
            "relation": th.get('relation'), "actions": actions,
        })
    alert_inds = []
    for ai in (alert.get('indicatorList') or []):
        alert_inds.append({
            "name": ai.get('indicatorName'), "value": ai.get('value'),
            "score_delta": ai.get('scoreDelta'), "ability": ai.get('abilityName'),
        })
    # 能力项短板（含降星预警内容）
    abilities = []
    for ab in (t.get('abilityList') or []):
        ab_inds = []
        for ind in (ab.get('indicatorList') or []):
            ab_inds.append({
                "name": ind.get('indicatorName') or ind.get('tips') or ind.get('indicatorCode'),
                "code": ind.get('indicatorCode'),
                "downgrade_alert": ind.get('starDowngradeAlertContent'),
                "score_delta": ind.get('scoreDelta'),
                "value": ind.get('value'),
            })
        abilities.append({"ability_name": ab.get('abilityName') or ab.get('abilityCode'),
                          "indicators": ab_inds})
    parsed['tracks'].append({
        "track_name": t.get('trackName'), "track_type": t.get('trackType'),
        "star": t.get('star'), "score": t.get('score'),
        "score_highest": t.get('scoreHighestTrack'), "all_reached": t.get('thresholdAllReached'),
        "beat_rate": t.get('cateLv2BeatRate'),
        "progress": {"position": prog.get('currentPosition'), "text": prog.get('currentPositionText')},
        "alert": {"title": alert.get('title'), "down": alert.get('down'),
                  "description": alert.get('description'), "indicators": alert_inds},
        "indicators": inds, "abilities": abilities,
    })

# 写库
c = sqlite3.connect(DB)
cur = c.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS star_rating (
    stat_date TEXT PRIMARY KEY, level_star INTEGER, display_star INTEGER,
    predict_track_type TEXT, enabled INTEGER, raw_json TEXT, parsed_json TEXT)""")
cur.execute("INSERT OR REPLACE INTO star_rating VALUES (?,?,?,?,?,?,?)",
    (parsed['stat_date'], parsed['level_star'], parsed['display_star'],
     parsed['predict_track_type'], 1 if parsed['star_rating_enabled'] else 0,
     json.dumps(d, ensure_ascii=False), json.dumps(parsed, ensure_ascii=False)))
c.commit(); c.close()

with open('raw/star_rating_parsed.json', 'w', encoding='utf-8') as f:
    json.dump(parsed, f, ensure_ascii=False, indent=1)

print("本月星级:", parsed['level_star'], "星 | 赛道:", len(parsed['tracks']))
for t in parsed['tracks']:
    print("  [%s] %s | 综合分进度 %s | %s" % (t['track_name'], '★'*t['star'], t['progress']['position'], t['progress']['text']))
    print("    预测: %s (降星=%s)" % (t['alert']['title'], t['alert']['down']))
    for ai in t['alert']['indicators']:
        print("    短板: %s 值=%s 分数变化=%s" % (ai['name'], ai['value'], ai['score_delta']))
    for i in t['indicators']:
        print("    指标 %s %s | 当前%s vs 门槛%s" % ('✅' if i['completed'] else '❌', i['title'], i['current'], i['threshold']))
