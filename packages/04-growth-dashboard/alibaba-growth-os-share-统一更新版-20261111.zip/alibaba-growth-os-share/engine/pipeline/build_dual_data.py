# -*- coding: utf-8 -*-
"""生成双店加密数据文件：dashboard_data.js(YH) + dashboard_data_lifeworth.js(莱华仕)"""
import json, os, hashlib, base64
from Crypto.Cipher import AES

DST = 'dashboard'
PASSWORD = os.environ.get('GOS_DASHBOARD_PASSWORD', 'Lifeworth123456')
os.makedirs(DST, exist_ok=True)

def encrypt_json(path, global_name, out_name):
    data = json.load(open(path, encoding='utf-8'))
    raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    key = hashlib.sha256(PASSWORD.encode('utf-8')).digest()
    nonce = os.urandom(12)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ct, tag = cipher.encrypt_and_digest(raw)
    enc = base64.b64encode(nonce + ct + tag).decode('ascii')
    js = 'window.%s = ' % global_name + json.dumps(enc) + ';\n'
    out = os.path.join(DST, out_name)
    with open(out, 'w', encoding='utf-8') as f:
        f.write(js)
    print('生成 %s (%d bytes)' % (out, len(js.encode('utf-8'))))
    return out

encrypt_json('v4_data.json', 'V4_DATA_ENCRYPTED', 'dashboard_data.js')
encrypt_json('v4_data_old.json', 'V4_DATA_ENCRYPTED_LW', 'dashboard_data_lifeworth.js')
print('DONE')
