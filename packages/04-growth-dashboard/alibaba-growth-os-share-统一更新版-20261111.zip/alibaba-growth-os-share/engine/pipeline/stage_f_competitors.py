"""stage_f_competitors.py — Stage F 真实同行落库（BASELINE 快照）。

数据来源: PUBLIC_ALIBABA（公开产品详情页实抓）+ ALIBABA_OFFICIAL（官方热品榜 prodInfoList）。
首次快照标记 BASELINE，不做"本周新增"类声明。
"""
from __future__ import annotations

import json
import sqlite3
from datetime import date
from pathlib import Path

DB = Path(__file__).resolve().parent / "database" / "alibaba_growth.db"
ADVISORY = "2026-08-20"

STORES = [
    {
        "store_name": "Xi'an Qinkangda Health Industry Co., Ltd. (Synkonda)",
        "store_url": "https://synkonda.en.alibaba.com/",
        "main_category": "Health Care > Healthcare Supplements > Sports Nutrition / Collagen",
        "years_on_alibaba": 1, "rating": 4.7, "rating_count": 393,
        "response_time": "≤1h", "on_time_rate": "99.5%", "reorder_rate": "18%",
        "verified_by": "Intertek", "online_revenue": "US$150,000+", "year_founded": 2025,
        "floorspace": "1253m²", "main_markets": "North America, Western Europe, South Asia",
        "positioning": "Multispecialty Supplier, 敏捷供应链+原料溯源+成品检验; #1 热卖运动营养/胶原蛋白品",
        "source": "PUBLIC_ALIBABA(产品详情页公司卡)",
        "matched_products": ["1600472561736", "1601829634947"],
    },
    {
        "store_name": "Guangzhou Yuanzhi Biological Technology Co., Ltd. (YUANZHI)",
        "store_url": "https://gzyuanzhi.m.en.alibaba.com/",
        "main_category": "Health Care > Healthcare Supplements > Sports Nutrition",
        "years_on_alibaba": 8, "rating": 4.8, "rating_count": 646,
        "response_time": "≤2h", "on_time_rate": "≥100%", "reorder_rate": "18%",
        "verified_by": "PUBLIC_ALIBABA 店铺卡", "online_revenue": None, "year_founded": None,
        "floorspace": None, "main_markets": "US, UAE, Malaysia, UK",
        "positioning": "Custom Manufacturer (定制制造商); #3 热卖运动营养 Caffeine Gummies 5150 sold",
        "source": "PUBLIC_ALIBABA(产品详情页公司卡)",
        "matched_products": ["1601719605709"],
    },
    {
        "store_name": "Zhengzhou Yuhe Biotechnology Co., Ltd. (Yuhe Health)",
        "store_url": "https://yuhehealth.m.en.alibaba.com/",
        "main_category": "Health Care > Healthcare Supplements > Collagen",
        "years_on_alibaba": 2, "rating": 4.7, "rating_count": 74,
        "response_time": "≤2h", "on_time_rate": "≥99%", "reorder_rate": "10%",
        "verified_by": "PUBLIC_ALIBABA 店铺卡", "online_revenue": None, "year_founded": None,
        "floorspace": None, "main_markets": None,
        "positioning": "胶原蛋白专业供应商; #3 热卖胶原蛋白 9105 sold; 免费样品+MOQ 500+15天交期",
        "source": "PUBLIC_ALIBABA(产品详情页公司卡)",
        "matched_products": ["1601829634947"],
    },
    {
        "store_name": "Guangzhou Hemp Biotechnology Co., Ltd.",
        "store_url": "https://gzhemp.m.en.alibaba.com/",
        "main_category": "Health Care > Healthcare Supplements > Herbal",
        "years_on_alibaba": 4, "rating": 4.8, "rating_count": 461,
        "response_time": "≤2h", "on_time_rate": "≥98%", "reorder_rate": "16%",
        "verified_by": "PUBLIC_ALIBABA 店铺卡", "online_revenue": None, "year_founded": None,
        "floorspace": None, "main_markets": None,
        "positioning": "Custom Manufacturer; #1 最热卖草本补充剂工厂; Maca 150 胶囊全定制",
        "source": "PUBLIC_ALIBABA(产品详情页公司卡)",
        "matched_products": [],
    },
    {
        "store_name": "Henan Baihuikang Biotechnology Co., Ltd.",
        "store_url": "https://bhkcosmetic.en.alibaba.com/",
        "main_category": "Health Care > Healthcare Supplements > Collagen / Beauty",
        "years_on_alibaba": 6, "rating": 4.5, "rating_count": 160,
        "response_time": "≤3h", "on_time_rate": "97.4%", "reorder_rate": "18%",
        "verified_by": "SGS Group", "online_revenue": "US$580,000+", "year_founded": 2008,
        "floorspace": "9000m²", "main_markets": "Nigeria 81%, US 10%, HK, Venezuela, Mongolia",
        "positioning": "Custom Manufacturer; #5 领先保健食品制造商; 120 员工; #5 热卖胶原蛋白 2688 sold",
        "source": "PUBLIC_ALIBABA(产品详情页公司卡)",
        "matched_products": ["1601829634947"],
    },
]

PRODUCTS = [
    {"store": 1, "product_id": "1601735691241", "title": "Wholesale Creatine Supplement Creatine Monohydrate Powder OEM ODM Pre Workout Powder Bulk",
     "product_url": "https://www.alibaba.com/product-detail/Wholesale-Creatine-Supplement-Creatine-Monohydrate-Powder-OEM-ODM-Pre-Workout-Powder-Bulk-Pure-Creatine-Monohydrat-Poudre_1601735691241.html",
     "price_range": "€3.71-3.03", "moq": "1000 boxes", "sold": 1421, "rank": "#1 运动营养热卖",
     "certifications": "GMP", "oem_odm": True, "private_label": True, "lead_time": "1-200 箱 7 天",
     "customization": "logo/包装/口味/成分全定制", "match_our_product": "1600472561736",
     "match_reason": "同品类 Creatine Monohydrate Pre Workout Powder, 与本店爆品直接竞争", "relevance": 0.95,
     "observed_gap": "本店 MOQ 100 更友好/价格略低; 同行有 #1 热卖排名与 1421 销量背书"},
    {"store": 1, "product_id": "1601690123315", "title": "Collagen Supplement Types I II III V X Biotin Keratin Hyaluronic Acid 14-in-1 90 Capsules Bulk Custom",
     "product_url": "https://www.alibaba.com/product-detail/Collagen-Supplement-Types-I-II-III-V-X-Biotin-Keratin-Hyaluronic-Acid-14-in-1-Adult-Dietary-Supplement-90-Capsules-Bulk-Custom_1601690123315.html",
     "price_range": "$2.55-1.70", "moq": "100 pieces", "sold": 2112, "rank": "#1 胶原蛋白好评",
     "certifications": "GMP HACCP COA ISO + HALAL + Kosher", "oem_odm": True, "private_label": True,
     "lead_time": "1-500 件 10 天", "customization": "logo $0.15/pc MOQ100", "match_our_product": "1601829634947",
     "match_reason": "同胶原蛋白品类, 14-in-1 复合配方胶囊剂型", "relevance": 0.7,
     "observed_gap": "剂型不同(胶囊 vs 粉末); 同行多成分复合+MOQ100 试单友好"},
    {"store": 2, "product_id": "1601787481126", "title": "Caffeine Gummies 100mg Natural Energy GMP HACCP ISO HALAL Certified Private Label OEM",
     "product_url": "https://www.alibaba.com/product-detail/Caffeine-Gummies-100mg-Natural-Energy-GMP-HACCP-ISO-HALAL-Certified-Private-Label-OEM_1601787481126.html",
     "price_range": "$0.90-1.90", "moq": "500 pcs", "sold": 5150, "rank": "#3 运动营养热卖",
     "certifications": "HALAL + GMP/HACCP/ISO", "oem_odm": True, "private_label": True,
     "lead_time": "1-50000 件 30 天", "customization": "主成分/口味 MOQ500, Sample $50", "match_our_product": "1601719605709",
     "match_reason": "同咖啡因能量品类, 剂型 Gummies vs 本店 Pouch", "relevance": 0.85,
     "observed_gap": "同行剂型更主流(软糖)+MOQ500+样品$50; 本店 MOQ 2000 更高"},
    {"store": 3, "product_id": "1601690570987", "title": "OEM Free Samples Vegan Collagen Peptides Powder 150000mg Glutathione",
     "product_url": "https://www.alibaba.com/product-detail/OEM-Free-Samples-Slimming-Supplement-Vegan-Collagen-Peptides-Powder-150000-mg-Glutathione-Collagen-Powder-for-Skin-Whitening_1601690570987.html",
     "price_range": "≈$3.0-3.1/200g", "moq": "500 bags", "sold": 9105, "rank": "#3 胶原蛋白热卖",
     "certifications": "cGMP/HACCP/ISO22000/HALAL/ISO9001", "oem_odm": True, "private_label": True,
     "lead_time": "1-500 件 15 天", "customization": "免费样品; 3天设计定制; 200g/10×10g 可选", "match_our_product": "1601829634947",
     "match_reason": "同胶原蛋白粉品类, 与本店 Collagen Ashwagandha 直接竞争", "relevance": 0.9,
     "observed_gap": "同行 MOQ 500+免费样品+15天交期 vs 本店 MOQ 10000/670 且无免费样品信号 —— 试单门槛显著落后"},
    {"store": 4, "product_id": "1601435345934", "title": "Premium Shecome Maca Root Black 1900mg Male Vitality Capsules",
     "product_url": "https://www.alibaba.com/product-detail/Premium-Shecome-Maca-Root-Black-1900-mg-Male-Vitality-Support-Energy-for-Men-and-Women-Maca-Capsules-Penis-Enlargement-Pills_1601435345934.html",
     "price_range": "≈$3.2-3.7", "moq": "100 pcs", "sold": 28, "rank": "#4 草本热卖",
     "certifications": None, "oem_odm": True, "private_label": True,
     "lead_time": "1-200 件 35 天", "customization": "logo/成分/口味 MOQ200", "match_our_product": None,
     "match_reason": "同健康补充剂大类(草本), 非直接竞争, 行业形态参考", "relevance": 0.4,
     "observed_gap": None},
    {"store": 5, "product_id": "1601640180171", "title": "High Quality Skin Brightening Glutathione Collagen Glow Capsules",
     "product_url": "https://www.alibaba.com/product-detail/High-Quality-Skin-Brightening-Whitening-Glutathione-Collagen-Glow-Capsules_1601640180171.html",
     "price_range": "$2.58-2.14", "moq": "100 boxes", "sold": 2688, "rank": "#5 胶原蛋白热卖",
     "certifications": "CE + IMDG; SGS 验证工厂", "oem_odm": True, "private_label": True,
     "lead_time": "1-20 箱 7 天", "customization": "logo 免费 MOQ100", "match_our_product": "1601829634947",
     "match_reason": "同胶原蛋白品类(胶囊剂型), 美白方向", "relevance": 0.65,
     "observed_gap": "剂型不同; 同行主打美白功效胶囊, 7 天交期快"},
]


def main() -> int:
    conn = sqlite3.connect(str(DB))
    conn.row_factory = sqlite3.Row
    try:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS competitor_stores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            store_name TEXT NOT NULL UNIQUE, store_url TEXT, main_category TEXT,
            years_on_alibaba INTEGER, rating REAL, rating_count INTEGER,
            response_time TEXT, on_time_rate TEXT, reorder_rate TEXT,
            verified_by TEXT, online_revenue TEXT, year_founded INTEGER,
            floorspace TEXT, main_markets TEXT, positioning TEXT,
            source TEXT, snapshot_date TEXT, snapshot_type TEXT DEFAULT 'BASELINE'
        );
        CREATE TABLE IF NOT EXISTS competitor_products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            store_id INTEGER REFERENCES competitor_stores(id),
            product_id TEXT, title TEXT, product_url TEXT,
            price_range TEXT, moq TEXT, sold INTEGER, rank TEXT,
            certifications TEXT, oem_odm INTEGER, private_label INTEGER,
            lead_time TEXT, customization TEXT,
            match_our_product TEXT, match_reason TEXT, relevance REAL, observed_gap TEXT,
            source TEXT, snapshot_date TEXT, snapshot_type TEXT DEFAULT 'BASELINE'
        );
        CREATE TABLE IF NOT EXISTS competitor_snapshot (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            snapshot_date TEXT, snapshot_type TEXT,
            store_count INTEGER, product_count INTEGER,
            notes TEXT
        );
        """)
        n_stores = 0
        for s in STORES:
            cur = conn.execute(
                """INSERT INTO competitor_stores
                   (store_name, store_url, main_category, years_on_alibaba, rating, rating_count,
                    response_time, on_time_rate, reorder_rate, verified_by, online_revenue,
                    year_founded, floorspace, main_markets, positioning, source, snapshot_date, snapshot_type)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(store_name) DO UPDATE SET store_url=excluded.store_url""",
                (s["store_name"], s["store_url"], s["main_category"], s["years_on_alibaba"],
                 s["rating"], s["rating_count"], s["response_time"], s["on_time_rate"],
                 s["reorder_rate"], s["verified_by"], s["online_revenue"], s["year_founded"],
                 s["floorspace"], s["main_markets"], s["positioning"], s["source"],
                 ADVISORY, "BASELINE"))
            n_stores += 1
        store_ids = {r["store_name"]: r["id"] for r in conn.execute("SELECT id, store_name FROM competitor_stores")}
        for p in PRODUCTS:
            conn.execute(
                """INSERT INTO competitor_products
                   (store_id, product_id, title, product_url, price_range, moq, sold, rank,
                    certifications, oem_odm, private_label, lead_time, customization,
                    match_our_product, match_reason, relevance, observed_gap, source, snapshot_date, snapshot_type)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (store_ids[STORES[p["store"] - 1]["store_name"]], p["product_id"], p["title"],
                 p["product_url"], p["price_range"], p["moq"], p["sold"], p["rank"],
                 p["certifications"], 1 if p.get("oem_odm") else 0, 1 if p.get("private_label") else 0,
                 p["lead_time"], p["customization"], p["match_our_product"], p["match_reason"],
                 p["relevance"], p["observed_gap"], "PUBLIC_ALIBABA", ADVISORY, "BASELINE"))
        conn.execute(
            """INSERT INTO competitor_snapshot (snapshot_date, snapshot_type, store_count, product_count, notes)
               VALUES (?, 'BASELINE', ?, ?, '首次快照: 仅 BASELINE, 不做本周新增声明')""",
            (ADVISORY, n_stores, len(PRODUCTS)))
        conn.commit()
        print(json.dumps({
            "stores": n_stores,
            "products": len(PRODUCTS),
            "snapshot": "BASELINE (" + ADVISORY + ")",
            "matched_our_products": sorted({p["match_our_product"] for p in PRODUCTS if p["match_our_product"]}),
            "sources": ["PUBLIC_ALIBABA(产品详情页实抓)", "ALIBABA_OFFICIAL(官方热品榜)"],
        }, ensure_ascii=False, indent=1))
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
