# -*- coding: utf-8 -*-
"""拉取「最新完整自然月」的产品效果全量分页 → raw/shop_product_m1_p*.json

为什么需要它：`product_weekly_stats` 只覆盖最新一周，导致「重点关注」等产品榜单
切到「月」时没有数据可切。数据参谋的商品效果接口其实支持 month 口径
（statDate 传当月 1 号，且必须在近 90 天内），本脚本就是用它把月度产品数据补上，
供 init_store.py 回填 product_monthly_stats 表。

用法: python v6_fetch_products_monthly.py [--statDate YYYY-MM-01] [--pages N]
"""
import subprocess, json, io, sys, os, argparse
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import _gos_ctx

RAW = _gos_ctx.RAW
os.makedirs(RAW, exist_ok=True)


def default_statdate():
    months=_gos_ctx.window().get('months') or []
    if not months: raise ValueError('缺少完整自然月窗口')
    latest=max(months,key=lambda p:p['month_start'])
    return latest['month_start'],latest['month_end']


def mcp_call(tool, payload_obj, timeout=180):
    pfile = os.path.join(RAW, '_tmp_pm_args.json')
    with open(pfile, 'w', encoding='utf-8') as f:
        json.dump(payload_obj, f, ensure_ascii=False)
    r = subprocess.run(['accio-mcp-cli', 'call', tool, '--json-file', pfile],
                       capture_output=True, text=True, encoding='utf-8', errors='replace',
                       timeout=timeout, shell=True)
    out = r.stdout or ''
    i = out.find('{')
    if i >= 0:
        try:
            return json.loads(out[i:])
        except Exception:
            pass
    return {"_raw": out[:400], "_stderr": (r.stderr or '')[:400]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--statDate', default=None, help='统计月 1 号 YYYY-MM-01（默认取最新完整月）')
    ap.add_argument('--pages', type=int, default=60, help='最大页数（每页 20）')
    args = ap.parse_args()

    if args.statDate:
        stat_date = args.statDate
        month_end = ''
    else:
        stat_date, month_end = default_statdate()
    print("月度产品窗口: statDate=%s%s" % (stat_date, (' ~ ' + month_end) if month_end else ''))

    all_rows, total = {}, 0
    _last_first_id = None
    for page in range(1, args.pages + 1):
        payload = {"shopProductQueryParam": {
            "statisticsType": "month", "statDate": stat_date,
            "orderBy": "inquiries", "order": "desc",
            "pageNo": page, "pageSize": 20, "terminalType": "TOTAL"}}
        resp = mcp_call('data_advisor_shop_product', payload)
        d = (resp.get('data') or {}) if isinstance(resp, dict) else {}
        rows = d.get('data') or []
        cnt = d.get('recordCount') or 0
        total = cnt or total
        p = os.path.join(RAW, 'shop_product_m1_p%02d.json' % page)
        with open(p, 'w', encoding='utf-8') as f:
            json.dump(resp, f, ensure_ascii=False)
        for r in rows:
            all_rows[str(r.get('id'))] = r
        print("  page %02d: %d 行（累计 %d / 总 %s）" % (page, len(rows), len(all_rows), total or '?'))
        # 月口径下接口每页实际只回 ~10 条（即便请求 20），所以不能按 <20 判断结束，
        # 以「总量到达」或「返回空」为终止条件，并用首页 id 防重复死循环
        first_id = str(rows[0].get('id')) if rows else None
        if not rows or first_id == _last_first_id:
            break
        _last_first_id = first_id
        if total and len(all_rows) >= total:
            break
    print("月度产品: total=%s fetched=%d" % (total, len(all_rows)))
    with open(os.path.join(RAW, '_month_product_window.json'), 'w', encoding='utf-8') as f:
        json.dump({"statDate": stat_date, "month_end": month_end}, f, ensure_ascii=False)
    print("DONE")


if __name__ == '__main__':
    main()
