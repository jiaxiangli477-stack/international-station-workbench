# -*- coding: utf-8 -*-
"""V6: 主图视觉诊断（基于视觉模型识别结果，12 个重点品）"""
import json, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 每个产品：主图类型/背景/卖点文字/认证/合规风险/视觉点评
VISION = {
    "62583845037": {"type":"实物图","bg":"白底+海滩场景","text":"ELECTROLYTE DRINK / +MAGNESIUM / +POTASSIUM","cert":"无","risk":"无",
        "score":90,"note":"产品实物+卖点大字+使用场景俱全，是标准的优秀主图"},
    "1600573690891": {"type":"占位图","bg":"黑底+健身场景","text":"WHEY PROTEIN POWDER / 40 SERVING","cert":"无","risk":"无",
        "score":50,"note":"桶身印「YOUR LOGO」=白牌 OEM 模板图，不是成品图，买家看到没信任感，应换真实品牌成品图"},
    "1600713698833": {"type":"实物图","bg":"白底+咖啡豆","text":"HIGH PROTEIN COFFEE / 2 ESPRESSO SHOTS / 20G WHEY","cert":"无","risk":"无",
        "score":88,"note":"卖点数据化(2shot/20g)+咖啡豆氛围，勾食欲又点明卖点"},
    "60237696766": {"type":"实物图","bg":"白底","text":"Freeze-dried Coffee / Medium Roast / 100% arabica","cert":"无","risk":"无",
        "score":85,"note":"玻璃罐透出冻干颗粒+金盖质感，Medium Roast/100% arabica 点明品质"},
    "60794753347": {"type":"实物图","bg":"白底+木槿花场景","text":"HIBISCUS / SABDARIFFA TEA / Caffeine-Free","cert":"无","risk":"无",
        "score":88,"note":"鲜花场景+Caffeine-Free 卖点清晰，茶品类标准打法"},
    "1600663590617": {"type":"实物图","bg":"白底+冰咖啡倒流","text":"Espresso Coffee","cert":"无","risk":"无",
        "score":80,"note":"咖啡倒流动态场景抓眼球，但卖点文字偏少，可加咖啡因含量"},
    "1600545801881": {"type":"实物图","bg":"白底","text":"MCT OIL / MENTAL ENERGY / STAMINA+FOCUS","cert":"无","risk":"无",
        "score":88,"note":"功能卖点(MENTAL ENERGY/STAMINA/FOCUS)排布清晰，瓶身专业"},
    "60737127822": {"type":"实物图","bg":"白底","text":"SLIM BLEND / PROMOTES HEALTHY DIGESTION","cert":"无","risk":"减肥",
        "score":55,"note":"「SLIM/瘦身」表述属减肥擦边，有下架风险；主图本身专业但需改文案"},
    "1600215059599": {"type":"实物图","bg":"白底+跑步者场景","text":"Energy Drink / 0 SUGAR / 0 CALORIES / 6 electrolytes","cert":"vegan/non-gmo/gluten-free","risk":"无",
        "score":92,"note":"0糖0卡+6电解质+跑步场景+认证标签齐全，能量饮料品类标杆图"},
    "1600462251785": {"type":"实物图","bg":"白底","text":"FAT BURNERS / BOOST METABOLISM / APPETITE SUPPRESSANT","cert":"无","risk":"减肥",
        "score":40,"note":"「FAT BURNERS/抑制食欲」是典型减肥擦边词，合规风险最高，应改「metabolism support」"},
    "60374879042": {"type":"渲染图","bg":"白底","text":"Arabica Freeze-dried / Instant Coffee","cert":"无","risk":"无",
        "score":62,"note":"数字渲染图非实拍，质感弱于实拍图，卖点文字清晰但缺真实产品感"},
    "1600512105898": {"type":"渲染图","bg":"白底+咖啡飞溅","text":"(仅数字1/无卖点文字)","cert":"无","risk":"无",
        "score":55,"note":"3D渲染+咖啡飞溅有视觉冲击，但几乎无产品信息文字，AI难以识别具体卖点"},
}

with open('raw/vision_result.json', 'w', encoding='utf-8') as f:
    json.dump(VISION, f, ensure_ascii=False, indent=1)

print("视觉诊断 %d 个产品" % len(VISION))
for pid, v in VISION.items():
    print("  [%s] %s | %s | %s | %d分" % (pid, v['type'], v['text'][:30], ('⚠'+v['risk']) if v['risk']!='无' else '合规', v['score']))
