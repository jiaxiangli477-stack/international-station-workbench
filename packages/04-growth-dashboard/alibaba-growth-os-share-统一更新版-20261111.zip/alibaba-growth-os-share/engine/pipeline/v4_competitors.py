# -*- coding: utf-8 -*-
"""V6: 提取 5 家供应商 Top20 竞品（过滤擦边+原料+去重+点评），输出 competitor_full.json"""
import json, io, sys, os, glob, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 目标品类白名单（只保留「成品」保健品类，剔除原料/添加剂类目）
KEEP_CATS = {"运动营养补给", "维生素", "草本补充剂", "胶原蛋白", "矿物质", "氨基酸",
             "膳食纤维", "抗氧化保健食品", "滋补营养品", "其它保健食品", "益生菌"}
# 原料/添加剂/非目标类目黑名单（成品店不卖原料粉）
RAW_CATS = {"植物提取物", "其他食品添加剂", "甜味剂", "日用化学品", "植物提取物原料"}

# 标题级原料检测：CAS 号 / 等级（食品/化妆品/医药/工业/饲料级）/ 原料词 / 提取物纯度
RAW_RE = re.compile(r'\b\d{2,7}-\d{2}-\d\b')
RAW_TITLE = [
    "food grade", "cosmetic grade", "pharma grade", "pharmaceutical grade",
    "industrial grade", "feed grade", "technical grade", "usp grade", "bp grade",
    "raw material", "raw materials", "raw ingredient", "原料", "化工", "化工品",
    "食品级", "化妆品级", "医药级", "工业级", "饲料级",
    "stearic acid", "decyl glucoside", "ambroxane", "mixed tocopherol",
    "tocopherol oil", "vitamin e oil",
]
PURITY_RE = re.compile(r'(9[5-9]|100)\s*%\s*(extract|powder|oil|acid|liquid|granule)', re.I)

def is_raw_title(t):
    tl = (t or '').lower()
    if RAW_RE.search(tl):
        return True
    if any(k in tl for k in RAW_TITLE):
        return True
    if PURITY_RE.search(tl):
        return True
    # Bulk 散装 + 克重（如 Bulk Creatina HCL Monohydrate 500g 1000g）→ 原料散粉
    if 'bulk' in tl and re.search(r'\b\d{3,4}\s*g\b', tl):
        return True
    return False

# 不合规/擦边/非目标 claim 黑名单（助孕/关节/骨骼/心脏/脑/眼睛/睡眠/前列腺/血糖/鱼油等）
BANNED = ["maca","penis","male","slimming","weight loss","enlargement","vitality","testosterone","sexual","erectile","detox","fat burn","skinny","lose weight","whitening capsule","skin brightening capsule","breast","boobs","butt","vaginal",
    # 助孕/生育
    "fertility","fertile","conceive","conception","pregnancy","prenatal","postnatal","ovulation","助孕","备孕","受孕",
    # 关节/骨骼
    "joint","arthritis","glucosamine","chondroitin","bone","cartilage","关节","骨骼",
    # 心脏/血压/胆固醇
    "heart","cholesterol","blood pressure","cardiovascular","心脏","血压",
    # 脑/认知
    "brain","memory","cognitive","citicoline","nootropic","脑","记忆","认知",
    # 眼睛/视力
    "eye","vision","lutein","eyesight","macular","视力","眼睛",
    # 睡眠
    "sleep","melatonin","insomnia","睡眠","褪黑素",
    # 前列腺/生发
    "prostate","saw palmetto","前列腺","生发","防脱","hair growth",
    # 血糖/代谢
    "blood sugar","diabetes","glucose","berberine","血糖","降糖",
    # 鱼油（非目标品类）
    "fish oil","omega-3","omega 3",
]
def banned(t):
    tl = (t or '').lower()
    # 硬性违规词：即使标题含 collagen 也要拦（生发/前列腺/助孕/脑/心脏/眼睛/睡眠/血糖/鱼油）
    HARD = ["hair growth","saw palmetto","prostate","生发","防脱","前列腺",
            "fertility","fertile","conceive","conception","pregnancy","prenatal","postnatal","ovulation","助孕","备孕","受孕",
            "brain","memory","cognitive","citicoline","nootropic","cognition","脑","记忆","认知",
            "heart","cholesterol","blood pressure","cardiovascular","心脏","血压",
            "eye","vision","lutein","eyesight","macular","视力","眼睛",
            "sleep","melatonin","insomnia","睡眠","褪黑素",
            "blood sugar","diabetes","glucose","berberine","血糖","降糖",
            "fish oil","omega-3","omega 3"]
    if any(b in tl for b in HARD): return True
    if 'collagen' in tl:   # 胶原蛋白是目标品类，豁免 joint/bone/hair/skin 等温和词
        return False
    return any(b in tl for b in BANNED)
def keep_cat(c):
    c = c or ''
    if c in RAW_CATS: return False          # 原料/添加剂直接排除
    return c in KEEP_CATS

def big_img(u):
    if not u: return ''
    return u.replace('_100x100.jpg', '_300x300.jpg').replace('_100x100.JPG', '_300x300.jpg')

files = glob.glob('competitor_data/shop-product-*.json')
products = {}
for fp in files:
    d = json.load(open(fp, encoding='utf-8'))
    data = (d.get('data') or {}).get('data') or []
    src = os.path.basename(fp).replace('shop-product-', '').replace('-ranked20.json', '').replace('.json', '')
    for p in data:
        t = p.get('subject') or p.get('prodName') or ''
        cat = p.get('cateName') or ''
        if banned(t): continue
        if is_raw_title(t): continue          # 原料竞品（CAS号/等级/化工/提取物纯度）直接剔除
        if cat and not keep_cat(cat): continue   # 只保留目标品类
        pid = p.get('id')
        if not pid or pid in products: continue
        products[pid] = {
            "title": t[:90],
            "img": big_img(p.get('prodImage') or ''),
            "url": p.get('detailUrl') or '',
            "price": p.get('priceRange') or p.get('price') or '—',
            "moq": p.get('minOrderQuantity') or '—',
            "category": p.get('cateName') or '',
            "orders": p.get('crtOrd') or 0,       # 月订单
            "inquiry": p.get('sumProdFbNum') or 0, # 月询盘
            "visitor": p.get('sumProdVisitorCnt') or 0,
            "clicks": p.get('totalClkCnt') or 0,
            "rts_amt": p.get('rtsOnlineAmt') or 0,
            "modified": p.get('gmtModified') or '',
            "source": src,
        }

# 生成"好在哪"点评
def good_point(p):
    pts = []
    if (p['orders'] or 0) >= 20: pts.append("月订单 %d 单，销量背书强" % p['orders'])
    elif (p['orders'] or 0) >= 5: pts.append("月订单 %d 单，稳定出单" % p['orders'])
    if (p['inquiry'] or 0) >= 10: pts.append("月询盘 %d 个，转化好" % p['inquiry'])
    elif (p['inquiry'] or 0) >= 3: pts.append("月询盘 %d 个" % p['inquiry'])
    moq = p['moq']
    try:
        if float(moq) <= 100: pts.append("MOQ %s 试单友好" % moq)
    except: pass
    if (p['clicks'] or 0) >= 100: pts.append("月点击 %d 有流量" % p['clicks'])
    if not pts: pts.append("该品有 listing 展示，可点跳转看主图/详情打法")
    return "；".join(pts)

out = []
for pid, p in products.items():
    p['good_point'] = good_point(p)
    out.append(p)

out.sort(key=lambda x: -(x['orders'] or 0) or -(x['inquiry'] or 0))

# 统计供应商数（按来源文件）
doms = {p.get('source') for p in out if p.get('source')}
print("竞品提取完成：去重后 %d 个（过滤擦边后），来自 %d 家供应商" % (len(out), len(doms)))

with open('raw/competitor_full.json', 'w', encoding='utf-8') as f:
    json.dump({"total": len(out), "supplier_count": len(doms), "competitors": out,
               "filter_note": "已剔除原料竞品（CAS号/食品级/Bulk/提取物纯度/化工品）"},
              f, ensure_ascii=False, indent=1)
print("\nTop10 竞品：")
for p in out[:10]:
    print("  [订单%d/询盘%d] %s | %s | MOQ %s" % (p['orders'], p['inquiry'], p['title'][:36], p['category'], p['moq']))
