# -*- coding: utf-8 -*-
"""把 dashboard/ 推送到 GitHub → Vercel 自动重新部署。

用法：python deploy.py
（每周二跑完 weekly_update.py 后执行一次即可）
"""
import subprocess, sys, os
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
DST = os.path.join(HERE, 'dashboard')


def run(args, cwd=DST):
    return subprocess.run(args, cwd=cwd, capture_output=True, text=True)


def main():
    if not os.path.isdir(os.path.join(DST, '.git')):
        print('[deploy] dashboard/ 尚未初始化 git 仓库。')
        print('        请先按 README-deploy.md 的「一次性初始化」做一遍。')
        sys.exit(1)

    tag = date.today().isoformat()
    run(['git', 'add', '-A'])
    run(['git', 'commit', '-m', 'weekly update %s' % tag, '--allow-empty'])

    r = run(['git', 'push'])
    if r.returncode == 0:
        print('[deploy] 推送成功，Vercel 将自动重新部署。')
        return

    # 可能还没配置 upstream，尝试首次推送
    r2 = run(['git', 'push', '-u', 'origin', 'HEAD'])
    if r2.returncode == 0:
        print('[deploy] 推送成功（已设置 upstream），Vercel 将自动重新部署。')
        return

    print('[deploy] 推送失败，请检查 GitHub 登录与远程仓库配置。')
    print((r2.stderr or r2.stdout or r.stderr or '')[:2000])
    sys.exit(1)


if __name__ == '__main__':
    main()
