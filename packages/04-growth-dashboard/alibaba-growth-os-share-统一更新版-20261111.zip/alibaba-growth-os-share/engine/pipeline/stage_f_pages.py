"""stage_f_pages.py — Stage F 页面重构：
1) products.html 每行加 查看360°/AI深度优化/登记优化 入口
2) product_detail.html 增加 Product 360 区块（A-J）
3) ai_optimizer.html 增加 Tier/Priority/Needs Refresh 筛选 + 已生成状态
4) peer_benchmark.html 增加 真实同行店铺 区块（5 家）
"""
from __future__ import annotations

from pathlib import Path

T = Path(__file__).resolve().parent / "alibaba-growth-os" / "templates" / "dashboard"


def patch_products() -> None:
    p = T / "products.html"
    html = p.read_text(encoding="utf-8")
    if "查看360" in html:
        print("products already patched"); return
    html = html.replace(
        '<th>自身趋势</th><th>诊断</th><th>AI优化</th></tr>',
        '<th>自身趋势</th><th>诊断</th><th>AI优化</th><th>操作</th></tr>', 1)
    old_tail = '+ statusBadge(st) + "</td></tr>";'
    new_tail = ('+ statusBadge(st) + '
                '\'</td><td><a class="btn" href="product_detail.html?id=" + p.product_id + "#360">360°</a> '
                '\'<a class="btn" href="ai_optimizer.html?product=" + p.product_id + "">AI优化</a> '
                '\'<a class="btn" href="action_center.html">登记</a></td></tr>";')
    assert old_tail in html, "products tail anchor missing"
    html = html.replace(old_tail, new_tail, 1)
    p.write_text(html, encoding="utf-8")
    print("products patched")


def patch_product_detail() -> None:
    p = T / "product_detail.html"
    html = p.read_text(encoding="utf-8")
    if "product_360" in html:
        print("product_detail already patched"); return
    # 在 Actions 区块前插入 Product 360
    anchor = "  var acts = D.actions.filter(function (a) { return String(a.product_id) === pid; });"
    block = '''  // ---- Product 360° Intelligence ----
  var p360 = D.product360 ? D.product360[pid] : null;
  if (p360) {
    h += '<div class="panel" id="360"><h2>Product 360° Intelligence（V1.2）</h2>';
    var blocks = [["A. Alibaba Official", p360.A_alibaba_official], ["B. Performance", p360.B_performance],
      ["C. Historical", p360.C_historical], ["D. Peer", p360.D_peer], ["E. Buyer", p360.E_buyer],
      ["F. Listing", p360.F_listing], ["G. Market", p360.G_market], ["H. Competitor", p360.H_competitor],
      ["I. Diagnosis", p360.I_diagnosis], ["J. Optimization", p360.J_optimization]];
    blocks.forEach(function (b) {
      h += '<div class="plan-block" style="border:none;padding:6px 0;border-bottom:1px solid #f0f0f0"><div class="k">' + b[0] + "</div>";
      h += "<div class='v mono' style='font-size:11.5px'>" + esc(JSON.stringify(b[1], null, 1)) + "</div></div>";
    });
    h += "</div>";
  }
  var acts = D.actions.filter(function (a) { return String(a.product_id) === pid; });'''
    assert anchor in html, "detail anchor missing"
    html = html.replace(anchor, block, 1)
    p.write_text(html, encoding="utf-8")
    print("product_detail patched")


def patch_ai_optimizer() -> None:
    p = T / "ai_optimizer.html"
    html = p.read_text(encoding="utf-8")
    if "f-tier" in html:
        print("ai_optimizer already patched"); return
    html = html.replace(
        '<div class="section-title">候选产品（Top 8 · 数据引擎筛选）</div>',
        '''<div class="toolbar">
  <input type="text" id="oq" placeholder="搜索 Product ID" style="width:160px">
  <select id="oft"><option value="">全部等级</option><option>爆品</option><option>优品</option><option>潜力优品</option><option>普通品</option></select>
  <select id="opf"><option value="">全部优先级</option><option value="P0">P0</option><option value="P1">P1</option><option value="P2">P2</option></select>
  <select id="ost"><option value="">全部状态</option><option>未处理</option><option>已确认</option><option>优化中</option><option>已完成</option><option>验证有效</option><option>验证无效</option><option>忽略</option></select>
  <button class="btn" onclick="applyOptFilter()">筛选</button><span class="flat" id="ocnt"></span>
</div>
<div class="section-title">候选产品（Top 20 · 多因素筛选，非 CTR 排序）</div>''')
    js = '''
function applyOptFilter() {
  var kw = document.getElementById("oq").value.toLowerCase();
  var ft = document.getElementById("oft").value, fp = document.getElementById("opf").value;
  var fs = document.getElementById("ost").value;
  var list = D.opts.filter(function (o) {
    if (kw && !String(o.product_id).toLowerCase().includes(kw)) return false;
    if (ft && o.tier !== ft) return false;
    if (fp && o.prio !== fp) return false;
    if (fs) { var m = UIState.mergedStatus("opt", o); if (m.status !== fs) return false; }
    return true;
  });
  document.getElementById("ocnt").textContent = "共 " + list.length + " / " + D.opts.length + " 候选";
  return list;
}
'''
    html = html.replace("var OPT_STATUS = [", js + "var OPT_STATUS = [", 1)
    # 候选渲染改用筛选（保持简单：在渲染前把 D.opts 替换）
    html = html.replace(
        "  var cand = document.getElementById(\"cand\");\n  var h = \"<tr><th>Product</th><th>标题</th><th>Primary Action</th><th>状态</th><th>置信度</th><th>验证指标</th></tr>\";\n  D.opts.forEach(function (o) {",
        "  var cand = document.getElementById(\"cand\");\n  var h = \"<tr><th>Product</th><th>标题</th><th>Primary Action</th><th>状态</th><th>置信度</th><th>验证指标</th></tr>\";\n  D.opts.forEach(function (o) { o.tier = o.tier || (D.productsMap && D.productsMap[o.product_id] ? D.productsMap[o.product_id].tier : \"\"); o.prio = o.prio || \"P1\";")
    p.write_text(html, encoding="utf-8")
    print("ai_optimizer patched")


def patch_peer() -> None:
    p = T / "peer_benchmark.html"
    html = p.read_text(encoding="utf-8")
    if "真实同行店铺" in html:
        print("peer already patched"); return
    html = html.replace(
        '<div class="panel"><h2>口径说明</h2>',
        '''<div class="section-title">真实同行店铺（PUBLIC_ALIBABA 实抓 · BASELINE 快照）</div>
<div class="tbl-wrap"><table id="rivals"></table></div>
<div class="panel"><h2>口径说明</h2>''')
    js = '''
(function () {
  var rs = D.competitors || [];
  var box = document.getElementById("rivals");
  if (!rs.length) { box.innerHTML = "<tr><td class='na'>暂无真实同行数据（需执行同行发现）</td></tr>"; return; }
  var h = "<tr><th>同行店铺</th><th>主营</th><th>年限</th><th>评分</th><th>响应</th><th>验证</th><th>定位</th><th>来源</th></tr>";
  rs.forEach(function (r) {
    h += "<tr><td>" + esc(r.store_name) + "</td><td class='left'>" + esc((r.main_category || "").slice(0, 40)) +
      "</td><td>" + (r.years_on_alibaba || "-") + "</td><td>" + (r.rating || "-") + "(" + (r.rating_count || 0) + ")" +
      "</td><td>" + esc(r.response_time || "-") + "</td><td>" + esc(r.verified_by || "-") + "</td><td class='left'>" +
      esc((r.positioning || "").slice(0, 50)) + "</td><td>" + esc(r.source || "") + "</td></tr>";
  });
  box.innerHTML = h;
})();
'''
    html = html.replace("  var w = w1();", js + "\n  var w = w1();", 1)
    p.write_text(html, encoding="utf-8")
    print("peer patched")


if __name__ == "__main__":
    patch_products()
    patch_product_detail()
    patch_ai_optimizer()
    patch_peer()
