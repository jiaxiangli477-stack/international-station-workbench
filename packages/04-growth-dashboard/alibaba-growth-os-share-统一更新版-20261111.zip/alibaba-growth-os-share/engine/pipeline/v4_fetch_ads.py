# -*- coding: utf-8 -*-
"""V4: 拉取国际站广告计划层数据（直通车 + 全站推计划列表 + 账户/计划周报告）"""
import subprocess, json, io, sys, os
from datetime import date, timedelta
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 最新完整自然周（动态计算）
_t = date.today(); _dow = (_t.weekday() + 1) % 7
_sun = _t - timedelta(days=_dow)
if _sun >= _t: _sun -= timedelta(days=7)
_wb = _sun - timedelta(days=6)
WEEK_BEGIN = _wb.isoformat() + " 00:00:00"
WEEK_END = _sun.isoformat() + " 23:59:59"
WEEK_TAG = _wb.isoformat().replace('-', '')

def workctl(params_obj):
    """写参数文件 → workctl icbu ads list → 解析 JSON-RPC envelope → structuredContent"""
    pfile = os.path.join(os.getcwd(), 'ads_tmp_params.json')
    with open(pfile, 'w', encoding='utf-8') as f:
        json.dump(params_obj, f, ensure_ascii=False)
    r = subprocess.run(['workctl', 'icbu', 'ads', 'list', '--params-file', pfile, '--format', 'json'],
                       capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120, shell=True)
    out = r.stdout or ''
    try:
        env = json.loads(out)
        return env.get('result', {}).get('structuredContent') or {}
    except Exception as e:
        print("  PARSE ERR:", e, out[:300])
        return {}

def q(entityType, filters=None, include='data', page=None):
    p = {"entityType": entityType, "include": include}
    if filters: p["filters"] = filters
    if page: p["page"] = page
    return workctl(p)

# 1. 计划列表
print("== 拉取计划列表 ==")
search = q("campaign", {"summaryTypes":"search","productLineId":"110101"}, "all", {"index":1,"size":50})
whole = q("campaign", {"summaryTypes":"wholeSite","productLineId":"110106"}, "all", {"index":1,"size":50})
search_data = (search.get('data') or {}).get('data') or []
whole_data = (whole.get('data') or {}).get('data') or []
print("  直通车计划 %d 个, 全站推计划 %d 个" % (len(search_data), len(whole_data)))

campaigns = []
for c in search_data + whole_data:
    campaigns.append({
        "campaign_id": c.get('campaignId'), "name": c.get('campaignName'),
        "type": c.get('campaignType'), "type_desc": c.get('campaignTypeDesc'),
        "budget": c.get('budget'), "bid_type": c.get('bidType'),
        "status": c.get('onlineStatus'), "product_count": c.get('onlineProductCount'),
        "match_type": c.get('matchType'), "gmt_create": c.get('gmtCreate'),
        "line": "search" if c in search_data else "wholeSite",
    })

# 2. 账户报告（周）
print("== 拉取账户周报告 ==")
acc_report = {}
for ds in ['company_search', 'company_whole_site']:
    r = q("report", {"datasource": ds, "beginDateTime": WEEK_BEGIN, "endDateTime": WEEK_END})
    rows = (r.get('data') or {}).get('data') or []
    acc_report[ds] = rows
    print("  %s -> %d 行" % (ds, len(rows)))

# 3. 计划报告（周）
print("== 拉取计划周报告 ==")
for c in campaigns:
    cid = c['campaign_id']
    ds = 'campaign_search' if c['line'] == 'search' else 'campaign_whole_site'
    r = q("report", {"datasource": ds, "campaignId": cid, "beginDateTime": WEEK_BEGIN, "endDateTime": WEEK_END})
    rows = (r.get('data') or {}).get('data') or []
    c['report'] = rows
    print("  %s (%s) -> %d 行" % (cid, c['name'][:20], len(rows)))

# 保存
out = {"week_begin": WEEK_BEGIN, "week_end": WEEK_END,
       "campaigns": campaigns, "account_report": acc_report}
with open('raw/ads_plan_%s.json' % WEEK_TAG, 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("saved raw/ads_plan_%s.json" % WEEK_TAG)

# 打印摘要
print("\n== 计划摘要 ==")
for c in campaigns:
    print("  [%s] %s | %s | 预算%s | 品%s | 状态%s" % (c['campaign_id'], c['name'][:28], c['type_desc'], c['budget'], c['product_count'], c['status']))
