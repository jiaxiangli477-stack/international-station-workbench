"""stage_b_candidates.py — STEP 17 候选筛选：从库中识别 Top 优化候选并输出清单。"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent / "database" / "alibaba_growth.db"

# 官方诊断推荐（store_diagnose_brief 真实返回）
OFFICIAL_RECOMMENDED = {
    "1601427218194": {"reason": "官方定价优化清单#1", "action": "price_optimize"},
    "1601427109870": {"reason": "官方定价优化清单#2", "action": "price_optimize"},
    "1601719480278": {"reason": "官方定价优化清单(三周前)", "action": "price_optimize"},
    "1601829634947": {"reason": "官方定价优化清单(三周前)", "action": "price_optimize"},
    "1601635924283": {"reason": "官方品证绑定推荐", "action": "cert_bind"},
}


def main() -> None:
    conn = sqlite3.connect(str(DB))
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        """
        SELECT p.product_id, p.title, p.prod_level, p.price_range, p.moq, p.detail_url,
               w.impressions, w.clicks, w.ctr, w.inquiries, w.orders, w.gmv,
               e.total_imps, e.total_clk, e.ad_imps, e.ad_clk, e.atm_fb_uv, e.mc_fb_uv,
               e.fav, e.cmp, e.sum_show_coc, e.sum_click_coc, e.sum_visitor_coc
        FROM products p
        JOIN product_weekly_stats w ON p.product_id = w.product_id AND w.week_start='2026-08-10'
        LEFT JOIN product_weekly_stats_ext e ON p.product_id = e.product_id AND e.week_start='2026-08-10'
        WHERE e.total_imps > 0
        ORDER BY e.total_imps DESC
        """
    ).fetchall()
    conn.close()

    cands: dict[str, dict] = {}

    def add(r, stage, reason, prio):
        pid = r["product_id"]
        if pid in cands:
            cands[pid]["reasons"].append(reason)
            if stage not in cands[pid]["stage"]:
                cands[pid]["stage"].append(stage)
            cands[pid]["prio"] = min(cands[pid]["prio"], prio)
        else:
            cands[pid] = {
                "product_id": pid, "title": r["title"], "tier": r["prod_level"],
                "price_range": r["price_range"], "moq": r["moq"], "detail_url": r["detail_url"],
                "imps": r["impressions"], "clicks": r["clicks"], "ctr": r["ctr"],
                "inquiries": r["inquiries"], "orders": r["orders"], "gmv": r["gmv"],
                "total_imps": r["total_imps"], "total_clk": r["total_clk"],
                "ad_imps": r["ad_imps"], "ad_clk": r["ad_clk"],
                "atm_fb_uv": r["atm_fb_uv"], "mc_fb_uv": r["mc_fb_uv"],
                "fav": r["fav"], "cmp": r["cmp"],
                "coc_show": r["sum_show_coc"], "coc_click": r["sum_click_coc"],
                "stage": list({stage}), "reasons": [reason], "prio": prio,
            }

    for r in rows:
        imps, clk, ctr, inq = r["impressions"] or 0, r["clicks"] or 0, r["ctr"] or 0, r["inquiries"] or 0
        coc_show = r["sum_show_coc"]
        # P1: 爆品（官方分层）
        if r["prod_level"] == "爆品":
            add(r, "P1_STAR", "官方爆品", 1)
        # P2 高流量低转化: 曝光高 + 有点击但无询盘
        if imps >= 3000 and clk >= 20 and inq == 0:
            add(r, "OPTIMIZE_CONVERSION", "高流量零询盘（曝光≥3000,点击≥20,询盘=0）", 1)
        # 转化好但流量受限
        if inq >= 2 and imps < 3000:
            add(r, "TRAFFIC_LIMITED", "转化好但搜索流量低（询盘≥2,曝光<3000）", 2)
        # 下滑风险: 曝光同比下滑 >20%
        if coc_show is not None and coc_show < 0.8 and imps >= 1000:
            add(r, "DECLINING_RISK", f"搜索曝光环比下滑 {int((1-coc_show)*100)}%", 2)
        # 官方推荐
        if r["product_id"] in OFFICIAL_RECOMMENDED:
            info = OFFICIAL_RECOMMENDED[r["product_id"]]
            add(r, "OFFICIAL", info["reason"], 1)

    ranked = sorted(cands.values(), key=lambda c: (c["prio"], -(c["imps"] or 0)))
    print(json.dumps({
        "candidate_count": len(ranked),
        "candidates": ranked[:12],
    }, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
