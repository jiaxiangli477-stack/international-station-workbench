# -*- coding: utf-8 -*-
"""
Alibaba Growth OS V6 — 一键周更主脚本
运行整条数据管线：拉图 → 竞品 → 评分 → 板块 → 合并 → 建看板
用法：python weekly_update.py [--skip-images] [--deploy]
  --skip-images  跳过图片拉取（图已缓存时）
  --deploy       完成后自动推送到 GitHub → Vercel 自动部署
"""
import subprocess, sys, io, os, argparse
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

STEPS = [
    ("拉取全量月度数据(含同行对标)", "v6_fetch_monthly.py", False),
    ("拉取产品主图URL", "v6_fetch_imgs.py", False),
    ("广告效果报告(花费/CPC/商机成本)", "v4_fetch_ads_report.py", False),
    ("竞品全量提取", "v4_competitors.py", False),
    ("拉取买家画像(身份/国家 × 全部/L1+)", "v7_fetch_buyer.py", False),
    ("数据预处理(国家/渠道/买家/关键词/热销)", "v4_prep_sections.py", False),
    ("市场趋势证据(报告/社媒/亚马逊)", "v6_market_evidence.py", False),
    ("AI产品评分(含市场趋势分)", "v4_score.py", False),
    ("合并数据", "v4_judge.py", False),
    ("重建看板", "v4_build.py", False),
]

def run(name, script):
    print("=== %s: %s ===" % (name, script))
    # 用当前解释器而不是裸 'python'：同事机器上 python 常在 PATH 里不可见
    r = subprocess.run([sys.executable, script], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=900)
    if r.stdout:
        print(r.stdout[-800:])
    if r.returncode != 0:
        print("!! 失败: %s\n%s" % (name, (r.stderr or '')[-500:]))
        return False
    return True

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--skip-images', action='store_true')
    ap.add_argument('--deploy', action='store_true', help='完成后自动推送到 GitHub → Vercel 部署')
    args = ap.parse_args()
    print("Alibaba Growth OS V6 一键周更开始")
    ok = True
    for name, script, is_img in STEPS:
        if is_img and args.skip_images:
            print("跳过: %s" % name); continue
        if not run(name, script):
            ok = False
            break
    if ok:
        print("\n全部完成 -> 双击 dashboard/index.html 查看")
        if args.deploy:
            print("\n推送部署中...")
            r = subprocess.run([sys.executable, 'deploy.py'], capture_output=True, text=True, encoding='utf-8', errors='replace')
            print((r.stdout or '').strip())
            if r.returncode != 0:
                print((r.stderr or '部署失败').strip())
    else:
        print("\n流程中断，请检查上面的错误")

if __name__ == '__main__':
    main()
