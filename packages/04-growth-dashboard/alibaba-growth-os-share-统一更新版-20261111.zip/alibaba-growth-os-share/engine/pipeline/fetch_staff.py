# -*- coding: utf-8 -*-
"""拉取 4 周子账号经营效果 → raw/cs_w1..w4.json（供 v4_ingest_staff.py 入库）

窗口取 raw/_window.json（与大盘/产品同一窗口），不再写死日期。
"""
import subprocess, json, io, sys, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import _gos_ctx

RAW = _gos_ctx.RAW
os.makedirs(RAW, exist_ok=True)

W = _gos_ctx.window()
WEEKS = [(x['week_start'], x['week_end'], 'w%d' % x['idx']) for x in W['weeks'][:4]]


def call(start, end):
    pfile = os.path.join(RAW, '_tmp_staff.json')
    with open(pfile, 'w', encoding='utf-8') as f:
        json.dump({"accountQueryParam": {"statisticsType": "week", "startDate": start, "endDate": end}}, f)
    r = subprocess.run(['accio-mcp-cli', 'call', 'data_advisor_account_summary', '--json-file', pfile],
                       capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120, shell=True)
    out = r.stdout or ''
    i = out.find('{')
    if i >= 0:
        try:
            return json.loads(out[i:])
        except Exception:
            pass
    return None


print("窗口: %s" % ", ".join('%s~%s' % (s, e) for s, e, _ in WEEKS))
for start, end, tag in WEEKS:
    resp = call(start, end)
    if resp:
        p = os.path.join(RAW, f'cs_{tag}.json')
        with open(p, 'w', encoding='utf-8') as f:
            json.dump(resp, f, ensure_ascii=False)
        d0 = (resp.get('data') or [{}])
        d0 = d0[0] if isinstance(d0, list) and d0 else d0
        n = sum(len(v) for v in d0.values()) if isinstance(d0, dict) else 0
        print(f"cs_{tag} ({start}~{end}): saved, staff entries={n}")
    else:
        print(f"cs_{tag} ({start}~{end}): EMPTY")

print("DONE")
