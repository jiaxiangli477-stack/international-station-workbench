"""stage_e_fix_db.py — Stage E AI 质量修复：
1) 双变量拆分（1601427218194: PRIMARY=MAIN_IMAGE, FUTURE=TITLE_SIMPLIFICATION）
2) MOQ 越权修复（1601492686064: REVIEW MOQ LADDER + NEEDS_HUMAN_CONFIRMATION=true）
3) 标题合规（1600472561736 方案A 的 Sugar Free → 标注需确认，改用真实属性 Low-Carb）
4) 新增 4 个深度方案（TITLE/IMAGE/DETAIL/MOQ-REVIEW）→ 8 候选全覆盖（PART 8 ≥7）
5) product_optimizations 补 priority_reason/impact/actionability
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent / "database" / "alibaba_growth.db"


def main() -> int:
    conn = sqlite3.connect(str(DB))
    conn.row_factory = sqlite3.Row
    try:
        # ---- 1. 双变量拆分 ----
        conn.execute(
            """UPDATE product_optimizations
               SET primary_action='MAIN_IMAGE (PRIMARY)',
                   secondary_actions=json_array(?, ?),
                   updated_at=datetime('now')
               WHERE product_id='1601427218194'""",
            ("TITLE_SIMPLIFICATION (FUTURE, 下一轮)", "PRICE_OPTIMIZE (官方任务, 独立执行)"),
        )
        conn.execute(
            """UPDATE diagnosis_actions
               SET primary_variable='MAIN_IMAGE（PRIMARY）—— TITLE_SIMPLIFICATION 拆分为 Future Action',
                   notes=COALESCE(notes,'') || ' [E2修复: 双变量拆分, PRIMARY=MAIN_IMAGE, FUTURE=TITLE_SIMPLIFICATION]'
               WHERE product_id='1601427218194'""")

        # ---- 2. MOQ 越权修复 ----
        conn.execute(
            """UPDATE diagnosis_actions
               SET recommended_change='REVIEW MOQ LADDER（NEEDS_HUMAN_CONFIRMATION=true）: 评估 1000pcs 试单档可行性，'
                                     ||'须工厂确认产能/成本后方可实施；AI 不得自行决定 MOQ 调整。',
                   notes=COALESCE(notes,'') || ' [E2修复: MOQ 越权→REVIEW MOQ LADDER, 需人工确认]'
               WHERE product_id='1601492686064'""")
        conn.execute(
            """UPDATE product_optimizations
               SET primary_action='REVIEW_MOQ_LADDER（NEEDS_HUMAN_CONFIRMATION=true）',
                   do_not_do=COALESCE(do_not_do,'') || '；AI 不自行决定 MOQ 数值，须工厂确认后实施',
                   notes=COALESCE(notes,'') || ' [E2修复: MOQ 越权→REVIEW MOQ LADDER]',
                   updated_at=datetime('now')
               WHERE product_id='1601492686064'""")

        # ---- 3. 标题合规（Sugar Free → 需确认）----
        conn.execute(
            """UPDATE product_optimizations
               SET candidate_titles=?, updated_at=datetime('now')
               WHERE product_id='1600472561736'""",
            (json.dumps([
                {"code": "A",
                 "title": "LIFEWORTH Creatine Monohydrate Pre Workout Powder 300g - Low Carb Energy Drink Mix Bulk OEM Private Label",
                 "note": "Sugar Free 改为 Listing 真实属性 Low-Carb（E2 合规修复）"},
                {"code": "B",
                 "title": "Creatine Monohydrate Pre-Workout 300g Can - Explosive Energy Endurance Powder Bulk OEM ODM Private Label GMP Factory",
                 "note": "GMP/ODM/Private Label 均为 Listing 真实能力"},
                {"code": "C",
                 "title": "Pre Workout Creatine Monohydrate Powder Bulk 300g - Caffeine Energy Drink Mix Low Carb, OEM Private Label Manufacturer",
                 "note": "Low Carb 真实属性，Manufacturer 收尾"}
            ], ensure_ascii=False),),
        )

        # ---- 4. 新增 4 个深度方案 ----
        plans = [
            {
                "product_id": "1600546912886",
                "primary_action": "TITLE_REWRITE",
                "plan": {
                    "1_why_selected": "官方爆品但点击同比 -81.8%（W1 仅 13 点击）；与同店 1600472561736 同配方不同价位（$4.00-4.60 vs $2.80-3.40）形成内部竞争，流量被分流",
                    "2_current_problem": "点击暴跌 82%、CTR 1.52% 低于店均 1.69%；询盘 0",
                    "3_data_evidence": "W1: 搜索曝光 857(coc -11.2%) | 点击 13(coc -81.8%) | CTR 1.52% | 询盘 0 | 订单 1；价格 $4.00-4.60, MOQ 100 bottles; 认证 HALAL MSDS FSSC HACCP",
                    "4_self_history": "曝光/点击双降，点击降幅远超曝光 → 首屏点击力衰减",
                    "5_peer_gap": "CTR 1.52% < 店均 1.69% < 同行平均 1.82%（W1 口径）",
                    "6_buyer_intent": "Private Label 品牌商意图（标题已含 Private Label）；买家身份: 零售商 71%+批发 21%",
                    "7_listing_diagnosis": "与 1600472561736 同质（creatine pre-workout），标题无差异化定位；'Private Label' 仅在句首品牌位",
                    "8_competitor_gap": "UNAVAILABLE（无竞品明细）",
                    "9_root_cause": "同质产品内部竞争 + 定位模糊（无明确 Private Label/OEM 差异化卖点）",
                    "10_primary_action": "TITLE_REWRITE（PRIMARY）",
                    "11_concrete_plan": {
                        "type": "TITLE_REWRITE",
                        "current_title": "LIFEWORTH Private Label Pre Workout Creatine Monohydrate Powder Muscle Building Energy Supplement Helps Support Explosive Energy",
                        "analysis": {
                            "定位": "与同店 300g 罐装品重合；无规格/定制差异化",
                            "核心词位置": "'Private Label' 在品牌位后，Creatine Monohydrate 中段",
                            "b2b_intent": "OEM/Custom Formula 缺失；'Helps Support Explosive Energy' 冗余功效句占用字符",
                            "剂型规格": "500g 大包装未在标题体现",
                            "buyer_query_match": "对 'private label pre workout bulk' 覆盖中；对 'custom formula pre workout' 覆盖弱"
                        },
                        "title_options": [
                            {"code": "A", "title": "LIFEWORTH Private Label Creatine Pre Workout Powder 500g - Custom Formula Bulk OEM Manufacturer HALAL Certified",
                             "target_intent": "Private Label 品牌商", "why": "500g 规格差异化 + Custom Formula 定制信号 + HALAL 真实认证", "solves": "与 300g 品切割规格定位"},
                            {"code": "B", "title": "Private Label Pre Workout Creatine Monohydrate 500g - Custom Branding OEM ODM Bulk Factory Direct GMP Certified",
                             "target_intent": "OEM/ODM 工厂直采", "why": "去品牌前缀占位 + 500g + Factory Direct 直采信号", "solves": "OEM 买家搜索匹配"},
                            {"code": "C", "title": "Creatine Pre Workout Private Label OEM - Custom Flavor & Packaging, 500g Bulk, HALAL & HACCP Certified",
                             "target_intent": "定制+认证双诉求买家", "why": "Custom Flavor & Packaging 具体定制项 + 双认证真实背书", "solves": "高定制诉求买家转化"}
                        ]
                    },
                    "12_do_not_change": "不与 1600472561736 竞价降 $2.8（自伤利润）；保留 Private Label 定位",
                    "13_future_actions": ["价格带差异化: 明确 500g 大包装定位", "详情页补 Private Label 定制流程 3 步"],
                    "14_validation_metric": "CTR / 点击 / 询盘（标题更换后完整自然周）",
                    "15_validation_period": "1 个完整自然周",
                    "16_confidence": "medium",
                    "17_evidence_source": "data_advisor_shop_product W1 + 公开 Listing 实读（认证清单）"
                }
            },
            {
                "product_id": "1601720577533",
                "primary_action": "MAIN_IMAGE",
                "plan": {
                    "1_why_selected": "官方爆品；询盘 3+TM 3 需求真实，但点击同比 -30.8%、CTR 1.72% 走低 → 创新剂型（口腔膜）缺乏视觉传达",
                    "2_current_problem": "Oral Film 剂型认知度低，首屏未直观展示膜片形态与速溶效果",
                    "3_data_evidence": "W1: 搜索曝光 523(coc -1.1%) | 点击 9(coc -30.8%) | CTR 1.72% | 询盘 3 | TM 3 | 订单 1；价格 $2.60-2.90, MOQ 3000 boxes",
                    "4_self_history": "4 周内点击持续下滑",
                    "5_peer_gap": "CTR 1.72% vs 店均 1.69%（持平）→ 点击下滑更多是关键词/排名衰减而非主图力弱",
                    "6_buyer_intent": "口腔膜为差异化创新剂型，买家需看到使用形态（图片/视频演示）",
                    "7_listing_diagnosis": "主图未展示膜片单片形态与速溶效果；无演示视频（Listing 实读）",
                    "8_competitor_gap": "UNAVAILABLE",
                    "9_root_cause": "创新剂型缺乏视觉传达 → 点击率走低 → 排名衰减循环",
                    "10_primary_action": "MAIN_IMAGE（PRIMARY）",
                    "11_concrete_plan": {
                        "type": "MAIN_IMAGE",
                        "current_image_problem": "未直观展示口腔膜形态与速溶效果（实读判断）",
                        "creative_brief": {
                            "subject": "口腔膜单片特写（指尖夹持）+ 3 口味条装",
                            "product_ratio": "膜片占 45-55%，条装占 25%",
                            "background": "浅色纯净背景（白/浅蓝渐变）",
                            "packaging_display": "单片膜 + 条装并置，展示便携性",
                            "b2b_signals": "是 — 左下角 'Fast Dissolving Oral Film' + 'ODM' 徽章",
                            "text_allowed": "'Fast Dissolving Oral Film'、'ODM'、'3 Flavors'",
                            "do_not_include": "不放大段成分表；不放胶囊/粉末形态（误导剂型）",
                            "mobile_thumbnail": "膜片轮廓在 80x80 下可辨",
                            "ab_test": "A: 速溶瞬间示意 vs B: 简洁产品摆拍，1 周对比 CTR"
                        }
                    },
                    "12_do_not_change": "不动 MOQ 3000（剂型产线经济性）",
                    "13_future_actions": ["15-30s 速溶演示视频", "关键词补 'energy strips'/'oral dissolving strips'"],
                    "14_validation_metric": "CTR / 点击 / 询盘",
                    "15_validation_period": "1 个完整自然周",
                    "16_confidence": "medium",
                    "17_evidence_source": "data_advisor_shop_product W1 + 公开 Listing 实读"
                }
            },
            {
                "product_id": "1601476000834",
                "primary_action": "DETAIL_CONVERSION",
                "plan": {
                    "1_why_selected": "官方爆品；CTR 3.72% 为全场最高（点击力强）、EU&UK 人气 #7、累计售出 1130，但 W1 零询盘零订单 + TM 6 → 详情转化链路断裂",
                    "2_current_problem": "高 CTR 未转化为询盘（0）；曝光同比 -22.7% 下滑",
                    "3_data_evidence": "W1: 搜索曝光 242(coc -22.7%) | 点击 9 | CTR 3.72% | 询盘 0 | 订单 0 | TM 6；价格 €2.42-2.77, MOQ 500 boxes; 认证 ISO22000/HACCP/GMP/HALAL/MSDS/COA",
                    "4_self_history": "曝光/点击 4 周下行，TM 咨询 6 次未沉淀询盘",
                    "5_peer_gap": "点击力（CTR 3.72%）远超店均，询盘 0 说明卡在详情转化层",
                    "6_buyer_intent": "EU/UK 市场对合规/认证敏感（ISO22000/HACCP/GMP 已持有但未在详情突出）",
                    "7_listing_diagnosis": "详情页未突出欧盟合规与 OEM 案例；TM 咨询未引导转询盘（详情实读）",
                    "8_competitor_gap": "UNAVAILABLE",
                    "9_root_cause": "详情页转化要素缺失 + TM 咨询未承接（客服响应慢放大）",
                    "10_primary_action": "DETAIL_CONVERSION（PRIMARY）",
                    "11_concrete_plan": {
                        "type": "DETAIL_B2B_SECTION",
                        "detail_modules": [
                            {"module": "模块1 产品核心价值", "content": "高浓度电解质恢复粉：维生素 C/B1/B3/B5/B12 复配（真实配方）"},
                            {"module": "模块2 规格/配方", "content": "Sachet 条装 + 口味矩阵 + 冲泡方法"},
                            {"module": "模块3 OEM/ODM", "content": "Private Label 定制流程（品牌商诉求）"},
                            {"module": "模块4 包装定制", "content": "条装/盒装选项与 logo 工艺"},
                            {"module": "模块5 认证", "content": "ISO22000 / HACCP / GMP / HALAL / MSDS / COA 图标行（真实持有）"},
                            {"module": "模块6 工厂能力", "content": "工贸一体、出口 12 年（店铺档案真实信息）"},
                            {"module": "模块7 MOQ/Sample", "content": "MOQ 500 boxes；样品政策需确认后填写"},
                            {"module": "模块8 交期", "content": "以工厂实际为准（需确认）"},
                            {"module": "模块9 询价 CTA", "content": "'Get EU Market Quote' CTA + TM 转询盘引导话术"}
                        ]
                    },
                    "12_do_not_change": "不动价格 €2.42-2.77（EU 市场竞争力）",
                    "13_future_actions": ["客服话术: TM 咨询 24h 内引导转询盘", "欧盟合规资料补充"],
                    "14_validation_metric": "询盘数 / TM→询盘转化 / 曝光环比",
                    "15_validation_period": "1 个完整自然周",
                    "16_confidence": "medium",
                    "17_evidence_source": "data_advisor_shop_product W1 + 公开 Listing 实读（认证清单）+ 店铺档案"
                }
            },
            {
                "product_id": "1601492686064",
                "primary_action": "REVIEW_MOQ_LADDER",
                "plan": {
                    "1_why_selected": "官方爆品；W1 搜索曝光同比 +194% 流量暴涨但询盘仅 1 → 高流量低转化的典型，MOQ 10000 pcs 为店最高档之一",
                    "2_current_problem": "曝光 3 倍增长未转化为询盘；MOQ 10000 门槛高，试单买家流失",
                    "3_data_evidence": "W1: 搜索曝光 784(coc +194%) | 点击 20 | CTR 2.55% | 询盘 1 | TM 4 | 订单 1；MOQ 10000 pcs；价格 $0.19-0.25",
                    "4_self_history": "曝光爆发期（+194%），转化未跟上",
                    "5_peer_gap": "UV→订单率 0.28% vs 平均 0.35%/优秀 0.42%（W1 店级）；询盘层转化弱",
                    "6_buyer_intent": "能量胶买家以跑团/经销渠道为主，习惯小批量试单（500-2000）验证口味",
                    "7_listing_diagnosis": "MOQ 10000 pcs 无试单档；未提供小批量 SKU/选项（Listing 实读）",
                    "8_competitor_gap": "UNAVAILABLE",
                    "9_root_cause": "MOQ 阶梯设计压制试单转化；流量暴涨窗口未被询盘承接",
                    "10_primary_action": "REVIEW_MOQ_LADDER（PRIMARY, NEEDS_HUMAN_CONFIRMATION=true）",
                    "11_concrete_plan": {
                        "type": "DETAIL_B2B_SECTION",
                        "moq_ladder": {
                            "current": {"moq": "10000 pcs", "price": "$0.19-0.25", "source": "Listing 实读"},
                            "problem": "无试单档与样品信息",
                            "buyer_risk": "品牌商需先验证口味再批量下单；10000 pcs 直接起步风险高",
                            "suggested_structure": [
                                {"tier": "Sample", "suggest": "样品政策需与工厂确认（Listing 未展示）", "status": "需人工确认"},
                                {"tier": "Trial Order", "suggest": "评估 1000-2000 pcs 试单档可行性（价格上浮覆盖成本）", "status": "需人工确认"},
                                {"tier": "Standard MOQ", "suggest": "10000 pcs（现状）", "status": "现状"},
                                {"tier": "Bulk Order", "suggest": "50000+ 阶梯价（需与工厂确认）", "status": "需人工确认"}
                            ],
                            "ai_note": "AI 不自行决定 MOQ 数值；所有试单档须工厂确认产能/成本后实施（NEEDS_HUMAN_CONFIRMATION=true）"
                        },
                        "detail_modules": [
                            {"module": "模块7 MOQ/Sample 说明", "content": "现有 MOQ 10000 与样品路径说明（确认后填写）"}
                        ]
                    },
                    "12_do_not_change": "不全面降价（$0.19-0.25 批发带已具竞争力）；不自行调整 MOQ",
                    "13_future_actions": ["详情页补应用场景（跑步/骑行）与口味矩阵", "评估广告承接新增流量"],
                    "14_validation_metric": "询盘数 / TM 数（MOQ 阶梯确认并实施后完整自然周）",
                    "15_validation_period": "1 个完整自然周（实施后）",
                    "16_confidence": "medium（MOQ 档位需人工确认）",
                    "17_evidence_source": "data_advisor_shop_product W1 + 公开 Listing 实读（MOQ/价格）"
                }
            },
            {
                "product_id": "1601829634947",
                "primary_action": "PRICE_OPTIMIZE_REVIEW",
                "plan": {
                    "1_why_selected": "官方诊断定价优化清单指定；优品但 W1 询盘 0/订单 0/流量低",
                    "2_current_problem": "流量与点击双低（曝光 189/点击 3）；官方判定定价待优化",
                    "3_data_evidence": "W1: 搜索曝光 189(coc +27.7%) | 点击 3 | CTR 1.59% | 询盘 0 | 订单 0；价格 €3.29-3.63, MOQ 10000 sachets/670 bags; 属性: 毛发生长/睡眠/免疫; 累计售出 308",
                    "4_self_history": "曝光小幅回升但点击未跟上",
                    "5_peer_gap": "低流量低转化尾部优品（店级询盘转化正常，本品偏离）",
                    "6_buyer_intent": "胶原蛋白+Ashwagandha 复合粉品牌商关注配方差异化与 MOQ 灵活性",
                    "7_listing_diagnosis": "MOQ 670 bags 偏高；'Form: Powder Capsule Gummies Liquid' 属性表述含混（Listing 实读）",
                    "8_competitor_gap": "UNAVAILABLE",
                    "9_root_cause": "官方定价判定 + MOQ 与属性表述削弱试单意愿",
                    "10_primary_action": "PRICE_OPTIMIZE_REVIEW（PRIMARY, 官方任务, NEEDS_HUMAN_CONFIRMATION=true）",
                    "11_concrete_plan": {
                        "type": "DETAIL_B2B_SECTION",
                        "moq_ladder": {
                            "current": {"moq": "10000 sachets / 670 bags", "price": "€3.29-3.63", "source": "Listing 实读"},
                            "problem": "MOQ 双档表述含混；无试单说明",
                            "buyer_risk": "小品牌商试单成本高",
                            "suggested_structure": [
                                {"tier": "Sample", "suggest": "样品政策需确认", "status": "需人工确认"},
                                {"tier": "Trial", "suggest": "评估 2000 sachets 试单档", "status": "需人工确认"},
                                {"tier": "Standard", "suggest": "10000 sachets / 670 bags（现状）", "status": "现状"},
                                {"tier": "Bulk", "suggest": "50000+ 阶梯（需确认）", "status": "需人工确认"}
                            ],
                            "ai_note": "定价调整按官方自动定价工具建议档位执行（NEEDS_HUMAN_CONFIRMATION=true）"
                        },
                        "detail_modules": [
                            {"module": "属性修正", "content": "Form 属性改为 'Powder'（修正含混表述）"}
                        ]
                    },
                    "12_do_not_change": "不虚构临床功效文案（仅用官方属性词）",
                    "13_future_actions": ["补 'Sleep Aid'/'Collagen Ashwagandha' 关键词", "详情页突出睡眠/毛发双功效成分表"],
                    "14_validation_metric": "询盘 / 订单 / CVR（定价调整后完整自然周）",
                    "15_validation_period": "1 个完整自然周",
                    "16_confidence": "high（官方任务背书）",
                    "17_evidence_source": "官方诊断任务清单 + data_advisor_shop_product W1 + Listing 实读"
                }
            },
        ]
        for p in plans:
            conn.execute(
                """UPDATE product_optimizations
                   SET deep_plan_json=?, plan_version='v1.1.1',
                       primary_action=?, updated_at=datetime('now')
                   WHERE product_id=?""",
                (json.dumps(p["plan"], ensure_ascii=False), p["primary_action"], p["product_id"]),
            )

        # ---- 5. 优先级字段 ----
        cols = {r[1] for r in conn.execute("PRAGMA table_info(product_optimizations)").fetchall()}
        for name, ddl in [("priority_reason", "TEXT"), ("impact", "TEXT"), ("actionability", "TEXT")]:
            if name not in cols:
                conn.execute(f"ALTER TABLE product_optimizations ADD COLUMN {name} {ddl}")
        prio = {
            "1600472561736": ("爆品+店最高询盘（5）→ 标题放大自然流量杠杆", "搜索曝光提升 30-80%（对标主词排名）", "高: 标题可直接修改"),
            "1601492686064": ("曝光 +194% 暴涨但询盘 1 → 流量窗口未被承接", "询盘转化恢复至店均水平", "中: 需工厂确认 MOQ 阶梯"),
            "1601720577533": ("点击 -31% 下滑 + 创新剂型视觉缺失", "CTR/点击止跌回升", "高: 主图可由设计直接执行"),
            "1600546912886": ("点击 -82% 暴跌 + 同店内部竞争", "流量分流修复, 点击恢复", "高: 标题可直接修改"),
            "1601719605709": ("GMV 最高（$158）但询盘 0 → 商机链路断裂", "询盘从 0 起步, 商机增长", "高: 详情模块可执行"),
            "1601476000834": ("CTR 3.72% 最高但询盘 0/订单 0", "询盘转化 0→正", "高: 详情模块可执行"),
            "1601829634947": ("官方定价优化任务 + 低流量低转化", "CVR 提升", "中: 官方工具联动"),
            "1601427218194": ("曝光 +98% 但 CTR 1.12% 全场最低", "CTR 修复至店均水平", "高: 主图可直接执行"),
        }
        for pid, (reason, impact, act) in prio.items():
            conn.execute(
                """UPDATE product_optimizations SET priority_reason=?, impact=?, actionability=?
                   WHERE product_id=?""", (reason, impact, act, pid))

        conn.commit()
        deep_n = conn.execute("SELECT COUNT(*) FROM product_optimizations WHERE deep_plan_json IS NOT NULL").fetchone()[0]
        print(f"deep plans: {deep_n}/8 | priority fields updated | 双变量/MOQ/合规修复完成")
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
