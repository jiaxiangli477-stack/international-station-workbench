# -*- coding: utf-8 -*-
"""
V4 构建：v4_data.json -> dashboard/dashboard_data.js，并复制 v4 模板到 dashboard/。
"""
import json, io, sys, os, shutil, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

SRC = 'templates/v4'
DST = 'dashboard'
os.makedirs(DST, exist_ok=True)

# 看板访问密码：优先取环境变量 GOS_DASHBOARD_PASSWORD，未设置用默认值；留空 '' 则不加密
PASSWORD = os.environ.get('GOS_DASHBOARD_PASSWORD', '')

# 1. 数据 -> dashboard_data.js（可选 AES-GCM 加密）
data = json.load(open('v4_data.json', encoding='utf-8'))
store_name = (data.get('meta') or {}).get('store_name', '')
raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')

if PASSWORD:
    import hashlib, base64
    from Crypto.Cipher import AES
    key = hashlib.sha256(PASSWORD.encode('utf-8')).digest()
    nonce = os.urandom(12)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ct, tag = cipher.encrypt_and_digest(raw)
    enc = base64.b64encode(nonce + ct + tag).decode('ascii')
    js = 'window.V4_DATA_ENCRYPTED = ' + json.dumps(enc) + ';\n'
    mode = 'AES-GCM 加密'
else:
    js = 'window.V4_DATA = ' + raw.decode('utf-8') + ';\n'
    mode = '明文'
with open(os.path.join(DST, 'dashboard_data.js'), 'w', encoding='utf-8') as f:
    f.write(js)
print('dashboard_data.js 写入完成（%s）, %d bytes' % (mode, len(js.encode('utf-8'))))

# 2. 复制模板
for fn in ['index.html', 'styles.css', 'app.js']:
    shutil.copyfile(os.path.join(SRC, fn), os.path.join(DST, fn))
print('复制 index.html / styles.css / app.js')

# 3. 替换 store 占位
#    店名取自 v4_data.json 的 meta.store_name；运营者标签取自 workspace/stores.json 的 user_label
#    （同事各自的店与账号，都是构建时注入，前端模板里不含任何真实身份）
_user_label = ''
try:
    _cfg = json.load(open('stores.json', encoding='utf-8'))
    _st = (_cfg.get('stores') or {}).get(_cfg.get('active')) or {}
    _user_label = (_st.get('user_label') or '').strip()
except Exception:
    pass

idx = os.path.join(DST, 'index.html')
html = open(idx, encoding='utf-8').read()
html = html.replace('__STORE_NAME__', store_name or '店铺')
html = html.replace('__USER_LABEL__', _user_label or '运营账号')
# cache-busting：dashboard_data.js 固定文件名易被浏览器缓存，注入文件时间戳强制刷新
mtime = int(os.path.getmtime(os.path.join(DST, 'dashboard_data.js')))
html = html.replace('<script src="dashboard_data.js"></script>',
                    '<script src="dashboard_data.js?v=%d"></script>' % mtime)
open(idx, 'w', encoding='utf-8').write(html)

# 4. 检查 chart.js 本地 vendor
chart_local = None
for p in ['templates/v4/chart.umd.min.js', 'dashboard/chart.umd.min.js', 'templates/dashboard/assets/chart.umd.min.js', 'dashboard/assets/chart.umd.min.js']:
    if os.path.exists(p):
        chart_local = p
        break
if chart_local:
    shutil.copyfile(chart_local, os.path.join(DST, 'chart.umd.min.js'))
    html = open(idx, encoding='utf-8').read()
    html = html.replace('https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js', 'chart.umd.min.js')
    open(idx, 'w', encoding='utf-8').write(html)
    print('使用本地 chart.js:', chart_local)
else:
    print('WARN: 未找到本地 chart.js，趋势图依赖 CDN（离线环境图表将不显示）')

print('构建完成 -> dashboard/index.html')
