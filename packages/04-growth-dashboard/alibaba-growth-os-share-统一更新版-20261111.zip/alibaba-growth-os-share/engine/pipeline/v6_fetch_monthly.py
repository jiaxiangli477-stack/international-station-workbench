# -*- coding: utf-8 -*-
"""V6: 拉取全量月度经营数据（含全量同行对标），存 raw/monthly_full.json"""
import subprocess, json, io, sys, os, sqlite3
from datetime import date, timedelta
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 月份：动态计算（最近 N 个完整自然月 + 当前月 MTD），不写死日期
def _mk(y, m): return "%04d-%02d" % (y, m)
import argparse as _ap
_a = _ap.ArgumentParser(description='拉取全量月度经营数据')
_a.add_argument('--months', type=int, default=6, help='拉最近 N 个完整自然月（另含当前月 MTD），默认 6')
_args = _a.parse_args()

_today = date.fromisoformat(os.environ['DASHBOARD_AS_OF'])
_this_first = _today.replace(day=1)
# MTD 截止日取「最近一个完整自然周的周日」，与 gos_window 的窗口口径保持一致
_dow = (_today.weekday() + 1) % 7          # Sunday=0
_mtd_end = _today - timedelta(days=_dow)
MONTHS = []  # Completed calendar months only.
_cursor = _this_first
for _i in range(max(1, _args.months)):
    _m_end = _cursor - timedelta(days=1)              # 上一个完整自然月的最后一天
    _m_start = _m_end.replace(day=1)
    MONTHS.insert(0, (_m_start.isoformat(), _m_end.isoformat(), _mk(_m_start.year, _m_start.month)))
    _cursor = _m_start

def fetch(start, end):
    pfile = os.path.join(os.getcwd(), 'msum_tmp.json')
    with open(pfile, 'w', encoding='utf-8') as f:
        json.dump({"advisorQueryParam": {"statisticsType": "30d", "startDate": start, "endDate": end}}, f)
    r = subprocess.run(['accio-mcp-cli', 'call', 'data_advisor_shop_summary', '--json-file', pfile],
                       capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120, shell=True)
    env = json.loads(r.stdout)
    d = env.get('data') or []
    return d[0] if d else {}

def fnum(v):
    try: return float(v)
    except: return None

def fnum2(v):
    try: return round(float(v), 1)
    except: return None

out = {}
for start, end, key in MONTHS:
    d = fetch(start, end)
    if not d:
        print("%s: 空" % key); continue
    out[key] = {
        "month_start": start, "month_end": end,
        "se_imps": fnum(d.get('seImpsCnt')), "se_clk": fnum(d.get('seClkCnt')), "se_ctr": fnum(d.get('seCtr')),
        "total_imps": fnum(d.get('totalImpsCnt')), "camp_imps": fnum(d.get('campImpsCnt')), "camp_clk": fnum(d.get('qztClkCnt')),
        "fb_cnt": fnum(d.get('fbCnt')), "fb_uv": fnum(d.get('fbUv')), "fb_tm_uv": fnum(d.get('fbTmUv')),
        "ab_cnt": fnum(d.get('abCnt')),
        "uv_cnt": fnum(d.get('uvCnt')), "pv_cnt": fnum(d.get('pvCnt')), "uv_ab_rate": fnum(d.get('uvAbRate')),
        "suc_byr_cnt": fnum(d.get('sucByrCnt')), "suc_ord_cnt": fnum(d.get('sucOrdCnt')), "suc_ord_amt": fnum2(d.get('sucOrdAmt')),
        "uv_payord_rate": fnum(d.get('uvPayordRate')),
        # 全量同行对标
        "se_imps_ra": fnum(d.get('seImpsCntRivalAvg')), "se_imps_rg": fnum(d.get('seImpsCntRivalGood')),
        "se_clk_ra": fnum(d.get('seClkCntRivalAvg')), "se_clk_rg": fnum(d.get('seClkCntRivalGood')),
        "se_ctr_ra": fnum(d.get('seCtrRivalAvg')), "se_ctr_rg": fnum(d.get('seCtrRivalGood')),
        "total_imps_ra": fnum(d.get('totalImpsCntRivalAvg')), "total_imps_rg": fnum(d.get('totalImpsCntRivalGood')),
        "camp_imps_ra": fnum(d.get('campImpsCntRivalAvg')), "camp_imps_rg": fnum(d.get('campImpsCntRivalGood')),
        "camp_clk_ra": fnum(d.get('campClkCntRivalAvg')), "camp_clk_rg": fnum(d.get('campClkCntRivalGood')),
        "fb_cnt_ra": fnum(d.get('fbCntRivalAvg')), "fb_cnt_rg": fnum(d.get('fbCntRivalGood')),
        "fb_tm_ra": fnum(d.get('fbTmUvRivalAvg')), "fb_tm_rg": fnum(d.get('fbTmUvRivalGood')),
        "ab_cnt_ra": fnum(d.get('abCntRivalAvg')), "ab_cnt_rg": fnum(d.get('abCntRivalGood')),
        "uv_cnt_ra": fnum(d.get('uvCntRivalAvg')), "uv_cnt_rg": fnum(d.get('uvCntRivalGood')),
        "uv_ab_ra": fnum(d.get('uvAbRateRivalAvg')), "uv_ab_rg": fnum(d.get('uvAbRateRivalGood')),
        "suc_byr_ra": fnum(d.get('sucByrCntRivalAvg')), "suc_byr_rg": fnum(d.get('sucByrCntRivalGood')),
        "suc_ord_cnt_ra": fnum(d.get('sucOrdCntRivalAvg')), "suc_ord_cnt_rg": fnum(d.get('sucOrdCntRivalGood')),
        "suc_ord_amt_ra": fnum2(d.get('sucOrdAmtRivalAvg')), "suc_ord_amt_rg": fnum2(d.get('sucOrdAmtRivalGood')),
        "uv_payord_ra": fnum(d.get('uvPayordRateRivalAvg')), "uv_payord_rg": fnum(d.get('uvPayordRateRivalGood')),
    }
    print("%s: 搜索曝光%s 询盘%s TM%s 商机%s | GMV%s (同行%s/优秀%s)" % (
        key, out[key]['se_imps'], out[key]['fb_cnt'], out[key]['fb_tm_uv'], out[key]['ab_cnt'],
        out[key]['suc_ord_amt'], out[key]['suc_ord_amt_ra'], out[key]['suc_ord_amt_rg']))

with open('raw/monthly_full.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("saved raw/monthly_full.json")
