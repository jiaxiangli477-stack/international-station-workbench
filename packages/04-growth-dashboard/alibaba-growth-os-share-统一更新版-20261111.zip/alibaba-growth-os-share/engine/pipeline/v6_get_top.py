# -*- coding: utf-8 -*-
import sqlite3, json, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
c = sqlite3.connect('database/alibaba_growth.db')
c.row_factory = sqlite3.Row
cur = c.cursor()
_wk = cur.execute("SELECT stat_week_end, stat_week_start FROM store_weekly_stats ORDER BY stat_week_end DESC LIMIT 1").fetchone()
WE = _wk['stat_week_end'] if _wk else '2026-08-16'
WS = _wk['stat_week_start'] if _wk else '2026-08-10'
# 有真实图URL 的 商机/点击 top 产品
cur.execute("""SELECT p.product_id, p.main_image, p.title, p.prod_level, p.category_name,
  ps.inquiries, ps.clicks, e.atm_fb_uv
  FROM products p
  LEFT JOIN product_weekly_stats ps ON ps.product_id=p.product_id AND ps.week_end=?
  LEFT JOIN product_weekly_stats_ext e ON e.product_id=p.product_id AND e.week_start=?
  WHERE p.main_image LIKE 'http%'
  ORDER BY (COALESCE(ps.inquiries,0) + COALESCE(e.atm_fb_uv,0)) DESC, COALESCE(ps.clicks,0) DESC
  LIMIT 30""", (WE, WS))
rows = [dict(r) for r in cur.fetchall()]
out = []
for r in rows:
    out.append({"product_id": r['product_id'], "img": r['main_image'], "title": (r['title'] or '')[:60],
                "level": r['prod_level'] or '', "cate": r['category_name'] or '',
                "inq": r['inquiries'] or 0, "clk": r['clicks'] or 0, "tm": r['atm_fb_uv'] or 0})
with open('raw/vision_imgs.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("视觉分析目标 %d 个产品：" % len(out))
for o in out:
    print("  %s | 询盘%d TM%d 点击%d | %s" % (o['product_id'], o['inq'], o['tm'], o['clk'], o['title'][:36]))
