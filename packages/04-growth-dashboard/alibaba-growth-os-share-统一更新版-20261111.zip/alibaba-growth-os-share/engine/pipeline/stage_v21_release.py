"""stage_v21_release.py — 冻结 Alibaba Growth OS V2.1 Beta Release。"""
from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKILL = ROOT / "alibaba-growth-os"
REL = ROOT / "releases" / "alibaba-growth-os-v2.1-beta"
ZIP_PATH = ROOT / "releases" / "alibaba-growth-os-v2.1-beta.zip"

PRIVATE = ["LIFEWORTH", "莱华仕", "1653192276", "1600472561736", "1601427218194",
           "1601387052135", "1601728673188", "1601618995199", "1601700931444",
           "1601724696246", "60337273387", "1601847167545", "1601361255457",
           "1601763326911", "60852053624", "1600718096240", "1600530523398",
           "1601386954792", "1600341073560", "26845", "64677", "10677.05", "12909.5", "16132.8"]


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main() -> int:
    if REL.exists():
        shutil.rmtree(REL)
    REL.mkdir(parents=True)
    files = []
    for p in sorted(SKILL.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc":
            rel = p.relative_to(SKILL)
            dest = REL / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dest)
            files.append(rel.as_posix())
    manifest = {
        "skill_name": "alibaba-growth-os",
        "skill_version": "2.1.0-beta",
        "schema_version": "1.0-stageA+stageB+d1+e+f+v2+v2.1",
        "release_date": date.today().isoformat(),
        "supersedes": "2.0.0-beta（V1.0-V2.0 均保留）",
        "supported_commands": [
            "SYNC WEEKLY", "SYNC MONTHLY", "OPTIMIZE PRODUCT <id>", "OPTIMIZE TOP PRODUCTS",
            "REBUILD DASHBOARD", "VALIDATE GROWTH OS", "RETRY PERIOD <period>",
            "EXPORT STORE PACKAGE", "IMPORT STORE PACKAGE", "INITIALIZE STORE",
            "IMPORT ACTION UPDATES", "DISCOVER COMPETITORS", "REFRESH MARKET INTELLIGENCE"
        ],
        "v21_features": {
            "global_period_selector": "全局 Period Bar（周/月切换真实生效，KPI/Funnel/Gap 随周期变化）",
            "overview_visual": "经营漏斗 Flow（Inquiry/TM 并行）+ 9 KPI 卡 + Benchmark Bar + 预警 + 增长机会 + AI 摘要",
            "focus_opportunity_boards": "9 个机会榜（自然增长/高曝光低点击/高点击低商机/高商机/TM/潜力升级/下降风险/爆品/等级结构）+ 缩略图 + badge + 三按钮",
            "trends_complete": "Store 5 图（Chart.js 本地 vendor）+ Product 选择器 + Advertising/CS/Buyer TAB",
            "snapshot_pipeline": "buyer_snapshot / customer_service_snapshot 表（趋势基础）",
            "competitor_real": "5 家真实同行（含国家/验证/收入）+ 竞品产品卡真实图片（本地缓存）",
            "chart_vendor": "本地 Chart.js（dashboard/assets/vendor/，file:// 可用，禁 CDN）"
        },
        "required_runtime_capabilities": ["python3", "Alibaba 官方数据访问", "config.json", "SQLite", "浏览器(file://)"],
        "default_locale": "zh-CN", "data_delay_days": 2, "week_start": "Monday", "week_end": "Sunday",
        "read_only_default": True,
        "files": {f: sha256(REL / f) for f in files},
        "checksums_algorithm": "SHA-256",
    }
    (REL / "RELEASE_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    leaks = []
    for p in REL.rglob("*"):
        if not p.is_file() or p.name == "RELEASE_MANIFEST.json":
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except Exception:
            continue
        for m in PRIVATE:
            idx = text.find(m)
            if idx >= 0 and "EXAMPLE ONLY" not in text[max(0, idx - 150): idx + 150]:
                leaks.append(f"{p.relative_to(REL)}: {m}")
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(REL.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(REL).as_posix())
    print(json.dumps({
        "release_dir": str(REL), "file_count_incl_manifest": len(files) + 1,
        "zip": str(ZIP_PATH), "zip_size_kb": round(ZIP_PATH.stat().st_size / 1024, 1),
        "private_data_leaks": leaks if leaks else "NONE (PASS)",
    }, ensure_ascii=False, indent=1))
    return 0 if not leaks else 1


if __name__ == "__main__":
    raise SystemExit(main())
