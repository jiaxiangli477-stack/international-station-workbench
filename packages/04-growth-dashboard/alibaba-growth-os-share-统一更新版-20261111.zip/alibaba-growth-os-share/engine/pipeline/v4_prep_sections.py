# -*- coding: utf-8 -*-
"""V5: 数据预处理 —— 国家(行业+我的)合并、流量渠道、买家L1+、关键词(过滤擦边)、热销品(过滤+带图)"""
import sqlite3, json, io, sys, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def load(p):
    with open(p, 'rb') as f: raw = f.read()
    if raw[:2] == b'\xff\xfe': return json.loads(raw.decode('utf-16'))
    if raw[:3] == b'\xef\xbb\xbf': return json.loads(raw.decode('utf-8-sig'))
    return json.loads(raw.decode('utf-8'))

# 国家代码 → 中文名
CC = {"US":"美国","FR":"法国","CD":"刚果(金)","GH":"加纳","CI":"科特迪瓦","SN":"塞内加尔","UK":"英国","CA":"加拿大","PH":"菲律宾","AU":"澳大利亚","CM":"喀麦隆","LB":"黎巴嫩","SA":"沙特","AE":"阿联酋","IN":"印度","DE":"德国","ZA":"南非","TG":"多哥","ES":"西班牙","PK":"巴基斯坦","BJ":"贝宁","BF":"布基纳法索","CN":"中国","BR":"巴西","MX":"墨西哥","RU":"俄罗斯","NG":"尼日利亚","KE":"肯尼亚","MA":"摩洛哥","IT":"意大利","NL":"荷兰","PL":"波兰","TR":"土耳其","ID":"印尼","TH":"泰国","VN":"越南","MY":"马来西亚","SG":"新加坡","JP":"日本","KR":"韩国","CO":"哥伦比亚","AR":"阿根廷","CL":"智利","PE":"秘鲁","EG":"埃及"}
EN2CC = {"United States":"US","United Kingdom":"UK","India":"IN","France":"FR","Philippines":"PH","Spain":"ES","Burkina Faso":"BF","Saudi Arabia":"SA","Cote d'Ivoire":"CI","Ivory Coast":"CI","Senegal":"SN","Canada":"CA","Australia":"AU","Cameroon":"CM","Lebanon":"LB","United Arab Emirates":"AE","Germany":"DE","South Africa":"ZA","Togo":"TG","Pakistan":"PK","Benin":"BJ","China":"CN","Brazil":"BR","Mexico":"MX","Russia":"RU","Nigeria":"NG","Kenya":"KE","Morocco":"MA","Italy":"IT","Netherlands":"NL","Poland":"PL","Turkey":"TR","Indonesia":"ID","Thailand":"TH","Vietnam":"VN","Malaysia":"MY","Singapore":"SG","Japan":"JP","South Korea":"KR","Korea":"KR","Colombia":"CO","Argentina":"AR","Chile":"CL","Peru":"PE","Egypt":"EG","Ghana":"GH","Congo (DRC)":"CD","DR Congo":"CD","Congo":"CD"}

# ===== 1. 行业国家榜 + 我的国家数据 合并 =====
ind = load('raw/industry_country_rank.json')
ind_data = ind.get('data') or []
ind_by_country = {}
for it in ind_data:
    cc = it.get('countryId') or ''
    ind_by_country[cc] = {
        "ind_ab": float(it.get('abCnt') or 0),          # 行业询盘规模
        "ind_yoy": round(float(it.get('abCntYoy') or 0)*100, 1),  # 行业询盘增速
        "ind_sd": float(it.get('supplyDemandRate') or 0),  # 供需比
        "ind_dab": round(float(it.get('dAbRate') or 0)*100, 1),  # 行业转化
        "hot_products": [{"name": (p.get('prodName') or '')[:40], "img": p.get('prodImage') or ''} for p in (it.get('prodInfoList') or [])[:4]],
    }

my = load('raw/country_region.json')
my_data = my.get('countries') or []
my_by_cc = {}
for c in my_data:
    en = c['country']
    cc = EN2CC.get(en) or en
    my_by_cc[cc] = c

# 合并：以行业榜国家为主，补我的数据
merged = []
for cc, indv in ind_by_country.items():
    name = CC.get(cc, cc)
    mv = my_by_cc.get(cc) or {}
    my_uv = mv.get('uv') or 0
    my_conv = mv.get('conv_rate') or 0
    # 判定
    ind_dab = indv['ind_dab']
    if my_uv >= 10:
        if my_conv >= ind_dab: verdict, vcls = "达标·跟住行业", "good"
        elif my_conv >= ind_dab*0.6: verdict, vcls = "略低于行业", "warn"
        else: verdict, vcls = "转化落后·优化", "danger"
    else:
        verdict, vcls = "量小·观察", "muted"
    merged.append({
        "country": name, "cc": cc,
        "ind_ab": indv['ind_ab'], "ind_yoy": indv['ind_yoy'], "ind_sd": indv['ind_sd'], "ind_dab": ind_dab,
        "my_uv": my_uv, "my_conv": my_conv,
        "verdict": verdict, "vcls": vcls,
        "hot_products": indv['hot_products'],
    })
merged.sort(key=lambda x: -(x['ind_ab'] or 0))

# ===== 2. 流量渠道结构 =====
flow = load('raw/shop_flow_channel.json')
flow_data = flow.get('data') or []
channels = {}
for it in flow_data:
    st = it.get('sourceType') or ''
    if st == 'TOTAL': continue
    ss = it.get('subSourceType') or 'TOTAL'
    if ss != 'TOTAL': continue
    uv = float(it.get('uv') or 0)
    abr = float(it.get('abRate') or 0)
    channels[st] = {"uv": uv, "ab_rate": round(abr*100, 1)}
ch_total = sum((v['uv'] for v in channels.values()), 0) or 1
ch_out = []
for st, v in channels.items():
    ch_out.append({"channel": st, "uv": int(v['uv']), "share": round(v['uv']/ch_total*100, 1), "ab_rate": v['ab_rate']})
ch_out.sort(key=lambda x: -(x['uv']))

# ===== 3. 买家身份 L1+ vs 全部 =====
c = sqlite3.connect('database/alibaba_growth.db')
c.row_factory = sqlite3.Row
cur = c.cursor()
def get_profile(growth, dim):
    cur.execute("SELECT payload_json FROM customer_profile_snapshot WHERE dimension=? AND byr_growth_level=? LIMIT 1", (dim, growth))
    r = cur.fetchone()
    if not r: return []
    try:
        j = json.loads(r['payload_json'])
        key = dim  # byr_identity / country
        for seg in j:
            if key in seg:
                return seg[key]
    except: return []
    return []

IDENT_CN = {"online_retailer":"线上零售商","offline_retailer":"线下零售商","wholesale":"批发商","manufacturer":"制造商","retailer":"零售商"}
all_ident = get_profile('', 'byr_identity')
l1_ident = get_profile('L1+', 'byr_identity')
buyer_ident = []
for a in all_ident[:6]:
    b = a.get('byrIdentity') or ''
    av = float(a.get('visitorRate') or 0)*100
    lv = None
    for l in l1_ident:
        if (l.get('byrIdentity') or '') == b: lv = float(l.get('visitorRate') or 0)*100
    buyer_ident.append({"ident": IDENT_CN.get(b, b), "en": b, "all_rate": round(av,1), "l1_rate": round(lv,1) if lv is not None else None})
# B2B 占比（后端统一计算，前端只展示，禁止前端临时表达式/恒等条件）
# 定义：B2B = 批发商 + 制造商 + 线下零售商 + 零售商；线上零售商单独统计（电商/代发卖家）
B2B_IDS = {"offline_retailer", "wholesale", "manufacturer", "retailer"}
if buyer_ident:
    b2b_rate = round(sum(b['all_rate'] for b in buyer_ident if b['en'] in B2B_IDS), 1)
    online_retail_rate = next((b['all_rate'] for b in buyer_ident if b['en'] == 'online_retailer'), None)
    b2b_stats = {
        "b2b_rate": b2b_rate,
        "online_retail_rate": online_retail_rate,
        "total_rate": round(sum(b['all_rate'] for b in buyer_ident), 1),
        "available": True,
        "definition": "B2B = 批发商 + 制造商 + 线下零售商（含零售商）；线上零售商单独统计（电商/代发）",
        "scope": "全部可识别买家占比；L1+ 占比见下表",
    }
else:
    b2b_stats = {
        "b2b_rate": None, "online_retail_rate": None, "total_rate": None,
        "available": False,
        "definition": "B2B = 批发商 + 制造商 + 线下零售商（含零售商）；线上零售商单独统计（电商/代发）",
        "scope": "买家身份画像数据未接入（customer_profile_snapshot 为空），无法计算 B2B 占比",
    }

# L1+ 国家占比 vs 全部
all_country = get_profile('', 'country')
l1_country = get_profile('L1+', 'country')
country_l1 = []
for a in all_country[:12]:
    cc = a.get('country') or ''
    av = float(a.get('visitorRate') or 0)*100
    lv = None
    for l in l1_country:
        if (l.get('country') or '') == cc: lv = float(l.get('visitorRate') or 0)*100
    country_l1.append({"cc": cc, "name": CC.get(cc, cc), "all_rate": round(av,1), "l1_rate": round(lv,1) if lv is not None else None})

# ===== 4. 关键词（过滤擦边/不相关）=====
kw = load('raw/industry_keyword.json')
kw_data = (kw.get('data') or [{}])[0]
se_kw = kw_data.get('seKwRate') or []
BANNED = ["male vitality","male enhancement","penis","erectile","enlarge","libido","sex","sexual","men power","testosterone","micro bikini","bikini","slimming","weight loss","fat burn","diet","skinny","detox","lose weight","fat","maca","vitality","vaginal","tightening","bbl","butt","enlargement","booster","male","man plus","man power","duozi"]
def is_banned(k):
    kk = (k or '').lower()
    return any(b in kk for b in BANNED)
keywords = []
for k in se_kw[:20]:
    kk = k.get('idxKey') or ''
    if is_banned(kk): continue
    keywords.append({"kw": kk, "idx": k.get('idxValue'), "rate": k.get('idxRate')})
keywords = keywords[:10]

# ===== 5. 热销品过滤（去擦边/减肥）+ 带图 =====
BANNED_PROD = BANNED + ["maca","gummies slimming","cbd","enlargement","booster","male"]
def prod_banned(t):
    tt = (t or '').lower()
    return any(b in tt for b in BANNED_PROD)
import re as _re
def _alibaba_url(pid, title):
    if not pid: return None
    slug = _re.sub(r'[^a-z0-9]+', '-', (title or '').lower()).strip('-')[:60]
    return f"https://www.alibaba.com/product-detail/{slug}_{pid}.html"

cur.execute("SELECT rank, title, category, image, product_id, product_url FROM market_products ORDER BY rank")
hot_products_clean = []
for r in cur.fetchall():
    t = r['title'] or ''
    if prod_banned(t): continue
    url = r['product_url'] or _alibaba_url(r['product_id'], t)
    hot_products_clean.append({"title": t[:80], "category": r['category'], "image": r['image'], "url": url, "product_id": str(r['product_id'] or '')})
    if len(hot_products_clean) >= 20: break

out = {
    "country_merged": merged[:15],
    "channels": ch_out,
    "buyer_ident": buyer_ident,
    "b2b_stats": b2b_stats,
    "country_l1": country_l1,
    "keywords": keywords,
    "hot_products_clean": hot_products_clean,
    "banned_count": sum(1 for r in cur.execute("SELECT title FROM market_products") if prod_banned(r['title'] or '')),
}
with open('raw/v4_sections.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

print("国家合并:", len(merged), "| 渠道:", len(ch_out), "| 买家身份:", len(buyer_ident), "| 关键词(过滤后):", len(keywords), "| 热销品(过滤后):", len(hot_products_clean), "| 被过滤擦边品:", out['banned_count'])
print("\n渠道结构:")
[print("  %s: uv %s, 占比 %.1f%%, 商机率 %.1f%%" % (x['channel'], x['uv'], x['share'], x['ab_rate'])) for x in ch_out]
print("\n关键词(过滤擦边后):")
[print("  %s (idx %s)" % (x['kw'], x['idx'])) for x in keywords]
