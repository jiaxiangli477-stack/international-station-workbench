# -*- coding: utf-8 -*-
"""V6: 拉取全部产品真实主图 URL，回填 products.main_image"""
import subprocess, json, io, sys, os, sqlite3
from datetime import date, timedelta
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 目标周：优先取 DB 最新完整周，回退到最近一个完整自然周（不写死日期）
WEEK_START, WEEK_END = '', ''
if os.path.exists('database/alibaba_growth.db'):
    try:
        _c = sqlite3.connect('database/alibaba_growth.db')
        _r = _c.execute("SELECT stat_week_start, stat_week_end FROM store_weekly_stats ORDER BY stat_week_end DESC LIMIT 1").fetchone()
        _c.close()
        if _r:
            WEEK_START, WEEK_END = _r[0], _r[1]
    except Exception:
        pass
if not WEEK_END:
    _t = date.today()
    _dow = (_t.weekday() + 1) % 7  # Sunday=0
    _sun = _t - timedelta(days=_dow)
    if _sun >= _t: _sun -= timedelta(days=7)
    WEEK_END = _sun.isoformat(); WEEK_START = (_sun - timedelta(days=6)).isoformat()

def call_page(page_no, page_size=20):
    pfile = os.path.join(os.getcwd(), 'prod_tmp.json')
    payload = {"shopProductQueryParam": {"statisticsType":"week","startDate":WEEK_START,"endDate":WEEK_END,
              "orderBy":"inquiries","order":"desc","pageNo":page_no,"pageSize":page_size,"terminalType":"TOTAL"}}
    with open(pfile, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False)
    r = subprocess.run(['accio-mcp-cli','call','data_advisor_shop_product','--json-file',pfile],
                       capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=180, shell=True)
    env = json.loads(r.stdout)
    d = env.get('data') or {}
    return d.get('recordCount') or 0, d.get('data') or []

def big_img(u):
    if not u: return ''
    return u.replace('_100x100.jpg', '_300x300.jpg').replace('_100x100.JPG', '_300x300.jpg')

all_rows = {}
total = 0
for page in range(1, 40):  # 40页 × 20 = 800 品（覆盖全部 680）
    cnt, rows = call_page(page, 20)
    total = cnt if cnt else total
    for r in rows:
        all_rows[r['id']] = r
    if len(rows) < 20:
        break
    print("页 %d: %d 条 (累计 %d)" % (page, len(rows), len(all_rows)))

print("总记录: %d, 拉到 %d 个产品" % (total, len(all_rows)))

# 回填 products.main_image + 存 detail_url/价格/MOQ 等
c = sqlite3.connect('database/alibaba_growth.db')
cur = c.cursor()
updated = 0
for pid, r in all_rows.items():
    img = big_img(r.get('prodImage') or '')
    if not img: continue
    cur.execute("UPDATE products SET main_image=? WHERE product_id=?", (img, str(pid)))
    if cur.rowcount > 0: updated += 1
c.commit()
c.close()
print("回填主图 URL: %d 个" % updated)

# 保存 top 产品图片清单（用于视觉分析）
top = []
for pid, r in list(all_rows.items())[:60]:
    img = big_img(r.get('prodImage') or '')
    if img:
        top.append({"product_id": str(pid), "img": img, "title": (r.get('subject') or '')[:70],
                    "prod_level": r.get('prodLevel3') or '', "cate": r.get('cateName') or '',
                    "inq": r.get('sumProdFbNum') or 0})
with open('raw/top_imgs.json', 'w', encoding='utf-8') as f:
    json.dump(top, f, ensure_ascii=False, indent=1)
print("保存 top %d 图片清单" % len(top))
for t in top[:10]:
    print("  %s | %s | %s" % (t['product_id'], t['title'][:40], t['img'][:60]))
