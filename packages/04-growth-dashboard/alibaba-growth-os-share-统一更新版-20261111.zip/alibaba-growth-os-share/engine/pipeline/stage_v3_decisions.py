"""stage_v3_decisions.py — Stage V3: Senior Operator Decision Layer。

从 SQLite 真实数据计算运营决策（不是模板拼句）：每周生成 executive_summary / primary_problem
/ root_cause / peer_gap / advantage / opportunities / risks / top_actions(P1/P2/P3)。
页面只展示本层结果，不允许自己从原始数据自由拼句子。
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent / "database" / "alibaba_growth.db"
PERIOD = "2026-08-16"


def pct(a, b):
    return round((a - b) / b, 4) if b else None


def main() -> int:
    conn = sqlite3.connect(str(DB))
    conn.row_factory = sqlite3.Row
    try:
        w = dict(conn.execute("SELECT * FROM store_weekly_stats WHERE stat_week_end=?", (PERIOD,)).fetchone())
        cs = dict(conn.execute("SELECT * FROM service_diag_snapshot ORDER BY stats_date DESC LIMIT 1").fetchone())
        lead = dict(conn.execute(
            "SELECT (SELECT SUM(inquiries) FROM product_weekly_stats WHERE week_start='2026-08-10') AS inquiries,"
            " (SELECT SUM(atm_fb_uv) FROM product_weekly_stats_ext WHERE week_start='2026-08-10') AS tm_uv").fetchone())
        aov = w["suc_ord_amt"] / w["suc_ord_cnt"] if w["suc_ord_cnt"] else 0
        aov_avg = w["suc_ord_amt_rival_avg"] / w["suc_ord_cnt_rival_avg"] if w["suc_ord_cnt_rival_avg"] else 0
        aov_good = w["suc_ord_amt_rival_good"] / w["suc_ord_cnt_rival_good"] if w["suc_ord_cnt_rival_good"] else 0

        # 机会雷达计数
        def cnt(sql):
            return conn.execute(sql).fetchone()[0]
        natural = cnt("SELECT COUNT(*) FROM products p JOIN product_weekly_stats w ON w.product_id=p.product_id AND w.week_start='2026-08-10' LEFT JOIN product_weekly_stats_ext e ON e.product_id=p.product_id AND e.week_start='2026-08-10' WHERE (e.ad_imps=0 OR e.ad_imps IS NULL) AND w.inquiries>=1")
        hi_exp_lo_ctr = cnt("SELECT COUNT(*) FROM products p JOIN product_weekly_stats w ON w.product_id=p.product_id AND w.week_start='2026-08-10' WHERE w.impressions>=300 AND w.ctr<0.015")
        hi_clk_lo_lead = cnt("SELECT COUNT(*) FROM products p JOIN product_weekly_stats w ON w.product_id=p.product_id AND w.week_start='2026-08-10' WHERE w.clicks>=15 AND w.inquiries=0")
        tier_up = cnt("SELECT COUNT(*) FROM products p JOIN product_weekly_stats w ON w.product_id=p.product_id AND w.week_start='2026-08-10' WHERE p.prod_level='潜力优品' AND (w.inquiries>=1 OR w.ctr>=0.02)")
        star = cnt("SELECT COUNT(*) FROM products WHERE prod_level='爆品'")

        # P1 行动（≤5，数据驱动排序）
        p1 = []
        # 1 客服（店级指标 vs 同行，影响客服环节承接）
        if (cs["five_min_reply_rate"] or 0) < (cs["five_min_reply_rate_avg"] or 0) * 0.7:
            p1.append({"priority": "P1", "domain": "客户接待", "object": "客服排班/话术",
                       "problem": f"5分钟首响率 {cs['five_min_reply_rate']:.0%} vs 同行平均 {cs['five_min_reply_rate_avg']:.0%}",
                       "why": "影响进入客服环节后的商机承接（相关性强，因果需验证）",
                       "action": "排班覆盖高峰 + 价格/交期/MOQ 快捷回复 + TM 24h 转询盘",
                       "impact": "首响率→50%+，商机承接提升", "effort": "低", "confidence": "high",
                       "owner": "客服主管", "validation": "2 周后复测 5 分钟首响率与询盘转化"})
        # 2 客单价/大单承接
        if aov < aov_avg * 0.5:
            p1.append({"priority": "P1", "domain": "成交", "object": "客单价提升/大单承接",
                       "problem": f"客单价 ${aov:.0f} 仅同行平均 ${aov_avg:.0f} 约 1/3",
                       "why": "GMV 落后优秀 76% 的主因是客单价与订单结构",
                       "action": "官方定价优化 5 品 + 大客户(批发/品牌商)专项报价 + 高价值买家优先跟进",
                       "impact": "客单价向同行平均靠拢", "effort": "中", "confidence": "high",
                       "owner": "运营负责人", "validation": "客单价与 GMV（1-2 完整自然周）"})
        # 3 Creatine 标题（全球热词 + 竞品 gap）
        p1.append({"priority": "P1", "domain": "产品优化", "object": "1600472561736 Creatine 标题",
                   "problem": "Creatine 为全球最热搜索词，本品核心词位置靠后、缺 Private Label 信号",
                   "why": "官方 top3HotKw = creatine/creatine monohydrate/creatine gummies；竞品 Qinkangda 以 #1 热卖占位",
                   "action": "标题 A/B/C 三方案（主词前置 + Private Label 信号）",
                   "impact": "自然搜索曝光提升", "effort": "低", "confidence": "medium",
                   "owner": "运营", "validation": "搜索曝光/点击/询盘 1 完整自然周"})
        # 4 胶原蛋白 MOQ 试单（同行 gap 真实）
        p1.append({"priority": "P1", "domain": "产品优化", "object": "1601829634947 胶原蛋白 MOQ 阶梯",
                   "problem": "本店 MOQ 10000 sachets/670 bags，同行 Yuhe MOQ 500 + 免费样品 + 15 天交期",
                   "why": "试单门槛显著高于头部同行，压制询盘转化",
                   "action": "REVIEW MOQ LADDER（需业务确认 Sample/Trial 档是否可提供）",
                   "impact": "试单询盘恢复", "effort": "低", "confidence": "medium",
                   "owner": "运营+业务", "validation": "询盘数 1 完整自然周（NEEDS_HUMAN_CONFIRMATION）"})
        # 5 主图（CTR 最低品）
        p1.append({"priority": "P1", "domain": "产品优化", "object": "1601427218194 主图",
                   "problem": "CTR 1.12% 全场最低、曝光 +98% 未兑现",
                   "why": "流量进来了但首屏无法承接点击",
                   "action": "主图改造任务书（200mg Caffeine 徽章 + 成分矩阵）",
                   "impact": "CTR 修复至店均", "effort": "中", "confidence": "medium",
                   "owner": "设计+运营", "validation": "CTR 1 完整自然周（A/B）"})
        p1 = p1[:5]

        # P2（优化方案其余，≤10）
        p2 = []
        for r in conn.execute("SELECT product_id, primary_action, confidence FROM product_optimizations WHERE id > 5 ORDER BY id LIMIT 10"):
            p2.append({"priority": "P2", "domain": "产品优化", "object": r["product_id"],
                       "action": r["primary_action"], "confidence": r["confidence"] or "medium",
                       "why": "Top20 多因素评分入选", "impact": "对应漏斗层改善", "effort": "中"})

        # P3 观察池
        p3 = [{"priority": "P3", "domain": "观察", "object": f"潜力优品升级候选 {tier_up} 个 + 自然增长 {natural} 个",
               "why": "进入观察池，数据变化后自动升级为 P1/P2"}]

        decision = {
            "period": PERIOD, "generated_at": "2026-08-22",
            "executive_summary": "流量不是问题，成交效率才是问题。",
            "primary_problem": f"UV→订单转化 {w['uv_payord_rate']:.2%}（同行优秀 {w['uv_payord_rate_rival_good']:.2%}）+ 客单价 ${aov:.0f} 仅同行平均约 1/3",
            "primary_root_cause": "订单结构以小单为主（客单价差距 -66%），非流量不足；客服响应落后放大商机承接损失",
            "secondary_problem": f"客服 5 分钟首响率 {cs['five_min_reply_rate']:.0%} 落后同行 {cs['five_min_reply_rate_avg']:.0%}（相关关系，因果需验证）",
            "largest_peer_gap": f"GMV 落后同行优秀 {pct(w['suc_ord_amt'], w['suc_ord_amt_rival_good'])*100:.0f}%（${w['suc_ord_amt']:.0f} vs ${w['suc_ord_amt_rival_good']:.0f}）",
            "strongest_advantage": f"流量规模高于同行平均 {pct(w['total_imps'], w['total_imps_rival_avg'])*100:.0f}%（${w['total_imps']} vs ${w['total_imps_rival_avg']}）",
            "top_opportunities": [
                {"name": "Creatine 全球最热搜索词", "why": "官方 top3HotKw，本店 2 个 Creatine 品处于最热赛道", "impact": "标题重构可放大自然曝光"},
                {"name": "自然增长产品 " + str(natural) + " 个", "why": "零付费曝光但已产生商机，最值得保护+测试放量", "impact": "PROTECT + PAID_TEST"},
                {"name": "潜力优品升级 " + str(tier_up) + " 个", "why": "官方等级距优品最近的一批，集中资源冲级", "impact": "优品占比提升"},
                {"name": "胶原蛋白高增长", "why": "官方子类目增速 +32.6%、转化 8.7%", "impact": "补 MOQ 试单承接需求"},
            ],
            "top_risks": [
                {"name": "GMV 连续 3 周回落", "why": "W3 $16,133 → W1 $2,542，客单价+转化双低", "impact": "现金流/店铺层级风险"},
                {"name": "美国需求环比 -33.2%", "why": "官方 opportunity(US 30d) 需求指数下滑", "impact": "主要市场短期波动"},
                {"name": "客服首响率落后 60%", "why": "22.1% vs 55.7%，商机承接弱", "impact": "询盘转化损失"},
            ],
            "top_actions": {"P1": p1, "P2": p2, "P3": p3},
            "why_now": "本周是流量红利窗口（Creatine 全球热词 + 曝光超同行优秀），但转化效率落后正在浪费流量优势",
            "expected_impact": "P1 五件事落地后，2-4 周客单价与询盘承接改善，GMV 向同行平均靠拢",
            "validation": "每项含 1 完整自然周验证指标；One Variable Test 控制因果",
            "radar": {"natural": natural, "hi_exp_lo_ctr": hi_exp_lo_ctr, "hi_clk_lo_lead": hi_clk_lo_lead,
                      "tier_up": tier_up, "star": star},
        }
        conn.execute("DROP TABLE IF EXISTS operator_decisions")
        conn.execute("""CREATE TABLE operator_decisions (
            period TEXT PRIMARY KEY, decision_json TEXT, generated_at TEXT)""")
        conn.execute("INSERT INTO operator_decisions (period, decision_json, generated_at) VALUES (?,?,datetime('now'))",
                     (PERIOD, json.dumps(decision, ensure_ascii=False)))
        conn.commit()
        print(json.dumps(decision, ensure_ascii=False, indent=1))
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
