# -*- coding: utf-8 -*-
"""补齐 diagnosis_actions / product_optimizations / competitor_stores 缺列"""
import sqlite3
DB = 'database/alibaba_growth.db'
c = sqlite3.connect(DB)
cur = c.cursor()

def cols(t):
    return {r[1] for r in cur.execute(f"PRAGMA table_info({t})").fetchall()}

def add(t, name, typ):
    if name not in cols(t):
        cur.execute(f"ALTER TABLE {t} ADD COLUMN {name} {typ}")
        print(f"  + {t}.{name} {typ}")

# diagnosis_actions
for name in ["owner","due_date","completed_at","actual_change","notes","updated_at"]:
    add("diagnosis_actions", name, "TEXT")
# product_optimizations
for name in ["status","owner","due_date","completed_at","actual_change","notes","updated_at",
             "deep_plan_json","plan_version","priority_reason","impact","actionability"]:
    add("product_optimizations", name, "TEXT")
# competitor_stores
add("competitor_stores", "country", "TEXT")
add("competitor_stores", "product_count", "INTEGER")

c.commit()
print("done")
c.close()
