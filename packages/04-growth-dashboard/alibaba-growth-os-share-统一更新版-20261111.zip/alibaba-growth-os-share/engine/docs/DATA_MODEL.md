# 数据模型（DATA_MODEL）

本地库为 SQLite，schema 定义在 `schema.sql`。设计原则：

- 业务身份字段（店铺名、Product ID、Campaign ID、关键词）只存**运行时实际值**，全部来自官方数据或配置注入，代码中零写死。
- 原始日度指标全量落表，周/月聚合为派生表（可由日度重算）。
- 诊断、行动、验证、学习为"经营闭环"四表，支撑 Action→Validation→Learning。

## 表清单

| 表 | 粒度 | 用途 |
|----|------|------|
| `store` | 1 行 | 店铺运行时配置快照（来自 config） |
| `products` | 产品 | 产品主档（官方 Product ID） |
| `product_daily_stats` | 产品×天 | 官方日度指标，历史累积主表 |
| `product_weekly_stats` | 产品×周 | 周聚合（派生） |
| `product_monthly_stats` | 产品×月 | 月聚合（派生） |
| `campaigns` | 活动 | 广告活动主档（官方 Campaign ID） |
| `campaign_daily_stats` | 活动×天 | 广告日度指标 |
| `keyword_daily_stats` | 词×产品×天 | 关键词表现 |
| `diagnostics` | 每次诊断 | 结构化发现（findings_json） |
| `actions` | 每条行动 | 经营动作登记与状态 |
| `validations` | 每次验证 | 动作效果验证（基线 vs 验证期） |
| `learnings` | 每条结论 | 可复用学习沉淀 |
| `sync_log` | 每次同步 | 数据新鲜度审计 |

## 核心指标口径

| 指标 | 定义 | 存储位置 |
|------|------|----------|
| impressions | 曝光（官方口径） | `*_daily_stats.impressions` |
| clicks | 点击（官方口径） | `*_daily_stats.clicks` |
| ctr | 点击率 = clicks / impressions | 日度存值，聚合表重算 |
| inquiries | 询盘（官方口径） | `*_daily_stats.inquiries` |
| orders | 订单数（官方口径） | `*_daily_stats.orders` |
| gmv | 成交额（官方口径，币种见 store.currency） | `*_daily_stats.gmv` |
| cost | 广告花费（官方口径） | `campaign_daily_stats.cost` |

## 主键与索引

- 日度表主键：`(product_id, stat_date)` 等，保证按天幂等 upsert。
- 周/月聚合主键：`(product_id, week_start|month_start)`，覆盖式重建。
- 常用查询索引：日期、诊断区间、行动状态、学习类别（见 schema.sql 末尾）。

## 派生关系

- `product_weekly_stats` ← 按 ISO 周聚合 `product_daily_stats`
- `product_monthly_stats` ← 按自然月聚合 `product_daily_stats`
- 趋势基线（Z-score 用）← `trend_baseline_days` 天的日度序列，动态计算，不落表

## 生命周期

- 日度数据只增不删（历史累积）；聚合表可随时全量重建。
- 诊断/行动/验证/学习表随经营持续累积，月度复盘引用。
- `sync_log` 用于审计数据新鲜度；同步失败必须落日志，禁止静默跳过。

## 数据质量承诺

- 无数据 → 明确提示数据缺口，不输出结论。
- 官方口径变化 → 在 `sync_log.message` 与变更记录中标注，聚合对比注明口径。
- 全部对比基线为**店铺自身历史**，不引入外部行业/同行数值。
