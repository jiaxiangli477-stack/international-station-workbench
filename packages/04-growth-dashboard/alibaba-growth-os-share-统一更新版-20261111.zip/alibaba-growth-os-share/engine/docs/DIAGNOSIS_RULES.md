# 诊断规则体系（DIAGNOSIS_RULES）

诊断引擎（`scripts/diagnose.py`）按本规则执行。所有阈值从 `config.json` 的 `diagnosis` 段注入，本文件只描述规则结构，**不写死数值**。

## 规则模板

每条规则必须声明：

```yaml
rule_id: <唯一ID>
dimension: store | product | campaign | keyword
trigger: <触发条件，基于 config 阈值>
method: <计算方法：环比 / Z-score / 占比 / 排名>
confidence: <判定后的置信度逻辑>
action_hint: <建议动作类型，链接 flows/optimize_product.md>
```

## 规则清单（默认集）

### R1 店铺整体环比（dimension: store）

- 指标：曝光、点击、GMV、订单、CTR。
- 方法：当前窗口 vs 上一窗口，计算 delta_pct。
- 触发：delta_pct 超过 config 中配置的环比告警阈值（默认段见 config，可调）。
- 置信度：与基线 Z-score 交叉验证时升级为 high；仅环比时 medium。
- 输出：每个指标一条 finding。

### R2 店铺趋势异常（dimension: store）

- 方法：当前窗口均值 vs 前 `trend_baseline_days` 天分布，Z-score。
- 触发：|Z| ≥ `anomaly_zscore_threshold`。
- 置信度：high（有统计依据）；基线样本 < `min_sample_days` 时不判定（输出"数据不足"）。

### R3 产品贡献排名（dimension: product）

- 方法：窗口内按 GMV 排序取 Top-N（N 来自 config，默认段见配置）。
- 用途：识别核心产品，供优化器与周报引用。
- 置信度：high（直接来自官方数据）。

### R4 产品异常波动（dimension: product）

- 方法：单品窗口汇总 vs 自身历史窗口，Z-score 或环比。
- 触发：超过阈值。
- 注意：单品日粒度噪声大，置信度默认 medium，需结合上下文（活动/价格变化）复核。

### R5 广告效率（dimension: campaign）

- 指标：花费、点击、订单、GMV、ROI（GMV/花费，从官方数据计算）。
- 方法：窗口内效率变化 + 花费结构占比。
- 触发：ROI 低于 config 阈值或花费突增。
- 输出：建议动作（bid_change / 预算调整）。

### R6 关键词表现（dimension: keyword）

- 方法：词级曝光/点击/花费/订单窗口对比。
- 触发：高花费低转化词、高转化低曝光词。
- 输出：建议动作（keyword_add / 否定词）。

## 置信度规则

| 置信度 | 条件 |
|--------|------|
| high | Z-score 判定 + 样本充足（≥ `min_sample_days` 天）+ 无已知混淆事件 |
| medium | 环比判定 / 样本不足 / 存在未排除混淆因素 |
| low | 数据缺口、口径变更、或仅单日证据 |

## 输出格式（findings 结构）

```json
{
  "dimension": "store",
  "metric": "gmv",
  "current": 12345,
  "prev": 10000,
  "delta_pct": 0.2345,
  "zscore": 2.1,
  "confidence": "high"
}
```

## 混淆因素处理

- 发现异常时，检查同期是否发生：活动/大促、价格调整、标题或主图变更、广告预算变动。
- 存在混淆因素则置信度降级并在 finding 中标注 `confounded: true`。
- 禁止仅凭时间巧合断言因果；验证归因必须走 `flows/validation.md` 控制实验式对比。

## 规则维护

- 新规则必须先在本文档登记（含触发条件与置信度逻辑），再在 `diagnose.py` 实现。
- 高置信度、可复用的经营经验写入 `learnings` 表，月度复盘时评估规则有效性。
- 行业/同行对比数值一律不引入；如用户提供外部基准，仅作为参考标注来源，不作为默认规则。
