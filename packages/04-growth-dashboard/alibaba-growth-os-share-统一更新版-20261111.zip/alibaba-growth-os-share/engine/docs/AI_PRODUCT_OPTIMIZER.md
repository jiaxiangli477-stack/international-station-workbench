# AI Product Optimizer（方法论）

产品优化器（`scripts/optimizer.py`）从店铺自身历史数据中识别高潜力与问题产品，生成优化动作并进入验证闭环。**不依赖行业/同行数值，全部基于本店官方数据。**

## 流程

```
screen（候选筛选） → score（评分排序） → actions（生成动作） → validate（验证闭环）
```

## 1. 候选筛选（screen）

按 `config.optimizer` 阈值筛选三类候选：

| 阶段(stage) | 特征 | 意义 |
|-------------|------|------|
| `traffic_rich_low_conv` | 曝光/点击充足、转化低于阈值 | 流量浪费，转化要素待优化 |
| `conv_rich_low_traffic` | 转化好但流量不足 | 潜力被流量瓶颈压制 |
| `declining` | 点击相对自身前窗口显著下滑 | 排名/流量流失预警 |

筛选使用店铺自身分布，不引入外部基准。

## 2. 评分（score）

综合分 = Σ(权重 × 归一化子分)，权重来自 `config.optimizer.score_weights`：

- **conversion_potential（转化潜力）**：基于转化率（orders/clicks）。
- **traffic_potential（流量潜力）**：基于 CTR 与曝光规模。
- **profitability（盈利性）**：基于 GMV。

归一化：候选集内 min-max 归一化到 0-1。候选池上限 `candidate_pool_size`。

## 3. 动作生成（actions）

| 动作类型 | 适用 stage | 内容 |
|----------|-----------|------|
| `title_rewrite` | traffic_rich_low_conv | 基于店铺自身关键词数据优化标题匹配 |
| `keyword_add` | conv_rich_low_traffic | 扩充高相关关键词、评估广告流量 |
| `bid_change` | declining | 调整出价/预算，保核心词排名 |
| `price_adjust` | 弹性证据充分时 | 价格区间建议（标注置信度） |
| `image/description` | 转化要素弱时 | 素材与详情优化提示 |

每条动作写入 `actions` 表（status=planned），含 expected_impact 与验证指标建议。

## 4. 验证闭环

- 动作执行后进入 `flows/validation.md`：基线期（动作前 `trend_baseline_days` 天均值）vs 验证期（≥ `min_validation_days` 天）。
- 判定：positive / neutral / negative / inconclusive。
- 结论沉淀 `learnings` 表，高置信度结论形成"已知模式"，供后续优化复用。

## 证据纪律

- 每个候选必须附带评分构成（score_breakdown）与原始指标证据。
- 转化/流量异常判定必须先排除同期混淆事件（活动、价格变动等）。
- 单产品短窗口噪声大：置信度默认 medium，验证窗口不足判 inconclusive，不强行下结论。
- 优化建议只基于本店数据；用户提供的行业参考仅作背景，不进入评分。

## 输出

- 候选清单（JSON）：stage、指标、score、score_breakdown。
- 行动登记：action_id 与描述。
- 验证计划：指标、窗口、判定标准。
