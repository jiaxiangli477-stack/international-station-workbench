# 架构说明（ARCHITECTURE）

## 总览

Alibaba Growth OS 是"可复用 Skill + 官方数据 + 本地历史 + AI 诊断 + 产品优化 + 验证闭环 + 中文 Dashboard"的经营系统。一个 Workspace 绑定一个 Alibaba 店铺。

```
┌─────────────────────────────────────────────────────────────┐
│                      用户 / 运营者                            │
│   提出诊断/优化/复盘请求 → 获得中文报告与 HTML Dashboard        │
└───────────────┬─────────────────────────────┬───────────────┘
                │ 调用                        │ 产出
┌───────────────▼─────────────────────────────▼───────────────┐
│                     Flow 层（flows/*.md）                     │
│   init → weekly → monthly → dashboard → optimize → validation│
└───────────────┬─────────────────────────────────────────────┘
                │ 编排
┌───────────────▼─────────────────────────────────────────────┐
│                    Scripts 层（scripts/*.py）                 │
│  sync.py ── 官方数据适配(DataProvider 契约)                   │
│  db.py ──── SQLite 持久化 + 周/月聚合                         │
│  window.py 时间窗口(周/月/基线，不写死日期)                     │
│  diagnose.py 诊断引擎 → diagnostics 表                        │
│  optimizer.py 候选筛选/评分 → actions 表                      │
│  dashboard_build.py 渲染 Jinja2 → output/*.html               │
└───────┬──────────────────────┬───────────────────────────────┘
        │ 写入                  │ 读取
┌───────▼────────────┐  ┌──────▼───────────────────────────────┐
│  Alibaba 官方数据源  │  │  本地库 SQLite（schema.sql）           │
│  (外部系统，经适配器) │  │  store/products/*_stats/campaigns/   │
└────────────────────┘  │  keywords/diagnostics/actions/        │
                        │  validations/learnings/sync_log       │
                        └───────────────────────────────────────┘
```

## 分层职责

| 层 | 组件 | 职责 | 禁止事项 |
|----|------|------|----------|
| 流程层 | `flows/*.md` | 定义标准工作流（何时做什么、产出什么） | 不写死业务数值 |
| 脚本层 | `scripts/*.py` | 可复用实现，CLI 驱动 | 不硬编码店铺/产品/活动/日期/行业/同行 |
| 数据层 | `schema.sql` + `db.py` | 本地持久化历史，唯一历史来源 | 不存样例数据 |
| 模板层 | `templates/dashboard.html.j2` | Dashboard 渲染模板 | 不内嵌具体数据（数据经 JSON 注入） |
| 文档层 | `docs/*.md` | 规则、模型、方法论 | 数值一律占位 |

## 数据流

1. **同步**：`sync.py` 通过 `DataProvider` 契约拉取 Alibaba 官方日度指标 → 写入 `*_daily_stats`。
2. **聚合**：`db.py --aggregate` 生成周/月聚合表。
3. **诊断**：`diagnose.py` 读取本地历史 + config 阈值 → 结构化 findings → `diagnostics` 表。
4. **优化**：`optimizer.py` 筛选候选、评分、登记行动 → `actions` 表。
5. **验证**：验证窗口结束后回填 `validations`，更新行动状态；结论沉淀到 `learnings`。
6. **展示**：`dashboard_build.py` 读本地库 → 渲染模板 → 全量重建 HTML。

## 设计约束（贯穿全层）

- **可复用**：一切业务参数来自 `config.json`；代码/文档零写死。
- **单一店铺**：一个 Workspace = 一个店铺，`store` 表仅一行运行时快照。
- **官方数据唯一**：不手工录入、不伪造数据源；未接入时明确报错。
- **Dashboard 一次性生成**：每次全量重建，禁止手工编辑产物。
- **闭环强制**：行动必须经过验证并沉淀学习，学习供后续诊断复用。

## 运行入口

| 命令 | 作用 |
|------|------|
| `python scripts/db.py --config config.json --init` | 建库 |
| `python scripts/sync.py --config config.json --init-sync` | 首次同步 |
| `python scripts/diagnose.py --config config.json --scope weekly` | 周度诊断 |
| `python scripts/dashboard_build.py --config config.json` | 生成 Dashboard |
| `python scripts/optimizer.py --config config.json --stage actions` | 产品优化 |

## 扩展点

- 接入新数据源：实现 `DataProvider` 子类并注册到 `sync.PROVIDERS`。
- 新诊断规则：在 `docs/DIAGNOSIS_RULES.md` 登记规则并在 `diagnose.py` 实现，阈值走配置。
- 新 Dashboard 区块：修改模板并在 `dashboard_build.collect()` 补充数据。
