# -*- coding: utf-8 -*-
"""
start.py — 一键部署 + 环境自检 + 引导（"打开即用"入口）

同事解压本包后，双击quickstart.bat(Windows) 或运行 ./start.sh (Mac/Linux)，
即自动在 workspace/ 目录里铺好全部脚本 + schema + 前端模板，生成 stores.json
模板，并自检运行环境。全程无需手动复制任何文件。

用法:
  python start.py                 # 部署 + 自检 + 打印下一步（不拉数，安全）
  python start.py --run           # 部署后自动跑核心流程，出基础看板
  python start.py --run --full    # 追加竞品/同行/客服等数据域（需各域已授权）
  python start.py --run --as-of 2026-09-09 --store mystore
  python start.py --open          # 打开已生成的 dashboard/index.html
  python start.py --run --full --weeks 8           # ★懒人模式：同步最近 8 个完整自然周
  python start.py --run --full --weeks 8 --as-of 2026-08-31   # 截至 8/31 往前 8 周（指定时间段）

说明:
  - 部署目标 = 本包下的 workspace/（自包含，数据 raw/ database/ dashboard/ 都落在里面）
  - 拉数靠的是「当前 Accio 登录的 Alibaba 账号」的实时接口，代码里零写死店铺
  - --run 会自动逐步执行并「失败即停」；首次使用请先在 Accio 完成接口授权
"""
import os, sys, io, shutil, json, argparse, subprocess, platform
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

PKG = os.path.dirname(os.path.abspath(__file__))
PIPE = os.path.join(PKG, 'pipeline')
WS = os.path.join(PKG, 'workspace')
WS_RAW = os.path.join(WS, 'raw')
WS_DB = os.path.join(WS, 'database')

STORES_TPL = {
    "active": "mystore",
    "stores": {
        "mystore": {
            "name": "在此填写-店铺显示名",
            "full_name": "在此填写-公司全称 (English Co., Ltd.)",
            "user_label": "在此填写-顶部显示的运营者（如 张三 (子账号)）",
            "store_id": "在此填写-你的 Alibaba 店铺 ID",
            "category": "在此填写-主类目，如 Sports Nutrition",
            "cate_id": 0,
            "db": "stores/mystore/database/alibaba_growth.db",
            "raw": "stores/mystore/raw",
            "img_map": "stores/mystore/img_map.json",
        }
    }
}


def deploy():
    """把 pipeline 脚本 + schema + 模板铺到 workspace/，生成 stores.json 模板。幂等。"""
    if not os.path.isdir(PIPE):
        print('!! 包不完整：缺少 pipeline/ 目录，请确认 zip 完整解压后再试。')
        return -1, False
    os.makedirs(WS_RAW, exist_ok=True)
    os.makedirs(WS_DB, exist_ok=True)
    n = 0
    for f in os.listdir(PIPE):
        if f.endswith('.py'):
            shutil.copy2(os.path.join(PIPE, f), os.path.join(WS, f))
            n += 1
    for f in ['schema.sql', 'requirements.txt']:
        src = os.path.join(PKG, f)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(WS, f))
            n += 1
    tv = os.path.join(WS, 'templates', 'v4')
    os.makedirs(tv, exist_ok=True)
    src_tv = os.path.join(PKG, 'templates', 'v4')
    if os.path.isdir(src_tv):
        for f in os.listdir(src_tv):
            shutil.copy2(os.path.join(src_tv, f), os.path.join(tv, f))
            n += 1
    sj = os.path.join(WS, 'stores.json')
    created = False
    if not os.path.exists(sj):
        json.dump(STORES_TPL, open(sj, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        created = True
    return n, created


def env_check():
    print('\n=== 环境自检 ===')
    print('Python: %s %s' % (platform.python_version(), platform.system()))
    try:
        import Crypto  # noqa
        print('pycryptodome: OK')
    except Exception:
        print('pycryptodome: 缺失 → 先运行  pip install -r requirements.txt')
    for tool in ['accio-mcp-cli', 'workctl']:
        print('%s: %s' % (tool, '可用' if shutil.which(tool) else '未找到（拉数/星等级需要，Accio 环境通常自带）'))


def stores_placeholder():
    sj = os.path.join(WS, 'stores.json')
    try:
        c = json.load(open(sj, encoding='utf-8'))
        st = c['stores'].get(c.get('active'), {})
        return '在此填写' in json.dumps(st, ensure_ascii=False)
    except Exception:
        return False


def open_dashboard():
    idx = os.path.join(WS, 'dashboard', 'index.html')
    if not os.path.exists(idx):
        print('\ndashboard 尚未生成（先跑 --run）。')
        return
    sysname = platform.system()
    try:
        if sysname == 'Windows':
            os.startfile(idx)  # type: ignore
        elif sysname == 'Darwin':
            subprocess.Popen(['open', idx])
        else:
            subprocess.Popen(['xdg-open', idx])
        print('\n已打开 dashboard/index.html（看板登录口令见「安全须知」）')
    except Exception as e:
        print('\n请手动打开: %s  (%s)' % (idx, e))


def db_has_data():
    db = os.path.join(WS_DB, 'alibaba_growth.db')
    if not os.path.exists(db):
        return False
    import sqlite3
    try:
        c = sqlite3.connect(db)
        n = c.execute('SELECT COUNT(*) FROM products').fetchone()[0]
        c.close()
        return n > 0
    except Exception:
        return False


def run(args):
    print('\n=== 开始跑数据管线（工作区: workspace/）===')
    if stores_placeholder():
        print('  提示: stores.json 仍是占位模板。拉数靠当前 Accio 登录账号，可先跑；但建议先填好店铺名/store_id。')
    py = sys.executable
    aof = ['--as-of', args.as_of] if args.as_of else []
    store = ['--store', args.store] if args.store else []
    wk = ['--weeks', str(args.weeks)] if args.weeks else []

    print('  周窗口: %s（as_of=%s）' % ('%d 个完整自然周' % args.weeks if args.weeks else '默认 4 周',
                                      args.as_of or '今天'))
    steps = [('A1 拉全量(周/月/产品)', [py, 'fetch_new_store.py'] + aof + wk)]
    # A2 幂等 upsert：周数变多（补历史周）时也必须重跑才能回填新周，故不再按 db_has_data 跳过
    steps.append(('A2 建库/回填(幂等)', [py, 'init_store.py'] + aof + store + wk))

    if args.full:
        steps += [
            ('C1 国家/渠道/关键词/类目热品', [py, 'fetch_prep.py']),
            ('C2 同行标杆', [py, 'fetch_peers.py']),
            ('C3 竞店 Top20', [py, 'fetch_competitors.py']),
            ('C4 子账号客服', [py, 'fetch_staff.py']),
            ('C5 地区入库', [py, 'v4_fetch_region.py']),
            ('C6 同行入库', [py, 'v4_ingest_peer.py']),
            ('C7 客服入库', [py, 'v4_ingest_staff.py']),
            ('C8 星等级入库', [py, 'v4_ingest_star.py']),
            ('D1 竞品全量', [py, 'v4_competitors.py']),
        ]

    steps += [
        ('D2 数据预处理', [py, 'v4_prep_sections.py']),
        ('D3 市场趋势证据', [py, 'v6_market_evidence.py']),
        ('D4 AI 五维评分', [py, 'v4_score.py']),
        ('E1 判定合并', [py, 'v4_judge.py']),
        ('E2 构建看板', [py, 'v4_build.py']),
    ]

    for name, cmd in steps:
        print('\n>>> %s\n    $ %s' % (name, ' '.join(cmd)))
        r = subprocess.run(cmd, cwd=WS)
        if r.returncode != 0:
            print('\n!! 步骤「%s」失败 (returncode=%d)，已停止。' % (name, r.returncode))
            print('   常见原因: 接口未授权 / 缺该数据域 / stores.json 未填 / 上一步未产出。')
            print('   修复后重新运行 start.py --run 即可（已完成的步骤可重复执行，幂等）。')
            return 1
    print('\n=== 管线完成 ===')
    open_dashboard()
    return 0


def main():
    ap = argparse.ArgumentParser(description='国际站数据面板 · 一键部署与引导')
    ap.add_argument('--run', action='store_true', help='部署后自动跑数据管线并建看板')
    ap.add_argument('--full', action='store_true', help='--run 时追加竞品/同行/客服/地区等数据域')
    ap.add_argument('--as-of', default=None, help='数据截至日 YYYY-MM-DD（--run 用；默认今天）')
    ap.add_argument('--weeks', type=int, default=None, help='同步 N 个完整自然周（懒人模式；默认 4）。"同步8周"→--weeks 8；"7/1至今"→--weeks N --as-of 截止日期')
    ap.add_argument('--store', default=None, help='stores.json 里的店铺 key（--run 用；默认 active）')
    ap.add_argument('--open', action='store_true', help='部署后打开已生成的 dashboard')
    args = ap.parse_args()

    print('=== 国际站数据面板 · 启动 ===')
    print('包目录:', PKG)
    n, created = deploy()
    if n < 0:
        return 1
    print('已部署 %d 个文件到 workspace/ %s' % (n, '(新生成 stores.json 模板)' if created else ''))
    env_check()

    if args.run:
        return run(args)

    print('\n=== 下一步（手动/一键）===')
    print('1) 在 Accio 登录你的 Alibaba 账号并授权：数据参谋 / 星等级 / 广告')
    if created:
        print('2) 编辑 workspace/stores.json：填 店铺名 / store_id / cate_id')
    print('3) 一键出看板:')
    print('     python start.py --run            # 核心基础看板(周期/重点关注/AI搜索/趋势)')
    print('     python start.py --run --full     # 含竞品/同行/客服/地区(需各域已授权)')
    print('     python start.py --run --full --weeks 8   # 懒人模式: 同步最近 8 周')
    print('     python start.py --run --full --weeks 8 --as-of 2026-08-31  # 指定时间段(截至日往前8周)')
    print('   或手动逐步跑: cd workspace && python fetch_new_store.py ... 见《REPRODUCE_GUIDE.md》')
    print('4) 打开: python start.py --open')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
