-- Alibaba Growth OS 本地持久化库 schema（SQLite）
-- 原则：不存储任何写死的业务数值；所有数据由同步层按官方数据写入。
-- 一个库对应一个店铺（store 表仅一行运行时配置）。

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- 店铺（运行时配置快照，由 config.json 注入，禁止硬编码）
CREATE TABLE IF NOT EXISTS store (
    id          INTEGER PRIMARY KEY CHECK (id = 1),
    name        TEXT NOT NULL,
    store_id    TEXT NOT NULL,
    currency    TEXT NOT NULL,
    timezone    TEXT NOT NULL,
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 产品主档（Product ID 为官方数据字段，仅存运行时值）
CREATE TABLE IF NOT EXISTS products (
    product_id       TEXT PRIMARY KEY,
    title            TEXT NOT NULL,
    category         TEXT,
    price            REAL,
    unit             TEXT,
    status           TEXT,
    first_seen_at    TEXT,
    last_seen_at     TEXT,
    raw             TEXT
);

-- 产品日度表现（官方原始指标，按天累积历史）
CREATE TABLE IF NOT EXISTS product_daily_stats (
    product_id     TEXT NOT NULL REFERENCES products(product_id),
    stat_date      TEXT NOT NULL,
    impressions    INTEGER NOT NULL DEFAULT 0,
    clicks         INTEGER NOT NULL DEFAULT 0,
    ctr            REAL NOT NULL DEFAULT 0,
    favorites      INTEGER NOT NULL DEFAULT 0,
    inquiries      INTEGER NOT NULL DEFAULT 0,
    orders         INTEGER NOT NULL DEFAULT 0,
    gmv            REAL NOT NULL DEFAULT 0,
    refunds        INTEGER NOT NULL DEFAULT 0,
    raw            TEXT,
    PRIMARY KEY (product_id, stat_date)
);

-- 周度聚合（由同步层按窗口聚合生成）
CREATE TABLE IF NOT EXISTS product_weekly_stats (
    product_id     TEXT NOT NULL REFERENCES products(product_id),
    week_start     TEXT NOT NULL,
    week_end       TEXT NOT NULL,
    impressions    INTEGER NOT NULL DEFAULT 0,
    clicks         INTEGER NOT NULL DEFAULT 0,
    ctr            REAL NOT NULL DEFAULT 0,
    inquiries      INTEGER NOT NULL DEFAULT 0,
    orders         INTEGER NOT NULL DEFAULT 0,
    gmv            REAL NOT NULL DEFAULT 0,
    PRIMARY KEY (product_id, week_start)
);

-- 月度聚合
CREATE TABLE IF NOT EXISTS product_monthly_stats (
    product_id     TEXT NOT NULL REFERENCES products(product_id),
    month_start    TEXT NOT NULL,
    month_end      TEXT NOT NULL,
    impressions    INTEGER NOT NULL DEFAULT 0,
    clicks         INTEGER NOT NULL DEFAULT 0,
    ctr            REAL NOT NULL DEFAULT 0,
    inquiries      INTEGER NOT NULL DEFAULT 0,
    orders         INTEGER NOT NULL DEFAULT 0,
    gmv            REAL NOT NULL DEFAULT 0,
    PRIMARY KEY (product_id, month_start)
);

-- 广告活动（Campaign ID 为官方字段，仅存运行时值）
CREATE TABLE IF NOT EXISTS campaigns (
    campaign_id    TEXT PRIMARY KEY,
    name           TEXT,
    status         TEXT,
    first_seen_at  TEXT,
    last_seen_at   TEXT,
    raw           TEXT
);

CREATE TABLE IF NOT EXISTS campaign_daily_stats (
    campaign_id    TEXT NOT NULL REFERENCES campaigns(campaign_id),
    stat_date      TEXT NOT NULL,
    impressions    INTEGER NOT NULL DEFAULT 0,
    clicks         INTEGER NOT NULL DEFAULT 0,
    cost           REAL NOT NULL DEFAULT 0,
    orders         INTEGER NOT NULL DEFAULT 0,
    gmv            REAL NOT NULL DEFAULT 0,
    raw            TEXT,
    PRIMARY KEY (campaign_id, stat_date)
);

-- 关键词表现（官方字段，运行时值）
CREATE TABLE IF NOT EXISTS keyword_daily_stats (
    keyword        TEXT NOT NULL,
    stat_date      TEXT NOT NULL,
    product_id     TEXT REFERENCES products(product_id),
    impressions    INTEGER NOT NULL DEFAULT 0,
    clicks         INTEGER NOT NULL DEFAULT 0,
    cost           REAL NOT NULL DEFAULT 0,
    orders         INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (keyword, stat_date, product_id)
);

-- 诊断结果（每次诊断的结论快照，含置信度）
CREATE TABLE IF NOT EXISTS diagnostics (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    run_at         TEXT NOT NULL DEFAULT (datetime('now')),
    scope          TEXT NOT NULL,          -- weekly | monthly | product | ad
    period_start   TEXT,
    period_end     TEXT,
    findings_json  TEXT NOT NULL,          -- 结构化发现列表
    status         TEXT NOT NULL DEFAULT 'open'  -- open | actioned | closed
);

-- 行动记录（Action 步骤：从诊断到执行）
CREATE TABLE IF NOT EXISTS actions (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at     TEXT NOT NULL DEFAULT (datetime('now')),
    diagnostic_id  INTEGER REFERENCES diagnostics(id),
    subject_type   TEXT NOT NULL,          -- product | campaign | keyword | store
    subject_id     TEXT,
    action_type    TEXT NOT NULL,          -- e.g. title_rewrite, price_adjust, keyword_add, bid_change
    description     TEXT NOT NULL,
    expected_impact TEXT,
    status          TEXT NOT NULL DEFAULT 'planned'  -- planned | executed | validated | reverted
);

-- 验证结果（Validation 步骤）
CREATE TABLE IF NOT EXISTS validations (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    action_id      INTEGER NOT NULL REFERENCES actions(id),
    started_at     TEXT NOT NULL,
    ended_at       TEXT NOT NULL,
    metric         TEXT NOT NULL,          -- 验证指标（从配置注入）
    baseline_value REAL,
    after_value    REAL,
    delta          REAL,
    delta_pct      REAL,
    verdict        TEXT NOT NULL,          -- positive | neutral | negative | inconclusive
    note           TEXT
);

-- 学习沉淀（Learning 步骤：可复用的结论/模式）
CREATE TABLE IF NOT EXISTS learnings (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at     TEXT NOT NULL DEFAULT (datetime('now')),
    source         TEXT NOT NULL,          -- validation | diagnosis | user_feedback
    category       TEXT NOT NULL,          -- e.g. product, keyword, price, title
    conclusion     TEXT NOT NULL,
    evidence_ref   TEXT,                   -- 关联 diagnostics/validations id
    confidence     REAL NOT NULL DEFAULT 0.5,
    reusable       INTEGER NOT NULL DEFAULT 1
);

-- 同步日志（数据新鲜度审计）
CREATE TABLE IF NOT EXISTS sync_log (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at     TEXT NOT NULL DEFAULT (datetime('now')),
    finished_at    TEXT,
    source         TEXT NOT NULL,
    records        INTEGER DEFAULT 0,
    status         TEXT NOT NULL,          -- running | success | failed
    message        TEXT
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_pds_date ON product_daily_stats(stat_date);
CREATE INDEX IF NOT EXISTS idx_cds_date ON campaign_daily_stats(stat_date);
CREATE INDEX IF NOT EXISTS idx_kds_date ON keyword_daily_stats(stat_date);
CREATE INDEX IF NOT EXISTS idx_diag_period ON diagnostics(scope, period_start);
CREATE INDEX IF NOT EXISTS idx_actions_status ON actions(status);
CREATE INDEX IF NOT EXISTS idx_learn_cat ON learnings(category);
