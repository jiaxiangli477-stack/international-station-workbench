# -*- coding: utf-8 -*-
"""客户背调与资格评估 —— 专家视角（地区合规 + 公司核实 + MEDDIC/BANT + 跟进话术）

被 make_inquiry_report.py 引用。所有判断集中在这里，改文案只改本文件。
字段说明：
  grade   A 重点推进 / B 常规跟进 / C 低优先 / R 风险
  intent  核心诉求（一句话）
  bg      公网/平台背调结论
  region  所在市场的进口门槛（查证过的写具体，未查证的写通用判断）
  tag     平台标签解读
  risk    风险提示（可为空）
  action  建议动作
  meddic  M/E/D/D/I/C 六维 0-2 分（Metrics/Economic buyer/Decision criteria/Decision process/Identify pain/Champion）
  prob    拿单概率（基于 MEDDIC 与地区门槛综合估）
  talk    可直接复制的英文跟进话术（无则 None）
"""

REGION_PLAYBOOK = [
    ('美国', 'DSHEA + 21 CFR 111', '无需上市前审批，成分合规即可卖；但工厂要有 FDA 注册 + GMP。',
     '门槛最低、成交最快，是首选市场。注意 NDI（新膳食成分）通知与标签合规。'),
    ('欧盟（波兰/比利时/丹麦）', '2002/46/EC 食品补充剂指令',
     '成分按成员国通报，部分成分需 novel food 审批；标签各国语言。', '门槛中等，成分先自查再报价。'),
    ('哥伦比亚', 'INVIMA Registro Sanitario（Decree 3249/3863）',
     '必须有哥伦比亚**本地进口商持证**；GMP 需海牙认证 + 西语翻译；需自由销售证明；周期 6-12 个月。',
     '周期长、必须落地进口商 —— 先问对方有没有 INVIMA 资质，再谈打样。'),
    ('孟加拉', 'DGDA 注册（2023 药品与化妆品法）',
     '**孟加拉央行已禁止银行对未获 DGDA 批准的补充剂开信用证/电汇**（2026-04-29 通函）；'
     '注册还要求品牌名出现在参考国（美/欧/英/日等）的自由销售证明上。',
     '门槛最高：先确认买家有没有 DGDA 注册，否则连货款通道都没有。'),
    ('以色列', '卫生部 NFS；2025-2026「What\'s Good for Europe」改革',
     '符合欧盟标准可走**声明制**，周期从数月缩到数周；需本地代表 + 进口商注册证；希伯来语/阿拉伯语标签。',
     '如果配方按欧盟标准做，这是被低估的好市场。'),
    ('伊拉克/中东', '各国卫生部进口许可',
     '支付与清关不确定性高；建议全额预付或 Trade Assurance 全额托管。', '订单可做，收款先谈死。'),
    ('拉美（巴西/阿根廷）', 'ANVISA / ANMAT 注册',
     '成品需本地注册；肽类按药品管。', '周期长，先做样品单试水。'),
    ('印尼/马来西亚', 'BPOM / NPRA 注册', '需本地持证方注册，周期数月。', '可做，但先确认对方持证情况。'),
]

ANALYSIS = {
    # ================= A 级 =================
    'Ariyan Khan': dict(
        grade='A', intent='高活跃运动营养买家，主动打招呼求对接',
        bg='公网搜不到公司信息（个人账号风格）。**但平台行为数据很强**：90 天浏览 73 个产品、登录 68 天；'
           '运动营养类目点击 95 次、**与供应商沟通 58 次** —— 这是"长期在找代工资源"的典型特征，不是随便问问。',
        region='孟加拉：**DGDA 注册是硬门槛**，且孟加拉央行已禁止银行为未获 DGDA 批准的补充剂开 LC/电汇'
               '（2026-04-29 通函）。注册还要求品牌名出现在参考国（美/欧/英/日/韩等）的自由销售证明上。',
        tag='L2 + 90 天登录 68 天 = 高频活跃账号；类目沟通 58 次 = 已在多家比价。',
        risk='他只在 10-11 发了一句 "Hi"，我方隔 4 天才回 "Hello" —— 没有给出任何实质内容，'
             '以他 58 次询盘的习惯，极可能已经被别家接走了。',
        action='**今天优先追**，且要用"专业开场 + 两个筛选问题"补回信任。核心是先确认他的 DGDA 资质，'
               '再谈产品 —— 顺序反了会白忙。',
        meddic=dict(M=1, E=0, D=0, Dp=1, I=2, C=1), prob='25%',
        talk="""Hi Ariyan — thanks for reaching out, and apologies for the slow reply (we were closed for the National Day holiday).

I can see you're very active in sports nutrition, so let me skip the generic pitch.

We're an OEM/ODM manufacturer in Dongguan, certified NSF-GMP / FSSC 22000 / HACCP. We run protein, creatine, electrolytes, BCAA/EAA, pre-workout and energy stick packs.

Two quick questions so I can be useful instead of noisy:
1) Which products are you planning to launch in the next 3 months?
2) Do you already hold a DGDA import registration for dietary supplements? (We ask because Bangladesh Bank now requires DGDA approval before banks will open an LC for supplement imports, so it affects how we structure the order and payment.)

Send me your wish-list and I'll come back with MOQ, lead time and pricing for each item."""),

    'Mads Jehg': dict(
        grade='A', intent='在手订单 + 正在谈价（单条装 30 条/盒，含专利肌酸）',
        bg='平台 L3，90 天登录 32 天；**已是成交客户**，有实物订单在手。我方 10-12 已报 USD 4.70/unit'
           '（单条装、30 条/盒、含专利肌酸）。',
        region='丹麦/澳洲：欧盟框架 + 澳洲 TGA 均无需逐批审批，可正常出货。',
        tag='L3 + 有历史成交 + 直接议价 = 全场最高质量线索。',
        risk='**10-13 他问"这个价格适用于首单还是仅后续订单"，至今未回。** '
             '这是典型的"临门一脚"——他已经在点头，只差我方确认。压着不回就是自伤。',
        action='**最优先，今天就回。** 明确首单同价（给足面子 + 锁定订单），并顺势把数量/口味/交期/付款'
               '四个要素一次性问全，用 Trade Assurance 出 PI。',
        meddic=dict(M=2, E=2, D=2, Dp=2, I=2, C=2), prob='80%',
        talk="""Hi Mads — good question, and let me be straight with you.

The USD 4.70 per unit (single sachets, 30 sachets per unit, patented creatine included) applies to your FIRST order as well. I don't want you to feel penalised for placing the order now.

To lock it in I just need four things:
1) Total units for this order
2) Flavour(s)
3) Delivery address and preferred Incoterm (EXW / FOB / DDP)
4) Payment via Alibaba Trade Assurance, or another method you prefer

Send me those and I'll issue the PI the same day. Production runs 25-30 days after deposit."""),

    'Orland Mata': dict(
        grade='A', intent='既有订单客户，问发货 ETA',
        bg='平台 L2，90 天登录 32 天；涉及草本/益生菌品类。是有历史往来的客户。',
        region='美国：无上市前审批，正常出货。',
        tag='L2 + 订单在途 = 服务型问题，不是销售问题。',
        risk='**10-09 问 "What\'s the ETA for shipping?"，至今 6 天未回。** '
             '已有订单的客户被晾，是最容易造成差评/纠纷的一类疏忽。',
        action='**今天就回**：先道歉（假期），再给**具体发货日期**，并承诺"一有变动当天告知"。'
               '如果确实延期，主动给补偿方案（加急运费或赠品），不要等客户问第二次。',
        meddic=dict(M=2, E=1, D=1, Dp=2, I=2, C=2), prob='70%',
        talk="""Hi Orland — my apologies for the silence, we were closed for the National Day holiday (Oct 1-8) and I should have set an auto-reply.

Here is exactly where your order stands: [ORDER STATUS]
Estimated ship date: [DATE]. I'll send the tracking number the moment it leaves the factory, and if anything changes I'll tell you the same day rather than let you chase me.

Thanks for your patience — and if the timing is now a problem for your side, tell me and I'll look at expediting it."""),

    'Lucas Hoffman': dict(
        grade='A', intent='问能否加 BCAA 或 EAA（配方微调）',
        bg='平台 L2，90 天浏览 58 个产品；**主打类目就是运动营养** —— 与我方产品线高度对口。'
           '公网无公司信息。',
        region='美国：无上市前审批，BCAA/EAA 均为合规常规原料，可正常报价。',
        tag='L2 + 类目高度对口 + 问的是**具体配方** = 意向度高的信号。',
        risk='**10-10 提问，5 天无人回复。** 问"能不能加 BCAA/EAA"说明他已经进入配方阶段，'
             '这类问题最不该被晾。',
        action='**今天就回**：明确"可以"，给出添加量区间、成本增量、MOQ 与打样周期，'
               '并问清份数/剂量/目标市场，把一个技术问题变成一次报价。',
        meddic=dict(M=1, E=1, D=1, Dp=1, I=2, C=1), prob='45%',
        talk="""Hi Lucas — thanks for your patience, we were off for the National Day holiday.

Yes, we can add BCAAs or EAAs. Both are straightforward in powder and stick-pack formats:
- BCAA 2:1:1 or 4:1:1, 5-10 g per serving
- Full-spectrum EAA, 8-10 g per serving
They can be blended into your existing base or run as a standalone formula.

To quote properly, could you confirm:
1) Servings per container and total units for the first order
2) BCAA or EAA (or both), and the dosage per serving
3) Which market you're selling into — US or elsewhere?

Sample lead time is 7-10 days; bulk production 25-30 days after sample approval."""),

    # ================= R 级 =================
    'matthew ragnauth': dict(
        grade='R', intent='SALT & IRON（美）要求配方保密合作、NDA、全套资质、500/1000/2500 桶报价，并要求抵扣此前 200 美元样品费',
        bg='**公网查不到这家保健品公司**：`saltniron.com` 实际是美国华盛顿州 Edmonds 的一家**同名餐厅**，'
           '与保健品无关；用姓名 + 品牌名多次检索均无可核实的实体。'
           '平台数据更反常：L2，90 天**只浏览 6 个产品**、登录 72 天 —— 与"要 500-2500 桶代工"的体量严重不匹配。',
        region='美国：市场本身无门槛，所以这不是监管问题，是**主体真实性**问题。',
        tag='L2 + 90 天仅浏览 6 个产品 + 登录 72 天 = 登录勤但几乎不看货，'
            '结合"法律函件式"行文，更像在走文件流程而非真实采购。',
        risk='**高风险，五处红旗**：①信里明写 "separate from the closed dispute" —— 双方此前有**已结案纠纷**；'
             '②要求先看配方、并要求我方披露"具体签约主体 / 生产厂 / 所有会接触配方的第三方"；'
             '③要求把原 200 美元样品费转为**不可过期抵扣**；④全文法律函件口吻'
             '（"本消息不授权配方披露/收费工作/打样/付款"）；⑤公网无实体。',
        action='**按流程走，绝不抢单**：1) 一律 Alibaba Trade Assurance，拒绝任何线下收款；'
               '2) 签保密协议 + 收到打样费之前**不披露任何配方**；3) 200 美元抵扣先不承诺，'
               '交由法务/管理层决策；4) 要求对方提供**美国公司注册名 + 州注册号 + EIN/税号**，'
               '核验主体后再进入下一步；5) 所有承诺书面化并留存。',
        meddic=dict(M=2, E=2, D=2, Dp=2, I=1, C=1), prob='低（先核验主体）',
        talk="""Matthew — thank you for the detailed note, and for setting out your process so clearly.

To move forward properly, here is where we stand:

1) Counterparty verification. Before any commercial discussion we need to confirm the contracting entity. Please send the registered company name, state of incorporation, registration number and tax ID for SALT & IRON. We will run standard KYC on our side as well.

2) Confidentiality. We are glad to sign a mutual NDA. We will not disclose formulation details until the NDA is executed and the sample/R&D fee is settled. Our standard practice is a development sample in a plain pouch or stock jar first, and a fully assembled retail prototype only after the formula is agreed.

3) Commercial terms. All orders go through Alibaba Trade Assurance — this protects both sides and is a condition we do not waive. It also means the 500 / 1,000 / 2,500 tub pricing will be quoted as a graded schedule on the PI.

4) The USD 200 sample credit. I have passed this to our management for review. I am not able to confirm it yet — I would rather give you a clear yes or no than a soft promise.

5) Documents. We can share our facility licences (NSF-GMP / FSSC 22000 / HACCP), a representative finished-powder COA and our per-lot testing panel once the NDA is in place.

If you send the entity details, I will get the NDA drafted and sent over."""),

    'Ivan Dias': dict(
        grade='R', intent='巴西买家询问肽类原料（pt141 / nad+ / ss31 / KPV / 谷胱甘肽）',
        bg='平台 L2，90 天浏览 28 个产品、登录 10 天；主打类目"其他保健品"，无公司信息。',
        region='巴西归 ANVISA 管；且这几项成分在多数市场按**药品或研究用化学品**监管，不属于膳食补充剂范畴。',
        tag='L2 + 登录仅 10 天 + 一上来点名管制类肽 = 典型的"试供应能力"型询价。',
        risk='**合规红线**：PT-141（布美兰肽）是处方药成分；NAD+/SS-31/KPV 属医药或研究用肽。'
             '**不能以膳食补充剂名义代工供货**，一旦成交可能涉及进出口许可与法律责任。',
        action='我方已回复 "not available"，方向正确。**建议补一句业务边界并留存记录**，'
               '同时抛出合规替代方案（氨基酸/肌酸/蛋白类）看是否能转化 —— 既划清界线又不直接关单。',
        meddic=dict(M=0, E=1, D=0, Dp=0, I=1, C=0), prob='不建议承接',
        talk="""Hi Ivan — thanks for the list.

To be transparent with you: the items you named (PT-141, NAD+, SS-31, KPV, and injectable-grade glutathione) sit outside what we are licensed and equipped to supply. Those are regulated as pharmaceutical or research-grade substances, not dietary supplement ingredients, so we cannot manufacture or export them as food supplements. That is a compliance boundary for us, not a pricing issue.

What we can do as an OEM/ODM is dietary-supplement compliant formulas: creatine, amino acids (glutamine, BCAA/EAA), protein blends, collagen, electrolytes and energy stick packs.

If any of those fit what you're building in Brazil, tell me the product and target volume and I'll send MOQ and lead time."""),

    # ================= B 级 =================
    'javier argoty': dict(
        grade='B', intent='哥伦比亚客户要样品做测试（最多 30 份）',
        bg='**公网找到疑似对应实体**：Logistrade Group SA，哥伦比亚 Cali，B2Brazil 标注 **Unverified**，'
           '2024 年成立，自述"大众消费品制造与销售，承接学校供餐项目"，同时经营冷冻鸡腿、香蕉粉、藜麦粉'
           '等大宗食品 —— **不是保健品渠道**。另有同城 Logistrade Pacific Co SAS（食品批发，NIT 9015336148）。'
           '他给的收货地址是"Logistrade Group de Colombia，Cali"。',
        region='哥伦比亚：膳食补充剂必须持 **INVIMA Registro Sanitario**，且**必须由哥方本地进口商持证**；'
               'GMP 证书需海牙认证 + 西语翻译，另需自由销售证明；周期 6-12 个月，注册有效期 10 年。',
        tag='L2 + 90 天浏览 34 个产品、登录 16 天；类目就是运动营养，且关注"剂型/功能/蛋白克数"属性'
            '= 至少懂品类，不是纯外行。',
        risk='①主营是学校供餐与大宗食品，**补充剂不是他的主渠道**，样品单金额小；'
             '②公司 2024 年成立、平台未认证，**是否持有 INVIMA 资质未知**；'
             '③他要求"先做测试装"但没提注册，可能低估了哥伦比亚的合规成本。',
        action='样品可以给，但**顺序要摆正**：先收样品费 + 对方自清关（我方已报 USD 30/份、快递到付，方案合理）；'
               '同时问一句"你们是否已持有 INVIMA 注册或本地持证进口商" —— 这个问题能快速判断是真渠道还是试水。',
        meddic=dict(M=1, E=1, D=1, Dp=1, I=2, C=1), prob='35%',
        talk="""Hola Javier — gracias por la paciencia.

Podemos enviar muestras. Para avanzar necesitamos dos cosas:

1) La fórmula o el tipo de producto que quieres desarrollar (por ejemplo: proteína, creatina, electrolitos, pre-entreno). Con eso te confirmo la muestra exacta.
2) Confirmación de que ustedes se encargan del despacho de aduana en Colombia. La muestra se envía por mensajería, costo de muestra USD 30 por referencia.

Una pregunta importante para nosotros: ¿Logistrade Group ya cuenta con registro sanitario INVIMA, o trabajan con un importador local que lo tenga? En Colombia los suplementos dietarios requieren registro sanitario INVIMA emitido a nombre del importador local, y el trámite toma entre 6 y 12 meses. Prefiero aclararlo ahora para que no te sorprenda después.

Si me confirmas esos dos puntos, preparo la muestra esta semana."""),

    'Gisselle Rodriguez': dict(
        grade='B', intent='等我方给配方清单后再推进',
        bg='平台 **L3**，90 天浏览 **1107 个产品**、登录 82 天 —— 平台超高活跃账号，跨类目'
           '（玩具/草本/日化）大量比价。无公司信息。',
        region='美国：无上市前审批，门槛最低。',
        tag='L3 + 浏览 1107 个产品 + 跨类目 = 典型"多品类采购/贸易商"，不是垂直品牌方。'
            '这类客户价值在于**复购与品类扩张**，不在于单笔大小。',
        risk='需求宽泛、跨类目比价，成交周期长；我方 10-10 问"要做什么配方"后对方未回，'
             '可能是我方提问太开放、没给抓手。',
        action='**降低她的决策成本**：不要再问开放式问题，直接推 3 个现成配方样板（草本胶囊 / 复合维生素 / '
               '胶原饮品），每个附 MOQ 与打样周期，让她**选**而不是**想**。',
        meddic=dict(M=0, E=0, D=1, Dp=0, I=1, C=1), prob='20%',
        talk="""Hi Gisselle — instead of asking you to spec something from scratch, here are three formulas we currently run that match the categories you've been looking at:

1) Herbal capsule line (ashwagandha / valerian / milk thistle blends) — MOQ 3,000 units, sample 7-10 days
2) Multivitamin & mineral tablets or capsules — MOQ 5,000 units, sample 7-10 days
3) Collagen beauty drink or stick pack — MOQ 5,000 units, sample 10-14 days

Tell me which one is closest to what you have in mind (or send the category you'd like) and I'll send the full formulation brief, EXW pricing and packaging options. If you're sourcing across several categories, I can also put it into one graded quote so you can compare."""),

    'Muhammad Aizat': dict(
        grade='B', intent='催进展（"Any update"）',
        bg='平台 **L3**，90 天登录 70 天，高度活跃；类目偏运动服饰，但也有运动营养沟通记录。',
        region='马来西亚：补充剂需 NPRA（国家药品管理局）注册，需本地持证方，周期数月。',
        tag='L3 + 登录 70 天 = 高频活跃，值得认真对待。',
        risk='我方 10-15 才回复（隔 5 天，理由"刚过完假期"），**买家体验已受损**，'
             '他连发 "Heyy / Any update" 说明真的在等。',
        action='**24 小时内必须给实质内容**（不是寒暄）。先给产品方案与报价，再问 NPRA 持证情况。'
               '如果只继续寒暄，这单基本就丢了。',
        meddic=dict(M=0, E=1, D=0, Dp=1, I=1, C=1), prob='25%',
        talk="""Hi Aizat — sorry for the delay, we were closed for the National Day holiday and I should have replied before we went off.

Here's something concrete rather than another "hello". We run these categories as an OEM/ODM (NSF-GMP / FSSC 22000 / HACCP):
- Protein and creatine powders
- Electrolyte and energy stick packs
- BCAA / EAA / pre-workout

Tell me which one you need and the target volume, and I'll send MOQ, EXW pricing and sample lead time within 24 hours.

One thing worth checking early: do you already have NPRA registration in Malaysia, or a local licence holder you work with? It affects the timeline, so I'd rather plan for it now."""),

    'isaaq Derray': dict(
        grade='B', intent='通过询盘卡问 Pre Workout Powder（产品 ID 1601621467210）',
        bg='平台 L1，90 天浏览 131 个产品、登录 28 天；类目含运动营养与清洁设备。',
        region='埃塞俄比亚：进口许可 + 外汇管制，付款与清关不确定性较高。',
        tag='L1 = 平台尚未积累足够行为数据，需通过沟通判断。',
        risk='我方 10-13 只打了招呼，没给任何实质信息；对方发的是**平台询盘卡**（带明确产品 ID），'
             '说明他已经锁定具体产品。',
        action='**直接针对他问的那款产品**给方案：配方方向、MOQ、打样周期与报价。'
               '既省时间又显得专业。付款方式建议 Trade Assurance 全额。',
        meddic=dict(M=1, E=0, D=0, Dp=0, I=2, C=0), prob='20%',
        talk="""Hi Isaaq — thanks for the enquiry on our Pre Workout Powder (item 1601621467210).

Rather than a generic hello, here's what you need to decide:

We produce it as an OEM/ODM item, so we can match your formula. Typical build: beta-alanine, citrulline malate, caffeine (or caffeine-free), taurine, B-vitamins — sugar-free, in powder or stick packs.
- MOQ: 3,000 units (or 500 kg bulk)
- Sample: 7-10 days
- Bulk lead time: 25-30 days after sample approval

Two questions:
1) Do you want it under your own brand, or matching our existing formulation?
2) Which market are you selling into? For Ethiopia I'd also recommend we run the order through Alibaba Trade Assurance so both sides are protected on payment and delivery."""),

    # ================= C 级 =================
    'melwyn rojas': dict(
        grade='B', intent='确认我们是否在广州/中国',
        bg='平台 L2，印度尼西亚（ID）账号。',
        region='印尼：需 BPOM 注册，本地持证方办理。',
        tag='L2；问位置 = 早期筛选动作，属"比价前置"。',
        risk='**10-08 提问，7 天无人回复。** 这类"确认供应商位置"的问题，答慢一步客户就流向下一家。',
        action='**补回**：说明我方在**东莞**（不是广州，别答错），距离广州机场约 1 小时，'
               '附工厂资质，并顺势问需求。',
        meddic=dict(M=0, E=0, D=0, Dp=0, I=1, C=0), prob='15%',
        talk="""Hi Melwyn — sorry for the slow reply, we were closed for the National Day holiday.

We're based in Dongguan, Guangdong — about one hour from Guangzhou airport and 40 minutes from Shenzhen. We're a factory, not a trading company: NSF-GMP / FSSC 22000 / HACCP certified, and we've been doing OEM/ODM supplements since 2013.

What are you looking to produce? Send me the product type and target quantity and I'll come back with MOQ, lead time and pricing."""),

    'Mustafa Bzeih': dict(
        grade='B', intent='沟通包装规格（"inside the box 14"）',
        bg='平台 L2，美区。',
        region='美国：无上市前审批。',
        tag='L2；消息被截断，语境缺失。',
        risk='**10-08 之后无下文，7 天未回。** 对话停在半句上，等于话题断了。',
        action='**补回并把话题接完整**：先确认"每盒 14 条"的理解，再直接给对应包装方案与价格区间，'
               '避免又是一轮空洞确认。',
        meddic=dict(M=1, E=0, D=1, Dp=0, I=1, C=0), prob='20%',
        talk="""Hi Mustafa — apologies for the delay, we were off for the National Day holiday.

Let me pick up where we left off: to confirm, you meant 14 sticks inside each box — correct?

If so, that's workable, and it's a common retail format for us. Two things I need to quote:
1) Serving size per stick (e.g. 5 g or 10 g)
2) Number of boxes for the first order

Send those and I'll come back with the EXW price, packaging options and lead time."""),

    'Ismatou diallo': dict(
        grade='C', intent='法语客户想买 5 盒成品',
        bg='平台 L1，90 天浏览 478 个产品但登录仅 13 天；类目偏假发/胶原/个人护理。'
           '**浏览多但登录少** = 广撒网型比价，不是定向采购。',
        region='比利时：欧盟框架，需按成员国通报。',
        tag='L1 + 登录 13 天 + 浏览 478 个 = 低质量流量特征。',
        risk='想买**现货成品 5 盒**，而我们是 OEM/ODM 定制为主，模式不匹配；我方已答"没现货"，'
             '但没有给出替代路径。',
        action='给一句有转化可能的回话：说明我们是代工厂、最低起订量是多少，'
               '问他在比利时是否有零售渠道。如果没有，礼貌结束，不必再追。',
        meddic=dict(M=1, E=0, D=0, Dp=0, I=1, C=0), prob='5%',
        talk="""Bonjour Ismatou — merci de votre message.

Nous sommes une usine de fabrication (OEM/ODM), pas un revendeur : nous ne vendons pas 5 boîtes de produits finis en stock. Notre production se fait sur commande, avec un minimum de commande de 3 000 unités par référence.

Si vous avez un projet de marque pour la Belgique et cherchez un fabricant, je serais ravi d'en discuter : envoyez-moi le type de produit et le volume envisagé et je vous enverrai le MOQ et les délais."""),

    'Wisam Alfaisal': dict(
        grade='C', intent='伊拉克 L3 买家，要 1000 个瓶子但只说"只要盖子"',
        bg='平台 **L3**，90 天浏览 562 个产品、登录 77 天；主打类目偏时尚饰品。',
        region='伊拉克：进口许可 + 付款风险，建议 Trade Assurance 全额。',
        tag='L3 + 562 个产品浏览 = 活跃但品类发散；饰品类目与保健品无关。',
        risk='需求与我们产线不匹配（我方做配方代工，不做包材）。我方已婉拒，处理得当。',
        action='保留线索，不要硬推。留一句"如需代工配方欢迎联系"，转入低频培育即可。',
        meddic=dict(M=1, E=1, D=0, Dp=1, I=0, C=0), prob='5%',
        talk=None),

    'n edwards': dict(
        grade='C', intent='确认我们位置',
        bg='平台 L2，90 天浏览 427 个产品、登录 41 天；类目偏美妆个护。',
        region='美国：无上市前审批。',
        tag='L2 + 浏览多但类目不对口（美妆个护）。',
        risk='品类不对口，暂无进展。',
        action='发一次公司资质 + 品类清单，之后转低频。',
        meddic=dict(M=0, E=0, D=0, Dp=0, I=1, C=0), prob='10%',
        talk=None),

    'dbyr bnhmw': dict(
        grade='C', intent='发了两张卡片，我方问样品份数后无回应',
        bg='平台 L2，90 天浏览 116 个产品；**主打类目是智能手环（消费电子）**，非保健品。',
        region='以色列：符合欧盟标准可走声明制；但需本地代表 + 进口商注册证。',
        tag='L2 + 主打类目是消费电子 = 大概率误触，不是目标客户。',
        risk='画像与业务不匹配，且对方发的卡片内容未展开。',
        action='**在卡片失效前催一次**问清品类；如仍是电子产品，直接归档。',
        meddic=dict(M=0, E=0, D=0, Dp=0, I=0, C=0), prob='5%',
        talk=None),

    'Elie Bouyounes': dict(
        grade='C', intent='仅我方发出 Trade Assurance 卡片，买家全程未说话',
        bg='平台 L1，90 天登录 8 天；关注"胶原贴片"类产品。',
        region='阿根廷：ANMAT 注册，周期长。',
        tag='L1 + 登录 8 天 + 零回复 = 单向触达，线索未激活。',
        risk='买家未回应任何消息。',
        action='针对他浏览过的**胶原类产品**发一条个性化消息激活；无回应即归档。',
        meddic=dict(M=0, E=0, D=0, Dp=0, I=1, C=0), prob='5%',
        talk="""Hi Elie — I noticed you were looking at our collagen products.

We make collagen in several formats: stick packs, powder, gummies and patches — OEM/ODM, so the formula and packaging carry your brand. NSF-GMP / FSSC 22000 / HACCP certified.

If you're sourcing for Argentina, tell me which format interests you and the volume you have in mind, and I'll send MOQ and pricing."""),

    'Malwa Zieba': dict(
        grade='C', intent='仅我方发出 TA 卡片，买家未回应',
        bg='平台 L2，90 天浏览 113 个产品、登录 51 天；关注运动营养，'
           '**成分偏好 Vit C / 锌 / 铜 / MSM / 硅**。',
        region='波兰：欧盟框架。',
        tag='L2 + 有明确成分偏好 = 至少知道自己在找什么，值得一次精准触达。',
        risk='买家未回应。',
        action='**按成分偏好定制一条消息**：推"MSM + 维 C + 锌"的关节/美容类配方，'
               '比泛泛问候有效得多。',
        meddic=dict(M=0, E=0, D=1, Dp=0, I=1, C=0), prob='10%',
        talk="""Hi Malwa — your recent browsing shows you looking at formulas built around vitamin C, zinc, MSM and silicon, so let me be specific.

We run a joint & beauty formula along those lines: MSM 1000 mg, vitamin C 80 mg, zinc 10 mg, copper and silicon — capsule or stick pack, under your own brand. MOQ 3,000 units, sample 7-10 days.

If that's close to what you need, tell me the format and volume and I'll send the full spec and pricing."""),
}
