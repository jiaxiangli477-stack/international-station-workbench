# -*- coding: utf-8 -*-
"""RFQ 报价历史 + 详情 → inquiry/rfq_leads.json
RFQ 详情里的 companyInfo 是我们能拿到的、最接近「买家公司档案」的平台字段。
"""
import io
import json
import os
import subprocess
import sys
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

HERE = os.path.dirname(os.path.abspath(__file__))
os.environ['PATH'] = os.path.join(HERE, 'bin') + os.pathsep + os.environ.get('PATH', '')
os.chdir(HERE)

OUT = os.path.join(HERE, 'inquiry')


def call(args, timeout=300):
    r = subprocess.run(args, capture_output=True, text=True, encoding='utf-8',
                       errors='replace', shell=True, timeout=timeout)
    o = (r.stdout or '') + (r.stderr or '')
    i = o.find('{')
    if i < 0:
        return None
    try:
        env = json.loads(o[i:])
    except Exception:
        return None
    d = env.get('data', env)
    if isinstance(d, str):
        try:
            d = json.loads(d)
        except Exception:
            return None
    return d


def main():
    days = int(sys.argv[sys.argv.index('--days') + 1]) if '--days' in sys.argv else 7
    now = int(time.time() * 1000)
    frm = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime((now - days * 86400000) / 1000))
    to = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(now / 1000))
    print('RFQ 窗口: %s ~ %s' % (frm, to))

    quotes = []
    for page in range(1, 6):
        d = call(['workctl', 'icbu', 'rfq', 'rfq-quote-history-search', '--format', 'json',
                  '--pageSize', '20', '--currentPage', str(page), '--documentaryStatus', 'all',
                  '--gmtCreateFrom', frm, '--gmtCreateTo', to])
        if not d:
            break
        lst = d.get('list') or []
        quotes += lst
        print('  第 %d 页 %d 条' % (page, len(lst)))
        if len(lst) < 20:
            break
        time.sleep(0.4)

    # 去重
    seen = {}
    for q in quotes:
        seen[str(q.get('quoteId'))] = q
    quotes = list(seen.values())
    print('报价合计 %d 条（去重后）' % len(quotes))

    # 详情（含 companyInfo）
    leads = []
    for q in quotes[:20]:
        rid = q.get('rfqId')
        det = None
        if rid:
            d = call(['workctl', 'icbu', 'rfq', 'rfq-detail-search', '--format', 'json',
                      '--rfq-id', str(rid)])
            items = (d or {}).get('items') or []
            det = items[0] if items else None
            time.sleep(0.3)
        ci = (det or {}).get('companyInfo') or {}
        bb = (det or {}).get('buyerBehaviorInfo') or {}
        pi = (det or {}).get('purchaseInfo') or {}
        leads.append({
            'quoteId': q.get('quoteId'), 'rfqId': rid,
            'buyerName': (det or {}).get('buyerName') or q.get('buyerName'),
            'country': q.get('buyerCountry') or (det or {}).get('countryCode'),
            'countryName': (det or {}).get('countryName'),
            'buyerLevel': q.get('buyerLevel'),
            'tags': [t for t in ((det or {}).get('buyerTags') or []) if t],
            'company': ci,
            'behavior': bb,
            'purchase': {'businessType': pi.get('businessType'),
                         'categories': (pi.get('frequentPurchaseCategories') or [])[:8],
                         'industry': pi.get('industry'), 'mainProducts': pi.get('mainProducts'),
                         'annualPurchaseAmount': ci.get('annualPurchaseAmount'),
                         'purchaseFrequency': ci.get('purchaseFrequency')},
            'rfqTitle': q.get('rfqTitle'), 'rfqDetail': (det or {}).get('detail'),
            'quoteStatus': q.get('documentaryStatus'), 'quoteTime': q.get('quoteCreateTime'),
            'account': q.get('loginId'),
        })

    p = os.path.join(OUT, 'rfq_leads.json')
    with open(p, 'w', encoding='utf-8') as f:
        json.dump({'window': {'from': frm, 'to': to}, 'count': len(quotes), 'leads': leads},
                  f, ensure_ascii=False, indent=1)

    print()
    print('=== RFQ 线索（前 20）===')
    for L in leads:
        c = L['company'] or {}
        nm = c.get('companyName') or '未披露'
        print('  %-18s %-4s L%-2s %-6s 公司=%-28s 年采购=%s 品类=%s' % (
            (L['buyerName'] or '')[:18], L['country'] or '-', L['buyerLevel'] or '-',
            (L['quoteStatus'] or '')[:6], nm[:28], c.get('annualPurchaseAmount'),
            (L['purchase']['categories'] or ['-'])[0][:22]))
    print()
    print('有公司名的:', sum(1 for L in leads if (L['company'] or {}).get('companyName') not in (None, '', 'NA')))
    print('写入:', p)


if __name__ == '__main__':
    main()
