from pathlib import Path
import re
def export_single(directory,output=None):
    root=Path(directory);html=(root/'index.html').read_text('utf-8-sig')
    css=(root/'styles.css').read_text('utf-8-sig')
    html=re.sub(r'<link[^>]+href="styles\.css[^\"]*"[^>]*>',lambda m:'<style>'+css+'</style>',html)
    for filename in ('chart.umd.min.js','dashboard_data.js'):
        js=(root/filename).read_text('utf-8-sig').replace('</script','<\\/script')
        html=re.sub(r'<script src="'+re.escape(filename)+r'[^\"]*"></script>',lambda m:'<script>'+js+'</script>',html)
    # This export uses the existing plaintext data; remove the asynchronous asset loader.
    html=re.sub(r'<script>\s*\(function\(\)\{[\s\S]*?</script>','',html,count=1)
    app=(root/'app.js').read_text('utf-8-sig').replace('</script','<\\/script')
    html,n=re.subn(r'</body>(\s*</html>\s*)$' ,lambda m:'<script>'+app+'</script>\n</body>'+m.group(1),html,flags=re.I)
    if n!=1: raise ValueError('HTML缺少完整文档尾部，停止导出')
    html=html.replace('<button class="btn">改密码</button>','').replace('<button class="btn">退出</button>','')
    output=Path(output) if output else root.parent/'经营数据面板.html'
    output.write_text(html,encoding='utf-8');return output
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('directory');p.add_argument('--output');a=p.parse_args();print(export_single(a.directory,a.output))

