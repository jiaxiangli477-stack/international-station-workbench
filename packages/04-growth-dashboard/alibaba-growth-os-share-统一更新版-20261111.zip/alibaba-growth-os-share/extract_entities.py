# -*- coding: utf-8 -*-
"""主体实体抽取（离线，不联网）—— 从询盘/TM 聊天原文与平台字段里抠出可核验的客户主体线索。

输出 `inquiry/entities.json`，供 verify_companies.py 做公网核验、供报告做「客户信息」评分。

抽什么：
  country   国家（**contactLoginId 前两位就是 ISO 国家码**，实测 254/254 全覆盖；persona 国家作对照）
  companies 公司名（严格法律后缀 + 自我介绍句式）
  domains   自有域名（剔除阿里站内域与免费邮箱域）
  emails    邮箱
  phones    电话（带国际区号推断）
  addresses 地址片段
  brands    品牌名（引号内 / 全大写词）
  signals   命中的线索类型汇总

只做「抽取 + 打标」，**不做任何判定** —— 判定留给 verify_companies.py，
避免把「聊天里提过」当成「已核实」。
"""

import collections
import io
import json
import os
import re
import sys
from collections import OrderedDict

HERE = os.path.dirname(os.path.abspath(__file__))
INQ = os.path.join(HERE, 'inquiry')

# ---------------------------------------------------------------- 国家码
ISO2 = {
    'ad': '安道尔', 'ae': '阿联酋', 'af': '阿富汗', 'ag': '安提瓜和巴布达', 'al': '阿尔巴尼亚',
    'am': '亚美尼亚', 'ao': '安哥拉', 'ar': '阿根廷', 'at': '奥地利', 'au': '澳大利亚',
    'az': '阿塞拜疆', 'ba': '波黑', 'bb': '巴巴多斯', 'bd': '孟加拉国', 'be': '比利时',
    'bf': '布基纳法索', 'bg': '保加利亚', 'bh': '巴林', 'bi': '布隆迪', 'bj': '贝宁',
    'bn': '文莱', 'bo': '玻利维亚', 'br': '巴西', 'bs': '巴哈马', 'bt': '不丹',
    'bw': '博茨瓦纳', 'by': '白俄罗斯', 'bz': '伯利兹', 'ca': '加拿大', 'cd': '刚果(金)',
    'cf': '中非', 'cg': '刚果(布)', 'ch': '瑞士', 'ci': '科特迪瓦', 'cl': '智利',
    'cm': '喀麦隆', 'cn': '中国', 'co': '哥伦比亚', 'cr': '哥斯达黎加', 'cu': '古巴',
    'cv': '佛得角', 'cy': '塞浦路斯', 'cz': '捷克', 'de': '德国', 'dj': '吉布提',
    'dk': '丹麦', 'dm': '多米尼克', 'do': '多米尼加', 'dz': '阿尔及利亚', 'ec': '厄瓜多尔',
    'ee': '爱沙尼亚', 'eg': '埃及', 'er': '厄立特里亚', 'es': '西班牙', 'et': '埃塞俄比亚',
    'fi': '芬兰', 'fj': '斐济', 'fr': '法国', 'ga': '加蓬', 'gb': '英国', 'gd': '格林纳达',
    'ge': '格鲁吉亚', 'gh': '加纳', 'gm': '冈比亚', 'gn': '几内亚', 'gr': '希腊',
    'gt': '危地马拉', 'gy': '圭亚那', 'hn': '洪都拉斯', 'hr': '克罗地亚', 'ht': '海地',
    'hu': '匈牙利', 'id': '印尼', 'ie': '爱尔兰', 'il': '以色列', 'in': '印度',
    'iq': '伊拉克', 'ir': '伊朗', 'is': '冰岛', 'it': '意大利', 'jm': '牙买加',
    'jo': '约旦', 'jp': '日本', 'ke': '肯尼亚', 'kg': '吉尔吉斯斯坦', 'kh': '柬埔寨',
    'km': '科摩罗', 'kr': '韩国', 'kw': '科威特', 'kz': '哈萨克斯坦', 'la': '老挝',
    'lb': '黎巴嫩', 'lc': '圣卢西亚', 'lk': '斯里兰卡', 'lr': '利比里亚', 'ls': '莱索托',
    'lt': '立陶宛', 'lu': '卢森堡', 'lv': '拉脱维亚', 'ly': '利比亚', 'ma': '摩洛哥',
    'md': '摩尔多瓦', 'me': '黑山', 'mg': '马达加斯加', 'mk': '北马其顿', 'ml': '马里',
    'mm': '缅甸', 'mn': '蒙古', 'mr': '毛里塔尼亚', 'mt': '马耳他', 'mu': '毛里求斯',
    'mv': '马尔代夫', 'mw': '马拉维', 'mx': '墨西哥', 'my': '马来西亚', 'mz': '莫桑比克',
    'na': '纳米比亚', 'ne': '尼日尔', 'ng': '尼日利亚', 'ni': '尼加拉瓜', 'nl': '荷兰',
    'no': '挪威', 'np': '尼泊尔', 'nz': '新西兰', 'om': '阿曼', 'pa': '巴拿马',
    'pe': '秘鲁', 'pg': '巴新', 'ph': '菲律宾', 'pk': '巴基斯坦', 'pl': '波兰',
    'ps': '巴勒斯坦', 'pt': '葡萄牙', 'py': '巴拉圭', 'qa': '卡塔尔', 'ro': '罗马尼亚',
    'rs': '塞尔维亚', 'ru': '俄罗斯', 'rw': '卢旺达', 'sa': '沙特', 'sb': '所罗门群岛',
    'sc': '塞舌尔', 'sd': '苏丹', 'se': '瑞典', 'sg': '新加坡', 'si': '斯洛文尼亚',
    'sk': '斯洛伐克', 'sl': '塞拉利昂', 'sm': '圣马力诺', 'sn': '塞内加尔', 'so': '索马里',
    'sr': '苏里南', 'sv': '萨尔瓦多', 'sy': '叙利亚', 'sz': '斯威士兰', 'td': '乍得',
    'tg': '多哥', 'th': '泰国', 'tj': '塔吉克斯坦', 'tl': '东帝汶', 'tm': '土库曼斯坦',
    'tn': '突尼斯', 'to': '汤加', 'tr': '土耳其', 'tt': '特立尼达', 'tw': '中国台湾',
    'tz': '坦桑尼亚', 'ua': '乌克兰', 'ug': '乌干达', 'uk': '英国', 'us': '美国',
    'uy': '乌拉圭', 'uz': '乌兹别克斯坦', 've': '委内瑞拉', 'vn': '越南', 'ye': '也门',
    'za': '南非', 'zm': '赞比亚', 'zw': '津巴布韦',
}

# 我方可识别身份 —— 命中即剔除，避免把「我们自己的公司名」当成客户主体
SELF_WORDS = ('lifeworth', '深证', '深圳', 'shenzhen lifeworth')

FREE_MAIL = ('gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'qq.com', '163.com',
             '126.com', 'icloud.com', 'protonmail.com', 'proton.me', 'live.com', 'aol.com',
             'mail.com', 'yandex.com', 'gmx.com', 'web.de', 'rediffmail.com', 'foxmail.com',
             'msn.com', 'me.com', 'googlemail.com', 'zoho.com', 'naver.com', 'hanmail.net',
             'daum.net', 'tutanota.com', 'yandex.ru', 'mail.ru', 'internet.ru', 'list.ru',
             'bk.ru', 'inbox.ru', 'sina.com', 'sohu.com', 'yeah.net', '21cn.com', 'tom.com',
             'docs.google.com', 'drive.google.com', 'sheets.google.com', 'translate.google.com',
             'sites.google.com', 'google.com', 'privaterelay.appleid.com', 'appleid.com')

# 免费邮箱品牌名（含各国后缀变体）：yahoo.fr / live.com.au / hotmail.es … 一律不算"客户自有域名"
FREE_LABELS = ('yahoo', 'hotmail', 'outlook', 'live', 'gmail', 'googlemail', 'aol', 'proton',
               'yandex', 'gmx', 'mail', 'msn', 'icloud', 'rediffmail', 'zoho', 'tutanota',
               'naver', 'hanmail', 'daum', 'web', 'sina', 'sohu', 'foxmail', 'docs',
               'privaterelay', 'drive', 'sheets', 'translate', 'sites')

# 平台/社交/建站/商城等噪声域 —— 不是客户主体，别拿去 RDAP 核验
NOISE_DOM = ('facebook.com', 'instagram.com', 'tiktok.com', 'linkedin.com', 'youtube.com',
             'youtu.be', 'wa.me', 't.me', 'pinterest.com', 'twitter.com', 'x.com',
             'snapchat.com', 'threads.net', 'wixsite.com', 'blogspot.com', 'wordpress.com',
             'godaddysites.com', 'shopify.com', 'myshopify.com', 'canva.com', 'weebly.com',
             'squarespace.com', 'sedo.com', 'afternic.com', 'dan.com', 'amazon.com',
             'ebay.com', 'etsy.com', 'wikipedia.org', 'googleusercontent.com',
             'gstatic.com', 'cloudflare.com', 'wix.com', 'mystrikingly.com', 'webnode.page',
             'linkedin.cn', 'alibaba.com', 'aliexpress.com', '1688.com')

ALIBABA_DOM = ('alibaba.com', 'aliexpress.com', '1688.com', 'alibabacloud.com')


def is_junk_domain(d):
    """是不是「不该当客户自有主体去核验」的域名。

    三类要拦：① 免费邮箱域（含各国后缀变体，如 yahoo.fr / live.com.au）；
    ② 平台/社交/建站/商城噪声域；③ 「com.my」「co.uk」这种被正则切出来的后缀碎片。
    实测这批数据里 docs.google.com / privaterelay.appleid.com / yahoo.fr / com.my 都被当成
    客户域名去查过 RDAP，报告里会出现「docs.google.com 未注册」这种明显错误的结论。
    """
    d = (d or '').lower().strip()
    if not d or '.' not in d:
        return True
    if d in NOISE_DOM or d in FREE_MAIL:
        return True
    if any(d.endswith('.' + a) for a in ALIBABA_DOM):
        return True
    parts = d.split('.')
    if len(parts) < 2:
        return True
    # 只有两段，且第一段是二级后缀碎片 → com.my / co.uk / com.au …
    if len(parts) == 2 and parts[0] in ('com', 'co', 'net', 'org', 'gov', 'edu', 'ac', 'or', 'ne'):
        return True
    # 免费邮箱品牌（含 .com.br / .co.uk 这类三段形式）
    if parts[0] in FREE_LABELS:
        return True
    if len(parts) >= 3 and parts[-2] in ('com', 'co', 'net', 'org', 'in') and parts[-3] in FREE_LABELS:
        return True
    return False

# 严格法律后缀（不含 Nutrition / Group / Trading / Company 这类行业或通用词，
# 否则会把产品名和 "Company Name" 这种短语当公司名 —— 第一版就踩了这个坑）
LEGAL_SUFFIX = (r'S\.A\.S|S\.A|SAS|S\.L|S\.R\.L|SRL|S\.p\.A|SpA|GmbH\s*&\s*Co\.?\s*KG|GmbH|AG|'
                r'L\.L\.C|LLC|Ltd\.?|Limited|Inc\.?|Incorporated|Corp\.?|Corporation|Pty\.?\s*Ltd|'
                r'SDN\.?\s*BHD|B\.?V\.?|N\.?V\.?|A/S|ApS|Oy|OÜ|Pte\.?\s*Ltd|Co\.?,?\s*Ltd|'
                r'Kft|D\.O\.O|d\.o\.o|SIA|UAB|TOO|LLP|Zrt|K\.K')

CO_RE = re.compile(r'\b((?:[A-Z][\w&\.\'\-]*)(?:\s+(?:[A-Z][\w&\.\'\-]*|of|and|&)){0,4}\s+'
                   r'(?:' + LEGAL_SUFFIX + r'))\.?')
INTRO_RE = re.compile(
    r'(?:my\s+company(?:\s+name)?\s*(?:is|:)\s*|our\s+company(?:\s+name)?\s*(?:is|:)\s*|'
    r'company\s*name\s*[:\-]\s*|we\s+are\s+(?:called\s+)?|i\s+am\s+from\s+|i\'m\s+from\s+|'
    r'(?:我(?:们)?(?:的)?公司(?:叫|名称|是|：|:)\s*))'
    r'([A-Z][A-Za-z&\.\'\-]*(?:\s+[A-Z][A-Za-z&\.\'\-]*){0,4})')
ADDR_RE = re.compile(r'[^\n]{0,70}(?:calle|torre|galp[oó]n|avenida|carretera|carrera|callejón|'
                     r'street|road\b|avenue|floor|suite|building|bldg|plaza|block|sector|'
                     r'box\s*\d+|km\s*\d+)[^\n]{0,70}', re.I)
TEL_RE = re.compile(r'\+?\d[\d \-()\.]{7,18}\d')
DATE_RE = re.compile(r'^\d{1,2}[./\-]\d{1,2}[./\-]\d{2,4}$')
DASHQTY_RE = re.compile(r'^\d{1,4}-\d{1,4}-\d{1,4}$')   # 150-150-200 这种是规格不是电话
QTY_NEAR = ('moq', 'quantity', 'qty', 'price', 'usd', 'kg', 'pcs', 'units', 'pieces', 'boxes',
            'bottles', 'servings', 'days', 'weeks', 'months', 'discount', 'cost', 'per unit')
DOM_RE = re.compile(r'(?<![\w@])((?:[a-z0-9](?:[a-z0-9\-]{0,61}[a-z0-9])?\.)+'
                    r'(?:com|net|org|io|co|biz|info|store|shop|health|fit|ltd|llc|group|'
                    r'br|mx|de|fr|uk|es|it|nl|be|at|ch|se|no|dk|fi|ie|pt|gr|pl|cz|sk|hu|ro|'
                    r'bg|hr|si|lt|lv|ee|ua|ru|kz|by|az|ge|am|il|tr|jo|kw|qa|bh|om|lb|'
                    r'in|pk|bd|lk|np|my|sg|th|vn|id|ph|kr|jp|tw|hk|cn|au|nz|'
                    r'za|ng|ke|gh|eg|ma|tn|dz|et|tz|ug|cm|ci|sn|'
                    r'ar|cl|pe|co|ec|ve|py|uy|bo|cr|pa|gt|do))(?![a-z0-9])', re.I)
BRAND_RE = re.compile(r'["“”\']([A-Z][A-Za-z0-9&\'\- ]{2,28})["“”\']|«([A-Za-z0-9&\'\- ]{2,28})»')
SOCIAL_RE = re.compile(r'(?:instagram\.com|instagr\.am|facebook\.com|fb\.me|tiktok\.com|'
                       r'linkedin\.com|youtube\.com|youtu\.be|x\.com|twitter\.com|'
                       r'wa\.me|t\.me|pinterest\.com|snapchat\.com|threads\.net)'
                       r'/[^\s,;)\]"\'<>]{2,60}', re.I)
AT_HANDLE_RE = re.compile(r'(?<![\w.@])@([A-Za-z][A-Za-z0-9._]{2,28})\b')
# 免费邮箱域 = 个人邮箱；其余 = 企业邮箱（企业域本身可做 RDAP/官网核验）
BRAND_INTRO_RE = re.compile(
    r'(?:(?:our|my|the)\s+(?:brand|label)(?:\s+name)?\s*(?:is|:)\s*|'
    r'(?:brand|label)\s*(?:name)?\s*[:\-]\s*|'
    r'we\s+(?:sell|market|distribute)\s+(?:it\s+)?(?:under\s+)?(?:the\s+)?(?:name|brand)\s+)'
    r'([A-Z][A-Za-z0-9&\'\-]*(?:\s+[A-Z][A-Za-z0-9&\'\-]*){0,3})')
PRODUCT_HINT = ('supplement', 'powder', 'capsule', 'gummy', 'gummies', 'tablet', 'sachet',
                'collagen', 'whey', 'creatine', 'pre workout', 'pre-workout', 'bcaa', 'eaa',
                'electrolyte', 'vitamin', 'protein', 'coffee', 'softgel', 'liquid', 'jelly',
                'glutathione', 'probiotic', 'omega', 'fiber', 'mushroom', 'gummies', 'stick',
                'drink', 'shake', 'bar ', 'flavor', 'flavour', 'formula', 'private label')
# 认证 / 成分 / 贸易 / 物流词 —— 出现在「公司名」或「品牌」位就是误命中
NOISE_TOKENS = ('gmp', 'iso', 'haccp', 'coa', 'msds', 'fda', 'ddp', 'cif', 'fob', 'exw', 'moq',
                'oem', 'odm', 'sku', 'asap', 'nad', 'pqq', 'gpc', 'cdp', 'pump', 'dhl', 'fedex',
                'tnt', 'ups', 'ems', 'tt', 'lc', 'pi', 'ok', 'hi', 'hello', 'thanks', 'dear',
                'yes', 'no', 'sir', 'madam', 'tel', 'order', 'product', 'price', 'sample',
                'china', 'usa', 'uk', 'eu', 'fy', 'qty', 'usd', 'eur', 'sgs', 'tuv', 'bpa',
                'hala', 'kosher', 'non-gmo', 'vegan', 'trade assurance', 'customer', 'supplier')
# 阿里卡片样板文本里的「地址」不是客户地址
CARD_MARK = ('this is a', 'card', 'product id', 'inquiry id', 'order id', 'product name is',
             'shipping address is china', 'lifeworth')


def _clean_co(s):
    s = re.sub(r'\s+', ' ', s).strip(' .,;:')
    return s


def _is_self(s):
    low = s.lower()
    return any(w in low for w in SELF_WORDS)


def _is_noise(s):
    """认证 / 成分 / 贸易 / 物流 / 问候词 —— 出现在公司名或品牌位就是误命中。"""
    toks = [t for t in re.split(r'[\s&,\./]+', s.lower()) if t]
    if not toks:
        return True
    if all(t in NOISE_TOKENS for t in toks):
        return True
    return _is_self(s)


def _looks_product(s):
    """带法律后缀但主体词是产品词的，多半是产品名 → 丢弃。"""
    low = s.lower()
    body = re.sub(r'\b(' + LEGAL_SUFFIX + r')\b', '', low, flags=re.I)
    return any(w in body for w in PRODUCT_HINT)


# 国际电话区号 → 国家（用于「手机归属国 vs 登录国」一致性判断，离线推断，不联网）
CALLING = {
    '1': 'US/CA', '7': 'RU/KZ', '20': 'EG', '27': 'ZA', '30': 'GR', '31': 'NL', '32': 'BE',
    '33': 'FR', '34': 'ES', '36': 'HU', '39': 'IT', '40': 'RO', '41': 'CH', '43': 'AT',
    '44': 'GB', '45': 'DK', '46': 'SE', '47': 'NO', '48': 'PL', '49': 'DE', '51': 'PE',
    '52': 'MX', '54': 'AR', '55': 'BR', '56': 'CL', '57': 'CO', '58': 'VE', '60': 'MY',
    '61': 'AU', '62': 'ID', '63': 'PH', '64': 'NZ', '65': 'SG', '66': 'TH', '81': 'JP',
    '82': 'KR', '84': 'VN', '86': 'CN', '90': 'TR', '91': 'IN', '92': 'PK', '94': 'LK',
    '95': 'MM', '98': 'IR', '212': 'MA', '213': 'DZ', '216': 'TN', '218': 'LY',
    '220': 'GM', '221': 'SN', '225': 'CI', '233': 'GH', '234': 'NG', '237': 'CM',
    '251': 'ET', '254': 'KE', '255': 'TZ', '256': 'UG', '263': 'ZW', '264': 'NA',
    '351': 'PT', '352': 'LU', '353': 'IE', '354': 'IS', '356': 'MT', '357': 'CY',
    '358': 'FI', '359': 'BG', '370': 'LT', '371': 'LV', '372': 'EE', '380': 'UA',
    '420': 'CZ', '421': 'SK', '501': 'BZ', '502': 'GT', '503': 'SV', '504': 'HN',
    '505': 'NI', '506': 'CR', '507': 'PA', '591': 'BO', '593': 'EC', '595': 'PY',
    '598': 'UY', '673': 'BN', '852': 'HK', '853': 'MO', '855': 'KH', '856': 'LA',
    '880': 'BD', '886': 'TW', '960': 'MV', '961': 'LB', '962': 'JO', '963': 'SY',
    '964': 'IQ', '965': 'KW', '966': 'SA', '967': 'YE', '968': 'OM', '971': 'AE',
    '972': 'IL', '973': 'BH', '974': 'QA', '975': 'BT', '976': 'MN', '977': 'NP',
}


def phone_region(raw):
    """从号码推断归属国（离线）。

    只认**带 + 的国际格式**：本地格式（如 17724649584）首两位恰好撞上某个区号，
    硬猜会得出错误国家（实测把 BD 客户的号码猜成 US/CA），所以宁可不猜。
    """
    raw = (raw or '').strip()
    if not raw.startswith('+'):
        return '', ''
    dg = re.sub(r'\D', '', raw)
    for n in (3, 2, 1):
        cc = dg[:n]
        if cc in CALLING:
            return '+' + cc, CALLING[cc]
    return '', ''


def country_of_login(login_id):
    """contactLoginId 前两位 = ISO 国家码（实测 254/254 全覆盖）。"""
    p = (login_id or '')[:2].lower()
    return (p.upper(), ISO2.get(p, '')) if p in ISO2 else ('', '')


def _is_card(content):
    """平台自动生成的产品卡/询盘卡/TA 卡 —— 实测 192 条挂在买家名下，必须剔除。"""
    t = (content or '').lstrip()
    return (t.startswith(('This is a', 'This is an')) or '[Card]' in t
            or 'card. The product' in t or 'card. Inquiry id' in t)


def _near_id(txt, i, span=46):
    """数字串前后是不是 'id is' / 'product' 这类标识字段（阿里产品 ID 有 13 位，极像电话）。"""
    seg = txt[max(0, i - span):i + span].lower()
    return any(w in seg for w in ('id is', 'id:', 'product id', 'inquiry id', 'order id',
                                  'product name', 'item id', 'sku', 'product card', 'order number',
                                  'tracking', 'track no', 'awb', 'waybill', 'reference number',
                                  'track number', 'shipment no'))


def crm_fields(crm):
    """从后台「客户详情」那批 CRM 字段里取邮箱/公司名（query_conversation_info 的返回）。

    之前只从聊天原文抽邮箱，覆盖率极低（5/245）；后台其实一直有 contactEmail，
    是抓数时没保存 —— 这行代码就是补这个洞。
    """
    k = crm or {}
    mail = (k.get('contactEmail') or '').strip().lower()
    comp = (k.get('customerBuyerName') or '').strip()
    return mail, comp


def extract_for(msgs):
    companies, domains, emails, phones, addrs, brands = (OrderedDict() for _ in range(6))
    bt = []   # 买家真实发言
    for m in msgs:
        if _is_card(m.get('content')):
            continue
        if m.get('senderRole') == 'buyer':
            bt.append(m.get('content') or '')
    btxt = '\n'.join(bt)

    # 公司名：只从买家自己的话里取（我方的消息里出现公司名多为我们自己的或样板文本）
    for m in CO_RE.finditer(btxt):
        s = _clean_co(m.group(1))
        if len(s) >= 5 and not _is_noise(s) and not _looks_product(s):
            companies[s] = companies.get(s, 0) + 1
    for m in INTRO_RE.finditer(btxt):
        s = _clean_co(re.split(r'[.,;!?\n]', m.group(1))[0])
        if not (3 <= len(s) <= 60) or _is_noise(s) or _looks_product(s + ' ltd'):
            continue
        if not all(w[:1].isupper() or w.lower() in ('of', 'and', 'the', '&')
                   for w in s.split()):
            continue   # 全首字母大写才收，否则 "we are waiting for design" 这类会被吃进来
        companies[s] = companies.get(s, 0) + 1

    for m in DOM_RE.finditer(btxt):
        d = m.group(1).lower()
        if is_junk_domain(d):
            continue
        if len(d) < 6 or d.count('.') > 3 or len(d.split('.')[0]) < 3:
            continue
        if d.startswith('www.'):
            d = d[4:]
        if is_junk_domain(d):
            continue
        domains[d] = domains.get(d, 0) + 1

    for m in re.finditer(r'[\w\.\-]+@[\w\-]+\.[a-z]{2,}', btxt, re.I):
        e = m.group(0).lower()
        if not e.startswith(('noreply', 'no-reply', 'service@alibaba')) and e.split('@')[0] not in ('info', 'contact'):
            emails[e] = emails.get(e, 0) + 1

    for m in TEL_RE.finditer(btxt):
        raw = m.group(0).strip()
        digits = re.sub(r'\D', '', raw)
        if not (8 <= len(digits) <= 14) or DATE_RE.match(raw) or DASHQTY_RE.match(raw):
            continue
        if _near_id(btxt, m.start()):
            continue
        seg = btxt[max(0, m.start() - 40):m.start() + 40].lower()
        if any(w in seg for w in QTY_NEAR):
            continue
        if len(digits) >= 13 and (digits.startswith(('1601', '1000', '1602')) or not raw.startswith('+')):
            continue   # 阿里产品/订单 ID
        if set(digits) == {'0'} or digits.endswith('000000'):
            continue
        phones[raw] = phones.get(raw, 0) + 1

    for m in ADDR_RE.finditer(btxt):
        a = re.sub(r'\s+', ' ', m.group(0)).strip()
        low = a.lower()
        if not (15 <= len(a) <= 150):
            continue
        if not re.search(r'\d', a):
            continue          # 街道地址必须有门牌/邮编数字
        if any(w in low for w in CARD_MARK) or 'lifeworth' in low:
            continue
        if '?' in a or any(w in low for w in ('moq', 'price', 'quantity', 'how many')):
            continue   # 问句里出现 "box 30" 这类不是地址
        if 'china' in low and ('广东' in a or '广州' in a or '深圳' in a):
            continue   # 我方发货地址
        addrs[a] = addrs.get(a, 0) + 1

    for m in BRAND_RE.finditer(btxt):
        b = (m.group(1) or m.group(2) or '').strip()
        if 3 <= len(b) <= 28 and not _is_noise(b) and not _looks_product(b):
            brands[b] = brands.get(b, 0) + 1
    for m in BRAND_INTRO_RE.finditer(btxt):
        b = _clean_co(re.split(r'[.,;!?\n]', m.group(1))[0])
        if 3 <= len(b) <= 28 and not _is_noise(b) and not _looks_product(b):
            brands[b] = brands.get(b, 0) + 1

    social, handles = OrderedDict(), OrderedDict()
    for m in SOCIAL_RE.finditer(btxt):
        u = re.sub(r'\s+$', '', m.group(0)).lower()
        social[u] = social.get(u, 0) + 1
    for m in AT_HANDLE_RE.finditer(btxt):
        h = m.group(1).lower()
        if h in NOISE_TOKENS or len(h) < 4:
            continue
        if h.endswith(('gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com')):
            continue
        handles[h] = handles.get(h, 0) + 1
    # 邮箱本地段当用户名（不是纯数字/乱码时）
    for e in list(emails):
        loc = e.split('@')[0]
        if len(loc) >= 4 and re.search(r'[a-z]{3}', loc) and not re.fullmatch(r'[a-z]{1,2}\d{6,}', loc):
            handles.setdefault(loc.replace('.', ''), handles.get(loc.replace('.', ''), 0) + 1)

    def ranked(d, n):
        return [k for k, _ in sorted(d.items(), key=lambda x: -x[1])[:n]]

    return dict(companies=ranked(companies, 5), domains=ranked(domains, 5), emails=ranked(emails, 3),
                phones=ranked(phones, 3), addresses=ranked(addrs, 3), brands=ranked(brands, 5),
                social=ranked(social, 4), handles=ranked(handles, 3))


def main():
    conv = json.load(io.open(os.path.join(INQ, 'conversations.json'), encoding='utf-8'))
    buyers = []
    bpath = os.path.join(INQ, 'buyers.json')
    if os.path.isfile(bpath):
        buyers = json.load(io.open(bpath, encoding='utf-8'))
    bmap = {b.get('contactName'): b for b in buyers}

    convs = [c for c in conv['conversations'] if (c.get('contactName') or '') != 'Assistant Eva']
    agg = OrderedDict()
    for c in convs:
        nm = c.get('contactName') or ''
        _k = c.get('crm') or {}
        e = agg.setdefault(nm, dict(loginId=c.get('contactLoginId') or '',
                                    aliId=c.get('contactAliId') or '',
                                    channels=set(), owners=set(), msgs=[],
                                    emails_crm=[], buyerName=''))
        e['channels'].add(c.get('channel') or 'TM')
        e['owners'].update(c.get('_owners') or [])
        e['msgs'].extend(c.get('messages') or [])
        _m, _b = crm_fields(c.get('crm'))
        if _m and _m not in e['emails_crm']:
            e['emails_crm'].append(_m)
        if _b and not e['buyerName']:
            e['buyerName'] = _b

    out = OrderedDict()
    for nm, e in agg.items():
        f = extract_for(e['msgs'])
        # 后台 CRM 字段优先：邮箱/公司名（contactEmail / customerBuyerName）
        _mails = list(e.get('emails_crm') or [])
        if _mails:
            f['emails'] = list(dict.fromkeys(_mails + f['emails']))[:3]
        _comp = (e.get('buyerName') or '').strip()
        if _comp and _comp.lower() not in ('none', 'null') and not _is_noise(_comp):
            f['companies'] = list(dict.fromkeys(([_comp] if len(_comp) >= 3 else []) + f['companies']))[:5]
        cc, cn = country_of_login(e['loginId'])
        p = (bmap.get(nm) or {}).get('persona') or {}
        nb = sum(1 for m in e['msgs'] if m.get('senderRole') == 'buyer' and not _is_card(m.get('content')))
        sig = []
        for k, lab in (('companies', '公司名'), ('domains', '自有域名'), ('emails', '邮箱'),
                       ('phones', '电话'), ('addresses', '地址'), ('brands', '品牌名'),
                       ('social', '社交链接')):
            if f[k]:
                sig.append(lab)
        mails = f['emails']
        kinds = []
        for _m in mails:      # 别用 e：外层 e 是 agg 里的会话条目
            _dom = _m.split('@')[-1].lower()
            kinds.append('企业邮箱' if (_dom not in FREE_MAIL and not is_junk_domain(_dom))
                         else '个人邮箱')
        if '企业邮箱' in kinds:
            sig.append('企业邮箱')
        out[nm] = dict(loginId=e['loginId'], aliId=e['aliId'],
                       channels='/'.join(sorted(e['channels'])),
                       owners=sorted(e['owners']), n_msgs=len(e['msgs']), n_buyer=nb,
                       country=cc, country_name=cn,
                       persona_country=(p.get('buyer_country_code') or '').upper(),
                       level=p.get('buyer_level') or '',
                       companies=f['companies'], domains=f['domains'], emails=f['emails'],
                       mail_kind='/'.join(dict.fromkeys(kinds)),
                       phones=f['phones'], addresses=f['addresses'], brands=f['brands'],
                       social=f['social'], handles=f['handles'], signals=sig,
                       phone_regions=[phone_region(x) for x in f['phones']])

    # 多个买家共用的域名（通常是平台短链或公共站点）不是「自有域名」→ 降级为「关联链接」
    shared = collections.Counter()
    for v in out.values():
        for d in v['domains']:
            shared[d] += 1
    for v in out.values():
        keep = [d for d in v['domains'] if shared[d] < 3]
        v['links'] = [d for d in v['domains'] if shared[d] >= 3]
        v['domains'] = keep
        v['signals'] = [s for s in v['signals'] if not (s == '自有域名' and not keep)]

    dst = os.path.join(INQ, 'entities.json')
    with io.open(dst, 'w', encoding='utf-8') as fh:
        fh.write(json.dumps(dict(store=conv.get('store'), window=conv.get('window'),
                                 buyers=out), ensure_ascii=False, indent=1))
    c = collections.Counter()
    for v in out.values():
        c['buyers'] += 1
        c['有国家'] += 1 if v['country'] else 0
        for k in ('companies', 'domains', 'emails', 'phones', 'addresses', 'brands'):
            c[k] += 1 if v[k] else 0
    print('已生成 %s' % dst)
    print('  ' + ' ｜ '.join('%s %d' % (k, v) for k, v in c.items()))
    nd = sum(len(v['domains']) for v in out.values())
    nc = sum(len(v['companies']) for v in out.values())
    print('  候选域名 %d 个 / 候选公司名 %d 个' % (nd, nc))


if __name__ == '__main__':
    sys.exit(main())
